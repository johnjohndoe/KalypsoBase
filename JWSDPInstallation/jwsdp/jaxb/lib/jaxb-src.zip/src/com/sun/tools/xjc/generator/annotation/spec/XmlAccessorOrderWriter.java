
package com.sun.tools.xjc.generator.annotation.spec;

import javax.xml.bind.annotation.AccessorOrder;
import javax.xml.bind.annotation.XmlAccessorOrder;
import com.sun.codemodel.JAnnotationWriter;
import com.sun.tools.xjc.generator.annotation.spec.XmlAccessorOrderWriter;

public interface XmlAccessorOrderWriter
    extends JAnnotationWriter<XmlAccessorOrder>
{


    XmlAccessorOrderWriter value(AccessorOrder value);

}
