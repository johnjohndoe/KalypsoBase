
package com.sun.tools.xjc.generator.annotation.spec;

import javax.xml.bind.annotation.AccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import com.sun.codemodel.JAnnotationWriter;
import com.sun.tools.xjc.generator.annotation.spec.XmlAccessorTypeWriter;

public interface XmlAccessorTypeWriter
    extends JAnnotationWriter<XmlAccessorType>
{


    XmlAccessorTypeWriter value(AccessType value);

}
