
package com.sun.tools.xjc.generator.annotation.spec;

import javax.xml.bind.annotation.XmlElementRefs;
import com.sun.codemodel.JAnnotationWriter;
import com.sun.tools.xjc.generator.annotation.spec.XmlElementRefWriter;
import com.sun.tools.xjc.generator.annotation.spec.XmlElementRefsWriter;

public interface XmlElementRefsWriter
    extends JAnnotationWriter<XmlElementRefs>
{


    XmlElementRefWriter value();

}
