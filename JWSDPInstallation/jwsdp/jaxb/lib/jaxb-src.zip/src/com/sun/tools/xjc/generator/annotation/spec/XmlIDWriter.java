
package com.sun.tools.xjc.generator.annotation.spec;

import javax.xml.bind.annotation.XmlID;
import com.sun.codemodel.JAnnotationWriter;
import com.sun.tools.xjc.generator.annotation.spec.XmlIDWriter;

public interface XmlIDWriter
    extends JAnnotationWriter<XmlID>
{


}
