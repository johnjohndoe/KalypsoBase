
package com.sun.tools.xjc.generator.annotation.spec;

import javax.xml.bind.annotation.XmlMimeType;
import com.sun.codemodel.JAnnotationWriter;
import com.sun.tools.xjc.generator.annotation.spec.XmlMimeTypeWriter;

public interface XmlMimeTypeWriter
    extends JAnnotationWriter<XmlMimeType>
{


    XmlMimeTypeWriter value(String value);

}
