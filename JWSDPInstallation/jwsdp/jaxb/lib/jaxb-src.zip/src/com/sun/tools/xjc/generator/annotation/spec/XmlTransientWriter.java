
package com.sun.tools.xjc.generator.annotation.spec;

import javax.xml.bind.annotation.XmlTransient;
import com.sun.codemodel.JAnnotationWriter;
import com.sun.tools.xjc.generator.annotation.spec.XmlTransientWriter;

public interface XmlTransientWriter
    extends JAnnotationWriter<XmlTransient>
{


}
