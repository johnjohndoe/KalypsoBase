
package com.sun.tools.xjc.generator.annotation.spec;

import javax.xml.bind.annotation.XmlValue;
import com.sun.codemodel.JAnnotationWriter;
import com.sun.tools.xjc.generator.annotation.spec.XmlValueWriter;

public interface XmlValueWriter
    extends JAnnotationWriter<XmlValue>
{


}
