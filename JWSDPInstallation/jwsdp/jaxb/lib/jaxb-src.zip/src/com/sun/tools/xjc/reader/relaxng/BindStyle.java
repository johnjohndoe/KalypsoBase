package com.sun.tools.xjc.reader.relaxng;

/**
 * @author Kohsuke Kawaguchi
 */
enum BindStyle {
    TYPE, ELEMENT
}
