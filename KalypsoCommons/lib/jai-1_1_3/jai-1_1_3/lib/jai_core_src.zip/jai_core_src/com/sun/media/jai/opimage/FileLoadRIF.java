/*
 * $RCSfile: FileLoadRIF.java,v $
 *
 * Copyright (c) 2005 Sun Microsystems, Inc. All rights reserved.
 *
 * Use is subject to license terms.
 *
 * $Revision: 1.1 $
 * $Date: 2005-02-11 04:56:26 $
 * $State: Exp $
 */
package com.sun.media.jai.opimage;

import java.awt.RenderingHints;
import java.awt.image.RenderedImage;
import java.awt.image.renderable.ParameterBlock;
import java.awt.image.renderable.RenderedImageFactory;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.AccessibleObject;
import java.lang.reflect.Method;

import javax.media.jai.JAI;
import javax.media.jai.OpImage;
import javax.media.jai.OperationRegistry;
import javax.media.jai.RenderedImageAdapter;
import javax.media.jai.registry.RIFRegistry;
import javax.media.jai.util.ImagingListener;

import com.sun.media.jai.codec.FileSeekableStream;
import com.sun.media.jai.codec.ImageDecodeParam;
import com.sun.media.jai.codec.SeekableStream;
import com.sun.media.jai.util.ImageUtil;

/*
 * Package-scope class which merely adds a finalize() method to close
 * the associated stream.
 */
class StreamImage extends RenderedImageAdapter {
	private final InputStream stream;

	/*
	 * Create the object and cache the stream.
	 */
	public StreamImage(final RenderedImage image, final InputStream stream) {
		super(image);
		this.stream = stream;
		if (image instanceof OpImage) {
			// Set the properties related to TileCache key as used in
			// RenderedOp.
			setProperty("tile_cache_key", image);
			final Object tileCache = ((OpImage) image).getTileCache();
			setProperty("tile_cache",
					tileCache == null ? java.awt.Image.UndefinedProperty
							: tileCache);
		}
	}

	@Override
	public synchronized void dispose() {
		// Use relection to invoke dispose();
		final RenderedImage trueSrc = getWrappedImage();
		Method disposeMethod = null;
		try {
			final Class cls = trueSrc.getClass();
			disposeMethod = cls.getMethod("dispose", null);
			if (!disposeMethod.isAccessible()) {
				AccessibleObject.setAccessible(
						new AccessibleObject[] { disposeMethod }, true);
			}
			disposeMethod.invoke(trueSrc, null);
		} catch (final Exception e) {
			// Ignore it.
		}

		try {
			if (stream != null)
				stream.close();
		} catch (final IOException e) {
			e.printStackTrace();
		}

		super.dispose();
	}

	/*
	 * Close the stream.
	 */
	@Override
	protected void finalize() throws Throwable {
		stream.close();
		super.finalize();
	}
}

/**
 * @see javax.media.jai.operator.FileDescriptor
 * 
 * @since EA3
 * 
 */
public class FileLoadRIF implements RenderedImageFactory {

	/** Constructor. */
	public FileLoadRIF() {
	}

	/**
	 * Creates an image from a String containing a file name.
	 */
	@Override
	public RenderedImage create(final ParameterBlock args, RenderingHints hints) {
		final ImagingListener listener = ImageUtil.getImagingListener(hints);

		try {
			// Create a SeekableStream from the file name (first parameter).
			final String fileName = (String) args.getObjectParameter(0);
			final SeekableStream src = new FileSeekableStream(fileName);

			ImageDecodeParam param = null;
			if (args.getNumParameters() > 1) {
				param = (ImageDecodeParam) args.getObjectParameter(1);
			}

			final ParameterBlock newArgs = new ParameterBlock();
			newArgs.add(src);
			newArgs.add(param);

			final RenderingHints.Key key = JAI.KEY_OPERATION_BOUND;
			final int bound = OpImage.OP_IO_BOUND;
			if (hints == null) {
				hints = new RenderingHints(key, new Integer(bound));
			} else if (!hints.containsKey(key)) {
				hints = (RenderingHints) hints.clone();
				hints.put(key, new Integer(bound));
			}

			// Get the registry from the hints, if any.
			// Don't check for null hints as it cannot be null here.
			final OperationRegistry registry = (OperationRegistry) hints
					.get(JAI.KEY_OPERATION_REGISTRY);

			// Create the image using the most preferred RIF for "stream".
			final RenderedImage image = RIFRegistry.create(registry, "stream",
					newArgs, hints);

			return image == null ? null : new StreamImage(image, src);

		} catch (final FileNotFoundException e) {
			final String message = JaiI18N.getString("FileLoadRIF0")
					+ args.getObjectParameter(0);
			listener.errorOccurred(message, e, this, false);
			// e.printStackTrace();
			return null;
		} catch (final Exception e) {
			final String message = JaiI18N.getString("FileLoadRIF1");
			listener.errorOccurred(message, e, this, false);
			// e.printStackTrace();
			return null;
		}
	}
}
