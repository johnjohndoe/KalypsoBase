//$HeadURL: https://sushibar/svn/deegree/base/trunk/src/org/deegree/model/csct/ct/CoordinateTransformationFactory.java $
/*----------------    FILE HEADER  ------------------------------------------
 This file is part of deegree.
 Copyright (C) 2001-2008 by:
 Department of Geography, University of Bonn
 http://www.giub.uni-bonn.de/deegree/
 lat/lon GmbH
 http://www.lat-lon.de

 This library is free software; you can redistribute it and/or
 modify it under the terms of the GNU Lesser General Public
 License as published by the Free Software Foundation; either
 version 2.1 of the License, or (at your option) any later version.
 This library is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 Lesser General Public License for more details.
 You should have received a copy of the GNU Lesser General Public
 License along with this library; if not, write to the Free Software
 Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 Contact:

 Andreas Poth
 lat/lon GmbH
 Aennchenstr. 19
 53177 Bonn
 Germany
 E-Mail: poth@lat-lon.de

 Prof. Dr. Klaus Greve
 Department of Geography
 University of Bonn
 Meckenheimer Allee 166
 53115 Bonn
 Germany
 E-Mail: greve@giub.uni-bonn.de
 ---------------------------------------------------------------------------*/
package org.deegree.crs.transformations;

// OpenGIS dependencies
import javax.vecmath.GMatrix;
import javax.vecmath.Matrix3d;
import javax.vecmath.Matrix4d;

import org.deegree.crs.components.Axis;
import org.deegree.crs.components.Ellipsoid;
import org.deegree.crs.components.GeodeticDatum;
import org.deegree.crs.components.PrimeMeridian;
import org.deegree.crs.components.Unit;
import org.deegree.crs.coordinatesystems.CoordinateSystem;
import org.deegree.crs.coordinatesystems.GeocentricCRS;
import org.deegree.crs.coordinatesystems.GeographicCRS;
import org.deegree.crs.coordinatesystems.ProjectedCRS;
import org.deegree.crs.exceptions.TransformationException;
import org.deegree.crs.projections.ProjectionUtils;
import org.deegree.crs.utilities.Matrix;
import org.deegree.framework.log.ILogger;
import org.deegree.framework.log.LoggerFactory;

/**
 * The <code>GeocentricTransform</code> class is the central access point for all transformations between different
 * crs's.
 * <p>
 * It creates a transformation chain for two given CoordinateSystems by considering their type. For example the
 * Transformation chain from EPSG:31466 ( a projected crs with underlying geographic crs epsg:4314 using the DHDN datum
 * and the TransverseMercator Projection) to EPSG:28992 (another projected crs with underlying geographic crs epsg:4289
 * using the 'new Amersfoort Datum' and the StereographicAzimuthal Projection) would result in following Transformation
 * Chain:
 * <ol>
 * <li>Inverse projection - thus getting the coordinates in lat/lon for geographic crs epsg:4314</li>
 * <li>Geodetic transformation - thus getting x-y-z coordinates for geographic crs epsg:4314</li>
 * <li>WGS84 transformation -thus getting the x-y-z coordinates for the WGS84 datum </li>
 * <li>Inverse WGS84 transformation -thus getting the x-y-z coordinates for the geodetic from epsg:4289</li>
 * <li>Inverse geodetic - thus getting the lat/lon for epsg:4289</li>
 * <li>projection - getting the coordinates (in meters) for epsg:28992</li>
 * </ol>
 * 
 * @author <a href="mailto:bezema@lat-lon.de">Rutger Bezema</a>
 * 
 * @author last edited by: $Author:$
 * 
 * @version $Revision:$, $Date:$
 * 
 */
public class TransformationFactory {
    private static ILogger LOG = LoggerFactory.getLogger( TransformationFactory.class );

    /**
     * The default coordinate transformation factory. Will be constructed only when first needed.
     */
    private static TransformationFactory DEFAULT_INSTANCE = null;

    private TransformationFactory() {
        // nottin
    }

    /**
     * @return the default coordinate transformation factory.
     */
    public static synchronized TransformationFactory getInstance() {
        if ( DEFAULT_INSTANCE == null ) {
            // DEFAULT_INSTANCE = new CoordinateTransformationFactory( MathTransformFactory.getDefault() );
            DEFAULT_INSTANCE = new TransformationFactory();
        }
        return DEFAULT_INSTANCE;
    }

    /**
     * Creates a transformation between two coordinate systems. This method will examine the coordinate systems in order
     * to construct a transformation between them. This method may fail if no path between the coordinate systems is
     * found.
     * 
     * @param sourceCRS
     *            Input coordinate system.
     * @param targetCRS
     *            Output coordinate system.
     * @return A coordinate transformation from <code>sourceCS</code> to <code>targetCS</code>.
     * @throws TransformationException
     * @throws TransformationException
     *             if no transformation path has been found.
     * 
     */
    public CRSTransformation createFromCoordinateSystems( final CoordinateSystem sourceCRS,
                                                          final CoordinateSystem targetCRS )
                                                                                            throws TransformationException {
        if ( sourceCRS == null ) {
            throw new IllegalArgumentException( "The source CRS may not be null" );
        }
        if ( targetCRS == null ) {
            throw new IllegalArgumentException( "The target CRS may not be null" );
        }
        if ( sourceCRS.equals( targetCRS ) ) {
            LOG.logDebug( "Source crs and target crs are equal, no transformation needed (returning identity matrix)." );
            final Matrix matrix = new Matrix( sourceCRS.getDimension() + 1 );
            matrix.setIdentity();
            return createAffineTransform( sourceCRS, targetCRS, matrix );
        }
        if ( ( sourceCRS.getType() != CoordinateSystem.GEOGRAPHIC_CRS && sourceCRS.getType() != CoordinateSystem.PROJECTED_CRS && sourceCRS.getType() != CoordinateSystem.GEOCENTRIC_CRS ) || ( targetCRS.getType() != CoordinateSystem.GEOGRAPHIC_CRS && targetCRS.getType() != CoordinateSystem.PROJECTED_CRS && targetCRS.getType() != CoordinateSystem.GEOCENTRIC_CRS ) ) {
            throw new TransformationException( sourceCRS,
                                               targetCRS,
                                               "Either the target crs type or the source crs type was unknown" );
        }
        CRSTransformation result = null;
        if ( sourceCRS.getType() == CoordinateSystem.GEOGRAPHIC_CRS ) {
            /**
             * Geographic --> Geographic, Projected or Geocentric
             */
            final GeographicCRS source = (GeographicCRS) sourceCRS;
            if ( targetCRS.getType() == CoordinateSystem.GEOGRAPHIC_CRS ) {
                result = createTransformationStep( source, (GeographicCRS) targetCRS );
            }
            if ( targetCRS.getType() == CoordinateSystem.PROJECTED_CRS ) {
                result = createTransformationStep( source, (ProjectedCRS) targetCRS );
            }
            if ( targetCRS.getType() == CoordinateSystem.GEOCENTRIC_CRS ) {
                result = createTransformationStep( source, (GeocentricCRS) targetCRS );
            }
        } else if ( sourceCRS.getType() == CoordinateSystem.PROJECTED_CRS ) {
            /**
             * Projected --> Projected, Geographic or Geocentric
             */
            final ProjectedCRS source = (ProjectedCRS) sourceCRS;
            if ( targetCRS.getType() == CoordinateSystem.PROJECTED_CRS ) {
                result = createTransformationStep( source, (ProjectedCRS) targetCRS );
            }
            if ( targetCRS.getType() == CoordinateSystem.GEOGRAPHIC_CRS ) {
                result = createTransformationStep( source, (GeographicCRS) targetCRS );
            }
            if ( targetCRS.getType() == CoordinateSystem.GEOCENTRIC_CRS ) {
                result = createTransformationStep( source, (GeocentricCRS) targetCRS );
            }
        } else if ( sourceCRS.getType() == CoordinateSystem.GEOCENTRIC_CRS ) {
            /**
             * Geocentric --> Geocentric, Horizontal or Compound
             */
            final GeocentricCRS source = (GeocentricCRS) sourceCRS;
            if ( targetCRS.getType() == CoordinateSystem.GEOCENTRIC_CRS ) {
                result = createTransformationStep( source, (GeocentricCRS) targetCRS );
            }
        }
        if ( result == null ) {
            LOG.logDebug( "The resulting transformation was null, returning an identity matrix." );
            final Matrix matrix = new Matrix( sourceCRS.getDimension() + 1 );
            matrix.setIdentity();
            result = createAffineTransform( sourceCRS, targetCRS, matrix );
        }
        if ( LOG.getLevel() == ILogger.LOG_DEBUG ) {
            StringBuilder output = new StringBuilder( "The resulting transformation chain: \n" );
            output = result.getTransformationPath( output );
            LOG.logDebug( output.toString() );
        }
        return result;

    }

    /**
     * Creates a transformation between two geographic coordinate systems. This method is automatically invoked by
     * {@link #createFromCoordinateSystems createFromCoordinateSystems(...)}. The default implementation can adjust
     * axis order and orientation (e.g. transforming from <code>(NORTH,WEST)</code> to <code>(EAST,NORTH)</code>),
     * performs units conversion and apply Bursa Wolf transformation if needed.
     * 
     * @param sourceCS
     *            Input coordinate system.
     * @param targetCS
     *            Output coordinate system.
     * @return A coordinate transformation from <code>sourceCS</code> to <code>targetCS</code>.
     * @throws TransformationException
     *             if no transformation path has been found.
     */
    private CRSTransformation createTransformationStep( final GeographicCRS sourceCS, final GeographicCRS targetCS )
                                                                                                                    throws TransformationException {
        if ( sourceCS.getGeodeticDatum().equals( targetCS.getGeodeticDatum() ) ) {
            LOG.logDebug( "The datums of geographic (source): " + sourceCS.getIdAndName()
                          + " equals geographic (target): "
                          + targetCS.getIdAndName()
                          + " returning null" );
            return null;
        }
        LOG.logDebug( "Creating geographic ->geographic transformation: from (source): " + sourceCS.getIdAndName()
                      + " to(target): "
                      + targetCS.getIdAndName() );
        final GeodeticDatum sourceDatum = sourceCS.getGeodeticDatum();
        final GeodeticDatum targetDatum = targetCS.getGeodeticDatum();
        final Ellipsoid sourceEllipsoid = sourceDatum.getEllipsoid();
        final Ellipsoid targetEllipsoid = targetDatum.getEllipsoid();
        if ( sourceEllipsoid != null && !sourceEllipsoid.equals( targetEllipsoid ) ) {
            /*
             * If the two geographic coordinate systems use differents ellipsoid, convert from the source to target
             * ellipsoid through the geocentric coordinate system.
             */
            final GeocentricCRS sourceGCS = new GeocentricCRS( sourceDatum,
                                                               sourceCS.getIdentifier(),
                                                               sourceCS.getName() + "Geocentric" );
            final GeocentricCRS targetGCS = new GeocentricCRS( targetDatum,
                                                               targetCS.getIdentifier(),
                                                               targetCS.getName() + "Geocentric" );
            CRSTransformation step1 = createTransformationStep( sourceCS, sourceGCS );
            LOG.logDebug( "Step 1 from geographic to geographic:\n" + step1 );
            CRSTransformation step2 = createTransformationStep( sourceGCS, targetGCS );
            LOG.logDebug( "Step 2 from geographic to geographic:\n" + step2 );
            CRSTransformation step3 = createTransformationStep( targetCS, targetGCS );
            LOG.logDebug( "Step 3 from geographic to geographic:\n" + step3 );
            if ( step3 != null ) {
                step3.inverse();// call inversetransform from step 3.
            }
            return concatenate( step1, step2, step3 );
        }

        /*
         * Swap axis order, and rotate the longitude coordinate if prime meridians are different.
         */
        final Matrix matrix = swapAndScaleGeoAxis( sourceCS, targetCS );
        // TODO: We should ensure that longitude is in range [-180..+180°].
        return createAffineTransform( sourceCS, targetCS, matrix );
        // return createFromMathTransform( sourceCS, targetCS, TransformType.CONVERSION, transform );
    }

    /**
     * Creates a transformation between a geographic and a projected coordinate systems. This method is automatically
     * invoked by {@link #createFromCoordinateSystems createFromCoordinateSystems(...)}.
     * 
     * @param sourceCRS
     *            Input coordinate system.
     * @param targetCRS
     *            Output coordinate system.
     * @return A coordinate transformation from <code>sourceCS</code> to <code>targetCS</code>.
     * @throws TransformationException
     *             if no transformation path has been found.
     */
    private CRSTransformation createTransformationStep( final GeographicCRS sourceCRS, final ProjectedCRS targetCRS )
                                                                                                                     throws TransformationException {

        LOG.logDebug( "Creating geographic->projected transformation: from (source): " + sourceCRS.getIdAndName()
                      + " to(target): "
                      + targetCRS.getIdAndName() );
        final GeographicCRS stepGeoCS = targetCRS.getGeographicCRS();

        // should perform a datum shift
        final CRSTransformation step1 = createTransformationStep( sourceCRS, stepGeoCS );
        final CRSTransformation step2 = new ProjectionTransform( targetCRS );
        return concatenate( step1, step2 );
    }

    /**
     * Creates a transformation between a geographic and a geocentric coordinate systems. Since the source coordinate
     * systems doesn't have a vertical axis, height above the ellipsoid is assumed equals to zero everywhere. This
     * method is automatically invoked by {@link #createFromCoordinateSystems createFromCoordinateSystems(...)}.
     * 
     * @param sourceCS
     *            Input geographic coordinate system.
     * @param targetCS
     *            Output coordinate system.
     * @return A coordinate transformation from <code>sourceCS</code> to <code>targetCS</code>.
     * @throws TransformationException
     *             if no transformation path has been found.
     */
    private CRSTransformation createTransformationStep( final GeographicCRS sourceCS, final GeocentricCRS targetCS )
                                                                                                                    throws TransformationException {
        LOG.logDebug( "Creating geographic ->geocentric transformation: from (source): " + sourceCS.getIdAndName()
                      + " to(target): "
                      + targetCS.getIdAndName() );
        if ( !PrimeMeridian.GREENWICH.equals( targetCS.getGeodeticDatum().getPrimeMeridian() ) ) {
            throw new TransformationException( "Rotation of prime meridian not yet implemented" );
        }
        final CRSTransformation step1 = createAffineTransform( sourceCS,
                                                               targetCS,
                                                               swapAndScaleGeoAxis( sourceCS, GeographicCRS.WGS84 ) );

        // TODO maybe something for a pool of transformations?
        final CRSTransformation step2 = new GeocentricTransform( sourceCS, targetCS );
        return createConcatenatedTransform( step1, step2 );
    }

    /**
     * Creates a transformation between two projected coordinate systems. This method is automatically invoked by
     * {@link #createFromCoordinateSystems createFromCoordinateSystems(...)}. The default implementation can adjust
     * axis order and orientation. It also performs units conversion if it is the only extra change needed. Otherwise,
     * it performs three steps:
     * 
     * <ol>
     * <li>Unproject <code>sourceCS</code>.</li>
     * <li>Transform from <code>sourceCS.geographicCS</code> to <code>targetCS.geographicCS</code>.</li>
     * <li>Project <code>targetCS</code>.</li>
     * </ol>
     * 
     * @param sourceCS
     *            Input coordinate system.
     * @param targetCS
     *            Output coordinate system.
     * @return A coordinate transformation from <code>sourceCS</code> to <code>targetCS</code>.
     * @throws TransformationException
     *             if no transformation path has been found.
     */
    private CRSTransformation createTransformationStep( final ProjectedCRS sourceCS, final ProjectedCRS targetCS )
                                                                                                                  throws TransformationException {
        LOG.logDebug( "Creating projected -> projected transformation: from (source): " + sourceCS.getIdAndName()
                      + " to(target): "
                      + targetCS.getIdAndName() );
        if ( sourceCS.getProjection().equals( targetCS.getProjection() ) ) {
            return null;
        }
        final GeographicCRS sourceGeo = sourceCS.getGeographicCRS();
        final GeographicCRS targetGeo = targetCS.getGeographicCRS();
        final CRSTransformation step1 = createTransformationStep( sourceCS, sourceGeo );
        LOG.logDebug( "Step 1: " + step1 );
        final CRSTransformation step2 = createTransformationStep( sourceGeo, targetGeo );
        LOG.logDebug( "Step 2: " + step2 );
        final CRSTransformation step3 = createTransformationStep( targetGeo, targetCS );
        LOG.logDebug( "Step 3: " + step3 );
        return concatenate( step1, step2, step3 );
    }

    /**
     * Creates a transformation between a projected and a geocentric coordinate systems. This method is automatically
     * invoked by {@link #createFromCoordinateSystems createFromCoordinateSystems(...)}. This method doesn't need to be
     * public since its decomposition in two step should be general enough.
     * 
     * @param sourceCS
     *            Input projected coordinate system.
     * @param targetCS
     *            Output coordinate system.
     * @return A coordinate transformation from <code>sourceCS</code> to <code>targetCS</code>.
     * @throws TransformationException
     *             if no transformation path has been found.
     */
    private CRSTransformation createTransformationStep( final ProjectedCRS sourceCS, final GeocentricCRS targetCS )
                                                                                                                   throws TransformationException {
        LOG.logDebug( "Creating projected -> geocentric transformation: from (source): " + sourceCS.getIdAndName()
                      + " to(target): "
                      + targetCS.getIdAndName() );
        final GeographicCRS sourceGCS = sourceCS.getGeographicCRS();

        final CRSTransformation step1 = createTransformationStep( sourceCS, sourceGCS );
        final CRSTransformation step2 = createTransformationStep( sourceGCS, targetCS );
        return concatenate( step1, step2 );
    }

    /**
     * Creates a transformation between a projected and a geographic coordinate systems. This method is automatically
     * invoked by {@link #createFromCoordinateSystems createFromCoordinateSystems(...)}. The default implementation
     * returns <code>{@link #createTransformationStep(GeographicCRS, ProjectedCRS)
     * createTransformationStep}(targetCS, sourceCS) inverse)</code>.
     * 
     * @param sourceCRS
     *            Input coordinate system.
     * @param targetCRS
     *            Output coordinate system.
     * @return A coordinate transformation from <code>sourceCS</code> to <code>targetCS</code> or <code>null</code>
     *         if {@link ProjectedCRS#getGeographicCRS()}.equals targetCRS.
     * @throws TransformationException
     *             if no transformation path has been found.
     */
    private CRSTransformation createTransformationStep( final ProjectedCRS sourceCRS, final GeographicCRS targetCRS )
                                                                                                                     throws TransformationException {
        LOG.logDebug( "Creating projected->geographic transformation: from (source): " + sourceCRS.getIdAndName()
                      + " to(target): "
                      + targetCRS.getIdAndName() );
        CRSTransformation result = createTransformationStep( targetCRS, sourceCRS );
        result.inverse();
        return result;

    }

    /**
     * Creates a transformation between two geocentric coordinate systems. This method is automatically invoked by
     * {@link #createFromCoordinateSystems createFromCoordinateSystems(...)}. The default implementation can adjust for
     * axis order and orientation, adjust for prime meridian, performs units conversion and apply Bursa Wolf
     * transformation if needed.
     * 
     * @param sourceCS
     *            Input coordinate system.
     * @param targetCS
     *            Output coordinate system.
     * @return A coordinate transformation from <code>sourceCS</code> to <code>targetCS</code>.
     * @throws TransformationException
     *             if no transformation path has been found.
     */
    private CRSTransformation createTransformationStep( final GeocentricCRS sourceCS, final GeocentricCRS targetCS )
                                                                                                                    throws TransformationException {
        LOG.logDebug( "Creating geocentric->geocetric transformation: from (source): " + sourceCS.getIdAndName()
                      + " to(target): "
                      + targetCS.getIdAndName() );
        final GeodeticDatum sourceHD = sourceCS.getGeodeticDatum();
        final GeodeticDatum targetHD = targetCS.getGeodeticDatum();
        if ( sourceHD.equals( targetHD ) ) {
            return null;
            // final Matrix matrix = swapAndScaleAxis( sourceCS, targetCS );
            // return createAffineTransform( sourceCS, targetCS, matrix );
        }
        if ( !PrimeMeridian.GREENWICH.equals( sourceHD.getPrimeMeridian() ) || !PrimeMeridian.GREENWICH.equals( targetHD.getPrimeMeridian() ) ) {
            throw new TransformationException( "Rotation of prime meridian not yet implemented" );
        }
        // Transform between differents ellipsoids
        // using Bursa Wolf parameters.
        Matrix tmp = swapAndScaleAxis( sourceCS, GeocentricCRS.WGS84 );
        Matrix4d step1 = null;
        if ( tmp != null ) {
            step1 = new Matrix4d();
            tmp.get( step1 );
        }
        final Matrix4d step2 = getWGS84Parameters( sourceHD );
        final Matrix4d step3 = getWGS84Parameters( targetHD );
        tmp = swapAndScaleAxis( GeocentricCRS.WGS84, targetCS );
        Matrix4d step4 = null;
        if ( tmp != null ) {
            step4 = new Matrix4d();
            tmp.get( step4 );
        }
        if ( step1 == null && step2 == null && step3 == null && step4 == null ) {
            LOG.logDebug( "The given geocentric crs's do not need a helmert transformation (but they are not equal), returning identity" );
            step4 = new Matrix4d();
            step4.setIdentity();
        } else {
            LOG.logDebug( "step1 matrix: \n " + step1 );
            LOG.logDebug( "step2 matrix: \n " + step2 );
            LOG.logDebug( "step3 matrix: \n " + step3 );
            LOG.logDebug( "step4 matrix: \n " + step4 );
            if ( step3 != null ) {
                step3.invert(); // Invert in place.
                LOG.logDebug( "step3 inverted matrix: \n " + step3 );
            }
            if ( step4 != null ) {
                if ( step3 != null ) {
                    step4.mul( step3 ); // step4 = step4*step3
                    LOG.logDebug( "step4 (after mul3): \n " + step4 );
                }
                if ( step2 != null ) {
                    step4.mul( step2 ); // step4 = step4*step3*step2
                    LOG.logDebug( "step4 (after mul2): \n " + step4 );
                }
                if ( step1 != null ) {
                    step4.mul( step1 ); // step4 = step4*step3*step2*step1
                }
            } else if ( step3 != null ) {
                step4 = step3;
                if ( step2 != null ) {
                    step4.mul( step2 ); // step4 = step3*step2*step1
                    LOG.logDebug( "step4 (after mul2): \n " + step4 );
                }
                if ( step1 != null ) {
                    step4.mul( step1 ); // step4 = step3*step2*step1
                }
            } else if ( step2 != null ) {
                step4 = step2;
                if ( step1 != null ) {
                    step4.mul( step1 ); // step4 = step2*step1
                }
            } else {
                step4 = step1;
            }
        }

        LOG.logDebug( "The resulting geo-geo matrix: from( " + sourceCS.getIdentifier()
                      + ") to("
                      + targetCS.getIdentifier()
                      + ")\n "
                      + step4 );
        return new MatrixTransform( sourceCS, targetCS, step4, CRSTransformation.createFromTo( sourceCS.getIdentifier(), targetCS.getIdentifier() ), "Helmert-Transformation" );
    }

    /**
     * Concatenates two existing transforms.
     * 
     * @param tr1
     *            The first transform to apply to points.
     * @param tr2
     *            The second transform to apply to points.
     * @return The concatenated transform.
     * 
     */
    private CRSTransformation createConcatenatedTransform( CRSTransformation tr1, CRSTransformation tr2 ) {
        if ( tr1 == null ) {
            return tr2;
        }
        if ( tr2 == null ) {
            return tr1;
        }
        // if one of the two is an identity transformation, just return the other.
        if ( tr1.isIdentity() ) {
            return tr2;
        }
        if ( tr2.isIdentity() ) {
            return tr1;
        }

        /*
         * If one transform is the inverse of the other, just return an identitiy transform.
         */
        if ( tr1.areInverse( tr2 ) ) {
            LOG.logDebug( "Transformation1 and Transformation2 are inverse operations, returning null" );
            return null;
        }

        /*
         * If both transforms use matrix, then we can create a single transform using the concatened matrix.
         */
        if ( tr1 instanceof MatrixTransform && tr2 instanceof MatrixTransform ) {
            GMatrix m1 = ( (MatrixTransform) tr1 ).getMatrix();
            GMatrix m2 = ( (MatrixTransform) tr2 ).getMatrix();
            if ( m1 == null ) {
                if ( m2 == null ) {
                    // both matrices are null, just return the identiy matrix.
                    return new MatrixTransform( tr1.getSourceCRS(),
                                                tr1.getTargetCRS(),
                                                new GMatrix( tr2.getTargetDimension() + 1, tr1.getSourceDimension() + 1 ) );
                }
                return tr2;
            } else if ( m2 == null ) {
                return tr1;
            }
            m2.mul( m1 );
            return new MatrixTransform( tr1.getSourceCRS(), tr2.getTargetCRS(), m2 );
        }

        /*
         * If one or both math transform are instance of {@link ConcatenatedTransform}, then concatenate <code>tr1</code>
         * or <code>tr2</code> with one of step transforms.
         */
        if ( tr1 instanceof ConcatenatedTransform ) {
            final ConcatenatedTransform ctr = (ConcatenatedTransform) tr1;
            tr1 = ctr.getFirstTransform();
            tr2 = createConcatenatedTransform( ctr.getSecondTransform(), tr2 );
        }
        if ( tr2 instanceof ConcatenatedTransform ) {
            final ConcatenatedTransform ctr = (ConcatenatedTransform) tr2;
            tr1 = createConcatenatedTransform( tr1, ctr.getFirstTransform() );
            tr2 = ctr.getSecondTransform();
        }

        return new ConcatenatedTransform( tr1, tr2 );
    }

    /**
     * Creates an affine transform from a matrix.
     * 
     * @param matrix
     *            The matrix used to define the affine transform.
     * @return The affine transform.
     * @throws TransformationException
     *             if the matrix is not affine.
     * 
     */
    private MatrixTransform createAffineTransform( CoordinateSystem source, CoordinateSystem target, final Matrix matrix )
                                                                                                                          throws TransformationException {
        if ( matrix == null ) {
            return null;
        }
        if ( matrix.isAffine() ) {// Affine transform are square.
            if ( matrix.getNumRow() == 3 && matrix.getNumCol() == 3 && !matrix.isIdentity() ) {
                LOG.logDebug( "Creating affineTransform of incoming matrix:\n" + matrix );
                Matrix3d tmp = matrix.toAffineTransform();
                LOG.logDebug( "Resulting AffineTransform is:\n" + tmp );
                return new MatrixTransform( source, target, tmp );
            }
            return new MatrixTransform( source, target, matrix );
        }
        throw new TransformationException( "Given matrix is not affine, cannot continue" );
    }

    /**
     * Returns the WGS84 parameters as an affine transform, or <code>null</code> if not available.
     */
    private Matrix4d getWGS84Parameters( final GeodeticDatum datum ) {
        final WGS84ConversionInfo info = datum.getWGS84Conversion();
        if ( info != null && !( new WGS84ConversionInfo( "test" ) ).equals( info ) ) {
            return info.getAsAffineTransform();
        }
        return null;
    }

    /**
     * Concatenate two transformation steps.
     * 
     * @param step1
     *            The first step, or <code>null</code> for the identity transform.
     * @param step2
     *            The second step, or <code>null</code> for the identity transform.
     * @return A concatenated transform, or <code>null</code> if all arguments was nul.
     */
    private CRSTransformation concatenate( final CRSTransformation step1, final CRSTransformation step2 ) {
        if ( step1 == null )
            return step2;
        if ( step2 == null )
            return step1;
//        if ( !step1.getTargetCRS().equals( step2.getSourceCRS() ) ) {
//            throw new IllegalArgumentException( "The given crsTranformation can not be concatenated because the first tranformations targetCRS: " + step1.getTargetCRS()
//                                                                                                                                                         .getIdentifier()
//                                                + " does not match the second transformations sourceCRS: "
//                                                + step2.getSourceCRS().getIdentifier() );
//        }
        return createConcatenatedTransform( step1, step2 );
    }

    /**
     * Concatenate three transformation steps.
     * 
     * @param step1
     *            The first step, or <code>null</code> for the identity transform.
     * @param step2
     *            The second step, or <code>null</code> for the identity transform.
     * @param step3
     *            The third step, or <code>null</code> for the identity transform.
     * @return A concatenated transform, or <code>null</code> if all arguments were <code>null</code>.
     */
    private CRSTransformation concatenate( final CRSTransformation step1, final CRSTransformation step2,
                                           final CRSTransformation step3 ) {
        if ( step1 == null ){
            return concatenate( step2, step3 );
        }
        if ( step2 == null ){
            return concatenate( step1, step3 );
        }
        if ( step3 == null ) {
            return concatenate( step1, step2 );
        }
        return createConcatenatedTransform( step1, createConcatenatedTransform( step2, step3 ) );
    }

    /**
     * Returns an affine transform between two coordinate systems. Only units and axis order (e.g. transforming from
     * (NORTH,WEST) to (EAST,NORTH)) are taken in account. Other attributes (especially the datum) must be checked
     * before invoking this method.
     * 
     * @param sourceCS
     *            The source coordinate system. If <code>null</code>, then (x,y,z,t) axis order is assumed.
     * @param targetCS
     *            The target coordinate system. If <code>null</code>, then (x,y,z,t) axis order is assumed.
     */
    private Matrix swapAndScaleAxis( final CoordinateSystem sourceCS, final CoordinateSystem targetCS )
                                                                                                       throws TransformationException {
        LOG.logDebug( "Creating swap matrix from: " + sourceCS.getIdAndName() + " to: " + targetCS.getIdAndName() );
        final Axis[] sourceAxis = sourceCS.getAxis();
        final Axis[] targetAxis = targetCS.getAxis();
        final Matrix matrix;
        try {
            matrix = Matrix.createAffineTransform( sourceAxis, targetAxis );
        } catch ( RuntimeException e ) {
            throw new TransformationException( sourceCS, targetCS, e.getMessage() );
        }
        // Convert units if necessary
        final int dimension = matrix.getNumRow() - 1;
        for ( int i = 0; i < dimension; i++ ) {
            final Unit sourceUnit = sourceAxis[i].getUnits();
            final Unit targetUnit = targetAxis[i].getUnits();
            double offset = 0;
            double scale = 1;
            if ( !sourceUnit.equals( targetUnit ) ) {
                offset = targetUnit.convert( 0, sourceUnit );
                scale = targetUnit.convert( 1, sourceUnit ) - offset;
            }
            matrix.setElement( i, i, scale * matrix.getElement( i, i ) );
            matrix.setElement( i, dimension, scale * matrix.getElement( i, dimension ) + offset );
        }
        if ( matrix.isIdentity() ) {
            return null;
        }
        return matrix;
    }

    /**
     * Returns an affine transform between two geographic coordinate systems. Only units, axis order (e.g. transforming
     * from (NORTH,WEST) to (EAST,NORTH)) and prime meridian are taken in account. Other attributes (especially the
     * datum) must be checked before invoking this method.
     * 
     * @param sourceCS
     *            The source coordinate system.
     * @param targetCS
     *            The target coordinate system.
     */
    private Matrix swapAndScaleGeoAxis( final GeographicCRS sourceCS, final GeographicCRS targetCS )
                                                                                                    throws TransformationException {
        LOG.logDebug( "Creating geo swap matrix from: " + sourceCS.getIdAndName() + " to: " + targetCS.getIdAndName() );
        final Matrix matrix = swapAndScaleAxis( sourceCS, targetCS );
        if ( matrix != null ) {
            Axis[] targetAxis = targetCS.getAxis();
            final int lastMatrixColumn = matrix.getNumCol() - 1;
            for ( int i = targetCS.getDimension(); --i >= 0; ) {
                // Find longitude, and apply a translation if prime meridians are different.
                final int orientation = targetAxis[i].getOrientation();
                if ( Axis.AO_EAST == Math.abs( orientation ) ) {
                    final Unit unit = targetAxis[i].getUnits();
                    final double sourceLongitude = sourceCS.getGeodeticDatum().getPrimeMeridian().getLongitude( unit );
                    final double targetLongitude = targetCS.getGeodeticDatum().getPrimeMeridian().getLongitude( unit );
                    if ( Math.abs( sourceLongitude - targetLongitude ) > ProjectionUtils.EPS11 ) {
                        double translation = targetLongitude - sourceLongitude;
                        if ( Axis.AO_WEST == orientation ) {
                            translation = -translation;
                        }
                        // add the translation to the matrix translate element of this axis
                        matrix.setElement( i, lastMatrixColumn, matrix.getElement( i, lastMatrixColumn ) - translation );
                    }
                }
            }
        }
        return matrix;
    }
}
