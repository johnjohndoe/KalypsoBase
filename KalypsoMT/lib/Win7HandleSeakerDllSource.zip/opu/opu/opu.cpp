// opu.cpp : Defines the exported functions for the DLL application.
//

#include "stdafx.h"
#include "org_kalypso_mt_input_MTWin7CanvasHandleSeeker.h"


JNIEXPORT jint JNICALL Java_org_kalypso_mt_input_MTWin7CanvasHandleSeeker_getHWND
  (JNIEnv *, jobject, jlong hwndParent)
{
	HWND hwnd;
	TCHAR buf[200];

	buf[0] = 0;

	hwnd = (HWND) hwndParent;
	while (hwnd != 0) {
		hwnd = GetWindow( hwnd, GW_CHILD );
		buf[0] = 0;
		GetClassName( hwnd, buf, 200 );
		
		if ( wcscmp( buf, L"SunAwtCanvas") == 0 ) {
			//printf("Found SunAwtCanvas: %i\r\n", hwnd );
			return (jint) hwnd;
		}
	}

	return 0;
}


const ULONG TOUCH_FLAGS(/*TWF_FINETOUCH|*/TWF_WANTPALM);

JNIEXPORT void JNICALL Java_org_kalypso_mt_input_MTWin7CanvasHandleSeeker_registerTouchWindowByHwnd
  (JNIEnv *, jobject, jlong hwnd)
{
	RegisterTouchWindow((HWND) hwnd, TOUCH_FLAGS);
}

