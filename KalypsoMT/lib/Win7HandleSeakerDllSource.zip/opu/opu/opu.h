
// The following ifdef block is the standard way of creating macros which make exporting 
// from a DLL simpler. All files within this DLL are compiled with the OPU_EXPORTS
// symbol defined on the command line. This symbol should not be defined on any project
// that uses this DLL. This way any other project whose source files include this file see 
// OPU_API functions as being imported from a DLL, whereas this DLL sees symbols
// defined with this macro as being exported.
#ifdef OPU_EXPORTS
#define OPU_API __declspec(dllexport)
#else
#define OPU_API __declspec(dllimport)
#endif


// This class is exported from the opu.dll
class OPU_API Copu {
public:
	Copu(void);
	// TODO: add your methods here.
};

//extern "C" JNIEXPORT jint JNICALL Java_plugtest_StartTailExample_getHWND(void);

#include "jni.h"
/* Header for class plugtest_StartTailExample */

#ifndef _Included_plugtest_StartTailExample
#define _Included_plugtest_StartTailExample
#ifdef __cplusplus
extern "C" {
#endif
#undef plugtest_StartTailExample_serialVersionUID
#define plugtest_StartTailExample_serialVersionUID 1i64
#undef plugtest_StartTailExample_serialVersionUID
#define plugtest_StartTailExample_serialVersionUID 1i64
/*
 * Class:     plugtest_StartTailExample
 * Method:    getHWND
 * Signature: (I)I
 */
JNIEXPORT jint JNICALL Java_plugtest_StartTailExample_getHWND
  (JNIEnv *, jobject, jint);

#ifdef __cplusplus
}
#endif
#endif
