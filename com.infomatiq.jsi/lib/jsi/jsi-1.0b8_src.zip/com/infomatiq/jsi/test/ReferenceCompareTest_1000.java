package com.infomatiq.jsi.test;

public class ReferenceCompareTest_1000 extends ReferenceCompareTest {
	public ReferenceCompareTest_1000(String s) {
		super(s);
		entriesToTest = 1000;
	}
}

