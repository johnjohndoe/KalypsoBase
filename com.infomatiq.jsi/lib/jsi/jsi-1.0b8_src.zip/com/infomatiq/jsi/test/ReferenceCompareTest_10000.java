package com.infomatiq.jsi.test;

public class ReferenceCompareTest_10000 extends ReferenceCompareTest {
	public ReferenceCompareTest_10000(String s) {
		super(s);
		entriesToTest = 10000;
	}
}

