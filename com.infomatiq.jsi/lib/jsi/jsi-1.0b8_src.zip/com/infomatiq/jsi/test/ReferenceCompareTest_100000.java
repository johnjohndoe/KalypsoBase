package com.infomatiq.jsi.test;

public class ReferenceCompareTest_100000 extends ReferenceCompareTest {
	public ReferenceCompareTest_100000(String s) {
		super(s);
		entriesToTest = 100000;
	}
}

