package com.infomatiq.jsi.test;

public class ReferenceGenerateTest_1000 extends ReferenceGenerateTest {

	public ReferenceGenerateTest_1000(String s) {
		super(s);
		entriesToTest = 1000;
	}
}
