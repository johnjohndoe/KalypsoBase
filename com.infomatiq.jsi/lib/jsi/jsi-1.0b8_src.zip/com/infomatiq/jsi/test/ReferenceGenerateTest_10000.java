package com.infomatiq.jsi.test;

public class ReferenceGenerateTest_10000 extends ReferenceGenerateTest {

	public ReferenceGenerateTest_10000(String s) {
		super(s);
		entriesToTest = 10000;
	}
}
