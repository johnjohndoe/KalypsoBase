<?xml version="1.0" encoding="WINDOWS-1252"?>
<cov:CoverageCollection xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:gml="http://www.opengis.net/gml" xmlns:xs="http://www.w3.org/2001/XMLSchema-instance" xmlns:cov="org.kalypso.gml.common.coverage" gml:id="root">
 <gml:description>testCollection</gml:description>
 <gml:name>testCollection</gml:name>
</cov:CoverageCollection>
