rem ;rd %1 /s/q
rem ;md %1

echo on

set targetdir=..\data\sobek_river
set targetformat=Sobek
set sourcefile=..\..\iDSS2PIstatic\nodes.xml
set sobekdir=%SOBEKROOT%\PROGRAMS

md %targetdir%
md %targetdir%\CMTWORK 
md %targetdir%\work 
md %targetdir%\FIXED

IF NOT %targetformat%==Sobek goto endsobekcreatetarget
  xcopy defaults\WORK\. %targetdir%\WORK\ /s /y
  xcopy defaults\CMTWORK\. %targetdir%\CMTWORK\ /s /y
  xcopy defaults\FIXED\. %targetdir%\FIXED\ /s /y
:endsobekcreatetarget

cd "%targetdir%\CMTWORK\"

dir

%sobekdir%\conv_sbk\Conv_Sbk.exe %sobekdir%\conv_sbk\PIstatic_sbk.ini /FILE=%sourcefile% /TARGET=%targetformat% 

type conv_sbk.log

cd ..\..\..\batch
