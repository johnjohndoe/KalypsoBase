;rd %1 /s/q
;md %1

echo on

set inifile=.\PIstatic_sbk.ini
set targetdir=..\data\sobek_river
set targetformat=Sobek
set sourcefile=..\..\iDSS2PIstatic\nodes.xml

md %targetdir%
md %targetdir%\CMTWORK 
md %targetdir%\work 
md %targetdir%\FIXED

IF NOT %targetformat%==Sobek goto endsobekcreatetarget
  xcopy defaults\WORK\. %targetdir%\WORK\ /s /y
:endsobekcreatetarget

IF NOT %targetformat%==Sobek goto endsobekcreatetarget
  xcopy defaults\CMTWORK\. %targetdir%\CMTWORK\ /s /y
:endsobekcreatetarget

IF NOT %targetformat%==Sobek goto endsobekcreatetarget
  xcopy defaults\FIXED\. %targetdir%\FIXED\ /s /y
:endsobekcreatetarget

copy %inifile% %targetdir%\CMTWORK\.

cd "%targetdir%\CMTWORK\"

dir

..\..\..\bin\Wl\Sobek\Conv_Sbk.exe %inifile% /FILE=%sourcefile% /TARGET=%targetformat% 

type conv_sbk.log

cd ..\..\..\batch

