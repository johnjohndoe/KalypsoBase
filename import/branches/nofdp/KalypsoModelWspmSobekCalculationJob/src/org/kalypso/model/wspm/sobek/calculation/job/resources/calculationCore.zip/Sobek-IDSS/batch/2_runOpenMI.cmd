cd ..\data\iDSS2OpenMI
..\..\bin\Oatc.OpenMI.Gui.CommandLine.exe -r sobek_river-fews_pi.opr
cd ..\..\batch
