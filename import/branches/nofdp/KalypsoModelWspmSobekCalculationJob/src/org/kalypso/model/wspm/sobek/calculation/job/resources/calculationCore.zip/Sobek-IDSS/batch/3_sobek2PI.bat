
set sourceDir=..\data\sobek_river\work
set targetDir=..\data\OpenMI2PIdyn

..\bin\hisxmlconverter %sourceDir%/calcpnt.his %targetDir%\calcpnt.xml /batch /debug /diagfile %targetDir%\diag_calcpnt_hisxmlconverter.xml
rem ..\bin\hisxmlconverter %sourceDir%/reachseg.his %targetDir%\reachseg.xml /batch /debug /diagfile %targetDir%\diag_reachseg_hisxmlconverter.xml
..\bin\hisxmlconverter %sourceDir%/struc.his %targetDir%\struc.xml /batch /debug /diagfile %targetDir%\diag_struc_hisxmlconverter.xml

