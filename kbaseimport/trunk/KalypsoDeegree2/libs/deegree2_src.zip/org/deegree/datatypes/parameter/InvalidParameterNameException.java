//$HeadURL: https://svn.wald.intevation.org/svn/deegree/base/trunk/src/org/deegree/datatypes/parameter/InvalidParameterNameException.java $
/*$************************************************************************************************
 **
 ** $Id: InvalidParameterNameException.java 6259 2007-03-20 09:15:15Z bezema $
 **
 ** $Source$
 **
 ** Copyright (C) 2003 Open GIS Consortium, Inc. All Rights Reserved. http://www.opengis.org/Legal/
 **
 *************************************************************************************************/
package org.deegree.datatypes.parameter;

/**
 * Thrown when an invalid parameter name was requested in a
 * {@linkplain OperationParameterGroupIm parameter group}.
 * 
 * @UML exception GC_InvalidParameterName
 * @author <A HREF="http://www.opengis.org">OpenGIS&reg; consortium</A>
 * @version <A HREF="http://www.opengis.org/docs/01-004.pdf">Grid Coverage specification 1.0</A>
 * @author last edited by: $Author: bezema $
 * 
 * @version $Revision: 6259 $, $Date: 2007-03-20 10:15:15 +0100 (Di, 20 Mrz 2007) $
 * 
 * @see OperationParameterGroupIm#getParameter
 * @see ParameterValueGroupIm#getValue
 */
public class InvalidParameterNameException extends IllegalArgumentException {
    /**
     * Serial number for interoperability with different versions.
     */
    private static final long serialVersionUID = -8473266898408204803L;

    /**
     * The invalid parameter name.
     */
    private final String parameterName;

    /**
     * Creates an exception with the specified message and parameter name.
     * 
     * @param message
     *            The detail message. The detail message is saved for later retrieval by the
     *            {@link #getMessage()} method.
     * @param parameterName
     *            The invalid parameter name.
     */
    public InvalidParameterNameException( String message, String parameterName ) {
        super( message );
        this.parameterName = parameterName;
    }

    /**
     * Returns the invalid parameter name.
     * 
     * @return the invalid parameter name.
     */
    public String getParameterName() {
        return parameterName;
    }
}
/***************************************************************************************************
 * <code>
 Changes to this class. What the people have been up to:
 
 $Log$
 Revision 1.2  2007/03/06 09:11:10  wanhoff
 Fixed Javadoc (@see, @link, @return)

 Revision 1.1  2007/02/09 17:26:53  poth
 *** empty log message ***

 Revision 1.2  2006/07/13 06:28:31  poth
 comment footer added

 </code>
 **************************************************************************************************/
