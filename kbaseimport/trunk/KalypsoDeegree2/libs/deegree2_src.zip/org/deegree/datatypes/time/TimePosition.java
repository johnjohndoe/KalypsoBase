//$HeadURL: https://svn.wald.intevation.org/svn/deegree/base/trunk/src/org/deegree/datatypes/time/TimePosition.java $
package org.deegree.datatypes.time;

import java.io.Serializable;
import java.net.URI;
import java.util.Calendar;
import java.util.GregorianCalendar;

/**
 * @version $Revision: 6696 $
 * @author <a href="mailto:poth@lat-lon.de">Andreas Poth</a>
 * @author last edited by: $Author: apoth $
 * 
 * @version 1.0. $Revision: 6696 $, $Date: 2007-04-25 21:57:05 +0200 (Mi, 25 Apr 2007) $
 * 
 * @since 2.0
 */

public class TimePosition implements Cloneable, Serializable {

    private static final long serialVersionUID = 1L;

    private TimeIndeterminateValue indeterminatePosition = null;

    private String calendarEraName = null;
    private URI frame = null; 
    private Calendar time = null;
    
    /**
     * defaults are:
     * <ul>
     *  <li>indeterminatePosition = now</li>
     *  <li>calendarEraName = AC</li>
     *  <li>frame = #ISO-8601</li>
     *  <li>time = new GregorianCalendar()</li>
     * </ul>
     */
    public TimePosition() {
        indeterminatePosition = new TimeIndeterminateValue();
        calendarEraName = "AC";
        try {
            frame = new URI( "#ISO-8601" );
        } catch(Exception e) {
            e.printStackTrace();
        }
        time = new GregorianCalendar();
    }
    
    
    /**
     * defaults are:
     * <ul>
     *  <li>indeterminatePosition = now</li>
     *  <li>calendarEraName = AC</li>
     *  <li>frame = #ISO-8601</li>
     * </ul>
     * @param time
     */
    public TimePosition(Calendar time) {
        this.time = time;
        indeterminatePosition = new TimeIndeterminateValue();
        calendarEraName = "AC";
        try {
            frame = new URI( "#ISO-8601" );
        } catch(Exception e) {
            e.printStackTrace();
        }        
    }
    
    /**
     * @param indeterminatePosition
     * @param calendarEraName
     * @param frame
     * @param time
     */
    public TimePosition(TimeIndeterminateValue indeterminatePosition, String calendarEraName, 
                        URI frame, Calendar time) {
        this.indeterminatePosition = indeterminatePosition;
        this.calendarEraName = calendarEraName;
        this.frame = frame;
        this.time = time;
    }

    /**
     * @return Returns the calendarEraName.
     * 
     */
    public String getCalendarEraName() {
        return calendarEraName;
    }

    /**
     * @param calendarEraName The calendarEraName to set.
     * 
     */
    public void setCalendarEraName(String calendarEraName) {
        this.calendarEraName = calendarEraName;
    }

    /**
     * @return Returns the frame.
     * 
     */
    public URI getFrame() {
        return frame;
    }

    /**
     * @param frame The frame to set.
     * 
     */
    public void setFrame(URI frame) {
        this.frame = frame;
    }

    /**
     * @return Returns the indeterminatePosition.
     * 
     */
    public TimeIndeterminateValue getIndeterminatePosition() {
        return indeterminatePosition;
    }

    /**
     * @param indeterminatePosition The indeterminatePosition to set.
     * 
     */
    public void setIndeterminatePosition(
        TimeIndeterminateValue indeterminatePosition) {
        this.indeterminatePosition = indeterminatePosition;
    }

    /**
     * @return Returns the time.
     * 
     */
    public Calendar getTime() {
        return time;
    }

    /**
     * @param time The time to set.
     * 
     */
    public void setTime(Calendar time) {
        this.time = time;
    }

    
    
    /**
     * @see java.lang.Object#clone()
     */
    public Object clone() {
        return new TimePosition( indeterminatePosition, calendarEraName, frame, time );
    }
    
}