//$HeadURL: https://svn.wald.intevation.org/svn/deegree/base/trunk/src/org/deegree/framework/trigger/TargetMethod.java $
/*----------------    FILE HEADER  ------------------------------------------

 This file is part of deegree.
 Copyright (C) 2001-2006 by:
 EXSE, Department of Geography, University of Bonn
 http://www.giub.uni-bonn.de/deegree/
 lat/lon GmbH
 http://www.lat-lon.de

 This library is free software; you can redistribute it and/or
 modify it under the terms of the GNU Lesser General Public
 License as published by the Free Software Foundation; either
 version 2.1 of the License, or (at your option) any later version.

 This library is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 Lesser General Public License for more details.

 You should have received a copy of the GNU Lesser General Public
 License along with this library; if not, write to the Free Software
 Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

 Contact:

 Andreas Poth
 lat/lon GmbH
 Aennchenstr. 19
 53177 Bonn
 Germany
 E-Mail: poth@lat-lon.de

 Prof. Dr. Klaus Greve
 Department of Geography
 University of Bonn
 Meckenheimer Allee 166
 53115 Bonn
 Germany
 E-Mail: greve@giub.uni-bonn.de

 ---------------------------------------------------------------------------*/
package org.deegree.framework.trigger;

/**
 * 
 * 
 * 
 * @version $Revision: 6259 $
 * @author <a href="mailto:poth@lat-lon.de">Andreas Poth</a>
 * @author last edited by: $Author: bezema $
 * 
 * @version 1.0. $Revision: 6259 $, $Date: 2007-03-20 10:15:15 +0100 (Di, 20 Mrz 2007) $
 * 
 * @since 2.0
 */
public class TargetMethod {

    private String name;

    private TriggerCapability preTrigger;

    private TriggerCapability postTrigger;

    /**
     * 
     * @param name
     *            name of the method
     * @param preTrigger
     *            may be <code>null</code>
     * @param postTrigger
     *            may be <code>null</code>
     */
    public TargetMethod( String name, TriggerCapability preTrigger, TriggerCapability postTrigger ) {
        this.name = name;
        this.preTrigger = preTrigger;
        this.postTrigger = postTrigger;
    }

    /**
     * returns the name of the method
     * 
     * @return the name of the method
     */
    public String getName() {
        return name;
    }

    /**
     * returns the capabilities of pre trigger assigned to the method. If no pre trigger is assigned
     * <code>null</code> will be returned.
     * 
     * @return the capabilities of pre trigger assigned to the method. If no pre trigger is assigned
     *         <code>null</code> will be returned.
     */
    public TriggerCapability getPostTrigger() {
        return postTrigger;
    }

    /**
     * returns the capabilities of post trigger assigned to the method. If no post trigger is
     * assigned <code>null</code> will be returned.
     * 
     * @return the capabilities of post trigger assigned to the method. If no post trigger is
     *         assigned <code>null</code> will be returned.
     */
    public TriggerCapability getPreTrigger() {
        return preTrigger;
    }

}

/***************************************************************************************************
 * <code>
 Changes to this class. What the people have been up to:

 $Log$
 Revision 1.2  2007/01/26 13:31:46  wanhoff
 fixed Javadoc @return tag and footer

 Revision 1.1  2006/09/19 20:10:43  poth
 initial check in

 </code>
 **************************************************************************************************/
