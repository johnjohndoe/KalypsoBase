//$HeadURL: https://svn.wald.intevation.org/svn/deegree/base/trunk/src/org/deegree/framework/util/Interceptor.java $
/*
 * Created on 21.06.2004
 * 
 * TODO To change the template for this generated file go to Window -
 * Preferences - Java - Code Generation - Code and Comments
 */
package org.deegree.framework.util;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

import org.deegree.framework.log.ILogger;
import org.deegree.framework.log.LoggerFactory;

/**
 * @author <a href="mailto:tfr@users.sourceforge.net">Torsten Friebe </A>
 * 
 * @author last edited by: $Author: apoth $
 * 
 * @version 2.0, $Revision: 6696 $, $Date: 2007-04-25 21:57:05 +0200 (Mi, 25 Apr 2007) $
 * 
 * @see <a href="http://www.dofactory.com/patterns/PatternChain.aspx">Chain of
 *      Responsibility Design Pattern </a>
 * 
 * @since 2.0
 */
public abstract class Interceptor {

    protected static final ILogger LOG = LoggerFactory.getLogger(Interceptor.class);
    
    protected abstract Object handleInvocation(Method method, Object[] params)
            throws IllegalAccessException, InvocationTargetException;

    /**
     * 
     */
    protected Interceptor nextInterceptor;

    protected Object getTarget() {
        return this.nextInterceptor.getTarget();
    }
}