//$HeadURL: https://svn.wald.intevation.org/svn/deegree/base/trunk/src/org/deegree/graphics/sld/RasterSymbolizer.java $
/*----------------    FILE HEADER  ------------------------------------------
 
 This file is part of deegree.
 Copyright (C) 2001-2006 by:
 EXSE, Department of Geography, University of Bonn
 http://www.giub.uni-bonn.de/deegree/
 lat/lon GmbH
 http://www.lat-lon.de

 This library is free software; you can redistribute it and/or
 modify it under the terms of the GNU Lesser General Public
 License as published by the Free Software Foundation; either
 version 2.1 of the License, or (at your option) any later version.

 This library is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 Lesser General Public License for more details.

 You should have received a copy of the GNU Lesser General Public
 License along with this library; if not, write to the Free Software
 Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

 Contact:

 Andreas Poth
 lat/lon GmbH
 Aennchenstr. 19
 53115 Bonn
 Germany
 E-Mail: poth@lat-lon.de

 Prof. Dr. Klaus Greve
 Department of Geography
 University of Bonn
 Meckenheimer Allee 166
 53115 Bonn
 Germany
 E-Mail: greve@giub.uni-bonn.de

 
 ---------------------------------------------------------------------------*/
package org.deegree.graphics.sld;

import org.deegree.framework.log.ILogger;
import org.deegree.framework.log.LoggerFactory;
import org.deegree.model.filterencoding.FilterEvaluationException;

/**
 * <code>RasterSymbolizer</code> encapsulates the Symbology Encoding values that may have been
 * set. Note that everything is optional, so all values may be null.
 * 
 * @author <a href="mailto:schmitz@lat-lon.de">Andreas Schmitz</a>
 * @author last edited by: $Author: aschmitz $
 * 
 * @version $Revision: 7824 $, $Date: 2007-07-24 11:02:18 +0200 (Di, 24 Jul 2007) $
 */
public class RasterSymbolizer extends AbstractSymbolizer {

    private static final ILogger LOG = LoggerFactory.getLogger( RasterSymbolizer.class );

    private double opacity;

    private boolean opacitySet;

    private Categorize categorize;

    private Interpolate interpolate;

    private double min;

    private double max;

    private boolean scaleSet;

    /**
     * Initializes nothing.
     */
    public RasterSymbolizer() {
        // initialize nothing
    }

    /**
     * @param min
     * @param max
     */
    public RasterSymbolizer( double min, double max ) {
        if ( min > 0 && max > 0 ) {
            scaleSet = true;
            this.min = min;
            this.max = max;
        }
    }

    /**
     * @param opac
     */
    public void setOpacity( ParameterValueType opac ) {
        try {
            opacity = Double.parseDouble( opac.evaluate( null ) );
            opacitySet = true;
        } catch ( NumberFormatException e ) {
            LOG.logError( "The opacity value of a RasterSymbolizer could not be parsed.", e );
        } catch ( FilterEvaluationException e ) {
            LOG.logError( "The opacity value of a RasterSymbolizer could not be parsed.", e );
        }
    }

    /**
     * @return the opacity or 1, if none was set
     */
    public double getOpacity() {
        return opacitySet ? opacity : 1;
    }

    /**
     * @param categorize
     */
    public void setCategorize( Categorize categorize ) {
        this.categorize = categorize;
    }

    /**
     * @param interpolate
     */
    public void setInterpolate( Interpolate interpolate ) {
        this.interpolate = interpolate;
    }

    /**
     * @return the categorize
     */
    public Categorize getCategorize() {
        return categorize;
    }

    /**
     * @return the interpolate
     */
    public Interpolate getInterpolate() {
        return interpolate;
    }

    /**
     * @return true, if none of the options has been set (scale is ignored)
     */
    public boolean isDefault() {
        return ( !opacitySet ) && categorize == null && interpolate == null;
    }

    /**
     * @param scale
     * @return true, if no scale hints have been set or if the given scale is valid
     */
    public boolean scaleValid( double scale ) {
        return ( scaleSet && min <= scale && max >= scale ) || !scaleSet;
    }

    @Override
    public String toString() {
        return opacity + ", " + categorize + ", " + interpolate;
    }

    /**
     * @return the max
     */
    public double getMax() {
        return max;
    }

    /**
     * @return the min
     */
    public double getMin() {
        return min;
    }

}
