//$HeadURL: svn+ssh://mschneider@svn.wald.intevation.org/deegree/base/trunk/resources/eclipse/svn_classfile_header_template.xml $
/*----------------    FILE HEADER  ------------------------------------------
 This file is part of deegree.
 Copyright (C) 2001-2007 by:
 Department of Geography, University of Bonn
 http://www.giub.uni-bonn.de/deegree/
 lat/lon GmbH
 http://www.lat-lon.de

 This library is free software; you can redistribute it and/or
 modify it under the terms of the GNU Lesser General Public
 License as published by the Free Software Foundation; either
 version 2.1 of the License, or (at your option) any later version.
 This library is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 Lesser General Public License for more details.
 You should have received a copy of the GNU Lesser General Public
 License along with this library; if not, write to the Free Software
 Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 Contact:

 Andreas Poth
 lat/lon GmbH
 Aennchenstr. 19
 53177 Bonn
 Germany
 E-Mail: poth@lat-lon.de

 Prof. Dr. Klaus Greve
 Department of Geography
 University of Bonn
 Meckenheimer Allee 166
 53115 Bonn
 Germany
 E-Mail: greve@giub.uni-bonn.de
 ---------------------------------------------------------------------------*/

package org.deegree.io.datastore;

import java.io.Serializable;
import java.util.Set;

import org.deegree.ogcwebservices.wfs.operation.GetFeatureWithLock;
import org.deegree.ogcwebservices.wfs.operation.LockFeature;

/**
 * Represents a lock that has been acquired by a {@link LockFeature} or a {@link GetFeatureWithLock}
 * request.
 * 
 * @author <a href="mailto:schneider@lat-lon.de">Markus Schneider </a>
 * @author last edited by: $Author:$
 * 
 * @version $Revision:$, $Date:$
 */
public class Lock implements Serializable {

    private static final long serialVersionUID = 9140063407823707226L;

    private String lockId;

    private Set<String> lockedFids;

    private long expiryTime;

    /**
     * Creates a new <code>Lock</code> from the given parameters.
     * 
     * @param lockId
     *            id of the lock (must be unique)
     * @param lockedFids
     *            locked feature ids
     * @param expiryTime
     *            point in time when the <code>Lock</code> expires automatically
     */
    Lock( String lockId, Set<String> lockedFids, long expiryTime ) {
        this.lockId = lockId;
        this.lockedFids = lockedFids;
        this.expiryTime = expiryTime;
    }

    /**
     * Returns the unique lock identifier.
     * 
     * @return the unique lock identifier
     */
    public String getId() {
        return this.lockId;
    }

    /**
     * Returns the ids of the features that are locked by this lock.
     * 
     * @return the ids of the locked features
     */
    public Set<String> getLockedFids() {
        return this.lockedFids;
    }

    /**
     * Returns the point in time when this lock will automatically expire.
     * 
     * @return the point in time when this lock will automatically expire
     */
    long getExpiryTime() {
        return this.expiryTime;
    }

    @Override
    public String toString() {
        StringBuffer sb = new StringBuffer();
        sb.append( "lock " + lockId + ": " );
        int i = this.lockedFids.size();
        for ( String fid : this.lockedFids ) {
            sb.append( fid );
            if ( --i != 0 ) {
                sb.append( ", " );
            }
        }
        return sb.toString();
    }
}
