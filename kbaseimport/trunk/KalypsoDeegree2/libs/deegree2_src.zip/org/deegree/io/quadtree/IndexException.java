//$HeadURL: https://svn.wald.intevation.org/svn/deegree/base/trunk/src/org/deegree/io/quadtree/IndexException.java $
/*----------------    FILE HEADER  ------------------------------------------

 This file is part of deegree.
 Copyright (C) 2001-2006 by:
 EXSE, Department of Geography, University of Bonn
 http://www.giub.uni-bonn.de/deegree/
 lat/lon GmbH
 http://www.lat-lon.de

 This library is free software; you can redistribute it and/or
 modify it under the terms of the GNU Lesser General Public
 License as published by the Free Software Foundation; either
 version 2.1 of the License, or (at your option) any later version.

 This library is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 Lesser General Public License for more details.

 You should have received a copy of the GNU Lesser General Public
 License along with this library; if not, write to the Free Software
 Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

 Contact:

 Andreas Poth
 lat/lon GmbH
 Aennchenstr. 19
 53115 Bonn
 Germany
 E-Mail: poth@lat-lon.de

 Prof. Dr. Klaus Greve
 Department of Geography
 University of Bonn
 Meckenheimer Allee 166
 53115 Bonn
 Germany
 E-Mail: greve@giub.uni-bonn.de

 ---------------------------------------------------------------------------*/
package org.deegree.io.quadtree;

/**
 * exception indicating an error will reading or manipulating an spatial
 * index implemented in deegree
 * 
 * @author <a href="mailto:poth@lat-lon.de">Andreas Poth</a>
 * @author last edited by: $Author: bezema $
 *
 * @version $Revision: 6259 $, $Date: 2007-03-20 10:15:15 +0100 (Di, 20 Mrz 2007) $
 */
public class IndexException extends Exception {

    /**
     * 
     */
    public IndexException() {
        super();
    }
    /**
     * @param message
     */
    public IndexException( String message ) {
        super( message );
    }
    
    /**
     * @param message
     * @param e
     */
    public IndexException( String message, Throwable e ) {
        super( message, e );
    }
    
    /**
     * @param e
     */
    public IndexException( Throwable e ) {
        super( e );
    }
}

/*********************************************************************
 * <code>
Changes to this class. What the people have been up to:

$Log$
Revision 1.4  2007/03/06 13:13:14  wanhoff
Fixed Javadoc (@param)

Revision 1.3  2006/04/06 20:25:31  poth
*** empty log message ***

Revision 1.2  2006/03/30 21:20:28  poth
*** empty log message ***

Revision 1.1  2005/10/28 14:57:12  poth
no message

</code>
********************************************************************** */