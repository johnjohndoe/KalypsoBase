//$HeadURL: https://svn.wald.intevation.org/svn/deegree/base/trunk/src/org/deegree/io/shpapi/shape_new/ShapeFileReader.java $
/*----------------    FILE HEADER  ------------------------------------------
 This file is part of deegree.
 Copyright (C) 2001-2006 by:
 Department of Geography, University of Bonn
 http://www.giub.uni-bonn.de/deegree/
 lat/lon GmbH
 http://www.lat-lon.de

 This library is free software; you can redistribute it and/or
 modify it under the terms of the GNU Lesser General Public
 License as published by the Free Software Foundation; either
 version 2.1 of the License, or (at your option) any later version.

 This library is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 Lesser General Public License for more details.

 You should have received a copy of the GNU Lesser General Public
 License along with this library; if not, write to the Free Software
 Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA

 Contact:

 Andreas Poth
 lat/lon GmbH
 Aennchenstr. 19
 53177 Bonn
 Germany
 E-Mail: poth@lat-lon.de

 Prof. Dr. Klaus Greve
 Department of Geography
 University of Bonn
 Meckenheimer Allee 166
 53115 Bonn
 Germany
 E-Mail: greve@giub.uni-bonn.de

 ---------------------------------------------------------------------------*/
package org.deegree.io.shpapi.shape_new;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.LinkedList;

import org.deegree.framework.log.ILogger;
import org.deegree.framework.log.LoggerFactory;
import org.deegree.io.dbaseapi.DBaseFile;
import org.deegree.model.spatialschema.ByteUtils;

/**
 * <code>ShapeFileReader</code> is a class to read shapefiles.
 * 
 * @author <a href="mailto:schmitz@lat-lon.de">Andreas Schmitz</a>
 * @author last edited by: $Author: rbezema $
 * 
 * @version $Revision: 7668 $, $Date: 2007-06-27 19:07:07 +0200 (Mi, 27 Jun 2007) $
 */
public class ShapeFileReader {

    private static final ILogger LOG = LoggerFactory.getLogger( ShapeFileReader.class );

    private String baseName;

    private int shapeType;

    private ShapeEnvelope envelope;

    private int length;

    /**
     * Does not read it yet - just initializes the object.
     * 
     * @param baseName
     */
    public ShapeFileReader( String baseName ) {

        if( baseName.endsWith( ".shp" ) ){
            baseName = baseName.substring( 0, baseName.length() - 4 );
            System.out.println( baseName );
        }
        this.baseName = baseName;
    }

    private void readHeader( InputStream in )
                            throws IOException {
        byte[] header = new byte[100];

        if ( in.read( header ) != 100 ) {
            LOG.logError( "Header is too small, unexpected things might happen!" );
            return;
        }

        int fileType = ByteUtils.readBEInt( header, 0 );
        if ( fileType != ShapeFile.FILETYPE ) {
            LOG.logWarning( "File type is wrong, unexpected things might happen, continuing anyway..." );
        }

        length = ByteUtils.readBEInt( header, 24 ) * 2; // 16 bit words...

        int version = ByteUtils.readLEInt( header, 28 );
        if ( version != ShapeFile.VERSION ) {
            LOG.logWarning( "File version is wrong, continuing in the hope of compatibility..." );
        }

        shapeType = ByteUtils.readLEInt( header, 32 );

        envelope = new ShapeEnvelope( false, false );
        envelope.read( header, 36 );

        // it shouldn't hurt to write these values as doubles default to 0.0 anyway
        double zmin = ByteUtils.readLEDouble( header, 68 );
        double zmax = ByteUtils.readLEDouble( header, 76 );
        double mmin = ByteUtils.readLEDouble( header, 84 );
        double mmax = ByteUtils.readLEDouble( header, 92 );

        switch ( shapeType ) {
        case ShapeFile.NULL:
        case ShapeFile.POINT:
        case ShapeFile.POLYLINE:
        case ShapeFile.POLYGON:
        case ShapeFile.MULTIPOINT:
            break;

        case ShapeFile.POINTM:
        case ShapeFile.POLYLINEM:
        case ShapeFile.POLYGONM:
        case ShapeFile.MULTIPOINTM:
            envelope.extend( mmin, mmax );
            break;

        case ShapeFile.POINTZ:
        case ShapeFile.POLYLINEZ:
        case ShapeFile.POLYGONZ:
        case ShapeFile.MULTIPOINTZ:
        case ShapeFile.MULTIPATCH:
            envelope.extend( zmin, zmax, mmin, mmax );

        }
    }

    private LinkedList<Shape> readShapes( InputStream in, boolean strict )
                            throws IOException {
        LinkedList<Shape> shapes = new LinkedList<Shape>();

        int offset = 0;
        byte[] bytes = new byte[length - 100];
        // read the whole file at once, this makes the "parsing" pretty fast
        in.read( bytes );

        while ( offset < bytes.length ) {
            if ( shapes.size() % 10000 == 0 ) {
                System.out.print( shapes.size() + " shapes read.\r" );
            }

            // ByteUtils.readBEInt( hdr, 0 ); // just ignore the record number
            int len = ByteUtils.readBEInt( bytes, offset + 4 ) * 2;
            offset += 8;

            if ( strict ) {
                Shape s = null;
                switch ( shapeType ) {
                case ShapeFile.NULL:
                    break;
                case ShapeFile.POINT:
                    s = new ShapePoint( false, false );
                    break;
                case ShapeFile.POINTM:
                    s = new ShapePoint( false, true );
                    break;
                case ShapeFile.POINTZ:
                    s = new ShapePoint( true, false );
                    break;
                case ShapeFile.POLYLINE:
                    s = new ShapePolyline( false, false );
                    break;
                case ShapeFile.POLYLINEM:
                    s = new ShapePolyline( false, true );
                    break;
                case ShapeFile.POLYLINEZ:
                    s = new ShapePolyline( true, false );
                    break;
                case ShapeFile.POLYGON:
                    s = new ShapePolygon( false, false );
                    break;
                case ShapeFile.POLYGONM:
                    s = new ShapePolygon( false, true );
                    break;
                case ShapeFile.POLYGONZ:
                    s = new ShapePolygon( true, false );
                    break;
                case ShapeFile.MULTIPOINT:
                    s = new ShapeMultiPoint( false, false );
                    break;
                case ShapeFile.MULTIPOINTM:
                    s = new ShapeMultiPoint( false, true );
                    break;
                case ShapeFile.MULTIPOINTZ:
                    s = new ShapeMultiPoint( true, false );
                    break;
                case ShapeFile.MULTIPATCH:
                    s = new ShapeMultiPatch( len );
                    break;
                }

                LOG.logDebug( "Reading shape type " + s.getClass().getSimpleName() );

                int alen = s.read( bytes, offset ) - offset;

                if ( len != alen ) {
                    LOG.logWarning( "Length is supposedly " + len + ", actual read length was "
                                    + alen );
                    // broken files that omit the M-section and that add the record length to the
                    // length header:
                    offset += len - 8;
                } else {
                    offset += len;
                }

                shapes.add( s );

            } else {
                // TODO
            }
        }

        LOG.logInfo( "Read " + shapes.size() + " shapes in total." );

        return shapes;
    }

    /**
     * @return the shape file contents.
     * @throws IOException
     */
    public ShapeFile read()
                            throws IOException {
        File mainFile = new File( baseName + ".shp" );
        BufferedInputStream mainIn = new BufferedInputStream( new FileInputStream( mainFile ) );
        readHeader( mainIn );

        LinkedList<Shape> shapes = readShapes( mainIn, true );

        DBaseFile dbf = new DBaseFile( baseName );

        return new ShapeFile( shapes, envelope, dbf, baseName );
    }

}

/***************************************************************************************************
 * <code>
 Changes to this class. What the people have been up to:

 $Log$
 Revision 1.4  2007/03/05 09:26:07  schmitz
 Added support for broken files with incorrect length record headers that omit the M-section.

 Revision 1.3  2007/02/27 13:03:40  schmitz
 Fixed handling of Multipatch type.

 Revision 1.2  2007/02/27 09:10:24  schmitz
 Reading ignores length attribute in record header now.

 Revision 1.1  2007/02/26 14:26:49  schmitz
 Added a new implementation of the ShapeFile API that implements the Z and M variants of the datatypes as well.
 Also added some basic tests for the API as well as a new version of the GML/Shape converters.

 </code>
 **************************************************************************************************/
