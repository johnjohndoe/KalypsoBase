//$HeadURL: https://svn.wald.intevation.org/svn/deegree/base/trunk/src/org/deegree/model/coverage/grid/GridCoverage.java $
/*----------------    FILE HEADER  ------------------------------------------

 This file is part of deegree.
 Copyright (C) 2001-2007 by:
 EXSE, Department of Geography, University of Bonn
 http://www.giub.uni-bonn.de/deegree/
 lat/lon GmbH
 http://www.lat-lon.de

 This library is free software; you can redistribute it and/or
 modify it under the terms of the GNU Lesser General Public
 License as published by the Free Software Foundation; either
 version 2.1 of the License, or (at your option) any later version.

 This library is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 Lesser General Public License for more details.

 You should have received a copy of the GNU Lesser General Public
 License along with this library; if not, write to the Free Software
 Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

 Contact:

 Andreas Poth
 lat/lon GmbH
 Aennchenstr. 19
 53115 Bonn
 Germany
 E-Mail: poth@lat-lon.de

 Prof. Dr. Klaus Greve
 Department of Geography
 University of Bonn
 Meckenheimer Allee 166
 53115 Bonn
 Germany
 E-Mail: greve@giub.uni-bonn.de

 
 ---------------------------------------------------------------------------*/
package org.deegree.model.coverage.grid;

import org.deegree.model.coverage.Coverage;

/**
 * Represent the basic implementation which provides access to grid coverage data. A
 * <code>GridCoverage</code> implementation may provide the ability to update grid values.
 * 
 * @UML abstract CV_GridCoverage
 * @author <A HREF="http://www.opengis.org">OpenGIS&reg; consortium</A>
 * @version <A HREF="http://www.opengis.org/docs/01-004.pdf">Grid Coverage specification 1.0</A>
 * 
 * @author last edited by: $Author: apoth $
 * 
 * @version $Revision: 7842 $, $Date: 2007-07-25 09:44:14 +0200 (Mi, 25 Jul 2007) $
 * 
 * @see java.awt.image.RenderedImage
 * @see javax.media.jai.PixelAccessor
 */
public interface GridCoverage extends Coverage {
    /**
     * Returns <code>true</code> if grid data can be edited.
     * 
     * @return <code>true</code> if grid data can be edited.
     * @UML mandatory dataEditable
     */
    boolean isDataEditable();

    /**
     * Information for the grid coverage geometry. Grid geometry includes the valid range of grid
     * coordinates and the georeferencing.
     * 
     * @return The information for the grid coverage geometry.
     * @UML mandatory gridGeometry
     */
    GridGeometry getGridGeometry();

    /**
     * Returns the source data for a grid coverage. If the <code>GridCoverage</code> was produced
     * from an underlying dataset (by {@link GridCoverageReader#read read(...)} for instance) the
     * getNumSources() method should returns zero, and this method should not be called.
     * 
     * If the <code>GridCoverage</code> was produced using {link
     * org.opengis.coverage.processing.GridCoverageProcessor} then it should return the source grid
     * coverage of the one used as input to <code>GridCoverageProcessor</code>. In general the
     * <code>getSource(i)</code> method is intended to return the original
     * <code>GridCoverage</code> on which it depends.
     * 
     * This is intended to allow applications to establish what <code>GridCoverage</code>s will
     * be affected when others are updated, as well as to trace back to the "raw data".
     * 
     * @param sourceDataIndex
     *            Source grid coverage index. Indexes start at 0.
     * @return The source data for a grid coverage.
     * @throws IndexOutOfBoundsException
     *             if <code>sourceDataIndex</code> is out of bounds.
     * @UML operation Coverage.getSource
     */
    Coverage getSource( int sourceDataIndex )
                            throws IndexOutOfBoundsException;
   
}
