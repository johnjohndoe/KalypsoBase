/*----------------    FILE HEADER  ------------------------------------------

 This file is part of deegree.
 Copyright (C) 2001-2007 by:
 lat/lon GmbH
 http://www.lat-lon.de

 This library is free software; you can redistribute it and/or
 modify it under the terms of the GNU Lesser General Public
 License as published by the Free Software Foundation; either
 version 2.1 of the License, or (at your option) any later version.

 This library is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 Lesser General Public License for more details.

 You should have received a copy of the GNU Lesser General Public
 License along with this library; if not, write to the Free Software
 Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

 Contact:

 Andreas Poth
 lat/lon GmbH
 Aennchenstr. 19
 53115 Bonn
 Germany
 E-Mail: poth@lat-lon.de
 
 ---------------------------------------------------------------------------*/
package org.deegree.model.crs;

import java.io.InputStream;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

import org.deegree.framework.log.ILogger;
import org.deegree.framework.log.LoggerFactory;
import org.deegree.model.crs.CSAccess;

/**
 * 
 * 
 * 
 * @author <a href="mailto:poth@lat-lon.de">Andreas Poth</a>
 * @author last edited by: $Author: poth $
 * 
 * @version. $Revision: 1.2 $, $Date: 2007-06-11 11:33:58 $
 */
public class CSAccessFactory {

    private static final ILogger LOG = LoggerFactory.getLogger( CSAccessFactory.class );

    /**
     * access key to default CSAccess class 
     */
    public static final String CSA_DEFAULT = "default";

    public static final String CSA_DEEGREE_OLD = "deegree_old";
    
    public static final String CSA_DEEGREE_NEW = "deegree_new";

    private static final String CSACCESS_RESOURCE = "csaccessfactory.properties";

    private static Map<String, CSAccess> csAccess = new HashMap<String, CSAccess>();

    /**
     * returns an instance of the default CSAccess class (default CSAccess assigend to key
     * 'deegree_new')
     * 
     * @return instance of the default CSAccess class
     */
    public static CSAccess getCSAccess() {
        return getCSAccess( CSA_DEFAULT );
    }

    /**
     * returns an instance of the CSAccess class assigend to the passed key
     * 
     * @param csAccessKey
     * @return instance of the CSAccess class assigend to the passed key
     */
    public static CSAccess getCSAccess( String csAccessKey ) {
        
        if ( csAccess.get( csAccessKey ) == null ) {
            initialCSAccess( csAccessKey );
        }
        return csAccess.get( csAccessKey );
    }

    /**
     * creates an instance of the CSAccess class assigend to the passed key and writes it into the
     * caching map
     * 
     * @param csAccessKey
     */
    private static void initialCSAccess( String csAccessKey ) {

        URL url = CSAccessFactory.class.getResource( CSACCESS_RESOURCE );
        Properties props = new Properties();
        try {
            InputStream is = url.openStream();
            props.load( is );
            is.close();
        } catch ( Exception e ) {
            LOG.logError( e.getMessage(), e );
            throw new CSAccessFactoryException( "could not load csaccess resource: " + CSACCESS_RESOURCE );
        }
        String clzzName = props.getProperty( csAccessKey );
        
        if ( clzzName == null ) {
            throw new CSAccessFactoryException( "no CSAccess class defined for key: " + csAccessKey );
        }

        try {
            csAccess.put( csAccessKey, (CSAccess) Class.forName( clzzName ).newInstance() );
        } catch ( InstantiationException e ) {
            LOG.logError( e.getMessage(), e );
            throw new CSAccessFactoryException( "could not initialize: " + clzzName );
        } catch ( IllegalAccessException e ) {
            LOG.logError( e.getMessage(), e );
            throw new CSAccessFactoryException( "the current process is not allowed to access: " + clzzName );
        } catch ( ClassNotFoundException e ) {
            LOG.logError( e.getMessage(), e );
            throw new CSAccessFactoryException( "class: " + clzzName + " has not been found in classpath" );
        }

    }

}
