/*----------------    FILE HEADER  ------------------------------------------

 This file is part of deegree.
 Copyright (C) 2001-2007 by:
 lat/lon GmbH
 http://www.lat-lon.de

 This library is free software; you can redistribute it and/or
 modify it under the terms of the GNU Lesser General Public
 License as published by the Free Software Foundation; either
 version 2.1 of the License, or (at your option) any later version.

 This library is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 Lesser General Public License for more details.

 You should have received a copy of the GNU Lesser General Public
 License along with this library; if not, write to the Free Software
 Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

 Contact:

 Andreas Poth
 lat/lon GmbH
 Aennchenstr. 19
 53115 Bonn
 Germany
 E-Mail: poth@lat-lon.de
 
 ---------------------------------------------------------------------------*/
package org.deegree.model.crs;

/**
 * 
 * 
 * 
 * @author <a href="mailto:poth@lat-lon.de">Andreas Poth</a>
 * @author last edited by: $Author: poth $
 * 
 * @version. $Revision: 1.2 $, $Date: 2007-06-11 11:33:58 $
 */
public class CSAccessFactoryException extends RuntimeException {

    public CSAccessFactoryException() {
        super();   
    }

    public CSAccessFactoryException( String arg0, Throwable arg1 ) {
        super( arg0, arg1 );
    }

    public CSAccessFactoryException( String arg0 ) {
        super( arg0 );
    }

    public CSAccessFactoryException( Throwable arg0 ) {
        super( arg0 );
    }

}
