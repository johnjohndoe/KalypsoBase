//$HeadURL: svn+ssh://developername@svn.wald.intevation.org/deegree/base/trunk/src/org/deegree/model/csct/cs/ConvenienceCSFactory.java $
/*----------------    FILE HEADER  ------------------------------------------

 This file is part of deegree.
 Copyright (C) 2001-2007 by:
 lat/lon GmbH
 http://www.lat-lon.de

 This library is free software; you can redistribute it and/or
 modify it under the terms of the GNU Lesser General Public
 License as published by the Free Software Foundation; either
 version 2.1 of the License, or (at your option) any later version.

 This library is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 Lesser General Public License for more details.

 You should have received a copy of the GNU Lesser General Public
 License along with this library; if not, write to the Free Software
 Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

 Contact:

 Andreas Poth
 lat/lon GmbH
 Aennchenstr. 19
 53115 Bonn
 Germany
 E-Mail: poth@lat-lon.de
 
 ---------------------------------------------------------------------------*/
package org.deegree.model.crs;

import java.awt.geom.Point2D;
import java.net.URI;
import java.net.URL;
import java.util.HashMap;

import org.deegree.framework.log.ILogger;
import org.deegree.framework.log.LoggerFactory;
import org.deegree.framework.util.BootLogger;
import org.deegree.framework.xml.NamespaceContext;
import org.deegree.framework.xml.XMLFragment;
import org.deegree.framework.xml.XMLParsingException;
import org.deegree.framework.xml.XMLTools;
import org.deegree.model.crs.CRSException;
import org.deegree.model.crs.CSAccess;
import org.deegree.model.csct.cs.AxisInfo;
import org.deegree.model.csct.cs.CoordinateSystem;
import org.deegree.model.csct.cs.CoordinateSystemFactory;
import org.deegree.model.csct.cs.Datum;
import org.deegree.model.csct.cs.DatumType;
import org.deegree.model.csct.cs.Ellipsoid;
import org.deegree.model.csct.cs.GeographicCoordinateSystem;
import org.deegree.model.csct.cs.HorizontalDatum;
import org.deegree.model.csct.cs.PrimeMeridian;
import org.deegree.model.csct.cs.ProjectedCoordinateSystem;
import org.deegree.model.csct.cs.Projection;
import org.deegree.model.csct.cs.WGS84ConversionInfo;
import org.deegree.model.csct.units.Unit;
import org.deegree.ogcbase.CommonNamespaces;
import org.w3c.dom.Element;

/**
 * 
 * 
 * @version $Revision: 1.1 $
 * @author <a href="mailto:poth@lat-lon.de">Andreas Poth</a>
 */
public class DeegreeCSAccess implements CSAccess {

    private static final ILogger LOG = LoggerFactory.getLogger( DeegreeCSAccess.class );

    private static final String CRS_DEF = "crs.xml";

    private static NamespaceContext nsc = CommonNamespaces.getNamespaceContext();
    static {
        try {
            nsc.addNamespace( "crs", new URI( "http://www.deegree.org/crs" ) );
        } catch ( Exception e ) {
            BootLogger.logError( e.getMessage(), e );
        }
    }

    private CoordinateSystemFactory csFactory = CoordinateSystemFactory.getDefault();

    /**
     * keys are names (i.e. "EPSG:4326"), values are CoordinateSystems
     */
    private HashMap<String, CoordinateSystem> systems = new HashMap<String, CoordinateSystem>( 300 );

    /**
     * keys are names (i.e. "EPSG:7006"), values are Ellipsoids
     */
    private HashMap<String, Ellipsoid> ellipsoids = new HashMap<String, Ellipsoid>( 30 );

    /**
     * keys are names (i.e. "EPSG:7006"), values are Ellipsoids
     */
    private HashMap<String, Datum> datums = new HashMap<String, Datum>( 30 );

    /**
     * keys are names (i.e. "EPSG:1777"), values are WGS84Conversion object
     */
    private HashMap<String, WGS84ConversionInfo> toWGS84Conversions = new HashMap<String, WGS84ConversionInfo>( 30 );

    /*
     * (non-Javadoc)
     * 
     * @see de.latlon.vodafone.crs.CSAccess#getCSByCode(java.lang.String, java.lang.String)
     */
    public synchronized CoordinateSystem getCSByCode( String code, String version )
                            throws CRSException {
        // normalize code
        code = code.toUpperCase();

        // reading CRS from cache and return it if available
        CoordinateSystem cs = systems.get( code.toUpperCase() );
        if ( cs != null ) {
            return cs;
        }

        // read defintion of CRS with passed code from CRS defintion resource
        // if no CRS with passed code is defined null will be returned
        Element crsElement = readCRSDefinition( code );
        if ( crsElement == null ) {
            throw new CRSException( "requested CRS with code: " + code + " is not defined" );
        }

        try {
            createCRS( crsElement );
        } catch ( XMLParsingException e ) {
            LOG.logError( e.getMessage(), e );
            throw new CRSException( e.getMessage(), e );
        }

        return systems.get( code );
    }

    /**
     * creates
     * 
     * @see CoordinateSystem from the passed Element
     * @param crsElement
     * @throws CRSException
     * @throws XMLParsingException
     */
    private void createCRS( Element crsElement )
                            throws CRSException, XMLParsingException {

        String type = crsElement.getLocalName();
        if ( "projectedReferenceSytemen".equals( type ) ) {
            createProjectedCRS( crsElement );
        } else if ( "geographicReferenceSytem".equals( type ) ) {
            createGeographicCRS( crsElement );
        } else {
            throw new CRSException( "not supoorted CRS type: " + type );
        }

    }

    /**
     * 
     * @param crsElement
     * @throws XMLParsingException
     * @throws CRSException
     */
    private void createGeographicCRS( Element crsElement )
                            throws XMLParsingException, CRSException {

        String code = XMLTools.getRequiredNodeAsString( crsElement, "crs:code/text()", nsc );

        GeographicCoordinateSystem cs = null;
        if ( "EPSG:4326".equals( code ) || "WGS84".equals( code ) ) {
            // use standard parameters because no conversion is required
            cs = csFactory.createGeographicCoordinateSystem( code, Unit.DEGREE, HorizontalDatum.WGS84,
                                                             PrimeMeridian.GREENWICH, AxisInfo.LONGITUDE,
                                                             AxisInfo.LATITUDE );
        } else {

            // try getting WGS84 conversion parameters from cache. If no conversion parameters with
            // required code is available in cache: read parameter and create an object storing
            // informations for converting current geographic reference system (better: its
            // underlying geogr. datum) to WGS84
            String toWGS84Code = XMLTools.getNodeAsString( crsElement, "crs:wgs84ConversionInfo/text()", nsc, null );
            WGS84ConversionInfo convInfo = toWGS84Conversions.get( toWGS84Code );
            if ( convInfo == null ) {
                String xPath = "/crs:definitons/crs:transformation[crs:code = '" + toWGS84Code + "']";
                Element toWGS84Element = XMLTools.getRequiredElement( crsElement, xPath, nsc );
                createWGS84ConversionInfo( toWGS84Element );
                convInfo = toWGS84Conversions.get( toWGS84Code );
            }

            // read code of used datum
            String datumCode = XMLTools.getRequiredNodeAsString( crsElement, "crs:usedDatum/text()", nsc );
            HorizontalDatum datum = (HorizontalDatum)datums.get( code );
            if ( datum == null ) {
                String xPath = "/crs:definitons/crs:datum[crs:code = '" + datumCode + "']";
                Element datumElement = XMLTools.getRequiredElement( crsElement, xPath, nsc );
                createDatum( datumElement, convInfo );
                datum = (HorizontalDatum)datums.get( datumCode );
            }

            String axisOrder = XMLTools.getNodeAsString( crsElement, "crs:axisOrder/text()", nsc, "XY" );
            // consider axisOrder creating reference system
            if ( "XY".equals( axisOrder ) ) {
                cs = csFactory.createGeographicCoordinateSystem( code, Unit.DEGREE, datum, PrimeMeridian.GREENWICH,
                                                                 AxisInfo.LONGITUDE, AxisInfo.LATITUDE );                
            } else {
                cs = csFactory.createGeographicCoordinateSystem( code, Unit.DEGREE, datum, PrimeMeridian.GREENWICH,
                                                                 AxisInfo.LATITUDE, AxisInfo.LONGITUDE );
            }

        }
        systems.put( code, cs );

    }

    /**
     * 
     * @param datumElement
     * @param convInfo
     * @throws XMLParsingException
     * @throws CRSException
     */
    private void createDatum( Element datumElement, WGS84ConversionInfo convInfo )
                            throws XMLParsingException, CRSException {
        
        String code = XMLTools.getRequiredNodeAsString( datumElement, "crs:code/text()", nsc );
        String type = XMLTools.getRequiredNodeAsString( datumElement, "crs:datumType/text()", nsc );
        
        // read code of used ellipsoid
        String ellCode = XMLTools.getRequiredNodeAsString( datumElement, "crs:usedEllipsoid/text()", nsc );
        // try getting elliposid from cache. If no ellipsoid with required code
        // is available in cache: create it
        Ellipsoid ellipsoid = ellipsoids.get( ellCode );
        if ( ellipsoid == null ) {
            String xPath = "/crs:definitons/crs:ellipsoid[crs:code = '" + ellCode + "']";
            Element ellipsoidElement = XMLTools.getRequiredElement( datumElement, xPath, nsc );
            createEllipsoid( ellipsoidElement );
            ellipsoid = ellipsoids.get( ellCode );
        }
        // at the moment just horizontal geogr. datum are supported
        if ( type.toLowerCase().equals( "geodetic" ) ) {
            datums.put( code, new HorizontalDatum( code, DatumType.CLASSIC, ellipsoid, convInfo ) );            
        } else {
            throw new CRSException( "not supported datum type: " + type );
        }
    }

    /**
     * 
     * @param toWGS84Element
     * @throws XMLParsingException
     */
    private void createWGS84ConversionInfo( Element toWGS84Element )
                            throws XMLParsingException {
        String code = XMLTools.getRequiredNodeAsString( toWGS84Element, "crs:code/text()", nsc );
        WGS84ConversionInfo convInfo = new WGS84ConversionInfo();
        convInfo.dx = XMLTools.getRequiredNodeAsDouble( toWGS84Element, "crs:xAxisTranslation/text()", nsc );
        convInfo.dy = XMLTools.getRequiredNodeAsDouble( toWGS84Element, "crs:yAxisTranslation/text()", nsc );
        convInfo.dz = XMLTools.getRequiredNodeAsDouble( toWGS84Element, "crs:zAxisTranslation/text()", nsc );
        convInfo.ex = XMLTools.getRequiredNodeAsDouble( toWGS84Element, "crs:xAxisRotation/text()", nsc );
        convInfo.ey = XMLTools.getRequiredNodeAsDouble( toWGS84Element, "crs:yAxisRotation/text()", nsc );
        convInfo.ez = XMLTools.getRequiredNodeAsDouble( toWGS84Element, "crs:zAxisRotation/text()", nsc );
        convInfo.ppm = XMLTools.getRequiredNodeAsDouble( toWGS84Element, "crs:scaleDifference/text()", nsc );
        toWGS84Conversions.put( code, convInfo );
    }

    /**
     * 
     * @param ellipsoidElement
     * @throws XMLParsingException
     * @throws CRSException
     */
    private void createEllipsoid( Element ellipsoidElement )
                            throws XMLParsingException, CRSException {

        String code = XMLTools.getRequiredNodeAsString( ellipsoidElement, "crs:code/text()", nsc );
        double semiMajorAxis = XMLTools.getRequiredNodeAsDouble( ellipsoidElement, "crs:semiMajorAxis/text()", nsc );
        double inverseFlatting = XMLTools.getRequiredNodeAsDouble( ellipsoidElement, "crs:inverseFlatting/text()", nsc );
        Unit unit = createUnit( ellipsoidElement );

        Ellipsoid ellipsoid = Ellipsoid.createFlattenedSphere( code, semiMajorAxis, inverseFlatting, unit );
        ellipsoids.put( code, ellipsoid );
    }

    /**
     * 
     * @param ellipsoidElement
     * @return
     * @throws XMLParsingException
     * @throws CRSException
     */
    private Unit createUnit( Element rootElement )
                            throws XMLParsingException, CRSException {
        String units = XMLTools.getRequiredNodeAsString( rootElement, "crs:units/text()", nsc );

        Unit unit = null;
        if ( "metre".equals( units ) || "meter".equals( units ) ) {
            unit = Unit.METRE;
        } else if ( "degree".equals( units ) ) {
            unit = Unit.DEGREE;
        } else if ( "britishyard".equals( units ) ) {
            unit = Unit.BRITISHYARD;
        } else {
            throw new CRSException( "unknown unit '" + units + "'" );
        }
        return unit;
    }

    /**
     * at the moment just TransverseMercator projection is supported
     * 
     * @param crsElement
     * @throws XMLParsingException
     * @throws CRSException
     */
    private void createProjectedCRS( Element crsElement )
                            throws XMLParsingException, CRSException {
        String xPath = "crs:projectionType/text()";
        String projection = XMLTools.getRequiredNodeAsString( crsElement, xPath, nsc );
        if ( !"TransverseMercator".equals( projection ) ) {
            throw new CRSException( "not supported projection: " + projection );
        }
        if ( "TransverseMercator".equals( projection ) ) {
            createTransverseMercatorCRS( crsElement );
        }
    }

    /**
     * 
     * @param crsElement
     * @throws XMLParsingException
     * @throws CRSException
     */
    private void createTransverseMercatorCRS( Element crsElement )
                            throws XMLParsingException, CRSException {
        String code = XMLTools.getRequiredNodeAsString( crsElement, "crs:code/text()", nsc );
        String name = XMLTools.getNodeAsString( crsElement, "crs:name/text()", nsc, "-" );

        // try getting geographic CRS parameters from cache. If no geographic CRS with
        // required code is available in cache: read parameter and create it
        String geogrCRSCode = XMLTools.getRequiredNodeAsString( crsElement, "crs:geographicReferenceSytem/text()", nsc );
        GeographicCoordinateSystem geogrCRS = (GeographicCoordinateSystem) systems.get( geogrCRSCode );
        if ( geogrCRS == null ) {
            String xPath = "/crs:definitons/crs:geographicReferenceSytem[crs:code = '" + geogrCRSCode + "']";
            Element geogrCRSElement = XMLTools.getRequiredElement( crsElement, xPath, nsc );
            createGeographicCRS( geogrCRSElement );
        }
        geogrCRS = (GeographicCoordinateSystem) systems.get( geogrCRSCode );
        Ellipsoid ellipsoid = geogrCRS.getHorizontalDatum().getEllipsoid();

        // read projection parameters and create a projection object
        double latono = XMLTools.getRequiredNodeAsDouble( crsElement, "crs:latitudeOfNaturalOrigin/text()", nsc );
        double lonono = XMLTools.getRequiredNodeAsDouble( crsElement, "crs:longitudeOfNaturalOrigin/text()", nsc );
        double scaleFactor = XMLTools.getRequiredNodeAsDouble( crsElement, "crs:scaleFactor/text()", nsc );
        double falseEasting = XMLTools.getRequiredNodeAsDouble( crsElement, "crs:falseEasting/text()", nsc );
        double falseNorthing = XMLTools.getRequiredNodeAsDouble( crsElement, "crs:falseNorthing/text()", nsc );
        Unit unit = createUnit( crsElement );

        Projection projection = csFactory.createProjection( name, "Transverse_Mercator", ellipsoid,
                                                            new Point2D.Double( lonono, latono ),
                                                            new Point2D.Double( falseEasting, falseNorthing ),
                                                            scaleFactor );

        // create projected CRS considering axisOrder
        String axisOrder = XMLTools.getNodeAsString( crsElement, "crs:axisOrder/text()", nsc, "XY" );
        ProjectedCoordinateSystem cs = null;
        if ( "XY".equals( axisOrder ) ) {
            cs = csFactory.createProjectedCoordinateSystem( code, geogrCRS, projection, unit, AxisInfo.X, AxisInfo.Y );
        } else {
            cs = csFactory.createProjectedCoordinateSystem( code, geogrCRS, projection, unit, AxisInfo.Y, AxisInfo.X );
        }
        systems.put( code, cs );
    }

    /**
     * reads a CRS defintion having passed code from CRS definition document
     * 
     * @param code
     * @return
     * @throws CRSException
     */
    private Element readCRSDefinition( String code )
                            throws CRSException {

        XMLFragment xml = null;
        try {
            URL url = DeegreeCSAccess.class.getResource( "/crs.xml" );
            xml = new XMLFragment( url );
        } catch ( Exception e ) {
            URL url = DeegreeCSAccess.class.getResource( CRS_DEF );
            try {
                xml = new XMLFragment( url );
            } catch ( Exception ee ) {
                LOG.logError( ee.getMessage(), ee );
                throw new CRSException( "CRS definition document could not be loaded" );
            }
        }

        Element crsElement;
        try {
            String xPath = "/crs:definitons/*[crs:code = '" + code + "']";
            crsElement = XMLTools.getRequiredElement( xml.getRootElement(), xPath, nsc );
        } catch ( XMLParsingException e ) {
            LOG.logError( e.getMessage(), e );
            throw new CRSException( "CRS definition could not be read from CRS definition document" );
        }
        return crsElement;
    }

}