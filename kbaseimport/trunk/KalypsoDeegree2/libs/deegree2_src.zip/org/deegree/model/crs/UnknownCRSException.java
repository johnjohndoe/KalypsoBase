//$HeadURL: https://svn.wald.intevation.org/svn/deegree/base/trunk/src/org/deegree/model/crs/UnknownCRSException.java $
/*----------------    FILE HEADER  ------------------------------------------

 This file is part of deegree.
 Copyright (C) 2001-2007 by:
 EXSE, Department of Geography, University of Bonn
 http://www.giub.uni-bonn.de/deegree/
 lat/lon GmbH
 http://www.lat-lon.de

 This library is free software; you can redistribute it and/or
 modify it under the terms of the GNU Lesser General Public
 License as published by the Free Software Foundation; either
 version 2.1 of the License, or (at your option) any later version.

 This library is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 Lesser General Public License for more details.

 You should have received a copy of the GNU Lesser General Public
 License along with this library; if not, write to the Free Software
 Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

 Contact:

 Andreas Poth
 lat/lon GmbH
 Aennchenstr. 19
 53177 Bonn
 Germany
 E-Mail: poth@lat-lon.de

 Prof. Dr. Klaus Greve
 Department of Geography
 University of Bonn
 Meckenheimer Allee 166
 53115 Bonn
 Germany
 E-Mail: greve@giub.uni-bonn.de

 ---------------------------------------------------------------------------*/
package org.deegree.model.crs;

import org.deegree.i18n.Messages;

/**
 * 
 * 
 * 
 * @version $Revision: 7102 $
 * @author <a href="mailto:poth@lat-lon.de">Andreas Poth</a>
 * @author last edited by: $Author: apoth $
 * 
 * @version 1.0. $Revision: 7102 $, $Date: 2007-05-14 11:26:29 +0200 (Mo, 14 Mai 2007) $
 * 
 * @since 2.0
 */
public class UnknownCRSException extends CRSException {

    public UnknownCRSException() {
        super( Messages.getMessage( "CRS_UNKNOWNCRS_DEFAULT" ) );
    }

    public UnknownCRSException( String arg0, Throwable arg1 ) {
        super( arg0, arg1 );
    }

    public UnknownCRSException( String arg0 ) {
        super( arg0 );
    }

    public UnknownCRSException( Throwable arg0 ) {
        super( arg0 );
    }

}