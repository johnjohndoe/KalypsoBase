<?xml version="1.0" encoding="WINDOWS-1252"?>
<StyledLayerDescriptor xmlns="http://www.opengis.net/sld" xmlns:gml="http://www.opengis.net/gml" xmlns:ogc="http://www.opengis.net/ogc" xmlns:sld="http://www.opengis.net/sld" xmlns:sldExt="http://www.opengis.net/sldExt" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" version="1.0">
    <NamedLayer>
        <Name>deegree style definition</Name>
        <UserStyle>
            <Name>Roughness style</Name>
            <Title>Roughness style</Title>
            <FeatureTypeStyle>
                <Rule>
                    <Name>undefinierterStilID</Name>
                    <Title>undefinierter Stil</Title>
                    <Abstract>undefinierter Stil</Abstract>
                    <ogc:ElseFilter/>
                    <MinScaleDenominator>0.0</MinScaleDenominator>
                    <MaxScaleDenominator>1.7976931348623157E308</MaxScaleDenominator>
                    <PolygonSymbolizer uom="pixel">
                        <Fill>
                            <CssParameter name="fill">#ffffff</CssParameter>
                            <CssParameter name="fill-opacity">0.0</CssParameter>
                        </Fill>
                        <Stroke>
                            <CssParameter name="stroke-width">1.5</CssParameter>
                            <CssParameter name="stroke-dasharray">2.0,3.5</CssParameter>
                            <CssParameter name="stroke-opacity">1.0</CssParameter>
                            <CssParameter name="stroke">#ff0000</CssParameter>
                            <CssParameter name="stroke-linejoin">mitre</CssParameter>
                            <CssParameter name="stroke-linecap">butt</CssParameter>
                        </Stroke>
                    </PolygonSymbolizer>
                </Rule>
                <Rule>
                    <Name>RoughnessCls117813102775819</Name>
                    <Title>deaktivierte Elemente</Title>
                    <Abstract>deaktivierte Elemente</Abstract>
                    <ogc:Filter>
                        <ogc:PropertyIsLike escape="/" singleChar="$" wildCard="*">
                            <ogc:PropertyName>roughnessStyle</ogc:PropertyName>
                            <ogc:Literal>deaktivierte Elemente</ogc:Literal>
                        </ogc:PropertyIsLike>
                    </ogc:Filter>
<MinScaleDenominator>0.0</MinScaleDenominator>
                    <MaxScaleDenominator>1.7976931348623157E308</MaxScaleDenominator>
                    <PolygonSymbolizer uom="pixel">
                        <Fill>
                            <CssParameter name="fill">#ff0000</CssParameter>
                            <CssParameter name="fill-opacity">0.75</CssParameter>
                        </Fill>
                        <Stroke>
                            <CssParameter name="stroke-width">1.0</CssParameter>
                            <CssParameter name="stroke-opacity">1.0</CssParameter>
                            <CssParameter name="stroke">#000000</CssParameter>
                            <CssParameter name="stroke-linejoin">mitre</CssParameter>
                            <CssParameter name="stroke-linecap">butt</CssParameter>
                        </Stroke>
                    </PolygonSymbolizer>
                </Rule>
                <Rule>
                    <Name>RoughnessCls117812331278327</Name>
                    <Title>Vorland mit Bewuchs 25</Title>
                    <Abstract>Vorland mit Bewuchs 25</Abstract>
                    <ogc:Filter>
                        <ogc:PropertyIsLike escape="/" singleChar="$" wildCard="*">
                            <ogc:PropertyName>roughnessStyle</ogc:PropertyName>
                            <ogc:Literal>Vorland mit Bewuchs 25</ogc:Literal>
                        </ogc:PropertyIsLike>
                    </ogc:Filter>
<MinScaleDenominator>0.0</MinScaleDenominator>
                    <MaxScaleDenominator>1.7976931348623157E308</MaxScaleDenominator>
                    <PolygonSymbolizer uom="pixel">
                        <Fill>
                            <CssParameter name="fill">#80ff80</CssParameter>
                            <CssParameter name="fill-opacity">0.75</CssParameter>
                        </Fill>
                        <Stroke>
                            <CssParameter name="stroke-width">1.0</CssParameter>
                            <CssParameter name="stroke-opacity">1.0</CssParameter>
                            <CssParameter name="stroke">#000000</CssParameter>
                            <CssParameter name="stroke-linejoin">mitre</CssParameter>
                            <CssParameter name="stroke-linecap">butt</CssParameter>
                        </Stroke>
                    </PolygonSymbolizer>
                </Rule>
                <Rule>
                    <Name>RoughnessCls11781233116313</Name>
                    <Title>Fluss oben</Title>
                    <Abstract>Fluss oben</Abstract>
                    <ogc:Filter>
                        <ogc:PropertyIsLike escape="/" singleChar="$" wildCard="*">
                            <ogc:PropertyName>roughnessStyle</ogc:PropertyName>
                            <ogc:Literal>Fluss oben</ogc:Literal>
                        </ogc:PropertyIsLike>
                    </ogc:Filter>
<MinScaleDenominator>0.0</MinScaleDenominator>
                    <MaxScaleDenominator>1.7976931348623157E308</MaxScaleDenominator>
                    <PolygonSymbolizer uom="pixel">
                        <Fill>
                            <CssParameter name="fill">#0080ff</CssParameter>
                            <CssParameter name="fill-opacity">0.75</CssParameter>
                        </Fill>
                        <Stroke>
                            <CssParameter name="stroke-width">1.0</CssParameter>
                            <CssParameter name="stroke-opacity">1.0</CssParameter>
                            <CssParameter name="stroke">#000000</CssParameter>
                            <CssParameter name="stroke-linejoin">mitre</CssParameter>
                            <CssParameter name="stroke-linecap">butt</CssParameter>
                        </Stroke>
                    </PolygonSymbolizer>
                </Rule>
                <Rule>
                    <Name>RoughnessCls117812331029919</Name>
                    <Title>Wehr</Title>
                    <Abstract>Wehr</Abstract>
                    <ogc:Filter>
                        <ogc:PropertyIsLike escape="/" singleChar="$" wildCard="*">
                            <ogc:PropertyName>roughnessStyle</ogc:PropertyName>
                            <ogc:Literal>Wehr</ogc:Literal>
                        </ogc:PropertyIsLike>
                    </ogc:Filter>
<MinScaleDenominator>0.0</MinScaleDenominator>
                    <MaxScaleDenominator>1.7976931348623157E308</MaxScaleDenominator>
                    <PolygonSymbolizer uom="pixel">
                        <Fill>
                            <CssParameter name="fill">#000000</CssParameter>
                            <CssParameter name="fill-opacity">0.75</CssParameter>
                        </Fill>
                        <Stroke>
                            <CssParameter name="stroke-width">1.0</CssParameter>
                            <CssParameter name="stroke-opacity">1.0</CssParameter>
                            <CssParameter name="stroke">#000000</CssParameter>
                            <CssParameter name="stroke-linejoin">mitre</CssParameter>
                            <CssParameter name="stroke-linecap">butt</CssParameter>
                        </Stroke>
                    </PolygonSymbolizer>
                </Rule>
                <Rule>
                    <Name>RoughnessCls11781230887268</Name>
                    <Title>Fluss</Title>
                    <Abstract>Fluss</Abstract>
                    <ogc:Filter>
                        <ogc:PropertyIsLike escape="/" singleChar="$" wildCard="*">
                            <ogc:PropertyName>roughnessStyle</ogc:PropertyName>
                            <ogc:Literal>Fluss</ogc:Literal>
                        </ogc:PropertyIsLike>
                    </ogc:Filter>
<MinScaleDenominator>0.0</MinScaleDenominator>
                    <MaxScaleDenominator>1.7976931348623157E308</MaxScaleDenominator>
                    <PolygonSymbolizer uom="pixel">
                        <Fill>
                            <CssParameter name="fill">#8000ff</CssParameter>
                            <CssParameter name="fill-opacity">0.75</CssParameter>
                        </Fill>
                        <Stroke>
                            <CssParameter name="stroke-width">1.0</CssParameter>
                            <CssParameter name="stroke-opacity">1.0</CssParameter>
                            <CssParameter name="stroke">#000000</CssParameter>
                            <CssParameter name="stroke-linejoin">mitre</CssParameter>
                            <CssParameter name="stroke-linecap">butt</CssParameter>
                        </Stroke>
                    </PolygonSymbolizer>
                </Rule>
                <Rule>
                    <Name>RoughnessCls117812308790520</Name>
                    <Title>Sohlsch�ttung</Title>
                    <Abstract>Sohlsch�ttung</Abstract>
                    <ogc:Filter>
                        <ogc:PropertyIsLike escape="/" singleChar="$" wildCard="*">
                            <ogc:PropertyName>roughnessStyle</ogc:PropertyName>
                            <ogc:Literal>Sohlsch�ttung</ogc:Literal>
                        </ogc:PropertyIsLike>
                    </ogc:Filter>
<MinScaleDenominator>0.0</MinScaleDenominator>
                    <MaxScaleDenominator>1.7976931348623157E308</MaxScaleDenominator>
                    <PolygonSymbolizer uom="pixel">
                        <Fill>
                            <CssParameter name="fill">#6b6b6b</CssParameter>
                            <CssParameter name="fill-opacity">0.75</CssParameter>
                        </Fill>
                        <Stroke>
                            <CssParameter name="stroke-width">1.0</CssParameter>
                            <CssParameter name="stroke-opacity">1.0</CssParameter>
                            <CssParameter name="stroke">#000000</CssParameter>
                            <CssParameter name="stroke-linejoin">mitre</CssParameter>
                            <CssParameter name="stroke-linecap">butt</CssParameter>
                        </Stroke>
                    </PolygonSymbolizer>
                </Rule>
                <Rule>
                    <Name>RoughnessCls117812308713428</Name>
                    <Title>Graben</Title>
                    <Abstract>Graben</Abstract>
                    <ogc:Filter>
                        <ogc:PropertyIsLike escape="/" singleChar="$" wildCard="*">
                            <ogc:PropertyName>roughnessStyle</ogc:PropertyName>
                            <ogc:Literal>Graben</ogc:Literal>
                        </ogc:PropertyIsLike>
                    </ogc:Filter>
<MinScaleDenominator>0.0</MinScaleDenominator>
                    <MaxScaleDenominator>1.7976931348623157E308</MaxScaleDenominator>
                    <PolygonSymbolizer uom="pixel">
                        <Fill>
                            <CssParameter name="fill">#8000ff</CssParameter>
                            <CssParameter name="fill-opacity">0.75</CssParameter>
                        </Fill>
                        <Stroke>
                            <CssParameter name="stroke-width">1.0</CssParameter>
                            <CssParameter name="stroke-opacity">1.0</CssParameter>
                            <CssParameter name="stroke">#000000</CssParameter>
                            <CssParameter name="stroke-linejoin">mitre</CssParameter>
                            <CssParameter name="stroke-linecap">butt</CssParameter>
                        </Stroke>
                    </PolygonSymbolizer>
                </Rule>
                <Rule>
                    <Name>RoughnessCls117812308631332</Name>
                    <Title>B�schung</Title>
                    <Abstract>B�schung</Abstract>
                    <ogc:Filter>
                        <ogc:PropertyIsLike escape="/" singleChar="$" wildCard="*">
                            <ogc:PropertyName>roughnessStyle</ogc:PropertyName>
                            <ogc:Literal>B�schung</ogc:Literal>
                        </ogc:PropertyIsLike>
                    </ogc:Filter>
<MinScaleDenominator>0.0</MinScaleDenominator>
                    <MaxScaleDenominator>1.7976931348623157E308</MaxScaleDenominator>
                    <PolygonSymbolizer uom="pixel">
                        <Fill>
                            <CssParameter name="fill">#ff8000</CssParameter>
                            <CssParameter name="fill-opacity">0.75</CssParameter>
                        </Fill>
                        <Stroke>
                            <CssParameter name="stroke-width">1.0</CssParameter>
                            <CssParameter name="stroke-opacity">1.0</CssParameter>
                            <CssParameter name="stroke">#000000</CssParameter>
                            <CssParameter name="stroke-linejoin">mitre</CssParameter>
                            <CssParameter name="stroke-linecap">butt</CssParameter>
                        </Stroke>
                    </PolygonSymbolizer>
                </Rule>
                <Rule>
                    <Name>RoughnessCls117812308554222</Name>
                    <Title>B�schung_rauh</Title>
                    <Abstract>B�schung_rauh</Abstract>
                    <ogc:Filter>
                        <ogc:PropertyIsLike escape="/" singleChar="$" wildCard="*">
                            <ogc:PropertyName>roughnessStyle</ogc:PropertyName>
                            <ogc:Literal>B�schung_rauh</ogc:Literal>
                        </ogc:PropertyIsLike>
                    </ogc:Filter>
<MinScaleDenominator>0.0</MinScaleDenominator>
                    <MaxScaleDenominator>1.7976931348623157E308</MaxScaleDenominator>
                    <PolygonSymbolizer uom="pixel">
                        <Fill>
                            <CssParameter name="fill">#ffff00</CssParameter>
                            <CssParameter name="fill-opacity">0.75</CssParameter>
                        </Fill>
                        <Stroke>
                            <CssParameter name="stroke-width">1.0</CssParameter>
                            <CssParameter name="stroke-opacity">1.0</CssParameter>
                            <CssParameter name="stroke">#000000</CssParameter>
                            <CssParameter name="stroke-linejoin">mitre</CssParameter>
                            <CssParameter name="stroke-linecap">butt</CssParameter>
                        </Stroke>
                    </PolygonSymbolizer>
                </Rule>
                <Rule>
                    <Name>RoughnessCls117812308473018</Name>
                    <Title>B�schungssicherung</Title>
                    <Abstract>B�schungssicherung</Abstract>
                    <ogc:Filter>
                        <ogc:PropertyIsLike escape="/" singleChar="$" wildCard="*">
                            <ogc:PropertyName>roughnessStyle</ogc:PropertyName>
                            <ogc:Literal>B�schungssicherung</ogc:Literal>
                        </ogc:PropertyIsLike>
                    </ogc:Filter>
<MinScaleDenominator>0.0</MinScaleDenominator>
                    <MaxScaleDenominator>1.7976931348623157E308</MaxScaleDenominator>
                    <PolygonSymbolizer uom="pixel">
                        <Fill>
                            <CssParameter name="fill">#808080</CssParameter>
                            <CssParameter name="fill-opacity">0.75</CssParameter>
                        </Fill>
                        <Stroke>
                            <CssParameter name="stroke-width">1.0</CssParameter>
                            <CssParameter name="stroke-opacity">1.0</CssParameter>
                            <CssParameter name="stroke">#000000</CssParameter>
                            <CssParameter name="stroke-linejoin">mitre</CssParameter>
                            <CssParameter name="stroke-linecap">butt</CssParameter>
                        </Stroke>
                    </PolygonSymbolizer>
                </Rule>
                <Rule>
                    <Name>RoughnessCls117812308355818</Name>
                    <Title>Vorland mit Bewuchs 1</Title>
                    <Abstract>Vorland mit Bewuchs 1</Abstract>
                    <ogc:Filter>
                        <ogc:PropertyIsLike escape="/" singleChar="$" wildCard="*">
                            <ogc:PropertyName>roughnessStyle</ogc:PropertyName>
                            <ogc:Literal>Vorland mit Bewuchs 1</ogc:Literal>
                        </ogc:PropertyIsLike>
                    </ogc:Filter>
<MinScaleDenominator>0.0</MinScaleDenominator>
                    <MaxScaleDenominator>1.7976931348623157E308</MaxScaleDenominator>
                    <PolygonSymbolizer uom="pixel">
                        <Fill>
                            <CssParameter name="fill">#808000</CssParameter>
                            <CssParameter name="fill-opacity">0.75</CssParameter>
                        </Fill>
                        <Stroke>
                            <CssParameter name="stroke-width">1.0</CssParameter>
                            <CssParameter name="stroke-opacity">1.0</CssParameter>
                            <CssParameter name="stroke">#000000</CssParameter>
                            <CssParameter name="stroke-linejoin">mitre</CssParameter>
                            <CssParameter name="stroke-linecap">butt</CssParameter>
                        </Stroke>
                    </PolygonSymbolizer>
                </Rule>
                <Rule>
                    <Name>RoughnessCls117812308269729</Name>
                    <Title>Vorland ohne Bewuchs</Title>
                    <Abstract>Vorland ohne Bewuchs</Abstract>
                    <ogc:Filter>
                        <ogc:PropertyIsLike escape="/" singleChar="$" wildCard="*">
                            <ogc:PropertyName>roughnessStyle</ogc:PropertyName>
                            <ogc:Literal>Vorland ohne Bewuchs</ogc:Literal>
                        </ogc:PropertyIsLike>
                    </ogc:Filter>
<MinScaleDenominator>0.0</MinScaleDenominator>
                    <MaxScaleDenominator>1.7976931348623157E308</MaxScaleDenominator>
                    <PolygonSymbolizer uom="pixel">
                        <Fill>
                            <CssParameter name="fill">#800080</CssParameter>
                            <CssParameter name="fill-opacity">0.75</CssParameter>
                        </Fill>
                        <Stroke>
                            <CssParameter name="stroke-width">1.0</CssParameter>
                            <CssParameter name="stroke-opacity">1.0</CssParameter>
                            <CssParameter name="stroke">#000000</CssParameter>
                            <CssParameter name="stroke-linejoin">mitre</CssParameter>
                            <CssParameter name="stroke-linecap">butt</CssParameter>
                        </Stroke>
                    </PolygonSymbolizer>
                </Rule>
                <Rule>
                    <Name>RoughnessCls117812308185619</Name>
                    <Title>Vorland R�hricht ohne Bewuchs</Title>
                    <Abstract>Vorland R�hricht ohne Bewuchs</Abstract>
                    <ogc:Filter>
                        <ogc:PropertyIsLike escape="/" singleChar="$" wildCard="*">
                            <ogc:PropertyName>roughnessStyle</ogc:PropertyName>
                            <ogc:Literal>Vorland R�hricht ohne Bewuchs</ogc:Literal>
                        </ogc:PropertyIsLike>
                    </ogc:Filter>
<MinScaleDenominator>0.0</MinScaleDenominator>
                    <MaxScaleDenominator>1.7976931348623157E308</MaxScaleDenominator>
                    <PolygonSymbolizer uom="pixel">
                        <Fill>
                            <CssParameter name="fill">#ff80ff</CssParameter>
                            <CssParameter name="fill-opacity">0.75</CssParameter>
                        </Fill>
                        <Stroke>
                            <CssParameter name="stroke-width">1.0</CssParameter>
                            <CssParameter name="stroke-opacity">1.0</CssParameter>
                            <CssParameter name="stroke">#000000</CssParameter>
                            <CssParameter name="stroke-linejoin">mitre</CssParameter>
                            <CssParameter name="stroke-linecap">butt</CssParameter>
                        </Stroke>
                    </PolygonSymbolizer>
                </Rule>
                <Rule>
                    <Name>RoughnessCls117812308098418</Name>
                    <Title>Strasse</Title>
                    <Abstract>Strasse</Abstract>
                    <ogc:Filter>
                        <ogc:PropertyIsLike escape="/" singleChar="$" wildCard="*">
                            <ogc:PropertyName>roughnessStyle</ogc:PropertyName>
                            <ogc:Literal>Strasse</ogc:Literal>
                        </ogc:PropertyIsLike>
                    </ogc:Filter>
<MinScaleDenominator>0.0</MinScaleDenominator>
                    <MaxScaleDenominator>1.7976931348623157E308</MaxScaleDenominator>
                    <PolygonSymbolizer uom="pixel">
                        <Fill>
                            <CssParameter name="fill">#c0c0c0</CssParameter>
                            <CssParameter name="fill-opacity">0.75</CssParameter>
                        </Fill>
                        <Stroke>
                            <CssParameter name="stroke-width">1.0</CssParameter>
                            <CssParameter name="stroke-opacity">1.0</CssParameter>
                            <CssParameter name="stroke">#000000</CssParameter>
                            <CssParameter name="stroke-linejoin">mitre</CssParameter>
                            <CssParameter name="stroke-linecap">butt</CssParameter>
                        </Stroke>
                    </PolygonSymbolizer>
                </Rule>
                <Rule>
                    <Name>RoughnessCls117812308008315</Name>
                    <Title>Vorland mit Bewuchs 2</Title>
                    <Abstract>Vorland mit Bewuchs 2</Abstract>
                    <ogc:Filter>
                        <ogc:PropertyIsLike escape="/" singleChar="$" wildCard="*">
                            <ogc:PropertyName>roughnessStyle</ogc:PropertyName>
                            <ogc:Literal>Vorland mit Bewuchs 2</ogc:Literal>
                        </ogc:PropertyIsLike>
                    </ogc:Filter>
<MinScaleDenominator>0.0</MinScaleDenominator>
                    <MaxScaleDenominator>1.7976931348623157E308</MaxScaleDenominator>
                    <PolygonSymbolizer uom="pixel">
                        <Fill>
                            <CssParameter name="fill">#004000</CssParameter>
                            <CssParameter name="fill-opacity">0.75</CssParameter>
                        </Fill>
                        <Stroke>
                            <CssParameter name="stroke-width">1.0</CssParameter>
                            <CssParameter name="stroke-opacity">1.0</CssParameter>
                            <CssParameter name="stroke">#000000</CssParameter>
                            <CssParameter name="stroke-linejoin">mitre</CssParameter>
                            <CssParameter name="stroke-linecap">butt</CssParameter>
                        </Stroke>
                    </PolygonSymbolizer>
                </Rule>
                <Rule>
                    <Name>RoughnessCls11781230781506</Name>
                    <Title>Vorland mit Bewuchs 3</Title>
                    <Abstract>Vorland mit Bewuchs 3</Abstract>
                    <ogc:Filter>
                        <ogc:PropertyIsLike escape="/" singleChar="$" wildCard="*">
                            <ogc:PropertyName>roughnessStyle</ogc:PropertyName>
                            <ogc:Literal>Vorland mit Bewuchs 3</ogc:Literal>
                        </ogc:PropertyIsLike>
                    </ogc:Filter>
<MinScaleDenominator>0.0</MinScaleDenominator>
                    <MaxScaleDenominator>1.7976931348623157E308</MaxScaleDenominator>
                    <PolygonSymbolizer uom="pixel">
                        <Fill>
                            <CssParameter name="fill">#008000</CssParameter>
                            <CssParameter name="fill-opacity">0.75</CssParameter>
                        </Fill>
                        <Stroke>
                            <CssParameter name="stroke-width">1.0</CssParameter>
                            <CssParameter name="stroke-opacity">1.0</CssParameter>
                            <CssParameter name="stroke">#000000</CssParameter>
                            <CssParameter name="stroke-linejoin">mitre</CssParameter>
                            <CssParameter name="stroke-linecap">butt</CssParameter>
                        </Stroke>
                    </PolygonSymbolizer>
                </Rule>
                <Rule>
                    <Name>RoughnessCls117812307736919</Name>
                    <Title>Vorland mit Bewuchs 4</Title>
                    <Abstract>Vorland mit Bewuchs 4</Abstract>
                    <ogc:Filter>
                        <ogc:PropertyIsLike escape="/" singleChar="$" wildCard="*">
                            <ogc:PropertyName>roughnessStyle</ogc:PropertyName>
                            <ogc:Literal>Vorland mit Bewuchs 4</ogc:Literal>
                        </ogc:PropertyIsLike>
                    </ogc:Filter>
<MinScaleDenominator>0.0</MinScaleDenominator>
                    <MaxScaleDenominator>1.7976931348623157E308</MaxScaleDenominator>
                    <PolygonSymbolizer uom="pixel">
                        <Fill>
                            <CssParameter name="fill">#00ff00</CssParameter>
                            <CssParameter name="fill-opacity">0.75</CssParameter>
                        </Fill>
                        <Stroke>
                            <CssParameter name="stroke-width">1.0</CssParameter>
                            <CssParameter name="stroke-opacity">1.0</CssParameter>
                            <CssParameter name="stroke">#000000</CssParameter>
                            <CssParameter name="stroke-linejoin">mitre</CssParameter>
                            <CssParameter name="stroke-linecap">butt</CssParameter>
                        </Stroke>
                    </PolygonSymbolizer>
                </Rule>
                <Rule>
                    <Name>RoughnessCls117812307639722</Name>
                    <Title>Vorland mit Bewuchs 5</Title>
                    <Abstract>Vorland mit Bewuchs 5</Abstract>
                    <ogc:Filter>
                        <ogc:PropertyIsLike escape="/" singleChar="$" wildCard="*">
                            <ogc:PropertyName>roughnessStyle</ogc:PropertyName>
                            <ogc:Literal>Vorland mit Bewuchs 5</ogc:Literal>
                        </ogc:PropertyIsLike>
                    </ogc:Filter>
<MinScaleDenominator>0.0</MinScaleDenominator>
                    <MaxScaleDenominator>1.7976931348623157E308</MaxScaleDenominator>
                    <PolygonSymbolizer uom="pixel">
                        <Fill>
                            <CssParameter name="fill">#008080</CssParameter>
                            <CssParameter name="fill-opacity">0.75</CssParameter>
                        </Fill>
                        <Stroke>
                            <CssParameter name="stroke-width">1.0</CssParameter>
                            <CssParameter name="stroke-opacity">1.0</CssParameter>
                            <CssParameter name="stroke">#000000</CssParameter>
                            <CssParameter name="stroke-linejoin">mitre</CssParameter>
                            <CssParameter name="stroke-linecap">butt</CssParameter>
                        </Stroke>
                    </PolygonSymbolizer>
                </Rule>
                <Rule>
                    <Name>RoughnessCls117812307525616</Name>
                    <Title>Vorland mit Bewuchs 6</Title>
                    <Abstract>Vorland mit Bewuchs 6</Abstract>
                    <ogc:Filter>
                        <ogc:PropertyIsLike escape="/" singleChar="$" wildCard="*">
                            <ogc:PropertyName>roughnessStyle</ogc:PropertyName>
                            <ogc:Literal>Vorland mit Bewuchs 6</ogc:Literal>
                        </ogc:PropertyIsLike>
                    </ogc:Filter>
<MinScaleDenominator>0.0</MinScaleDenominator>
                    <MaxScaleDenominator>1.7976931348623157E308</MaxScaleDenominator>
                    <PolygonSymbolizer uom="pixel">
                        <Fill>
                            <CssParameter name="fill">#408080</CssParameter>
                            <CssParameter name="fill-opacity">0.75</CssParameter>
                        </Fill>
                        <Stroke>
                            <CssParameter name="stroke-width">1.0</CssParameter>
                            <CssParameter name="stroke-opacity">1.0</CssParameter>
                            <CssParameter name="stroke">#000000</CssParameter>
                            <CssParameter name="stroke-linejoin">mitre</CssParameter>
                            <CssParameter name="stroke-linecap">butt</CssParameter>
                        </Stroke>
                    </PolygonSymbolizer>
                </Rule>
                <Rule>
                    <Name>RoughnessCls11781230738834</Name>
                    <Title>Vorland mit Bewuchs 7</Title>
                    <Abstract>Vorland mit Bewuchs 7</Abstract>
                    <ogc:Filter>
                        <ogc:PropertyIsLike escape="/" singleChar="$" wildCard="*">
                            <ogc:PropertyName>roughnessStyle</ogc:PropertyName>
                            <ogc:Literal>Vorland mit Bewuchs 7</ogc:Literal>
                        </ogc:PropertyIsLike>
                    </ogc:Filter>
<MinScaleDenominator>0.0</MinScaleDenominator>
                    <MaxScaleDenominator>1.7976931348623157E308</MaxScaleDenominator>
                    <PolygonSymbolizer uom="pixel">
                        <Fill>
                            <CssParameter name="fill">#ff8080</CssParameter>
                            <CssParameter name="fill-opacity">0.75</CssParameter>
                        </Fill>
                        <Stroke>
                            <CssParameter name="stroke-width">1.0</CssParameter>
                            <CssParameter name="stroke-opacity">1.0</CssParameter>
                            <CssParameter name="stroke">#000000</CssParameter>
                            <CssParameter name="stroke-linejoin">mitre</CssParameter>
                            <CssParameter name="stroke-linecap">butt</CssParameter>
                        </Stroke>
                    </PolygonSymbolizer>
                </Rule>
                <Rule>
                    <Name>RoughnessCls11781230731726</Name>
                    <Title>Vorland mit Bewuchs 8</Title>
                    <Abstract>Vorland mit Bewuchs 8</Abstract>
                    <ogc:Filter>
                        <ogc:PropertyIsLike escape="/" singleChar="$" wildCard="*">
                            <ogc:PropertyName>roughnessStyle</ogc:PropertyName>
                            <ogc:Literal>Vorland mit Bewuchs 8</ogc:Literal>
                        </ogc:PropertyIsLike>
                    </ogc:Filter>
<MinScaleDenominator>0.0</MinScaleDenominator>
                    <MaxScaleDenominator>1.7976931348623157E308</MaxScaleDenominator>
                    <PolygonSymbolizer uom="pixel">
                        <Fill>
                            <CssParameter name="fill">#ff80ff</CssParameter>
                            <CssParameter name="fill-opacity">0.75</CssParameter>
                        </Fill>
                        <Stroke>
                            <CssParameter name="stroke-width">1.0</CssParameter>
                            <CssParameter name="stroke-opacity">1.0</CssParameter>
                            <CssParameter name="stroke">#000000</CssParameter>
                            <CssParameter name="stroke-linejoin">mitre</CssParameter>
                            <CssParameter name="stroke-linecap">butt</CssParameter>
                        </Stroke>
                    </PolygonSymbolizer>
                </Rule>
                <Rule>
                    <Name>RoughnessCls11781230724212</Name>
                    <Title>Vorland mit Bewuchs 9</Title>
                    <Abstract>Vorland mit Bewuchs 9</Abstract>
                    <ogc:Filter>
                        <ogc:PropertyIsLike escape="/" singleChar="$" wildCard="*">
                            <ogc:PropertyName>roughnessStyle</ogc:PropertyName>
                            <ogc:Literal>Vorland mit Bewuchs 9</ogc:Literal>
                        </ogc:PropertyIsLike>
                    </ogc:Filter>
<MinScaleDenominator>0.0</MinScaleDenominator>
                    <MaxScaleDenominator>1.7976931348623157E308</MaxScaleDenominator>
                    <PolygonSymbolizer uom="pixel">
                        <Fill>
                            <CssParameter name="fill">#00ffff</CssParameter>
                            <CssParameter name="fill-opacity">0.75</CssParameter>
                        </Fill>
                        <Stroke>
                            <CssParameter name="stroke-width">1.0</CssParameter>
                            <CssParameter name="stroke-opacity">1.0</CssParameter>
                            <CssParameter name="stroke">#000000</CssParameter>
                            <CssParameter name="stroke-linejoin">mitre</CssParameter>
                            <CssParameter name="stroke-linecap">butt</CssParameter>
                        </Stroke>
                    </PolygonSymbolizer>
                </Rule>
                <Rule>
                    <Name>RoughnessCls117812307166011</Name>
                    <Title>Vorland mit Bewuchs 10</Title>
                    <Abstract>Vorland mit Bewuchs 10</Abstract>
                    <ogc:Filter>
                        <ogc:PropertyIsLike escape="/" singleChar="$" wildCard="*">
                            <ogc:PropertyName>roughnessStyle</ogc:PropertyName>
                            <ogc:Literal>Vorland mit Bewuchs 10</ogc:Literal>
                        </ogc:PropertyIsLike>
                    </ogc:Filter>
<MinScaleDenominator>0.0</MinScaleDenominator>
                    <MaxScaleDenominator>1.7976931348623157E308</MaxScaleDenominator>
                    <PolygonSymbolizer uom="pixel">
                        <Fill>
                            <CssParameter name="fill">#c05b3f</CssParameter>
                            <CssParameter name="fill-opacity">0.75</CssParameter>
                        </Fill>
                        <Stroke>
                            <CssParameter name="stroke-width">1.0</CssParameter>
                            <CssParameter name="stroke-opacity">1.0</CssParameter>
                            <CssParameter name="stroke">#000000</CssParameter>
                            <CssParameter name="stroke-linejoin">mitre</CssParameter>
                            <CssParameter name="stroke-linecap">butt</CssParameter>
                        </Stroke>
                    </PolygonSymbolizer>
                </Rule>
                <Rule>
                    <Name>RoughnessCls11781230709497</Name>
                    <Title>Vorland mit Bewuchs 11</Title>
                    <Abstract>Vorland mit Bewuchs 11</Abstract>
                    <ogc:Filter>
                        <ogc:PropertyIsLike escape="/" singleChar="$" wildCard="*">
                            <ogc:PropertyName>roughnessStyle</ogc:PropertyName>
                            <ogc:Literal>Vorland mit Bewuchs 11</ogc:Literal>
                        </ogc:PropertyIsLike>
                    </ogc:Filter>
<MinScaleDenominator>0.0</MinScaleDenominator>
                    <MaxScaleDenominator>1.7976931348623157E308</MaxScaleDenominator>
                    <PolygonSymbolizer uom="pixel">
                        <Fill>
                            <CssParameter name="fill">#914d93</CssParameter>
                            <CssParameter name="fill-opacity">0.75</CssParameter>
                        </Fill>
                        <Stroke>
                            <CssParameter name="stroke-width">1.0</CssParameter>
                            <CssParameter name="stroke-opacity">1.0</CssParameter>
                            <CssParameter name="stroke">#000000</CssParameter>
                            <CssParameter name="stroke-linejoin">mitre</CssParameter>
                            <CssParameter name="stroke-linecap">butt</CssParameter>
                        </Stroke>
                    </PolygonSymbolizer>
                </Rule>
                <Rule>
                    <Name>RoughnessCls11781230702084</Name>
                    <Title>Vorland mit Bewuchs 12</Title>
                    <Abstract>Vorland mit Bewuchs 12</Abstract>
                    <ogc:Filter>
                        <ogc:PropertyIsLike escape="/" singleChar="$" wildCard="*">
                            <ogc:PropertyName>roughnessStyle</ogc:PropertyName>
                            <ogc:Literal>Vorland mit Bewuchs 12</ogc:Literal>
                        </ogc:PropertyIsLike>
                    </ogc:Filter>
<MinScaleDenominator>0.0</MinScaleDenominator>
                    <MaxScaleDenominator>1.7976931348623157E308</MaxScaleDenominator>
                    <PolygonSymbolizer uom="pixel">
                        <Fill>
                            <CssParameter name="fill">#e21dbf</CssParameter>
                            <CssParameter name="fill-opacity">0.75</CssParameter>
                        </Fill>
                        <Stroke>
                            <CssParameter name="stroke-width">1.0</CssParameter>
                            <CssParameter name="stroke-opacity">1.0</CssParameter>
                            <CssParameter name="stroke">#000000</CssParameter>
                            <CssParameter name="stroke-linejoin">mitre</CssParameter>
                            <CssParameter name="stroke-linecap">butt</CssParameter>
                        </Stroke>
                    </PolygonSymbolizer>
                </Rule>
                <Rule>
                    <Name>RoughnessCls117812306935612</Name>
                    <Title>Vorland mit Bewuchs 13</Title>
                    <Abstract>Vorland mit Bewuchs 13</Abstract>
                    <ogc:Filter>
                        <ogc:PropertyIsLike escape="/" singleChar="$" wildCard="*">
                            <ogc:PropertyName>roughnessStyle</ogc:PropertyName>
                            <ogc:Literal>Vorland mit Bewuchs 13</ogc:Literal>
                        </ogc:PropertyIsLike>
                    </ogc:Filter>
<MinScaleDenominator>0.0</MinScaleDenominator>
                    <MaxScaleDenominator>1.7976931348623157E308</MaxScaleDenominator>
                    <PolygonSymbolizer uom="pixel">
                        <Fill>
                            <CssParameter name="fill">#f8d6d8</CssParameter>
                            <CssParameter name="fill-opacity">0.75</CssParameter>
                        </Fill>
                        <Stroke>
                            <CssParameter name="stroke-width">1.0</CssParameter>
                            <CssParameter name="stroke-opacity">1.0</CssParameter>
                            <CssParameter name="stroke">#000000</CssParameter>
                            <CssParameter name="stroke-linejoin">mitre</CssParameter>
                            <CssParameter name="stroke-linecap">butt</CssParameter>
                        </Stroke>
                    </PolygonSymbolizer>
                </Rule>
                <Rule>
                    <Name>RoughnessCls11781230573989</Name>
                    <Title>Vorland mit Bewuchs 15</Title>
                    <Abstract>Vorland mit Bewuchs 15</Abstract>
                    <ogc:Filter>
                        <ogc:PropertyIsLike escape="/" singleChar="$" wildCard="*">
                            <ogc:PropertyName>roughnessStyle</ogc:PropertyName>
                            <ogc:Literal>Vorland mit Bewuchs 15</ogc:Literal>
                        </ogc:PropertyIsLike>
                    </ogc:Filter>
<MinScaleDenominator>0.0</MinScaleDenominator>
                    <MaxScaleDenominator>1.7976931348623157E308</MaxScaleDenominator>
                    <PolygonSymbolizer uom="pixel">
                        <Fill>
                            <CssParameter name="fill">#3ec16b</CssParameter>
                            <CssParameter name="fill-opacity">0.75</CssParameter>
                        </Fill>
                        <Stroke>
                            <CssParameter name="stroke-width">1.0</CssParameter>
                            <CssParameter name="stroke-opacity">1.0</CssParameter>
                            <CssParameter name="stroke">#000000</CssParameter>
                            <CssParameter name="stroke-linejoin">mitre</CssParameter>
                            <CssParameter name="stroke-linecap">butt</CssParameter>
                        </Stroke>
                    </PolygonSymbolizer>
                </Rule>
                <Rule>
                    <Name>RoughnessCls11781230557968</Name>
                    <Title>Vorland mit Bewuchs 17</Title>
                    <Abstract>Vorland mit Bewuchs 17</Abstract>
                    <ogc:Filter>
                        <ogc:PropertyIsLike escape="/" singleChar="$" wildCard="*">
                            <ogc:PropertyName>roughnessStyle</ogc:PropertyName>
                            <ogc:Literal>Vorland mit Bewuchs 17</ogc:Literal>
                        </ogc:PropertyIsLike>
                    </ogc:Filter>
<MinScaleDenominator>0.0</MinScaleDenominator>
                    <MaxScaleDenominator>1.7976931348623157E308</MaxScaleDenominator>
                    <PolygonSymbolizer uom="pixel">
                        <Fill>
                            <CssParameter name="fill">#c1b91e</CssParameter>
                            <CssParameter name="fill-opacity">0.75</CssParameter>
                        </Fill>
                        <Stroke>
                            <CssParameter name="stroke-width">1.0</CssParameter>
                            <CssParameter name="stroke-opacity">1.0</CssParameter>
                            <CssParameter name="stroke">#000000</CssParameter>
                            <CssParameter name="stroke-linejoin">mitre</CssParameter>
                            <CssParameter name="stroke-linecap">butt</CssParameter>
                        </Stroke>
                    </PolygonSymbolizer>
                </Rule>
                <Rule>
                    <Name>RoughnessCls11781230548541</Name>
                    <Title>Vorland mit Bewuchs 18</Title>
                    <Abstract>Vorland mit Bewuchs 18</Abstract>
                    <ogc:Filter>
                        <ogc:PropertyIsLike escape="/" singleChar="$" wildCard="*">
                            <ogc:PropertyName>roughnessStyle</ogc:PropertyName>
                            <ogc:Literal>Vorland mit Bewuchs 18</ogc:Literal>
                        </ogc:PropertyIsLike>
                    </ogc:Filter>
<MinScaleDenominator>0.0</MinScaleDenominator>
                    <MaxScaleDenominator>1.7976931348623157E308</MaxScaleDenominator>
                    <PolygonSymbolizer uom="pixel">
                        <Fill>
                            <CssParameter name="fill">#5e0f4e</CssParameter>
                            <CssParameter name="fill-opacity">0.75</CssParameter>
                        </Fill>
                        <Stroke>
                            <CssParameter name="stroke-width">1.0</CssParameter>
                            <CssParameter name="stroke-opacity">1.0</CssParameter>
                            <CssParameter name="stroke">#000000</CssParameter>
                            <CssParameter name="stroke-linejoin">mitre</CssParameter>
                            <CssParameter name="stroke-linecap">butt</CssParameter>
                        </Stroke>
                    </PolygonSymbolizer>
                </Rule>
                <Rule>
                    <Name>RoughnessCls11781230538025</Name>
                    <Title>Vorland mit Bewuchs 19</Title>
                    <Abstract>Vorland mit Bewuchs 19</Abstract>
                    <ogc:Filter>
                        <ogc:PropertyIsLike escape="/" singleChar="$" wildCard="*">
                            <ogc:PropertyName>roughnessStyle</ogc:PropertyName>
                            <ogc:Literal>Vorland mit Bewuchs 19</ogc:Literal>
                        </ogc:PropertyIsLike>
                    </ogc:Filter>
<MinScaleDenominator>0.0</MinScaleDenominator>
                    <MaxScaleDenominator>1.7976931348623157E308</MaxScaleDenominator>
                    <PolygonSymbolizer uom="pixel">
                        <Fill>
                            <CssParameter name="fill">#0db360</CssParameter>
                            <CssParameter name="fill-opacity">0.75</CssParameter>
                        </Fill>
                        <Stroke>
                            <CssParameter name="stroke-width">1.0</CssParameter>
                            <CssParameter name="stroke-opacity">1.0</CssParameter>
                            <CssParameter name="stroke">#000000</CssParameter>
                            <CssParameter name="stroke-linejoin">mitre</CssParameter>
                            <CssParameter name="stroke-linecap">butt</CssParameter>
                        </Stroke>
                    </PolygonSymbolizer>
                </Rule>
                <Rule>
                    <Name>RoughnessCls11781230528011</Name>
                    <Title>Vorland mit Bewuchs 20</Title>
                    <Abstract>Vorland mit Bewuchs 20</Abstract>
                    <ogc:Filter>
                        <ogc:PropertyIsLike escape="/" singleChar="$" wildCard="*">
                            <ogc:PropertyName>roughnessStyle</ogc:PropertyName>
                            <ogc:Literal>Vorland mit Bewuchs 20</ogc:Literal>
                        </ogc:PropertyIsLike>
                    </ogc:Filter>
<MinScaleDenominator>0.0</MinScaleDenominator>
                    <MaxScaleDenominator>1.7976931348623157E308</MaxScaleDenominator>
                    <PolygonSymbolizer uom="pixel">
                        <Fill>
                            <CssParameter name="fill">#0e6372</CssParameter>
                            <CssParameter name="fill-opacity">0.75</CssParameter>
                        </Fill>
                        <Stroke>
                            <CssParameter name="stroke-width">1.0</CssParameter>
                            <CssParameter name="stroke-opacity">1.0</CssParameter>
                            <CssParameter name="stroke">#000000</CssParameter>
                            <CssParameter name="stroke-linejoin">mitre</CssParameter>
                            <CssParameter name="stroke-linecap">butt</CssParameter>
                        </Stroke>
                    </PolygonSymbolizer>
                </Rule>
                <Rule>
                    <Name>RoughnessCls11781230517393</Name>
                    <Title>Vorland mit Bewuchs 21</Title>
                    <Abstract>Vorland mit Bewuchs 21</Abstract>
                    <ogc:Filter>
                        <ogc:PropertyIsLike escape="/" singleChar="$" wildCard="*">
                            <ogc:PropertyName>roughnessStyle</ogc:PropertyName>
                            <ogc:Literal>Vorland mit Bewuchs 21</ogc:Literal>
                        </ogc:PropertyIsLike>
                    </ogc:Filter>
<MinScaleDenominator>0.0</MinScaleDenominator>
                    <MaxScaleDenominator>1.7976931348623157E308</MaxScaleDenominator>
                    <PolygonSymbolizer uom="pixel">
                        <Fill>
                            <CssParameter name="fill">#cd4932</CssParameter>
                            <CssParameter name="fill-opacity">0.75</CssParameter>
                        </Fill>
                        <Stroke>
                            <CssParameter name="stroke-width">1.0</CssParameter>
                            <CssParameter name="stroke-opacity">1.0</CssParameter>
                            <CssParameter name="stroke">#000000</CssParameter>
                            <CssParameter name="stroke-linejoin">mitre</CssParameter>
                            <CssParameter name="stroke-linecap">butt</CssParameter>
                        </Stroke>
                    </PolygonSymbolizer>
                </Rule>
                <Rule>
                    <Name>RoughnessCls11781230490251</Name>
                    <Title>Vorland mit Bewuchs 22</Title>
                    <Abstract>Vorland mit Bewuchs 22</Abstract>
                    <ogc:Filter>
                        <ogc:PropertyIsLike escape="/" singleChar="$" wildCard="*">
                            <ogc:PropertyName>roughnessStyle</ogc:PropertyName>
                            <ogc:Literal>Vorland mit Bewuchs 22</ogc:Literal>
                        </ogc:PropertyIsLike>
                    </ogc:Filter>
<MinScaleDenominator>0.0</MinScaleDenominator>
                    <MaxScaleDenominator>1.7976931348623157E308</MaxScaleDenominator>
                    <PolygonSymbolizer uom="pixel">
                        <Fill>
                            <CssParameter name="fill">#ff8040</CssParameter>
                            <CssParameter name="fill-opacity">0.75</CssParameter>
                        </Fill>
                        <Stroke>
                            <CssParameter name="stroke-width">1.0</CssParameter>
                            <CssParameter name="stroke-opacity">1.0</CssParameter>
                            <CssParameter name="stroke">#000000</CssParameter>
                            <CssParameter name="stroke-linejoin">mitre</CssParameter>
                            <CssParameter name="stroke-linecap">butt</CssParameter>
                        </Stroke>
                    </PolygonSymbolizer>
                </Rule>
                <Rule>
                    <Name>RoughnessCls11768145593596</Name>
                    <Title>Vorland mit Bewuchs 23</Title>
                    <Abstract>Vorland mit Bewuchs 23</Abstract>
                    <ogc:Filter>
                        <ogc:PropertyIsLike escape="/" singleChar="$" wildCard="*">
                            <ogc:PropertyName>roughnessStyle</ogc:PropertyName>
                            <ogc:Literal>Vorland mit Bewuchs 23</ogc:Literal>
                        </ogc:PropertyIsLike>
                    </ogc:Filter>
<MinScaleDenominator>0.0</MinScaleDenominator>
                    <MaxScaleDenominator>1.7976931348623157E308</MaxScaleDenominator>
                    <PolygonSymbolizer uom="pixel">
                        <Fill>
                            <CssParameter name="fill">#8bf3c1</CssParameter>
                            <CssParameter name="fill-opacity">0.75</CssParameter>
                        </Fill>
                        <Stroke>
                            <CssParameter name="stroke-width">1.0</CssParameter>
                            <CssParameter name="stroke-opacity">1.0</CssParameter>
                            <CssParameter name="stroke">#000000</CssParameter>
                            <CssParameter name="stroke-linejoin">mitre</CssParameter>
                            <CssParameter name="stroke-linecap">butt</CssParameter>
                        </Stroke>
                    </PolygonSymbolizer>
                </Rule>
                <Rule>
                    <Name>RoughnessCls11707777217344</Name>
                    <Title>Vorland mit Bewuchs 24</Title>
                    <Abstract>Vorland mit Bewuchs 24</Abstract>
                    <ogc:Filter>
                        <ogc:PropertyIsLike escape="/" singleChar="$" wildCard="*">
                            <ogc:PropertyName>roughnessStyle</ogc:PropertyName>
                            <ogc:Literal>Vorland mit Bewuchs 24</ogc:Literal>
                        </ogc:PropertyIsLike>
                    </ogc:Filter>
<MinScaleDenominator>0.0</MinScaleDenominator>
                    <MaxScaleDenominator>1.7976931348623157E308</MaxScaleDenominator>
                    <PolygonSymbolizer uom="pixel">
                        <Fill>
                            <CssParameter name="fill">#e39be1</CssParameter>
                            <CssParameter name="fill-opacity">0.75</CssParameter>
                        </Fill>
                        <Stroke>
                            <CssParameter name="stroke-width">1.0</CssParameter>
                            <CssParameter name="stroke-opacity">1.0</CssParameter>
                            <CssParameter name="stroke">#000000</CssParameter>
                            <CssParameter name="stroke-linejoin">mitre</CssParameter>
                            <CssParameter name="stroke-linecap">butt</CssParameter>
                        </Stroke>
                    </PolygonSymbolizer>
                </Rule>
                <Rule>
                    <Name>RoughnessCls1183482233335331</Name>
                    <Title>Gras mit dichtem jungen Baumbesatz</Title>
                    <Abstract>Gras mit dichtem jungen Baumbesatz</Abstract>
                    <ogc:Filter>
                        <ogc:PropertyIsLike escape="/" singleChar="$" wildCard="*">
                            <ogc:PropertyName>roughnessStyle</ogc:PropertyName>
                            <ogc:Literal>Gras mit dichtem jungen Baumbesatz</ogc:Literal>
                        </ogc:PropertyIsLike>
                    </ogc:Filter>
<MinScaleDenominator>0.0</MinScaleDenominator>
                    <MaxScaleDenominator>1.7976931348623157E308</MaxScaleDenominator>
                    <PolygonSymbolizer uom="pixel">
                        <Fill>
                            <CssParameter name="fill">#003300</CssParameter>
                            <CssParameter name="fill-opacity">0.75</CssParameter>
                        </Fill>
                        <Stroke>
                            <CssParameter name="stroke-width">1.0</CssParameter>
                            <CssParameter name="stroke-opacity">1.0</CssParameter>
                            <CssParameter name="stroke">#000000</CssParameter>
                            <CssParameter name="stroke-linejoin">mitre</CssParameter>
                            <CssParameter name="stroke-linecap">butt</CssParameter>
                        </Stroke>
                    </PolygonSymbolizer>
                </Rule>
                <Rule>
                    <Name>RoughnessCls1183482232364651</Name>
                    <Title>Gras mit dichtem mehrj�hrigen Baumbesatz</Title>
                    <Abstract>Gras mit dichtem mehrj�hrigen Baumbesatz</Abstract>
                    <ogc:Filter>
                        <ogc:PropertyIsLike escape="/" singleChar="$" wildCard="*">
                            <ogc:PropertyName>roughnessStyle</ogc:PropertyName>
                            <ogc:Literal>Gras mit dichtem mehrj�hrigen Baumbesatz</ogc:Literal>
                        </ogc:PropertyIsLike>
                    </ogc:Filter>
<MinScaleDenominator>0.0</MinScaleDenominator>
                    <MaxScaleDenominator>1.7976931348623157E308</MaxScaleDenominator>
                    <PolygonSymbolizer uom="pixel">
                        <Fill>
                            <CssParameter name="fill">#005100</CssParameter>
                            <CssParameter name="fill-opacity">0.75</CssParameter>
                        </Fill>
                        <Stroke>
                            <CssParameter name="stroke-width">1.0</CssParameter>
                            <CssParameter name="stroke-opacity">1.0</CssParameter>
                            <CssParameter name="stroke">#000000</CssParameter>
                            <CssParameter name="stroke-linejoin">mitre</CssParameter>
                            <CssParameter name="stroke-linecap">butt</CssParameter>
                        </Stroke>
                    </PolygonSymbolizer>
                </Rule>
                <Rule>
                    <Name>RoughnessCls1183482231563611</Name>
                    <Title>Gras mit lockerem Baumbesatz</Title>
                    <Abstract>Gras mit lockerem Baumbesatz</Abstract>
                    <ogc:Filter>
                        <ogc:PropertyIsLike escape="/" singleChar="$" wildCard="*">
                            <ogc:PropertyName>roughnessStyle</ogc:PropertyName>
                            <ogc:Literal>Gras mit lockerem Baumbesatz</ogc:Literal>
                        </ogc:PropertyIsLike>
                    </ogc:Filter>
<MinScaleDenominator>0.0</MinScaleDenominator>
                    <MaxScaleDenominator>1.7976931348623157E308</MaxScaleDenominator>
                    <PolygonSymbolizer uom="pixel">
                        <Fill>
                            <CssParameter name="fill">#006f00</CssParameter>
                            <CssParameter name="fill-opacity">0.75</CssParameter>
                        </Fill>
                        <Stroke>
                            <CssParameter name="stroke-width">1.0</CssParameter>
                            <CssParameter name="stroke-opacity">1.0</CssParameter>
                            <CssParameter name="stroke">#000000</CssParameter>
                            <CssParameter name="stroke-linejoin">mitre</CssParameter>
                            <CssParameter name="stroke-linecap">butt</CssParameter>
                        </Stroke>
                    </PolygonSymbolizer>
                </Rule>
                <Rule>
                    <Name>RoughnessCls1183482230732181</Name>
                    <Title>Gras mit mehrj�hrigem Baumbesatz</Title>
                    <Abstract>Gras mit mehrj�hrigem Baumbesatz</Abstract>
                    <ogc:Filter>
                        <ogc:PropertyIsLike escape="/" singleChar="$" wildCard="*">
                            <ogc:PropertyName>roughnessStyle</ogc:PropertyName>
                            <ogc:Literal>Gras mit mehrj�hrigem Baumbesatz</ogc:Literal>
                        </ogc:PropertyIsLike>
                    </ogc:Filter>
<MinScaleDenominator>0.0</MinScaleDenominator>
                    <MaxScaleDenominator>1.7976931348623157E308</MaxScaleDenominator>
                    <PolygonSymbolizer uom="pixel">
                        <Fill>
                            <CssParameter name="fill">#008c00</CssParameter>
                            <CssParameter name="fill-opacity">0.75</CssParameter>
                        </Fill>
                        <Stroke>
                            <CssParameter name="stroke-width">1.0</CssParameter>
                            <CssParameter name="stroke-opacity">1.0</CssParameter>
                            <CssParameter name="stroke">#000000</CssParameter>
                            <CssParameter name="stroke-linejoin">mitre</CssParameter>
                            <CssParameter name="stroke-linecap">butt</CssParameter>
                        </Stroke>
                    </PolygonSymbolizer>
                </Rule>
                <Rule>
                    <Name>RoughnessCls1183482229950481</Name>
                    <Title>Gras mit aufgelockerten B�schen</Title>
                    <Abstract>Gras mit aufgelockerten B�schen</Abstract>
                    <ogc:Filter>
                        <ogc:PropertyIsLike escape="/" singleChar="$" wildCard="*">
                            <ogc:PropertyName>roughnessStyle</ogc:PropertyName>
                            <ogc:Literal>Gras mit aufgelockerten B�schen</ogc:Literal>
                        </ogc:PropertyIsLike>
                    </ogc:Filter>
<MinScaleDenominator>0.0</MinScaleDenominator>
                    <MaxScaleDenominator>1.7976931348623157E308</MaxScaleDenominator>
                    <PolygonSymbolizer uom="pixel">
                        <Fill>
                            <CssParameter name="fill">#00aa00</CssParameter>
                            <CssParameter name="fill-opacity">0.75</CssParameter>
                        </Fill>
                        <Stroke>
                            <CssParameter name="stroke-width">1.0</CssParameter>
                            <CssParameter name="stroke-opacity">1.0</CssParameter>
                            <CssParameter name="stroke">#000000</CssParameter>
                            <CssParameter name="stroke-linejoin">mitre</CssParameter>
                            <CssParameter name="stroke-linecap">butt</CssParameter>
                        </Stroke>
                    </PolygonSymbolizer>
                </Rule>
                <Rule>
                    <Name>RoughnessCls1183482229109461</Name>
                    <Title>Gras mit gro�en B�schen</Title>
                    <Abstract>Gras mit gro�en B�schen</Abstract>
                    <ogc:Filter>
                        <ogc:PropertyIsLike escape="/" singleChar="$" wildCard="*">
                            <ogc:PropertyName>roughnessStyle</ogc:PropertyName>
                            <ogc:Literal>Gras mit gro�en B�schen</ogc:Literal>
                        </ogc:PropertyIsLike>
                    </ogc:Filter>
<MinScaleDenominator>0.0</MinScaleDenominator>
                    <MaxScaleDenominator>1.7976931348623157E308</MaxScaleDenominator>
                    <PolygonSymbolizer uom="pixel">
                        <Fill>
                            <CssParameter name="fill">#00aa00</CssParameter>
                            <CssParameter name="fill-opacity">0.75</CssParameter>
                        </Fill>
                        <Stroke>
                            <CssParameter name="stroke-width">1.0</CssParameter>
                            <CssParameter name="stroke-opacity">1.0</CssParameter>
                            <CssParameter name="stroke">#000000</CssParameter>
                            <CssParameter name="stroke-linejoin">mitre</CssParameter>
                            <CssParameter name="stroke-linecap">butt</CssParameter>
                        </Stroke>
                    </PolygonSymbolizer>
                </Rule>
                <Rule>
                    <Name>RoughnessCls118348222829821</Name>
                    <Title>Gras mit kleinen Buschgruppen</Title>
                    <Abstract>Gras mit kleinen Buschgruppen</Abstract>
                    <ogc:Filter>
                        <ogc:PropertyIsLike escape="/" singleChar="$" wildCard="*">
                            <ogc:PropertyName>roughnessStyle</ogc:PropertyName>
                            <ogc:Literal>Gras mit kleinen Buschgruppen</ogc:Literal>
                        </ogc:PropertyIsLike>
                    </ogc:Filter>
<MinScaleDenominator>0.0</MinScaleDenominator>
                    <MaxScaleDenominator>1.7976931348623157E308</MaxScaleDenominator>
                    <PolygonSymbolizer uom="pixel">
                        <Fill>
                            <CssParameter name="fill">#00cc00</CssParameter>
                            <CssParameter name="fill-opacity">0.75</CssParameter>
                        </Fill>
                        <Stroke>
                            <CssParameter name="stroke-width">1.0</CssParameter>
                            <CssParameter name="stroke-opacity">1.0</CssParameter>
                            <CssParameter name="stroke">#000000</CssParameter>
                            <CssParameter name="stroke-linejoin">mitre</CssParameter>
                            <CssParameter name="stroke-linecap">butt</CssParameter>
                        </Stroke>
                    </PolygonSymbolizer>
                </Rule>
                <Rule>
                    <Name>RoughnessCls1183482215419581</Name>
                    <Title>Gras mit kleinen B�schen</Title>
                    <Abstract>Gras mit kleinen B�schen</Abstract>
                    <ogc:Filter>
                        <ogc:PropertyIsLike escape="/" singleChar="$" wildCard="*">
                            <ogc:PropertyName>roughnessStyle</ogc:PropertyName>
                            <ogc:Literal>Gras mit kleinen B�schen</ogc:Literal>
                        </ogc:PropertyIsLike>
                    </ogc:Filter>
<MinScaleDenominator>0.0</MinScaleDenominator>
                    <MaxScaleDenominator>1.7976931348623157E308</MaxScaleDenominator>
                    <PolygonSymbolizer uom="pixel">
                        <Fill>
                            <CssParameter name="fill">#00e800</CssParameter>
                            <CssParameter name="fill-opacity">0.75</CssParameter>
                        </Fill>
                        <Stroke>
                            <CssParameter name="stroke-width">1.0</CssParameter>
                            <CssParameter name="stroke-opacity">1.0</CssParameter>
                            <CssParameter name="stroke">#000000</CssParameter>
                            <CssParameter name="stroke-linejoin">mitre</CssParameter>
                            <CssParameter name="stroke-linecap">butt</CssParameter>
                        </Stroke>
                    </PolygonSymbolizer>
                </Rule>
                <Rule>
                    <Name>RoughnessCls1183482214208401</Name>
                    <Title>Gras mit B�schen mit Kronenschluss</Title>
                    <Abstract>Gras mit B�schen mit Kronenschluss</Abstract>
                    <ogc:Filter>
                        <ogc:PropertyIsLike escape="/" singleChar="$" wildCard="*">
                            <ogc:PropertyName>roughnessStyle</ogc:PropertyName>
                            <ogc:Literal>Gras mit B�schen mit Kronenschluss</ogc:Literal>
                        </ogc:PropertyIsLike>
                    </ogc:Filter>
<MinScaleDenominator>0.0</MinScaleDenominator>
                    <MaxScaleDenominator>1.7976931348623157E308</MaxScaleDenominator>
                    <PolygonSymbolizer uom="pixel">
                        <Fill>
                            <CssParameter name="fill">#15ff15</CssParameter>
                            <CssParameter name="fill-opacity">0.75</CssParameter>
                        </Fill>
                        <Stroke>
                            <CssParameter name="stroke-width">1.0</CssParameter>
                            <CssParameter name="stroke-opacity">1.0</CssParameter>
                            <CssParameter name="stroke">#000000</CssParameter>
                            <CssParameter name="stroke-linejoin">mitre</CssParameter>
                            <CssParameter name="stroke-linecap">butt</CssParameter>
                        </Stroke>
                    </PolygonSymbolizer>
                </Rule>
                <Rule>
                    <Name>RoughnessCls1183482213347331</Name>
                    <Title>Gras mit B�schen mittlerer Gr��e</Title>
                    <Abstract>Gras mit B�schen mittlerer Gr��e</Abstract>
                    <ogc:Filter>
                        <ogc:PropertyIsLike escape="/" singleChar="$" wildCard="*">
                            <ogc:PropertyName>roughnessStyle</ogc:PropertyName>
                            <ogc:Literal>Gras mit B�schen mittlerer Gr��e</ogc:Literal>
                        </ogc:PropertyIsLike>
                    </ogc:Filter>
<MinScaleDenominator>0.0</MinScaleDenominator>
                    <MaxScaleDenominator>1.7976931348623157E308</MaxScaleDenominator>
                    <PolygonSymbolizer uom="pixel">
                        <Fill>
                            <CssParameter name="fill">#53ff53</CssParameter>
                            <CssParameter name="fill-opacity">0.75</CssParameter>
                        </Fill>
                        <Stroke>
                            <CssParameter name="stroke-width">1.0</CssParameter>
                            <CssParameter name="stroke-opacity">1.0</CssParameter>
                            <CssParameter name="stroke">#000000</CssParameter>
                            <CssParameter name="stroke-linejoin">mitre</CssParameter>
                            <CssParameter name="stroke-linecap">butt</CssParameter>
                        </Stroke>
                    </PolygonSymbolizer>
                </Rule>
                <Rule>
                    <Name>RoughnessCls118348221256501</Name>
                    <Title>Gras mit gro�en Buschgruppen</Title>
                    <Abstract>Gras mit gro�en Buschgruppen</Abstract>
                    <ogc:Filter>
                        <ogc:PropertyIsLike escape="/" singleChar="$" wildCard="*">
                            <ogc:PropertyName>roughnessStyle</ogc:PropertyName>
                            <ogc:Literal>Gras mit gro�en Buschgruppen</ogc:Literal>
                        </ogc:PropertyIsLike>
                    </ogc:Filter>
<MinScaleDenominator>0.0</MinScaleDenominator>
                    <MaxScaleDenominator>1.7976931348623157E308</MaxScaleDenominator>
                    <PolygonSymbolizer uom="pixel">
                        <Fill>
                            <CssParameter name="fill">#95ff95</CssParameter>
                            <CssParameter name="fill-opacity">0.75</CssParameter>
                        </Fill>
                        <Stroke>
                            <CssParameter name="stroke-width">1.0</CssParameter>
                            <CssParameter name="stroke-opacity">1.0</CssParameter>
                            <CssParameter name="stroke">#000000</CssParameter>
                            <CssParameter name="stroke-linejoin">mitre</CssParameter>
                            <CssParameter name="stroke-linecap">butt</CssParameter>
                        </Stroke>
                    </PolygonSymbolizer>
                </Rule>
                <Rule>
                    <Name>RoughnessCls1183482211454381</Name>
                    <Title>Kraut mit dichtem jungen Baumbesatz</Title>
                    <Abstract>Kraut mit dichtem jungen Baumbesatz</Abstract>
                    <ogc:Filter>
                        <ogc:PropertyIsLike escape="/" singleChar="$" wildCard="*">
                            <ogc:PropertyName>roughnessStyle</ogc:PropertyName>
                            <ogc:Literal>Kraut mit dichtem jungen Baumbesatz</ogc:Literal>
                        </ogc:PropertyIsLike>
                    </ogc:Filter>
<MinScaleDenominator>0.0</MinScaleDenominator>
                    <MaxScaleDenominator>1.7976931348623157E308</MaxScaleDenominator>
                    <PolygonSymbolizer uom="pixel">
                        <Fill>
                            <CssParameter name="fill">#804000</CssParameter>
                            <CssParameter name="fill-opacity">0.75</CssParameter>
                        </Fill>
                        <Stroke>
                            <CssParameter name="stroke-width">1.0</CssParameter>
                            <CssParameter name="stroke-opacity">1.0</CssParameter>
                            <CssParameter name="stroke">#000000</CssParameter>
                            <CssParameter name="stroke-linejoin">mitre</CssParameter>
                            <CssParameter name="stroke-linecap">butt</CssParameter>
                        </Stroke>
                    </PolygonSymbolizer>
                </Rule>
                <Rule>
                    <Name>RoughnessCls1183482210663381</Name>
                    <Title>Kraut mit dichtem mehrj�hrigen Baumbesatz</Title>
                    <Abstract>Kraut mit dichtem mehrj�hrigen Baumbesatz</Abstract>
                    <ogc:Filter>
                        <ogc:PropertyIsLike escape="/" singleChar="$" wildCard="*">
                            <ogc:PropertyName>roughnessStyle</ogc:PropertyName>
                            <ogc:Literal>Kraut mit dichtem mehrj�hrigen Baumbesatz</ogc:Literal>
                        </ogc:PropertyIsLike>
                    </ogc:Filter>
<MinScaleDenominator>0.0</MinScaleDenominator>
                    <MaxScaleDenominator>1.7976931348623157E308</MaxScaleDenominator>
                    <PolygonSymbolizer uom="pixel">
                        <Fill>
                            <CssParameter name="fill">#b35900</CssParameter>
                            <CssParameter name="fill-opacity">0.75</CssParameter>
                        </Fill>
                        <Stroke>
                            <CssParameter name="stroke-width">1.0</CssParameter>
                            <CssParameter name="stroke-opacity">1.0</CssParameter>
                            <CssParameter name="stroke">#000000</CssParameter>
                            <CssParameter name="stroke-linejoin">mitre</CssParameter>
                            <CssParameter name="stroke-linecap">butt</CssParameter>
                        </Stroke>
                    </PolygonSymbolizer>
                </Rule>
                <Rule>
                    <Name>RoughnessCls1183482209902441</Name>
                    <Title>Kraut mit lockeren Baumbesatz</Title>
                    <Abstract>Kraut mit lockeren Baumbesatz</Abstract>
                    <ogc:Filter>
                        <ogc:PropertyIsLike escape="/" singleChar="$" wildCard="*">
                            <ogc:PropertyName>roughnessStyle</ogc:PropertyName>
                            <ogc:Literal>Kraut mit lockeren Baumbesatz</ogc:Literal>
                        </ogc:PropertyIsLike>
                    </ogc:Filter>
<MinScaleDenominator>0.0</MinScaleDenominator>
                    <MaxScaleDenominator>1.7976931348623157E308</MaxScaleDenominator>
                    <PolygonSymbolizer uom="pixel">
                        <Fill>
                            <CssParameter name="fill">#d76b00</CssParameter>
                            <CssParameter name="fill-opacity">0.75</CssParameter>
                        </Fill>
                        <Stroke>
                            <CssParameter name="stroke-width">1.0</CssParameter>
                            <CssParameter name="stroke-opacity">1.0</CssParameter>
                            <CssParameter name="stroke">#000000</CssParameter>
                            <CssParameter name="stroke-linejoin">mitre</CssParameter>
                            <CssParameter name="stroke-linecap">butt</CssParameter>
                        </Stroke>
                    </PolygonSymbolizer>
                </Rule>
                <Rule>
                    <Name>RoughnessCls1183482208950281</Name>
                    <Title>Kraut mit aufgelockerten B�schen</Title>
                    <Abstract>Kraut mit aufgelockerten B�schen</Abstract>
                    <ogc:Filter>
                        <ogc:PropertyIsLike escape="/" singleChar="$" wildCard="*">
                            <ogc:PropertyName>roughnessStyle</ogc:PropertyName>
                            <ogc:Literal>Kraut mit aufgelockerten B�schen</ogc:Literal>
                        </ogc:PropertyIsLike>
                    </ogc:Filter>
<MinScaleDenominator>0.0</MinScaleDenominator>
                    <MaxScaleDenominator>1.7976931348623157E308</MaxScaleDenominator>
                    <PolygonSymbolizer uom="pixel">
                        <Fill>
                            <CssParameter name="fill">#ff8b17</CssParameter>
                            <CssParameter name="fill-opacity">0.75</CssParameter>
                        </Fill>
                        <Stroke>
                            <CssParameter name="stroke-width">1.0</CssParameter>
                            <CssParameter name="stroke-opacity">1.0</CssParameter>
                            <CssParameter name="stroke">#000000</CssParameter>
                            <CssParameter name="stroke-linejoin">mitre</CssParameter>
                            <CssParameter name="stroke-linecap">butt</CssParameter>
                        </Stroke>
                    </PolygonSymbolizer>
                </Rule>
                <Rule>
                    <Name>RoughnessCls1183482208039171</Name>
                    <Title>Kraut mit gro�en B�schen</Title>
                    <Abstract>Kraut mit gro�en B�schen</Abstract>
                    <ogc:Filter>
                        <ogc:PropertyIsLike escape="/" singleChar="$" wildCard="*">
                            <ogc:PropertyName>roughnessStyle</ogc:PropertyName>
                            <ogc:Literal>Kraut mit gro�en B�schen</ogc:Literal>
                        </ogc:PropertyIsLike>
                    </ogc:Filter>
<MinScaleDenominator>0.0</MinScaleDenominator>
                    <MaxScaleDenominator>1.7976931348623157E308</MaxScaleDenominator>
                    <PolygonSymbolizer uom="pixel">
                        <Fill>
                            <CssParameter name="fill">#ffaa55</CssParameter>
                            <CssParameter name="fill-opacity">0.75</CssParameter>
                        </Fill>
                        <Stroke>
                            <CssParameter name="stroke-width">1.0</CssParameter>
                            <CssParameter name="stroke-opacity">1.0</CssParameter>
                            <CssParameter name="stroke">#000000</CssParameter>
                            <CssParameter name="stroke-linejoin">mitre</CssParameter>
                            <CssParameter name="stroke-linecap">butt</CssParameter>
                        </Stroke>
                    </PolygonSymbolizer>
                </Rule>
                <Rule>
                    <Name>RoughnessCls117812307094971</Name>
                    <Title>Kraut mit kleinen Buschgruppen</Title>
                    <Abstract>Kraut mit kleinen Buschgruppen</Abstract>
                    <ogc:Filter>
                        <ogc:PropertyIsLike escape="/" singleChar="$" wildCard="*">
                            <ogc:PropertyName>roughnessStyle</ogc:PropertyName>
                            <ogc:Literal>Kraut mit kleinen Buschgruppen</ogc:Literal>
                        </ogc:PropertyIsLike>
                    </ogc:Filter>
<MinScaleDenominator>0.0</MinScaleDenominator>
                    <MaxScaleDenominator>1.7976931348623157E308</MaxScaleDenominator>
                    <PolygonSymbolizer uom="pixel">
                        <Fill>
                            <CssParameter name="fill">#ffc68c</CssParameter>
                            <CssParameter name="fill-opacity">0.75</CssParameter>
                        </Fill>
                        <Stroke>
                            <CssParameter name="stroke-width">1.0</CssParameter>
                            <CssParameter name="stroke-opacity">1.0</CssParameter>
                            <CssParameter name="stroke">#000000</CssParameter>
                            <CssParameter name="stroke-linejoin">mitre</CssParameter>
                            <CssParameter name="stroke-linecap">butt</CssParameter>
                        </Stroke>
                    </PolygonSymbolizer>
                </Rule>
                <Rule>
                    <Name>RoughnessCls117812307020841</Name>
                    <Title>Kraut mit kleinen B�schen</Title>
                    <Abstract>Kraut mit kleinen B�schen</Abstract>
                    <ogc:Filter>
                        <ogc:PropertyIsLike escape="/" singleChar="$" wildCard="*">
                            <ogc:PropertyName>roughnessStyle</ogc:PropertyName>
                            <ogc:Literal>Kraut mit kleinen B�schen</ogc:Literal>
                        </ogc:PropertyIsLike>
                    </ogc:Filter>
<MinScaleDenominator>0.0</MinScaleDenominator>
                    <MaxScaleDenominator>1.7976931348623157E308</MaxScaleDenominator>
                    <PolygonSymbolizer uom="pixel">
                        <Fill>
                            <CssParameter name="fill">#ffe6cc</CssParameter>
                            <CssParameter name="fill-opacity">0.75</CssParameter>
                        </Fill>
                        <Stroke>
                            <CssParameter name="stroke-width">1.0</CssParameter>
                            <CssParameter name="stroke-opacity">1.0</CssParameter>
                            <CssParameter name="stroke">#000000</CssParameter>
                            <CssParameter name="stroke-linejoin">mitre</CssParameter>
                            <CssParameter name="stroke-linecap">butt</CssParameter>
                        </Stroke>
                    </PolygonSymbolizer>
                </Rule>
                <Rule>
                    <Name>RoughnessCls1178123069356121</Name>
                    <Title>Kraut mit B�schen mit Kronenschluss</Title>
                    <Abstract>Kraut mit B�schen mit Kronenschluss</Abstract>
                    <ogc:Filter>
                        <ogc:PropertyIsLike escape="/" singleChar="$" wildCard="*">
                            <ogc:PropertyName>roughnessStyle</ogc:PropertyName>
                            <ogc:Literal>Kraut mit B�schen mit Kronenschluss</ogc:Literal>
                        </ogc:PropertyIsLike>
                    </ogc:Filter>
<MinScaleDenominator>0.0</MinScaleDenominator>
                    <MaxScaleDenominator>1.7976931348623157E308</MaxScaleDenominator>
                    <PolygonSymbolizer uom="pixel">
                        <Fill>
                            <CssParameter name="fill">#fefbc5</CssParameter>
                            <CssParameter name="fill-opacity">0.75</CssParameter>
                        </Fill>
                        <Stroke>
                            <CssParameter name="stroke-width">1.0</CssParameter>
                            <CssParameter name="stroke-opacity">1.0</CssParameter>
                            <CssParameter name="stroke">#000000</CssParameter>
                            <CssParameter name="stroke-linejoin">mitre</CssParameter>
                            <CssParameter name="stroke-linecap">butt</CssParameter>
                        </Stroke>
                    </PolygonSymbolizer>
                </Rule>
                <Rule>
                    <Name>RoughnessCls117812305739891</Name>
                    <Title>Kraut mit B�schen mittlerer Gr��e</Title>
                    <Abstract>Kraut mit B�schen mittlerer Gr��e</Abstract>
                    <ogc:Filter>
                        <ogc:PropertyIsLike escape="/" singleChar="$" wildCard="*">
                            <ogc:PropertyName>roughnessStyle</ogc:PropertyName>
                            <ogc:Literal>Kraut mit B�schen mittlerer Gr��e</ogc:Literal>
                        </ogc:PropertyIsLike>
                    </ogc:Filter>
<MinScaleDenominator>0.0</MinScaleDenominator>
                    <MaxScaleDenominator>1.7976931348623157E308</MaxScaleDenominator>
                    <PolygonSymbolizer uom="pixel">
                        <Fill>
                            <CssParameter name="fill">#fded80</CssParameter>
                            <CssParameter name="fill-opacity">0.75</CssParameter>
                        </Fill>
                        <Stroke>
                            <CssParameter name="stroke-width">1.0</CssParameter>
                            <CssParameter name="stroke-opacity">1.0</CssParameter>
                            <CssParameter name="stroke">#000000</CssParameter>
                            <CssParameter name="stroke-linejoin">mitre</CssParameter>
                            <CssParameter name="stroke-linecap">butt</CssParameter>
                        </Stroke>
                    </PolygonSymbolizer>
                </Rule>
                <Rule>
                    <Name>RoughnessCls117812305485411</Name>
                    <Title>Kraut mit mehrj�hrigem Baumbesatz</Title>
                    <Abstract>Kraut mit mehrj�hrigem Baumbesatz</Abstract>
                    <ogc:Filter>
                        <ogc:PropertyIsLike escape="/" singleChar="$" wildCard="*">
                            <ogc:PropertyName>roughnessStyle</ogc:PropertyName>
                            <ogc:Literal>Kraut mit mehrj�hrigem Baumbesatz</ogc:Literal>
                        </ogc:PropertyIsLike>
                    </ogc:Filter>
<MinScaleDenominator>0.0</MinScaleDenominator>
                    <MaxScaleDenominator>1.7976931348623157E308</MaxScaleDenominator>
                    <PolygonSymbolizer uom="pixel">
                        <Fill>
                            <CssParameter name="fill">#f4dd59</CssParameter>
                            <CssParameter name="fill-opacity">0.75</CssParameter>
                        </Fill>
                        <Stroke>
                            <CssParameter name="stroke-width">1.0</CssParameter>
                            <CssParameter name="stroke-opacity">1.0</CssParameter>
                            <CssParameter name="stroke">#000000</CssParameter>
                            <CssParameter name="stroke-linejoin">mitre</CssParameter>
                            <CssParameter name="stroke-linecap">butt</CssParameter>
                        </Stroke>
                    </PolygonSymbolizer>
                </Rule>
                <Rule>
                    <Name>RoughnessCls117812305579681</Name>
                    <Title>Kraut mit gro�en Buschgruppen</Title>
                    <Abstract>Kraut mit gro�en Buschgruppen</Abstract>
                    <ogc:Filter>
                        <ogc:PropertyIsLike escape="/" singleChar="$" wildCard="*">
                            <ogc:PropertyName>roughnessStyle</ogc:PropertyName>
                            <ogc:Literal>Kraut mit gro�en Buschgruppen</ogc:Literal>
                        </ogc:PropertyIsLike>
                    </ogc:Filter>
<MinScaleDenominator>0.0</MinScaleDenominator>
                    <MaxScaleDenominator>1.7976931348623157E308</MaxScaleDenominator>
                    <PolygonSymbolizer uom="pixel">
                        <Fill>
                            <CssParameter name="fill">#ffff00</CssParameter>
                            <CssParameter name="fill-opacity">0.75</CssParameter>
                        </Fill>
                        <Stroke>
                            <CssParameter name="stroke-width">1.0</CssParameter>
                            <CssParameter name="stroke-opacity">1.0</CssParameter>
                            <CssParameter name="stroke">#000000</CssParameter>
                            <CssParameter name="stroke-linejoin">mitre</CssParameter>
                            <CssParameter name="stroke-linecap">butt</CssParameter>
                        </Stroke>
                    </PolygonSymbolizer>
                </Rule>
                <Rule>
                    <Name>Labelle</Name>
                    <Title>Labelle</Title>
                    <Abstract>Labelle</Abstract>
                    <MinScaleDenominator>0.0</MinScaleDenominator>
                    <MaxScaleDenominator>10.0</MaxScaleDenominator>
                    <TextSymbolizer uom="pixel">
                        <Label>
                            <ogc:PropertyName>roughnessStyle</ogc:PropertyName>
                        </Label>
                        <Font>
                            <CssParameter name="font-family">Arial</CssParameter>
                            <CssParameter name="font-size">11.0</CssParameter>
                            <CssParameter name="font-weight">normal</CssParameter>
                            <CssParameter name="font-color">#000000</CssParameter>
                            <CssParameter name="font-style">normal</CssParameter>
                        </Font>
                        <LabelPlacement>
                            <PointPlacement auto="true">
                                <AnchorPoint>
                                    <AnchorPointX>0.5</AnchorPointX>
                                    <AnchorPointY>0.5</AnchorPointY>
                                </AnchorPoint>
                                <Rotation>0.0</Rotation>
                            </PointPlacement>
                        </LabelPlacement>
                        <Fill>
                            <CssParameter name="fill">#808080</CssParameter>
                            <CssParameter name="fill-opacity">1.0</CssParameter>
                        </Fill>
                    </TextSymbolizer>
                </Rule>
            </FeatureTypeStyle>
        </UserStyle>
    </NamedLayer>
</StyledLayerDescriptor>
