<?xml version="1.0" encoding="WINDOWS-1252"?>
<c1d2d:ControlModelGroup xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:gml="http://www.opengis.net/gml" xmlns:xs="http://www.w3.org/2001/XMLSchema-instance" xmlns:c1d2d="http://www.tu-harburg.de/wb/kalypso/schemata/1d2dControl" xmlns:swe="http://www.opengis.net/swe" xmlns:sweExt="org.kalypso.swe.ext" gml:id="root">
 <simBase:version xmlns:simBase="http://www.tu-harburg.de/wb/kalypso/schemata/simulationbase">1.0</simBase:version>
 <c1d2d:controlModelCollection>
  <c1d2d:ControlModelCollection gml:id="ControlModelCollection12125814299811">
   <c1d2d:activeModelID xlink:href="#ControlModel121446393945210"/>
   <c1d2d:controlModelMember>
    <c1d2d:ControlModel gml:id="ControlModel121446393945210">
     <gml:description>Demomodell f�r eine gekoppelte 1D/2D Berechnung/ Demo model to run coupled 1D/2D calculations.</gml:description>
     <wb1d2d:calculationUnit xmlns:wb1d2d="http://www.tu-harburg.de/wb/kalypso/schemata/1d2d" xlink:href="discretisation.gml#CalculationUnit1D2D12144639393734308"/>
     <c1d2d:Version>1_1_0_20081208</c1d2d:Version>
     <c1d2d:VEGETA>true</c1d2d:VEGETA>
     <c1d2d:BEIENT>true</c1d2d:BEIENT>
     <c1d2d:ICPU>2</c1d2d:ICPU>
     <c1d2d:BUFFSIZ>5000000</c1d2d:BUFFSIZ>
     <c1d2d:MFW>500</c1d2d:MFW>
     <c1d2d:PERCENT_CHECK/>
     <c1d2d:IDNOPT>-1</c1d2d:IDNOPT>
     <c1d2d:startsim/>
     <c1d2d:IEDSW>10</c1d2d:IEDSW>
     <c1d2d:TBFACT>0.2</c1d2d:TBFACT>
     <c1d2d:TBMIN>1.8</c1d2d:TBMIN>
     <c1d2d:_p_bottom/>
     <c1d2d:OMEGA>59.0</c1d2d:OMEGA>
     <c1d2d:ELEV/>
     <c1d2d:UNOM>0.5</c1d2d:UNOM>
     <c1d2d:UDIR/>
     <c1d2d:HMIN/>
     <c1d2d:DSET>0.09</c1d2d:DSET>
     <c1d2d:DSETD>0.1</c1d2d:DSETD>
     <c1d2d:_steady>true</c1d2d:_steady>
     <c1d2d:_unsteady>true</c1d2d:_unsteady>
     <c1d2d:NITI>35</c1d2d:NITI>
     <c1d2d:NITN>20</c1d2d:NITN>
     <c1d2d:CONV_1>0.01</c1d2d:CONV_1>
     <c1d2d:CONV_2>0.01</c1d2d:CONV_2>
     <c1d2d:CONV_3>0.01</c1d2d:CONV_3>
     <c1d2d:IDRPT>0</c1d2d:IDRPT>
     <c1d2d:DRFACT>0.05</c1d2d:DRFACT>
     <c1d2d:AC1>1.5</c1d2d:AC1>
     <c1d2d:AC2>0.67</c1d2d:AC2>
     <c1d2d:AC3>0.04</c1d2d:AC3>
     <c1d2d:_restart>true</c1d2d:_restart>
     <c1d2d:restartInfoMember>
      <c1d2d:RestartInfo gml:id="RestartInfo122249761179639">
       <c1d2d:calculationUnitID>CalculationUnit1D2D12144639393734308</c1d2d:calculationUnitID>
       <c1d2d:stepResultMetaID>StepResultMeta122249749529621</c1d2d:stepResultMetaID>
       <c1d2d:filePath>results/CalculationUnit1D2D12144639393734308/steady/results.zip!/results.gml</c1d2d:filePath>
      </c1d2d:RestartInfo>
     </c1d2d:restartInfoMember>
     <c1d2d:IACCYC>1</c1d2d:IACCYC>
     <c1d2d:FNAM3/>
     <c1d2d:_steadyBC>0.4</c1d2d:_steadyBC>
     <c1d2d:timestepsMember>
      <c1d2d:TimestepsObservation gml:id="TimestepsObservation121446393945215">
       <gml:name>Zeitschrittdefinition</gml:name>
       <om:resultDefinition xmlns:om="http://www.opengis.net/om">
        <sweExt:SortedRecordDefinition gml:id="SortedRecordDefinition122269478499419">
         <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:1d2d:timeserie:components#OrdinalNumber"/>
         <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:1d2d:timeserie:components#Time"/>
         <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:1d2d:timeserie:components#UnderRelaxationFactor"/>
         <sweExt:sortedComponent xlink:href="urn:ogc:gml:dict:kalypso:model:1d2d:timeserie:components#Time"/>
         <sweExt:ordinalNumberComponent xlink:href="urn:ogc:gml:dict:kalypso:model:1d2d:timeserie:components#OrdinalNumber"/>
        </sweExt:SortedRecordDefinition>
       </om:resultDefinition>
       <om:result xmlns:om="http://www.opengis.net/om"><![CDATA[1 2008-06-03T22%3A00%3A00.000Z 0.7
2 2008-06-03T23%3A00%3A00.000Z 0.7
3 2008-06-04T00%3A00%3A00.000Z 0.7
4 2008-06-04T01%3A00%3A00.000Z 0.7
5 2008-06-04T02%3A00%3A00.000Z 0.7
6 2008-06-04T03%3A00%3A00.000Z 0.7
7 2008-06-04T04%3A00%3A00.000Z 0.7
]]></om:result>
      </c1d2d:TimestepsObservation>
     </c1d2d:timestepsMember>
    </c1d2d:ControlModel>
   </c1d2d:controlModelMember>
   <c1d2d:controlModelMember>
    <c1d2d:ControlModel gml:id="ControlModel12143997993122">
     <wb1d2d:calculationUnit xmlns:wb1d2d="http://www.tu-harburg.de/wb/kalypso/schemata/1d2d" xlink:href="discretisation.gml#CalculationUnit2D121439979923417593"/>
     <c1d2d:Version>1_1_0_20081208</c1d2d:Version>
     <c1d2d:VEGETA>true</c1d2d:VEGETA>
     <c1d2d:BEIENT>true</c1d2d:BEIENT>
     <c1d2d:ICPU>2</c1d2d:ICPU>
     <c1d2d:BUFFSIZ>5000000</c1d2d:BUFFSIZ>
     <c1d2d:MFW>500</c1d2d:MFW>
     <c1d2d:PERCENT_CHECK/>
     <c1d2d:IDNOPT>-1</c1d2d:IDNOPT>
     <c1d2d:startsim/>
     <c1d2d:IEDSW>10</c1d2d:IEDSW>
     <c1d2d:TBFACT>0.2</c1d2d:TBFACT>
     <c1d2d:TBMIN>1.8</c1d2d:TBMIN>
     <c1d2d:_p_bottom/>
     <c1d2d:OMEGA>59.0</c1d2d:OMEGA>
     <c1d2d:ELEV>367.0</c1d2d:ELEV>
     <c1d2d:UNOM>0.5</c1d2d:UNOM>
     <c1d2d:UDIR/>
     <c1d2d:HMIN/>
     <c1d2d:DSET>0.09</c1d2d:DSET>
     <c1d2d:DSETD>0.1</c1d2d:DSETD>
     <c1d2d:_steady>true</c1d2d:_steady>
     <c1d2d:_unsteady>true</c1d2d:_unsteady>
     <c1d2d:NITI>50</c1d2d:NITI>
     <c1d2d:NITN>20</c1d2d:NITN>
     <c1d2d:CONV_1>0.05</c1d2d:CONV_1>
     <c1d2d:CONV_2>0.05</c1d2d:CONV_2>
     <c1d2d:CONV_3>0.01</c1d2d:CONV_3>
     <c1d2d:IDRPT>1</c1d2d:IDRPT>
     <c1d2d:DRFACT>0.05</c1d2d:DRFACT>
     <c1d2d:AC1>1.5</c1d2d:AC1>
     <c1d2d:AC2>0.67</c1d2d:AC2>
     <c1d2d:AC3>0.04</c1d2d:AC3>
     <c1d2d:_restart>true</c1d2d:_restart>
     <c1d2d:restartInfoMember>
      <c1d2d:RestartInfo gml:id="RestartInfo121447349925834">
       <c1d2d:calculationUnitID>CalculationUnit2D121439979923417593</c1d2d:calculationUnitID>
       <c1d2d:stepResultMetaID>StepResultMeta121440229167121</c1d2d:stepResultMetaID>
       <c1d2d:filePath>results/CalculationUnit2D121439979923417593/steady/results.gml</c1d2d:filePath>
      </c1d2d:RestartInfo>
     </c1d2d:restartInfoMember>
     <c1d2d:IACCYC>6</c1d2d:IACCYC>
     <c1d2d:FNAM3/>
     <c1d2d:_steadyBC>0.5</c1d2d:_steadyBC>
     <c1d2d:timestepsMember>
      <c1d2d:TimestepsObservation gml:id="TimestepsObservation12143997993124">
       <gml:name>Zeitschrittdefinition</gml:name>
       <om:resultDefinition xmlns:om="http://www.opengis.net/om">
        <sweExt:SortedRecordDefinition gml:id="SortedRecordDefinition122245239517134">
         <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:1d2d:timeserie:components#OrdinalNumber"/>
         <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:1d2d:timeserie:components#Time"/>
         <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:1d2d:timeserie:components#UnderRelaxationFactor"/>
         <sweExt:sortedComponent xlink:href="urn:ogc:gml:dict:kalypso:model:1d2d:timeserie:components#Time"/>
         <sweExt:ordinalNumberComponent xlink:href="urn:ogc:gml:dict:kalypso:model:1d2d:timeserie:components#OrdinalNumber"/>
        </sweExt:SortedRecordDefinition>
       </om:resultDefinition>
       <om:result xmlns:om="http://www.opengis.net/om"><![CDATA[1 2008-06-24T22%3A00%3A00.000Z 0.3
2 2008-06-24T23%3A00%3A00.000Z 0.7
3 2008-06-25T00%3A00%3A00.000Z 0.7
4 2008-06-25T01%3A00%3A00.000Z 0.7
5 2008-06-25T02%3A00%3A00.000Z 0.7
6 2008-06-25T03%3A00%3A00.000Z 0.7
]]></om:result>
      </c1d2d:TimestepsObservation>
     </c1d2d:timestepsMember>
    </c1d2d:ControlModel>
   </c1d2d:controlModelMember>
   <c1d2d:controlModelMember>
    <c1d2d:ControlModel gml:id="ControlModel12125830338111">
     <gml:description>Demomodell f�r eine gekoppelte 1D/2D Berechnung/ Demo model to run coupled 1D/2D calculations.</gml:description>
     <wb1d2d:calculationUnit xmlns:wb1d2d="http://www.tu-harburg.de/wb/kalypso/schemata/1d2d" xlink:href="discretisation.gml#CalculationUnit1D12125830336860"/>
     <c1d2d:Version>1_1_0_20081208</c1d2d:Version>
     <c1d2d:VEGETA>false</c1d2d:VEGETA>
     <c1d2d:BEIENT>false</c1d2d:BEIENT>
     <c1d2d:ICPU>2</c1d2d:ICPU>
     <c1d2d:BUFFSIZ>5000000</c1d2d:BUFFSIZ>
     <c1d2d:MFW>500</c1d2d:MFW>
     <c1d2d:PERCENT_CHECK/>
     <c1d2d:IDNOPT>-1</c1d2d:IDNOPT>
     <c1d2d:startsim/>
     <c1d2d:IEDSW>10</c1d2d:IEDSW>
     <c1d2d:TBFACT>0.2</c1d2d:TBFACT>
     <c1d2d:TBMIN>2.0</c1d2d:TBMIN>
     <c1d2d:_p_bottom/>
     <c1d2d:OMEGA>59.0</c1d2d:OMEGA>
     <c1d2d:ELEV/>
     <c1d2d:UNOM>0.5</c1d2d:UNOM>
     <c1d2d:UDIR/>
     <c1d2d:HMIN/>
     <c1d2d:DSET>0.01</c1d2d:DSET>
     <c1d2d:DSETD>0.02</c1d2d:DSETD>
     <c1d2d:_steady>true</c1d2d:_steady>
     <c1d2d:_unsteady>false</c1d2d:_unsteady>
     <c1d2d:NITI>35</c1d2d:NITI>
     <c1d2d:NITN>40</c1d2d:NITN>
     <c1d2d:CONV_1>0.01</c1d2d:CONV_1>
     <c1d2d:CONV_2>0.01</c1d2d:CONV_2>
     <c1d2d:CONV_3>0.0010</c1d2d:CONV_3>
     <c1d2d:IDRPT>0</c1d2d:IDRPT>
     <c1d2d:DRFACT>0.05</c1d2d:DRFACT>
     <c1d2d:AC1>1.5</c1d2d:AC1>
     <c1d2d:AC2>0.67</c1d2d:AC2>
     <c1d2d:AC3>0.04</c1d2d:AC3>
     <c1d2d:_restart>true</c1d2d:_restart>
     <c1d2d:restartInfoMember>
      <c1d2d:RestartInfo gml:id="RestartInfo12288247746389">
       <c1d2d:calculationUnitID>restart1dStationary1212583531082</c1d2d:calculationUnitID>
       <c1d2d:stepResultMetaID>StepResultMeta12127360649530</c1d2d:stepResultMetaID>
       <c1d2d:filePath>results/restart1dStationary1212583531082/250/results.gml</c1d2d:filePath>
      </c1d2d:RestartInfo>
     </c1d2d:restartInfoMember>
     <c1d2d:IACCYC>1</c1d2d:IACCYC>
     <c1d2d:FNAM3/>
     <c1d2d:_steadyBC>0.5</c1d2d:_steadyBC>
     <c1d2d:timestepsMember>
      <c1d2d:TimestepsObservation gml:id="TimestepsObservation12125830338730">
       <gml:name>Zeitschrittdefinition</gml:name>
       <om:resultDefinition xmlns:om="http://www.opengis.net/om">
        <sweExt:SortedRecordDefinition gml:id="SortedRecordDefinition122245239520312">
         <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:1d2d:timeserie:components#OrdinalNumber"/>
         <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:1d2d:timeserie:components#Time"/>
         <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:1d2d:timeserie:components#UnderRelaxationFactor"/>
         <sweExt:sortedComponent xlink:href="urn:ogc:gml:dict:kalypso:model:1d2d:timeserie:components#Time"/>
         <sweExt:ordinalNumberComponent xlink:href="urn:ogc:gml:dict:kalypso:model:1d2d:timeserie:components#OrdinalNumber"/>
        </sweExt:SortedRecordDefinition>
       </om:resultDefinition>
       <om:result xmlns:om="http://www.opengis.net/om"></om:result>
      </c1d2d:TimestepsObservation>
     </c1d2d:timestepsMember>
    </c1d2d:ControlModel>
   </c1d2d:controlModelMember>
  </c1d2d:ControlModelCollection>
 </c1d2d:controlModelCollection>
</c1d2d:ControlModelGroup>
