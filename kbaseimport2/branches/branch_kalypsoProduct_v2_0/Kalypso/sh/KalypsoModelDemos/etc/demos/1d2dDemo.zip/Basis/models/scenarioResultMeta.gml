<?xml version="1.0" encoding="WINDOWS-1252"?>
<resultMeta1d2d:ScenarioResultMeta xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:gml="http://www.opengis.net/gml" xmlns:xs="http://www.w3.org/2001/XMLSchema-instance" xmlns:resultMeta1d2d="http://www.tu-harburg.de/wb/kalypso/schemata/1d2dResultMeta" xmlns:commonShp="org.kalypso.gml.common" gml:id="root">
 <gml:name>Ergebnisse</gml:name>
 <resultMeta:path xmlns:resultMeta="http://www.tu-harburg.de/wb/kalypso/schemata/simulationbase/result/meta">results</resultMeta:path>
 <resultMeta:childMember xmlns:resultMeta="http://www.tu-harburg.de/wb/kalypso/schemata/simulationbase/result/meta">
  <resultMeta1d2d:CalculationUnitResultMeta gml:id="CalculationUnitResultMeta12125835310821">
   <gml:description>Ergebnisimporte aus dem WSPM-Projekt '1D-station�r: WSPMDemo'</gml:description>
   <gml:name>1D-station�r: WSPMDemo</gml:name>
   <resultMeta:path>restart1dStationary1212583531082</resultMeta:path>
   <resultMeta:childMember>
    <resultMeta1d2d:StepResultMeta gml:id="StepResultMeta12125835311292">
     <gml:description>Rechenvariante 'Rechnung 1'</gml:description>
     <gml:name>Rechnung 1</gml:name>
     <resultMeta:path>Rechnung 1</resultMeta:path>
     <resultMeta:childMember>
      <resultMeta1d2d:DocumentResultMeta gml:id="DocumentResultMeta12125835312231">
       <gml:description>WSPM-Ergebnis: &#13;
WSPMDemo - Rechnung 1</gml:description>
       <gml:name>vektoren</gml:name>
       <resultMeta:path>results.gml</resultMeta:path>
       <resultMeta1d2d:type>nodes</resultMeta1d2d:type>
       <resultMeta1d2d:minValue>0.051</resultMeta1d2d:minValue>
       <resultMeta1d2d:maxValue>0.717</resultMeta1d2d:maxValue>
      </resultMeta1d2d:DocumentResultMeta>
     </resultMeta:childMember>
     <resultMeta1d2d:stepTime/>
     <resultMeta1d2d:stepNumber/>
     <resultMeta1d2d:isRestart>true</resultMeta1d2d:isRestart>
     <resultMeta1d2d:type>steady</resultMeta1d2d:type>
    </resultMeta1d2d:StepResultMeta>
   </resultMeta:childMember>
   <resultMeta:childMember>
    <resultMeta1d2d:StepResultMeta gml:id="StepResultMeta12125847459334">
     <gml:description>Rechenvariante 'Rechnung 2'</gml:description>
     <gml:name>Rechnung 2</gml:name>
     <resultMeta:path>Rechnung 2</resultMeta:path>
     <resultMeta:childMember>
      <resultMeta1d2d:DocumentResultMeta gml:id="DocumentResultMeta12125847459339">
       <gml:description>WSPM-Ergebnis: &#13;
WSPMDemo - Rechnung 2</gml:description>
       <gml:name>vektoren</gml:name>
       <resultMeta:path>results.gml</resultMeta:path>
       <resultMeta1d2d:type>nodes</resultMeta1d2d:type>
       <resultMeta1d2d:minValue>0.282</resultMeta1d2d:minValue>
       <resultMeta1d2d:maxValue>1.796</resultMeta1d2d:maxValue>
      </resultMeta1d2d:DocumentResultMeta>
     </resultMeta:childMember>
     <resultMeta1d2d:stepTime/>
     <resultMeta1d2d:stepNumber/>
     <resultMeta1d2d:isRestart>true</resultMeta1d2d:isRestart>
     <resultMeta1d2d:type>steady</resultMeta1d2d:type>
    </resultMeta1d2d:StepResultMeta>
   </resultMeta:childMember>
   <resultMeta:childMember>
    <resultMeta1d2d:StepResultMeta gml:id="StepResultMeta12127360649530">
     <gml:description>Rechenvariante '250'</gml:description>
     <gml:name>250</gml:name>
     <resultMeta:path>250</resultMeta:path>
     <resultMeta:childMember>
      <resultMeta1d2d:DocumentResultMeta gml:id="DocumentResultMeta12127360650167">
       <gml:description>WSPM-Ergebnis: &#13;
WSPMDemo - 250</gml:description>
       <gml:name>vektoren</gml:name>
       <resultMeta:path>results.gml</resultMeta:path>
       <resultMeta1d2d:type>nodes</resultMeta1d2d:type>
       <resultMeta1d2d:minValue>0.262</resultMeta1d2d:minValue>
       <resultMeta1d2d:maxValue>1.573</resultMeta1d2d:maxValue>
      </resultMeta1d2d:DocumentResultMeta>
     </resultMeta:childMember>
     <resultMeta1d2d:stepTime/>
     <resultMeta1d2d:stepNumber/>
     <resultMeta1d2d:isRestart>true</resultMeta1d2d:isRestart>
     <resultMeta1d2d:type>steady</resultMeta1d2d:type>
    </resultMeta1d2d:StepResultMeta>
   </resultMeta:childMember>
   <resultMeta1d2d:simulationStartTime/>
   <resultMeta1d2d:simulationEndTime/>
   <resultMeta1d2d:calcUnitID>restart1dStationary1212583531082</resultMeta1d2d:calcUnitID>
  </resultMeta1d2d:CalculationUnitResultMeta>
 </resultMeta:childMember>
 <resultMeta:childMember xmlns:resultMeta="http://www.tu-harburg.de/wb/kalypso/schemata/simulationbase/result/meta">
  <resultMeta1d2d:CalculationUnitResultMeta gml:id="CalculationUnitResultMeta12125835502222">
   <gml:description></gml:description>
   <gml:name>Demo 1D</gml:name>
   <resultMeta:path>CalculationUnit1D12125830336860</resultMeta:path>
   <resultMeta:childMember>
    <resultMeta1d2d:DocumentResultMeta gml:id="DocumentResultMeta12288248269192">
     <gml:description>TIN der Modellh�hen</gml:description>
     <gml:name>Modellh�hen</gml:name>
     <resultMeta:path>model/Tin/tin_TERRAIN.zip!/tin_TERRAIN.gml</resultMeta:path>
     <resultMeta1d2d:type>tinTerrain</resultMeta1d2d:type>
     <resultMeta1d2d:minValue>356.958</resultMeta1d2d:minValue>
     <resultMeta1d2d:maxValue>362.984</resultMeta1d2d:maxValue>
    </resultMeta1d2d:DocumentResultMeta>
   </resultMeta:childMember>
   <resultMeta1d2d:simulationStartTime/>
   <resultMeta1d2d:simulationEndTime>2008-12-09T12:13:47.513Z</resultMeta1d2d:simulationEndTime>
   <resultMeta1d2d:calcUnitID>CalculationUnit1D12125830336860</resultMeta1d2d:calcUnitID>
  </resultMeta1d2d:CalculationUnitResultMeta>
 </resultMeta:childMember>
 <resultMeta:childMember xmlns:resultMeta="http://www.tu-harburg.de/wb/kalypso/schemata/simulationbase/result/meta">
  <resultMeta1d2d:CalculationUnitResultMeta gml:id="CalculationUnitResultMeta12143999679018">
   <gml:name>Demo 2D</gml:name>
   <resultMeta:path>CalculationUnit2D121439979923417593</resultMeta:path>
   <resultMeta:childMember>
    <resultMeta1d2d:DocumentResultMeta gml:id="DocumentResultMeta122882244245850">
     <gml:description>TIN der Modellh�hen</gml:description>
     <gml:name>Modellh�hen</gml:name>
     <resultMeta:path>model/Tin/tin_TERRAIN.zip!/tin_TERRAIN.gml</resultMeta:path>
     <resultMeta1d2d:type>tinTerrain</resultMeta1d2d:type>
     <resultMeta1d2d:minValue>359.256</resultMeta1d2d:minValue>
     <resultMeta1d2d:maxValue>377.769</resultMeta1d2d:maxValue>
    </resultMeta1d2d:DocumentResultMeta>
   </resultMeta:childMember>
   <resultMeta1d2d:simulationStartTime/>
   <resultMeta1d2d:simulationEndTime>2008-12-09T11:36:38.198Z</resultMeta1d2d:simulationEndTime>
   <resultMeta1d2d:calcUnitID>CalculationUnit2D121439979923417593</resultMeta1d2d:calcUnitID>
  </resultMeta1d2d:CalculationUnitResultMeta>
 </resultMeta:childMember>
 <resultMeta:childMember xmlns:resultMeta="http://www.tu-harburg.de/wb/kalypso/schemata/simulationbase/result/meta">
  <resultMeta1d2d:CalculationUnitResultMeta gml:id="CalculationUnitResultMeta12144642158727">
   <gml:description></gml:description>
   <gml:name>Demo 1D2D</gml:name>
   <resultMeta:path>CalculationUnit1D2D12144639393734308</resultMeta:path>
   <resultMeta:childMember>
    <resultMeta1d2d:StepResultMeta gml:id="StepResultMeta122246681056238">
     <resultMeta:path/>
     <resultMeta:childMember>
      <resultMeta1d2d:DocumentResultMeta gml:id="DocumentResultMeta1222466811125186">
       <gml:description>ASCII Ergebnisdatei(en) des RMA10 Rechenkerns</gml:description>
       <gml:name>RMA-Rohdaten</gml:name>
       <resultMeta:path>original.2d.zip</resultMeta:path>
       <resultMeta1d2d:type>coreDataZip</resultMeta1d2d:type>
      </resultMeta1d2d:DocumentResultMeta>
     </resultMeta:childMember>
     <resultMeta1d2d:stepTime/>
     <resultMeta1d2d:stepNumber/>
     <resultMeta1d2d:isRestart/>
     <resultMeta1d2d:type/>
    </resultMeta1d2d:StepResultMeta>
   </resultMeta:childMember>
   <resultMeta:childMember>
    <resultMeta1d2d:DocumentResultMeta gml:id="DocumentResultMeta1228825511793109">
     <gml:description>TIN der Modellh�hen</gml:description>
     <gml:name>Modellh�hen</gml:name>
     <resultMeta:path>model/Tin/tin_TERRAIN.zip!/tin_TERRAIN.gml</resultMeta:path>
     <resultMeta1d2d:type>tinTerrain</resultMeta1d2d:type>
     <resultMeta1d2d:minValue>356.958</resultMeta1d2d:minValue>
     <resultMeta1d2d:maxValue>377.769</resultMeta1d2d:maxValue>
    </resultMeta1d2d:DocumentResultMeta>
   </resultMeta:childMember>
   <resultMeta1d2d:simulationStartTime/>
   <resultMeta1d2d:simulationEndTime>2008-12-09T12:28:35.839Z</resultMeta1d2d:simulationEndTime>
   <resultMeta1d2d:calcUnitID>CalculationUnit1D2D12144639393734308</resultMeta1d2d:calcUnitID>
  </resultMeta1d2d:CalculationUnitResultMeta>
 </resultMeta:childMember>
</resultMeta1d2d:ScenarioResultMeta>
