<?xml version="1.0" encoding="UTF-8"?>
<commonShp:StatusCollection xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:gml="http://www.opengis.net/gml" xmlns:xs="http://www.w3.org/2001/XMLSchema-instance" xmlns:commonShp="org.kalypso.gml.common" gml:id="root">
 <commonShp:statusMember>
  <commonShp:Status gml:id="Status12288248192630">
   <gml:description>Start der Simulation</gml:description>
   <commonShp:time>2008-12-09T12:13:39.263Z</commonShp:time>
   <commonShp:severity>info</commonShp:severity>
   <commonShp:code>0</commonShp:code>
   <commonShp:plugin>org.kalypso.model1d2d</commonShp:plugin>
   <commonShp:exception>rO0ABXA=</commonShp:exception>
  </commonShp:Status>
 </commonShp:statusMember>
 <commonShp:statusMember>
  <commonShp:Status gml:id="Status12288248192782">
   <gml:description>Schreibe RMA·Kalypso-ASCII Dateien für FE-Simulation</gml:description>
   <commonShp:time>2008-12-09T12:13:39.278Z</commonShp:time>
   <commonShp:severity>info</commonShp:severity>
   <commonShp:code>1</commonShp:code>
   <commonShp:plugin>org.kalypso.model1d2d</commonShp:plugin>
   <commonShp:exception>rO0ABXA=</commonShp:exception>
  </commonShp:Status>
 </commonShp:statusMember>
 <commonShp:statusMember>
  <commonShp:Status gml:id="Status12288248192781">
   <gml:description>Restart-Daten werden gelesen</gml:description>
   <commonShp:time>2008-12-09T12:13:39.278Z</commonShp:time>
   <commonShp:severity>info</commonShp:severity>
   <commonShp:code>1</commonShp:code>
   <commonShp:plugin>org.kalypso.model1d2d</commonShp:plugin>
   <commonShp:exception>rO0ABXA=</commonShp:exception>
  </commonShp:Status>
 </commonShp:statusMember>
 <commonShp:statusMember>
  <commonShp:Status gml:id="Status12288248193254">
   <gml:description>Schreibe Finite Elemente Netz</gml:description>
   <commonShp:time>2008-12-09T12:13:39.325Z</commonShp:time>
   <commonShp:severity>info</commonShp:severity>
   <commonShp:code>1</commonShp:code>
   <commonShp:plugin>org.kalypso.model1d2d</commonShp:plugin>
   <commonShp:exception>rO0ABXA=</commonShp:exception>
  </commonShp:Status>
 </commonShp:statusMember>
 <commonShp:statusMember>
  <commonShp:Status gml:id="Status12288248194502">
   <gml:description>Schreibe Randbedingungen und Berechnungssteuerung</gml:description>
   <commonShp:time>2008-12-09T12:13:39.450Z</commonShp:time>
   <commonShp:severity>info</commonShp:severity>
   <commonShp:code>1</commonShp:code>
   <commonShp:plugin>org.kalypso.model1d2d</commonShp:plugin>
   <commonShp:exception>rO0ABXA=</commonShp:exception>
  </commonShp:Status>
 </commonShp:statusMember>
 <commonShp:statusMember>
  <commonShp:Status gml:id="Status12288248194974">
   <gml:description>Schreibe Bauwerke</gml:description>
   <commonShp:time>2008-12-09T12:13:39.497Z</commonShp:time>
   <commonShp:severity>info</commonShp:severity>
   <commonShp:code>1</commonShp:code>
   <commonShp:plugin>org.kalypso.model1d2d</commonShp:plugin>
   <commonShp:exception>rO0ABXA=</commonShp:exception>
  </commonShp:Status>
 </commonShp:statusMember>
 <commonShp:statusMember>
  <commonShp:Status gml:id="Status12288248194972">
   <gml:description>Schreibe W/Q-Randbedingungen</gml:description>
   <commonShp:time>2008-12-09T12:13:39.497Z</commonShp:time>
   <commonShp:severity>info</commonShp:severity>
   <commonShp:code>1</commonShp:code>
   <commonShp:plugin>org.kalypso.model1d2d</commonShp:plugin>
   <commonShp:exception>rO0ABXA=</commonShp:exception>
  </commonShp:Status>
 </commonShp:statusMember>
 <commonShp:statusMember>
  <commonShp:Status gml:id="Status12288248195134">
   <gml:description>RMA·Kalypso wird ausgeführt: D:\Kalypso_2_1_RC1\bin\rma-kalypso_1_1_0_20081208.exe</gml:description>
   <commonShp:time>2008-12-09T12:13:39.513Z</commonShp:time>
   <commonShp:severity>info</commonShp:severity>
   <commonShp:code>1</commonShp:code>
   <commonShp:plugin>org.kalypso.model1d2d</commonShp:plugin>
   <commonShp:exception>rO0ABXA=</commonShp:exception>
  </commonShp:Status>
 </commonShp:statusMember>
 <commonShp:statusMember>
  <commonShp:Status gml:id="Status12288248231537">
   <gml:description>Simulation erfolgreich beendet</gml:description>
   <commonShp:time>2008-12-09T12:13:43.153Z</commonShp:time>
   <commonShp:severity>ok</commonShp:severity>
   <commonShp:code>0</commonShp:code>
   <commonShp:plugin>org.kalypso.model1d2d</commonShp:plugin>
   <commonShp:exception>rO0ABXA=</commonShp:exception>
  </commonShp:Status>
 </commonShp:statusMember>
 <commonShp:statusMember>
  <commonShp:Status gml:id="Status12288248250914">
   <gml:description>Start der Ergebnisauswertung</gml:description>
   <commonShp:time>2008-12-09T12:13:45.091Z</commonShp:time>
   <commonShp:severity>info</commonShp:severity>
   <commonShp:code>0</commonShp:code>
   <commonShp:plugin>org.kalypso.model1d2d</commonShp:plugin>
   <commonShp:exception>rO0ABXA=</commonShp:exception>
  </commonShp:Status>
 </commonShp:statusMember>
 <commonShp:statusMember>
  <commonShp:Status gml:id="Status12288248250918">
   <gml:description>Bestehende Ergebnisse werden gelöscht.</gml:description>
   <commonShp:time>2008-12-09T12:13:45.091Z</commonShp:time>
   <commonShp:severity>info</commonShp:severity>
   <commonShp:code>1</commonShp:code>
   <commonShp:plugin>org.kalypso.model1d2d</commonShp:plugin>
   <commonShp:exception>rO0ABXA=</commonShp:exception>
  </commonShp:Status>
 </commonShp:statusMember>
 <commonShp:statusMember>
  <commonShp:Status gml:id="Status12288248251382">
   <gml:description>Ergebnisauswertung - steady</gml:description>
   <commonShp:time>2008-12-09T12:13:45.138Z</commonShp:time>
   <commonShp:severity>info</commonShp:severity>
   <commonShp:code>1</commonShp:code>
   <commonShp:plugin>org.kalypso.model1d2d</commonShp:plugin>
   <commonShp:exception>rO0ABXA=</commonShp:exception>
  </commonShp:Status>
 </commonShp:statusMember>
 <commonShp:statusMember>
  <commonShp:Status gml:id="Status122882482751311">
   <gml:description>Alle Ergebnisse wurden erfolgreich ausgewertet.</gml:description>
   <commonShp:time>2008-12-09T12:13:47.513Z</commonShp:time>
   <commonShp:severity>ok</commonShp:severity>
   <commonShp:code>3000</commonShp:code>
   <commonShp:plugin>org.kalypso.model1d2d</commonShp:plugin>
   <commonShp:exception>rO0ABXA=</commonShp:exception>
  </commonShp:Status>
 </commonShp:statusMember>
 <commonShp:statusMember>
  <commonShp:Status gml:id="Status12288248275133">
   <gml:description>Ergebnisse werden in Arbeitsbereich verschoben und Ergebnisdatenbank aktualisiert.</gml:description>
   <commonShp:time>2008-12-09T12:13:47.513Z</commonShp:time>
   <commonShp:severity>info</commonShp:severity>
   <commonShp:code>1</commonShp:code>
   <commonShp:plugin>org.kalypso.model1d2d</commonShp:plugin>
   <commonShp:exception>rO0ABXA=</commonShp:exception>
  </commonShp:Status>
 </commonShp:statusMember>
 <commonShp:statusMember>
  <commonShp:Status gml:id="Status12288248275448">
   <gml:description>Ergebnisauswertung erfolgreich beendet</gml:description>
   <commonShp:time>2008-12-09T12:13:47.544Z</commonShp:time>
   <commonShp:severity>ok</commonShp:severity>
   <commonShp:code>0</commonShp:code>
   <commonShp:plugin>org.kalypso.model1d2d</commonShp:plugin>
   <commonShp:exception>rO0ABXA=</commonShp:exception>
  </commonShp:Status>
 </commonShp:statusMember>
</commonShp:StatusCollection>
