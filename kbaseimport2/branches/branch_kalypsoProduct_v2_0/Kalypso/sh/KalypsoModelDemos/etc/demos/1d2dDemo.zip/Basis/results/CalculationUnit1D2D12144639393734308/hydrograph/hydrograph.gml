<?xml version="1.0" encoding="WINDOWS-1252"?>
<res1d2d:HydrographCollection xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:gml="http://www.opengis.net/gml" xmlns:xs="http://www.w3.org/2001/XMLSchema-instance" xmlns:res1d2d="http://www.tu-harburg.de/wb/kalypso/schemata/1d2dResults" xmlns:swe="http://www.opengis.net/swe" xmlns:sweExt="org.kalypso.swe.ext" gml:id="root">
 <gml:name>Demo 1D2D</gml:name>
 <res1d2d:hydrographMember>
  <res1d2d:Hydrograph gml:id="Hydrograph122254314982820">
   <gml:description>Ganglinienpunkt f�r Teilmodell</gml:description>
   <gml:name>Ganglinienpunkt</gml:name>
   <gml:location>
    <gml:Point xmlns:ns6="http://www.w3.org/2001/SMIL20/" xmlns:st="http://www.seegrid.csiro.au/xml/st" xmlns:ns1="http://www.isotc211.org/2005/gmd" xmlns:ns7="http://www.isotc211.org/2005/gco" xmlns:ns8="http://www.isotc211.org/2005/gss" xmlns:ns9="http://www.isotc211.org/2005/gts" xmlns:ns10="http://www.isotc211.org/2005/gsr" xmlns:ns11="http://www.w3.org/2001/SMIL20/Language" srsName="EPSG:31467">
     <gml:coordinates ts="," decimal="." cs=" ">3931330.728 777535.229 362.399</gml:coordinates>
    </gml:Point>
   </gml:location>
   <om:resultDefinition xmlns:om="http://www.opengis.net/om">
    <sweExt:SortedRecordDefinition gml:id="SortedRecordDefinition122254331278132">
     <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:1d2d:timeserie:components#Time"/>
     <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:1d2d:timeserie:components#Waterlevel"/>
     <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:1d2d:timeserie:components#Depth"/>
     <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:1d2d:timeserie:components#Velocity"/>
     <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:1d2d:timeserie:components#Discharge"/>
     <sweExt:sortedComponent xlink:href="urn:ogc:gml:dict:kalypso:model:1d2d:timeserie:components#Time"/>
    </sweExt:SortedRecordDefinition>
   </om:resultDefinition>
   <om:result xmlns:om="http://www.opengis.net/om"><![CDATA[2008-06-04T01%3A00%3A00.000%2B02%3A00 367.1028 4.7038 0.5257 255.6880
2008-06-04T06%3A00%3A00.000%2B02%3A00 367.1223 4.7233 0.5370 262.7310
2008-06-04T11%3A00%3A00.000%2B02%3A00 367.1549 4.7559 0.5444 268.9770
2008-06-04T16%3A00%3A00.000%2B02%3A00 367.1921 4.7931 0.5500 274.7780
2008-06-04T21%3A00%3A00.000%2B02%3A00 367.3506 4.9516 0.5934 310.5020
2008-06-05T02%3A00%3A00.000%2B02%3A00 367.4049 5.0059 0.5989 318.2690
2008-06-05T07%3A00%3A00.000%2B02%3A00 367.4741 5.0751 0.6127 332.0020
2008-06-05T12%3A00%3A00.000%2B02%3A00 367.5718 5.1728 0.6508 362.2940
2008-06-05T17%3A00%3A00.000%2B02%3A00 367.6909 5.2919 0.6727 386.7190
2008-06-05T22%3A00%3A00.000%2B02%3A00 367.7711 5.3721 0.6934 407.1590
2008-06-06T03%3A00%3A00.000%2B02%3A00 367.8440 5.4450 0.7081 423.7510
2008-06-06T08%3A00%3A00.000%2B02%3A00 367.9000 5.5010 0.7257 440.5720
2008-06-06T13%3A00%3A00.000%2B02%3A00 367.9450 5.5460 0.7251 445.2700
2008-06-06T18%3A00%3A00.000%2B02%3A00 367.9080 5.5090 0.7097 431.7390
2008-06-06T23%3A00%3A00.000%2B02%3A00 367.8292 5.4302 0.6855 408.6590
2008-06-07T04%3A00%3A00.000%2B02%3A00 367.7911 5.3921 0.6753 398.6100
2008-06-07T09%3A00%3A00.000%2B02%3A00 367.7324 5.3334 0.6646 386.2930
2008-06-07T14%3A00%3A00.000%2B02%3A00 367.6550 5.2560 0.6339 360.9310
2008-06-07T19%3A00%3A00.000%2B02%3A00 367.5553 5.1563 0.6175 342.2070
2008-06-08T00%3A00%3A00.000%2B02%3A00 367.4998 5.1008 0.6083 331.9850
2008-06-08T05%3A00%3A00.000%2B02%3A00 367.4471 5.0481 0.5887 316.5950
2008-06-08T10%3A00%3A00.000%2B02%3A00 367.3810 4.9820 0.5777 304.9250
2008-06-08T15%3A00%3A00.000%2B02%3A00 367.3298 4.9308 0.5691 296.0110
2008-06-08T20%3A00%3A00.000%2B02%3A00 367.2806 4.8816 0.5568 285.5150
2008-06-09T01%3A00%3A00.000%2B02%3A00 367.2136 4.8146 0.5443 273.6690
2008-06-09T06%3A00%3A00.000%2B02%3A00 367.1529 4.7539 0.5340 263.6800
2008-06-09T11%3A00%3A00.000%2B02%3A00 367.0869 4.6879 0.5199 251.6480
2008-06-09T16%3A00%3A00.000%2B02%3A00 367.0276 4.6286 0.5078 241.3620
2008-06-09T21%3A00%3A00.000%2B02%3A00 366.9414 4.5424 0.4979 230.3780
2008-06-10T00%3A00%3A00.000%2B02%3A00 366.9121 4.5131 0.4904 224.8150
]]></om:result>
  </res1d2d:Hydrograph>
 </res1d2d:hydrographMember>
 <res1d2d:hydrographMember>
  <res1d2d:Hydrograph gml:id="Hydrograph122254315079627">
   <gml:description>Ganglinienpunkt f�r Teilmodell</gml:description>
   <gml:name>Ganglinienpunkt</gml:name>
   <gml:location>
    <gml:Point xmlns:ns6="http://www.w3.org/2001/SMIL20/" xmlns:st="http://www.seegrid.csiro.au/xml/st" xmlns:ns1="http://www.isotc211.org/2005/gmd" xmlns:ns7="http://www.isotc211.org/2005/gco" xmlns:ns8="http://www.isotc211.org/2005/gss" xmlns:ns9="http://www.isotc211.org/2005/gts" xmlns:ns10="http://www.isotc211.org/2005/gsr" xmlns:ns11="http://www.w3.org/2001/SMIL20/Language" srsName="EPSG:31467">
     <gml:coordinates ts="," decimal="." cs=" ">3930630.518 776986.725 358.194</gml:coordinates>
    </gml:Point>
   </gml:location>
   <om:resultDefinition xmlns:om="http://www.opengis.net/om">
    <sweExt:SortedRecordDefinition gml:id="SortedRecordDefinition122254331278127">
     <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:1d2d:timeserie:components#Time"/>
     <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:1d2d:timeserie:components#Waterlevel"/>
     <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:1d2d:timeserie:components#Depth"/>
     <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:1d2d:timeserie:components#Velocity"/>
     <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:1d2d:timeserie:components#Discharge"/>
     <sweExt:sortedComponent xlink:href="urn:ogc:gml:dict:kalypso:model:1d2d:timeserie:components#Time"/>
    </sweExt:SortedRecordDefinition>
   </om:resultDefinition>
   <om:result xmlns:om="http://www.opengis.net/om"><![CDATA[2008-06-04T01%3A00%3A00.000%2B02%3A00 367.0839 8.8899 0.2984 254.5680
2008-06-04T06%3A00%3A00.000%2B02%3A00 367.1028 8.9088 0.3067 262.5070
2008-06-04T11%3A00%3A00.000%2B02%3A00 367.1349 8.9409 0.3118 268.3560
2008-06-04T16%3A00%3A00.000%2B02%3A00 367.1720 8.9780 0.3169 274.4900
2008-06-04T21%3A00%3A00.000%2B02%3A00 367.3279 9.1339 0.3474 308.9750
2008-06-05T02%3A00%3A00.000%2B02%3A00 367.3821 9.1881 0.3531 316.9070
2008-06-05T07%3A00%3A00.000%2B02%3A00 367.4504 9.2564 0.3652 331.5060
2008-06-05T12%3A00%3A00.000%2B02%3A00 367.5457 9.3517 0.3901 359.6990
2008-06-05T17%3A00%3A00.000%2B02%3A00 367.6635 9.4695 0.4107 385.9980
2008-06-05T22%3A00%3A00.000%2B02%3A00 367.7424 9.5484 0.4263 405.7570
2008-06-06T03%3A00%3A00.000%2B02%3A00 367.8144 9.6204 0.4396 423.2260
2008-06-06T08%3A00%3A00.000%2B02%3A00 367.8692 9.6752 0.4532 440.1020
2008-06-06T13%3A00%3A00.000%2B02%3A00 367.9145 9.7205 0.4560 445.9730
2008-06-06T18%3A00%3A00.000%2B02%3A00 367.8785 9.6845 0.4440 431.7980
2008-06-06T23%3A00%3A00.000%2B02%3A00 367.8012 9.6072 0.4257 408.9890
2008-06-07T04%3A00%3A00.000%2B02%3A00 367.7639 9.5699 0.4182 399.4120
2008-06-07T09%3A00%3A00.000%2B02%3A00 367.7055 9.5115 0.4086 386.6230
2008-06-07T14%3A00%3A00.000%2B02%3A00 367.6301 9.4361 0.3874 362.1430
2008-06-07T19%3A00%3A00.000%2B02%3A00 367.5312 9.3372 0.3728 342.9330
2008-06-08T00%3A00%3A00.000%2B02%3A00 367.4761 9.2821 0.3645 332.2770
2008-06-08T05%3A00%3A00.000%2B02%3A00 367.4246 9.2306 0.3521 318.2520
2008-06-08T10%3A00%3A00.000%2B02%3A00 367.3590 9.1650 0.3417 305.4940
2008-06-08T15%3A00%3A00.000%2B02%3A00 367.3083 9.1143 0.3349 296.8780
2008-06-08T20%3A00%3A00.000%2B02%3A00 367.2596 9.0656 0.3257 286.3560
2008-06-09T01%3A00%3A00.000%2B02%3A00 367.1932 8.9992 0.3161 274.7920
2008-06-09T06%3A00%3A00.000%2B02%3A00 367.1329 8.9389 0.3071 264.2190
2008-06-09T11%3A00%3A00.000%2B02%3A00 367.0677 8.8737 0.2964 252.1520
2008-06-09T16%3A00%3A00.000%2B02%3A00 367.0091 8.8151 0.2872 241.8390
2008-06-09T21%3A00%3A00.000%2B02%3A00 366.9229 8.7289 0.2784 230.8940
2008-06-10T00%3A00%3A00.000%2B02%3A00 366.8942 8.7002 0.2734 225.5930
]]></om:result>
  </res1d2d:Hydrograph>
 </res1d2d:hydrographMember>
 <res1d2d:hydrographMember>
  <res1d2d:Hydrograph gml:id="Hydrograph122254315225010">
   <gml:description>Ganglinienpunkt f�r Teilmodell</gml:description>
   <gml:name>Ganglinienpunkt</gml:name>
   <gml:location>
    <gml:Point xmlns:ns6="http://www.w3.org/2001/SMIL20/" xmlns:st="http://www.seegrid.csiro.au/xml/st" xmlns:ns1="http://www.isotc211.org/2005/gmd" xmlns:ns7="http://www.isotc211.org/2005/gco" xmlns:ns8="http://www.isotc211.org/2005/gss" xmlns:ns9="http://www.isotc211.org/2005/gts" xmlns:ns10="http://www.isotc211.org/2005/gsr" xmlns:ns11="http://www.w3.org/2001/SMIL20/Language" srsName="EPSG:31467">
     <gml:coordinates ts="," decimal="." cs=" ">3930234.182 776097.545 360.251</gml:coordinates>
    </gml:Point>
   </gml:location>
   <om:resultDefinition xmlns:om="http://www.opengis.net/om">
    <sweExt:SortedRecordDefinition gml:id="SortedRecordDefinition122254331279656">
     <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:1d2d:timeserie:components#Time"/>
     <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:1d2d:timeserie:components#Waterlevel"/>
     <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:1d2d:timeserie:components#Depth"/>
     <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:1d2d:timeserie:components#Velocity"/>
     <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:1d2d:timeserie:components#Discharge"/>
     <sweExt:sortedComponent xlink:href="urn:ogc:gml:dict:kalypso:model:1d2d:timeserie:components#Time"/>
    </sweExt:SortedRecordDefinition>
   </om:resultDefinition>
   <om:result xmlns:om="http://www.opengis.net/om"><![CDATA[2008-06-04T01%3A00%3A00.000%2B02%3A00 367.0510 6.8000 0.5352 254.8000
2008-06-04T06%3A00%3A00.000%2B02%3A00 367.0685 6.8175 0.5484 262.5860
2008-06-04T11%3A00%3A00.000%2B02%3A00 367.0998 6.8488 0.5550 268.4670
2008-06-04T16%3A00%3A00.000%2B02%3A00 367.1366 6.8856 0.5600 274.1190
2008-06-04T21%3A00%3A00.000%2B02%3A00 367.2877 7.0367 0.6003 308.1350
2008-06-05T02%3A00%3A00.000%2B02%3A00 367.3412 7.0902 0.6069 316.6610
2008-06-05T07%3A00%3A00.000%2B02%3A00 367.4079 7.1569 0.6219 331.0670
2008-06-05T12%3A00%3A00.000%2B02%3A00 367.4987 7.2477 0.6556 358.4810
2008-06-05T17%3A00%3A00.000%2B02%3A00 367.6137 7.3627 0.6815 385.1660
2008-06-05T22%3A00%3A00.000%2B02%3A00 367.6898 7.4388 0.7023 405.4940
2008-06-06T03%3A00%3A00.000%2B02%3A00 367.7598 7.5088 0.7184 422.8780
2008-06-06T08%3A00%3A00.000%2B02%3A00 367.8124 7.5614 0.7356 439.2400
2008-06-06T13%3A00%3A00.000%2B02%3A00 367.8578 7.6068 0.7375 445.7820
2008-06-06T18%3A00%3A00.000%2B02%3A00 367.8240 7.5730 0.7212 431.9920
2008-06-06T23%3A00%3A00.000%2B02%3A00 367.7498 7.4988 0.6974 409.3940
2008-06-07T04%3A00%3A00.000%2B02%3A00 367.7140 7.4630 0.6875 399.6220
2008-06-07T09%3A00%3A00.000%2B02%3A00 367.6568 7.4058 0.6761 386.7850
2008-06-07T14%3A00%3A00.000%2B02%3A00 367.5847 7.3337 0.6500 364.3460
2008-06-07T19%3A00%3A00.000%2B02%3A00 367.4881 7.2371 0.6305 343.6910
2008-06-08T00%3A00%3A00.000%2B02%3A00 367.4343 7.1833 0.6196 332.4420
2008-06-08T05%3A00%3A00.000%2B02%3A00 367.3849 7.1339 0.6038 319.2270
2008-06-08T10%3A00%3A00.000%2B02%3A00 367.3208 7.0698 0.5897 305.7820
2008-06-08T15%3A00%3A00.000%2B02%3A00 367.2710 7.0200 0.5813 296.8490
2008-06-08T20%3A00%3A00.000%2B02%3A00 367.2235 6.9725 0.5706 287.1090
2008-06-09T01%3A00%3A00.000%2B02%3A00 367.1586 6.9076 0.5582 275.1670
2008-06-09T06%3A00%3A00.000%2B02%3A00 367.0993 6.8483 0.5473 264.7000
2008-06-09T11%3A00%3A00.000%2B02%3A00 367.0359 6.7849 0.5325 252.2570
2008-06-09T16%3A00%3A00.000%2B02%3A00 366.9784 6.7274 0.5216 242.4110
2008-06-09T21%3A00%3A00.000%2B02%3A00 366.8930 6.6420 0.5128 231.5070
2008-06-10T00%3A00%3A00.000%2B02%3A00 366.8654 6.6144 0.5040 225.3760
]]></om:result>
  </res1d2d:Hydrograph>
 </res1d2d:hydrographMember>
 <res1d2d:hydrographMember>
  <res1d2d:Hydrograph gml:id="Hydrograph122254315429624">
   <gml:description>Ganglinienpunkt f�r Teilmodell</gml:description>
   <gml:name>Ganglinienpunkt</gml:name>
   <gml:location>
    <gml:Point xmlns:ns6="http://www.w3.org/2001/SMIL20/" xmlns:st="http://www.seegrid.csiro.au/xml/st" xmlns:ns1="http://www.isotc211.org/2005/gmd" xmlns:ns7="http://www.isotc211.org/2005/gco" xmlns:ns8="http://www.isotc211.org/2005/gss" xmlns:ns9="http://www.isotc211.org/2005/gts" xmlns:ns10="http://www.isotc211.org/2005/gsr" xmlns:ns11="http://www.w3.org/2001/SMIL20/Language" srsName="EPSG:31467">
     <gml:coordinates ts="," decimal="." cs=" ">3929912.625 775317.063 365.5290945</gml:coordinates>
    </gml:Point>
   </gml:location>
   <om:resultDefinition xmlns:om="http://www.opengis.net/om">
    <sweExt:SortedRecordDefinition gml:id="SortedRecordDefinition122254331279646">
     <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:1d2d:timeserie:components#Time"/>
     <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:1d2d:timeserie:components#Waterlevel"/>
     <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:1d2d:timeserie:components#Depth"/>
     <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:1d2d:timeserie:components#Velocity"/>
     <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:1d2d:timeserie:components#Discharge"/>
     <sweExt:sortedComponent xlink:href="urn:ogc:gml:dict:kalypso:model:1d2d:timeserie:components#Time"/>
    </sweExt:SortedRecordDefinition>
   </om:resultDefinition>
   <om:result xmlns:om="http://www.opengis.net/om"><![CDATA[2008-06-04T01%3A00%3A00.000%2B02%3A00 366.9993 1.4702 0.6333 0.0000
2008-06-04T06%3A00%3A00.000%2B02%3A00 367.0141 1.4850 0.6533 0.0000
2008-06-04T11%3A00%3A00.000%2B02%3A00 367.0460 1.5169 0.6583 0.0000
2008-06-04T16%3A00%3A00.000%2B02%3A00 367.0784 1.5494 0.6660 0.0000
2008-06-04T21%3A00%3A00.000%2B02%3A00 367.2219 1.6928 0.7112 0.0000
2008-06-05T02%3A00%3A00.000%2B02%3A00 367.2753 1.7462 0.7161 0.0000
2008-06-05T07%3A00%3A00.000%2B02%3A00 367.3400 1.8109 0.7330 0.0000
2008-06-05T12%3A00%3A00.000%2B02%3A00 367.4242 1.8951 0.7732 0.0000
2008-06-05T17%3A00%3A00.000%2B02%3A00 367.5359 2.0068 0.8021 0.0000
2008-06-05T22%3A00%3A00.000%2B02%3A00 367.6085 2.0794 0.8270 0.0000
2008-06-06T03%3A00%3A00.000%2B02%3A00 367.6764 2.1473 0.8447 0.0000
2008-06-06T08%3A00%3A00.000%2B02%3A00 367.7263 2.1972 0.8652 0.0000
2008-06-06T13%3A00%3A00.000%2B02%3A00 367.7721 2.2430 0.8663 0.0000
2008-06-06T18%3A00%3A00.000%2B02%3A00 367.7396 2.2105 0.8441 0.0000
2008-06-06T23%3A00%3A00.000%2B02%3A00 367.6725 2.1434 0.8123 0.0000
2008-06-07T04%3A00%3A00.000%2B02%3A00 367.6335 2.1044 0.8057 0.0000
2008-06-07T09%3A00%3A00.000%2B02%3A00 367.5823 2.0532 0.7889 0.0000
2008-06-07T14%3A00%3A00.000%2B02%3A00 367.5141 1.9850 0.7608 0.0000
2008-06-07T19%3A00%3A00.000%2B02%3A00 367.4207 1.8916 0.7379 0.0000
2008-06-08T00%3A00%3A00.000%2B02%3A00 367.3681 1.8390 0.7264 0.0000
2008-06-08T05%3A00%3A00.000%2B02%3A00 367.3210 1.7919 0.7097 0.0000
2008-06-08T10%3A00%3A00.000%2B02%3A00 367.2593 1.7302 0.6923 0.0000
2008-06-08T15%3A00%3A00.000%2B02%3A00 367.2101 1.6810 0.6850 0.0000
2008-06-08T20%3A00%3A00.000%2B02%3A00 367.1638 1.6347 0.6752 0.0000
2008-06-09T01%3A00%3A00.000%2B02%3A00 367.1013 1.5722 0.6629 0.0000
2008-06-09T06%3A00%3A00.000%2B02%3A00 367.0431 1.5140 0.6525 0.0000
2008-06-09T11%3A00%3A00.000%2B02%3A00 366.9767 1.4476 0.6410 0.0000
2008-06-09T16%3A00%3A00.000%2B02%3A00 366.9161 1.3870 0.6326 0.0000
2008-06-09T21%3A00%3A00.000%2B02%3A00 366.8405 1.3114 0.6188 0.0000
2008-06-10T00%3A00%3A00.000%2B02%3A00 366.8066 1.2775 0.6157 0.0000
]]></om:result>
  </res1d2d:Hydrograph>
 </res1d2d:hydrographMember>
 <res1d2d:hydrographMember>
  <res1d2d:Hydrograph gml:id="Hydrograph122254315551546">
   <gml:description>Ganglinienpunkt f�r Teilmodell</gml:description>
   <gml:name>Ganglinienpunkt</gml:name>
   <gml:location>
    <gml:Point xmlns:ns6="http://www.w3.org/2001/SMIL20/" xmlns:st="http://www.seegrid.csiro.au/xml/st" xmlns:ns1="http://www.isotc211.org/2005/gmd" xmlns:ns7="http://www.isotc211.org/2005/gco" xmlns:ns8="http://www.isotc211.org/2005/gss" xmlns:ns9="http://www.isotc211.org/2005/gts" xmlns:ns10="http://www.isotc211.org/2005/gsr" xmlns:ns11="http://www.w3.org/2001/SMIL20/Language" srsName="EPSG:31467">
     <gml:coordinates ts="," decimal="." cs=" ">3929863.875 774964.625 365.1994875</gml:coordinates>
    </gml:Point>
   </gml:location>
   <om:resultDefinition xmlns:om="http://www.opengis.net/om">
    <sweExt:SortedRecordDefinition gml:id="SortedRecordDefinition122254331279652">
     <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:1d2d:timeserie:components#Time"/>
     <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:1d2d:timeserie:components#Waterlevel"/>
     <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:1d2d:timeserie:components#Depth"/>
     <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:1d2d:timeserie:components#Velocity"/>
     <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:1d2d:timeserie:components#Discharge"/>
     <sweExt:sortedComponent xlink:href="urn:ogc:gml:dict:kalypso:model:1d2d:timeserie:components#Time"/>
    </sweExt:SortedRecordDefinition>
   </om:resultDefinition>
   <om:result xmlns:om="http://www.opengis.net/om"><![CDATA[2008-06-04T01%3A00%3A00.000%2B02%3A00 366.9657 1.7662 0.4749 0.0000
2008-06-04T06%3A00%3A00.000%2B02%3A00 366.9791 1.7796 0.4912 0.0000
2008-06-04T11%3A00%3A00.000%2B02%3A00 367.0110 1.8115 0.4974 0.0000
2008-06-04T16%3A00%3A00.000%2B02%3A00 367.0433 1.8438 0.5070 0.0000
2008-06-04T21%3A00%3A00.000%2B02%3A00 367.1846 1.9851 0.5494 0.0000
2008-06-05T02%3A00%3A00.000%2B02%3A00 367.2385 2.0390 0.5581 0.0000
2008-06-05T07%3A00%3A00.000%2B02%3A00 367.3029 2.1034 0.5751 0.0000
2008-06-05T12%3A00%3A00.000%2B02%3A00 367.3851 2.1856 0.6059 0.0000
2008-06-05T17%3A00%3A00.000%2B02%3A00 367.4964 2.2969 0.6322 0.0000
2008-06-05T22%3A00%3A00.000%2B02%3A00 367.5683 2.3688 0.6547 0.0000
2008-06-06T03%3A00%3A00.000%2B02%3A00 367.6364 2.4369 0.6687 0.0000
2008-06-06T08%3A00%3A00.000%2B02%3A00 367.6858 2.4863 0.6849 0.0000
2008-06-06T13%3A00%3A00.000%2B02%3A00 367.7325 2.5331 0.6865 0.0000
2008-06-06T18%3A00%3A00.000%2B02%3A00 367.7007 2.5012 0.6707 0.0000
2008-06-06T23%3A00%3A00.000%2B02%3A00 367.6345 2.4350 0.6465 0.0000
2008-06-07T04%3A00%3A00.000%2B02%3A00 367.5952 2.3957 0.6414 0.0000
2008-06-07T09%3A00%3A00.000%2B02%3A00 367.5442 2.3448 0.6276 0.0000
2008-06-07T14%3A00%3A00.000%2B02%3A00 367.4769 2.2775 0.6046 0.0000
2008-06-07T19%3A00%3A00.000%2B02%3A00 367.3835 2.1840 0.5840 0.0000
2008-06-08T00%3A00%3A00.000%2B02%3A00 367.3313 2.1318 0.5702 0.0000
2008-06-08T05%3A00%3A00.000%2B02%3A00 367.2852 2.0858 0.5564 0.0000
2008-06-08T10%3A00%3A00.000%2B02%3A00 367.2242 2.0248 0.5412 0.0000
2008-06-08T15%3A00%3A00.000%2B02%3A00 367.1749 1.9754 0.5314 0.0000
2008-06-08T20%3A00%3A00.000%2B02%3A00 367.1287 1.9292 0.5204 0.0000
2008-06-09T01%3A00%3A00.000%2B02%3A00 367.0666 1.8672 0.5076 0.0000
2008-06-09T06%3A00%3A00.000%2B02%3A00 367.0085 1.8090 0.4946 0.0000
2008-06-09T11%3A00%3A00.000%2B02%3A00 366.9422 1.7427 0.4796 0.0000
2008-06-09T16%3A00%3A00.000%2B02%3A00 366.8815 1.6820 0.4675 0.0000
2008-06-09T21%3A00%3A00.000%2B02%3A00 366.8061 1.6066 0.4482 0.0000
2008-06-10T00%3A00%3A00.000%2B02%3A00 366.7720 1.5725 0.4416 0.0000
]]></om:result>
  </res1d2d:Hydrograph>
 </res1d2d:hydrographMember>
 <res1d2d:hydrographMember>
  <res1d2d:Hydrograph gml:id="Hydrograph122254315667147">
   <gml:description>Ganglinienpunkt f�r Teilmodell</gml:description>
   <gml:name>Ganglinienpunkt</gml:name>
   <gml:location>
    <gml:Point xmlns:ns6="http://www.w3.org/2001/SMIL20/" xmlns:st="http://www.seegrid.csiro.au/xml/st" xmlns:ns1="http://www.isotc211.org/2005/gmd" xmlns:ns7="http://www.isotc211.org/2005/gco" xmlns:ns8="http://www.isotc211.org/2005/gss" xmlns:ns9="http://www.isotc211.org/2005/gts" xmlns:ns10="http://www.isotc211.org/2005/gsr" xmlns:ns11="http://www.w3.org/2001/SMIL20/Language" srsName="EPSG:31467">
     <gml:coordinates ts="," decimal="." cs=" ">3929785.625 774548.625 364.4798735</gml:coordinates>
    </gml:Point>
   </gml:location>
   <om:resultDefinition xmlns:om="http://www.opengis.net/om">
    <sweExt:SortedRecordDefinition gml:id="SortedRecordDefinition122254331279633">
     <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:1d2d:timeserie:components#Time"/>
     <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:1d2d:timeserie:components#Waterlevel"/>
     <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:1d2d:timeserie:components#Depth"/>
     <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:1d2d:timeserie:components#Velocity"/>
     <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:1d2d:timeserie:components#Discharge"/>
     <sweExt:sortedComponent xlink:href="urn:ogc:gml:dict:kalypso:model:1d2d:timeserie:components#Time"/>
    </sweExt:SortedRecordDefinition>
   </om:resultDefinition>
   <om:result xmlns:om="http://www.opengis.net/om"><![CDATA[2008-06-04T01%3A00%3A00.000%2B02%3A00 366.9203 2.4404 0.5852 0.0000
2008-06-04T06%3A00%3A00.000%2B02%3A00 366.9315 2.4517 0.6025 0.0000
2008-06-04T11%3A00%3A00.000%2B02%3A00 366.9642 2.4843 0.6016 0.0000
2008-06-04T16%3A00%3A00.000%2B02%3A00 366.9964 2.5165 0.6073 0.0000
2008-06-04T21%3A00%3A00.000%2B02%3A00 367.1372 2.6574 0.6256 0.0000
2008-06-05T02%3A00%3A00.000%2B02%3A00 367.1927 2.7128 0.6210 0.0000
2008-06-05T07%3A00%3A00.000%2B02%3A00 367.2574 2.7775 0.6265 0.0000
2008-06-05T12%3A00%3A00.000%2B02%3A00 367.3392 2.8593 0.6362 0.0000
2008-06-05T17%3A00%3A00.000%2B02%3A00 367.4517 2.9718 0.6397 0.0000
2008-06-05T22%3A00%3A00.000%2B02%3A00 367.5239 3.0440 0.6447 0.0000
2008-06-06T03%3A00%3A00.000%2B02%3A00 367.5934 3.1135 0.6399 0.0000
2008-06-06T08%3A00%3A00.000%2B02%3A00 367.6430 3.1631 0.6420 0.0000
2008-06-06T13%3A00%3A00.000%2B02%3A00 367.6916 3.2117 0.6323 0.0000
2008-06-06T18%3A00%3A00.000%2B02%3A00 367.6602 3.1803 0.6256 0.0000
2008-06-06T23%3A00%3A00.000%2B02%3A00 367.5941 3.1143 0.6189 0.0000
2008-06-07T04%3A00%3A00.000%2B02%3A00 367.5538 3.0739 0.6237 0.0000
2008-06-07T09%3A00%3A00.000%2B02%3A00 367.5025 3.0226 0.6222 0.0000
2008-06-07T14%3A00%3A00.000%2B02%3A00 367.4350 2.9551 0.6163 0.0000
2008-06-07T19%3A00%3A00.000%2B02%3A00 367.3408 2.8610 0.6158 0.0000
2008-06-08T00%3A00%3A00.000%2B02%3A00 367.2876 2.8077 0.6170 0.0000
2008-06-08T05%3A00%3A00.000%2B02%3A00 367.2413 2.7615 0.6123 0.0000
2008-06-08T10%3A00%3A00.000%2B02%3A00 367.1801 2.7003 0.6081 0.0000
2008-06-08T15%3A00%3A00.000%2B02%3A00 367.1300 2.6501 0.6079 0.0000
2008-06-08T20%3A00%3A00.000%2B02%3A00 367.0830 2.6031 0.6080 0.0000
2008-06-09T01%3A00%3A00.000%2B02%3A00 367.0200 2.5401 0.6072 0.0000
2008-06-09T06%3A00%3A00.000%2B02%3A00 366.9612 2.4813 0.6044 0.0000
2008-06-09T11%3A00%3A00.000%2B02%3A00 366.8943 2.4144 0.6004 0.0000
2008-06-09T16%3A00%3A00.000%2B02%3A00 366.8328 2.3530 0.5994 0.0000
2008-06-09T21%3A00%3A00.000%2B02%3A00 366.7567 2.2768 0.5949 0.0000
2008-06-10T00%3A00%3A00.000%2B02%3A00 366.7219 2.2420 0.5952 0.0000
]]></om:result>
  </res1d2d:Hydrograph>
 </res1d2d:hydrographMember>
 <res1d2d:hydrographMember>
  <res1d2d:Hydrograph gml:id="Hydrograph122254315785943">
   <gml:description>Ganglinienpunkt f�r Teilmodell</gml:description>
   <gml:name>Ganglinienpunkt</gml:name>
   <gml:location>
    <gml:Point xmlns:ns6="http://www.w3.org/2001/SMIL20/" xmlns:st="http://www.seegrid.csiro.au/xml/st" xmlns:ns1="http://www.isotc211.org/2005/gmd" xmlns:ns7="http://www.isotc211.org/2005/gco" xmlns:ns8="http://www.isotc211.org/2005/gss" xmlns:ns9="http://www.isotc211.org/2005/gts" xmlns:ns10="http://www.isotc211.org/2005/gsr" xmlns:ns11="http://www.w3.org/2001/SMIL20/Language" srsName="EPSG:31467">
     <gml:coordinates ts="," decimal="." cs=" ">3929841.875 774230.688 365.8745802</gml:coordinates>
    </gml:Point>
   </gml:location>
   <om:resultDefinition xmlns:om="http://www.opengis.net/om">
    <sweExt:SortedRecordDefinition gml:id="SortedRecordDefinition122254331281281">
     <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:1d2d:timeserie:components#Time"/>
     <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:1d2d:timeserie:components#Waterlevel"/>
     <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:1d2d:timeserie:components#Depth"/>
     <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:1d2d:timeserie:components#Velocity"/>
     <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:1d2d:timeserie:components#Discharge"/>
     <sweExt:sortedComponent xlink:href="urn:ogc:gml:dict:kalypso:model:1d2d:timeserie:components#Time"/>
    </sweExt:SortedRecordDefinition>
   </om:resultDefinition>
   <om:result xmlns:om="http://www.opengis.net/om"><![CDATA[2008-06-04T01%3A00%3A00.000%2B02%3A00 366.8993 1.0247 0.0656 0.0000
2008-06-04T06%3A00%3A00.000%2B02%3A00 366.9096 1.0350 0.0688 0.0000
2008-06-04T11%3A00%3A00.000%2B02%3A00 366.9428 1.0682 0.0711 0.0000
2008-06-04T16%3A00%3A00.000%2B02%3A00 366.9752 1.1006 0.0756 0.0000
2008-06-04T21%3A00%3A00.000%2B02%3A00 367.1167 1.2421 0.0937 0.0000
2008-06-05T02%3A00%3A00.000%2B02%3A00 367.1730 1.2984 0.1062 0.0000
2008-06-05T07%3A00%3A00.000%2B02%3A00 367.2382 1.3637 0.1147 0.0000
2008-06-05T12%3A00%3A00.000%2B02%3A00 367.3203 1.4457 0.1352 0.0000
2008-06-05T17%3A00%3A00.000%2B02%3A00 367.4335 1.5589 0.1561 0.0000
2008-06-05T22%3A00%3A00.000%2B02%3A00 367.5059 1.6313 0.1704 0.0000
2008-06-06T03%3A00%3A00.000%2B02%3A00 367.5760 1.7014 0.1844 0.0000
2008-06-06T08%3A00%3A00.000%2B02%3A00 367.6256 1.7510 0.1964 0.0000
2008-06-06T13%3A00%3A00.000%2B02%3A00 367.6750 1.8004 0.2015 0.0000
2008-06-06T18%3A00%3A00.000%2B02%3A00 367.6436 1.7691 0.1946 0.0000
2008-06-06T23%3A00%3A00.000%2B02%3A00 367.5776 1.7030 0.1813 0.0000
2008-06-07T04%3A00%3A00.000%2B02%3A00 367.5368 1.6623 0.1763 0.0000
2008-06-07T09%3A00%3A00.000%2B02%3A00 367.4853 1.6108 0.1669 0.0000
2008-06-07T14%3A00%3A00.000%2B02%3A00 367.4177 1.5431 0.1550 0.0000
2008-06-07T19%3A00%3A00.000%2B02%3A00 367.3230 1.4484 0.1380 0.0000
2008-06-08T00%3A00%3A00.000%2B02%3A00 367.2693 1.3947 0.1280 0.0000
2008-06-08T05%3A00%3A00.000%2B02%3A00 367.2228 1.3482 0.1209 0.0000
2008-06-08T10%3A00%3A00.000%2B02%3A00 367.1612 1.2867 0.1055 0.0000
2008-06-08T15%3A00%3A00.000%2B02%3A00 367.1105 1.2360 0.0987 0.0000
2008-06-08T20%3A00%3A00.000%2B02%3A00 367.0629 1.1884 0.0912 0.0000
2008-06-09T01%3A00%3A00.000%2B02%3A00 366.9992 1.1246 0.0801 0.0000
2008-06-09T06%3A00%3A00.000%2B02%3A00 366.9397 1.0651 0.0741 0.0000
2008-06-09T11%3A00%3A00.000%2B02%3A00 366.8720 0.9974 0.0670 0.0000
2008-06-09T16%3A00%3A00.000%2B02%3A00 366.8095 0.9349 0.0615 0.0000
2008-06-09T21%3A00%3A00.000%2B02%3A00 366.7320 0.8574 0.0539 0.0000
2008-06-10T00%3A00%3A00.000%2B02%3A00 366.6964 0.8219 0.0479 0.0000
]]></om:result>
  </res1d2d:Hydrograph>
 </res1d2d:hydrographMember>
 <res1d2d:hydrographMember>
  <res1d2d:Hydrograph gml:id="Hydrograph122254315965644">
   <gml:description>Ganglinienpunkt f�r Teilmodell</gml:description>
   <gml:name>Ganglinienpunkt</gml:name>
   <gml:location>
    <gml:Point xmlns:ns6="http://www.w3.org/2001/SMIL20/" xmlns:st="http://www.seegrid.csiro.au/xml/st" xmlns:ns1="http://www.isotc211.org/2005/gmd" xmlns:ns7="http://www.isotc211.org/2005/gco" xmlns:ns8="http://www.isotc211.org/2005/gss" xmlns:ns9="http://www.isotc211.org/2005/gts" xmlns:ns10="http://www.isotc211.org/2005/gsr" xmlns:ns11="http://www.w3.org/2001/SMIL20/Language" srsName="EPSG:31467">
     <gml:coordinates ts="," decimal="." cs=" ">3929482.625 774285.375 365.843128</gml:coordinates>
    </gml:Point>
   </gml:location>
   <om:resultDefinition xmlns:om="http://www.opengis.net/om">
    <sweExt:SortedRecordDefinition gml:id="SortedRecordDefinition122254331281234">
     <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:1d2d:timeserie:components#Time"/>
     <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:1d2d:timeserie:components#Waterlevel"/>
     <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:1d2d:timeserie:components#Depth"/>
     <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:1d2d:timeserie:components#Velocity"/>
     <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:1d2d:timeserie:components#Discharge"/>
     <sweExt:sortedComponent xlink:href="urn:ogc:gml:dict:kalypso:model:1d2d:timeserie:components#Time"/>
    </sweExt:SortedRecordDefinition>
   </om:resultDefinition>
   <om:result xmlns:om="http://www.opengis.net/om"><![CDATA[2008-06-04T01%3A00%3A00.000%2B02%3A00 366.8615 1.0184 0.3866 0.0000
2008-06-04T06%3A00%3A00.000%2B02%3A00 366.8702 1.0271 0.3985 0.0000
2008-06-04T11%3A00%3A00.000%2B02%3A00 366.9050 1.0618 0.3983 0.0000
2008-06-04T16%3A00%3A00.000%2B02%3A00 366.9376 1.0945 0.4049 0.0000
2008-06-04T21%3A00%3A00.000%2B02%3A00 367.0811 1.2380 0.4263 0.0000
2008-06-05T02%3A00%3A00.000%2B02%3A00 367.1386 1.2955 0.4299 0.0000
2008-06-05T07%3A00%3A00.000%2B02%3A00 367.2045 1.3614 0.4392 0.0000
2008-06-05T12%3A00%3A00.000%2B02%3A00 367.2865 1.4433 0.4555 0.0000
2008-06-05T17%3A00%3A00.000%2B02%3A00 367.4001 1.5569 0.4739 0.0000
2008-06-05T22%3A00%3A00.000%2B02%3A00 367.4722 1.6291 0.4889 0.0000
2008-06-06T03%3A00%3A00.000%2B02%3A00 367.5428 1.6997 0.4966 0.0000
2008-06-06T08%3A00%3A00.000%2B02%3A00 367.5921 1.7490 0.5074 0.0000
2008-06-06T13%3A00%3A00.000%2B02%3A00 367.6427 1.7995 0.5058 0.0000
2008-06-06T18%3A00%3A00.000%2B02%3A00 367.6117 1.7686 0.4968 0.0000
2008-06-06T23%3A00%3A00.000%2B02%3A00 367.5461 1.7030 0.4826 0.0000
2008-06-07T04%3A00%3A00.000%2B02%3A00 367.5047 1.6616 0.4811 0.0000
2008-06-07T09%3A00%3A00.000%2B02%3A00 367.4529 1.6098 0.4742 0.0000
2008-06-07T14%3A00%3A00.000%2B02%3A00 367.3854 1.5423 0.4611 0.0000
2008-06-07T19%3A00%3A00.000%2B02%3A00 367.2904 1.4472 0.4468 0.0000
2008-06-08T00%3A00%3A00.000%2B02%3A00 367.2359 1.3928 0.4413 0.0000
2008-06-08T05%3A00%3A00.000%2B02%3A00 367.1892 1.3460 0.4342 0.0000
2008-06-08T10%3A00%3A00.000%2B02%3A00 367.1275 1.2844 0.4226 0.0000
2008-06-08T15%3A00%3A00.000%2B02%3A00 367.0759 1.2328 0.4178 0.0000
2008-06-08T20%3A00%3A00.000%2B02%3A00 367.0272 1.1841 0.4144 0.0000
2008-06-09T01%3A00%3A00.000%2B02%3A00 366.9621 1.1189 0.4089 0.0000
2008-06-09T06%3A00%3A00.000%2B02%3A00 366.9008 1.0577 0.4037 0.0000
2008-06-09T11%3A00%3A00.000%2B02%3A00 366.8307 0.9876 0.3987 0.0000
2008-06-09T16%3A00%3A00.000%2B02%3A00 366.7651 0.9219 0.3972 0.0000
2008-06-09T21%3A00%3A00.000%2B02%3A00 366.6831 0.8400 0.3927 0.0000
2008-06-10T00%3A00%3A00.000%2B02%3A00 366.6451 0.8019 0.3921 0.0000
]]></om:result>
  </res1d2d:Hydrograph>
 </res1d2d:hydrographMember>
 <res1d2d:hydrographMember>
  <res1d2d:Hydrograph gml:id="Hydrograph122254316132858">
   <gml:description>Ganglinienpunkt f�r Teilmodell</gml:description>
   <gml:name>Ganglinienpunkt</gml:name>
   <gml:location>
    <gml:Point xmlns:ns6="http://www.w3.org/2001/SMIL20/" xmlns:st="http://www.seegrid.csiro.au/xml/st" xmlns:ns1="http://www.isotc211.org/2005/gmd" xmlns:ns7="http://www.isotc211.org/2005/gco" xmlns:ns8="http://www.isotc211.org/2005/gss" xmlns:ns9="http://www.isotc211.org/2005/gts" xmlns:ns10="http://www.isotc211.org/2005/gsr" xmlns:ns11="http://www.w3.org/2001/SMIL20/Language" srsName="EPSG:31467">
     <gml:coordinates ts="," decimal="." cs=" ">3929212.125 774308.813 366.481056</gml:coordinates>
    </gml:Point>
   </gml:location>
   <om:resultDefinition xmlns:om="http://www.opengis.net/om">
    <sweExt:SortedRecordDefinition gml:id="SortedRecordDefinition122254331281295">
     <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:1d2d:timeserie:components#Time"/>
     <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:1d2d:timeserie:components#Waterlevel"/>
     <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:1d2d:timeserie:components#Depth"/>
     <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:1d2d:timeserie:components#Velocity"/>
     <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:1d2d:timeserie:components#Discharge"/>
     <sweExt:sortedComponent xlink:href="urn:ogc:gml:dict:kalypso:model:1d2d:timeserie:components#Time"/>
    </sweExt:SortedRecordDefinition>
   </om:resultDefinition>
   <om:result xmlns:om="http://www.opengis.net/om"><![CDATA[2008-06-04T01%3A00%3A00.000%2B02%3A00 366.8278 0.3467 0.5449 0.0000
2008-06-04T06%3A00%3A00.000%2B02%3A00 366.8336 0.3525 0.5634 0.0000
2008-06-04T11%3A00%3A00.000%2B02%3A00 366.8697 0.3886 0.5694 0.0000
2008-06-04T16%3A00%3A00.000%2B02%3A00 366.9032 0.4221 0.5846 0.0000
2008-06-04T21%3A00%3A00.000%2B02%3A00 367.0483 0.5672 0.6327 0.0000
2008-06-05T02%3A00%3A00.000%2B02%3A00 367.1075 0.6265 0.6391 0.0000
2008-06-05T07%3A00%3A00.000%2B02%3A00 367.1742 0.6932 0.6535 0.0000
2008-06-05T12%3A00%3A00.000%2B02%3A00 367.2564 0.7753 0.6721 0.0000
2008-06-05T17%3A00%3A00.000%2B02%3A00 367.3715 0.8904 0.6718 0.0000
2008-06-05T22%3A00%3A00.000%2B02%3A00 367.4439 0.9629 0.6758 0.0000
2008-06-06T03%3A00%3A00.000%2B02%3A00 367.5160 1.0349 0.6639 0.0000
2008-06-06T08%3A00%3A00.000%2B02%3A00 367.5657 1.0846 0.6606 0.0000
2008-06-06T13%3A00%3A00.000%2B02%3A00 367.6187 1.1376 0.6359 0.0000
2008-06-06T18%3A00%3A00.000%2B02%3A00 367.5877 1.1066 0.6353 0.0000
2008-06-06T23%3A00%3A00.000%2B02%3A00 367.5215 1.0404 0.6398 0.0000
2008-06-07T04%3A00%3A00.000%2B02%3A00 367.4789 0.9979 0.6512 0.0000
2008-06-07T09%3A00%3A00.000%2B02%3A00 367.4260 0.9449 0.6597 0.0000
2008-06-07T14%3A00%3A00.000%2B02%3A00 367.3581 0.8771 0.6551 0.0000
2008-06-07T19%3A00%3A00.000%2B02%3A00 367.2626 0.7815 0.6483 0.0000
2008-06-08T00%3A00%3A00.000%2B02%3A00 367.2067 0.7256 0.6504 0.0000
2008-06-08T05%3A00%3A00.000%2B02%3A00 367.1595 0.6784 0.6433 0.0000
2008-06-08T10%3A00%3A00.000%2B02%3A00 367.0977 0.6166 0.6274 0.0000
2008-06-08T15%3A00%3A00.000%2B02%3A00 367.0451 0.5640 0.6166 0.0000
2008-06-08T20%3A00%3A00.000%2B02%3A00 366.9948 0.5138 0.6099 0.0000
2008-06-09T01%3A00%3A00.000%2B02%3A00 366.9281 0.4471 0.5938 0.0000
2008-06-09T06%3A00%3A00.000%2B02%3A00 366.8651 0.3840 0.5767 0.0000
2008-06-09T11%3A00%3A00.000%2B02%3A00 366.7948 0.3137 0.5568 0.0000
2008-06-09T16%3A00%3A00.000%2B02%3A00 366.7289 0.2478 0.5408 0.0000
2008-06-09T21%3A00%3A00.000%2B02%3A00 366.6388 0.1577 0.5191 0.0000
2008-06-10T00%3A00%3A00.000%2B02%3A00 366.6041 0.1230 0.5095 0.0000
]]></om:result>
  </res1d2d:Hydrograph>
 </res1d2d:hydrographMember>
 <res1d2d:hydrographMember>
  <res1d2d:Hydrograph gml:id="Hydrograph122254316260925">
   <gml:description>Ganglinienpunkt f�r Teilmodell</gml:description>
   <gml:name>Ganglinienpunkt</gml:name>
   <gml:location>
    <gml:Point xmlns:ns6="http://www.w3.org/2001/SMIL20/" xmlns:st="http://www.seegrid.csiro.au/xml/st" xmlns:ns1="http://www.isotc211.org/2005/gmd" xmlns:ns7="http://www.isotc211.org/2005/gco" xmlns:ns8="http://www.isotc211.org/2005/gss" xmlns:ns9="http://www.isotc211.org/2005/gts" xmlns:ns10="http://www.isotc211.org/2005/gsr" xmlns:ns11="http://www.w3.org/2001/SMIL20/Language" srsName="EPSG:31467">
     <gml:coordinates ts="," decimal="." cs=" ">3929182.0 774046.25 367.1322973</gml:coordinates>
    </gml:Point>
   </gml:location>
   <om:resultDefinition xmlns:om="http://www.opengis.net/om">
    <sweExt:SortedRecordDefinition gml:id="SortedRecordDefinition1222543312812115">
     <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:1d2d:timeserie:components#Time"/>
     <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:1d2d:timeserie:components#Waterlevel"/>
     <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:1d2d:timeserie:components#Depth"/>
     <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:1d2d:timeserie:components#Velocity"/>
     <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:1d2d:timeserie:components#Discharge"/>
     <sweExt:sortedComponent xlink:href="urn:ogc:gml:dict:kalypso:model:1d2d:timeserie:components#Time"/>
    </sweExt:SortedRecordDefinition>
   </om:resultDefinition>
   <om:result xmlns:om="http://www.opengis.net/om"><![CDATA[2008-06-04T01%3A00%3A00.000%2B02%3A00 365.1156 0.0000 0.0000 0.0000
2008-06-04T06%3A00%3A00.000%2B02%3A00 365.1156 0.0000 0.0000 0.0000
2008-06-04T11%3A00%3A00.000%2B02%3A00 365.1156 0.0000 0.0000 0.0000
2008-06-04T16%3A00%3A00.000%2B02%3A00 365.1156 0.0000 0.0000 0.0000
2008-06-04T21%3A00%3A00.000%2B02%3A00 365.1156 0.0000 0.0000 0.0000
2008-06-05T02%3A00%3A00.000%2B02%3A00 365.1156 0.0000 0.0000 0.0000
2008-06-05T07%3A00%3A00.000%2B02%3A00 365.1156 0.0000 0.0000 0.0000
2008-06-05T12%3A00%3A00.000%2B02%3A00 367.1437 0.0114 0.1223 0.0000
2008-06-05T17%3A00%3A00.000%2B02%3A00 367.2306 0.0983 0.3450 0.0000
2008-06-05T22%3A00%3A00.000%2B02%3A00 367.2967 0.1645 0.3837 0.0000
2008-06-06T03%3A00%3A00.000%2B02%3A00 367.3684 0.2361 0.4228 0.0000
2008-06-06T08%3A00%3A00.000%2B02%3A00 367.4164 0.2841 0.4566 0.0000
2008-06-06T13%3A00%3A00.000%2B02%3A00 367.4759 0.3436 0.4801 0.0000
2008-06-06T18%3A00%3A00.000%2B02%3A00 367.4473 0.3150 0.4589 0.0000
2008-06-06T23%3A00%3A00.000%2B02%3A00 367.3834 0.2511 0.4151 0.0000
2008-06-07T04%3A00%3A00.000%2B02%3A00 367.3404 0.2081 0.3973 0.0000
2008-06-07T09%3A00%3A00.000%2B02%3A00 367.2858 0.1535 0.3649 0.0000
2008-06-07T14%3A00%3A00.000%2B02%3A00 367.2236 0.0913 0.3244 0.0000
2008-06-07T19%3A00%3A00.000%2B02%3A00 367.1376 0.0053 0.2710 0.0000
2008-06-08T00%3A00%3A00.000%2B02%3A00 367.2186 0.0863 0.1222 0.0000
2008-06-08T05%3A00%3A00.000%2B02%3A00 367.0393 0.0000 0.0000 0.0000
2008-06-08T10%3A00%3A00.000%2B02%3A00 365.1156 0.0000 0.0000 0.0000
2008-06-08T15%3A00%3A00.000%2B02%3A00 365.1156 0.0000 0.0000 0.0000
2008-06-08T20%3A00%3A00.000%2B02%3A00 365.1156 0.0000 0.0000 0.0000
2008-06-09T01%3A00%3A00.000%2B02%3A00 365.1156 0.0000 0.0000 0.0000
2008-06-09T06%3A00%3A00.000%2B02%3A00 365.1156 0.0000 0.0000 0.0000
2008-06-09T11%3A00%3A00.000%2B02%3A00 365.1156 0.0000 0.0000 0.0000
2008-06-09T16%3A00%3A00.000%2B02%3A00 365.1156 0.0000 0.0000 0.0000
2008-06-09T21%3A00%3A00.000%2B02%3A00 365.1156 0.0000 0.0000 0.0000
2008-06-10T00%3A00%3A00.000%2B02%3A00 365.1156 0.0000 0.0000 0.0000
]]></om:result>
  </res1d2d:Hydrograph>
 </res1d2d:hydrographMember>
 <res1d2d:hydrographMember>
  <res1d2d:Hydrograph gml:id="Hydrograph122254316409315">
   <gml:description>Ganglinienpunkt f�r Teilmodell</gml:description>
   <gml:name>Ganglinienpunkt</gml:name>
   <gml:location>
    <gml:Point xmlns:ns6="http://www.w3.org/2001/SMIL20/" xmlns:st="http://www.seegrid.csiro.au/xml/st" xmlns:ns1="http://www.isotc211.org/2005/gmd" xmlns:ns7="http://www.isotc211.org/2005/gco" xmlns:ns8="http://www.isotc211.org/2005/gss" xmlns:ns9="http://www.isotc211.org/2005/gts" xmlns:ns10="http://www.isotc211.org/2005/gsr" xmlns:ns11="http://www.w3.org/2001/SMIL20/Language" srsName="EPSG:31467">
     <gml:coordinates ts="," decimal="." cs=" ">3929186.75 773908.375 366.5510748</gml:coordinates>
    </gml:Point>
   </gml:location>
   <om:resultDefinition xmlns:om="http://www.opengis.net/om">
    <sweExt:SortedRecordDefinition gml:id="SortedRecordDefinition122254331282877">
     <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:1d2d:timeserie:components#Time"/>
     <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:1d2d:timeserie:components#Waterlevel"/>
     <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:1d2d:timeserie:components#Depth"/>
     <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:1d2d:timeserie:components#Velocity"/>
     <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:1d2d:timeserie:components#Discharge"/>
     <sweExt:sortedComponent xlink:href="urn:ogc:gml:dict:kalypso:model:1d2d:timeserie:components#Time"/>
    </sweExt:SortedRecordDefinition>
   </om:resultDefinition>
   <om:result xmlns:om="http://www.opengis.net/om"><![CDATA[2008-06-04T01%3A00%3A00.000%2B02%3A00 366.6552 0.1042 0.2606 0.0000
2008-06-04T06%3A00%3A00.000%2B02%3A00 366.6494 0.0983 0.2657 0.0000
2008-06-04T11%3A00%3A00.000%2B02%3A00 366.6843 0.1332 0.2873 0.0000
2008-06-04T16%3A00%3A00.000%2B02%3A00 366.7130 0.1619 0.3125 0.0000
2008-06-04T21%3A00%3A00.000%2B02%3A00 366.8467 0.2956 0.3578 0.0000
2008-06-05T02%3A00%3A00.000%2B02%3A00 366.9051 0.3540 0.3917 0.0000
2008-06-05T07%3A00%3A00.000%2B02%3A00 366.9684 0.4173 0.4367 0.0000
2008-06-05T12%3A00%3A00.000%2B02%3A00 367.0443 0.4932 0.4852 0.0000
2008-06-05T17%3A00%3A00.000%2B02%3A00 367.1529 0.6019 0.5497 0.0000
2008-06-05T22%3A00%3A00.000%2B02%3A00 367.2210 0.6699 0.6034 0.0000
2008-06-06T03%3A00%3A00.000%2B02%3A00 367.2973 0.7462 0.6293 0.0000
2008-06-06T08%3A00%3A00.000%2B02%3A00 367.3450 0.7939 0.6563 0.0000
2008-06-06T13%3A00%3A00.000%2B02%3A00 367.4103 0.8592 0.6611 0.0000
2008-06-06T18%3A00%3A00.000%2B02%3A00 367.3814 0.8304 0.6454 0.0000
2008-06-06T23%3A00%3A00.000%2B02%3A00 367.3175 0.7664 0.6145 0.0000
2008-06-07T04%3A00%3A00.000%2B02%3A00 367.2700 0.7189 0.6013 0.0000
2008-06-07T09%3A00%3A00.000%2B02%3A00 367.2130 0.6619 0.5831 0.0000
2008-06-07T14%3A00%3A00.000%2B02%3A00 367.1483 0.5972 0.5440 0.0000
2008-06-07T19%3A00%3A00.000%2B02%3A00 367.0578 0.5068 0.4785 0.0000
2008-06-08T00%3A00%3A00.000%2B02%3A00 366.9997 0.4487 0.4517 0.0000
2008-06-08T05%3A00%3A00.000%2B02%3A00 366.9553 0.4042 0.4246 0.0000
2008-06-08T10%3A00%3A00.000%2B02%3A00 366.9006 0.3495 0.3840 0.0000
2008-06-08T15%3A00%3A00.000%2B02%3A00 366.8492 0.2981 0.3507 0.0000
2008-06-08T20%3A00%3A00.000%2B02%3A00 366.7991 0.2480 0.3265 0.0000
2008-06-09T01%3A00%3A00.000%2B02%3A00 366.7337 0.1827 0.3286 0.0000
2008-06-09T06%3A00%3A00.000%2B02%3A00 366.6751 0.1240 0.2874 0.0000
2008-06-09T11%3A00%3A00.000%2B02%3A00 366.6129 0.0618 0.2437 0.0000
2008-06-09T16%3A00%3A00.000%2B02%3A00 366.5516 0.0005 0.2069 0.0000
2008-06-09T21%3A00%3A00.000%2B02%3A00 366.4631 0.0000 0.0000 0.0000
2008-06-10T00%3A00%3A00.000%2B02%3A00 366.4326 0.0000 0.0000 0.0000
]]></om:result>
  </res1d2d:Hydrograph>
 </res1d2d:hydrographMember>
 <res1d2d:resultMember>
  <res1d2d:HydrographResult gml:id="HydrographResult122254313909324">
   <res1d2d:path>results/CalculationUnit1D2D12144639393734308/timestep-4.06.2008_16_00_CEST/results.zip!/results.gml</res1d2d:path>
   <res1d2d:date>2008-06-04T14:00:00.000Z</res1d2d:date>
  </res1d2d:HydrographResult>
 </res1d2d:resultMember>
 <res1d2d:resultMember>
  <res1d2d:HydrographResult gml:id="HydrographResult122254313909318">
   <res1d2d:path>results/CalculationUnit1D2D12144639393734308/timestep-10.06.2008_00_00_CEST/results.zip!/results.gml</res1d2d:path>
   <res1d2d:date>2008-06-09T22:00:00.000Z</res1d2d:date>
  </res1d2d:HydrographResult>
 </res1d2d:resultMember>
 <res1d2d:resultMember>
  <res1d2d:HydrographResult gml:id="HydrographResult122254313909312">
   <res1d2d:path>results/CalculationUnit1D2D12144639393734308/timestep-6.06.2008_08_00_CEST/results.zip!/results.gml</res1d2d:path>
   <res1d2d:date>2008-06-06T06:00:00.000Z</res1d2d:date>
  </res1d2d:HydrographResult>
 </res1d2d:resultMember>
 <res1d2d:resultMember>
  <res1d2d:HydrographResult gml:id="HydrographResult122254313909311">
   <res1d2d:path>results/CalculationUnit1D2D12144639393734308/timestep-5.06.2008_02_00_CEST/results.zip!/results.gml</res1d2d:path>
   <res1d2d:date>2008-06-05T00:00:00.000Z</res1d2d:date>
  </res1d2d:HydrographResult>
 </res1d2d:resultMember>
 <res1d2d:resultMember>
  <res1d2d:HydrographResult gml:id="HydrographResult12225431390935">
   <res1d2d:path>results/CalculationUnit1D2D12144639393734308/timestep-8.06.2008_15_00_CEST/results.zip!/results.gml</res1d2d:path>
   <res1d2d:date>2008-06-08T13:00:00.000Z</res1d2d:date>
  </res1d2d:HydrographResult>
 </res1d2d:resultMember>
 <res1d2d:resultMember>
  <res1d2d:HydrographResult gml:id="HydrographResult122254313909322">
   <res1d2d:path>results/CalculationUnit1D2D12144639393734308/timestep-4.06.2008_01_00_CEST/results.zip!/results.gml</res1d2d:path>
   <res1d2d:date>2008-06-03T23:00:00.000Z</res1d2d:date>
  </res1d2d:HydrographResult>
 </res1d2d:resultMember>
 <res1d2d:resultMember>
  <res1d2d:HydrographResult gml:id="HydrographResult122254313909313">
   <res1d2d:path>results/CalculationUnit1D2D12144639393734308/timestep-9.06.2008_06_00_CEST/results.zip!/results.gml</res1d2d:path>
   <res1d2d:date>2008-06-09T04:00:00.000Z</res1d2d:date>
  </res1d2d:HydrographResult>
 </res1d2d:resultMember>
 <res1d2d:resultMember>
  <res1d2d:HydrographResult gml:id="HydrographResult122254313909320">
   <res1d2d:path>results/CalculationUnit1D2D12144639393734308/timestep-7.06.2008_14_00_CEST/results.zip!/results.gml</res1d2d:path>
   <res1d2d:date>2008-06-07T12:00:00.000Z</res1d2d:date>
  </res1d2d:HydrographResult>
 </res1d2d:resultMember>
 <res1d2d:resultMember>
  <res1d2d:HydrographResult gml:id="HydrographResult122254313909321">
   <res1d2d:path>results/CalculationUnit1D2D12144639393734308/timestep-9.06.2008_16_00_CEST/results.zip!/results.gml</res1d2d:path>
   <res1d2d:date>2008-06-09T14:00:00.000Z</res1d2d:date>
  </res1d2d:HydrographResult>
 </res1d2d:resultMember>
 <res1d2d:resultMember>
  <res1d2d:HydrographResult gml:id="HydrographResult122254313909314">
   <res1d2d:path>results/CalculationUnit1D2D12144639393734308/timestep-9.06.2008_21_00_CEST/results.zip!/results.gml</res1d2d:path>
   <res1d2d:date>2008-06-09T19:00:00.000Z</res1d2d:date>
  </res1d2d:HydrographResult>
 </res1d2d:resultMember>
 <res1d2d:resultMember>
  <res1d2d:HydrographResult gml:id="HydrographResult122254313909319">
   <res1d2d:path>results/CalculationUnit1D2D12144639393734308/timestep-8.06.2008_05_00_CEST/results.zip!/results.gml</res1d2d:path>
   <res1d2d:date>2008-06-08T03:00:00.000Z</res1d2d:date>
  </res1d2d:HydrographResult>
 </res1d2d:resultMember>
 <res1d2d:resultMember>
  <res1d2d:HydrographResult gml:id="HydrographResult122254313909315">
   <res1d2d:path>results/CalculationUnit1D2D12144639393734308/timestep-5.06.2008_07_00_CEST/results.zip!/results.gml</res1d2d:path>
   <res1d2d:date>2008-06-05T05:00:00.000Z</res1d2d:date>
  </res1d2d:HydrographResult>
 </res1d2d:resultMember>
 <res1d2d:resultMember>
  <res1d2d:HydrographResult gml:id="HydrographResult122254313909317">
   <res1d2d:path>results/CalculationUnit1D2D12144639393734308/timestep-9.06.2008_01_00_CEST/results.zip!/results.gml</res1d2d:path>
   <res1d2d:date>2008-06-08T23:00:00.000Z</res1d2d:date>
  </res1d2d:HydrographResult>
 </res1d2d:resultMember>
 <res1d2d:resultMember>
  <res1d2d:HydrographResult gml:id="HydrographResult12225431390939">
   <res1d2d:path>results/CalculationUnit1D2D12144639393734308/timestep-9.06.2008_11_00_CEST/results.zip!/results.gml</res1d2d:path>
   <res1d2d:date>2008-06-09T09:00:00.000Z</res1d2d:date>
  </res1d2d:HydrographResult>
 </res1d2d:resultMember>
 <res1d2d:resultMember>
  <res1d2d:HydrographResult gml:id="HydrographResult122254313909316">
   <res1d2d:path>results/CalculationUnit1D2D12144639393734308/timestep-4.06.2008_06_00_CEST/results.zip!/results.gml</res1d2d:path>
   <res1d2d:date>2008-06-04T04:00:00.000Z</res1d2d:date>
  </res1d2d:HydrographResult>
 </res1d2d:resultMember>
 <res1d2d:resultMember>
  <res1d2d:HydrographResult gml:id="HydrographResult12225431390933">
   <res1d2d:path>results/CalculationUnit1D2D12144639393734308/timestep-4.06.2008_21_00_CEST/results.zip!/results.gml</res1d2d:path>
   <res1d2d:date>2008-06-04T19:00:00.000Z</res1d2d:date>
  </res1d2d:HydrographResult>
 </res1d2d:resultMember>
 <res1d2d:resultMember>
  <res1d2d:HydrographResult gml:id="HydrographResult122254313909310">
   <res1d2d:path>results/CalculationUnit1D2D12144639393734308/timestep-6.06.2008_13_00_CEST/results.zip!/results.gml</res1d2d:path>
   <res1d2d:date>2008-06-06T11:00:00.000Z</res1d2d:date>
  </res1d2d:HydrographResult>
 </res1d2d:resultMember>
 <res1d2d:resultMember>
  <res1d2d:HydrographResult gml:id="HydrographResult12225431390937">
   <res1d2d:path>results/CalculationUnit1D2D12144639393734308/timestep-8.06.2008_10_00_CEST/results.zip!/results.gml</res1d2d:path>
   <res1d2d:date>2008-06-08T08:00:00.000Z</res1d2d:date>
  </res1d2d:HydrographResult>
 </res1d2d:resultMember>
 <res1d2d:resultMember>
  <res1d2d:HydrographResult gml:id="HydrographResult12225431390931">
   <res1d2d:path>results/CalculationUnit1D2D12144639393734308/timestep-5.06.2008_17_00_CEST/results.zip!/results.gml</res1d2d:path>
   <res1d2d:date>2008-06-05T15:00:00.000Z</res1d2d:date>
  </res1d2d:HydrographResult>
 </res1d2d:resultMember>
 <res1d2d:resultMember>
  <res1d2d:HydrographResult gml:id="HydrographResult12225431390934">
   <res1d2d:path>results/CalculationUnit1D2D12144639393734308/timestep-8.06.2008_20_00_CEST/results.zip!/results.gml</res1d2d:path>
   <res1d2d:date>2008-06-08T18:00:00.000Z</res1d2d:date>
  </res1d2d:HydrographResult>
 </res1d2d:resultMember>
 <res1d2d:resultMember>
  <res1d2d:HydrographResult gml:id="HydrographResult12225431390932">
   <res1d2d:path>results/CalculationUnit1D2D12144639393734308/timestep-7.06.2008_19_00_CEST/results.zip!/results.gml</res1d2d:path>
   <res1d2d:date>2008-06-07T17:00:00.000Z</res1d2d:date>
  </res1d2d:HydrographResult>
 </res1d2d:resultMember>
 <res1d2d:resultMember>
  <res1d2d:HydrographResult gml:id="HydrographResult12225431390936">
   <res1d2d:path>results/CalculationUnit1D2D12144639393734308/timestep-7.06.2008_04_00_CEST/results.zip!/results.gml</res1d2d:path>
   <res1d2d:date>2008-06-07T02:00:00.000Z</res1d2d:date>
  </res1d2d:HydrographResult>
 </res1d2d:resultMember>
 <res1d2d:resultMember>
  <res1d2d:HydrographResult gml:id="HydrographResult12225431390938">
   <res1d2d:path>results/CalculationUnit1D2D12144639393734308/timestep-5.06.2008_22_00_CEST/results.zip!/results.gml</res1d2d:path>
   <res1d2d:date>2008-06-05T20:00:00.000Z</res1d2d:date>
  </res1d2d:HydrographResult>
 </res1d2d:resultMember>
 <res1d2d:resultMember>
  <res1d2d:HydrographResult gml:id="HydrographResult12225431390786">
   <res1d2d:path>results/CalculationUnit1D2D12144639393734308/timestep-8.06.2008_00_00_CEST/results.zip!/results.gml</res1d2d:path>
   <res1d2d:date>2008-06-07T22:00:00.000Z</res1d2d:date>
  </res1d2d:HydrographResult>
 </res1d2d:resultMember>
 <res1d2d:resultMember>
  <res1d2d:HydrographResult gml:id="HydrographResult12225431390785">
   <res1d2d:path>results/CalculationUnit1D2D12144639393734308/timestep-6.06.2008_18_00_CEST/results.zip!/results.gml</res1d2d:path>
   <res1d2d:date>2008-06-06T16:00:00.000Z</res1d2d:date>
  </res1d2d:HydrographResult>
 </res1d2d:resultMember>
 <res1d2d:resultMember>
  <res1d2d:HydrographResult gml:id="HydrographResult12225431390784">
   <res1d2d:path>results/CalculationUnit1D2D12144639393734308/timestep-6.06.2008_03_00_CEST/results.zip!/results.gml</res1d2d:path>
   <res1d2d:date>2008-06-06T01:00:00.000Z</res1d2d:date>
  </res1d2d:HydrographResult>
 </res1d2d:resultMember>
 <res1d2d:resultMember>
  <res1d2d:HydrographResult gml:id="HydrographResult12225431390783">
   <res1d2d:path>results/CalculationUnit1D2D12144639393734308/timestep-6.06.2008_23_00_CEST/results.zip!/results.gml</res1d2d:path>
   <res1d2d:date>2008-06-06T21:00:00.000Z</res1d2d:date>
  </res1d2d:HydrographResult>
 </res1d2d:resultMember>
 <res1d2d:resultMember>
  <res1d2d:HydrographResult gml:id="HydrographResult12225431390782">
   <res1d2d:path>results/CalculationUnit1D2D12144639393734308/timestep-4.06.2008_11_00_CEST/results.zip!/results.gml</res1d2d:path>
   <res1d2d:date>2008-06-04T09:00:00.000Z</res1d2d:date>
  </res1d2d:HydrographResult>
 </res1d2d:resultMember>
 <res1d2d:resultMember>
  <res1d2d:HydrographResult gml:id="HydrographResult12225431390781">
   <res1d2d:path>results/CalculationUnit1D2D12144639393734308/timestep-7.06.2008_09_00_CEST/results.zip!/results.gml</res1d2d:path>
   <res1d2d:date>2008-06-07T07:00:00.000Z</res1d2d:date>
  </res1d2d:HydrographResult>
 </res1d2d:resultMember>
 <res1d2d:resultMember>
  <res1d2d:HydrographResult gml:id="HydrographResult12225431390780">
   <res1d2d:path>results/CalculationUnit1D2D12144639393734308/timestep-5.06.2008_12_00_CEST/results.zip!/results.gml</res1d2d:path>
   <res1d2d:date>2008-06-05T10:00:00.000Z</res1d2d:date>
  </res1d2d:HydrographResult>
 </res1d2d:resultMember>
</res1d2d:HydrographCollection>
