<?xml version="1.0" encoding="UTF-8"?>
<commonShp:StatusCollection xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:gml="http://www.opengis.net/gml" xmlns:xs="http://www.w3.org/2001/XMLSchema-instance" xmlns:commonShp="org.kalypso.gml.common" gml:id="root">
 <commonShp:statusMember>
  <commonShp:Status gml:id="Status12288249984490">
   <gml:description>Start der Simulation</gml:description>
   <commonShp:time>2008-12-09T12:16:38.449Z</commonShp:time>
   <commonShp:severity>info</commonShp:severity>
   <commonShp:code>0</commonShp:code>
   <commonShp:plugin>org.kalypso.model1d2d</commonShp:plugin>
   <commonShp:exception>rO0ABXA=</commonShp:exception>
  </commonShp:Status>
 </commonShp:statusMember>
 <commonShp:statusMember>
  <commonShp:Status gml:id="Status12288249984491">
   <gml:description>Schreibe RMA·Kalypso-ASCII Dateien für FE-Simulation</gml:description>
   <commonShp:time>2008-12-09T12:16:38.449Z</commonShp:time>
   <commonShp:severity>info</commonShp:severity>
   <commonShp:code>1</commonShp:code>
   <commonShp:plugin>org.kalypso.model1d2d</commonShp:plugin>
   <commonShp:exception>rO0ABXA=</commonShp:exception>
  </commonShp:Status>
 </commonShp:statusMember>
 <commonShp:statusMember>
  <commonShp:Status gml:id="Status12288249984492">
   <gml:description>Restart-Daten werden gelesen</gml:description>
   <commonShp:time>2008-12-09T12:16:38.449Z</commonShp:time>
   <commonShp:severity>info</commonShp:severity>
   <commonShp:code>1</commonShp:code>
   <commonShp:plugin>org.kalypso.model1d2d</commonShp:plugin>
   <commonShp:exception>rO0ABXA=</commonShp:exception>
  </commonShp:Status>
 </commonShp:statusMember>
 <commonShp:statusMember>
  <commonShp:Status gml:id="Status12288250034343">
   <gml:description>Schreibe Finite Elemente Netz</gml:description>
   <commonShp:time>2008-12-09T12:16:43.434Z</commonShp:time>
   <commonShp:severity>info</commonShp:severity>
   <commonShp:code>1</commonShp:code>
   <commonShp:plugin>org.kalypso.model1d2d</commonShp:plugin>
   <commonShp:exception>rO0ABXA=</commonShp:exception>
  </commonShp:Status>
 </commonShp:statusMember>
 <commonShp:statusMember>
  <commonShp:Status gml:id="Status12288250038710">
   <gml:description>Element 'PolyElement1214398184137932' hat keine Rauheitszone zugewiesen und wird für die Rechnung deaktiviert.</gml:description>
   <gml:location>
    <gml:Point xmlns:ns4="http://www.w3.org/2001/SMIL20/" xmlns:swe="http://www.opengis.net/swe" xmlns:st="http://www.seegrid.csiro.au/xml/st" xmlns:ns1="http://www.isotc211.org/2005/gmd" xmlns:ns5="http://www.isotc211.org/2005/gco" xmlns:ns6="http://www.isotc211.org/2005/gss" xmlns:ns7="http://www.isotc211.org/2005/gts" xmlns:ns8="http://www.isotc211.org/2005/gsr" xmlns:ns9="http://www.w3.org/2001/SMIL20/Language" srsName="EPSG:31467">
     <gml:coordinates ts="," decimal="." cs=" ">3929661.188 775331.25 370.7958716</gml:coordinates>
    </gml:Point>
   </gml:location>
   <commonShp:time>2008-12-09T12:16:43.871Z</commonShp:time>
   <commonShp:severity>warning</commonShp:severity>
   <commonShp:code>1000</commonShp:code>
   <commonShp:plugin>org.kalypso.model1d2d</commonShp:plugin>
   <commonShp:exception>rO0ABXA=</commonShp:exception>
  </commonShp:Status>
 </commonShp:statusMember>
 <commonShp:statusMember>
  <commonShp:Status gml:id="Status12288250038711">
   <gml:description>Element 'PolyElement121439818413710612' hat keine Rauheitszone zugewiesen und wird für die Rechnung deaktiviert.</gml:description>
   <gml:location>
    <gml:Point xmlns:ns4="http://www.w3.org/2001/SMIL20/" xmlns:swe="http://www.opengis.net/swe" xmlns:st="http://www.seegrid.csiro.au/xml/st" xmlns:ns1="http://www.isotc211.org/2005/gmd" xmlns:ns5="http://www.isotc211.org/2005/gco" xmlns:ns6="http://www.isotc211.org/2005/gss" xmlns:ns7="http://www.isotc211.org/2005/gts" xmlns:ns8="http://www.isotc211.org/2005/gsr" xmlns:ns9="http://www.w3.org/2001/SMIL20/Language" srsName="EPSG:31467">
     <gml:coordinates ts="," decimal="." cs=" ">3929685.625 775342.375 370.8316877</gml:coordinates>
    </gml:Point>
   </gml:location>
   <commonShp:time>2008-12-09T12:16:43.871Z</commonShp:time>
   <commonShp:severity>warning</commonShp:severity>
   <commonShp:code>1000</commonShp:code>
   <commonShp:plugin>org.kalypso.model1d2d</commonShp:plugin>
   <commonShp:exception>rO0ABXA=</commonShp:exception>
  </commonShp:Status>
 </commonShp:statusMember>
 <commonShp:statusMember>
  <commonShp:Status gml:id="Status12288250096054">
   <gml:description>Schreibe Randbedingungen und Berechnungssteuerung</gml:description>
   <commonShp:time>2008-12-09T12:16:49.605Z</commonShp:time>
   <commonShp:severity>info</commonShp:severity>
   <commonShp:code>1</commonShp:code>
   <commonShp:plugin>org.kalypso.model1d2d</commonShp:plugin>
   <commonShp:exception>rO0ABXA=</commonShp:exception>
  </commonShp:Status>
 </commonShp:statusMember>
 <commonShp:statusMember>
  <commonShp:Status gml:id="Status12288250100276">
   <gml:description>Schreibe Bauwerke</gml:description>
   <commonShp:time>2008-12-09T12:16:50.027Z</commonShp:time>
   <commonShp:severity>info</commonShp:severity>
   <commonShp:code>1</commonShp:code>
   <commonShp:plugin>org.kalypso.model1d2d</commonShp:plugin>
   <commonShp:exception>rO0ABXA=</commonShp:exception>
  </commonShp:Status>
 </commonShp:statusMember>
 <commonShp:statusMember>
  <commonShp:Status gml:id="Status12288250100278">
   <gml:description>Schreibe W/Q-Randbedingungen</gml:description>
   <commonShp:time>2008-12-09T12:16:50.027Z</commonShp:time>
   <commonShp:severity>info</commonShp:severity>
   <commonShp:code>1</commonShp:code>
   <commonShp:plugin>org.kalypso.model1d2d</commonShp:plugin>
   <commonShp:exception>rO0ABXA=</commonShp:exception>
  </commonShp:Status>
 </commonShp:statusMember>
 <commonShp:statusMember>
  <commonShp:Status gml:id="Status12288250100586">
   <gml:description>RMA·Kalypso wird ausgeführt: D:\Kalypso_2_1_RC1\bin\rma-kalypso_1_1_0_20081208.exe</gml:description>
   <commonShp:time>2008-12-09T12:16:50.058Z</commonShp:time>
   <commonShp:severity>info</commonShp:severity>
   <commonShp:code>1</commonShp:code>
   <commonShp:plugin>org.kalypso.model1d2d</commonShp:plugin>
   <commonShp:exception>rO0ABXA=</commonShp:exception>
  </commonShp:Status>
 </commonShp:statusMember>
 <commonShp:statusMember>
  <commonShp:Status gml:id="Status12288251473081">
   <gml:description>Simulation erfolgreich beendet</gml:description>
   <commonShp:time>2008-12-09T12:19:07.308Z</commonShp:time>
   <commonShp:severity>ok</commonShp:severity>
   <commonShp:code>0</commonShp:code>
   <commonShp:plugin>org.kalypso.model1d2d</commonShp:plugin>
   <commonShp:exception>rO0ABXA=</commonShp:exception>
  </commonShp:Status>
 </commonShp:statusMember>
 <commonShp:statusMember>
  <commonShp:Status gml:id="Status122882547554311">
   <gml:description>Start der Ergebnisauswertung</gml:description>
   <commonShp:time>2008-12-09T12:24:35.543Z</commonShp:time>
   <commonShp:severity>info</commonShp:severity>
   <commonShp:code>0</commonShp:code>
   <commonShp:plugin>org.kalypso.model1d2d</commonShp:plugin>
   <commonShp:exception>rO0ABXA=</commonShp:exception>
  </commonShp:Status>
 </commonShp:statusMember>
 <commonShp:statusMember>
  <commonShp:Status gml:id="Status12288254756053">
   <gml:description>Bestehende Ergebnisse werden gelöscht.</gml:description>
   <commonShp:time>2008-12-09T12:24:35.605Z</commonShp:time>
   <commonShp:severity>info</commonShp:severity>
   <commonShp:code>1</commonShp:code>
   <commonShp:plugin>org.kalypso.model1d2d</commonShp:plugin>
   <commonShp:exception>rO0ABXA=</commonShp:exception>
  </commonShp:Status>
 </commonShp:statusMember>
 <commonShp:statusMember>
  <commonShp:Status gml:id="Status12288254757304">
   <gml:description>Ergebnisauswertung - steady</gml:description>
   <commonShp:time>2008-12-09T12:24:35.730Z</commonShp:time>
   <commonShp:severity>info</commonShp:severity>
   <commonShp:code>1</commonShp:code>
   <commonShp:plugin>org.kalypso.model1d2d</commonShp:plugin>
   <commonShp:exception>rO0ABXA=</commonShp:exception>
  </commonShp:Status>
 </commonShp:statusMember>
 <commonShp:statusMember>
  <commonShp:Status gml:id="Status12288255128245">
   <gml:description>Ergebnisauswertung - maxi</gml:description>
   <commonShp:time>2008-12-09T12:25:12.824Z</commonShp:time>
   <commonShp:severity>info</commonShp:severity>
   <commonShp:code>1</commonShp:code>
   <commonShp:plugin>org.kalypso.model1d2d</commonShp:plugin>
   <commonShp:exception>rO0ABXA=</commonShp:exception>
  </commonShp:Status>
 </commonShp:statusMember>
 <commonShp:statusMember>
  <commonShp:Status gml:id="Status122882554123011">
   <gml:description>Ergebnisauswertung - A0001</gml:description>
   <commonShp:time>2008-12-09T12:25:41.230Z</commonShp:time>
   <commonShp:severity>info</commonShp:severity>
   <commonShp:code>1</commonShp:code>
   <commonShp:plugin>org.kalypso.model1d2d</commonShp:plugin>
   <commonShp:exception>rO0ABXA=</commonShp:exception>
  </commonShp:Status>
 </commonShp:statusMember>
 <commonShp:statusMember>
  <commonShp:Status gml:id="Status122882557143314">
   <gml:description>Ergebnisauswertung - A0002</gml:description>
   <commonShp:time>2008-12-09T12:26:11.433Z</commonShp:time>
   <commonShp:severity>info</commonShp:severity>
   <commonShp:code>1</commonShp:code>
   <commonShp:plugin>org.kalypso.model1d2d</commonShp:plugin>
   <commonShp:exception>rO0ABXA=</commonShp:exception>
  </commonShp:Status>
 </commonShp:statusMember>
 <commonShp:statusMember>
  <commonShp:Status gml:id="Status122882559990210">
   <gml:description>Ergebnisauswertung - A0003</gml:description>
   <commonShp:time>2008-12-09T12:26:39.902Z</commonShp:time>
   <commonShp:severity>info</commonShp:severity>
   <commonShp:code>1</commonShp:code>
   <commonShp:plugin>org.kalypso.model1d2d</commonShp:plugin>
   <commonShp:exception>rO0ABXA=</commonShp:exception>
  </commonShp:Status>
 </commonShp:statusMember>
 <commonShp:statusMember>
  <commonShp:Status gml:id="Status12288256294806">
   <gml:description>Ergebnisauswertung - A0004</gml:description>
   <commonShp:time>2008-12-09T12:27:09.480Z</commonShp:time>
   <commonShp:severity>info</commonShp:severity>
   <commonShp:code>1</commonShp:code>
   <commonShp:plugin>org.kalypso.model1d2d</commonShp:plugin>
   <commonShp:exception>rO0ABXA=</commonShp:exception>
  </commonShp:Status>
 </commonShp:statusMember>
 <commonShp:statusMember>
  <commonShp:Status gml:id="Status122882565791811">
   <gml:description>Ergebnisauswertung - A0005</gml:description>
   <commonShp:time>2008-12-09T12:27:37.918Z</commonShp:time>
   <commonShp:severity>info</commonShp:severity>
   <commonShp:code>1</commonShp:code>
   <commonShp:plugin>org.kalypso.model1d2d</commonShp:plugin>
   <commonShp:exception>rO0ABXA=</commonShp:exception>
  </commonShp:Status>
 </commonShp:statusMember>
 <commonShp:statusMember>
  <commonShp:Status gml:id="Status12288256863556">
   <gml:description>Ergebnisauswertung - A0006</gml:description>
   <commonShp:time>2008-12-09T12:28:06.355Z</commonShp:time>
   <commonShp:severity>info</commonShp:severity>
   <commonShp:code>1</commonShp:code>
   <commonShp:plugin>org.kalypso.model1d2d</commonShp:plugin>
   <commonShp:exception>rO0ABXA=</commonShp:exception>
  </commonShp:Status>
 </commonShp:statusMember>
 <commonShp:statusMember>
  <commonShp:Status gml:id="Status122882571583916">
   <gml:description>Alle Ergebnisse wurden erfolgreich ausgewertet.</gml:description>
   <commonShp:time>2008-12-09T12:28:35.839Z</commonShp:time>
   <commonShp:severity>ok</commonShp:severity>
   <commonShp:code>3000</commonShp:code>
   <commonShp:plugin>org.kalypso.model1d2d</commonShp:plugin>
   <commonShp:exception>rO0ABXA=</commonShp:exception>
  </commonShp:Status>
 </commonShp:statusMember>
 <commonShp:statusMember>
  <commonShp:Status gml:id="Status122882571583918">
   <gml:description>Ergebnisse werden in Arbeitsbereich verschoben und Ergebnisdatenbank aktualisiert.</gml:description>
   <commonShp:time>2008-12-09T12:28:35.839Z</commonShp:time>
   <commonShp:severity>info</commonShp:severity>
   <commonShp:code>1</commonShp:code>
   <commonShp:plugin>org.kalypso.model1d2d</commonShp:plugin>
   <commonShp:exception>rO0ABXA=</commonShp:exception>
  </commonShp:Status>
 </commonShp:statusMember>
 <commonShp:statusMember>
  <commonShp:Status gml:id="Status122882571590119">
   <gml:description>Ergebnisauswertung erfolgreich beendet</gml:description>
   <commonShp:time>2008-12-09T12:28:35.901Z</commonShp:time>
   <commonShp:severity>ok</commonShp:severity>
   <commonShp:code>0</commonShp:code>
   <commonShp:plugin>org.kalypso.model1d2d</commonShp:plugin>
   <commonShp:exception>rO0ABXA=</commonShp:exception>
  </commonShp:Status>
 </commonShp:statusMember>
</commonShp:StatusCollection>
