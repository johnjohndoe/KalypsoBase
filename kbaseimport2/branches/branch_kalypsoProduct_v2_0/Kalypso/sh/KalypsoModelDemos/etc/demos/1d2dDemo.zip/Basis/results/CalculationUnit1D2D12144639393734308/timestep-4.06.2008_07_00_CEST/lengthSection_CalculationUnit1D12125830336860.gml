<?xml version="1.0" encoding="WINDOWS-1252"?>
<om:Observation xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:gml="http://www.opengis.net/gml" xmlns:xs="http://www.w3.org/2001/XMLSchema-instance" xmlns:om="http://www.opengis.net/om" xmlns:st="http://www.seegrid.csiro.au/xml/st" xmlns:sweExt="org.kalypso.swe.ext" xs:schemaLocation="http://www.opengis.net/om http://dev.bjoernsen.de/ogc/schema/om/1.0.30/om.xsd     http://www.opengis.net/gml http://dev.bjoernsen.de/ogc/schema/gml/3.1.1/base/gml.xsd     http://www.w3.org/1999/xlink http://dev.bjoernsen.de/ogc/schema/gml/3.1.1/xlink/xlinks.xsd     http://www.opengis.net/swe http://dev.bjoernsen.de/ogc/schema/sweCommon/1.0.30/swe.xsd     http://www.seegrid.csiro.au/xml/st http://dev.bjoernsen.de/ogc/schema/sweCommon/1.0.30/simpleTypeDerivation.xsd" gml:id="LengthSectionResult">
 <gml:name>L�ngsschnitt</gml:name>
 <om:procedure>
  <om:ObservationProcedure gml:id="proc_wspm_ls">
   <gml:description>WSPM TUHH L�ngsschnitt Ergebnis</gml:description>
   <gml:name>WSPM-TUHH-LS</gml:name>
   <om:method/>
  </om:ObservationProcedure>
 </om:procedure>
 <om:resultDefinition>
  <sweExt:SortedRecordDefinition gml:id="SortedRecordDefinition12224670907966">
   <swe:component xmlns:swe="http://www.opengis.net/swe" xlink:href="urn:ogc:gml:dict:kalypso:model:wspm:components#LengthSectionStation"/>
   <swe:component xmlns:swe="http://www.opengis.net/swe" xlink:href="urn:ogc:gml:dict:kalypso:model:wspm:components#LengthSectionRunOff"/>
   <swe:component xmlns:swe="http://www.opengis.net/swe" xlink:href="urn:ogc:gml:dict:kalypso:model:wspm:components#LengthSection_v_m"/>
   <swe:component xmlns:swe="http://www.opengis.net/swe" xlink:href="urn:ogc:gml:dict:kalypso:model:wspm:components#LengthSectionGround"/>
   <swe:component xmlns:swe="http://www.opengis.net/swe" xlink:href="urn:ogc:gml:dict:kalypso:model:wspm:components#LengthSectionWaterlevel"/>
   <sweExt:sortedComponent xlink:href="urn:ogc:gml:dict:kalypso:model:wspm:components#LengthSectionStation"/>
  </sweExt:SortedRecordDefinition>
 </om:resultDefinition>
 <om:result><![CDATA[44.4050 263.751 0.7608 361.5630 367.0061
44.4250 263.750 0.7129 361.6010 367.0095
44.5000 263.802 0.5274 361.7920 367.0280
44.6000 263.820 0.6301 360.7400 367.0294
44.7000 263.865 0.6500 359.7280 367.0331
44.8000 263.928 0.6203 359.5990 367.0446
44.9000 263.962 0.5582 359.9860 367.0538
45.0000 264.000 0.5643 359.8540 367.0618
45.1000 264.040 0.5502 360.2510 367.0699
45.2000 264.048 0.5127 358.9970 367.0770
45.3000 264.088 0.4808 358.5160 367.0823
45.4000 264.120 0.4069 358.5040 367.0885
45.5000 264.122 0.3112 356.9580 367.0938
45.6000 264.228 0.3786 357.3760 367.0927
45.7000 264.251 0.3646 358.5970 367.0954
45.8000 264.305 0.4070 358.9100 367.0953
45.9000 264.331 0.3703 359.3010 367.0990
46.0000 264.399 0.3308 359.8570 367.1017
46.0160 264.376 0.3041 359.7230 367.1026
46.1000 264.433 0.3502 358.5050 367.1021
46.2000 264.373 0.3087 358.1940 367.1046
46.3000 264.490 0.3162 359.0200 367.1052
46.4000 264.422 0.3159 359.0940 367.1062
46.5000 264.578 0.3616 359.1720 367.1056
46.6000 264.551 0.3859 359.3090 367.1060
46.7000 264.664 0.4806 361.1990 367.1040
46.8000 264.639 0.6114 362.9840 367.1013
46.9000 264.772 0.6144 362.7480 367.1080
47.0000 264.711 0.5921 362.5350 367.1158
47.1000 264.871 0.5403 362.3990 367.1245
47.2000 264.769 0.5354 362.5320 367.1301
47.3000 264.959 0.6402 362.5100 367.1299
]]></om:result>
</om:Observation>
