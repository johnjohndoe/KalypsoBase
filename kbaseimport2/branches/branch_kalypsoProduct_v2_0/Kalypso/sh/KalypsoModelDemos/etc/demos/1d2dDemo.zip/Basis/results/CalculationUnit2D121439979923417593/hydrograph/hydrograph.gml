<?xml version="1.0" encoding="WINDOWS-1252"?>
<res1d2d:HydrographCollection xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:gml="http://www.opengis.net/gml" xmlns:xs="http://www.w3.org/2001/XMLSchema-instance" xmlns:res1d2d="http://www.tu-harburg.de/wb/kalypso/schemata/1d2dResults" xmlns:swe="http://www.opengis.net/swe" xmlns:sweExt="org.kalypso.swe.ext" gml:id="root">
 <gml:name>Demo 2D</gml:name>
 <res1d2d:resultMember>
  <res1d2d:HydrographResult gml:id="HydrographResult12203687385314">
   <res1d2d:path>results/CalculationUnit2D121439979923417593/timestep-25.06.2008_02_00_CEST/results.gml</res1d2d:path>
   <res1d2d:date>2008-06-25T00:00:00.000Z</res1d2d:date>
  </res1d2d:HydrographResult>
 </res1d2d:resultMember>
 <res1d2d:resultMember>
  <res1d2d:HydrographResult gml:id="HydrographResult12203687385313">
   <res1d2d:path>results/CalculationUnit2D121439979923417593/timestep-25.06.2008_01_00_CEST/results.gml</res1d2d:path>
   <res1d2d:date>2008-06-24T23:00:00.000Z</res1d2d:date>
  </res1d2d:HydrographResult>
 </res1d2d:resultMember>
 <res1d2d:resultMember>
  <res1d2d:HydrographResult gml:id="HydrographResult12203687385311">
   <res1d2d:path>results/CalculationUnit2D121439979923417593/timestep-25.06.2008_05_00_CEST/results.gml</res1d2d:path>
   <res1d2d:date>2008-06-25T03:00:00.000Z</res1d2d:date>
  </res1d2d:HydrographResult>
 </res1d2d:resultMember>
 <res1d2d:resultMember>
  <res1d2d:HydrographResult gml:id="HydrographResult12203687385312">
   <res1d2d:path>results/CalculationUnit2D121439979923417593/timestep-25.06.2008_04_00_CEST/results.gml</res1d2d:path>
   <res1d2d:date>2008-06-25T02:00:00.000Z</res1d2d:date>
  </res1d2d:HydrographResult>
 </res1d2d:resultMember>
 <res1d2d:resultMember>
  <res1d2d:HydrographResult gml:id="HydrographResult12203687385310">
   <res1d2d:path>results/CalculationUnit2D121439979923417593/timestep-25.06.2008_03_00_CEST/results.gml</res1d2d:path>
   <res1d2d:date>2008-06-25T01:00:00.000Z</res1d2d:date>
  </res1d2d:HydrographResult>
 </res1d2d:resultMember>
</res1d2d:HydrographCollection>
