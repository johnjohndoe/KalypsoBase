<?xml version="1.0" encoding="UTF-8"?>
<commonShp:StatusCollection xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:gml="http://www.opengis.net/gml" xmlns:xs="http://www.w3.org/2001/XMLSchema-instance" xmlns:commonShp="org.kalypso.gml.common" gml:id="root">
 <commonShp:statusMember>
  <commonShp:Status gml:id="Status12288222824080">
   <gml:description>Start der Simulation</gml:description>
   <commonShp:time>2008-12-09T11:31:22.408Z</commonShp:time>
   <commonShp:severity>info</commonShp:severity>
   <commonShp:code>0</commonShp:code>
   <commonShp:plugin>org.kalypso.model1d2d</commonShp:plugin>
   <commonShp:exception>rO0ABXA=</commonShp:exception>
  </commonShp:Status>
 </commonShp:statusMember>
 <commonShp:statusMember>
  <commonShp:Status gml:id="Status12288222824081">
   <gml:description>Schreibe RMA·Kalypso-ASCII Dateien für FE-Simulation</gml:description>
   <commonShp:time>2008-12-09T11:31:22.408Z</commonShp:time>
   <commonShp:severity>info</commonShp:severity>
   <commonShp:code>1</commonShp:code>
   <commonShp:plugin>org.kalypso.model1d2d</commonShp:plugin>
   <commonShp:exception>rO0ABXA=</commonShp:exception>
  </commonShp:Status>
 </commonShp:statusMember>
 <commonShp:statusMember>
  <commonShp:Status gml:id="Status12288222824083">
   <gml:description>Restart-Daten werden gelesen</gml:description>
   <commonShp:time>2008-12-09T11:31:22.408Z</commonShp:time>
   <commonShp:severity>info</commonShp:severity>
   <commonShp:code>1</commonShp:code>
   <commonShp:plugin>org.kalypso.model1d2d</commonShp:plugin>
   <commonShp:exception>rO0ABXA=</commonShp:exception>
  </commonShp:Status>
 </commonShp:statusMember>
 <commonShp:statusMember>
  <commonShp:Status gml:id="Status12288222900751">
   <gml:description>Schreibe Finite Elemente Netz</gml:description>
   <commonShp:time>2008-12-09T11:31:30.075Z</commonShp:time>
   <commonShp:severity>info</commonShp:severity>
   <commonShp:code>1</commonShp:code>
   <commonShp:plugin>org.kalypso.model1d2d</commonShp:plugin>
   <commonShp:exception>rO0ABXA=</commonShp:exception>
  </commonShp:Status>
 </commonShp:statusMember>
 <commonShp:statusMember>
  <commonShp:Status gml:id="Status12288222910323">
   <gml:description>Element 'PolyElement1214398184137932' hat keine Rauheitszone zugewiesen und wird für die Rechnung deaktiviert.</gml:description>
   <gml:location>
    <gml:Point xmlns:ns4="http://www.w3.org/2001/SMIL20/" xmlns:swe="http://www.opengis.net/swe" xmlns:st="http://www.seegrid.csiro.au/xml/st" xmlns:ns1="http://www.isotc211.org/2005/gmd" xmlns:ns5="http://www.isotc211.org/2005/gco" xmlns:ns6="http://www.isotc211.org/2005/gss" xmlns:ns7="http://www.isotc211.org/2005/gts" xmlns:ns8="http://www.isotc211.org/2005/gsr" xmlns:ns9="http://www.w3.org/2001/SMIL20/Language" srsName="EPSG:31467">
     <gml:coordinates ts="," decimal="." cs=" ">3929661.188 775331.25 370.7958716</gml:coordinates>
    </gml:Point>
   </gml:location>
   <commonShp:time>2008-12-09T11:31:31.032Z</commonShp:time>
   <commonShp:severity>warning</commonShp:severity>
   <commonShp:code>1000</commonShp:code>
   <commonShp:plugin>org.kalypso.model1d2d</commonShp:plugin>
   <commonShp:exception>rO0ABXA=</commonShp:exception>
  </commonShp:Status>
 </commonShp:statusMember>
 <commonShp:statusMember>
  <commonShp:Status gml:id="Status12288222910472">
   <gml:description>Element 'PolyElement121439818413710612' hat keine Rauheitszone zugewiesen und wird für die Rechnung deaktiviert.</gml:description>
   <gml:location>
    <gml:Point xmlns:ns4="http://www.w3.org/2001/SMIL20/" xmlns:swe="http://www.opengis.net/swe" xmlns:st="http://www.seegrid.csiro.au/xml/st" xmlns:ns1="http://www.isotc211.org/2005/gmd" xmlns:ns5="http://www.isotc211.org/2005/gco" xmlns:ns6="http://www.isotc211.org/2005/gss" xmlns:ns7="http://www.isotc211.org/2005/gts" xmlns:ns8="http://www.isotc211.org/2005/gsr" xmlns:ns9="http://www.w3.org/2001/SMIL20/Language" srsName="EPSG:31467">
     <gml:coordinates ts="," decimal="." cs=" ">3929685.625 775342.375 370.8316877</gml:coordinates>
    </gml:Point>
   </gml:location>
   <commonShp:time>2008-12-09T11:31:31.047Z</commonShp:time>
   <commonShp:severity>warning</commonShp:severity>
   <commonShp:code>1000</commonShp:code>
   <commonShp:plugin>org.kalypso.model1d2d</commonShp:plugin>
   <commonShp:exception>rO0ABXA=</commonShp:exception>
  </commonShp:Status>
 </commonShp:statusMember>
 <commonShp:statusMember>
  <commonShp:Status gml:id="Status12288223056687">
   <gml:description>Schreibe Randbedingungen und Berechnungssteuerung</gml:description>
   <commonShp:time>2008-12-09T11:31:45.668Z</commonShp:time>
   <commonShp:severity>info</commonShp:severity>
   <commonShp:code>1</commonShp:code>
   <commonShp:plugin>org.kalypso.model1d2d</commonShp:plugin>
   <commonShp:exception>rO0ABXA=</commonShp:exception>
  </commonShp:Status>
 </commonShp:statusMember>
 <commonShp:statusMember>
  <commonShp:Status gml:id="Status12288223057598">
   <gml:description>Schreibe Bauwerke</gml:description>
   <commonShp:time>2008-12-09T11:31:45.759Z</commonShp:time>
   <commonShp:severity>info</commonShp:severity>
   <commonShp:code>1</commonShp:code>
   <commonShp:plugin>org.kalypso.model1d2d</commonShp:plugin>
   <commonShp:exception>rO0ABXA=</commonShp:exception>
  </commonShp:Status>
 </commonShp:statusMember>
 <commonShp:statusMember>
  <commonShp:Status gml:id="Status12288223057591">
   <gml:description>Schreibe W/Q-Randbedingungen</gml:description>
   <commonShp:time>2008-12-09T11:31:45.759Z</commonShp:time>
   <commonShp:severity>info</commonShp:severity>
   <commonShp:code>1</commonShp:code>
   <commonShp:plugin>org.kalypso.model1d2d</commonShp:plugin>
   <commonShp:exception>rO0ABXA=</commonShp:exception>
  </commonShp:Status>
 </commonShp:statusMember>
 <commonShp:statusMember>
  <commonShp:Status gml:id="Status12288223058049">
   <gml:description>RMA·Kalypso wird ausgeführt: D:\Kalypso_2_1_RC1\bin\rma-kalypso_1_1_0_20081208.exe</gml:description>
   <commonShp:time>2008-12-09T11:31:45.804Z</commonShp:time>
   <commonShp:severity>info</commonShp:severity>
   <commonShp:code>1</commonShp:code>
   <commonShp:plugin>org.kalypso.model1d2d</commonShp:plugin>
   <commonShp:exception>rO0ABXA=</commonShp:exception>
  </commonShp:Status>
 </commonShp:statusMember>
 <commonShp:statusMember>
  <commonShp:Status gml:id="Status122882240235511">
   <gml:description>Simulation erfolgreich beendet</gml:description>
   <commonShp:time>2008-12-09T11:33:22.355Z</commonShp:time>
   <commonShp:severity>ok</commonShp:severity>
   <commonShp:code>0</commonShp:code>
   <commonShp:plugin>org.kalypso.model1d2d</commonShp:plugin>
   <commonShp:exception>rO0ABXA=</commonShp:exception>
  </commonShp:Status>
 </commonShp:statusMember>
 <commonShp:statusMember>
  <commonShp:Status gml:id="Status12288224097173">
   <gml:description>Start der Ergebnisauswertung</gml:description>
   <commonShp:time>2008-12-09T11:33:29.717Z</commonShp:time>
   <commonShp:severity>info</commonShp:severity>
   <commonShp:code>0</commonShp:code>
   <commonShp:plugin>org.kalypso.model1d2d</commonShp:plugin>
   <commonShp:exception>rO0ABXA=</commonShp:exception>
  </commonShp:Status>
 </commonShp:statusMember>
 <commonShp:statusMember>
  <commonShp:Status gml:id="Status12288224097171">
   <gml:description>Bestehende Ergebnisse werden gelöscht.</gml:description>
   <commonShp:time>2008-12-09T11:33:29.717Z</commonShp:time>
   <commonShp:severity>info</commonShp:severity>
   <commonShp:code>1</commonShp:code>
   <commonShp:plugin>org.kalypso.model1d2d</commonShp:plugin>
   <commonShp:exception>rO0ABXA=</commonShp:exception>
  </commonShp:Status>
 </commonShp:statusMember>
 <commonShp:statusMember>
  <commonShp:Status gml:id="Status12288224098418">
   <gml:description>Ergebnisauswertung - steady</gml:description>
   <commonShp:time>2008-12-09T11:33:29.841Z</commonShp:time>
   <commonShp:severity>info</commonShp:severity>
   <commonShp:code>1</commonShp:code>
   <commonShp:plugin>org.kalypso.model1d2d</commonShp:plugin>
   <commonShp:exception>rO0ABXA=</commonShp:exception>
  </commonShp:Status>
 </commonShp:statusMember>
 <commonShp:statusMember>
  <commonShp:Status gml:id="Status12288224434482">
   <gml:description>Ergebnisauswertung - maxi</gml:description>
   <commonShp:time>2008-12-09T11:34:03.448Z</commonShp:time>
   <commonShp:severity>info</commonShp:severity>
   <commonShp:code>1</commonShp:code>
   <commonShp:plugin>org.kalypso.model1d2d</commonShp:plugin>
   <commonShp:exception>rO0ABXA=</commonShp:exception>
  </commonShp:Status>
 </commonShp:statusMember>
 <commonShp:statusMember>
  <commonShp:Status gml:id="Status122882246952313">
   <gml:description>Ergebnisauswertung - A0001</gml:description>
   <commonShp:time>2008-12-09T11:34:29.523Z</commonShp:time>
   <commonShp:severity>info</commonShp:severity>
   <commonShp:code>1</commonShp:code>
   <commonShp:plugin>org.kalypso.model1d2d</commonShp:plugin>
   <commonShp:exception>rO0ABXA=</commonShp:exception>
  </commonShp:Status>
 </commonShp:statusMember>
 <commonShp:statusMember>
  <commonShp:Status gml:id="Status12288224957532">
   <gml:description>Ergebnisauswertung - A0002</gml:description>
   <commonShp:time>2008-12-09T11:34:55.753Z</commonShp:time>
   <commonShp:severity>info</commonShp:severity>
   <commonShp:code>1</commonShp:code>
   <commonShp:plugin>org.kalypso.model1d2d</commonShp:plugin>
   <commonShp:exception>rO0ABXA=</commonShp:exception>
  </commonShp:Status>
 </commonShp:statusMember>
 <commonShp:statusMember>
  <commonShp:Status gml:id="Status12288225209167">
   <gml:description>Ergebnisauswertung - A0003</gml:description>
   <commonShp:time>2008-12-09T11:35:20.916Z</commonShp:time>
   <commonShp:severity>info</commonShp:severity>
   <commonShp:code>1</commonShp:code>
   <commonShp:plugin>org.kalypso.model1d2d</commonShp:plugin>
   <commonShp:exception>rO0ABXA=</commonShp:exception>
  </commonShp:Status>
 </commonShp:statusMember>
 <commonShp:statusMember>
  <commonShp:Status gml:id="Status12288225469449">
   <gml:description>Ergebnisauswertung - A0004</gml:description>
   <commonShp:time>2008-12-09T11:35:46.944Z</commonShp:time>
   <commonShp:severity>info</commonShp:severity>
   <commonShp:code>1</commonShp:code>
   <commonShp:plugin>org.kalypso.model1d2d</commonShp:plugin>
   <commonShp:exception>rO0ABXA=</commonShp:exception>
  </commonShp:Status>
 </commonShp:statusMember>
 <commonShp:statusMember>
  <commonShp:Status gml:id="Status12288225722159">
   <gml:description>Ergebnisauswertung - A0005</gml:description>
   <commonShp:time>2008-12-09T11:36:12.215Z</commonShp:time>
   <commonShp:severity>info</commonShp:severity>
   <commonShp:code>1</commonShp:code>
   <commonShp:plugin>org.kalypso.model1d2d</commonShp:plugin>
   <commonShp:exception>rO0ABXA=</commonShp:exception>
  </commonShp:Status>
 </commonShp:statusMember>
 <commonShp:statusMember>
  <commonShp:Status gml:id="Status12288225981988">
   <gml:description>Alle Ergebnisse wurden erfolgreich ausgewertet.</gml:description>
   <commonShp:time>2008-12-09T11:36:38.198Z</commonShp:time>
   <commonShp:severity>ok</commonShp:severity>
   <commonShp:code>3000</commonShp:code>
   <commonShp:plugin>org.kalypso.model1d2d</commonShp:plugin>
   <commonShp:exception>rO0ABXA=</commonShp:exception>
  </commonShp:Status>
 </commonShp:statusMember>
 <commonShp:statusMember>
  <commonShp:Status gml:id="Status122882259819813">
   <gml:description>Ergebnisse werden in Arbeitsbereich verschoben und Ergebnisdatenbank aktualisiert.</gml:description>
   <commonShp:time>2008-12-09T11:36:38.198Z</commonShp:time>
   <commonShp:severity>info</commonShp:severity>
   <commonShp:code>1</commonShp:code>
   <commonShp:plugin>org.kalypso.model1d2d</commonShp:plugin>
   <commonShp:exception>rO0ABXA=</commonShp:exception>
  </commonShp:Status>
 </commonShp:statusMember>
 <commonShp:statusMember>
  <commonShp:Status gml:id="Status12288225982448">
   <gml:description>Ergebnisauswertung erfolgreich beendet</gml:description>
   <commonShp:time>2008-12-09T11:36:38.244Z</commonShp:time>
   <commonShp:severity>ok</commonShp:severity>
   <commonShp:code>0</commonShp:code>
   <commonShp:plugin>org.kalypso.model1d2d</commonShp:plugin>
   <commonShp:exception>rO0ABXA=</commonShp:exception>
  </commonShp:Status>
 </commonShp:statusMember>
</commonShp:StatusCollection>
