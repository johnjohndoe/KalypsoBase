<?xml version="1.0" encoding="WINDOWS-1252"?>
<krrdm:RasterDataModel xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:gml="http://www.opengis.net/gml" xmlns:xs="http://www.w3.org/2001/XMLSchema-instance" xmlns:krrdm="http://www.tu-harburg.de/wb/kalypso/risk/schemata/rasterDataModel" gml:id="root">
 <krrdm:waterlevelCoverageCollection>
  <krrdm:AnnualCoverageCollection gml:id="AnnualCoverageCollection11946127359370">
   <krrdm:annualCoverageMember>
    <krrdm:AnnualCoverage gml:id="AnnualCoverage12331398389474">
     <gml:name>HQ100</gml:name>
     <cov:coverageMember xmlns:cov="org.kalypso.gml.common.coverage">
      <gml:RectifiedGridCoverage gml:id="RectifiedGridCoverage12331398389470">
       <gml:boundedBy>
        <gml:Envelope xmlns:ns3="http://www.w3.org/2001/SMIL20/" xmlns:swe="http://www.opengis.net/swe" xmlns:st="http://www.seegrid.csiro.au/xml/st" xmlns:ns1="http://www.isotc211.org/2005/gmd" xmlns:ns4="http://www.isotc211.org/2005/gco" xmlns:ns5="http://www.isotc211.org/2005/gss" xmlns:ns6="http://www.isotc211.org/2005/gts" xmlns:ns7="http://www.isotc211.org/2005/gsr" xmlns:ns8="http://www.w3.org/2001/SMIL20/Language" srsName="EPSG:31467">
         <gml:lowerCorner>3928742.313 773732.875</gml:lowerCorner>
         <gml:upperCorner>3931464.313 777886.875</gml:upperCorner>
        </gml:Envelope>
       </gml:boundedBy>
       <rectifiedGridDomain xmlns="http://www.opengis.net/gml">
        <gml:RectifiedGrid dimension="2">
         <gml:limits>
          <gml:GridEnvelope>
           <gml:low>0 0</gml:low>
           <gml:high>1362 2078</gml:high>
          </gml:GridEnvelope>
         </gml:limits>
         <gml:origin>
          <gml:Point srsName="EPSG:31467">
           <gml:pos>3928742.313 777886.875</gml:pos>
          </gml:Point>
         </gml:origin>
         <rgc:offsetVector xmlns:rgc="http://www.opengis.net/gml">2.0 0.0</rgc:offsetVector>
         <rgc:offsetVector xmlns:rgc="http://www.opengis.net/gml">0.0 -2.0</rgc:offsetVector>
        </gml:RectifiedGrid>
       </rectifiedGridDomain>
       <gml:rangeSet xmlns:ns3="http://www.w3.org/2001/SMIL20/" xmlns:swe="http://www.opengis.net/swe" xmlns:st="http://www.seegrid.csiro.au/xml/st" xmlns:ns1="http://www.isotc211.org/2005/gmd" xmlns:ns4="http://www.isotc211.org/2005/gco" xmlns:ns5="http://www.isotc211.org/2005/gss" xmlns:ns6="http://www.isotc211.org/2005/gts" xmlns:ns7="http://www.isotc211.org/2005/gsr" xmlns:ns8="http://www.w3.org/2001/SMIL20/Language">
        <gml:File>
         <gml:fileName>raster/input/HQ_100.asc.bin</gml:fileName>
         <gml:mimeType>image/bin</gml:mimeType>
        </gml:File>
       </gml:rangeSet>
       <gml:description>Importiert vonHQ_100.asc</gml:description>
       <gml:name>HQ_100.asc.bin</gml:name>
      </gml:RectifiedGridCoverage>
     </cov:coverageMember>
     <krrdm:annuality>100</krrdm:annuality>
    </krrdm:AnnualCoverage>
   </krrdm:annualCoverageMember>
   <krrdm:annualCoverageMember>
    <krrdm:AnnualCoverage gml:id="AnnualCoverage12331398778181">
     <gml:name>HQ2</gml:name>
     <cov:coverageMember xmlns:cov="org.kalypso.gml.common.coverage">
      <gml:RectifiedGridCoverage gml:id="RectifiedGridCoverage12331398778184">
       <gml:boundedBy>
        <gml:Envelope xmlns:ns3="http://www.w3.org/2001/SMIL20/" xmlns:swe="http://www.opengis.net/swe" xmlns:st="http://www.seegrid.csiro.au/xml/st" xmlns:ns1="http://www.isotc211.org/2005/gmd" xmlns:ns4="http://www.isotc211.org/2005/gco" xmlns:ns5="http://www.isotc211.org/2005/gss" xmlns:ns6="http://www.isotc211.org/2005/gts" xmlns:ns7="http://www.isotc211.org/2005/gsr" xmlns:ns8="http://www.w3.org/2001/SMIL20/Language" srsName="EPSG:31467">
         <gml:lowerCorner>3928742.313 773732.875</gml:lowerCorner>
         <gml:upperCorner>3931464.313 777886.875</gml:upperCorner>
        </gml:Envelope>
       </gml:boundedBy>
       <rectifiedGridDomain xmlns="http://www.opengis.net/gml">
        <gml:RectifiedGrid dimension="2">
         <gml:limits>
          <gml:GridEnvelope>
           <gml:low>0 0</gml:low>
           <gml:high>1362 2078</gml:high>
          </gml:GridEnvelope>
         </gml:limits>
         <gml:origin>
          <gml:Point srsName="EPSG:31467">
           <gml:pos>3928742.313 777886.875</gml:pos>
          </gml:Point>
         </gml:origin>
         <rgc:offsetVector xmlns:rgc="http://www.opengis.net/gml">2.0 0.0</rgc:offsetVector>
         <rgc:offsetVector xmlns:rgc="http://www.opengis.net/gml">0.0 -2.0</rgc:offsetVector>
        </gml:RectifiedGrid>
       </rectifiedGridDomain>
       <gml:rangeSet xmlns:ns3="http://www.w3.org/2001/SMIL20/" xmlns:swe="http://www.opengis.net/swe" xmlns:st="http://www.seegrid.csiro.au/xml/st" xmlns:ns1="http://www.isotc211.org/2005/gmd" xmlns:ns4="http://www.isotc211.org/2005/gco" xmlns:ns5="http://www.isotc211.org/2005/gss" xmlns:ns6="http://www.isotc211.org/2005/gts" xmlns:ns7="http://www.isotc211.org/2005/gsr" xmlns:ns8="http://www.w3.org/2001/SMIL20/Language">
        <gml:File>
         <gml:fileName>raster/input/HQ_2.asc.bin</gml:fileName>
         <gml:mimeType>image/bin</gml:mimeType>
        </gml:File>
       </gml:rangeSet>
       <gml:description>Importiert vonHQ_2.asc</gml:description>
       <gml:name>HQ_2.asc.bin</gml:name>
      </gml:RectifiedGridCoverage>
     </cov:coverageMember>
     <krrdm:annuality>2</krrdm:annuality>
    </krrdm:AnnualCoverage>
   </krrdm:annualCoverageMember>
   <krrdm:annualCoverageMember>
    <krrdm:AnnualCoverage gml:id="AnnualCoverage12331399161910">
     <gml:name>HQ5</gml:name>
     <cov:coverageMember xmlns:cov="org.kalypso.gml.common.coverage">
      <gml:RectifiedGridCoverage gml:id="RectifiedGridCoverage12331399161919">
       <gml:boundedBy>
        <gml:Envelope xmlns:ns3="http://www.w3.org/2001/SMIL20/" xmlns:swe="http://www.opengis.net/swe" xmlns:st="http://www.seegrid.csiro.au/xml/st" xmlns:ns1="http://www.isotc211.org/2005/gmd" xmlns:ns4="http://www.isotc211.org/2005/gco" xmlns:ns5="http://www.isotc211.org/2005/gss" xmlns:ns6="http://www.isotc211.org/2005/gts" xmlns:ns7="http://www.isotc211.org/2005/gsr" xmlns:ns8="http://www.w3.org/2001/SMIL20/Language" srsName="EPSG:31467">
         <gml:lowerCorner>3928742.313 773732.875</gml:lowerCorner>
         <gml:upperCorner>3931464.313 777886.875</gml:upperCorner>
        </gml:Envelope>
       </gml:boundedBy>
       <rectifiedGridDomain xmlns="http://www.opengis.net/gml">
        <gml:RectifiedGrid dimension="2">
         <gml:limits>
          <gml:GridEnvelope>
           <gml:low>0 0</gml:low>
           <gml:high>1362 2078</gml:high>
          </gml:GridEnvelope>
         </gml:limits>
         <gml:origin>
          <gml:Point srsName="EPSG:31467">
           <gml:pos>3928742.313 777886.875</gml:pos>
          </gml:Point>
         </gml:origin>
         <rgc:offsetVector xmlns:rgc="http://www.opengis.net/gml">2.0 0.0</rgc:offsetVector>
         <rgc:offsetVector xmlns:rgc="http://www.opengis.net/gml">0.0 -2.0</rgc:offsetVector>
        </gml:RectifiedGrid>
       </rectifiedGridDomain>
       <gml:rangeSet xmlns:ns3="http://www.w3.org/2001/SMIL20/" xmlns:swe="http://www.opengis.net/swe" xmlns:st="http://www.seegrid.csiro.au/xml/st" xmlns:ns1="http://www.isotc211.org/2005/gmd" xmlns:ns4="http://www.isotc211.org/2005/gco" xmlns:ns5="http://www.isotc211.org/2005/gss" xmlns:ns6="http://www.isotc211.org/2005/gts" xmlns:ns7="http://www.isotc211.org/2005/gsr" xmlns:ns8="http://www.w3.org/2001/SMIL20/Language">
        <gml:File>
         <gml:fileName>raster/input/HQ_5.asc.bin</gml:fileName>
         <gml:mimeType>image/bin</gml:mimeType>
        </gml:File>
       </gml:rangeSet>
       <gml:description>Importiert vonHQ_5.asc</gml:description>
       <gml:name>HQ_5.asc.bin</gml:name>
      </gml:RectifiedGridCoverage>
     </cov:coverageMember>
     <krrdm:annuality>5</krrdm:annuality>
    </krrdm:AnnualCoverage>
   </krrdm:annualCoverageMember>
   <krrdm:annualCoverageMember>
    <krrdm:AnnualCoverage gml:id="AnnualCoverage12331399553774">
     <gml:name>HQ10</gml:name>
     <cov:coverageMember xmlns:cov="org.kalypso.gml.common.coverage">
      <gml:RectifiedGridCoverage gml:id="RectifiedGridCoverage12331399553776">
       <gml:boundedBy>
        <gml:Envelope xmlns:ns3="http://www.w3.org/2001/SMIL20/" xmlns:swe="http://www.opengis.net/swe" xmlns:st="http://www.seegrid.csiro.au/xml/st" xmlns:ns1="http://www.isotc211.org/2005/gmd" xmlns:ns4="http://www.isotc211.org/2005/gco" xmlns:ns5="http://www.isotc211.org/2005/gss" xmlns:ns6="http://www.isotc211.org/2005/gts" xmlns:ns7="http://www.isotc211.org/2005/gsr" xmlns:ns8="http://www.w3.org/2001/SMIL20/Language" srsName="EPSG:31467">
         <gml:lowerCorner>3928742.313 773732.875</gml:lowerCorner>
         <gml:upperCorner>3931464.313 777886.875</gml:upperCorner>
        </gml:Envelope>
       </gml:boundedBy>
       <rectifiedGridDomain xmlns="http://www.opengis.net/gml">
        <gml:RectifiedGrid dimension="2">
         <gml:limits>
          <gml:GridEnvelope>
           <gml:low>0 0</gml:low>
           <gml:high>1362 2078</gml:high>
          </gml:GridEnvelope>
         </gml:limits>
         <gml:origin>
          <gml:Point srsName="EPSG:31467">
           <gml:pos>3928742.313 777886.875</gml:pos>
          </gml:Point>
         </gml:origin>
         <rgc:offsetVector xmlns:rgc="http://www.opengis.net/gml">2.0 0.0</rgc:offsetVector>
         <rgc:offsetVector xmlns:rgc="http://www.opengis.net/gml">0.0 -2.0</rgc:offsetVector>
        </gml:RectifiedGrid>
       </rectifiedGridDomain>
       <gml:rangeSet xmlns:ns3="http://www.w3.org/2001/SMIL20/" xmlns:swe="http://www.opengis.net/swe" xmlns:st="http://www.seegrid.csiro.au/xml/st" xmlns:ns1="http://www.isotc211.org/2005/gmd" xmlns:ns4="http://www.isotc211.org/2005/gco" xmlns:ns5="http://www.isotc211.org/2005/gss" xmlns:ns6="http://www.isotc211.org/2005/gts" xmlns:ns7="http://www.isotc211.org/2005/gsr" xmlns:ns8="http://www.w3.org/2001/SMIL20/Language">
        <gml:File>
         <gml:fileName>raster/input/HQ_10.asc.bin</gml:fileName>
         <gml:mimeType>image/bin</gml:mimeType>
        </gml:File>
       </gml:rangeSet>
       <gml:description>Importiert vonHQ_10.asc</gml:description>
       <gml:name>HQ_10.asc.bin</gml:name>
      </gml:RectifiedGridCoverage>
     </cov:coverageMember>
     <krrdm:annuality>10</krrdm:annuality>
    </krrdm:AnnualCoverage>
   </krrdm:annualCoverageMember>
   <krrdm:annualCoverageMember>
    <krrdm:AnnualCoverage gml:id="AnnualCoverage123313999387513">
     <gml:name>HQ20</gml:name>
     <cov:coverageMember xmlns:cov="org.kalypso.gml.common.coverage">
      <gml:RectifiedGridCoverage gml:id="RectifiedGridCoverage123313999387511">
       <gml:boundedBy>
        <gml:Envelope xmlns:ns3="http://www.w3.org/2001/SMIL20/" xmlns:swe="http://www.opengis.net/swe" xmlns:st="http://www.seegrid.csiro.au/xml/st" xmlns:ns1="http://www.isotc211.org/2005/gmd" xmlns:ns4="http://www.isotc211.org/2005/gco" xmlns:ns5="http://www.isotc211.org/2005/gss" xmlns:ns6="http://www.isotc211.org/2005/gts" xmlns:ns7="http://www.isotc211.org/2005/gsr" xmlns:ns8="http://www.w3.org/2001/SMIL20/Language" srsName="EPSG:31467">
         <gml:lowerCorner>3928742.313 773732.875</gml:lowerCorner>
         <gml:upperCorner>3931464.313 777886.875</gml:upperCorner>
        </gml:Envelope>
       </gml:boundedBy>
       <rectifiedGridDomain xmlns="http://www.opengis.net/gml">
        <gml:RectifiedGrid dimension="2">
         <gml:limits>
          <gml:GridEnvelope>
           <gml:low>0 0</gml:low>
           <gml:high>1362 2078</gml:high>
          </gml:GridEnvelope>
         </gml:limits>
         <gml:origin>
          <gml:Point srsName="EPSG:31467">
           <gml:pos>3928742.313 777886.875</gml:pos>
          </gml:Point>
         </gml:origin>
         <rgc:offsetVector xmlns:rgc="http://www.opengis.net/gml">2.0 0.0</rgc:offsetVector>
         <rgc:offsetVector xmlns:rgc="http://www.opengis.net/gml">0.0 -2.0</rgc:offsetVector>
        </gml:RectifiedGrid>
       </rectifiedGridDomain>
       <gml:rangeSet xmlns:ns3="http://www.w3.org/2001/SMIL20/" xmlns:swe="http://www.opengis.net/swe" xmlns:st="http://www.seegrid.csiro.au/xml/st" xmlns:ns1="http://www.isotc211.org/2005/gmd" xmlns:ns4="http://www.isotc211.org/2005/gco" xmlns:ns5="http://www.isotc211.org/2005/gss" xmlns:ns6="http://www.isotc211.org/2005/gts" xmlns:ns7="http://www.isotc211.org/2005/gsr" xmlns:ns8="http://www.w3.org/2001/SMIL20/Language">
        <gml:File>
         <gml:fileName>raster/input/HQ_20.asc.bin</gml:fileName>
         <gml:mimeType>image/bin</gml:mimeType>
        </gml:File>
       </gml:rangeSet>
       <gml:description>Importiert vonHQ_20.asc</gml:description>
       <gml:name>HQ_20.asc.bin</gml:name>
      </gml:RectifiedGridCoverage>
     </cov:coverageMember>
     <krrdm:annuality>20</krrdm:annuality>
    </krrdm:AnnualCoverage>
   </krrdm:annualCoverageMember>
  </krrdm:AnnualCoverageCollection>
 </krrdm:waterlevelCoverageCollection>
 <krrdm:specificDamageCoverageCollection>
  <krrdm:AnnualCoverageCollection gml:id="AnnualCoverageCollection11946127768432">
   <krrdm:annualCoverageMember>
    <krrdm:AnnualCoverage gml:id="AnnualCoverage123314686955717">
     <cov:coverageMember xmlns:cov="org.kalypso.gml.common.coverage">
      <gml:RectifiedGridCoverage gml:id="RectifiedGridCoverage123314704627511">
       <gml:boundedBy>
        <gml:Envelope xmlns:ns3="http://www.w3.org/2001/SMIL20/" xmlns:swe="http://www.opengis.net/swe" xmlns:st="http://www.seegrid.csiro.au/xml/st" xmlns:ns1="http://www.isotc211.org/2005/gmd" xmlns:ns4="http://www.isotc211.org/2005/gco" xmlns:ns5="http://www.isotc211.org/2005/gss" xmlns:ns6="http://www.isotc211.org/2005/gts" xmlns:ns7="http://www.isotc211.org/2005/gsr" xmlns:ns8="http://www.w3.org/2001/SMIL20/Language" srsName="EPSG:31467">
         <gml:lowerCorner>3928742.313 773732.875</gml:lowerCorner>
         <gml:upperCorner>3931464.313 777886.875</gml:upperCorner>
        </gml:Envelope>
       </gml:boundedBy>
       <rectifiedGridDomain xmlns="http://www.opengis.net/gml">
        <gml:RectifiedGrid dimension="2">
         <gml:limits>
          <gml:GridEnvelope>
           <gml:low>0 0</gml:low>
           <gml:high>1362 2078</gml:high>
          </gml:GridEnvelope>
         </gml:limits>
         <gml:origin>
          <gml:Point srsName="EPSG:31467">
           <gml:pos>3928742.313 777886.875</gml:pos>
          </gml:Point>
         </gml:origin>
         <rgc:offsetVector xmlns:rgc="http://www.opengis.net/gml">2.0 0.0</rgc:offsetVector>
         <rgc:offsetVector xmlns:rgc="http://www.opengis.net/gml">0.0 -2.0</rgc:offsetVector>
        </gml:RectifiedGrid>
       </rectifiedGridDomain>
       <gml:rangeSet xmlns:ns3="http://www.w3.org/2001/SMIL20/" xmlns:swe="http://www.opengis.net/swe" xmlns:st="http://www.seegrid.csiro.au/xml/st" xmlns:ns1="http://www.isotc211.org/2005/gmd" xmlns:ns4="http://www.isotc211.org/2005/gco" xmlns:ns5="http://www.isotc211.org/2005/gss" xmlns:ns6="http://www.isotc211.org/2005/gts" xmlns:ns7="http://www.isotc211.org/2005/gsr" xmlns:ns8="http://www.w3.org/2001/SMIL20/Language">
        <gml:File>
         <gml:fileName>raster/output/specificDamage_HQ100_part0.bin</gml:fileName>
         <gml:fileStructure>Record Interleaved</gml:fileStructure>
         <gml:mimeType>image/bin</gml:mimeType>
        </gml:File>
       </gml:rangeSet>
       <gml:description>!erstellt am!Wed Jan 28 13:50:46 CET 2009</gml:description>
       <gml:name>!Spezifischer Schaden!100 [0]</gml:name>
      </gml:RectifiedGridCoverage>
     </cov:coverageMember>
     <krrdm:annuality>100</krrdm:annuality>
    </krrdm:AnnualCoverage>
   </krrdm:annualCoverageMember>
   <krrdm:annualCoverageMember>
    <krrdm:AnnualCoverage gml:id="AnnualCoverage12331470462753">
     <cov:coverageMember xmlns:cov="org.kalypso.gml.common.coverage">
      <gml:RectifiedGridCoverage gml:id="RectifiedGridCoverage12331472047136">
       <gml:boundedBy>
        <gml:Envelope xmlns:ns3="http://www.w3.org/2001/SMIL20/" xmlns:swe="http://www.opengis.net/swe" xmlns:st="http://www.seegrid.csiro.au/xml/st" xmlns:ns1="http://www.isotc211.org/2005/gmd" xmlns:ns4="http://www.isotc211.org/2005/gco" xmlns:ns5="http://www.isotc211.org/2005/gss" xmlns:ns6="http://www.isotc211.org/2005/gts" xmlns:ns7="http://www.isotc211.org/2005/gsr" xmlns:ns8="http://www.w3.org/2001/SMIL20/Language" srsName="EPSG:31467">
         <gml:lowerCorner>3928742.313 773732.875</gml:lowerCorner>
         <gml:upperCorner>3931464.313 777886.875</gml:upperCorner>
        </gml:Envelope>
       </gml:boundedBy>
       <rectifiedGridDomain xmlns="http://www.opengis.net/gml">
        <gml:RectifiedGrid dimension="2">
         <gml:limits>
          <gml:GridEnvelope>
           <gml:low>0 0</gml:low>
           <gml:high>1362 2078</gml:high>
          </gml:GridEnvelope>
         </gml:limits>
         <gml:origin>
          <gml:Point srsName="EPSG:31467">
           <gml:pos>3928742.313 777886.875</gml:pos>
          </gml:Point>
         </gml:origin>
         <rgc:offsetVector xmlns:rgc="http://www.opengis.net/gml">2.0 0.0</rgc:offsetVector>
         <rgc:offsetVector xmlns:rgc="http://www.opengis.net/gml">0.0 -2.0</rgc:offsetVector>
        </gml:RectifiedGrid>
       </rectifiedGridDomain>
       <gml:rangeSet xmlns:ns3="http://www.w3.org/2001/SMIL20/" xmlns:swe="http://www.opengis.net/swe" xmlns:st="http://www.seegrid.csiro.au/xml/st" xmlns:ns1="http://www.isotc211.org/2005/gmd" xmlns:ns4="http://www.isotc211.org/2005/gco" xmlns:ns5="http://www.isotc211.org/2005/gss" xmlns:ns6="http://www.isotc211.org/2005/gts" xmlns:ns7="http://www.isotc211.org/2005/gsr" xmlns:ns8="http://www.w3.org/2001/SMIL20/Language">
        <gml:File>
         <gml:fileName>raster/output/specificDamage_HQ2_part0.bin</gml:fileName>
         <gml:fileStructure>Record Interleaved</gml:fileStructure>
         <gml:mimeType>image/bin</gml:mimeType>
        </gml:File>
       </gml:rangeSet>
       <gml:description>!erstellt am!Wed Jan 28 13:53:24 CET 2009</gml:description>
       <gml:name>!Spezifischer Schaden!2 [0]</gml:name>
      </gml:RectifiedGridCoverage>
     </cov:coverageMember>
     <krrdm:annuality>2</krrdm:annuality>
    </krrdm:AnnualCoverage>
   </krrdm:annualCoverageMember>
   <krrdm:annualCoverageMember>
    <krrdm:AnnualCoverage gml:id="AnnualCoverage12331472047133">
     <cov:coverageMember xmlns:cov="org.kalypso.gml.common.coverage">
      <gml:RectifiedGridCoverage gml:id="RectifiedGridCoverage123314738071315">
       <gml:boundedBy>
        <gml:Envelope xmlns:ns3="http://www.w3.org/2001/SMIL20/" xmlns:swe="http://www.opengis.net/swe" xmlns:st="http://www.seegrid.csiro.au/xml/st" xmlns:ns1="http://www.isotc211.org/2005/gmd" xmlns:ns4="http://www.isotc211.org/2005/gco" xmlns:ns5="http://www.isotc211.org/2005/gss" xmlns:ns6="http://www.isotc211.org/2005/gts" xmlns:ns7="http://www.isotc211.org/2005/gsr" xmlns:ns8="http://www.w3.org/2001/SMIL20/Language" srsName="EPSG:31467">
         <gml:lowerCorner>3928742.313 773732.875</gml:lowerCorner>
         <gml:upperCorner>3931464.313 777886.875</gml:upperCorner>
        </gml:Envelope>
       </gml:boundedBy>
       <rectifiedGridDomain xmlns="http://www.opengis.net/gml">
        <gml:RectifiedGrid dimension="2">
         <gml:limits>
          <gml:GridEnvelope>
           <gml:low>0 0</gml:low>
           <gml:high>1362 2078</gml:high>
          </gml:GridEnvelope>
         </gml:limits>
         <gml:origin>
          <gml:Point srsName="EPSG:31467">
           <gml:pos>3928742.313 777886.875</gml:pos>
          </gml:Point>
         </gml:origin>
         <rgc:offsetVector xmlns:rgc="http://www.opengis.net/gml">2.0 0.0</rgc:offsetVector>
         <rgc:offsetVector xmlns:rgc="http://www.opengis.net/gml">0.0 -2.0</rgc:offsetVector>
        </gml:RectifiedGrid>
       </rectifiedGridDomain>
       <gml:rangeSet xmlns:ns3="http://www.w3.org/2001/SMIL20/" xmlns:swe="http://www.opengis.net/swe" xmlns:st="http://www.seegrid.csiro.au/xml/st" xmlns:ns1="http://www.isotc211.org/2005/gmd" xmlns:ns4="http://www.isotc211.org/2005/gco" xmlns:ns5="http://www.isotc211.org/2005/gss" xmlns:ns6="http://www.isotc211.org/2005/gts" xmlns:ns7="http://www.isotc211.org/2005/gsr" xmlns:ns8="http://www.w3.org/2001/SMIL20/Language">
        <gml:File>
         <gml:fileName>raster/output/specificDamage_HQ5_part0.bin</gml:fileName>
         <gml:fileStructure>Record Interleaved</gml:fileStructure>
         <gml:mimeType>image/bin</gml:mimeType>
        </gml:File>
       </gml:rangeSet>
       <gml:description>!erstellt am!Wed Jan 28 13:56:20 CET 2009</gml:description>
       <gml:name>!Spezifischer Schaden!5 [0]</gml:name>
      </gml:RectifiedGridCoverage>
     </cov:coverageMember>
     <krrdm:annuality>5</krrdm:annuality>
    </krrdm:AnnualCoverage>
   </krrdm:annualCoverageMember>
   <krrdm:annualCoverageMember>
    <krrdm:AnnualCoverage gml:id="AnnualCoverage123314738072822">
     <cov:coverageMember xmlns:cov="org.kalypso.gml.common.coverage">
      <gml:RectifiedGridCoverage gml:id="RectifiedGridCoverage12331475689464">
       <gml:boundedBy>
        <gml:Envelope xmlns:ns3="http://www.w3.org/2001/SMIL20/" xmlns:swe="http://www.opengis.net/swe" xmlns:st="http://www.seegrid.csiro.au/xml/st" xmlns:ns1="http://www.isotc211.org/2005/gmd" xmlns:ns4="http://www.isotc211.org/2005/gco" xmlns:ns5="http://www.isotc211.org/2005/gss" xmlns:ns6="http://www.isotc211.org/2005/gts" xmlns:ns7="http://www.isotc211.org/2005/gsr" xmlns:ns8="http://www.w3.org/2001/SMIL20/Language" srsName="EPSG:31467">
         <gml:lowerCorner>3928742.313 773732.875</gml:lowerCorner>
         <gml:upperCorner>3931464.313 777886.875</gml:upperCorner>
        </gml:Envelope>
       </gml:boundedBy>
       <rectifiedGridDomain xmlns="http://www.opengis.net/gml">
        <gml:RectifiedGrid dimension="2">
         <gml:limits>
          <gml:GridEnvelope>
           <gml:low>0 0</gml:low>
           <gml:high>1362 2078</gml:high>
          </gml:GridEnvelope>
         </gml:limits>
         <gml:origin>
          <gml:Point srsName="EPSG:31467">
           <gml:pos>3928742.313 777886.875</gml:pos>
          </gml:Point>
         </gml:origin>
         <rgc:offsetVector xmlns:rgc="http://www.opengis.net/gml">2.0 0.0</rgc:offsetVector>
         <rgc:offsetVector xmlns:rgc="http://www.opengis.net/gml">0.0 -2.0</rgc:offsetVector>
        </gml:RectifiedGrid>
       </rectifiedGridDomain>
       <gml:rangeSet xmlns:ns3="http://www.w3.org/2001/SMIL20/" xmlns:swe="http://www.opengis.net/swe" xmlns:st="http://www.seegrid.csiro.au/xml/st" xmlns:ns1="http://www.isotc211.org/2005/gmd" xmlns:ns4="http://www.isotc211.org/2005/gco" xmlns:ns5="http://www.isotc211.org/2005/gss" xmlns:ns6="http://www.isotc211.org/2005/gts" xmlns:ns7="http://www.isotc211.org/2005/gsr" xmlns:ns8="http://www.w3.org/2001/SMIL20/Language">
        <gml:File>
         <gml:fileName>raster/output/specificDamage_HQ10_part0.bin</gml:fileName>
         <gml:fileStructure>Record Interleaved</gml:fileStructure>
         <gml:mimeType>image/bin</gml:mimeType>
        </gml:File>
       </gml:rangeSet>
       <gml:description>!erstellt am!Wed Jan 28 13:59:28 CET 2009</gml:description>
       <gml:name>!Spezifischer Schaden!10 [0]</gml:name>
      </gml:RectifiedGridCoverage>
     </cov:coverageMember>
     <krrdm:annuality>10</krrdm:annuality>
    </krrdm:AnnualCoverage>
   </krrdm:annualCoverageMember>
   <krrdm:annualCoverageMember>
    <krrdm:AnnualCoverage gml:id="AnnualCoverage123314756894624">
     <cov:coverageMember xmlns:cov="org.kalypso.gml.common.coverage">
      <gml:RectifiedGridCoverage gml:id="RectifiedGridCoverage12331477606636">
       <gml:boundedBy>
        <gml:Envelope xmlns:ns3="http://www.w3.org/2001/SMIL20/" xmlns:swe="http://www.opengis.net/swe" xmlns:st="http://www.seegrid.csiro.au/xml/st" xmlns:ns1="http://www.isotc211.org/2005/gmd" xmlns:ns4="http://www.isotc211.org/2005/gco" xmlns:ns5="http://www.isotc211.org/2005/gss" xmlns:ns6="http://www.isotc211.org/2005/gts" xmlns:ns7="http://www.isotc211.org/2005/gsr" xmlns:ns8="http://www.w3.org/2001/SMIL20/Language" srsName="EPSG:31467">
         <gml:lowerCorner>3928742.313 773732.875</gml:lowerCorner>
         <gml:upperCorner>3931464.313 777886.875</gml:upperCorner>
        </gml:Envelope>
       </gml:boundedBy>
       <rectifiedGridDomain xmlns="http://www.opengis.net/gml">
        <gml:RectifiedGrid dimension="2">
         <gml:limits>
          <gml:GridEnvelope>
           <gml:low>0 0</gml:low>
           <gml:high>1362 2078</gml:high>
          </gml:GridEnvelope>
         </gml:limits>
         <gml:origin>
          <gml:Point srsName="EPSG:31467">
           <gml:pos>3928742.313 777886.875</gml:pos>
          </gml:Point>
         </gml:origin>
         <rgc:offsetVector xmlns:rgc="http://www.opengis.net/gml">2.0 0.0</rgc:offsetVector>
         <rgc:offsetVector xmlns:rgc="http://www.opengis.net/gml">0.0 -2.0</rgc:offsetVector>
        </gml:RectifiedGrid>
       </rectifiedGridDomain>
       <gml:rangeSet xmlns:ns3="http://www.w3.org/2001/SMIL20/" xmlns:swe="http://www.opengis.net/swe" xmlns:st="http://www.seegrid.csiro.au/xml/st" xmlns:ns1="http://www.isotc211.org/2005/gmd" xmlns:ns4="http://www.isotc211.org/2005/gco" xmlns:ns5="http://www.isotc211.org/2005/gss" xmlns:ns6="http://www.isotc211.org/2005/gts" xmlns:ns7="http://www.isotc211.org/2005/gsr" xmlns:ns8="http://www.w3.org/2001/SMIL20/Language">
        <gml:File>
         <gml:fileName>raster/output/specificDamage_HQ20_part0.bin</gml:fileName>
         <gml:fileStructure>Record Interleaved</gml:fileStructure>
         <gml:mimeType>image/bin</gml:mimeType>
        </gml:File>
       </gml:rangeSet>
       <gml:description>!erstellt am!Wed Jan 28 14:02:40 CET 2009</gml:description>
       <gml:name>!Spezifischer Schaden!20 [0]</gml:name>
      </gml:RectifiedGridCoverage>
     </cov:coverageMember>
     <krrdm:annuality>20</krrdm:annuality>
    </krrdm:AnnualCoverage>
   </krrdm:annualCoverageMember>
  </krrdm:AnnualCoverageCollection>
 </krrdm:specificDamageCoverageCollection>
 <krrdm:landuseCoverage>
  <cov:CoverageCollection xmlns:cov="org.kalypso.gml.common.coverage" gml:id="CoverageCollection11946128251872">
   <cov:coverageMember>
    <gml:RectifiedGridCoverage gml:id="RectifiedGridCoverage12331468101973">
     <gml:boundedBy>
      <gml:Envelope xmlns:ns3="http://www.w3.org/2001/SMIL20/" xmlns:swe="http://www.opengis.net/swe" xmlns:st="http://www.seegrid.csiro.au/xml/st" xmlns:ns1="http://www.isotc211.org/2005/gmd" xmlns:ns4="http://www.isotc211.org/2005/gco" xmlns:ns5="http://www.isotc211.org/2005/gss" xmlns:ns6="http://www.isotc211.org/2005/gts" xmlns:ns7="http://www.isotc211.org/2005/gsr" xmlns:ns8="http://www.w3.org/2001/SMIL20/Language" srsName="EPSG:31467">
       <gml:lowerCorner>3928742.313 773732.875</gml:lowerCorner>
       <gml:upperCorner>3931464.313 777886.875</gml:upperCorner>
      </gml:Envelope>
     </gml:boundedBy>
     <rectifiedGridDomain xmlns="http://www.opengis.net/gml">
      <gml:RectifiedGrid dimension="2">
       <gml:limits>
        <gml:GridEnvelope>
         <gml:low>0 0</gml:low>
         <gml:high>1362 2078</gml:high>
        </gml:GridEnvelope>
       </gml:limits>
       <gml:origin>
        <gml:Point srsName="EPSG:31467">
         <gml:pos>3928742.313 777886.875</gml:pos>
        </gml:Point>
       </gml:origin>
       <rgc:offsetVector xmlns:rgc="http://www.opengis.net/gml">2.0 0.0</rgc:offsetVector>
       <rgc:offsetVector xmlns:rgc="http://www.opengis.net/gml">0.0 -2.0</rgc:offsetVector>
      </gml:RectifiedGrid>
     </rectifiedGridDomain>
     <gml:rangeSet xmlns:ns3="http://www.w3.org/2001/SMIL20/" xmlns:swe="http://www.opengis.net/swe" xmlns:st="http://www.seegrid.csiro.au/xml/st" xmlns:ns1="http://www.isotc211.org/2005/gmd" xmlns:ns4="http://www.isotc211.org/2005/gco" xmlns:ns5="http://www.isotc211.org/2005/gss" xmlns:ns6="http://www.isotc211.org/2005/gts" xmlns:ns7="http://www.isotc211.org/2005/gsr" xmlns:ns8="http://www.w3.org/2001/SMIL20/Language">
      <gml:File>
       <gml:fileName>raster/output/LanduseCoverage0.dat</gml:fileName>
       <gml:fileStructure>Record Interleaved</gml:fileStructure>
       <gml:mimeType>image/bin</gml:mimeType>
      </gml:File>
     </gml:rangeSet>
     <gml:description>Imported via Kalypso</gml:description>
    </gml:RectifiedGridCoverage>
   </cov:coverageMember>
  </cov:CoverageCollection>
 </krrdm:landuseCoverage>
 <krrdm:riskZonesCoverage>
  <cov:CoverageCollection xmlns:cov="org.kalypso.gml.common.coverage" gml:id="CoverageCollection11946128304061">
   <cov:coverageMember>
    <gml:RectifiedGridCoverage gml:id="RectifiedGridCoverage123314914890522">
     <gml:boundedBy>
      <gml:Envelope xmlns:ns3="http://www.w3.org/2001/SMIL20/" xmlns:swe="http://www.opengis.net/swe" xmlns:st="http://www.seegrid.csiro.au/xml/st" xmlns:ns1="http://www.isotc211.org/2005/gmd" xmlns:ns4="http://www.isotc211.org/2005/gco" xmlns:ns5="http://www.isotc211.org/2005/gss" xmlns:ns6="http://www.isotc211.org/2005/gts" xmlns:ns7="http://www.isotc211.org/2005/gsr" xmlns:ns8="http://www.w3.org/2001/SMIL20/Language" srsName="EPSG:31467">
       <gml:lowerCorner>3928742.313 773732.875</gml:lowerCorner>
       <gml:upperCorner>3931464.313 777886.875</gml:upperCorner>
      </gml:Envelope>
     </gml:boundedBy>
     <rectifiedGridDomain xmlns="http://www.opengis.net/gml">
      <gml:RectifiedGrid dimension="2">
       <gml:limits>
        <gml:GridEnvelope>
         <gml:low>0 0</gml:low>
         <gml:high>1362 2078</gml:high>
        </gml:GridEnvelope>
       </gml:limits>
       <gml:origin>
        <gml:Point srsName="EPSG:31467">
         <gml:pos>3928742.313 777886.875</gml:pos>
        </gml:Point>
       </gml:origin>
       <rgc:offsetVector xmlns:rgc="http://www.opengis.net/gml">2.0 0.0</rgc:offsetVector>
       <rgc:offsetVector xmlns:rgc="http://www.opengis.net/gml">0.0 -2.0</rgc:offsetVector>
      </gml:RectifiedGrid>
     </rectifiedGridDomain>
     <gml:rangeSet xmlns:ns3="http://www.w3.org/2001/SMIL20/" xmlns:swe="http://www.opengis.net/swe" xmlns:st="http://www.seegrid.csiro.au/xml/st" xmlns:ns1="http://www.isotc211.org/2005/gmd" xmlns:ns4="http://www.isotc211.org/2005/gco" xmlns:ns5="http://www.isotc211.org/2005/gss" xmlns:ns6="http://www.isotc211.org/2005/gts" xmlns:ns7="http://www.isotc211.org/2005/gsr" xmlns:ns8="http://www.w3.org/2001/SMIL20/Language">
      <gml:File>
       <gml:fileName>raster/output/RiskZonesCoverage0.dat</gml:fileName>
       <gml:fileStructure>Record Interleaved</gml:fileStructure>
       <gml:mimeType>image/bin</gml:mimeType>
      </gml:File>
     </gml:rangeSet>
     <gml:description>erstellt amWed Jan 28 14:25:48 CET 2009</gml:description>
     <gml:name>Risikozonen [0]</gml:name>
    </gml:RectifiedGridCoverage>
   </cov:coverageMember>
  </cov:CoverageCollection>
 </krrdm:riskZonesCoverage>
</krrdm:RasterDataModel>
