<?xml version="1.0" encoding="WINDOWS-1252"?>
<krrcm:RasterizationControlModel xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:gml="http://www.opengis.net/gml" xmlns:xs="http://www.w3.org/2001/XMLSchema-instance" xmlns:krrcm="http://www.tu-harburg.de/wb/kalypso/risk/schemata/rasterizationControlModel" xmlns:swe="http://www.opengis.net/swe" gml:id="root">
 <krrcm:landuseClassMember>
  <krrcm:LanduseClass gml:id="LanduseClass123314195663216">
   <krrcm:name>light developed area</krrcm:name>
   <krrcm:description>angelegt auf Grundlage der importierten Landnutzung</krrcm:description>
   <krrcm:ordinalNumber>10</krrcm:ordinalNumber>
   <krrcm:damageFunctionLink xlink:href="#DamageFunction123314195663219"/>
   <krrcm:landuseRiskTypeLink xlink:href="#LanduseRiskType119462338753110"/>
   <krrcm:AssetValueClassLink xlink:href="#AssetValueClass123314195663219"/>
   <krrcm:colorStyle>#88fcd9</krrcm:colorStyle>
   <krrcm:minDamage>0.0</krrcm:minDamage>
   <krrcm:maxDamage>0.0</krrcm:maxDamage>
   <krrcm:averageAnnualDamage>0.0</krrcm:averageAnnualDamage>
   <krrcm:totalDamage>0.0</krrcm:totalDamage>
  </krrcm:LanduseClass>
 </krrcm:landuseClassMember>
 <krrcm:landuseClassMember xmlns:kr_common="http://www.tu-harburg.de/wb/kalypso/risk/schemata/common">
  <krrcm:LanduseClass gml:id="LanduseClass123314195663214">
   <krrcm:name>dense vegetation area</krrcm:name>
   <krrcm:description>angelegt auf Grundlage der importierten Landnutzung</krrcm:description>
   <krrcm:ordinalNumber>11</krrcm:ordinalNumber>
   <krrcm:damageFunctionLink xlink:href="#DamageFunction12331419566326"/>
   <krrcm:landuseRiskTypeLink xlink:href="#LanduseRiskType11946232986252"/>
   <krrcm:AssetValueClassLink xlink:href="#AssetValueClass12331419566325"/>
   <krrcm:colorStyle>#f0059c</krrcm:colorStyle>
   <krrcm:statisticClassMember>
    <krrcm:StatisticClass gml:id="StatisticClass123314691557226">
     <gml:description>Statistik f�r das Ereignis mit der J�hrlichkeit100 [a]</gml:description>
     <gml:name>HQ100</gml:name>
     <krrcm:statReturnPeriod>100</krrcm:statReturnPeriod>
     <krrcm:statMinDamage>0.01</krrcm:statMinDamage>
     <krrcm:statMaxDamage>0.01</krrcm:statMaxDamage>
     <krrcm:statAverageDamage>0.01</krrcm:statAverageDamage>
     <krrcm:statAverageAnnualDamage>0.0</krrcm:statAverageAnnualDamage>
     <krrcm:statSumDamage>172.73</krrcm:statSumDamage>
     <krrcm:statTotalDamage>690.9200</krrcm:statTotalDamage>
     <krrcm:statFloodedArea>69092.00</krrcm:statFloodedArea>
    </krrcm:StatisticClass>
   </krrcm:statisticClassMember>
   <krrcm:statisticClassMember>
    <krrcm:StatisticClass gml:id="StatisticClass12331470917758">
     <gml:description>Statistik f�r das Ereignis mit der J�hrlichkeit2 [a]</gml:description>
     <gml:name>HQ2</gml:name>
     <krrcm:statReturnPeriod>2</krrcm:statReturnPeriod>
     <krrcm:statMinDamage>0.01</krrcm:statMinDamage>
     <krrcm:statMaxDamage>0.01</krrcm:statMaxDamage>
     <krrcm:statAverageDamage>0.01</krrcm:statAverageDamage>
     <krrcm:statAverageAnnualDamage>0.0</krrcm:statAverageAnnualDamage>
     <krrcm:statSumDamage>143.04</krrcm:statSumDamage>
     <krrcm:statTotalDamage>572.1600</krrcm:statTotalDamage>
     <krrcm:statFloodedArea>57216.00</krrcm:statFloodedArea>
    </krrcm:StatisticClass>
   </krrcm:statisticClassMember>
   <krrcm:statisticClassMember>
    <krrcm:StatisticClass gml:id="StatisticClass12331472503386">
     <gml:description>Statistik f�r das Ereignis mit der J�hrlichkeit5 [a]</gml:description>
     <gml:name>HQ5</gml:name>
     <krrcm:statReturnPeriod>5</krrcm:statReturnPeriod>
     <krrcm:statMinDamage>0.01</krrcm:statMinDamage>
     <krrcm:statMaxDamage>0.01</krrcm:statMaxDamage>
     <krrcm:statAverageDamage>0.01</krrcm:statAverageDamage>
     <krrcm:statAverageAnnualDamage>0.0</krrcm:statAverageAnnualDamage>
     <krrcm:statSumDamage>154.23</krrcm:statSumDamage>
     <krrcm:statTotalDamage>616.9200</krrcm:statTotalDamage>
     <krrcm:statFloodedArea>61692.00</krrcm:statFloodedArea>
    </krrcm:StatisticClass>
   </krrcm:statisticClassMember>
   <krrcm:statisticClassMember>
    <krrcm:StatisticClass gml:id="StatisticClass12331474297444">
     <gml:description>Statistik f�r das Ereignis mit der J�hrlichkeit10 [a]</gml:description>
     <gml:name>HQ10</gml:name>
     <krrcm:statReturnPeriod>10</krrcm:statReturnPeriod>
     <krrcm:statMinDamage>0.01</krrcm:statMinDamage>
     <krrcm:statMaxDamage>0.01</krrcm:statMaxDamage>
     <krrcm:statAverageDamage>0.01</krrcm:statAverageDamage>
     <krrcm:statAverageAnnualDamage>0.0</krrcm:statAverageAnnualDamage>
     <krrcm:statSumDamage>163.94</krrcm:statSumDamage>
     <krrcm:statTotalDamage>655.7600</krrcm:statTotalDamage>
     <krrcm:statFloodedArea>65576.00</krrcm:statFloodedArea>
    </krrcm:StatisticClass>
   </krrcm:statisticClassMember>
   <krrcm:statisticClassMember>
    <krrcm:StatisticClass gml:id="StatisticClass123314762003928">
     <gml:description>Statistik f�r das Ereignis mit der J�hrlichkeit20 [a]</gml:description>
     <gml:name>HQ20</gml:name>
     <krrcm:statReturnPeriod>20</krrcm:statReturnPeriod>
     <krrcm:statMinDamage>0.01</krrcm:statMinDamage>
     <krrcm:statMaxDamage>0.01</krrcm:statMaxDamage>
     <krrcm:statAverageDamage>0.01</krrcm:statAverageDamage>
     <krrcm:statAverageAnnualDamage>0.0</krrcm:statAverageAnnualDamage>
     <krrcm:statSumDamage>169.86</krrcm:statSumDamage>
     <krrcm:statTotalDamage>679.4400</krrcm:statTotalDamage>
     <krrcm:statFloodedArea>67944.00</krrcm:statFloodedArea>
    </krrcm:StatisticClass>
   </krrcm:statisticClassMember>
   <krrcm:minDamage>0.004900000000000001</krrcm:minDamage>
   <krrcm:maxDamage>2.0E-4</krrcm:maxDamage>
   <krrcm:averageAnnualDamage>0.004900000000000001</krrcm:averageAnnualDamage>
   <krrcm:totalDamage>8.0E-4</krrcm:totalDamage>
  </krrcm:LanduseClass>
 </krrcm:landuseClassMember>
 <krrcm:landuseClassMember>
  <krrcm:LanduseClass gml:id="LanduseClass12331419566323">
   <krrcm:name>no data</krrcm:name>
   <krrcm:description>angelegt auf Grundlage der importierten Landnutzung</krrcm:description>
   <krrcm:ordinalNumber>12</krrcm:ordinalNumber>
   <krrcm:colorStyle>#ded5c1</krrcm:colorStyle>
   <krrcm:minDamage>0.0</krrcm:minDamage>
   <krrcm:maxDamage>0.0</krrcm:maxDamage>
   <krrcm:averageAnnualDamage>0.0</krrcm:averageAnnualDamage>
   <krrcm:totalDamage>0.0</krrcm:totalDamage>
  </krrcm:LanduseClass>
 </krrcm:landuseClassMember>
 <krrcm:landuseClassMember>
  <krrcm:LanduseClass gml:id="LanduseClass123314195663243">
   <krrcm:name>river bank, with vegetation</krrcm:name>
   <krrcm:description>angelegt auf Grundlage der importierten Landnutzung</krrcm:description>
   <krrcm:ordinalNumber>13</krrcm:ordinalNumber>
   <krrcm:colorStyle>#919eb7</krrcm:colorStyle>
   <krrcm:minDamage>0.0</krrcm:minDamage>
   <krrcm:maxDamage>0.0</krrcm:maxDamage>
   <krrcm:averageAnnualDamage>0.0</krrcm:averageAnnualDamage>
   <krrcm:totalDamage>0.0</krrcm:totalDamage>
  </krrcm:LanduseClass>
 </krrcm:landuseClassMember>
 <krrcm:landuseClassMember>
  <krrcm:LanduseClass gml:id="LanduseClass123314195663224">
   <krrcm:name>grassland</krrcm:name>
   <krrcm:description>angelegt auf Grundlage der importierten Landnutzung</krrcm:description>
   <krrcm:ordinalNumber>14</krrcm:ordinalNumber>
   <krrcm:damageFunctionLink xlink:href="#DamageFunction123314195663227"/>
   <krrcm:landuseRiskTypeLink xlink:href="#LanduseRiskType11946232986252"/>
   <krrcm:AssetValueClassLink xlink:href="#AssetValueClass12331419566328"/>
   <krrcm:colorStyle>#5f522a</krrcm:colorStyle>
   <krrcm:statisticClassMember>
    <krrcm:StatisticClass gml:id="StatisticClass123314687074425">
     <gml:description>Statistik f�r das Ereignis mit der J�hrlichkeit100 [a]</gml:description>
     <gml:name>HQ100</gml:name>
     <krrcm:statReturnPeriod>100</krrcm:statReturnPeriod>
     <krrcm:statMinDamage>0.34</krrcm:statMinDamage>
     <krrcm:statMaxDamage>0.34</krrcm:statMaxDamage>
     <krrcm:statAverageDamage>0.34</krrcm:statAverageDamage>
     <krrcm:statAverageAnnualDamage>0.0</krrcm:statAverageAnnualDamage>
     <krrcm:statSumDamage>82758.04</krrcm:statSumDamage>
     <krrcm:statTotalDamage>331032.1600</krrcm:statTotalDamage>
     <krrcm:statFloodedArea>973624.00</krrcm:statFloodedArea>
    </krrcm:StatisticClass>
   </krrcm:statisticClassMember>
   <krrcm:statisticClassMember>
    <krrcm:StatisticClass gml:id="StatisticClass12331470474471">
     <gml:description>Statistik f�r das Ereignis mit der J�hrlichkeit2 [a]</gml:description>
     <gml:name>HQ2</gml:name>
     <krrcm:statReturnPeriod>2</krrcm:statReturnPeriod>
     <krrcm:statMinDamage>0.34</krrcm:statMinDamage>
     <krrcm:statMaxDamage>0.34</krrcm:statMaxDamage>
     <krrcm:statAverageDamage>0.34</krrcm:statAverageDamage>
     <krrcm:statAverageAnnualDamage>0.0</krrcm:statAverageAnnualDamage>
     <krrcm:statSumDamage>70142.34</krrcm:statSumDamage>
     <krrcm:statTotalDamage>280569.3600</krrcm:statTotalDamage>
     <krrcm:statFloodedArea>825204.00</krrcm:statFloodedArea>
    </krrcm:StatisticClass>
   </krrcm:statisticClassMember>
   <krrcm:statisticClassMember>
    <krrcm:StatisticClass gml:id="StatisticClass123314720586947">
     <gml:description>Statistik f�r das Ereignis mit der J�hrlichkeit5 [a]</gml:description>
     <gml:name>HQ5</gml:name>
     <krrcm:statReturnPeriod>5</krrcm:statReturnPeriod>
     <krrcm:statMinDamage>0.34</krrcm:statMinDamage>
     <krrcm:statMaxDamage>0.34</krrcm:statMaxDamage>
     <krrcm:statAverageDamage>0.34</krrcm:statAverageDamage>
     <krrcm:statAverageAnnualDamage>0.0</krrcm:statAverageAnnualDamage>
     <krrcm:statSumDamage>76904.94</krrcm:statSumDamage>
     <krrcm:statTotalDamage>307619.7600</krrcm:statTotalDamage>
     <krrcm:statFloodedArea>904764.00</krrcm:statFloodedArea>
    </krrcm:StatisticClass>
   </krrcm:statisticClassMember>
   <krrcm:statisticClassMember>
    <krrcm:StatisticClass gml:id="StatisticClass123314738191611">
     <gml:description>Statistik f�r das Ereignis mit der J�hrlichkeit10 [a]</gml:description>
     <gml:name>HQ10</gml:name>
     <krrcm:statReturnPeriod>10</krrcm:statReturnPeriod>
     <krrcm:statMinDamage>0.34</krrcm:statMinDamage>
     <krrcm:statMaxDamage>0.34</krrcm:statMaxDamage>
     <krrcm:statAverageDamage>0.34</krrcm:statAverageDamage>
     <krrcm:statAverageAnnualDamage>0.0</krrcm:statAverageAnnualDamage>
     <krrcm:statSumDamage>80435.16</krrcm:statSumDamage>
     <krrcm:statTotalDamage>321740.6400</krrcm:statTotalDamage>
     <krrcm:statFloodedArea>946296.00</krrcm:statFloodedArea>
    </krrcm:StatisticClass>
   </krrcm:statisticClassMember>
   <krrcm:statisticClassMember>
    <krrcm:StatisticClass gml:id="StatisticClass123314757013335">
     <gml:description>Statistik f�r das Ereignis mit der J�hrlichkeit20 [a]</gml:description>
     <gml:name>HQ20</gml:name>
     <krrcm:statReturnPeriod>20</krrcm:statReturnPeriod>
     <krrcm:statMinDamage>0.34</krrcm:statMinDamage>
     <krrcm:statMaxDamage>0.34</krrcm:statMaxDamage>
     <krrcm:statAverageDamage>0.34</krrcm:statAverageDamage>
     <krrcm:statAverageAnnualDamage>0.0</krrcm:statAverageAnnualDamage>
     <krrcm:statSumDamage>82169.50</krrcm:statSumDamage>
     <krrcm:statTotalDamage>328678.0000</krrcm:statTotalDamage>
     <krrcm:statFloodedArea>966700.00</krrcm:statFloodedArea>
    </krrcm:StatisticClass>
   </krrcm:statisticClassMember>
   <krrcm:minDamage>0.16660000000000003</krrcm:minDamage>
   <krrcm:maxDamage>0.16660000000000003</krrcm:maxDamage>
   <krrcm:averageAnnualDamage>0.16660000000000003</krrcm:averageAnnualDamage>
   <krrcm:totalDamage>0.6664000000000001</krrcm:totalDamage>
  </krrcm:LanduseClass>
 </krrcm:landuseClassMember>
 <krrcm:landuseClassMember>
  <krrcm:LanduseClass gml:id="LanduseClass12331419566321">
   <krrcm:name>river</krrcm:name>
   <krrcm:description>angelegt auf Grundlage der importierten Landnutzung</krrcm:description>
   <krrcm:ordinalNumber>15</krrcm:ordinalNumber>
   <krrcm:colorStyle>#e2e97b</krrcm:colorStyle>
   <krrcm:minDamage>0.0</krrcm:minDamage>
   <krrcm:maxDamage>0.0</krrcm:maxDamage>
   <krrcm:averageAnnualDamage>0.0</krrcm:averageAnnualDamage>
   <krrcm:totalDamage>0.0</krrcm:totalDamage>
  </krrcm:LanduseClass>
 </krrcm:landuseClassMember>
 <krrcm:landuseClassMember>
  <krrcm:LanduseClass gml:id="LanduseClass123314195663239">
   <krrcm:name>heavy developed area</krrcm:name>
   <krrcm:description>angelegt auf Grundlage der importierten Landnutzung</krrcm:description>
   <krrcm:ordinalNumber>16</krrcm:ordinalNumber>
   <krrcm:damageFunctionLink xlink:href="#DamageFunction12331419566325"/>
   <krrcm:landuseRiskTypeLink xlink:href="#LanduseRiskType119462338753110"/>
   <krrcm:AssetValueClassLink xlink:href="#AssetValueClass123314195663227"/>
   <krrcm:colorStyle>#dda22c</krrcm:colorStyle>
   <krrcm:statisticClassMember>
    <krrcm:StatisticClass gml:id="StatisticClass123314697207224">
     <gml:description>Statistik f�r das Ereignis mit der J�hrlichkeit100 [a]</gml:description>
     <gml:name>HQ100</gml:name>
     <krrcm:statReturnPeriod>100</krrcm:statReturnPeriod>
     <krrcm:statMinDamage>17.07</krrcm:statMinDamage>
     <krrcm:statMaxDamage>93.38</krrcm:statMaxDamage>
     <krrcm:statAverageDamage>60.04</krrcm:statAverageDamage>
     <krrcm:statAverageAnnualDamage>0.0</krrcm:statAverageAnnualDamage>
     <krrcm:statSumDamage>669424.60</krrcm:statSumDamage>
     <krrcm:statTotalDamage>2677784.0000</krrcm:statTotalDamage>
     <krrcm:statFloodedArea>44600.00</krrcm:statFloodedArea>
    </krrcm:StatisticClass>
   </krrcm:statisticClassMember>
   <krrcm:statisticClassMember>
    <krrcm:StatisticClass gml:id="StatisticClass123314714549414">
     <gml:description>Statistik f�r das Ereignis mit der J�hrlichkeit2 [a]</gml:description>
     <gml:name>HQ2</gml:name>
     <krrcm:statReturnPeriod>2</krrcm:statReturnPeriod>
     <krrcm:statMinDamage>15.40</krrcm:statMinDamage>
     <krrcm:statMaxDamage>72.29</krrcm:statMaxDamage>
     <krrcm:statAverageDamage>47.67</krrcm:statAverageDamage>
     <krrcm:statAverageAnnualDamage>0.0</krrcm:statAverageAnnualDamage>
     <krrcm:statSumDamage>423338.53</krrcm:statSumDamage>
     <krrcm:statTotalDamage>1693238.4000</krrcm:statTotalDamage>
     <krrcm:statFloodedArea>35520.00</krrcm:statFloodedArea>
    </krrcm:StatisticClass>
   </krrcm:statisticClassMember>
   <krrcm:statisticClassMember>
    <krrcm:StatisticClass gml:id="StatisticClass123314730890012">
     <gml:description>Statistik f�r das Ereignis mit der J�hrlichkeit5 [a]</gml:description>
     <gml:name>HQ5</gml:name>
     <krrcm:statReturnPeriod>5</krrcm:statReturnPeriod>
     <krrcm:statMinDamage>17.07</krrcm:statMinDamage>
     <krrcm:statMaxDamage>81.72</krrcm:statMaxDamage>
     <krrcm:statAverageDamage>56.93</krrcm:statAverageDamage>
     <krrcm:statAverageAnnualDamage>0.0</krrcm:statAverageAnnualDamage>
     <krrcm:statSumDamage>509389.71</krrcm:statSumDamage>
     <krrcm:statTotalDamage>2037638.5600</krrcm:statTotalDamage>
     <krrcm:statFloodedArea>35792.00</krrcm:statFloodedArea>
    </krrcm:StatisticClass>
   </krrcm:statisticClassMember>
   <krrcm:statisticClassMember>
    <krrcm:StatisticClass gml:id="StatisticClass12331474923218">
     <gml:description>Statistik f�r das Ereignis mit der J�hrlichkeit10 [a]</gml:description>
     <gml:name>HQ10</gml:name>
     <krrcm:statReturnPeriod>10</krrcm:statReturnPeriod>
     <krrcm:statMinDamage>16.51</krrcm:statMinDamage>
     <krrcm:statMaxDamage>87.00</krrcm:statMaxDamage>
     <krrcm:statAverageDamage>56.23</krrcm:statAverageDamage>
     <krrcm:statAverageAnnualDamage>0.0</krrcm:statAverageAnnualDamage>
     <krrcm:statSumDamage>586213.35</krrcm:statSumDamage>
     <krrcm:statTotalDamage>2344791.0000</krrcm:statTotalDamage>
     <krrcm:statFloodedArea>41700.00</krrcm:statFloodedArea>
    </krrcm:StatisticClass>
   </krrcm:statisticClassMember>
   <krrcm:statisticClassMember>
    <krrcm:StatisticClass gml:id="StatisticClass123314768122655">
     <gml:description>Statistik f�r das Ereignis mit der J�hrlichkeit20 [a]</gml:description>
     <gml:name>HQ20</gml:name>
     <krrcm:statReturnPeriod>20</krrcm:statReturnPeriod>
     <krrcm:statMinDamage>17.34</krrcm:statMinDamage>
     <krrcm:statMaxDamage>90.60</krrcm:statMaxDamage>
     <krrcm:statAverageDamage>58.26</krrcm:statAverageDamage>
     <krrcm:statAverageAnnualDamage>0.0</krrcm:statAverageAnnualDamage>
     <krrcm:statSumDamage>635165.24</krrcm:statSumDamage>
     <krrcm:statTotalDamage>2540835.1200</krrcm:statTotalDamage>
     <krrcm:statFloodedArea>43612.00</krrcm:statFloodedArea>
    </krrcm:StatisticClass>
   </krrcm:statisticClassMember>
   <krrcm:minDamage>0.3636</krrcm:minDamage>
   <krrcm:maxDamage>39.244049999999994</krrcm:maxDamage>
   <krrcm:averageAnnualDamage>26.576</krrcm:averageAnnualDamage>
   <krrcm:totalDamage>999642.4472</krrcm:totalDamage>
  </krrcm:LanduseClass>
 </krrcm:landuseClassMember>
 <krrcm:landuseClassMember>
  <krrcm:LanduseClass gml:id="LanduseClass123314195663241">
   <krrcm:name>river bank, no vegetation</krrcm:name>
   <krrcm:description>angelegt auf Grundlage der importierten Landnutzung</krrcm:description>
   <krrcm:ordinalNumber>17</krrcm:ordinalNumber>
   <krrcm:colorStyle>#843214</krrcm:colorStyle>
   <krrcm:minDamage>0.0</krrcm:minDamage>
   <krrcm:maxDamage>0.0</krrcm:maxDamage>
   <krrcm:averageAnnualDamage>0.0</krrcm:averageAnnualDamage>
   <krrcm:totalDamage>0.0</krrcm:totalDamage>
  </krrcm:LanduseClass>
 </krrcm:landuseClassMember>
 <krrcm:landuseClassMember>
  <krrcm:LanduseClass gml:id="LanduseClass12331419566329">
   <krrcm:name>light vegetation area</krrcm:name>
   <krrcm:description>angelegt auf Grundlage der importierten Landnutzung</krrcm:description>
   <krrcm:ordinalNumber>18</krrcm:ordinalNumber>
   <krrcm:damageFunctionLink xlink:href="#DamageFunction12331419566327"/>
   <krrcm:landuseRiskTypeLink xlink:href="#LanduseRiskType11946232986252"/>
   <krrcm:AssetValueClassLink xlink:href="#AssetValueClass12331419566327"/>
   <krrcm:colorStyle>#6004b1</krrcm:colorStyle>
   <krrcm:statisticClassMember>
    <krrcm:StatisticClass gml:id="StatisticClass123314692276035">
     <gml:description>Statistik f�r das Ereignis mit der J�hrlichkeit100 [a]</gml:description>
     <gml:name>HQ100</gml:name>
     <krrcm:statReturnPeriod>100</krrcm:statReturnPeriod>
     <krrcm:statMinDamage>0.34</krrcm:statMinDamage>
     <krrcm:statMaxDamage>0.34</krrcm:statMaxDamage>
     <krrcm:statAverageDamage>0.34</krrcm:statAverageDamage>
     <krrcm:statAverageAnnualDamage>0.0</krrcm:statAverageAnnualDamage>
     <krrcm:statSumDamage>5681.06</krrcm:statSumDamage>
     <krrcm:statTotalDamage>22724.2400</krrcm:statTotalDamage>
     <krrcm:statFloodedArea>66836.00</krrcm:statFloodedArea>
    </krrcm:StatisticClass>
   </krrcm:statisticClassMember>
   <krrcm:statisticClassMember>
    <krrcm:StatisticClass gml:id="StatisticClass123314709899424">
     <gml:description>Statistik f�r das Ereignis mit der J�hrlichkeit2 [a]</gml:description>
     <gml:name>HQ2</gml:name>
     <krrcm:statReturnPeriod>2</krrcm:statReturnPeriod>
     <krrcm:statMinDamage>0.34</krrcm:statMinDamage>
     <krrcm:statMaxDamage>0.34</krrcm:statMaxDamage>
     <krrcm:statAverageDamage>0.34</krrcm:statAverageDamage>
     <krrcm:statAverageAnnualDamage>0.0</krrcm:statAverageAnnualDamage>
     <krrcm:statSumDamage>5132.30</krrcm:statSumDamage>
     <krrcm:statTotalDamage>20529.2000</krrcm:statTotalDamage>
     <krrcm:statFloodedArea>60380.00</krrcm:statFloodedArea>
    </krrcm:StatisticClass>
   </krrcm:statisticClassMember>
   <krrcm:statisticClassMember>
    <krrcm:StatisticClass gml:id="StatisticClass123314725772846">
     <gml:description>Statistik f�r das Ereignis mit der J�hrlichkeit5 [a]</gml:description>
     <gml:name>HQ5</gml:name>
     <krrcm:statReturnPeriod>5</krrcm:statReturnPeriod>
     <krrcm:statMinDamage>0.34</krrcm:statMinDamage>
     <krrcm:statMaxDamage>0.34</krrcm:statMaxDamage>
     <krrcm:statAverageDamage>0.34</krrcm:statAverageDamage>
     <krrcm:statAverageAnnualDamage>0.0</krrcm:statAverageAnnualDamage>
     <krrcm:statSumDamage>5426.06</krrcm:statSumDamage>
     <krrcm:statTotalDamage>21704.2400</krrcm:statTotalDamage>
     <krrcm:statFloodedArea>63836.00</krrcm:statFloodedArea>
    </krrcm:StatisticClass>
   </krrcm:statisticClassMember>
   <krrcm:statisticClassMember>
    <krrcm:StatisticClass gml:id="StatisticClass123314743724434">
     <gml:description>Statistik f�r das Ereignis mit der J�hrlichkeit10 [a]</gml:description>
     <gml:name>HQ10</gml:name>
     <krrcm:statReturnPeriod>10</krrcm:statReturnPeriod>
     <krrcm:statMinDamage>0.34</krrcm:statMinDamage>
     <krrcm:statMaxDamage>0.34</krrcm:statMaxDamage>
     <krrcm:statAverageDamage>0.34</krrcm:statAverageDamage>
     <krrcm:statAverageAnnualDamage>0.0</krrcm:statAverageAnnualDamage>
     <krrcm:statSumDamage>5526.36</krrcm:statSumDamage>
     <krrcm:statTotalDamage>22105.4400</krrcm:statTotalDamage>
     <krrcm:statFloodedArea>65016.00</krrcm:statFloodedArea>
    </krrcm:StatisticClass>
   </krrcm:statisticClassMember>
   <krrcm:statisticClassMember>
    <krrcm:StatisticClass gml:id="StatisticClass123314762894620">
     <gml:description>Statistik f�r das Ereignis mit der J�hrlichkeit20 [a]</gml:description>
     <gml:name>HQ20</gml:name>
     <krrcm:statReturnPeriod>20</krrcm:statReturnPeriod>
     <krrcm:statMinDamage>0.34</krrcm:statMinDamage>
     <krrcm:statMaxDamage>0.34</krrcm:statMaxDamage>
     <krrcm:statAverageDamage>0.34</krrcm:statAverageDamage>
     <krrcm:statAverageAnnualDamage>0.0</krrcm:statAverageAnnualDamage>
     <krrcm:statSumDamage>5610.68</krrcm:statSumDamage>
     <krrcm:statTotalDamage>22442.7200</krrcm:statTotalDamage>
     <krrcm:statFloodedArea>66008.00</krrcm:statFloodedArea>
    </krrcm:StatisticClass>
   </krrcm:statisticClassMember>
   <krrcm:minDamage>0.16660000000000003</krrcm:minDamage>
   <krrcm:maxDamage>0.0221</krrcm:maxDamage>
   <krrcm:averageAnnualDamage>0.16660000000000003</krrcm:averageAnnualDamage>
   <krrcm:totalDamage>0.0884</krrcm:totalDamage>
  </krrcm:LanduseClass>
 </krrcm:landuseClassMember>
 <krrcm:damageFunctionMember>
  <krrcm:DamageFunction gml:id="DamageFunction123314659974112">
   <krrcm:name>Wohnen</krrcm:name>
   <krrcm:description>[IKSE, Regionalisierung Schleswig-Holstein]</krrcm:description>
   <krrcm:function>6.4*x+4.9</krrcm:function>
  </krrcm:DamageFunction>
 </krrcm:damageFunctionMember>
 <krrcm:damageFunctionMember>
  <krrcm:DamageFunction gml:id="DamageFunction123314659974116">
   <krrcm:name>Industrie und Gewerbe</krrcm:name>
   <krrcm:description>[IKSE, Regionalisierung Schleswig-Holstein]</krrcm:description>
   <krrcm:function>9.6*x+6</krrcm:function>
  </krrcm:DamageFunction>
 </krrcm:damageFunctionMember>
 <krrcm:damageFunctionMember>
  <krrcm:DamageFunction gml:id="DamageFunction12331465997411">
   <krrcm:name>Verkehr</krrcm:name>
   <krrcm:description>[IKSE, Regionalisierung Schleswig-Holstein]</krrcm:description>
   <krrcm:function>10</krrcm:function>
  </krrcm:DamageFunction>
 </krrcm:damageFunctionMember>
 <krrcm:damageFunctionMember>
  <krrcm:DamageFunction gml:id="DamageFunction12331465997417">
   <krrcm:name>Ackerland</krrcm:name>
   <krrcm:description>[IKSE, Regionalisierung Schleswig-Holstein]</krrcm:description>
   <krrcm:function>50</krrcm:function>
  </krrcm:DamageFunction>
 </krrcm:damageFunctionMember>
 <krrcm:damageFunctionMember>
  <krrcm:DamageFunction gml:id="DamageFunction123314659974118">
   <krrcm:name>Gr�nland</krrcm:name>
   <krrcm:description>[IKSE, Regionalisierung Schleswig-Holstein]</krrcm:description>
   <krrcm:function>50</krrcm:function>
  </krrcm:DamageFunction>
 </krrcm:damageFunctionMember>
 <krrcm:damageFunctionMember>
  <krrcm:DamageFunction gml:id="DamageFunction123314659974124">
   <krrcm:name>Forst</krrcm:name>
   <krrcm:description>[IKSE, Regionalisierung Schleswig-Holstein]</krrcm:description>
   <krrcm:function>1</krrcm:function>
  </krrcm:DamageFunction>
 </krrcm:damageFunctionMember>
 <krrcm:assetValueClassMember>
  <krrcm:AssetValueClass gml:id="AssetValueClass123314659974130">
   <krrcm:name>Wohnen</krrcm:name>
   <krrcm:description>[Regionalisierungsmethode Schleswig-Holstein]</krrcm:description>
   <krrcm:value>234.0</krrcm:value>
  </krrcm:AssetValueClass>
 </krrcm:assetValueClassMember>
 <krrcm:assetValueClassMember>
  <krrcm:AssetValueClass gml:id="AssetValueClass123314659974110">
   <krrcm:name>Gewerbe</krrcm:name>
   <krrcm:description>[Regionalisierungsmethode Schleswig-Holstein]</krrcm:description>
   <krrcm:value>289.06</krrcm:value>
  </krrcm:AssetValueClass>
 </krrcm:assetValueClassMember>
 <krrcm:assetValueClassMember>
  <krrcm:AssetValueClass gml:id="AssetValueClass123314659974125">
   <krrcm:name>Verkehr</krrcm:name>
   <krrcm:description>[Regionalisierungsmethode Schleswig-Holstein]</krrcm:description>
   <krrcm:value>54.32</krrcm:value>
  </krrcm:AssetValueClass>
 </krrcm:assetValueClassMember>
 <krrcm:assetValueClassMember>
  <krrcm:AssetValueClass gml:id="AssetValueClass123314659974117">
   <krrcm:name>Ackerland</krrcm:name>
   <krrcm:description>[Regionalisierungsmethode Schleswig-Holstein]</krrcm:description>
   <krrcm:value>0.67</krrcm:value>
  </krrcm:AssetValueClass>
 </krrcm:assetValueClassMember>
 <krrcm:assetValueClassMember>
  <krrcm:AssetValueClass gml:id="AssetValueClass12331465997414">
   <krrcm:name>Gr�nland</krrcm:name>
   <krrcm:description>[Regionalisierungsmethode Schleswig-Holstein]</krrcm:description>
   <krrcm:value>0.67</krrcm:value>
  </krrcm:AssetValueClass>
 </krrcm:assetValueClassMember>
 <krrcm:assetValueClassMember>
  <krrcm:AssetValueClass gml:id="AssetValueClass123314659974140">
   <krrcm:name>Forst</krrcm:name>
   <krrcm:description>[Regionalisierungsmethode Schleswig-Holstein]</krrcm:description>
   <krrcm:value>0.67</krrcm:value>
  </krrcm:AssetValueClass>
 </krrcm:assetValueClassMember>
 <krrcm:administrationUnitMember>
  <krrcm:AdministrationUnit gml:id="AdministrationUnit11944542912340">
   <krrcm:name>Schleswig-Holstein</krrcm:name>
   <krrcm:description/>
  </krrcm:AdministrationUnit>
 </krrcm:administrationUnitMember>
 <krrcm:landuseRiskTypeMember>
  <krrcm:LanduseRiskType gml:id="LanduseRiskType11946232986252">
   <krrcm:name>Freifl�che</krrcm:name>
   <krrcm:description/>
   <krrcm:isUrbanLanduseType>false</krrcm:isUrbanLanduseType>
  </krrcm:LanduseRiskType>
 </krrcm:landuseRiskTypeMember>
 <krrcm:landuseRiskTypeMember>
  <krrcm:LanduseRiskType gml:id="LanduseRiskType119462338753110">
   <krrcm:name>bebaute Fl�che</krrcm:name>
   <krrcm:description/>
   <krrcm:isUrbanLanduseType>true</krrcm:isUrbanLanduseType>
  </krrcm:LanduseRiskType>
 </krrcm:landuseRiskTypeMember>
 <krrcm:riskZoneDefinitionMember>
  <krrcm:RiskZoneDefinition gml:id="RiskZoneDefinition119504743178128">
   <krrcm:name>m��ige Betroffenheit, bebaute Fl�chen</krrcm:name>
   <krrcm:description/>
   <krrcm:lowerBoundaryValue>0.0</krrcm:lowerBoundaryValue>
   <krrcm:colorStyle>#ffff00</krrcm:colorStyle>
   <krrcm:zoneInternalNumber>1</krrcm:zoneInternalNumber>
   <krrcm:isUrbanLanduseType>true</krrcm:isUrbanLanduseType>
  </krrcm:RiskZoneDefinition>
 </krrcm:riskZoneDefinitionMember>
 <krrcm:riskZoneDefinitionMember>
  <krrcm:RiskZoneDefinition gml:id="RiskZoneDefinition11950474295936">
   <krrcm:name>mittlere Betroffenheit, bebaute Fl�chen</krrcm:name>
   <krrcm:description/>
   <krrcm:lowerBoundaryValue>0.1</krrcm:lowerBoundaryValue>
   <krrcm:colorStyle>#ff8040</krrcm:colorStyle>
   <krrcm:zoneInternalNumber>2</krrcm:zoneInternalNumber>
   <krrcm:isUrbanLanduseType>true</krrcm:isUrbanLanduseType>
  </krrcm:RiskZoneDefinition>
 </krrcm:riskZoneDefinitionMember>
 <krrcm:riskZoneDefinitionMember>
  <krrcm:RiskZoneDefinition gml:id="RiskZoneDefinition119504742781219">
   <krrcm:name>hohe Betroffenheit, bebaute Fl�chen</krrcm:name>
   <krrcm:description/>
   <krrcm:lowerBoundaryValue>1.0</krrcm:lowerBoundaryValue>
   <krrcm:colorStyle>#ff0000</krrcm:colorStyle>
   <krrcm:zoneInternalNumber>3</krrcm:zoneInternalNumber>
   <krrcm:isUrbanLanduseType>true</krrcm:isUrbanLanduseType>
  </krrcm:RiskZoneDefinition>
 </krrcm:riskZoneDefinitionMember>
 <krrcm:riskZoneDefinitionMember>
  <krrcm:RiskZoneDefinition gml:id="RiskZoneDefinition119504742610930">
   <krrcm:name>m��ige Betroffenheit, Freifl�chen</krrcm:name>
   <krrcm:description/>
   <krrcm:lowerBoundaryValue>0.0</krrcm:lowerBoundaryValue>
   <krrcm:colorStyle>#8080ff</krrcm:colorStyle>
   <krrcm:zoneInternalNumber>4</krrcm:zoneInternalNumber>
   <krrcm:isUrbanLanduseType>false</krrcm:isUrbanLanduseType>
  </krrcm:RiskZoneDefinition>
 </krrcm:riskZoneDefinitionMember>
 <krrcm:riskZoneDefinitionMember>
  <krrcm:RiskZoneDefinition gml:id="RiskZoneDefinition119504742404618">
   <krrcm:name>mittlere Betroffenheit, Freifl�chen</krrcm:name>
   <krrcm:description/>
   <krrcm:lowerBoundaryValue>0.1</krrcm:lowerBoundaryValue>
   <krrcm:colorStyle>#8000ff</krrcm:colorStyle>
   <krrcm:zoneInternalNumber>5</krrcm:zoneInternalNumber>
   <krrcm:isUrbanLanduseType>false</krrcm:isUrbanLanduseType>
  </krrcm:RiskZoneDefinition>
 </krrcm:riskZoneDefinitionMember>
 <krrcm:riskZoneDefinitionMember>
  <krrcm:RiskZoneDefinition gml:id="RiskZoneDefinition119504742029619">
   <krrcm:name>hohe Betroffenheit, Freifl�chen</krrcm:name>
   <krrcm:description/>
   <krrcm:lowerBoundaryValue>1.0</krrcm:lowerBoundaryValue>
   <krrcm:colorStyle>#400080</krrcm:colorStyle>
   <krrcm:zoneInternalNumber>6</krrcm:zoneInternalNumber>
   <krrcm:isUrbanLanduseType>false</krrcm:isUrbanLanduseType>
  </krrcm:RiskZoneDefinition>
 </krrcm:riskZoneDefinitionMember>
 <krrcm:riskStatisticResultMember>
  <krrcm:RiskStatisticResult gml:id="RiskStatisticResult123314914890547">
   <gml:description>description</gml:description>
   <gml:name>name</gml:name>
   <om:resultDefinition xmlns:om="http://www.opengis.net/om">
    <swe:RecordDefinition gml:id="RecordDefinition123314914901410">
     <swe:component>
      <swe:ItemDefinition gml:id="ItemDefinition123314914901446">
       <gml:description>Landuse</gml:description>
       <gml:name>Landuse</gml:name>
       <swe:property>
        <swe:Phenomenon gml:id="Phenomenon12331491490147">
         <gml:description>Landuse</gml:description>
         <gml:name>Landuse</gml:name>
        </swe:Phenomenon>
       </swe:property>
       <representation xmlns="http://www.opengis.net/swe">

        <Word/>

       </representation>
      </swe:ItemDefinition>
     </swe:component>
     <swe:component>
      <swe:ItemDefinition gml:id="ItemDefinition123314914901415">
       <gml:description>TotalDamage_HQ2</gml:description>
       <gml:name>TotalDamage_HQ2</gml:name>
       <swe:property>
        <swe:Phenomenon gml:id="Phenomenon123314914901425">
         <gml:description>TotalDamage_HQ2</gml:description>
         <gml:name>TotalDamage</gml:name>
        </swe:Phenomenon>
       </swe:property>
       <representation xmlns="http://www.opengis.net/swe">

        <SimpleType>

         <restriction xmlns="http://www.seegrid.csiro.au/xml/st" base="decimal"/>

         <unitOfMeasure xmlns="http://www.opengis.net/gml" uom="none"/>

        </SimpleType>

       </representation>
      </swe:ItemDefinition>
     </swe:component>
     <swe:component>
      <swe:ItemDefinition gml:id="ItemDefinition123314914901449">
       <gml:description>FloodedArea_HQ2</gml:description>
       <gml:name>FloodedArea_HQ2</gml:name>
       <swe:property>
        <swe:Phenomenon gml:id="Phenomenon123314914901436">
         <gml:description>FloodedArea_HQ2</gml:description>
         <gml:name>FloodedArea</gml:name>
        </swe:Phenomenon>
       </swe:property>
       <representation xmlns="http://www.opengis.net/swe">

        <SimpleType>

         <restriction xmlns="http://www.seegrid.csiro.au/xml/st" base="decimal"/>

         <unitOfMeasure xmlns="http://www.opengis.net/gml" uom="none"/>

        </SimpleType>

       </representation>
      </swe:ItemDefinition>
     </swe:component>
     <swe:component>
      <swe:ItemDefinition gml:id="ItemDefinition123314914901456">
       <gml:description>AverageDamage_HQ2</gml:description>
       <gml:name>AverageDamage_HQ2</gml:name>
       <swe:property>
        <swe:Phenomenon gml:id="Phenomenon123314914901432">
         <gml:description>AverageDamage_HQ2</gml:description>
         <gml:name>AveragedDamage</gml:name>
        </swe:Phenomenon>
       </swe:property>
       <representation xmlns="http://www.opengis.net/swe">

        <SimpleType>

         <restriction xmlns="http://www.seegrid.csiro.au/xml/st" base="decimal"/>

         <unitOfMeasure xmlns="http://www.opengis.net/gml" uom="none"/>

        </SimpleType>

       </representation>
      </swe:ItemDefinition>
     </swe:component>
     <swe:component>
      <swe:ItemDefinition gml:id="ItemDefinition123314914901471">
       <gml:description>TotalDamage_HQ5</gml:description>
       <gml:name>TotalDamage_HQ5</gml:name>
       <swe:property>
        <swe:Phenomenon gml:id="Phenomenon123314914901447">
         <gml:description>TotalDamage_HQ5</gml:description>
         <gml:name>TotalDamage</gml:name>
        </swe:Phenomenon>
       </swe:property>
       <representation xmlns="http://www.opengis.net/swe">

        <SimpleType>

         <restriction xmlns="http://www.seegrid.csiro.au/xml/st" base="decimal"/>

         <unitOfMeasure xmlns="http://www.opengis.net/gml" uom="none"/>

        </SimpleType>

       </representation>
      </swe:ItemDefinition>
     </swe:component>
     <swe:component>
      <swe:ItemDefinition gml:id="ItemDefinition123314914901417">
       <gml:description>FloodedArea_HQ5</gml:description>
       <gml:name>FloodedArea_HQ5</gml:name>
       <swe:property>
        <swe:Phenomenon gml:id="Phenomenon123314914901420">
         <gml:description>FloodedArea_HQ5</gml:description>
         <gml:name>FloodedArea</gml:name>
        </swe:Phenomenon>
       </swe:property>
       <representation xmlns="http://www.opengis.net/swe">

        <SimpleType>

         <restriction xmlns="http://www.seegrid.csiro.au/xml/st" base="decimal"/>

         <unitOfMeasure xmlns="http://www.opengis.net/gml" uom="none"/>

        </SimpleType>

       </representation>
      </swe:ItemDefinition>
     </swe:component>
     <swe:component>
      <swe:ItemDefinition gml:id="ItemDefinition123314914901472">
       <gml:description>AverageDamage_HQ5</gml:description>
       <gml:name>AverageDamage_HQ5</gml:name>
       <swe:property>
        <swe:Phenomenon gml:id="Phenomenon123314914901427">
         <gml:description>AverageDamage_HQ5</gml:description>
         <gml:name>AveragedDamage</gml:name>
        </swe:Phenomenon>
       </swe:property>
       <representation xmlns="http://www.opengis.net/swe">

        <SimpleType>

         <restriction xmlns="http://www.seegrid.csiro.au/xml/st" base="decimal"/>

         <unitOfMeasure xmlns="http://www.opengis.net/gml" uom="none"/>

        </SimpleType>

       </representation>
      </swe:ItemDefinition>
     </swe:component>
     <swe:component>
      <swe:ItemDefinition gml:id="ItemDefinition123314914901460">
       <gml:description>TotalDamage_HQ10</gml:description>
       <gml:name>TotalDamage_HQ10</gml:name>
       <swe:property>
        <swe:Phenomenon gml:id="Phenomenon12331491490143">
         <gml:description>TotalDamage_HQ10</gml:description>
         <gml:name>TotalDamage</gml:name>
        </swe:Phenomenon>
       </swe:property>
       <representation xmlns="http://www.opengis.net/swe">

        <SimpleType>

         <restriction xmlns="http://www.seegrid.csiro.au/xml/st" base="decimal"/>

         <unitOfMeasure xmlns="http://www.opengis.net/gml" uom="none"/>

        </SimpleType>

       </representation>
      </swe:ItemDefinition>
     </swe:component>
     <swe:component>
      <swe:ItemDefinition gml:id="ItemDefinition123314914901454">
       <gml:description>FloodedArea_HQ10</gml:description>
       <gml:name>FloodedArea_HQ10</gml:name>
       <swe:property>
        <swe:Phenomenon gml:id="Phenomenon123314914901416">
         <gml:description>FloodedArea_HQ10</gml:description>
         <gml:name>FloodedArea</gml:name>
        </swe:Phenomenon>
       </swe:property>
       <representation xmlns="http://www.opengis.net/swe">

        <SimpleType>

         <restriction xmlns="http://www.seegrid.csiro.au/xml/st" base="decimal"/>

         <unitOfMeasure xmlns="http://www.opengis.net/gml" uom="none"/>

        </SimpleType>

       </representation>
      </swe:ItemDefinition>
     </swe:component>
     <swe:component>
      <swe:ItemDefinition gml:id="ItemDefinition12331491490144">
       <gml:description>AverageDamage_HQ10</gml:description>
       <gml:name>AverageDamage_HQ10</gml:name>
       <swe:property>
        <swe:Phenomenon gml:id="Phenomenon123314914901433">
         <gml:description>AverageDamage_HQ10</gml:description>
         <gml:name>AveragedDamage</gml:name>
        </swe:Phenomenon>
       </swe:property>
       <representation xmlns="http://www.opengis.net/swe">

        <SimpleType>

         <restriction xmlns="http://www.seegrid.csiro.au/xml/st" base="decimal"/>

         <unitOfMeasure xmlns="http://www.opengis.net/gml" uom="none"/>

        </SimpleType>

       </representation>
      </swe:ItemDefinition>
     </swe:component>
     <swe:component>
      <swe:ItemDefinition gml:id="ItemDefinition123314914901467">
       <gml:description>TotalDamage_HQ20</gml:description>
       <gml:name>TotalDamage_HQ20</gml:name>
       <swe:property>
        <swe:Phenomenon gml:id="Phenomenon123314914901470">
         <gml:description>TotalDamage_HQ20</gml:description>
         <gml:name>TotalDamage</gml:name>
        </swe:Phenomenon>
       </swe:property>
       <representation xmlns="http://www.opengis.net/swe">

        <SimpleType>

         <restriction xmlns="http://www.seegrid.csiro.au/xml/st" base="decimal"/>

         <unitOfMeasure xmlns="http://www.opengis.net/gml" uom="none"/>

        </SimpleType>

       </representation>
      </swe:ItemDefinition>
     </swe:component>
     <swe:component>
      <swe:ItemDefinition gml:id="ItemDefinition12331491490148">
       <gml:description>FloodedArea_HQ20</gml:description>
       <gml:name>FloodedArea_HQ20</gml:name>
       <swe:property>
        <swe:Phenomenon gml:id="Phenomenon123314914901456">
         <gml:description>FloodedArea_HQ20</gml:description>
         <gml:name>FloodedArea</gml:name>
        </swe:Phenomenon>
       </swe:property>
       <representation xmlns="http://www.opengis.net/swe">

        <SimpleType>

         <restriction xmlns="http://www.seegrid.csiro.au/xml/st" base="decimal"/>

         <unitOfMeasure xmlns="http://www.opengis.net/gml" uom="none"/>

        </SimpleType>

       </representation>
      </swe:ItemDefinition>
     </swe:component>
     <swe:component>
      <swe:ItemDefinition gml:id="ItemDefinition123314914901490">
       <gml:description>AverageDamage_HQ20</gml:description>
       <gml:name>AverageDamage_HQ20</gml:name>
       <swe:property>
        <swe:Phenomenon gml:id="Phenomenon123314914901422">
         <gml:description>AverageDamage_HQ20</gml:description>
         <gml:name>AveragedDamage</gml:name>
        </swe:Phenomenon>
       </swe:property>
       <representation xmlns="http://www.opengis.net/swe">

        <SimpleType>

         <restriction xmlns="http://www.seegrid.csiro.au/xml/st" base="decimal"/>

         <unitOfMeasure xmlns="http://www.opengis.net/gml" uom="none"/>

        </SimpleType>

       </representation>
      </swe:ItemDefinition>
     </swe:component>
     <swe:component>
      <swe:ItemDefinition gml:id="ItemDefinition123314914901442">
       <gml:description>TotalDamage_HQ100</gml:description>
       <gml:name>TotalDamage_HQ100</gml:name>
       <swe:property>
        <swe:Phenomenon gml:id="Phenomenon123314914901431">
         <gml:description>TotalDamage_HQ100</gml:description>
         <gml:name>TotalDamage</gml:name>
        </swe:Phenomenon>
       </swe:property>
       <representation xmlns="http://www.opengis.net/swe">

        <SimpleType>

         <restriction xmlns="http://www.seegrid.csiro.au/xml/st" base="decimal"/>

         <unitOfMeasure xmlns="http://www.opengis.net/gml" uom="none"/>

        </SimpleType>

       </representation>
      </swe:ItemDefinition>
     </swe:component>
     <swe:component>
      <swe:ItemDefinition gml:id="ItemDefinition123314914901489">
       <gml:description>FloodedArea_HQ100</gml:description>
       <gml:name>FloodedArea_HQ100</gml:name>
       <swe:property>
        <swe:Phenomenon gml:id="Phenomenon123314914901414">
         <gml:description>FloodedArea_HQ100</gml:description>
         <gml:name>FloodedArea</gml:name>
        </swe:Phenomenon>
       </swe:property>
       <representation xmlns="http://www.opengis.net/swe">

        <SimpleType>

         <restriction xmlns="http://www.seegrid.csiro.au/xml/st" base="decimal"/>

         <unitOfMeasure xmlns="http://www.opengis.net/gml" uom="none"/>

        </SimpleType>

       </representation>
      </swe:ItemDefinition>
     </swe:component>
     <swe:component>
      <swe:ItemDefinition gml:id="ItemDefinition123314914901461">
       <gml:description>AverageDamage_HQ100</gml:description>
       <gml:name>AverageDamage_HQ100</gml:name>
       <swe:property>
        <swe:Phenomenon gml:id="Phenomenon123314914901488">
         <gml:description>AverageDamage_HQ100</gml:description>
         <gml:name>AveragedDamage</gml:name>
        </swe:Phenomenon>
       </swe:property>
       <representation xmlns="http://www.opengis.net/swe">

        <SimpleType>

         <restriction xmlns="http://www.seegrid.csiro.au/xml/st" base="decimal"/>

         <unitOfMeasure xmlns="http://www.opengis.net/gml" uom="none"/>

        </SimpleType>

       </representation>
      </swe:ItemDefinition>
     </swe:component>
     <swe:component xlink:href="urn:ogc:gml:dict:kalypso:risk:model:riskresultstat#ANNUAL"/>
    </swe:RecordDefinition>
   </om:resultDefinition>
   <om:result xmlns:om="http://www.opengis.net/om"><![CDATA[no+data 0.0 0.0 0.0 0.0 0.0 0.0 0.0 0.0 0.0 0.0 0.0 0.0 0.0 0.0 0.0 0.0
river 0.0 0.0 0.0 0.0 0.0 0.0 0.0 0.0 0.0 0.0 0.0 0.0 0.0 0.0 0.0 0.0
grassland 280569.3600 825204.00 0.34 307619.7600 904764.00 0.34 321740.6400 946296.00 0.34 328678.0000 966700.00 0.34 331032.1600 973624.00 0.34 0.16660000000000003
light+vegetation+area 20529.2000 60380.00 0.34 21704.2400 63836.00 0.34 22105.4400 65016.00 0.34 22442.7200 66008.00 0.34 22724.2400 66836.00 0.34 0.16660000000000003
dense+vegetation+area 572.1600 57216.00 0.01 616.9200 61692.00 0.01 655.7600 65576.00 0.01 679.4400 67944.00 0.01 690.9200 69092.00 0.01 0.004900000000000001
light+developed+area 0.0 0.0 0.0 0.0 0.0 0.0 0.0 0.0 0.0 0.0 0.0 0.0 0.0 0.0 0.0 0.0
river+bank%2C+no+vegetation 0.0 0.0 0.0 0.0 0.0 0.0 0.0 0.0 0.0 0.0 0.0 0.0 0.0 0.0 0.0 0.0
river+bank%2C+with+vegetation 0.0 0.0 0.0 0.0 0.0 0.0 0.0 0.0 0.0 0.0 0.0 0.0 0.0 0.0 0.0 0.0
heavy+developed+area 1693238.4000 35520.00 47.67 2037638.5600 35792.00 56.93 2344791.0000 41700.00 56.23 2540835.1200 43612.00 58.26 2677784.0000 44600.00 60.04 26.576
Total 1994909.1200 978320.00 2.04 2367579.4800 1066084.00 2.22 2689292.8400 1118588.00 2.40 2892635.2800 1144264.00 2.53 3032231.3200 1154152.00 2.63 1.0961999999999998
]]></om:result>
  </krrcm:RiskStatisticResult>
 </krrcm:riskStatisticResultMember>
</krrcm:RasterizationControlModel>
