/*
 * MATLAB Compiler: 4.8 (R2008a)
 * Date: Thu Aug  7 10:57:37 2008
 * Arguments: "-B" "macro_default" "-o" "Gaja3dService" "-W" "main" "-d"
 * "/fibus/fs3/01/wbku/gaja3d_07.07.08/Gaja3dService/src" "-T" "link:exe" "-v"
 * "-C" "/fibus/fs3/01/wbku/gaja3d_07.07.08/Gaja3dService/Gaja3dService.m" "-a"
 * "/fibus/fs3/01/wbku/gaja3d_07.07.08/+org/+kalypso/+gaja3d/+matlab/BilateralFi
 * lter.m" "-a"
 * "/fibus/fs3/01/wbku/gaja3d_07.07.08/+org/+kalypso/+gaja3d/+matlab/CannyDetect
 * or.m" "-a"
 * "/fibus/fs3/01/wbku/gaja3d_07.07.08/+org/+kalypso/+gaja3d/+matlab/Curve.m"
 * "-a"
 * "/fibus/fs3/01/wbku/gaja3d_07.07.08/+org/+kalypso/+gaja3d/+matlab/EdgeFilter.
 * m" "-a"
 * "/fibus/fs3/01/wbku/gaja3d_07.07.08/+org/+kalypso/+gaja3d/+matlab/FeatureDete
 * ctor.m" "-a"
 * "/fibus/fs3/01/wbku/gaja3d_07.07.08/+org/+kalypso/+gaja3d/+matlab/Gaja3D.m"
 * "-a"
 * "/fibus/fs3/01/wbku/gaja3d_07.07.08/+org/+kalypso/+gaja3d/+matlab/GaussianFil
 * ter.m" "-a"
 * "/fibus/fs3/01/wbku/gaja3d_07.07.08/+org/+kalypso/+gaja3d/+matlab/Polygon.m"
 * "-a"
 * "/fibus/fs3/01/wbku/gaja3d_07.07.08/+org/+kalypso/+gaja3d/+matlab/RectifiedGr
 * idCoverage.m" "-a"
 * "/fibus/fs3/01/wbku/gaja3d_07.07.08/+org/+kalypso/+gaja3d/+matlab/Shape.m"
 * "-a"
 * "/fibus/fs3/01/wbku/gaja3d_07.07.08/+org/+kalypso/+gaja3d/+matlab/SimpleFeatu
 * reDetector.m" "-a"
 * "/fibus/fs3/01/wbku/gaja3d_07.07.08/+org/+kalypso/+gaja3d/+matlab/Triangulate
 * dSurface.m" "-a" "/fibus/fs3/01/wbku/gaja3d_07.07.08/data/loadDbf.m" "-a"
 * "/fibus/fs3/01/wbku/gaja3d_07.07.08/data/loadGrid.m" "-a"
 * "/fibus/fs3/01/wbku/gaja3d_07.07.08/data/loadLineData.m" "-a"
 * "/fibus/fs3/01/wbku/gaja3d_07.07.08/data/loadPointData.m" "-a"
 * "/fibus/fs3/01/wbku/gaja3d_07.07.08/data/loadPointShape.m" "-a"
 * "/fibus/fs3/01/wbku/gaja3d_07.07.08/data/loadPolygonData.m" "-a"
 * "/fibus/fs3/01/wbku/gaja3d_07.07.08/data/loadTriangleOutput.m" "-a"
 * "/fibus/fs3/01/wbku/gaja3d_07.07.08/data/loadTriangleShape.m" "-a"
 * "/fibus/fs3/01/wbku/gaja3d_07.07.08/data/progressbar.m" "-a"
 * "/fibus/fs3/01/wbku/gaja3d_07.07.08/data/readAsciiGrid.m" "-a"
 * "/fibus/fs3/01/wbku/gaja3d_07.07.08/data/saveAsciiGrid.m" "-a"
 * "/fibus/fs3/01/wbku/gaja3d_07.07.08/data/savePointShape.m" "-a"
 * "/fibus/fs3/01/wbku/gaja3d_07.07.08/data/saveTiff.m" "-a"
 * "/fibus/fs3/01/wbku/gaja3d_07.07.08/data/saveTrianglesAsBce2d.m" "-a"
 * "/fibus/fs3/01/wbku/gaja3d_07.07.08/data/saveTrianglesAsEle.m" "-a"
 * "/fibus/fs3/01/wbku/gaja3d_07.07.08/data/saveTrianglesAsShape.m" "-a"
 * "/fibus/fs3/01/wbku/gaja3d_07.07.08/utils/simplifyLine.m" "-a"
 * "/fibus/fs3/01/wbku/gaja3d_07.07.08/utils/assert_equalsTol.m" "-a"
 * "/fibus/fs3/01/wbku/gaja3d_07.07.08/utils/bfilter2.m" "-a"
 * "/fibus/fs3/01/wbku/gaja3d_07.07.08/utils/boundariesForGrids.m" "-a"
 * "/fibus/fs3/01/wbku/gaja3d_07.07.08/utils/bufferPolygon.m" "-a"
 * "/fibus/fs3/01/wbku/gaja3d_07.07.08/utils/clipLine.m" "-a"
 * "/fibus/fs3/01/wbku/gaja3d_07.07.08/utils/constructRefMat.m" "-a"
 * "/fibus/fs3/01/wbku/gaja3d_07.07.08/utils/createGrid.m" "-a"
 * "/fibus/fs3/01/wbku/gaja3d_07.07.08/utils/exportArea.m" "-a"
 * "/fibus/fs3/01/wbku/gaja3d_07.07.08/utils/exportNodeEle.m" "-a"
 * "/fibus/fs3/01/wbku/gaja3d_07.07.08/utils/exportNodes.m" "-a"
 * "/fibus/fs3/01/wbku/gaja3d_07.07.08/utils/exportPoly.m" "-a"
 * "/fibus/fs3/01/wbku/gaja3d_07.07.08/utils/getPointInPolygon.m" "-a"
 * "/fibus/fs3/01/wbku/gaja3d_07.07.08/utils/griddedBoundaries.m" "-a"
 * "/fibus/fs3/01/wbku/gaja3d_07.07.08/utils/gridfit.m" "-a"
 * "/fibus/fs3/01/wbku/gaja3d_07.07.08/utils/interptri.m" "-a"
 * "/fibus/fs3/01/wbku/gaja3d_07.07.08/utils/reduceToBoundary.m" 
 */

#include <stdio.h>
#include "mclmcrrt.h"
#ifdef __cplusplus
extern "C" {
#endif

extern mclComponentData __MCC_Gaja3dService_component_data;

#ifdef __cplusplus
}
#endif

static HMCRINSTANCE _mcr_inst = NULL;


#ifdef __cplusplus
extern "C" {
#endif

static int mclDefaultPrintHandler(const char *s)
{
  return mclWrite(1 /* stdout */, s, sizeof(char)*strlen(s));
}

#ifdef __cplusplus
} /* End extern "C" block */
#endif

#ifdef __cplusplus
extern "C" {
#endif

static int mclDefaultErrorHandler(const char *s)
{
  int written = 0;
  size_t len = 0;
  len = strlen(s);
  written = mclWrite(2 /* stderr */, s, sizeof(char)*len);
  if (len > 0 && s[ len-1 ] != '\n')
    written += mclWrite(2 /* stderr */, "\n", sizeof(char));
  return written;
}

#ifdef __cplusplus
} /* End extern "C" block */
#endif

/* This symbol is defined in shared libraries. Define it here
 * (to nothing) in case this isn't a shared library. 
 */
#ifndef LIB_Gaja3dService_C_API 
#define LIB_Gaja3dService_C_API /* No special import/export declaration */
#endif

LIB_Gaja3dService_C_API 
bool MW_CALL_CONV Gaja3dServiceInitializeWithHandlers(
    mclOutputHandlerFcn error_handler,
    mclOutputHandlerFcn print_handler
)
{
  if (_mcr_inst != NULL)
    return true;
  if (!mclmcrInitialize())
    return false;
  if (!mclInitializeComponentInstance(&_mcr_inst,
                                      &__MCC_Gaja3dService_component_data,
                                      true, NoObjectType, ExeTarget,
                                      error_handler, print_handler))
    return false;
  return true;
}

LIB_Gaja3dService_C_API 
bool MW_CALL_CONV Gaja3dServiceInitialize(void)
{
  return Gaja3dServiceInitializeWithHandlers(mclDefaultErrorHandler,
                                             mclDefaultPrintHandler);
}

LIB_Gaja3dService_C_API 
void MW_CALL_CONV Gaja3dServiceTerminate(void)
{
  if (_mcr_inst != NULL)
    mclTerminateInstance(&_mcr_inst);
}

int run_main(int argc, const char **argv)
{
  int _retval;
  /* Generate and populate the path_to_component. */
  char path_to_component[(PATH_MAX*2)+1];
  separatePathName(argv[0], path_to_component, (PATH_MAX*2)+1);
  __MCC_Gaja3dService_component_data.path_to_component = path_to_component; 
  if (!Gaja3dServiceInitialize()) {
    return -1;
  }
  _retval = mclMain(_mcr_inst, argc, argv, "Gaja3dService", 0);
  if (_retval == 0 /* no error */) mclWaitForFiguresToDie(NULL);
  Gaja3dServiceTerminate();
  mclTerminateApplication();
  return _retval;
}

int main(int argc, const char **argv)
{
  if (!mclInitializeApplication(
    __MCC_Gaja3dService_component_data.runtime_options,
    __MCC_Gaja3dService_component_data.runtime_option_count))
    return 0;
  
  return mclRunMain(run_main, argc, argv);
}
