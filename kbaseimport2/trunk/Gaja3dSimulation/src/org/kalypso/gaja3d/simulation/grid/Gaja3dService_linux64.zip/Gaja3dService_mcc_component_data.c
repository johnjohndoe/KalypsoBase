/*
 * MATLAB Compiler: 4.8 (R2008a)
 * Date: Thu Aug  7 10:57:37 2008
 * Arguments: "-B" "macro_default" "-o" "Gaja3dService" "-W" "main" "-d"
 * "/fibus/fs3/01/wbku/gaja3d_07.07.08/Gaja3dService/src" "-T" "link:exe" "-v"
 * "-C" "/fibus/fs3/01/wbku/gaja3d_07.07.08/Gaja3dService/Gaja3dService.m" "-a"
 * "/fibus/fs3/01/wbku/gaja3d_07.07.08/+org/+kalypso/+gaja3d/+matlab/BilateralFi
 * lter.m" "-a"
 * "/fibus/fs3/01/wbku/gaja3d_07.07.08/+org/+kalypso/+gaja3d/+matlab/CannyDetect
 * or.m" "-a"
 * "/fibus/fs3/01/wbku/gaja3d_07.07.08/+org/+kalypso/+gaja3d/+matlab/Curve.m"
 * "-a"
 * "/fibus/fs3/01/wbku/gaja3d_07.07.08/+org/+kalypso/+gaja3d/+matlab/EdgeFilter.
 * m" "-a"
 * "/fibus/fs3/01/wbku/gaja3d_07.07.08/+org/+kalypso/+gaja3d/+matlab/FeatureDete
 * ctor.m" "-a"
 * "/fibus/fs3/01/wbku/gaja3d_07.07.08/+org/+kalypso/+gaja3d/+matlab/Gaja3D.m"
 * "-a"
 * "/fibus/fs3/01/wbku/gaja3d_07.07.08/+org/+kalypso/+gaja3d/+matlab/GaussianFil
 * ter.m" "-a"
 * "/fibus/fs3/01/wbku/gaja3d_07.07.08/+org/+kalypso/+gaja3d/+matlab/Polygon.m"
 * "-a"
 * "/fibus/fs3/01/wbku/gaja3d_07.07.08/+org/+kalypso/+gaja3d/+matlab/RectifiedGr
 * idCoverage.m" "-a"
 * "/fibus/fs3/01/wbku/gaja3d_07.07.08/+org/+kalypso/+gaja3d/+matlab/Shape.m"
 * "-a"
 * "/fibus/fs3/01/wbku/gaja3d_07.07.08/+org/+kalypso/+gaja3d/+matlab/SimpleFeatu
 * reDetector.m" "-a"
 * "/fibus/fs3/01/wbku/gaja3d_07.07.08/+org/+kalypso/+gaja3d/+matlab/Triangulate
 * dSurface.m" "-a" "/fibus/fs3/01/wbku/gaja3d_07.07.08/data/loadDbf.m" "-a"
 * "/fibus/fs3/01/wbku/gaja3d_07.07.08/data/loadGrid.m" "-a"
 * "/fibus/fs3/01/wbku/gaja3d_07.07.08/data/loadLineData.m" "-a"
 * "/fibus/fs3/01/wbku/gaja3d_07.07.08/data/loadPointData.m" "-a"
 * "/fibus/fs3/01/wbku/gaja3d_07.07.08/data/loadPointShape.m" "-a"
 * "/fibus/fs3/01/wbku/gaja3d_07.07.08/data/loadPolygonData.m" "-a"
 * "/fibus/fs3/01/wbku/gaja3d_07.07.08/data/loadTriangleOutput.m" "-a"
 * "/fibus/fs3/01/wbku/gaja3d_07.07.08/data/loadTriangleShape.m" "-a"
 * "/fibus/fs3/01/wbku/gaja3d_07.07.08/data/progressbar.m" "-a"
 * "/fibus/fs3/01/wbku/gaja3d_07.07.08/data/readAsciiGrid.m" "-a"
 * "/fibus/fs3/01/wbku/gaja3d_07.07.08/data/saveAsciiGrid.m" "-a"
 * "/fibus/fs3/01/wbku/gaja3d_07.07.08/data/savePointShape.m" "-a"
 * "/fibus/fs3/01/wbku/gaja3d_07.07.08/data/saveTiff.m" "-a"
 * "/fibus/fs3/01/wbku/gaja3d_07.07.08/data/saveTrianglesAsBce2d.m" "-a"
 * "/fibus/fs3/01/wbku/gaja3d_07.07.08/data/saveTrianglesAsEle.m" "-a"
 * "/fibus/fs3/01/wbku/gaja3d_07.07.08/data/saveTrianglesAsShape.m" "-a"
 * "/fibus/fs3/01/wbku/gaja3d_07.07.08/utils/simplifyLine.m" "-a"
 * "/fibus/fs3/01/wbku/gaja3d_07.07.08/utils/assert_equalsTol.m" "-a"
 * "/fibus/fs3/01/wbku/gaja3d_07.07.08/utils/bfilter2.m" "-a"
 * "/fibus/fs3/01/wbku/gaja3d_07.07.08/utils/boundariesForGrids.m" "-a"
 * "/fibus/fs3/01/wbku/gaja3d_07.07.08/utils/bufferPolygon.m" "-a"
 * "/fibus/fs3/01/wbku/gaja3d_07.07.08/utils/clipLine.m" "-a"
 * "/fibus/fs3/01/wbku/gaja3d_07.07.08/utils/constructRefMat.m" "-a"
 * "/fibus/fs3/01/wbku/gaja3d_07.07.08/utils/createGrid.m" "-a"
 * "/fibus/fs3/01/wbku/gaja3d_07.07.08/utils/exportArea.m" "-a"
 * "/fibus/fs3/01/wbku/gaja3d_07.07.08/utils/exportNodeEle.m" "-a"
 * "/fibus/fs3/01/wbku/gaja3d_07.07.08/utils/exportNodes.m" "-a"
 * "/fibus/fs3/01/wbku/gaja3d_07.07.08/utils/exportPoly.m" "-a"
 * "/fibus/fs3/01/wbku/gaja3d_07.07.08/utils/getPointInPolygon.m" "-a"
 * "/fibus/fs3/01/wbku/gaja3d_07.07.08/utils/griddedBoundaries.m" "-a"
 * "/fibus/fs3/01/wbku/gaja3d_07.07.08/utils/gridfit.m" "-a"
 * "/fibus/fs3/01/wbku/gaja3d_07.07.08/utils/interptri.m" "-a"
 * "/fibus/fs3/01/wbku/gaja3d_07.07.08/utils/reduceToBoundary.m" 
 */

#include "mclmcrrt.h"

#ifdef __cplusplus
extern "C" {
#endif
const unsigned char __MCC_Gaja3dService_session_key[] = {
    'B', 'E', 'E', '8', 'B', '6', '7', '2', '1', 'D', 'C', 'A', 'A', 'D', 'E',
    'C', 'B', '9', 'B', '3', 'C', '4', '1', '9', 'B', 'D', '3', '4', 'A', '9',
    'C', '3', 'D', '7', '8', '1', '8', '6', 'B', '8', '6', '0', '8', 'D', 'D',
    '9', 'D', 'E', 'E', '1', 'F', '4', 'D', '4', 'A', '1', 'A', '0', '5', '3',
    '9', '5', 'C', 'C', '4', 'B', '3', 'B', '1', '8', 'D', '6', '7', '5', '9',
    '1', 'F', '3', '0', 'D', '2', '0', 'F', '1', '0', '8', 'C', '1', '4', 'A',
    'B', '3', '5', 'F', '9', 'C', '8', 'E', '0', '3', 'F', '2', '5', '3', 'F',
    '1', 'D', 'D', '2', '8', 'D', '3', 'B', '8', '7', '4', '8', '4', '2', '8',
    '3', 'E', '9', 'B', '6', '4', 'C', '4', '7', 'E', '3', '3', 'D', 'F', '4',
    '6', '7', '4', 'A', 'C', '8', 'F', '9', 'A', '9', '2', '6', 'B', 'B', '8',
    'F', 'F', '6', '4', '2', 'B', '2', 'D', 'F', '7', '0', 'B', 'A', '6', '0',
    '0', '4', '2', '8', '4', 'C', '2', '9', '6', 'C', 'A', 'A', '6', '0', '9',
    'F', '5', 'B', '5', '3', 'E', '0', '4', '8', '5', 'C', '9', 'D', '9', '3',
    '3', 'D', 'E', '3', '3', '3', '4', '7', '9', '0', 'C', 'D', '7', '3', '5',
    '0', '4', '3', '4', '6', '4', 'C', '8', '9', '2', '1', '7', 'C', '4', '2',
    'A', 'C', '2', 'F', 'D', 'B', '3', '0', 'E', '9', '8', 'B', '3', '1', '6',
    '6', '3', '1', '3', '3', '2', 'E', '6', 'F', '0', 'B', '8', '3', '3', 'D',
    '2', '\0'};

const unsigned char __MCC_Gaja3dService_public_key[] = {
    '3', '0', '8', '1', '9', 'D', '3', '0', '0', 'D', '0', '6', '0', '9', '2',
    'A', '8', '6', '4', '8', '8', '6', 'F', '7', '0', 'D', '0', '1', '0', '1',
    '0', '1', '0', '5', '0', '0', '0', '3', '8', '1', '8', 'B', '0', '0', '3',
    '0', '8', '1', '8', '7', '0', '2', '8', '1', '8', '1', '0', '0', 'C', '4',
    '9', 'C', 'A', 'C', '3', '4', 'E', 'D', '1', '3', 'A', '5', '2', '0', '6',
    '5', '8', 'F', '6', 'F', '8', 'E', '0', '1', '3', '8', 'C', '4', '3', '1',
    '5', 'B', '4', '3', '1', '5', '2', '7', '7', 'E', 'D', '3', 'F', '7', 'D',
    'A', 'E', '5', '3', '0', '9', '9', 'D', 'B', '0', '8', 'E', 'E', '5', '8',
    '9', 'F', '8', '0', '4', 'D', '4', 'B', '9', '8', '1', '3', '2', '6', 'A',
    '5', '2', 'C', 'C', 'E', '4', '3', '8', '2', 'E', '9', 'F', '2', 'B', '4',
    'D', '0', '8', '5', 'E', 'B', '9', '5', '0', 'C', '7', 'A', 'B', '1', '2',
    'E', 'D', 'E', '2', 'D', '4', '1', '2', '9', '7', '8', '2', '0', 'E', '6',
    '3', '7', '7', 'A', '5', 'F', 'E', 'B', '5', '6', '8', '9', 'D', '4', 'E',
    '6', '0', '3', '2', 'F', '6', '0', 'C', '4', '3', '0', '7', '4', 'A', '0',
    '4', 'C', '2', '6', 'A', 'B', '7', '2', 'F', '5', '4', 'B', '5', '1', 'B',
    'B', '4', '6', '0', '5', '7', '8', '7', '8', '5', 'B', '1', '9', '9', '0',
    '1', '4', '3', '1', '4', 'A', '6', '5', 'F', '0', '9', '0', 'B', '6', '1',
    'F', 'C', '2', '0', '1', '6', '9', '4', '5', '3', 'B', '5', '8', 'F', 'C',
    '8', 'B', 'A', '4', '3', 'E', '6', '7', '7', '6', 'E', 'B', '7', 'E', 'C',
    'D', '3', '1', '7', '8', 'B', '5', '6', 'A', 'B', '0', 'F', 'A', '0', '6',
    'D', 'D', '6', '4', '9', '6', '7', 'C', 'B', '1', '4', '9', 'E', '5', '0',
    '2', '0', '1', '1', '1', '\0'};

static const char * MCC_Gaja3dService_matlabpath_data[] = 
  { "Gaja3dServic/", "toolbox/compiler/deploy/", "Gaja3dService/", "data/",
    "utils/", "$TOOLBOXMATLABDIR/general/", "$TOOLBOXMATLABDIR/ops/",
    "$TOOLBOXMATLABDIR/lang/", "$TOOLBOXMATLABDIR/elmat/",
    "$TOOLBOXMATLABDIR/elfun/", "$TOOLBOXMATLABDIR/specfun/",
    "$TOOLBOXMATLABDIR/matfun/", "$TOOLBOXMATLABDIR/datafun/",
    "$TOOLBOXMATLABDIR/polyfun/", "$TOOLBOXMATLABDIR/funfun/",
    "$TOOLBOXMATLABDIR/sparfun/", "$TOOLBOXMATLABDIR/scribe/",
    "$TOOLBOXMATLABDIR/graph2d/", "$TOOLBOXMATLABDIR/graph3d/",
    "$TOOLBOXMATLABDIR/specgraph/", "$TOOLBOXMATLABDIR/graphics/",
    "$TOOLBOXMATLABDIR/uitools/", "$TOOLBOXMATLABDIR/strfun/",
    "$TOOLBOXMATLABDIR/imagesci/", "$TOOLBOXMATLABDIR/iofun/",
    "$TOOLBOXMATLABDIR/audiovideo/", "$TOOLBOXMATLABDIR/timefun/",
    "$TOOLBOXMATLABDIR/datatypes/", "$TOOLBOXMATLABDIR/verctrl/",
    "$TOOLBOXMATLABDIR/codetools/", "$TOOLBOXMATLABDIR/helptools/",
    "$TOOLBOXMATLABDIR/demos/", "$TOOLBOXMATLABDIR/timeseries/",
    "$TOOLBOXMATLABDIR/hds/", "$TOOLBOXMATLABDIR/guide/",
    "$TOOLBOXMATLABDIR/plottools/", "toolbox/local/",
    "toolbox/shared/dastudio/", "$TOOLBOXMATLABDIR/datamanager/",
    "toolbox/compiler/", "toolbox/images/images/", "toolbox/images/imuitools/",
    "toolbox/images/iptutils/", "toolbox/shared/imageslib/",
    "toolbox/images/medformats/", "toolbox/map/map/", "toolbox/map/mapdemos/",
    "toolbox/map/mapdisp/", "toolbox/map/mapformats/", "toolbox/map/mapproj/",
    "toolbox/shared/mapgeodesy/", "toolbox/map/maputils/" };

static const char * MCC_Gaja3dService_classpath_data[] = 
  { "java/jar/toolbox/images.jar" };

static const char * MCC_Gaja3dService_libpath_data[] = 
  { "" };

static const char * MCC_Gaja3dService_app_opts_data[] = 
  { "" };

static const char * MCC_Gaja3dService_run_opts_data[] = 
  { "" };

static const char * MCC_Gaja3dService_warning_state_data[] = 
  { "off:MATLAB:dispatcher:nameConflict" };


mclComponentData __MCC_Gaja3dService_component_data = { 

  /* Public key data */
  __MCC_Gaja3dService_public_key,

  /* Component name */
  "Gaja3dService",

  /* Component Root */
  "",

  /* Application key data */
  __MCC_Gaja3dService_session_key,

  /* Component's MATLAB Path */
  MCC_Gaja3dService_matlabpath_data,

  /* Number of directories in the MATLAB Path */
  52,

  /* Component's Java class path */
  MCC_Gaja3dService_classpath_data,
  /* Number of directories in the Java class path */
  1,

  /* Component's load library path (for extra shared libraries) */
  MCC_Gaja3dService_libpath_data,
  /* Number of directories in the load library path */
  0,

  /* MCR instance-specific runtime options */
  MCC_Gaja3dService_app_opts_data,
  /* Number of MCR instance-specific runtime options */
  0,

  /* MCR global runtime options */
  MCC_Gaja3dService_run_opts_data,
  /* Number of MCR global runtime options */
  0,
  
  /* Component preferences directory */
  "Gaja3dServic_D2C00530A250C4E91BD244338E1D2189",

  /* MCR warning status data */
  MCC_Gaja3dService_warning_state_data,
  /* Number of MCR warning status modifiers */
  1,

  /* Path to component - evaluated at runtime */
  NULL

};

#ifdef __cplusplus
}
#endif


