



          *****************************************************
          *****************************************************
          ****                                             ****
          ****      HAMBURG UNIVERSITY OF TECHNOLOGY       ****
          ****                                             ****
          **** Department of River and Coastal Engineering ****
          ****                                             ****
          ****                                             ****
          ****            K A L Y P S O - N A              ****
          ****                                             ****
          ****                                             ****
          ****           Rainfall-Runoff-Model             ****
          ****                                             ****
          ****                                             ****
          ****                                             ****
          ****     VERS.  2.0.6      STATUS: 01.08.2006    ****
          ****                                             ****
          ****                                             ****
          ****     Contact:          Dipl.-Ing J. H�bsch   ****
          ****                       j.huebsch@tuhh.de     ****
          *****************************************************
          *****************************************************




 Bearbeitung Fall / Berechnungseinstellungen aus Steuerungsdatei:
 ----------------------------------------------------------------
 2 .. we nat  1996 08 24 00 1996 08 30 22 start\we_nat_start.txt                                                         


 Anzahl der Straenge in der Netzdatei:    182

 Anzahl der Teilgebiete in der Netzdatei:  77



 K U R Z Z E I T S I M U L A T I O N
 Zyklus (iz):                         1
 Anfangsdatum Zyklus (idatsa):   960824
 Enddatum Zyklus (idatse):       960830
 Zeitschritte (idif):              1993


 ************************************************************************************
 *  Neuer Jahreszyklus                                                              *
 *      Jahr:    1996                                                              *
 *      Zyklus:     1                                                              *
 ************************************************************************************
 Auswertung des Stranges:         1000

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4503

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    1.11

 gesamtmenge an niederschlag (mm):       39.6

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     63


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  1.000


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4503
 anzahl hydrotope:      63


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      39.6 mm
 interz.verd.:                       5.7 mm
 bestandsniederschlag:              31.8 mm
 differenz interz.speicher:         -2.1 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      15.5 mm
 aktuelle verdunstung:               8.8 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              31.8 mm
 overlandflow:                       0.8 mm
 [infiltration:                     31.1 mm]
 verdunstung (bodensp.):             3.1 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -27.9 mm
 fehler:                             0.0 mm


 0.00000000E+00  -> zufluss grundwasserleiter in  4503
TG:    4503 -> TG:    4500
Prozent:0.20

TG:    4503 -> TG:    4501
Prozent:0.10

TG:    4503 -> TG:    4506
Prozent:0.20

TG:    4503 -> TG:    4504
Prozent:0.50


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:            0.0 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:           2.0 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                -0.9 mm
     pot.entnahme GWS:                -0.9 mm
 speicherinhaltsaenderung:            -1.1 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.872 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.872 qkm



 ISO: Normierungsfaktor   = 1.0001
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =           656.139
niederschlag =      656.139
flaeche zft  =        1.000
flaeche eing.=        0.872

GEBIET: Abflusswelle Interflow:

 ISO: Normierungsfaktor   = 1.0001
 ISO: Summe normierter uh =   1.0000


 Anzahl der Zeitschritte in iso durch Nachlauf zu hoch geworden.
 Sie wird auf 460 begrenzt !  gebiet :  4503

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.872

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV: Retentionskonstanten:   2.2       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =       1.00
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH =  400
ISOV:  fuellenberechnung
ISOV: Abflusz =          2389.599
ISOV: Niederschlag =     2389.603

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
ISOV: Retentionskonstanten:6000.0       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =   96602.20
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH = 2880
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1001

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4501

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    1.11

 gesamtmenge an niederschlag (mm):       39.6

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     18


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  1.000


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4501
 anzahl hydrotope:      18


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      39.6 mm
 interz.verd.:                       5.6 mm
 bestandsniederschlag:              32.0 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      15.7 mm
 aktuelle verdunstung:              11.1 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              32.0 mm
 overlandflow:                      14.6 mm
 [infiltration:                     17.4 mm]
 verdunstung (bodensp.):             5.5 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -12.0 mm
 fehler:                             0.0 mm


 0.575069070  -> zufluss grundwasserleiter in  4501
TG:    4501 -> TG:    4502
Prozent:0.80

TG:    4501 -> TG:    4506
Prozent:0.20


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:            1.5 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:           2.4 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -0.9 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.115 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.115 qkm



 ISO: Normierungsfaktor   = 1.0001
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =          1669.401
niederschlag =     1669.401
flaeche zft  =        1.000
flaeche eing.=        0.115

GEBIET: Abflusswelle Interflow:

 ISO: Normierungsfaktor   = 1.0001
 ISO: Summe normierter uh =   1.0000


 Anzahl der Zeitschritte in iso durch Nachlauf zu hoch geworden.
 Sie wird auf 460 begrenzt !  gebiet :  4501

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.115

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV: Retentionskonstanten:   2.0       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =       1.00
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH =  374
ISOV:  fuellenberechnung
ISOV: Abflusz =            92.696
ISOV: Niederschlag =       92.696

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
ISOV: Retentionskonstanten:6000.0       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =   96602.20
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH = 2880
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1002

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4506

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    1.11

 gesamtmenge an niederschlag (mm):       39.6

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     16


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  1.000


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4506
 anzahl hydrotope:      16


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      39.6 mm
 interz.verd.:                       5.6 mm
 bestandsniederschlag:              32.1 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      15.5 mm
 aktuelle verdunstung:              10.9 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              32.1 mm
 overlandflow:                      14.6 mm
 [infiltration:                     17.5 mm]
 verdunstung (bodensp.):             5.4 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -12.1 mm
 fehler:                             0.0 mm


 1.33030891  -> zufluss grundwasserleiter in  4506
TG:    4506 -> TG:    4510
Prozent:1.00


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:            2.0 mm
 abgabe basisabfluss:                  0.1 mm
        grundw. unterh.l.TG:           2.8 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -0.9 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.196 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.196 qkm



 ISO: Normierungsfaktor   = 1.0001
 ISO: Summe normierter uh =   1.0000


 Anzahl der Zeitschritte in iso durch Nachlauf zu hoch geworden.
 Sie wird auf 460 begrenzt !  gebiet :  4506

fuellenberechnung in iso
abflusz =          2858.788
niederschlag =     2858.789
flaeche zft  =        1.000
flaeche eing.=        0.196

GEBIET: Abflusswelle Interflow:

 ISO: Normierungsfaktor   = 1.0001
 ISO: Summe normierter uh =   1.0000


 Anzahl der Zeitschritte in iso durch Nachlauf zu hoch geworden.
 Sie wird auf 460 begrenzt !  gebiet :  4506

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.196

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV: Retentionskonstanten:   3.0       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =       1.00
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH =  544
ISOV:  fuellenberechnung
ISOV: Abflusz =            40.007
ISOV: Niederschlag =       40.007

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
ISOV: Retentionskonstanten:6000.0       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =   96602.20
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH = 2880
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1003

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4504

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    1.11

 gesamtmenge an niederschlag (mm):       39.6

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     86


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  1.250


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4504
 anzahl hydrotope:      86


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      39.6 mm
 interz.verd.:                       5.6 mm
 bestandsniederschlag:              32.0 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      16.0 mm
 aktuelle verdunstung:               9.6 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              32.0 mm
 overlandflow:                       5.7 mm
 [infiltration:                     26.3 mm]
 verdunstung (bodensp.):             4.0 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -22.3 mm
 fehler:                             0.0 mm


 2.87534523  -> zufluss grundwasserleiter in  4504
TG:    4504 -> TG:    4510
Prozent:0.20

TG:    4504 -> TG:    4509
Prozent:0.80


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:            1.4 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:           2.6 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -1.2 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.621 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.621 qkm



 ISO: Normierungsfaktor   = 1.0001
 ISO: Summe normierter uh =   1.0000


 Anzahl der Zeitschritte in iso durch Nachlauf zu hoch geworden.
 Sie wird auf 460 begrenzt !  gebiet :  4504

fuellenberechnung in iso
abflusz =          3543.170
niederschlag =     3543.170
flaeche zft  =        1.000
flaeche eing.=        0.621

GEBIET: Abflusswelle Interflow:

 ISO: Normierungsfaktor   = 1.0001
 ISO: Summe normierter uh =   1.0000


 Anzahl der Zeitschritte in iso durch Nachlauf zu hoch geworden.
 Sie wird auf 460 begrenzt !  gebiet :  4504

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.621

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV: Retentionskonstanten:   1.8       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =       1.00
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH =  334
ISOV:  fuellenberechnung
ISOV: Abflusz =          3639.311
ISOV: Niederschlag =     3639.311

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
ISOV: Retentionskonstanten:6000.0       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =   96602.20
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH = 2880
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1004

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4510

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    1.11

 gesamtmenge an niederschlag (mm):       39.6

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:    106


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  1.500


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4510
 anzahl hydrotope:     106


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      39.6 mm
 interz.verd.:                       5.6 mm
 bestandsniederschlag:              32.0 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      15.9 mm
 aktuelle verdunstung:               9.4 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              32.0 mm
 overlandflow:                       0.7 mm
 [infiltration:                     31.4 mm]
 verdunstung (bodensp.):             3.8 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -27.5 mm
 fehler:                             0.0 mm


 2.89805770  -> zufluss grundwasserleiter in  4510
TG:    4510 -> TG:    4511
Prozent:0.20

TG:    4510 -> TG:    4526
Prozent:0.80


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:            1.8 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:           5.7 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -3.8 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.478 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.478 qkm



 ISO: Normierungsfaktor   = 1.0002
 ISO: Summe normierter uh =   1.0000


 Anzahl der Zeitschritte in iso durch Nachlauf zu hoch geworden.
 Sie wird auf 460 begrenzt !  gebiet :  4510

fuellenberechnung in iso
abflusz =           319.408
niederschlag =      319.960
flaeche zft  =        1.000
flaeche eing.=        0.478

GEBIET: Abflusswelle Interflow:

 ISO: Normierungsfaktor   = 1.0000
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.478

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV: Retentionskonstanten:   1.4       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =       1.00
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH =  264
ISOV:  fuellenberechnung
ISOV: Abflusz =          2706.774
ISOV: Niederschlag =     2706.779

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
ISOV: Retentionskonstanten:6000.0       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =   96602.20
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH = 2880
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1005

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4502

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    1.11

 gesamtmenge an niederschlag (mm):       39.6

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     77


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  1.000


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4502
 anzahl hydrotope:      77


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      39.6 mm
 interz.verd.:                       5.6 mm
 bestandsniederschlag:              32.1 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      15.5 mm
 aktuelle verdunstung:               9.0 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              32.1 mm
 overlandflow:                       2.5 mm
 [infiltration:                     29.6 mm]
 verdunstung (bodensp.):             3.4 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -26.2 mm
 fehler:                             0.0 mm


 0.720679641  -> zufluss grundwasserleiter in  4502
TG:    4502 -> TG:    4520
Prozent:0.40

TG:    4502 -> TG:    4523
Prozent:0.60


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:            0.5 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:           1.8 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -1.2 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.413 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.413 qkm



 ISO: Normierungsfaktor   = 1.0001
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =          1025.359
niederschlag =     1025.359
flaeche zft  =        1.000
flaeche eing.=        0.413

GEBIET: Abflusswelle Interflow:

 ISO: Normierungsfaktor   = 1.0001
 ISO: Summe normierter uh =   1.0000


 Anzahl der Zeitschritte in iso durch Nachlauf zu hoch geworden.
 Sie wird auf 460 begrenzt !  gebiet :  4502

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.413

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV: Retentionskonstanten:   1.2       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =       1.00
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH =  239
ISOV:  fuellenberechnung
ISOV: Abflusz =          3621.367
ISOV: Niederschlag =     3621.369

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
ISOV: Retentionskonstanten:6000.0       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =   96602.20
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH = 2880
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1006

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4500

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    1.11

 gesamtmenge an niederschlag (mm):       39.6

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:    125


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  1.000


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4500
 anzahl hydrotope:     125


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      39.6 mm
 interz.verd.:                       5.6 mm
 bestandsniederschlag:              32.0 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      15.9 mm
 aktuelle verdunstung:               9.1 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              32.0 mm
 overlandflow:                       1.9 mm
 [infiltration:                     30.2 mm]
 verdunstung (bodensp.):             3.5 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -26.6 mm
 fehler:                             0.0 mm


 1.15013814  -> zufluss grundwasserleiter in  4500
TG:    4500 -> TG:    4516
Prozent:0.60

TG:    4500 -> TG:    4520
Prozent:0.40


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:            0.4 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:           2.2 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                -0.9 mm
     pot.entnahme GWS:                -0.9 mm
 speicherinhaltsaenderung:            -1.0 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.933 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.933 qkm



 ISO: Normierungsfaktor   = 1.0001
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =          1742.978
niederschlag =     1742.977
flaeche zft  =        1.000
flaeche eing.=        0.933

GEBIET: Abflusswelle Interflow:

 ISO: Normierungsfaktor   = 1.0001
 ISO: Summe normierter uh =   1.0000


 Anzahl der Zeitschritte in iso durch Nachlauf zu hoch geworden.
 Sie wird auf 460 begrenzt !  gebiet :  4500

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.933

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV: Retentionskonstanten:   2.0       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =       1.00
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH =  380
ISOV:  fuellenberechnung
ISOV: Abflusz =          6712.470
ISOV: Niederschlag =     6712.466

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
ISOV: Retentionskonstanten:6000.0       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =   96602.20
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH = 2880
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1007

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4512

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    1.11

 gesamtmenge an niederschlag (mm):       39.6

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     33


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  3.800


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4512
 anzahl hydrotope:      33


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      39.6 mm
 interz.verd.:                       5.6 mm
 bestandsniederschlag:              32.0 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      16.1 mm
 aktuelle verdunstung:               8.8 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              32.0 mm
 overlandflow:                       0.0 mm
 [infiltration:                     32.0 mm]
 verdunstung (bodensp.):             3.1 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -28.9 mm
 fehler:                             0.0 mm


 entnahme gws [qbm/s]:       0.001
 0.00000000E+00  -> zufluss grundwasserleiter in  4512
TG:    4512 -> TG:    4513
Prozent:0.10

TG:    4512 -> TG:    4514
Prozent:0.90


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:            0.0 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:           1.9 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 1.0 mm
     pot.entnahme GWS:                 1.0 mm
 speicherinhaltsaenderung:            -2.9 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.408 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.408 qkm



 ISO: Normierungsfaktor   = 1.0002
 ISO: Summe normierter uh =   1.0000


 Anzahl der Zeitschritte in iso durch Nachlauf zu hoch geworden.
 Sie wird auf 460 begrenzt !  gebiet :  4512

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.408

GEBIET: Abflusswelle Interflow:

 ISO: Normierungsfaktor   = 1.0000
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.408

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV: Retentionskonstanten:   1.4       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =       1.00
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH =  264
ISOV:  fuellenberechnung
ISOV: Abflusz =          2612.527
ISOV: Niederschlag =     2612.530

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
ISOV: Retentionskonstanten:6000.0       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =   96602.20
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH = 2880
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1008

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4513

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    1.11

 gesamtmenge an niederschlag (mm):       39.6

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     13


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  2.300


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4513
 anzahl hydrotope:      13


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      39.6 mm
 interz.verd.:                       5.6 mm
 bestandsniederschlag:              32.1 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      15.9 mm
 aktuelle verdunstung:               8.7 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              32.1 mm
 overlandflow:                       0.0 mm
 [infiltration:                     32.1 mm]
 verdunstung (bodensp.):             3.1 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -29.0 mm
 fehler:                             0.0 mm


 entnahme gws [qbm/s]:       0.000
 0.257184803  -> zufluss grundwasserleiter in  4513
TG:    4513 -> TG:    4516
Prozent:1.00


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:            0.4 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:           3.4 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.2 mm
     pot.entnahme GWS:                 0.2 mm
 speicherinhaltsaenderung:            -3.2 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.207 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.207 qkm



 ISO: Normierungsfaktor   = 1.0002
 ISO: Summe normierter uh =   1.0000


 Anzahl der Zeitschritte in iso durch Nachlauf zu hoch geworden.
 Sie wird auf 460 begrenzt !  gebiet :  4513

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.207

GEBIET: Abflusswelle Interflow:

 ISO: Normierungsfaktor   = 1.0000
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.207

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV: Retentionskonstanten:   1.4       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =       1.00
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH =  264
ISOV:  fuellenberechnung
ISOV: Abflusz =          1179.553
ISOV: Niederschlag =     1179.553

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
ISOV: Retentionskonstanten:6000.0       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =   96602.20
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH = 2880
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1009

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4516

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    1.11

 gesamtmenge an niederschlag (mm):       39.6

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     38


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  8.000


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4516
 anzahl hydrotope:      38


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      39.6 mm
 interz.verd.:                       5.6 mm
 bestandsniederschlag:              32.0 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      16.1 mm
 aktuelle verdunstung:               8.8 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              32.0 mm
 overlandflow:                       0.0 mm
 [infiltration:                     32.0 mm]
 verdunstung (bodensp.):             3.1 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -28.9 mm
 fehler:                             0.0 mm


 6.44798565  -> zufluss grundwasserleiter in  4516
TG:    4516 -> TG:    4519
Prozent:0.65

TG:    4516 -> TG:    4520
Prozent:0.35


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:            4.5 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:          10.2 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -5.7 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.429 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.429 qkm



 ISO: Normierungsfaktor   = 1.0002
 ISO: Summe normierter uh =   1.0000


 Anzahl der Zeitschritte in iso durch Nachlauf zu hoch geworden.
 Sie wird auf 460 begrenzt !  gebiet :  4516

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.429

GEBIET: Abflusswelle Interflow:

 ISO: Normierungsfaktor   = 1.0000
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.429

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV: Retentionskonstanten:   1.4       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =       1.00
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH =  264
ISOV:  fuellenberechnung
ISOV: Abflusz =          2455.859
ISOV: Niederschlag =     2455.859

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
ISOV: Retentionskonstanten:6000.0       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =   96602.20
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH = 2880
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1010

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4520

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    1.11

 gesamtmenge an niederschlag (mm):       39.6

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     47


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  5.000


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4520
 anzahl hydrotope:      47


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      39.6 mm
 interz.verd.:                       5.6 mm
 bestandsniederschlag:              32.0 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      16.1 mm
 aktuelle verdunstung:               8.8 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              32.0 mm
 overlandflow:                       0.0 mm
 [infiltration:                     32.0 mm]
 verdunstung (bodensp.):             3.2 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -28.8 mm
 fehler:                             0.0 mm


 8.81579304  -> zufluss grundwasserleiter in  4520
TG:    4520 -> TG:    4522
Prozent:0.10

TG:    4520 -> TG:    4524
Prozent:0.75

TG:    4520 -> TG:    4523
Prozent:0.15


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:            6.5 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:          13.1 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -6.5 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.404 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.404 qkm



 ISO: Normierungsfaktor   = 1.0002
 ISO: Summe normierter uh =   1.0000


 Anzahl der Zeitschritte in iso durch Nachlauf zu hoch geworden.
 Sie wird auf 460 begrenzt !  gebiet :  4520

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.404

GEBIET: Abflusswelle Interflow:

 ISO: Normierungsfaktor   = 1.0000
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.404

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV: Retentionskonstanten:   1.4       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =       1.00
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH =  264
ISOV:  fuellenberechnung
ISOV: Abflusz =          2407.704
ISOV: Niederschlag =     2407.705

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
ISOV: Retentionskonstanten:6000.0       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =   96602.20
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH = 2880
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1011

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4523

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    1.11

 gesamtmenge an niederschlag (mm):       39.6

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     66


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  2.500


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4523
 anzahl hydrotope:      66


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      39.6 mm
 interz.verd.:                       5.7 mm
 bestandsniederschlag:              31.9 mm
 differenz interz.speicher:         -2.1 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      15.5 mm
 aktuelle verdunstung:               8.9 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              31.9 mm
 overlandflow:                       0.0 mm
 [infiltration:                     31.9 mm]
 verdunstung (bodensp.):             3.3 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -28.6 mm
 fehler:                             0.0 mm


 4.09409475  -> zufluss grundwasserleiter in  4523
TG:    4523 -> TG:    4526
Prozent:0.10

TG:    4523 -> TG:    4524
Prozent:0.90


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:            3.0 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:           7.5 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -4.6 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.416 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.416 qkm



 ISO: Normierungsfaktor   = 1.0002
 ISO: Summe normierter uh =   1.0000


 Anzahl der Zeitschritte in iso durch Nachlauf zu hoch geworden.
 Sie wird auf 460 begrenzt !  gebiet :  4523

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.416

GEBIET: Abflusswelle Interflow:

 ISO: Normierungsfaktor   = 1.0000
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.416

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV: Retentionskonstanten:   1.4       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =       1.00
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH =  264
ISOV:  fuellenberechnung
ISOV: Abflusz =          1914.619
ISOV: Niederschlag =     1914.619

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
ISOV: Retentionskonstanten:6000.0       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =   96602.20
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH = 2880
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1012

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4526

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    1.11

 gesamtmenge an niederschlag (mm):       39.6

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     86


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  1.000


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4526
 anzahl hydrotope:      86


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      39.6 mm
 interz.verd.:                       5.7 mm
 bestandsniederschlag:              31.8 mm
 differenz interz.speicher:         -2.1 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      15.8 mm
 aktuelle verdunstung:               9.7 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              31.8 mm
 overlandflow:                       0.3 mm
 [infiltration:                     31.5 mm]
 verdunstung (bodensp.):             4.0 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -27.5 mm
 fehler:                             0.0 mm


 8.27566338  -> zufluss grundwasserleiter in  4526
TG:    4526 -> TG:    4532
Prozent:0.50

TG:    4526 -> TG:    4566
Prozent:0.20

TG:    4526 -> TG:    4567
Prozent:0.30


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:            4.1 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:           9.0 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -5.0 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.608 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.608 qkm



 ISO: Normierungsfaktor   = 1.0002
 ISO: Summe normierter uh =   1.0000


 Anzahl der Zeitschritte in iso durch Nachlauf zu hoch geworden.
 Sie wird auf 460 begrenzt !  gebiet :  4526

fuellenberechnung in iso
abflusz =           168.213
niederschlag =      168.504
flaeche zft  =        1.000
flaeche eing.=        0.608

GEBIET: Abflusswelle Interflow:

 ISO: Normierungsfaktor   = 1.0000
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.608

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV: Retentionskonstanten:   1.4       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =       1.00
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH =  264
ISOV:  fuellenberechnung
ISOV: Abflusz =          2374.699
ISOV: Niederschlag =     2374.703

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
ISOV: Retentionskonstanten:6000.0       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =   96602.20
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH = 2880
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1013

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4514

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    1.11

 gesamtmenge an niederschlag (mm):       39.6

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     96


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  8.000


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4514
 anzahl hydrotope:      96


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      39.6 mm
 interz.verd.:                       5.6 mm
 bestandsniederschlag:              32.0 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      16.1 mm
 aktuelle verdunstung:               8.9 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              32.0 mm
 overlandflow:                       0.0 mm
 [infiltration:                     32.0 mm]
 verdunstung (bodensp.):             3.2 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -28.8 mm
 fehler:                             0.0 mm


 2.31466365  -> zufluss grundwasserleiter in  4514
TG:    4514 -> TG:    4515
Prozent:0.15

TG:    4514 -> TG:    4518
Prozent:0.20

TG:    4514 -> TG:    4519
Prozent:0.65


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:            1.0 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:           5.3 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -4.3 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.701 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.701 qkm



 ISO: Normierungsfaktor   = 1.0002
 ISO: Summe normierter uh =   1.0000


 Anzahl der Zeitschritte in iso durch Nachlauf zu hoch geworden.
 Sie wird auf 460 begrenzt !  gebiet :  4514

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.701

GEBIET: Abflusswelle Interflow:

 ISO: Normierungsfaktor   = 1.0000
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.701

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV: Retentionskonstanten:   1.4       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =       1.00
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH =  264
ISOV:  fuellenberechnung
ISOV: Abflusz =          5365.399
ISOV: Niederschlag =     5365.402

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
ISOV: Retentionskonstanten:6000.0       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =   96602.20
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH = 2880
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1014

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4515

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    1.11

 gesamtmenge an niederschlag (mm):       39.6

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     23


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  8.000


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4515
 anzahl hydrotope:      23


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      39.6 mm
 interz.verd.:                       5.3 mm
 bestandsniederschlag:              32.6 mm
 differenz interz.speicher:         -1.8 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      13.7 mm
 aktuelle verdunstung:               8.0 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              32.6 mm
 overlandflow:                       0.0 mm
 [infiltration:                     32.6 mm]
 verdunstung (bodensp.):             2.8 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -29.8 mm
 fehler:                             0.0 mm


 1.84850907  -> zufluss grundwasserleiter in  4515
TG:    4515 -> TG:    4519
Prozent:1.00


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:            9.3 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:          11.1 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -1.8 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.060 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.060 qkm



 ISO: Normierungsfaktor   = 1.0002
 ISO: Summe normierter uh =   1.0000


 Anzahl der Zeitschritte in iso durch Nachlauf zu hoch geworden.
 Sie wird auf 460 begrenzt !  gebiet :  4515

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.060

GEBIET: Abflusswelle Interflow:

 ISO: Normierungsfaktor   = 1.0000
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.060

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV: Retentionskonstanten:   0.6       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =       1.00
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH =  125
ISOV:  fuellenberechnung
ISOV: Abflusz =           904.922
ISOV: Niederschlag =      904.922

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
ISOV: Retentionskonstanten:6000.0       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =   96602.20
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH = 2880
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1015

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4518

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    1.11

 gesamtmenge an niederschlag (mm):       39.6

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     15


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  2.000


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4518
 anzahl hydrotope:      15


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      39.6 mm
 interz.verd.:                       5.6 mm
 bestandsniederschlag:              32.1 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      15.6 mm
 aktuelle verdunstung:               8.7 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              32.1 mm
 overlandflow:                       0.0 mm
 [infiltration:                     32.1 mm]
 verdunstung (bodensp.):             3.1 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -28.9 mm
 fehler:                             0.0 mm


 2.46467853  -> zufluss grundwasserleiter in  4518
TG:    4518 -> TG:    4519
Prozent:1.00


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:           36.3 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:          43.0 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -6.6 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.020 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.020 qkm



 ISO: Normierungsfaktor   = 1.0002
 ISO: Summe normierter uh =   1.0000


 Anzahl der Zeitschritte in iso durch Nachlauf zu hoch geworden.
 Sie wird auf 460 begrenzt !  gebiet :  4518

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.020

GEBIET: Abflusswelle Interflow:

 ISO: Normierungsfaktor   = 1.0000
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.020

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV: Retentionskonstanten:   0.6       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =       1.00
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH =  125
ISOV:  fuellenberechnung
ISOV: Abflusz =            35.696
ISOV: Niederschlag =       35.696

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
ISOV: Retentionskonstanten:6000.0       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =   96602.20
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH = 2880
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1016

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4519

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    1.11

 gesamtmenge an niederschlag (mm):       39.6

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     73


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  7.000


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4519
 anzahl hydrotope:      73


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      39.6 mm
 interz.verd.:                       5.5 mm
 bestandsniederschlag:              32.2 mm
 differenz interz.speicher:         -1.9 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      15.4 mm
 aktuelle verdunstung:               8.9 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              32.2 mm
 overlandflow:                       0.0 mm
 [infiltration:                     32.2 mm]
 verdunstung (bodensp.):             3.3 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -28.8 mm
 fehler:                             0.0 mm


 22.6299171  -> zufluss grundwasserleiter in  4519
TG:    4519 -> TG:    4522
Prozent:0.60

TG:    4519 -> TG:    4527
Prozent:0.20

TG:    4519 -> TG:    4530
Prozent:0.10

TG:    4519 -> TG:    4529
Prozent:0.10


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:           24.9 mm
 abgabe basisabfluss:                  4.7 mm
        grundw. unterh.l.TG:          21.2 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -1.0 mm
 fehler:                               0.1 mm


 flaechenanteile: 

   grundwasserleiter:                0.272 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.272 qkm



 ISO: Normierungsfaktor   = 1.0002
 ISO: Summe normierter uh =   1.0000


 Anzahl der Zeitschritte in iso durch Nachlauf zu hoch geworden.
 Sie wird auf 460 begrenzt !  gebiet :  4519

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.272

GEBIET: Abflusswelle Interflow:

 ISO: Normierungsfaktor   = 1.0000
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.272

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV: Retentionskonstanten:   1.2       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =       1.00
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH =  236
ISOV:  fuellenberechnung
ISOV: Abflusz =          1713.724
ISOV: Niederschlag =     1713.725

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
ISOV: Retentionskonstanten:6000.0       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =   96602.20
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH = 2880
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1017

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4522

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    1.11

 gesamtmenge an niederschlag (mm):       39.6

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     19


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  5.000


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4522
 anzahl hydrotope:      19


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      39.6 mm
 interz.verd.:                       5.3 mm
 bestandsniederschlag:              32.5 mm
 differenz interz.speicher:         -1.8 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      14.0 mm
 aktuelle verdunstung:               8.5 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              32.5 mm
 overlandflow:                       0.0 mm
 [infiltration:                     32.5 mm]
 verdunstung (bodensp.):             3.2 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -29.3 mm
 fehler:                             0.0 mm


 13.2926903  -> zufluss grundwasserleiter in  4522
TG:    4522 -> TG:    4524
Prozent:0.60

TG:    4522 -> TG:    4532
Prozent:0.40


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:          111.2 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:         113.6 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -2.5 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.036 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.036 qkm



 ISO: Normierungsfaktor   = 1.0002
 ISO: Summe normierter uh =   1.0000


 Anzahl der Zeitschritte in iso durch Nachlauf zu hoch geworden.
 Sie wird auf 460 begrenzt !  gebiet :  4522

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.036

GEBIET: Abflusswelle Interflow:

 ISO: Normierungsfaktor   = 1.0000
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.036

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV: Retentionskonstanten:   0.6       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =       1.00
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH =  125
ISOV:  fuellenberechnung
ISOV: Abflusz =           549.928
ISOV: Niederschlag =      549.928

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
ISOV: Retentionskonstanten:6000.0       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =   96602.20
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH = 2880
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1018

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4524

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    1.11

 gesamtmenge an niederschlag (mm):       39.6

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     41


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 = 10.000


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4524
 anzahl hydrotope:      41


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      39.6 mm
 interz.verd.:                       5.7 mm
 bestandsniederschlag:              31.5 mm
 differenz interz.speicher:         -2.5 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      14.8 mm
 aktuelle verdunstung:               9.1 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              31.5 mm
 overlandflow:                       0.0 mm
 [infiltration:                     31.5 mm]
 verdunstung (bodensp.):             3.4 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -28.0 mm
 fehler:                             0.0 mm


 30.7882748  -> zufluss grundwasserleiter in  4524
TG:    4524 -> TG:    4532
Prozent:1.00


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:           39.5 mm
 abgabe basisabfluss:                  9.9 mm
        grundw. unterh.l.TG:          30.4 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -0.9 mm
 fehler:                               0.1 mm


 flaechenanteile: 

   grundwasserleiter:                0.234 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.234 qkm



 ISO: Normierungsfaktor   = 1.0002
 ISO: Summe normierter uh =   1.0000


 Anzahl der Zeitschritte in iso durch Nachlauf zu hoch geworden.
 Sie wird auf 460 begrenzt !  gebiet :  4524

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.234

GEBIET: Abflusswelle Interflow:

 ISO: Normierungsfaktor   = 1.0000
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.234

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV: Retentionskonstanten:   2.8       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =       1.00
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH =  500
ISOV:  fuellenberechnung
ISOV: Abflusz =           238.681
ISOV: Niederschlag =      238.681

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
ISOV: Retentionskonstanten:6000.0       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =   96602.20
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH = 2880
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1019

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4527

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    1.11

 gesamtmenge an niederschlag (mm):       39.6

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     14


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  1.000


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4527
 anzahl hydrotope:      14


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      39.6 mm
 interz.verd.:                       5.6 mm
 bestandsniederschlag:              32.0 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      16.1 mm
 aktuelle verdunstung:               9.6 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              32.0 mm
 overlandflow:                       0.0 mm
 [infiltration:                     32.0 mm]
 verdunstung (bodensp.):             4.0 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -28.0 mm
 fehler:                             0.0 mm


 3.84314227  -> zufluss grundwasserleiter in  4527
TG:    4527 -> TG:    4530
Prozent:0.30

TG:    4527 -> TG:    4529
Prozent:0.70


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:            7.8 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:          10.6 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -2.8 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.148 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.148 qkm



 ISO: Normierungsfaktor   = 1.0002
 ISO: Summe normierter uh =   1.0000


 Anzahl der Zeitschritte in iso durch Nachlauf zu hoch geworden.
 Sie wird auf 460 begrenzt !  gebiet :  4527

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.148

GEBIET: Abflusswelle Interflow:

 ISO: Normierungsfaktor   = 1.0000
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.148

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV: Retentionskonstanten:   1.2       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =       1.00
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH =  236
ISOV:  fuellenberechnung
ISOV: Abflusz =          1090.504
ISOV: Niederschlag =     1090.503

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
ISOV: Retentionskonstanten:6000.0       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =   96602.20
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH = 2880
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1020

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4530

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    1.11

 gesamtmenge an niederschlag (mm):       39.6

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     67


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  2.500


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4530
 anzahl hydrotope:      67


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      39.6 mm
 interz.verd.:                       5.6 mm
 bestandsniederschlag:              32.0 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      16.0 mm
 aktuelle verdunstung:               9.7 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              32.0 mm
 overlandflow:                       0.0 mm
 [infiltration:                     32.0 mm]
 verdunstung (bodensp.):             4.1 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -28.0 mm
 fehler:                             0.0 mm


 3.48186660  -> zufluss grundwasserleiter in  4530
TG:    4530 -> TG:    4532
Prozent:0.70

TG:    4530 -> TG:    4563
Prozent:0.30


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:            3.8 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:           6.9 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -3.1 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.275 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.275 qkm



 ISO: Normierungsfaktor   = 1.0002
 ISO: Summe normierter uh =   1.0000


 Anzahl der Zeitschritte in iso durch Nachlauf zu hoch geworden.
 Sie wird auf 460 begrenzt !  gebiet :  4530

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.275

GEBIET: Abflusswelle Interflow:

 ISO: Normierungsfaktor   = 1.0000
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.275

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV: Retentionskonstanten:   1.2       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =       1.00
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH =  236
ISOV:  fuellenberechnung
ISOV: Abflusz =          1683.830
ISOV: Niederschlag =     1683.830

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
ISOV: Retentionskonstanten:6000.0       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =   96602.20
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH = 2880
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1021

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4532

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    1.11

 gesamtmenge an niederschlag (mm):       39.6

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     85


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  8.000


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4532
 anzahl hydrotope:      85


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      39.6 mm
 interz.verd.:                       6.1 mm
 bestandsniederschlag:              31.0 mm
 differenz interz.speicher:         -2.6 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      15.6 mm
 aktuelle verdunstung:               9.7 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              31.0 mm
 overlandflow:                       0.0 mm
 [infiltration:                     31.0 mm]
 verdunstung (bodensp.):             3.6 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -27.3 mm
 fehler:                             0.0 mm


 42.7466660  -> zufluss grundwasserleiter in  4532
TG:    4532 -> TG:    4563
Prozent:0.25

TG:    4532 -> TG:    4565
Prozent:0.25

TG:    4532 -> TG:    4566
Prozent:0.50


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:            8.8 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:          12.1 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -3.3 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                1.464 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    1.464 qkm



 ISO: Normierungsfaktor   = 1.0002
 ISO: Summe normierter uh =   1.0000


 Anzahl der Zeitschritte in iso durch Nachlauf zu hoch geworden.
 Sie wird auf 460 begrenzt !  gebiet :  4532

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        1.464

GEBIET: Abflusswelle Interflow:

 ISO: Normierungsfaktor   = 1.0000
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        1.464

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV: Retentionskonstanten:   3.1       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =       1.00
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH =  551
ISOV:  fuellenberechnung
ISOV: Abflusz =           731.482
ISOV: Niederschlag =      731.483

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
ISOV: Retentionskonstanten:6000.0       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =   96602.20
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH = 2880
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1022

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4534

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    1.11

 gesamtmenge an niederschlag (mm):       39.6

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     32


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  0.900
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  2.200


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4534
 anzahl hydrotope:      32


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      39.6 mm
 interz.verd.:                       5.6 mm
 bestandsniederschlag:              32.0 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      16.0 mm
 aktuelle verdunstung:               8.4 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              32.0 mm
 overlandflow:                       0.4 mm
 [infiltration:                     31.6 mm]
 verdunstung (bodensp.):             2.8 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -28.8 mm
 fehler:                             0.0 mm


 0.00000000E+00  -> zufluss grundwasserleiter in  4534
TG:    4534 -> TG:    4535
Prozent:0.50

TG:    4534 -> TG:    4542
Prozent:0.15

TG:    4534 -> TG:    4537
Prozent:0.35


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:            0.0 mm
 abgabe basisabfluss:                  1.3 mm
        grundw. unterh.l.TG:          11.8 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:               -13.1 mm
     pot.entnahme GWS:               -13.1 mm
 speicherinhaltsaenderung:             0.0 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.299 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.299 qkm



 ISO: Normierungsfaktor   = 1.0001
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =           129.370
niederschlag =      129.370
flaeche zft  =        1.000
flaeche eing.=        0.299

GEBIET: Abflusswelle Interflow:

 ISO: Normierungsfaktor   = 1.0000
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.299

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV: Retentionskonstanten:   0.2       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =       1.00
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH =   38
ISOV:  fuellenberechnung
ISOV: Abflusz =          2452.784
ISOV: Niederschlag =     2452.784

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
ISOV: Retentionskonstanten:6000.0       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =   96602.20
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH = 2880
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1023

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4542

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    1.11

 gesamtmenge an niederschlag (mm):       39.6

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     49


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  0.900
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  1.500


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4542
 anzahl hydrotope:      49


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      39.6 mm
 interz.verd.:                       5.6 mm
 bestandsniederschlag:              32.0 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      16.2 mm
 aktuelle verdunstung:               8.5 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              32.0 mm
 overlandflow:                       0.4 mm
 [infiltration:                     31.6 mm]
 verdunstung (bodensp.):             2.9 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -28.7 mm
 fehler:                             0.0 mm


 1.76380777  -> zufluss grundwasserleiter in  4542
TG:    4542 -> TG:    4543
Prozent:0.80

TG:    4542 -> TG:    4544
Prozent:0.20


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:            1.3 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:           3.3 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -2.0 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.395 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.395 qkm



 ISO: Normierungsfaktor   = 1.0001
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =           171.436
niederschlag =      171.436
flaeche zft  =        1.000
flaeche eing.=        0.395

GEBIET: Abflusswelle Interflow:

 ISO: Normierungsfaktor   = 1.0000
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.395

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV: Retentionskonstanten:   0.4       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =       1.00
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH =   90
ISOV:  fuellenberechnung
ISOV: Abflusz =          2121.441
ISOV: Niederschlag =     2121.440

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
ISOV: Retentionskonstanten:6000.0       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =   96602.20
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH = 2880
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1024

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4537

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    1.11

 gesamtmenge an niederschlag (mm):       39.6

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     19


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  0.900
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  2.700


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4537
 anzahl hydrotope:      19


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      39.6 mm
 interz.verd.:                       5.6 mm
 bestandsniederschlag:              32.0 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      16.1 mm
 aktuelle verdunstung:               8.5 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              32.0 mm
 overlandflow:                       0.4 mm
 [infiltration:                     31.6 mm]
 verdunstung (bodensp.):             2.9 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -28.7 mm
 fehler:                             0.0 mm


 4.11544704  -> zufluss grundwasserleiter in  4537
TG:    4537 -> TG:    4539
Prozent:0.90

TG:    4537 -> TG:    4543
Prozent:0.10


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:           19.4 mm
 abgabe basisabfluss:                  4.9 mm
        grundw. unterh.l.TG:          26.6 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:               -11.8 mm
     pot.entnahme GWS:               -11.8 mm
 speicherinhaltsaenderung:            -0.2 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.064 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.064 qkm



 ISO: Normierungsfaktor   = 1.0001
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =            27.602
niederschlag =       27.602
flaeche zft  =        1.000
flaeche eing.=        0.064

GEBIET: Abflusswelle Interflow:

 ISO: Normierungsfaktor   = 1.0000
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.064

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV: Retentionskonstanten:   0.5       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =       1.00
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH =  105
ISOV:  fuellenberechnung
ISOV: Abflusz =           350.746
ISOV: Niederschlag =      350.747

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
ISOV: Retentionskonstanten:6000.0       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =   96602.20
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH = 2880
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1025

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4543

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    1.11

 gesamtmenge an niederschlag (mm):       39.6

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     80


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  0.900
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  2.000


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4543
 anzahl hydrotope:      80


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      39.6 mm
 interz.verd.:                       5.6 mm
 bestandsniederschlag:              32.0 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      16.1 mm
 aktuelle verdunstung:               8.5 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              32.0 mm
 overlandflow:                       0.4 mm
 [infiltration:                     31.6 mm]
 verdunstung (bodensp.):             2.8 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -28.8 mm
 fehler:                             0.0 mm


 4.07773209  -> zufluss grundwasserleiter in  4543
TG:    4543 -> TG:    4544
Prozent:0.10

TG:    4543 -> TG:    4551
Prozent:0.50

TG:    4543 -> TG:    4549
Prozent:0.40


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:            1.3 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:           4.5 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -3.1 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.918 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.918 qkm



 ISO: Normierungsfaktor   = 1.0001
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =           399.670
niederschlag =      399.671
flaeche zft  =        1.000
flaeche eing.=        0.918

GEBIET: Abflusswelle Interflow:

 ISO: Normierungsfaktor   = 1.0000
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.918

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV: Retentionskonstanten:   0.4       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =       1.00
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH =   90
ISOV:  fuellenberechnung
ISOV: Abflusz =          5777.388
ISOV: Niederschlag =     5777.397

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
ISOV: Retentionskonstanten:6000.0       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =   96602.20
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH = 2880
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1026

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4549

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    1.11

 gesamtmenge an niederschlag (mm):       39.6

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     73


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  0.900
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  1.000


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4549
 anzahl hydrotope:      73


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      39.6 mm
 interz.verd.:                       5.6 mm
 bestandsniederschlag:              32.0 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      16.1 mm
 aktuelle verdunstung:               8.5 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              32.0 mm
 overlandflow:                       1.3 mm
 [infiltration:                     30.7 mm]
 verdunstung (bodensp.):             2.9 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -27.8 mm
 fehler:                             0.0 mm


 5.47681570  -> zufluss grundwasserleiter in  4549
TG:    4549 -> TG:    4551
Prozent:0.40

TG:    4549 -> TG:    4558
Prozent:0.60


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:            1.5 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:           6.1 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -4.6 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                1.076 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    1.076 qkm



 ISO: Normierungsfaktor   = 1.0001
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =          1437.763
niederschlag =     1437.763
flaeche zft  =        1.000
flaeche eing.=        1.076

GEBIET: Abflusswelle Interflow:

 ISO: Normierungsfaktor   = 1.0000
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        1.076

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV: Retentionskonstanten:   0.4       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =       1.00
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH =   86
ISOV:  fuellenberechnung
ISOV: Abflusz =          6455.620
ISOV: Niederschlag =     6455.621

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
ISOV: Retentionskonstanten:6000.0       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =   96602.20
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH = 2880
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1027

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4551

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    1.11

 gesamtmenge an niederschlag (mm):       39.6

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:    113


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  0.900
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  2.000


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4551
 anzahl hydrotope:     113


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      39.6 mm
 interz.verd.:                       5.6 mm
 bestandsniederschlag:              32.0 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      16.1 mm
 aktuelle verdunstung:               8.7 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              32.0 mm
 overlandflow:                       8.0 mm
 [infiltration:                     24.0 mm]
 verdunstung (bodensp.):             3.0 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -21.0 mm
 fehler:                             0.0 mm


 15.5802021  -> zufluss grundwasserleiter in  4551
TG:    4551 -> TG:    4553
Prozent:0.40

TG:    4551 -> TG:    4558
Prozent:0.30

TG:    4551 -> TG:    4552
Prozent:0.30


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:            7.3 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:          15.2 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -7.9 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.641 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.641 qkm



 ISO: Normierungsfaktor   = 1.0001
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =          5155.401
niederschlag =     5155.403
flaeche zft  =        1.000
flaeche eing.=        0.641

GEBIET: Abflusswelle Interflow:

 ISO: Normierungsfaktor   = 1.0000
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.641

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV: Retentionskonstanten:   0.4       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =       1.00
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH =   78
ISOV:  fuellenberechnung
ISOV: Abflusz =          3871.903
ISOV: Niederschlag =     3871.906

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
ISOV: Retentionskonstanten:6000.0       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =   96602.20
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH = 2880
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1028

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4552

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    1.11

 gesamtmenge an niederschlag (mm):       39.6

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     31


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  0.900
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  7.000


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4552
 anzahl hydrotope:      31


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      39.6 mm
 interz.verd.:                       5.6 mm
 bestandsniederschlag:              32.1 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      15.9 mm
 aktuelle verdunstung:               8.5 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              32.1 mm
 overlandflow:                       4.0 mm
 [infiltration:                     28.0 mm]
 verdunstung (bodensp.):             2.9 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -25.1 mm
 fehler:                             0.0 mm


 9.74566078  -> zufluss grundwasserleiter in  4552
TG:    4552 -> TG:    4553
Prozent:0.50

TG:    4552 -> TG:    4558
Prozent:0.50


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:           39.3 mm
 abgabe basisabfluss:                 17.6 mm
        grundw. unterh.l.TG:          22.5 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -1.0 mm
 fehler:                               0.2 mm


 flaechenanteile: 

   grundwasserleiter:                0.074 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.074 qkm



 ISO: Normierungsfaktor   = 1.0001
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =           301.150
niederschlag =      301.150
flaeche zft  =        1.000
flaeche eing.=        0.074

GEBIET: Abflusswelle Interflow:

 ISO: Normierungsfaktor   = 1.0000
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.074

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV: Retentionskonstanten:   0.2       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =       1.00
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH =   52
ISOV:  fuellenberechnung
ISOV: Abflusz =           667.731
ISOV: Niederschlag =      667.731

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
ISOV: Retentionskonstanten:6000.0       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =   96602.20
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH = 2880
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1029

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4553

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    1.11

 gesamtmenge an niederschlag (mm):       39.6

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     35


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  0.900
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 = 12.200


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4553
 anzahl hydrotope:      35


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      39.6 mm
 interz.verd.:                       5.6 mm
 bestandsniederschlag:              32.1 mm
 differenz interz.speicher:         -1.9 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      15.8 mm
 aktuelle verdunstung:               8.4 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              32.1 mm
 overlandflow:                       0.6 mm
 [infiltration:                     31.5 mm]
 verdunstung (bodensp.):             2.8 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -28.7 mm
 fehler:                             0.0 mm


 15.7821541  -> zufluss grundwasserleiter in  4553
TG:    4553 -> TG:    4558
Prozent:1.00


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:           78.5 mm
 abgabe basisabfluss:                 15.9 mm
        grundw. unterh.l.TG:          63.6 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -1.2 mm
 fehler:                               0.2 mm


 flaechenanteile: 

   grundwasserleiter:                0.060 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.060 qkm



 ISO: Normierungsfaktor   = 1.0001
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =            35.671
niederschlag =       35.671
flaeche zft  =        1.000
flaeche eing.=        0.060

GEBIET: Abflusswelle Interflow:

 ISO: Normierungsfaktor   = 1.0000
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.060

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV: Retentionskonstanten:   0.2       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =       1.00
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH =   36
ISOV:  fuellenberechnung
ISOV: Abflusz =           620.876
ISOV: Niederschlag =      620.876

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
ISOV: Retentionskonstanten:6000.0       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =   96602.20
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH = 2880
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1030

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4558

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    1.11

 gesamtmenge an niederschlag (mm):       39.6

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     90


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  0.900
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 = 10.000


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4558
 anzahl hydrotope:      90


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      39.6 mm
 interz.verd.:                       5.6 mm
 bestandsniederschlag:              32.0 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      15.9 mm
 aktuelle verdunstung:               9.1 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              32.0 mm
 overlandflow:                      10.1 mm
 [infiltration:                     21.9 mm]
 verdunstung (bodensp.):             3.5 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -18.5 mm
 fehler:                             0.0 mm


 38.4231071  -> zufluss grundwasserleiter in  4558
TG:    4558 -> TG:    4561
Prozent:0.50

TG:    4558 -> TG:    4564
Prozent:0.50


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:           28.8 mm
 abgabe basisabfluss:                  2.8 mm
        grundw. unterh.l.TG:          27.7 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -1.7 mm
 fehler:                               0.1 mm


 flaechenanteile: 

   grundwasserleiter:                0.400 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.400 qkm



 ISO: Normierungsfaktor   = 1.0001
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =          4041.527
niederschlag =     4041.531
flaeche zft  =        1.000
flaeche eing.=        0.400

GEBIET: Abflusswelle Interflow:

 ISO: Normierungsfaktor   = 1.0000
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.400

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV: Retentionskonstanten:   0.1       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =       1.00
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH =   32
ISOV:  fuellenberechnung
ISOV: Abflusz =          1891.413
ISOV: Niederschlag =     1891.413

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
ISOV: Retentionskonstanten:6000.0       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =   96602.20
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH = 2880
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1031

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4533

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    1.11

 gesamtmenge an niederschlag (mm):       39.6

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     26


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  0.900
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  0.500


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4533
 anzahl hydrotope:      26


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      39.6 mm
 interz.verd.:                       5.6 mm
 bestandsniederschlag:              32.0 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      16.1 mm
 aktuelle verdunstung:               8.5 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              32.0 mm
 overlandflow:                       0.4 mm
 [infiltration:                     31.6 mm]
 verdunstung (bodensp.):             2.8 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -28.8 mm
 fehler:                             0.0 mm


 entnahme gws [qbm/s]:       0.000
 0.00000000E+00  -> zufluss grundwasserleiter in  4533
TG:    4533 -> TG:    4535
Prozent:1.00


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:            0.0 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:           3.5 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.2 mm
     pot.entnahme GWS:                 0.2 mm
 speicherinhaltsaenderung:            -3.6 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.211 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.211 qkm



 ISO: Normierungsfaktor   = 1.0002
 ISO: Summe normierter uh =   1.0000


 Anzahl der Zeitschritte in iso durch Nachlauf zu hoch geworden.
 Sie wird auf 460 begrenzt !  gebiet :  4533

fuellenberechnung in iso
abflusz =            91.262
niederschlag =       91.420
flaeche zft  =        1.000
flaeche eing.=        0.211

GEBIET: Abflusswelle Interflow:

 ISO: Normierungsfaktor   = 1.0000
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.211

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV: Retentionskonstanten:   1.5       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =       1.00
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH =  291
ISOV:  fuellenberechnung
ISOV: Abflusz =          1452.535
ISOV: Niederschlag =     1452.536

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
ISOV: Retentionskonstanten:6000.0       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =   96602.20
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH = 2880
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1032

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4535

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    1.11

 gesamtmenge an niederschlag (mm):       39.6

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     16


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  0.900
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  2.500


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4535
 anzahl hydrotope:      16


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      39.6 mm
 interz.verd.:                       5.8 mm
 bestandsniederschlag:              31.6 mm
 differenz interz.speicher:         -2.2 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      16.2 mm
 aktuelle verdunstung:               8.7 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              31.6 mm
 overlandflow:                       0.5 mm
 [infiltration:                     31.2 mm]
 verdunstung (bodensp.):             2.9 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -28.3 mm
 fehler:                             0.0 mm


 8.30385113  -> zufluss grundwasserleiter in  4535
TG:    4535 -> TG:    4539
Prozent:1.00


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:            9.4 mm
 abgabe basisabfluss:                  3.9 mm
        grundw. unterh.l.TG:           5.9 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -0.5 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.266 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.266 qkm



 ISO: Normierungsfaktor   = 1.0001
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =           120.242
niederschlag =      120.242
flaeche zft  =        1.000
flaeche eing.=        0.266

GEBIET: Abflusswelle Interflow:

 ISO: Normierungsfaktor   = 1.0000
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.266

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV: Retentionskonstanten:   0.5       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =       1.00
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH =  105
ISOV:  fuellenberechnung
ISOV: Abflusz =           559.533
ISOV: Niederschlag =      559.533

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
ISOV: Retentionskonstanten:6000.0       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =   96602.20
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH = 2880
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1033

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4539

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    1.11

 gesamtmenge an niederschlag (mm):       39.6

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     66


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  0.900
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  8.000


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4539
 anzahl hydrotope:      66


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      39.6 mm
 interz.verd.:                       6.4 mm
 bestandsniederschlag:              30.3 mm
 differenz interz.speicher:         -2.9 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      16.4 mm
 aktuelle verdunstung:               9.2 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              30.3 mm
 overlandflow:                       0.5 mm
 [infiltration:                     29.8 mm]
 verdunstung (bodensp.):             2.8 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -27.0 mm
 fehler:                             0.0 mm


 entnahme gws [qbm/s]:       0.001
 10.3070755  -> zufluss grundwasserleiter in  4539
TG:    4539 -> TG:    4541
Prozent:0.70

TG:    4539 -> TG:    4547
Prozent:0.10

TG:    4539 -> TG:    4554
Prozent:0.20


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:            1.1 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:           5.2 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.1 mm
     pot.entnahme GWS:                 0.1 mm
 speicherinhaltsaenderung:            -4.3 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                2.864 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    2.864 qkm



 ISO: Normierungsfaktor   = 1.0001
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =          1329.598
niederschlag =     1329.603
flaeche zft  =        1.000
flaeche eing.=        2.864

GEBIET: Abflusswelle Interflow:

 ISO: Normierungsfaktor   = 1.0000
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        2.864

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV: Retentionskonstanten:   0.5       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =       1.00
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH =   95
ISOV:  fuellenberechnung
ISOV: Abflusz =         10221.760
ISOV: Niederschlag =    10221.773

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
ISOV: Retentionskonstanten:6000.0       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =   96602.20
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH = 2880
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1034

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4541

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    1.11

 gesamtmenge an niederschlag (mm):       39.6

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     46


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  0.900
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  5.000


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4541
 anzahl hydrotope:      46


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      39.6 mm
 interz.verd.:                       6.0 mm
 bestandsniederschlag:              31.2 mm
 differenz interz.speicher:         -2.4 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      16.1 mm
 aktuelle verdunstung:               9.1 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              31.2 mm
 overlandflow:                       3.6 mm
 [infiltration:                     27.7 mm]
 verdunstung (bodensp.):             3.1 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -24.5 mm
 fehler:                             0.0 mm


 34.7793770  -> zufluss grundwasserleiter in  4541
TG:    4541 -> TG:    4548
Prozent:0.20

TG:    4541 -> TG:    4554
Prozent:0.15

TG:    4541 -> TG:    4556
Prozent:0.65


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:           26.0 mm
 abgabe basisabfluss:                  3.6 mm
        grundw. unterh.l.TG:          22.9 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -0.5 mm
 fehler:                               0.1 mm


 flaechenanteile: 

   grundwasserleiter:                0.401 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.401 qkm



 ISO: Normierungsfaktor   = 1.0001
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =          1432.022
niederschlag =     1432.022
flaeche zft  =        1.000
flaeche eing.=        0.401

GEBIET: Abflusswelle Interflow:

 ISO: Normierungsfaktor   = 1.0000
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.401

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV: Retentionskonstanten:   0.3       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =       1.00
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH =   56
ISOV:  fuellenberechnung
ISOV: Abflusz =          2918.477
ISOV: Niederschlag =     2918.480

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
ISOV: Retentionskonstanten:6000.0       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =   96602.20
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH = 2880
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1035

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4547

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    1.11

 gesamtmenge an niederschlag (mm):       39.6

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     38


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  0.900
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  2.750


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4547
 anzahl hydrotope:      38


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      39.6 mm
 interz.verd.:                       5.6 mm
 bestandsniederschlag:              32.0 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      16.3 mm
 aktuelle verdunstung:              10.1 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              32.0 mm
 overlandflow:                      14.0 mm
 [infiltration:                     18.0 mm]
 verdunstung (bodensp.):             4.4 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -13.5 mm
 fehler:                             0.0 mm


 4.96848679  -> zufluss grundwasserleiter in  4547
TG:    4547 -> TG:    4548
Prozent:1.00


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:           13.2 mm
 abgabe basisabfluss:                  8.1 mm
        grundw. unterh.l.TG:          17.6 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:               -12.4 mm
     pot.entnahme GWS:               -12.4 mm
 speicherinhaltsaenderung:             0.0 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.113 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.113 qkm



 ISO: Normierungsfaktor   = 1.0001
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =          1578.694
niederschlag =     1578.696
flaeche zft  =        1.000
flaeche eing.=        0.113

GEBIET: Abflusswelle Interflow:

 ISO: Normierungsfaktor   = 1.0000
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.113

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV: Retentionskonstanten:   0.1       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =       1.00
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH =   26
ISOV:  fuellenberechnung
ISOV: Abflusz =          1158.154
ISOV: Niederschlag =     1158.154

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
ISOV: Retentionskonstanten:6000.0       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =   96602.20
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH = 2880
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1036

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4544

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    1.11

 gesamtmenge an niederschlag (mm):       39.6

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     49


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  0.900
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  2.000


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4544
 anzahl hydrotope:      49


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      39.6 mm
 interz.verd.:                       5.6 mm
 bestandsniederschlag:              32.0 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      16.2 mm
 aktuelle verdunstung:               8.8 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              32.0 mm
 overlandflow:                       2.8 mm
 [infiltration:                     29.3 mm]
 verdunstung (bodensp.):             3.2 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -26.1 mm
 fehler:                             0.0 mm


 2.24781537  -> zufluss grundwasserleiter in  4544
TG:    4544 -> TG:    4546
Prozent:1.00


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:            1.8 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:           4.9 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                -0.7 mm
     pot.entnahme GWS:                -0.7 mm
 speicherinhaltsaenderung:            -2.5 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.385 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.385 qkm



 ISO: Normierungsfaktor   = 1.0001
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =          1061.657
niederschlag =     1061.660
flaeche zft  =        1.000
flaeche eing.=        0.385

GEBIET: Abflusswelle Interflow:

 ISO: Normierungsfaktor   = 1.0000
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.385

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV: Retentionskonstanten:   0.3       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =       1.00
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH =   68
ISOV:  fuellenberechnung
ISOV: Abflusz =          2443.241
ISOV: Niederschlag =     2443.243

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
ISOV: Retentionskonstanten:6000.0       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =   96602.20
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH = 2880
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1037

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4546

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    1.11

 gesamtmenge an niederschlag (mm):       39.6

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     67


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  0.900
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  2.250


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4546
 anzahl hydrotope:      67


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      39.6 mm
 interz.verd.:                       5.6 mm
 bestandsniederschlag:              32.0 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      16.2 mm
 aktuelle verdunstung:               9.1 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              32.0 mm
 overlandflow:                       9.6 mm
 [infiltration:                     22.5 mm]
 verdunstung (bodensp.):             3.5 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -19.0 mm
 fehler:                             0.0 mm


 6.31676960  -> zufluss grundwasserleiter in  4546
TG:    4546 -> TG:    4548
Prozent:1.00


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:            8.8 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:          12.8 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -4.0 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.216 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.216 qkm



 ISO: Normierungsfaktor   = 1.0001
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =          2063.292
niederschlag =     2063.297
flaeche zft  =        1.000
flaeche eing.=        0.216

GEBIET: Abflusswelle Interflow:

 ISO: Normierungsfaktor   = 1.0000
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.216

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV: Retentionskonstanten:   0.2       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =       1.00
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH =   48
ISOV:  fuellenberechnung
ISOV: Abflusz =          1311.748
ISOV: Niederschlag =     1311.749

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
ISOV: Retentionskonstanten:6000.0       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =   96602.20
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH = 2880
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1038

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4548

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    1.11

 gesamtmenge an niederschlag (mm):       39.6

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:    125


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  0.900
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  2.000


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4548
 anzahl hydrotope:     125


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      39.6 mm
 interz.verd.:                       5.6 mm
 bestandsniederschlag:              32.0 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      16.2 mm
 aktuelle verdunstung:               8.9 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              32.0 mm
 overlandflow:                       5.3 mm
 [infiltration:                     26.7 mm]
 verdunstung (bodensp.):             3.3 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -23.4 mm
 fehler:                             0.0 mm


 21.9350929  -> zufluss grundwasserleiter in  4548
TG:    4548 -> TG:    4556
Prozent:0.50

TG:    4548 -> TG:    4559
Prozent:0.50


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:           13.6 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:          17.9 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -4.3 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.483 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.483 qkm



 ISO: Normierungsfaktor   = 1.0001
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =          2552.248
niederschlag =     2552.252
flaeche zft  =        1.000
flaeche eing.=        0.483

GEBIET: Abflusswelle Interflow:

 ISO: Normierungsfaktor   = 1.0000
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.483

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV: Retentionskonstanten:   0.2       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =       1.00
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH =   44
ISOV:  fuellenberechnung
ISOV: Abflusz =          3004.582
ISOV: Niederschlag =     3004.582

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
ISOV: Retentionskonstanten:6000.0       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =   96602.20
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH = 2880
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1039

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4554

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    1.11

 gesamtmenge an niederschlag (mm):       39.6

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     34


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  0.900
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  3.000


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4554
 anzahl hydrotope:      34


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      39.6 mm
 interz.verd.:                       5.7 mm
 bestandsniederschlag:              31.8 mm
 differenz interz.speicher:         -2.1 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      15.7 mm
 aktuelle verdunstung:               8.4 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              31.8 mm
 overlandflow:                       0.4 mm
 [infiltration:                     31.4 mm]
 verdunstung (bodensp.):             2.7 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -28.7 mm
 fehler:                             0.0 mm


 14.5307360  -> zufluss grundwasserleiter in  4554
TG:    4554 -> TG:    4556
Prozent:0.50

TG:    4554 -> TG:    4559
Prozent:0.50


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:            8.0 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:          12.4 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -4.4 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.547 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.547 qkm



 ISO: Normierungsfaktor   = 1.0000
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =           234.803
niederschlag =      234.803
flaeche zft  =        1.000
flaeche eing.=        0.547

GEBIET: Abflusswelle Interflow:

 ISO: Normierungsfaktor   = 1.0001
 ISO: Summe normierter uh =   1.0000


 Anzahl der Zeitschritte in iso durch Nachlauf zu hoch geworden.
 Sie wird auf 460 begrenzt !  gebiet :  4554

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.547

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV: Retentionskonstanten:   0.3       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =       1.00
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH =   62
ISOV:  fuellenberechnung
ISOV: Abflusz =          5563.471
ISOV: Niederschlag =     5563.473

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
ISOV: Retentionskonstanten:6000.0       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =   96602.20
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH = 2880
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1040

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4556

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    1.11

 gesamtmenge an niederschlag (mm):       39.6

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:    105


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  0.900
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 = 12.000


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4556
 anzahl hydrotope:     105


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      39.6 mm
 interz.verd.:                       5.6 mm
 bestandsniederschlag:              32.1 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      16.0 mm
 aktuelle verdunstung:               8.4 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              32.1 mm
 overlandflow:                       0.7 mm
 [infiltration:                     31.4 mm]
 verdunstung (bodensp.):             2.8 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -28.6 mm
 fehler:                             0.0 mm


 45.5907516  -> zufluss grundwasserleiter in  4556
TG:    4556 -> TG:    4559
Prozent:1.00


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:           15.1 mm
 abgabe basisabfluss:                  3.5 mm
        grundw. unterh.l.TG:          12.9 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                -0.6 mm
     pot.entnahme GWS:                -0.6 mm
 speicherinhaltsaenderung:            -0.9 mm
 fehler:                               0.2 mm


 flaechenanteile: 

   grundwasserleiter:                0.904 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.904 qkm



 ISO: Normierungsfaktor   = 1.0001
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =           595.221
niederschlag =      595.222
flaeche zft  =        1.000
flaeche eing.=        0.904

GEBIET: Abflusswelle Interflow:

 ISO: Normierungsfaktor   = 1.0000
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.904

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV: Retentionskonstanten:   0.6       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =       1.00
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH =  112
ISOV:  fuellenberechnung
ISOV: Abflusz =          7932.092
ISOV: Niederschlag =     7932.090

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
ISOV: Retentionskonstanten:6000.0       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =   96602.20
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH = 2880
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1041

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4559

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    1.11

 gesamtmenge an niederschlag (mm):       39.6

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:    121


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  0.900
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  4.000


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4559
 anzahl hydrotope:     121


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      39.6 mm
 interz.verd.:                       5.6 mm
 bestandsniederschlag:              32.1 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      15.9 mm
 aktuelle verdunstung:               8.6 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              32.1 mm
 overlandflow:                       5.8 mm
 [infiltration:                     26.3 mm]
 verdunstung (bodensp.):             3.0 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -23.3 mm
 fehler:                             0.0 mm


 64.6178284  -> zufluss grundwasserleiter in  4559
TG:    4559 -> TG:    4560
Prozent:0.10

TG:    4559 -> TG:    4564
Prozent:0.60

TG:    4559 -> TG:    4589
Prozent:0.30


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:           27.0 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:          34.1 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                -1.6 mm
     pot.entnahme GWS:                -1.6 mm
 speicherinhaltsaenderung:            -5.5 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.718 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.718 qkm



 ISO: Normierungsfaktor   = 1.0001
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =          4152.533
niederschlag =     4152.541
flaeche zft  =        1.000
flaeche eing.=        0.718

GEBIET: Abflusswelle Interflow:

 ISO: Normierungsfaktor   = 1.0000
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.718

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV: Retentionskonstanten:   0.5       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =       1.00
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH =  105
ISOV:  fuellenberechnung
ISOV: Abflusz =          5203.025
ISOV: Niederschlag =     5203.024

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
ISOV: Retentionskonstanten:6000.0       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =   96602.20
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH = 2880
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1042

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4560

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    1.11

 gesamtmenge an niederschlag (mm):       39.6

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:      4


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  0.900
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  7.500


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4560
 anzahl hydrotope:       4


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      39.6 mm
 interz.verd.:                       5.2 mm
 bestandsniederschlag:              32.6 mm
 differenz interz.speicher:         -1.7 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      13.5 mm
 aktuelle verdunstung:               7.2 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              32.6 mm
 overlandflow:                       0.4 mm
 [infiltration:                     32.2 mm]
 verdunstung (bodensp.):             2.0 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -30.2 mm
 fehler:                             0.0 mm


 8.15345573  -> zufluss grundwasserleiter in  4560
TG:    4560 -> TG:    4564
Prozent:1.00


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:           71.8 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:          79.7 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -7.9 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.034 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.034 qkm



 ISO: Normierungsfaktor   = 1.0001
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =            13.737
niederschlag =       13.737
flaeche zft  =        1.000
flaeche eing.=        0.034

GEBIET: Abflusswelle Interflow:

 ISO: Normierungsfaktor   = 1.0000
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.034

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV: Retentionskonstanten:   0.5       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =       1.00
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH =  105
ISOV:  fuellenberechnung
ISOV: Abflusz =           612.633
ISOV: Niederschlag =      612.633

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
ISOV: Retentionskonstanten:6000.0       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =   96602.20
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH = 2880
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1043

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4561

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    1.11

 gesamtmenge an niederschlag (mm):       39.6

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     28


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  0.900
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  6.300


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4561
 anzahl hydrotope:      28


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      39.6 mm
 interz.verd.:                       5.3 mm
 bestandsniederschlag:              32.6 mm
 differenz interz.speicher:         -1.8 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      13.8 mm
 aktuelle verdunstung:               8.1 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              32.6 mm
 overlandflow:                      12.8 mm
 [infiltration:                     19.8 mm]
 verdunstung (bodensp.):             2.8 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -17.0 mm
 fehler:                             0.0 mm


 18.4201660  -> zufluss grundwasserleiter in  4561
TG:    4561 -> TG:    4564
Prozent:0.90

TG:    4561 -> TG:    4565
Prozent:0.10


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:          101.7 mm
 abgabe basisabfluss:                 67.5 mm
        grundw. unterh.l.TG:          34.4 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -0.4 mm
 fehler:                               0.1 mm


 flaechenanteile: 

   grundwasserleiter:                0.054 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.054 qkm



 ISO: Normierungsfaktor   = 1.0001
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =           695.979
niederschlag =      695.980
flaeche zft  =        1.000
flaeche eing.=        0.054

GEBIET: Abflusswelle Interflow:

 ISO: Normierungsfaktor   = 1.0000
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.054

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV: Retentionskonstanten:   0.5       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =       1.00
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH =  105
ISOV:  fuellenberechnung
ISOV: Abflusz =           869.575
ISOV: Niederschlag =      869.575

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
ISOV: Retentionskonstanten:6000.0       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =   96602.20
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH = 2880
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1044

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4529

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    1.11

 gesamtmenge an niederschlag (mm):       39.6

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     23


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  3.000


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4529
 anzahl hydrotope:      23


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      39.6 mm
 interz.verd.:                       5.3 mm
 bestandsniederschlag:              32.4 mm
 differenz interz.speicher:         -1.8 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      13.8 mm
 aktuelle verdunstung:               8.3 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              32.4 mm
 overlandflow:                       0.0 mm
 [infiltration:                     32.4 mm]
 verdunstung (bodensp.):             3.0 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -29.4 mm
 fehler:                             0.0 mm


 5.56225872  -> zufluss grundwasserleiter in  4529
TG:    4529 -> TG:    4563
Prozent:1.00


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:           25.2 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:          26.5 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -1.3 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.066 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.066 qkm



 ISO: Normierungsfaktor   = 1.0002
 ISO: Summe normierter uh =   1.0000


 Anzahl der Zeitschritte in iso durch Nachlauf zu hoch geworden.
 Sie wird auf 460 begrenzt !  gebiet :  4529

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.066

GEBIET: Abflusswelle Interflow:

 ISO: Normierungsfaktor   = 1.0000
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.066

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV: Retentionskonstanten:   0.6       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =       1.00
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH =  125
ISOV:  fuellenberechnung
ISOV: Abflusz =          1059.150
ISOV: Niederschlag =     1059.151

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
ISOV: Retentionskonstanten:6000.0       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =   96602.20
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH = 2880
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1045

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4563

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    1.11

 gesamtmenge an niederschlag (mm):       39.6

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     28


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  4.000


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4563
 anzahl hydrotope:      28


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      39.6 mm
 interz.verd.:                       5.8 mm
 bestandsniederschlag:              31.5 mm
 differenz interz.speicher:         -2.2 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      15.8 mm
 aktuelle verdunstung:              10.5 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              31.5 mm
 overlandflow:                       0.0 mm
 [infiltration:                     31.5 mm]
 verdunstung (bodensp.):             4.7 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -26.8 mm
 fehler:                             0.0 mm


 22.5295734  -> zufluss grundwasserleiter in  4563
TG:    4563 -> TG:    4564
Prozent:0.30

TG:    4563 -> TG:    4565
Prozent:0.70


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:           48.1 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:          49.8 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -1.8 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.141 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.141 qkm



 ISO: Normierungsfaktor   = 1.0002
 ISO: Summe normierter uh =   1.0000


 Anzahl der Zeitschritte in iso durch Nachlauf zu hoch geworden.
 Sie wird auf 460 begrenzt !  gebiet :  4563

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.141

GEBIET: Abflusswelle Interflow:

 ISO: Normierungsfaktor   = 1.0000
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.141

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV: Retentionskonstanten:   1.4       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =       1.00
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH =  264
ISOV:  fuellenberechnung
ISOV: Abflusz =           421.029
ISOV: Niederschlag =      421.029

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
ISOV: Retentionskonstanten:6000.0       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =   96602.20
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH = 2880
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1046

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4564

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    1.11

 gesamtmenge an niederschlag (mm):       39.6

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:    108


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  8.500


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4564
 anzahl hydrotope:     108


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      39.6 mm
 interz.verd.:                       5.6 mm
 bestandsniederschlag:              32.0 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      16.0 mm
 aktuelle verdunstung:               9.7 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              32.0 mm
 overlandflow:                       0.0 mm
 [infiltration:                     32.0 mm]
 verdunstung (bodensp.):             4.1 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -27.9 mm
 fehler:                             0.0 mm


 89.0153732  -> zufluss grundwasserleiter in  4564
TG:    4564 -> TG:    4565
Prozent:0.40

TG:    4564 -> TG:    4566
Prozent:0.40

TG:    4564 -> TG:    4571
Prozent:0.20


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:           34.5 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:          35.5 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -1.0 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.773 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.773 qkm



 ISO: Normierungsfaktor   = 1.0002
 ISO: Summe normierter uh =   1.0000


 Anzahl der Zeitschritte in iso durch Nachlauf zu hoch geworden.
 Sie wird auf 460 begrenzt !  gebiet :  4564

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.773

GEBIET: Abflusswelle Interflow:

 ISO: Normierungsfaktor   = 1.0000
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.773

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV: Retentionskonstanten:   1.4       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =       1.00
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH =  264
ISOV:  fuellenberechnung
ISOV: Abflusz =          4699.349
ISOV: Niederschlag =     4699.350

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
ISOV: Retentionskonstanten:6000.0       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =   96602.20
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH = 2880
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1047

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4562

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    1.11

 gesamtmenge an niederschlag (mm):       39.6

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:      7


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  0.900
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  3.500


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4562
 anzahl hydrotope:       7


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      39.6 mm
 interz.verd.:                       5.6 mm
 bestandsniederschlag:              32.0 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      15.5 mm
 aktuelle verdunstung:              10.4 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              32.0 mm
 overlandflow:                      17.9 mm
 [infiltration:                     14.1 mm]
 verdunstung (bodensp.):             4.8 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:           -9.3 mm
 fehler:                             0.0 mm


 0.00000000E+00  -> zufluss grundwasserleiter in  4562
TG:    4562 -> TG:    4565
Prozent:0.10


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:            0.0 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:           2.2 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -2.2 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.081 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.081 qkm



 ISO: Normierungsfaktor   = 1.0001
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =          1444.183
niederschlag =     1444.186
flaeche zft  =        1.000
flaeche eing.=        0.081

GEBIET: Abflusswelle Interflow:

 ISO: Normierungsfaktor   = 1.0000
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.081

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV: Retentionskonstanten:   0.3       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =       1.00
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH =   68
ISOV:  fuellenberechnung
ISOV: Abflusz =             2.758
ISOV: Niederschlag =        2.758

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
ISOV: Retentionskonstanten:6000.0       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =   96602.20
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH = 2880
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1048

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4565

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    1.11

 gesamtmenge an niederschlag (mm):       39.6

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     14


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  8.000


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4565
 anzahl hydrotope:      14


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      39.6 mm
 interz.verd.:                       7.0 mm
 bestandsniederschlag:              29.0 mm
 differenz interz.speicher:         -3.6 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      16.4 mm
 aktuelle verdunstung:              10.8 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              29.0 mm
 overlandflow:                       0.0 mm
 [infiltration:                     29.0 mm]
 verdunstung (bodensp.):             3.7 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -25.2 mm
 fehler:                             0.0 mm


 68.4345322  -> zufluss grundwasserleiter in  4565
TG:    4565 -> TG:    4566
Prozent:1.00


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:          121.8 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:         125.2 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -3.4 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.169 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.169 qkm



 ISO: Normierungsfaktor   = 1.0002
 ISO: Summe normierter uh =   1.0000


 Anzahl der Zeitschritte in iso durch Nachlauf zu hoch geworden.
 Sie wird auf 460 begrenzt !  gebiet :  4565

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.169

GEBIET: Abflusswelle Interflow:

 ISO: Normierungsfaktor   = 1.0000
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.169

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV: Retentionskonstanten:   2.8       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =       1.00
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH =  500
ISOV:  fuellenberechnung
ISOV: Abflusz =            73.643
ISOV: Niederschlag =       73.643

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
ISOV: Retentionskonstanten:6000.0       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =   96602.20
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH = 2880
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1049

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4566

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    1.11

 gesamtmenge an niederschlag (mm):       39.6

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     54


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 = 14.500


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4566
 anzahl hydrotope:      54


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      39.6 mm
 interz.verd.:                       6.1 mm
 bestandsniederschlag:              31.0 mm
 differenz interz.speicher:         -2.5 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      16.3 mm
 aktuelle verdunstung:              10.0 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              31.0 mm
 overlandflow:                       0.0 mm
 [infiltration:                     31.0 mm]
 verdunstung (bodensp.):             3.9 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -27.1 mm
 fehler:                             0.0 mm


 140.165955  -> zufluss grundwasserleiter in  4566
TG:    4566 -> TG:    4567
Prozent:0.30

TG:    4566 -> TG:    4580
Prozent:0.50

TG:    4566 -> TG:    4587
Prozent:0.20


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:           46.0 mm
 abgabe basisabfluss:                 23.1 mm
        grundw. unterh.l.TG:          23.0 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -0.2 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.914 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.914 qkm



 ISO: Normierungsfaktor   = 1.0002
 ISO: Summe normierter uh =   1.0000


 Anzahl der Zeitschritte in iso durch Nachlauf zu hoch geworden.
 Sie wird auf 460 begrenzt !  gebiet :  4566

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.914

GEBIET: Abflusswelle Interflow:

 ISO: Normierungsfaktor   = 1.0000
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.914

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV: Retentionskonstanten:   2.8       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =       1.00
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH =  500
ISOV:  fuellenberechnung
ISOV: Abflusz =           969.847
ISOV: Niederschlag =      969.847

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
ISOV: Retentionskonstanten:6000.0       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =   96602.20
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH = 2880
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1050

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4571

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    1.11

 gesamtmenge an niederschlag (mm):       39.6

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     21


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  1.000


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4571
 anzahl hydrotope:      21


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      39.6 mm
 interz.verd.:                       5.7 mm
 bestandsniederschlag:              32.0 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      16.3 mm
 aktuelle verdunstung:              10.1 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              32.0 mm
 overlandflow:                       0.0 mm
 [infiltration:                     32.0 mm]
 verdunstung (bodensp.):             4.4 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -27.5 mm
 fehler:                             0.0 mm


 18.3173828  -> zufluss grundwasserleiter in  4571
TG:    4571 -> TG:    4573
Prozent:0.20

TG:    4571 -> TG:    4580
Prozent:0.80


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:           34.5 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:          34.7 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -0.2 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.160 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.160 qkm



 ISO: Normierungsfaktor   = 1.0001
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.160

GEBIET: Abflusswelle Interflow:

 ISO: Normierungsfaktor   = 1.0000
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.160

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV: Retentionskonstanten:   0.7       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =       1.00
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH =  148
ISOV:  fuellenberechnung
ISOV: Abflusz =           726.696
ISOV: Niederschlag =      726.696

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
ISOV: Retentionskonstanten:1455.0       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =    1512.20
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH = 2880
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1051

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4589

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    1.11

 gesamtmenge an niederschlag (mm):       39.6

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     99


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  1.000


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4589
 anzahl hydrotope:      99


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      39.6 mm
 interz.verd.:                       5.6 mm
 bestandsniederschlag:              32.0 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      16.1 mm
 aktuelle verdunstung:               9.2 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              32.0 mm
 overlandflow:                       0.0 mm
 [infiltration:                     32.0 mm]
 verdunstung (bodensp.):             3.6 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -28.4 mm
 fehler:                             0.0 mm


 24.4603634  -> zufluss grundwasserleiter in  4589
TG:    4589 -> TG:    4572
Prozent:0.20

TG:    4589 -> TG:    4593
Prozent:0.80


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:           13.6 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:          16.6 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                -2.5 mm
     pot.entnahme GWS:                -2.5 mm
 speicherinhaltsaenderung:            -0.5 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.541 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.541 qkm



 ISO: Normierungsfaktor   = 1.0002
 ISO: Summe normierter uh =   1.0000


 Anzahl der Zeitschritte in iso durch Nachlauf zu hoch geworden.
 Sie wird auf 460 begrenzt !  gebiet :  4589

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.541

GEBIET: Abflusswelle Interflow:

 ISO: Normierungsfaktor   = 1.0000
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.541

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV: Retentionskonstanten:   1.4       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =       1.00
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH =  264
ISOV:  fuellenberechnung
ISOV: Abflusz =          3154.085
ISOV: Niederschlag =     3154.087

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
ISOV: Retentionskonstanten:6000.0       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =   96602.20
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH = 2880
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1052

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4572

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    1.11

 gesamtmenge an niederschlag (mm):       39.6

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     35


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  1.000


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4572
 anzahl hydrotope:      35


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      39.6 mm
 interz.verd.:                       5.6 mm
 bestandsniederschlag:              32.0 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      16.2 mm
 aktuelle verdunstung:               9.5 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              32.0 mm
 overlandflow:                       0.0 mm
 [infiltration:                     32.0 mm]
 verdunstung (bodensp.):             3.9 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -28.1 mm
 fehler:                             0.0 mm


 6.00380278  -> zufluss grundwasserleiter in  4572
TG:    4572 -> TG:    4574
Prozent:0.50

TG:    4572 -> TG:    4573
Prozent:0.50


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:            6.6 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:           6.8 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -0.2 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.275 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.275 qkm



 ISO: Normierungsfaktor   = 1.0001
 ISO: Summe normierter uh =   1.0000


 Anzahl der Zeitschritte in iso durch Nachlauf zu hoch geworden.
 Sie wird auf 460 begrenzt !  gebiet :  4572

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.275

GEBIET: Abflusswelle Interflow:

 ISO: Normierungsfaktor   = 1.0000
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.275

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV: Retentionskonstanten:   1.6       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =       1.00
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH =  299
ISOV:  fuellenberechnung
ISOV: Abflusz =           878.546
ISOV: Niederschlag =      878.547

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
ISOV: Retentionskonstanten:3273.0       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =   16076.66
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH = 2880
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1053

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4573

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    1.11

 gesamtmenge an niederschlag (mm):       39.6

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     21


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  1.000


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4573
 anzahl hydrotope:      21


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      39.6 mm
 interz.verd.:                       5.6 mm
 bestandsniederschlag:              32.0 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      16.2 mm
 aktuelle verdunstung:              11.0 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              32.0 mm
 overlandflow:                       0.0 mm
 [infiltration:                     32.0 mm]
 verdunstung (bodensp.):             5.4 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -26.6 mm
 fehler:                             0.0 mm


 6.77878523  -> zufluss grundwasserleiter in  4573
TG:    4573 -> TG:    4576
Prozent:0.50

TG:    4573 -> TG:    4578
Prozent:0.50


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:           22.4 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:          23.0 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -0.6 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.091 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.091 qkm



 ISO: Normierungsfaktor   = 1.0001
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.091

GEBIET: Abflusswelle Interflow:

 ISO: Normierungsfaktor   = 1.0000
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.091

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV: Retentionskonstanten:   0.7       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =       1.00
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH =  142
ISOV:  fuellenberechnung
ISOV: Abflusz =           458.437
ISOV: Niederschlag =      458.437

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
ISOV: Retentionskonstanten:1382.0       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =    1304.24
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH = 2880
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1054

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4576

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    1.11

 gesamtmenge an niederschlag (mm):       39.6

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     12


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  1.000


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4576
 anzahl hydrotope:      12


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      39.6 mm
 interz.verd.:                       5.6 mm
 bestandsniederschlag:              32.0 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      16.0 mm
 aktuelle verdunstung:              11.0 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              32.0 mm
 overlandflow:                       0.0 mm
 [infiltration:                     32.0 mm]
 verdunstung (bodensp.):             5.4 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -26.6 mm
 fehler:                             0.0 mm


 3.47443843  -> zufluss grundwasserleiter in  4576
TG:    4576 -> TG:    4578
Prozent:0.80

TG:    4576 -> TG:    4579
Prozent:0.20


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:           60.3 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:          60.2 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:             0.1 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.017 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.017 qkm



 ISO: Normierungsfaktor   = 1.0000
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.017

GEBIET: Abflusswelle Interflow:

 ISO: Normierungsfaktor   = 1.0001
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.017

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV: Retentionskonstanten:   0.3       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =       1.00
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH =   60
ISOV:  fuellenberechnung
ISOV: Abflusz =            30.212
ISOV: Niederschlag =       30.212

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
ISOV: Retentionskonstanten: 545.0       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =      97.39
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH = 2880
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1055

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4578

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    1.11

 gesamtmenge an niederschlag (mm):       39.6

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     15


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  1.000


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4578
 anzahl hydrotope:      15


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      39.6 mm
 interz.verd.:                       5.7 mm
 bestandsniederschlag:              31.8 mm
 differenz interz.speicher:         -2.1 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      16.3 mm
 aktuelle verdunstung:              11.1 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              31.8 mm
 overlandflow:                       0.0 mm
 [infiltration:                     31.8 mm]
 verdunstung (bodensp.):             5.3 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -26.5 mm
 fehler:                             0.0 mm


 6.25002670  -> zufluss grundwasserleiter in  4578
TG:    4578 -> TG:    4579
Prozent:0.80

TG:    4578 -> TG:    4580
Prozent:0.20


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:           85.6 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:          85.9 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -0.3 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.022 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.022 qkm



 ISO: Normierungsfaktor   = 1.0000
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.022

GEBIET: Abflusswelle Interflow:

 ISO: Normierungsfaktor   = 1.0001
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.022

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV: Retentionskonstanten:   0.3       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =       1.00
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH =   60
ISOV:  fuellenberechnung
ISOV: Abflusz =            57.031
ISOV: Niederschlag =       57.031

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
ISOV: Retentionskonstanten: 545.0       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =      97.39
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH = 2880
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1056

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4580

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    1.11

 gesamtmenge an niederschlag (mm):       39.6

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     31


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 = 10.000


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4580
 anzahl hydrotope:      31


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      39.6 mm
 interz.verd.:                       5.6 mm
 bestandsniederschlag:              32.0 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      16.0 mm
 aktuelle verdunstung:               9.8 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              32.0 mm
 overlandflow:                       0.0 mm
 [infiltration:                     32.0 mm]
 verdunstung (bodensp.):             4.2 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -27.9 mm
 fehler:                             0.0 mm


 51.0693474  -> zufluss grundwasserleiter in  4580
TG:    4580 -> TG:    4579
Prozent:0.10

TG:    4580 -> TG:    4584
Prozent:0.30

TG:    4580 -> TG:    4586
Prozent:0.60


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:          230.3 mm
 abgabe basisabfluss:                 73.2 mm
        grundw. unterh.l.TG:         157.3 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -0.3 mm
 fehler:                               0.1 mm


 flaechenanteile: 

   grundwasserleiter:                0.067 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.067 qkm



 ISO: Normierungsfaktor   = 1.0002
 ISO: Summe normierter uh =   1.0000


 Anzahl der Zeitschritte in iso durch Nachlauf zu hoch geworden.
 Sie wird auf 460 begrenzt !  gebiet :  4580

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.067

GEBIET: Abflusswelle Interflow:

 ISO: Normierungsfaktor   = 1.0000
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.067

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV: Retentionskonstanten:   0.9       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =       1.00
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH =  181
ISOV:  fuellenberechnung
ISOV: Abflusz =           226.349
ISOV: Niederschlag =      226.349

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
ISOV: Retentionskonstanten:6000.0       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =   96602.20
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH = 2880
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1057

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4584

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    1.11

 gesamtmenge an niederschlag (mm):       39.6

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     21


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  5.000


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4584
 anzahl hydrotope:      21


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      39.6 mm
 interz.verd.:                       5.7 mm
 bestandsniederschlag:              32.0 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      16.4 mm
 aktuelle verdunstung:               9.2 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              32.0 mm
 overlandflow:                       0.0 mm
 [infiltration:                     32.0 mm]
 verdunstung (bodensp.):             3.6 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -28.4 mm
 fehler:                             0.0 mm


 10.4633913  -> zufluss grundwasserleiter in  4584
TG:    4584 -> TG:    4587
Prozent:1.00


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:           54.5 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:          54.7 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -0.2 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.058 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.058 qkm



 ISO: Normierungsfaktor   = 1.0001
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.058

GEBIET: Abflusswelle Interflow:

 ISO: Normierungsfaktor   = 1.0000
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.058

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV: Retentionskonstanten:   0.9       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =       1.00
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH =  168
ISOV:  fuellenberechnung
ISOV: Abflusz =           597.036
ISOV: Niederschlag =      597.036

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
ISOV: Retentionskonstanten:1667.0       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =    2238.97
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH = 2880
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1058

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4587

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    1.11

 gesamtmenge an niederschlag (mm):       39.6

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     15


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  5.000


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4587
 anzahl hydrotope:      15


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      39.6 mm
 interz.verd.:                       5.6 mm
 bestandsniederschlag:              32.1 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      16.0 mm
 aktuelle verdunstung:               8.7 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              32.1 mm
 overlandflow:                       0.0 mm
 [infiltration:                     32.1 mm]
 verdunstung (bodensp.):             3.1 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -28.9 mm
 fehler:                             0.0 mm


 24.5319424  -> zufluss grundwasserleiter in  4587
TG:    4587 -> TG:    4598
Prozent:1.00


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:          403.9 mm
 abgabe basisabfluss:                 44.1 mm
        grundw. unterh.l.TG:         360.1 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -0.4 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.018 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.018 qkm



 ISO: Normierungsfaktor   = 1.0001
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.018

GEBIET: Abflusswelle Interflow:

 ISO: Normierungsfaktor   = 1.0000
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.018

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV: Retentionskonstanten:   0.9       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =       1.00
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH =  168
ISOV:  fuellenberechnung
ISOV: Abflusz =            88.130
ISOV: Niederschlag =       88.130

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
ISOV: Retentionskonstanten:1667.0       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =    2238.97
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH = 2880
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1059

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4574

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    1.11

 gesamtmenge an niederschlag (mm):       39.6

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     26


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  1.000


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4574
 anzahl hydrotope:      26


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      39.6 mm
 interz.verd.:                       5.7 mm
 bestandsniederschlag:              31.9 mm
 differenz interz.speicher:         -2.1 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      16.2 mm
 aktuelle verdunstung:               9.5 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              31.9 mm
 overlandflow:                       0.0 mm
 [infiltration:                     31.9 mm]
 verdunstung (bodensp.):             3.8 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -28.1 mm
 fehler:                             0.0 mm


 3.09175181  -> zufluss grundwasserleiter in  4574
TG:    4574 -> TG:    4575
Prozent:1.00


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:           10.3 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:          10.7 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -0.4 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.090 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.090 qkm



 ISO: Normierungsfaktor   = 1.0001
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.090

GEBIET: Abflusswelle Interflow:

 ISO: Normierungsfaktor   = 1.0000
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.090

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV: Retentionskonstanten:   1.0       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =       1.00
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH =  190
ISOV:  fuellenberechnung
ISOV: Abflusz =           484.812
ISOV: Niederschlag =      484.813

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
ISOV: Retentionskonstanten:1891.0       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =    3227.00
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH = 2880
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1060

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4575

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    1.11

 gesamtmenge an niederschlag (mm):       39.6

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     16


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  1.000


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4575
 anzahl hydrotope:      16


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      39.6 mm
 interz.verd.:                       5.6 mm
 bestandsniederschlag:              32.1 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      16.0 mm
 aktuelle verdunstung:               8.8 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              32.1 mm
 overlandflow:                       0.0 mm
 [infiltration:                     32.1 mm]
 verdunstung (bodensp.):             3.2 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -28.9 mm
 fehler:                             0.0 mm


 3.20433426  -> zufluss grundwasserleiter in  4575
TG:    4575 -> TG:    4585
Prozent:1.00


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:           20.5 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:          20.6 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -0.2 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.047 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.047 qkm



 ISO: Normierungsfaktor   = 1.0000
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.047

GEBIET: Abflusswelle Interflow:

 ISO: Normierungsfaktor   = 1.0000
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.047

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV: Retentionskonstanten:   0.6       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =       1.00
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH =  124
ISOV:  fuellenberechnung
ISOV: Abflusz =           342.092
ISOV: Niederschlag =      342.092

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
ISOV: Retentionskonstanten:1200.0       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =     870.72
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH = 2880
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1061

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4579

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    1.11

 gesamtmenge an niederschlag (mm):       39.6

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     20


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  1.000


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4579
 anzahl hydrotope:      20


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      39.6 mm
 interz.verd.:                       5.6 mm
 bestandsniederschlag:              32.1 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      15.9 mm
 aktuelle verdunstung:              10.4 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              32.1 mm
 overlandflow:                       0.0 mm
 [infiltration:                     32.1 mm]
 verdunstung (bodensp.):             4.8 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -27.3 mm
 fehler:                             0.0 mm


 9.20037270  -> zufluss grundwasserleiter in  4579
TG:    4579 -> TG:    4585
Prozent:0.50

TG:    4579 -> TG:    4586
Prozent:0.50


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:          213.3 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:         213.9 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -0.6 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.013 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.013 qkm



 ISO: Normierungsfaktor   = 1.0000
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.013

GEBIET: Abflusswelle Interflow:

 ISO: Normierungsfaktor   = 1.0002
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.013

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV: Retentionskonstanten:   0.2       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =       1.00
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH =   42
ISOV:  fuellenberechnung
ISOV: Abflusz =           101.604
ISOV: Niederschlag =      101.604

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
ISOV: Retentionskonstanten: 364.0       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =      34.03
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH = 2880
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1062

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4585

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    1.11

 gesamtmenge an niederschlag (mm):       39.6

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     24


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  5.000


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4585
 anzahl hydrotope:      24


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      39.6 mm
 interz.verd.:                       5.6 mm
 bestandsniederschlag:              32.0 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      16.1 mm
 aktuelle verdunstung:               9.3 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              32.0 mm
 overlandflow:                       0.0 mm
 [infiltration:                     32.0 mm]
 verdunstung (bodensp.):             3.6 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -28.4 mm
 fehler:                             0.0 mm


 7.84610462  -> zufluss grundwasserleiter in  4585
TG:    4585 -> TG:    4596
Prozent:1.00


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:           40.9 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:          44.1 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -3.2 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.058 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.058 qkm



 ISO: Normierungsfaktor   = 1.0002
 ISO: Summe normierter uh =   1.0000


 Anzahl der Zeitschritte in iso durch Nachlauf zu hoch geworden.
 Sie wird auf 460 begrenzt !  gebiet :  4585

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.058

GEBIET: Abflusswelle Interflow:

 ISO: Normierungsfaktor   = 1.0000
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.058

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV: Retentionskonstanten:   1.8       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =       1.00
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH =  335
ISOV:  fuellenberechnung
ISOV: Abflusz =           426.831
ISOV: Niederschlag =      426.830

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
ISOV: Retentionskonstanten:5000.0       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =   56239.74
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH = 2880
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1063

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4586

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    1.11

 gesamtmenge an niederschlag (mm):       39.6

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     44


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  5.000


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4586
 anzahl hydrotope:      44


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      39.6 mm
 interz.verd.:                       5.6 mm
 bestandsniederschlag:              32.1 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      16.0 mm
 aktuelle verdunstung:               9.9 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              32.1 mm
 overlandflow:                       0.0 mm
 [infiltration:                     32.1 mm]
 verdunstung (bodensp.):             4.3 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -27.8 mm
 fehler:                             0.0 mm


 25.5400829  -> zufluss grundwasserleiter in  4586
TG:    4586 -> TG:    4598
Prozent:0.50

TG:    4586 -> TG:    4596
Prozent:0.50


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:          132.9 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:         133.3 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -0.4 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.058 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.058 qkm



 ISO: Normierungsfaktor   = 1.0001
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.058

GEBIET: Abflusswelle Interflow:

 ISO: Normierungsfaktor   = 1.0000
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.058

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV: Retentionskonstanten:   0.9       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =       1.00
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH =  168
ISOV:  fuellenberechnung
ISOV: Abflusz =           381.656
ISOV: Niederschlag =      381.656

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
ISOV: Retentionskonstanten:1667.0       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =    2238.97
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH = 2880
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         4585

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.

 Keine angeschlossenen Teilgebiete an Strang      4585
 Auswertung des Stranges:         4587

 Abflussverzoegerung mit Kalinin-Miljukov Parametern

 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 dt [h]:   0.08      tmax [d]:     4.86


 Kennwerte Zuflusswelle
 ----------------------

 Scheitel-Zufluss               iqzmax =   1401   qzmax =       0.031 [m**3/s]
 Scheitel-Zufluss im Gerinne    iqzfmx =   1401  qzfmax =       0.031 [m**3/s]
 Scheitel-Zufluss im Vorland    iqzvmx =      0  qzvmax =       0.000 [m**3/s]

 Fuelle-Zufluss                   fuqz =   0.0008 [hm**3]
 Fuelle-zufluss im Gerinne       fuqzf =   0.0008 [hm**3]
 Fuelle-zufluss im Vorland       fuqzv =   0.0000 [hm**3]


 Kennwerte der Systemfunktionen
 -------------------------------

 Anzahl der Zeitschritte  ituh =     18
 Maximum u                imax =      3     umax = 0.269426
 Summe u                   suu = 0.999998   suuh = 1.000000


 tmax [d]:     4.88


 Kennwerte Ausflusswelle
 -----------------------

 Endordinate Ausfluss           qaend =   0.000
 Scheitel-Ausfluss              iqmax =   1405    qmax =       0.031 [m**3/s]

 Fuelle-Ausfluss                  fuq =   0.0008 [hm**3]
 Fuelle-Ausfluss im Gerinne      fuqa =   0.0008 [hm**3]

 Scheitel-Ausfluss im Gerinne  iqamax =   1405   qamax =       0.031 [m**3/s]


 Gesamtzuflusswelle (ohne Basisabfluss)  sqz =        2.695
 Gesamtabflusswelle    "       "         sq  =        2.695


 Keine angeschlossenen Teilgebiete an Strang      4587
 Auswertung des Stranges:         4621

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Fiktiver Strang! Es erfolgt keine Abflussverzoegerung!
 Keine angeschlossenen Teilgebiete an Strang      4621
 Auswertung des Stranges:         1064

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4507

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    1.11

 gesamtmenge an niederschlag (mm):       39.6

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     69


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  0.500


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4507
 anzahl hydrotope:      69


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      39.6 mm
 interz.verd.:                       5.6 mm
 bestandsniederschlag:              32.0 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      16.1 mm
 aktuelle verdunstung:               9.5 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              32.0 mm
 overlandflow:                       0.0 mm
 [infiltration:                     32.0 mm]
 verdunstung (bodensp.):             3.9 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        2.0 mm
 differenz bodenspeicher:          -26.1 mm
 fehler:                             0.0 mm


 0.00000000E+00  -> zufluss grundwasserleiter in  4507
TG:    4507 -> TG:    4508
Prozent:1.00


 aufteilung perkolation: 

 perkolation bodenspeicher:            2.0 mm

 abgabe grundw.speicher:               2.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  2.0 mm
        grundw. oberh.l.TG:            0.0 mm
 abgabe basisabfluss:                  0.7 mm
        grundw. unterh.l.TG:           2.9 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                -1.2 mm
     pot.entnahme GWS:                -1.2 mm
 speicherinhaltsaenderung:            -0.3 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.513 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.513 qkm



 ISO: Normierungsfaktor   = 1.0002
 ISO: Summe normierter uh =   1.0000


 Anzahl der Zeitschritte in iso durch Nachlauf zu hoch geworden.
 Sie wird auf 460 begrenzt !  gebiet :  4507

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.513

GEBIET: Abflusswelle Interflow:

 ISO: Normierungsfaktor   = 1.0002
 ISO: Summe normierter uh =   1.0000


 Anzahl der Zeitschritte in iso durch Nachlauf zu hoch geworden.
 Sie wird auf 460 begrenzt !  gebiet :  4507

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.513

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV: Retentionskonstanten:   1.4       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =       1.00
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH =  264
ISOV:  fuellenberechnung
ISOV: Abflusz =          3002.746
ISOV: Niederschlag =     3002.744

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
ISOV: Retentionskonstanten:6000.0       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =   96602.20
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH = 2880
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1065

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4508

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    1.11

 gesamtmenge an niederschlag (mm):       39.6

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     56


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  1.000


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4508
 anzahl hydrotope:      56


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      39.6 mm
 interz.verd.:                       5.6 mm
 bestandsniederschlag:              32.1 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      16.0 mm
 aktuelle verdunstung:               9.0 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              32.1 mm
 overlandflow:                       0.0 mm
 [infiltration:                     32.1 mm]
 verdunstung (bodensp.):             3.4 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.9 mm
 differenz bodenspeicher:          -27.8 mm
 fehler:                             0.0 mm


 entnahme gws [qbm/s]:       0.000
 4.91823721  -> zufluss grundwasserleiter in  4508
TG:    4508 -> TG:    4509
Prozent:1.00


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.9 mm

 abgabe grundw.speicher:               0.9 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.9 mm
        grundw. oberh.l.TG:            3.8 mm
 abgabe basisabfluss:                  1.6 mm
        grundw. unterh.l.TG:           3.7 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.2 mm
     pot.entnahme GWS:                 0.2 mm
 speicherinhaltsaenderung:            -0.9 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.390 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.390 qkm



 ISO: Normierungsfaktor   = 1.0002
 ISO: Summe normierter uh =   1.0000


 Anzahl der Zeitschritte in iso durch Nachlauf zu hoch geworden.
 Sie wird auf 460 begrenzt !  gebiet :  4508

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.390

GEBIET: Abflusswelle Interflow:

 ISO: Normierungsfaktor   = 1.0002
 ISO: Summe normierter uh =   1.0000


 Anzahl der Zeitschritte in iso durch Nachlauf zu hoch geworden.
 Sie wird auf 460 begrenzt !  gebiet :  4508

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.390

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV: Retentionskonstanten:   1.4       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =       1.00
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH =  264
ISOV:  fuellenberechnung
ISOV: Abflusz =          2872.004
ISOV: Niederschlag =     2872.007

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
ISOV: Retentionskonstanten:6000.0       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =   96602.20
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH = 2880
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1066

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4509

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    1.11

 gesamtmenge an niederschlag (mm):       39.6

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     83


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  1.500


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4509
 anzahl hydrotope:      83


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      39.6 mm
 interz.verd.:                       5.6 mm
 bestandsniederschlag:              32.1 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      16.0 mm
 aktuelle verdunstung:               9.2 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              32.1 mm
 overlandflow:                       0.0 mm
 [infiltration:                     32.0 mm]
 verdunstung (bodensp.):             3.6 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.2 mm
 differenz bodenspeicher:          -28.3 mm
 fehler:                             0.0 mm


 entnahme gws [qbm/s]:       0.000
 9.01979828  -> zufluss grundwasserleiter in  4509
TG:    4509 -> TG:    4511
Prozent:1.00


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.2 mm

 abgabe grundw.speicher:               0.2 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.2 mm
        grundw. oberh.l.TG:            3.4 mm
 abgabe basisabfluss:                  1.3 mm
        grundw. unterh.l.TG:           3.4 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -1.2 mm
 fehler:                               0.1 mm


 flaechenanteile: 

   grundwasserleiter:                0.801 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.801 qkm



 ISO: Normierungsfaktor   = 1.0002
 ISO: Summe normierter uh =   1.0000


 Anzahl der Zeitschritte in iso durch Nachlauf zu hoch geworden.
 Sie wird auf 460 begrenzt !  gebiet :  4509

fuellenberechnung in iso
abflusz =            31.001
niederschlag =       31.054
flaeche zft  =        1.000
flaeche eing.=        0.801

GEBIET: Abflusswelle Interflow:

 ISO: Normierungsfaktor   = 1.0002
 ISO: Summe normierter uh =   1.0000


 Anzahl der Zeitschritte in iso durch Nachlauf zu hoch geworden.
 Sie wird auf 460 begrenzt !  gebiet :  4509

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.801

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV: Retentionskonstanten:   1.4       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =       1.00
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH =  264
ISOV:  fuellenberechnung
ISOV: Abflusz =          4894.820
ISOV: Niederschlag =     4894.820

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
ISOV: Retentionskonstanten:6000.0       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =   96602.20
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH = 2880
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         4507

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.

 Keine angeschlossenen Teilgebiete an Strang      4507
 Auswertung des Stranges:         4508

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Abflussverzoegerung mit Kalinin-Miljukov Parametern

 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 dt [h]:   0.08      tmax [d]:     4.89


 Kennwerte Zuflusswelle
 ----------------------

 Scheitel-Zufluss               iqzmax =   1409   qzmax =       0.111 [m**3/s]
 Scheitel-Zufluss im Gerinne    iqzfmx =   1409  qzfmax =       0.111 [m**3/s]
 Scheitel-Zufluss im Vorland    iqzvmx =      0  qzvmax =       0.000 [m**3/s]

 Fuelle-Zufluss                   fuqz =   0.0034 [hm**3]
 Fuelle-zufluss im Gerinne       fuqzf =   0.0034 [hm**3]
 Fuelle-zufluss im Vorland       fuqzv =   0.0000 [hm**3]


 Kennwerte der Systemfunktionen
 -------------------------------

 Anzahl der Zeitschritte  ituh =     32
 Maximum u                imax =      1     umax = 0.248968
 Summe u                   suu = 1.001107   suuh = 1.000000


 tmax [d]:     4.90


 Kennwerte Ausflusswelle
 -----------------------

 Endordinate Ausfluss           qaend =   0.000
 Scheitel-Ausfluss              iqmax =   1410    qmax =       0.111 [m**3/s]

 Fuelle-Ausfluss                  fuq =   0.0034 [hm**3]
 Fuelle-Ausfluss im Gerinne      fuqa =   0.0034 [hm**3]

 Scheitel-Ausfluss im Gerinne  iqamax =   1410   qamax =       0.111 [m**3/s]


 Gesamtzuflusswelle (ohne Basisabfluss)  sqz =       11.236
 Gesamtabflusswelle    "       "         sq  =       11.236


 Keine angeschlossenen Teilgebiete an Strang      4508
 Auswertung des Stranges:         4509

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Abflussverzoegerung mit Kalinin-Miljukov Parametern

 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 dt [h]:   0.08      tmax [d]:     4.90


 Kennwerte Zuflusswelle
 ----------------------

 Scheitel-Zufluss               iqzmax =   1410   qzmax =       0.218 [m**3/s]
 Scheitel-Zufluss im Gerinne    iqzfmx =   1410  qzfmax =       0.218 [m**3/s]
 Scheitel-Zufluss im Vorland    iqzvmx =      0  qzvmax =       0.000 [m**3/s]

 Fuelle-Zufluss                   fuqz =   0.0069 [hm**3]
 Fuelle-zufluss im Gerinne       fuqzf =   0.0069 [hm**3]
 Fuelle-zufluss im Vorland       fuqzv =   0.0000 [hm**3]


 Kennwerte der Systemfunktionen
 -------------------------------

 Anzahl der Zeitschritte  ituh =     18
 Maximum u                imax =      3     umax = 0.269426
 Summe u                   suu = 0.999998   suuh = 1.000000


 tmax [d]:     4.91


 Kennwerte Ausflusswelle
 -----------------------

 Endordinate Ausfluss           qaend =   0.000
 Scheitel-Ausfluss              iqmax =   1413    qmax =       0.217 [m**3/s]

 Fuelle-Ausfluss                  fuq =   0.0069 [hm**3]
 Fuelle-Ausfluss im Gerinne      fuqa =   0.0069 [hm**3]

 Scheitel-Ausfluss im Gerinne  iqamax =   1413   qamax =       0.217 [m**3/s]


 Gesamtzuflusswelle (ohne Basisabfluss)  sqz =       22.910
 Gesamtabflusswelle    "       "         sq  =       22.910


 Keine angeschlossenen Teilgebiete an Strang      4509
 Auswertung des Stranges:         4605

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Fiktiver Strang! Es erfolgt keine Abflussverzoegerung!
 Keine angeschlossenen Teilgebiete an Strang      4605
 Auswertung des Stranges:         1067

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4511

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    1.11

 gesamtmenge an niederschlag (mm):       39.6

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     62


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  2.500


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4511
 anzahl hydrotope:      62


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      39.6 mm
 interz.verd.:                       5.6 mm
 bestandsniederschlag:              32.1 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      16.0 mm
 aktuelle verdunstung:               9.2 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              32.1 mm
 overlandflow:                       0.2 mm
 [infiltration:                     31.8 mm]
 verdunstung (bodensp.):             3.6 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -28.3 mm
 fehler:                             0.0 mm


 10.9381447  -> zufluss grundwasserleiter in  4511
TG:    4511 -> TG:    4567
Prozent:1.00


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:            9.6 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:          15.0 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -5.4 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.341 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.341 qkm



 ISO: Normierungsfaktor   = 1.0002
 ISO: Summe normierter uh =   1.0000


 Anzahl der Zeitschritte in iso durch Nachlauf zu hoch geworden.
 Sie wird auf 460 begrenzt !  gebiet :  4511

fuellenberechnung in iso
abflusz =            79.426
niederschlag =       79.563
flaeche zft  =        1.000
flaeche eing.=        0.341

GEBIET: Abflusswelle Interflow:

 ISO: Normierungsfaktor   = 1.0000
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.341

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV: Retentionskonstanten:   1.4       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =       1.00
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH =  264
ISOV:  fuellenberechnung
ISOV: Abflusz =          2476.593
ISOV: Niederschlag =     2476.592

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
ISOV: Retentionskonstanten:6000.0       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =   96602.20
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH = 2880
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1068

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4567

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    1.11

 gesamtmenge an niederschlag (mm):       39.6

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     67


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  6.000


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4567
 anzahl hydrotope:      67


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      39.6 mm
 interz.verd.:                       6.1 mm
 bestandsniederschlag:              31.0 mm
 differenz interz.speicher:         -2.5 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      16.3 mm
 aktuelle verdunstung:               9.7 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              31.0 mm
 overlandflow:                       0.3 mm
 [infiltration:                     30.7 mm]
 verdunstung (bodensp.):             3.7 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -27.1 mm
 fehler:                             0.0 mm


 43.6112938  -> zufluss grundwasserleiter in  4567
TG:    4567 -> TG:    4588
Prozent:1.00


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:           50.7 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:          53.3 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -2.6 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.258 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.258 qkm



 ISO: Normierungsfaktor   = 1.0002
 ISO: Summe normierter uh =   1.0000


 Anzahl der Zeitschritte in iso durch Nachlauf zu hoch geworden.
 Sie wird auf 460 begrenzt !  gebiet :  4567

fuellenberechnung in iso
abflusz =            78.079
niederschlag =       78.214
flaeche zft  =        1.000
flaeche eing.=        0.258

GEBIET: Abflusswelle Interflow:

 ISO: Normierungsfaktor   = 1.0000
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.258

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV: Retentionskonstanten:   1.4       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =       1.00
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH =  264
ISOV:  fuellenberechnung
ISOV: Abflusz =          1225.487
ISOV: Niederschlag =     1225.489

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
ISOV: Retentionskonstanten:6000.0       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =   96602.20
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH = 2880
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1069

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4588

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    1.11

 gesamtmenge an niederschlag (mm):       39.6

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     26


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  6.000


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4588
 anzahl hydrotope:      26


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      39.6 mm
 interz.verd.:                       5.6 mm
 bestandsniederschlag:              32.0 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      16.1 mm
 aktuelle verdunstung:               8.8 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              32.0 mm
 overlandflow:                       0.0 mm
 [infiltration:                     32.0 mm]
 verdunstung (bodensp.):             3.2 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -28.8 mm
 fehler:                             0.0 mm


 entnahme gws [qbm/s]:       0.000
 45.8445129  -> zufluss grundwasserleiter in  4588
TG:    4588 -> TG:    4598
Prozent:1.00


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:          119.3 mm
 abgabe basisabfluss:                 19.4 mm
        grundw. unterh.l.TG:         100.4 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.2 mm
     pot.entnahme GWS:                 0.2 mm
 speicherinhaltsaenderung:            -0.7 mm
 fehler:                               0.1 mm


 flaechenanteile: 

   grundwasserleiter:                0.115 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.115 qkm



 ISO: Normierungsfaktor   = 1.0002
 ISO: Summe normierter uh =   1.0000


 Anzahl der Zeitschritte in iso durch Nachlauf zu hoch geworden.
 Sie wird auf 460 begrenzt !  gebiet :  4588

fuellenberechnung in iso
abflusz =             3.308
niederschlag =        3.314
flaeche zft  =        1.000
flaeche eing.=        0.115

GEBIET: Abflusswelle Interflow:

 ISO: Normierungsfaktor   = 1.0000
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.115

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV: Retentionskonstanten:   2.8       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =       1.00
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH =  500
ISOV:  fuellenberechnung
ISOV: Abflusz =           613.267
ISOV: Niederschlag =      613.267

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
ISOV: Retentionskonstanten:6000.0       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =   96602.20
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH = 2880
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         4503

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.

 Keine angeschlossenen Teilgebiete an Strang      4503
 Auswertung des Stranges:         4504

 Abflussverzoegerung mit Kalinin-Miljukov Parametern

 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 dt [h]:   0.08      tmax [d]:     4.94


 Kennwerte Zuflusswelle
 ----------------------

 Scheitel-Zufluss               iqzmax =   1423   qzmax =       0.074 [m**3/s]
 Scheitel-Zufluss im Gerinne    iqzfmx =   1423  qzfmax =       0.074 [m**3/s]
 Scheitel-Zufluss im Vorland    iqzvmx =      0  qzvmax =       0.000 [m**3/s]

 Fuelle-Zufluss                   fuqz =   0.0030 [hm**3]
 Fuelle-zufluss im Gerinne       fuqzf =   0.0030 [hm**3]
 Fuelle-zufluss im Vorland       fuqzv =   0.0000 [hm**3]


 Kennwerte der Systemfunktionen
 -------------------------------

 Anzahl der Zeitschritte  ituh =     18
 Maximum u                imax =      3     umax = 0.269426
 Summe u                   suu = 0.999998   suuh = 1.000000


 tmax [d]:     4.95


 Kennwerte Ausflusswelle
 -----------------------

 Endordinate Ausfluss           qaend =   0.000
 Scheitel-Ausfluss              iqmax =   1426    qmax =       0.074 [m**3/s]

 Fuelle-Ausfluss                  fuq =   0.0030 [hm**3]
 Fuelle-Ausfluss im Gerinne      fuqa =   0.0030 [hm**3]

 Scheitel-Ausfluss im Gerinne  iqamax =   1426   qamax =       0.074 [m**3/s]


 Gesamtzuflusswelle (ohne Basisabfluss)  sqz =       10.152
 Gesamtabflusswelle    "       "         sq  =       10.152


 Keine angeschlossenen Teilgebiete an Strang      4504
 Auswertung des Stranges:         4505

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Aufruf der Speicherroutine 


 zufluss-fuelle [hm]        0.009844 speicher 4505
 zusaetzl.zufl im nachl.ast [hm]  0.000407

 speicher   0.010251 abfluss-fuelle [hm]      4505

 speicherinhaltsaenderung [hm]  0.000000
 Keine angeschlossenen Teilgebiete an Strang      4505
 Auswertung des Stranges:         4603

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Fiktiver Strang! Es erfolgt keine Abflussverzoegerung!
 Keine angeschlossenen Teilgebiete an Strang      4603
 Auswertung des Stranges:         4580

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.

 Keine angeschlossenen Teilgebiete an Strang      4580
 Auswertung des Stranges:         4581

 Abflussverzoegerung mit Kalinin-Miljukov Parametern
 Keine angeschlossenen Teilgebiete an Strang      4581
 Auswertung des Stranges:         4626

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Fiktiver Strang! Es erfolgt keine Abflussverzoegerung!
 Keine angeschlossenen Teilgebiete an Strang      4626
 Auswertung des Stranges:         4571

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.

 Keine angeschlossenen Teilgebiete an Strang      4571
 Auswertung des Stranges:         4570

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.

 Keine angeschlossenen Teilgebiete an Strang      4570
 Auswertung des Stranges:         4572

 Abflussverzoegerung mit Kalinin-Miljukov Parametern
 Keine angeschlossenen Teilgebiete an Strang      4572
 Auswertung des Stranges:         4576

 Abflussverzoegerung mit Kalinin-Miljukov Parametern

 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 dt [h]:   0.08      tmax [d]:     4.85


 Kennwerte Zuflusswelle
 ----------------------

 Scheitel-Zufluss               iqzmax =   1398   qzmax =       0.068 [m**3/s]
 Scheitel-Zufluss im Gerinne    iqzfmx =   1398  qzfmax =       0.068 [m**3/s]
 Scheitel-Zufluss im Vorland    iqzvmx =      0  qzvmax =       0.000 [m**3/s]

 Fuelle-Zufluss                   fuqz =   0.0016 [hm**3]
 Fuelle-zufluss im Gerinne       fuqzf =   0.0016 [hm**3]
 Fuelle-zufluss im Vorland       fuqzv =   0.0000 [hm**3]


 Kennwerte der Systemfunktionen
 -------------------------------

 Anzahl der Zeitschritte  ituh =     18
 Maximum u                imax =      3     umax = 0.269426
 Summe u                   suu = 0.999998   suuh = 1.000000


 tmax [d]:     4.87


 Kennwerte Ausflusswelle
 -----------------------

 Endordinate Ausfluss           qaend =   0.000
 Scheitel-Ausfluss              iqmax =   1402    qmax =       0.068 [m**3/s]

 Fuelle-Ausfluss                  fuq =   0.0016 [hm**3]
 Fuelle-Ausfluss im Gerinne      fuqa =   0.0016 [hm**3]

 Scheitel-Ausfluss im Gerinne  iqamax =   1402   qamax =       0.068 [m**3/s]


 Gesamtzuflusswelle (ohne Basisabfluss)  sqz =        5.351
 Gesamtabflusswelle    "       "         sq  =        5.351


 Keine angeschlossenen Teilgebiete an Strang      4576
 Auswertung des Stranges:         4577

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Aufruf der Speicherroutine 


 zufluss-fuelle [hm]        0.002869 speicher 4577
 zusaetzl.zufl im nachl.ast [hm]  0.000055

 speicher   0.002923 abfluss-fuelle [hm]      4577

 speicherinhaltsaenderung [hm]  0.000006
 Keine angeschlossenen Teilgebiete an Strang      4577
 Auswertung des Stranges:         4578

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Abflussverzoegerung mit Kalinin-Miljukov Parametern

 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 dt [h]:   0.08      tmax [d]:     4.87


 Kennwerte Zuflusswelle
 ----------------------

 Scheitel-Zufluss               iqzmax =   1402   qzmax =       0.139 [m**3/s]
 Scheitel-Zufluss im Gerinne    iqzfmx =   1402  qzfmax =       0.139 [m**3/s]
 Scheitel-Zufluss im Vorland    iqzvmx =      0  qzvmax =       0.000 [m**3/s]

 Fuelle-Zufluss                   fuqz =   0.0029 [hm**3]
 Fuelle-zufluss im Gerinne       fuqzf =   0.0029 [hm**3]
 Fuelle-zufluss im Vorland       fuqzv =   0.0000 [hm**3]


 Kennwerte der Systemfunktionen
 -------------------------------

 Anzahl der Zeitschritte  ituh =     18
 Maximum u                imax =      3     umax = 0.269426
 Summe u                   suu = 0.999998   suuh = 1.000000


 tmax [d]:     4.88


 Kennwerte Ausflusswelle
 -----------------------

 Endordinate Ausfluss           qaend =   0.000
 Scheitel-Ausfluss              iqmax =   1405    qmax =       0.138 [m**3/s]

 Fuelle-Ausfluss                  fuq =   0.0029 [hm**3]
 Fuelle-Ausfluss im Gerinne      fuqa =   0.0029 [hm**3]

 Scheitel-Ausfluss im Gerinne  iqamax =   1405   qamax =       0.138 [m**3/s]


 Gesamtzuflusswelle (ohne Basisabfluss)  sqz =        9.747
 Gesamtabflusswelle    "       "         sq  =        9.747


 Keine angeschlossenen Teilgebiete an Strang      4578
 Auswertung des Stranges:         4579

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Fiktiver Strang! Es erfolgt keine Abflussverzoegerung!
 Keine angeschlossenen Teilgebiete an Strang      4579
 Auswertung des Stranges:         4620

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.

 Keine angeschlossenen Teilgebiete an Strang      4620
 Auswertung des Stranges:         4582

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Abflussverzoegerung mit Kalinin-Miljukov Parametern

 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 dt [h]:   0.08      tmax [d]:     4.88


 Kennwerte Zuflusswelle
 ----------------------

 Scheitel-Zufluss               iqzmax =   1405   qzmax =       0.139 [m**3/s]
 Scheitel-Zufluss im Gerinne    iqzfmx =   1405  qzfmax =       0.139 [m**3/s]
 Scheitel-Zufluss im Vorland    iqzvmx =      0  qzvmax =       0.000 [m**3/s]

 Fuelle-Zufluss                   fuqz =   0.0031 [hm**3]
 Fuelle-zufluss im Gerinne       fuqzf =   0.0031 [hm**3]
 Fuelle-zufluss im Vorland       fuqzv =   0.0000 [hm**3]


 Kennwerte der Systemfunktionen
 -------------------------------

 Anzahl der Zeitschritte  ituh =     18
 Maximum u                imax =      3     umax = 0.269426
 Summe u                   suu = 0.999998   suuh = 1.000000


 tmax [d]:     4.89


 Kennwerte Ausflusswelle
 -----------------------

 Endordinate Ausfluss           qaend =   0.000
 Scheitel-Ausfluss              iqmax =   1408    qmax =       0.138 [m**3/s]

 Fuelle-Ausfluss                  fuq =   0.0031 [hm**3]
 Fuelle-Ausfluss im Gerinne      fuqa =   0.0031 [hm**3]

 Scheitel-Ausfluss im Gerinne  iqamax =   1408   qamax =       0.138 [m**3/s]


 Gesamtzuflusswelle (ohne Basisabfluss)  sqz =       10.279
 Gesamtabflusswelle    "       "         sq  =       10.279


 Keine angeschlossenen Teilgebiete an Strang      4582
 Auswertung des Stranges:         4583

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Abflussverzoegerung mit Kalinin-Miljukov Parametern

 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 dt [h]:   0.08      tmax [d]:     4.89


 Kennwerte Zuflusswelle
 ----------------------

 Scheitel-Zufluss               iqzmax =   1408   qzmax =       0.157 [m**3/s]
 Scheitel-Zufluss im Gerinne    iqzfmx =   1408  qzfmax =       0.157 [m**3/s]
 Scheitel-Zufluss im Vorland    iqzvmx =      0  qzvmax =       0.000 [m**3/s]

 Fuelle-Zufluss                   fuqz =   0.0082 [hm**3]
 Fuelle-zufluss im Gerinne       fuqzf =   0.0082 [hm**3]
 Fuelle-zufluss im Vorland       fuqzv =   0.0000 [hm**3]


 Kennwerte der Systemfunktionen
 -------------------------------

 Anzahl der Zeitschritte  ituh =     18
 Maximum u                imax =      3     umax = 0.269426
 Summe u                   suu = 0.999998   suuh = 1.000000


 tmax [d]:     4.90


 Kennwerte Ausflusswelle
 -----------------------

 Endordinate Ausfluss           qaend =   0.000
 Scheitel-Ausfluss              iqmax =   1411    qmax =       0.156 [m**3/s]

 Fuelle-Ausfluss                  fuq =   0.0082 [hm**3]
 Fuelle-Ausfluss im Gerinne      fuqa =   0.0082 [hm**3]

 Scheitel-Ausfluss im Gerinne  iqamax =   1411   qamax =       0.156 [m**3/s]


 Gesamtzuflusswelle (ohne Basisabfluss)  sqz =       27.273
 Gesamtabflusswelle    "       "         sq  =       27.272


 Keine angeschlossenen Teilgebiete an Strang      4583
 Auswertung des Stranges:         4627

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Fiktiver Strang! Es erfolgt keine Abflussverzoegerung!
 Keine angeschlossenen Teilgebiete an Strang      4627
 Auswertung des Stranges:         4567

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.

 Keine angeschlossenen Teilgebiete an Strang      4567
 Auswertung des Stranges:         4568

 Aufruf der Speicherroutine 


 zufluss-fuelle [hm]        0.001262 speicher 4568
 zusaetzl.zufl im nachl.ast [hm]  0.000042

 speicher   0.001304 abfluss-fuelle [hm]      4568

 speicherinhaltsaenderung [hm]  0.000000
 Keine angeschlossenen Teilgebiete an Strang      4568
 Auswertung des Stranges:         4617

 Fiktiver Strang! Es erfolgt keine Abflussverzoegerung!
 Keine angeschlossenen Teilgebiete an Strang      4617
 Auswertung des Stranges:         4527

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.

 Keine angeschlossenen Teilgebiete an Strang      4527
 Auswertung des Stranges:         4528

 Aufruf der Speicherroutine 


 zufluss-fuelle [hm]        0.001066 speicher 4528
 zusaetzl.zufl im nachl.ast [hm]  0.000024

 speicher   0.001091 abfluss-fuelle [hm]      4528

 speicherinhaltsaenderung [hm]  0.000002
 Keine angeschlossenen Teilgebiete an Strang      4528
 Auswertung des Stranges:         4623

 Abflussverzoegerung mit Kalinin-Miljukov Parametern

 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 dt [h]:   0.08      tmax [d]:     4.92


 Kennwerte Zuflusswelle
 ----------------------

 Scheitel-Zufluss               iqzmax =   1417   qzmax =       0.040 [m**3/s]
 Scheitel-Zufluss im Gerinne    iqzfmx =   1417  qzfmax =       0.040 [m**3/s]
 Scheitel-Zufluss im Vorland    iqzvmx =      0  qzvmax =       0.000 [m**3/s]

 Fuelle-Zufluss                   fuqz =   0.0011 [hm**3]
 Fuelle-zufluss im Gerinne       fuqzf =   0.0011 [hm**3]
 Fuelle-zufluss im Vorland       fuqzv =   0.0000 [hm**3]


 Kennwerte der Systemfunktionen
 -------------------------------

 Anzahl der Zeitschritte  ituh =     18
 Maximum u                imax =      3     umax = 0.269426
 Summe u                   suu = 0.999998   suuh = 1.000000


 tmax [d]:     4.93


 Kennwerte Ausflusswelle
 -----------------------

 Endordinate Ausfluss           qaend =   0.000
 Scheitel-Ausfluss              iqmax =   1420    qmax =       0.040 [m**3/s]

 Fuelle-Ausfluss                  fuq =   0.0011 [hm**3]
 Fuelle-Ausfluss im Gerinne      fuqa =   0.0011 [hm**3]

 Scheitel-Ausfluss im Gerinne  iqamax =   1420   qamax =       0.040 [m**3/s]


 Gesamtzuflusswelle (ohne Basisabfluss)  sqz =        3.635
 Gesamtabflusswelle    "       "         sq  =        3.635


 Keine angeschlossenen Teilgebiete an Strang      4623
 Auswertung des Stranges:         4624

 Fiktiver Strang! Es erfolgt keine Abflussverzoegerung!
 Keine angeschlossenen Teilgebiete an Strang      4624
 Auswertung des Stranges:         4610

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.

 Keine angeschlossenen Teilgebiete an Strang      4610
 Auswertung des Stranges:         4531

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Aufruf der Speicherroutine 


 zufluss-fuelle [hm]        0.002703 speicher 4531
 zusaetzl.zufl im nachl.ast [hm]  0.000042

 speicher   0.002746 abfluss-fuelle [hm]      4531

 speicherinhaltsaenderung [hm]  0.000000
 Keine angeschlossenen Teilgebiete an Strang      4531
 Auswertung des Stranges:         4625

 Fiktiver Strang! Es erfolgt keine Abflussverzoegerung!
 Keine angeschlossenen Teilgebiete an Strang      4625
 Auswertung des Stranges:         4520

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.

 Keine angeschlossenen Teilgebiete an Strang      4520
 Auswertung des Stranges:         4521

 Aufruf der Speicherroutine 


 zufluss-fuelle [hm]        0.002338 speicher 4521
 zusaetzl.zufl im nachl.ast [hm]  0.000070

 speicher   0.002408 abfluss-fuelle [hm]      4521

 speicherinhaltsaenderung [hm]  0.000000
 Keine angeschlossenen Teilgebiete an Strang      4521
 Auswertung des Stranges:         4608

 Fiktiver Strang! Es erfolgt keine Abflussverzoegerung!
 Keine angeschlossenen Teilgebiete an Strang      4608
 Auswertung des Stranges:         4514

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.

 Keine angeschlossenen Teilgebiete an Strang      4514
 Auswertung des Stranges:         4515

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Abflussverzoegerung mit Kalinin-Miljukov Parametern

 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 dt [h]:   0.08      tmax [d]:     4.89


 Kennwerte Zuflusswelle
 ----------------------

 Scheitel-Zufluss               iqzmax =   1409   qzmax =       0.197 [m**3/s]
 Scheitel-Zufluss im Gerinne    iqzfmx =   1409  qzfmax =       0.197 [m**3/s]
 Scheitel-Zufluss im Vorland    iqzvmx =      0  qzvmax =       0.000 [m**3/s]

 Fuelle-Zufluss                   fuqz =   0.0054 [hm**3]
 Fuelle-zufluss im Gerinne       fuqzf =   0.0054 [hm**3]
 Fuelle-zufluss im Vorland       fuqzv =   0.0000 [hm**3]


 Kennwerte der Systemfunktionen
 -------------------------------

 Anzahl der Zeitschritte  ituh =     18
 Maximum u                imax =      3     umax = 0.269426
 Summe u                   suu = 0.999998   suuh = 1.000000


 tmax [d]:     4.91


 Kennwerte Ausflusswelle
 -----------------------

 Endordinate Ausfluss           qaend =   0.000
 Scheitel-Ausfluss              iqmax =   1413    qmax =       0.197 [m**3/s]

 Fuelle-Ausfluss                  fuq =   0.0054 [hm**3]
 Fuelle-Ausfluss im Gerinne      fuqa =   0.0054 [hm**3]

 Scheitel-Ausfluss im Gerinne  iqamax =   1413   qamax =       0.197 [m**3/s]


 Gesamtzuflusswelle (ohne Basisabfluss)  sqz =       17.896
 Gesamtabflusswelle    "       "         sq  =       17.896


 Keine angeschlossenen Teilgebiete an Strang      4515
 Auswertung des Stranges:         4516

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Aufruf der Speicherroutine 


 zufluss-fuelle [hm]        0.006096 speicher 4516
 zusaetzl.zufl im nachl.ast [hm]  0.000179

 speicher   0.006275 abfluss-fuelle [hm]      4516

 speicherinhaltsaenderung [hm]  0.000000
 Keine angeschlossenen Teilgebiete an Strang      4516
 Auswertung des Stranges:         4517

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Abflussverzoegerung mit Kalinin-Miljukov Parametern

 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 dt [h]:   0.08      tmax [d]:     4.89


 Kennwerte Zuflusswelle
 ----------------------

 Scheitel-Zufluss               iqzmax =   1409   qzmax =       0.227 [m**3/s]
 Scheitel-Zufluss im Gerinne    iqzfmx =   1409  qzfmax =       0.227 [m**3/s]
 Scheitel-Zufluss im Vorland    iqzvmx =      0  qzvmax =       0.000 [m**3/s]

 Fuelle-Zufluss                   fuqz =   0.0063 [hm**3]
 Fuelle-zufluss im Gerinne       fuqzf =   0.0063 [hm**3]
 Fuelle-zufluss im Vorland       fuqzv =   0.0000 [hm**3]


 Kennwerte der Systemfunktionen
 -------------------------------

 Anzahl der Zeitschritte  ituh =     18
 Maximum u                imax =      3     umax = 0.269426
 Summe u                   suu = 0.999998   suuh = 1.000000


 tmax [d]:     4.91


 Kennwerte Ausflusswelle
 -----------------------

 Endordinate Ausfluss           qaend =   0.000
 Scheitel-Ausfluss              iqmax =   1413    qmax =       0.226 [m**3/s]

 Fuelle-Ausfluss                  fuq =   0.0063 [hm**3]
 Fuelle-Ausfluss im Gerinne      fuqa =   0.0063 [hm**3]

 Scheitel-Ausfluss im Gerinne  iqamax =   1413   qamax =       0.226 [m**3/s]


 Gesamtzuflusswelle (ohne Basisabfluss)  sqz =       20.923
 Gesamtabflusswelle    "       "         sq  =       20.923


 Keine angeschlossenen Teilgebiete an Strang      4517
 Auswertung des Stranges:         4518

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Aufruf der Speicherroutine 


 zufluss-fuelle [hm]        0.006031 speicher 4518
 zusaetzl.zufl im nachl.ast [hm]  0.000282

 speicher   0.006313 abfluss-fuelle [hm]      4518

 speicherinhaltsaenderung [hm]  0.000054
 Keine angeschlossenen Teilgebiete an Strang      4518
 Auswertung des Stranges:         4607

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Fiktiver Strang! Es erfolgt keine Abflussverzoegerung!
 Keine angeschlossenen Teilgebiete an Strang      4607
 Auswertung des Stranges:         4512

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.

 Keine angeschlossenen Teilgebiete an Strang      4512
 Auswertung des Stranges:         4513

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Abflussverzoegerung mit Kalinin-Miljukov Parametern

 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 dt [h]:   0.08      tmax [d]:     4.89


 Kennwerte Zuflusswelle
 ----------------------

 Scheitel-Zufluss               iqzmax =   1409   qzmax =       0.096 [m**3/s]
 Scheitel-Zufluss im Gerinne    iqzfmx =   1409  qzfmax =       0.096 [m**3/s]
 Scheitel-Zufluss im Vorland    iqzvmx =      0  qzvmax =       0.000 [m**3/s]

 Fuelle-Zufluss                   fuqz =   0.0026 [hm**3]
 Fuelle-zufluss im Gerinne       fuqzf =   0.0026 [hm**3]
 Fuelle-zufluss im Vorland       fuqzv =   0.0000 [hm**3]


 Kennwerte der Systemfunktionen
 -------------------------------

 Anzahl der Zeitschritte  ituh =     18
 Maximum u                imax =      3     umax = 0.269426
 Summe u                   suu = 0.999998   suuh = 1.000000


 tmax [d]:     4.91


 Kennwerte Ausflusswelle
 -----------------------

 Endordinate Ausfluss           qaend =   0.000
 Scheitel-Ausfluss              iqmax =   1413    qmax =       0.096 [m**3/s]

 Fuelle-Ausfluss                  fuq =   0.0026 [hm**3]
 Fuelle-Ausfluss im Gerinne      fuqa =   0.0026 [hm**3]

 Scheitel-Ausfluss im Gerinne  iqamax =   1413   qamax =       0.096 [m**3/s]


 Gesamtzuflusswelle (ohne Basisabfluss)  sqz =        8.750
 Gesamtabflusswelle    "       "         sq  =        8.750


 Keine angeschlossenen Teilgebiete an Strang      4513
 Auswertung des Stranges:         4519

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Abflussverzoegerung mit Kalinin-Miljukov Parametern

 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 dt [h]:   0.08      tmax [d]:     4.90


 Kennwerte Zuflusswelle
 ----------------------

 Scheitel-Zufluss               iqzmax =   1412   qzmax =       0.139 [m**3/s]
 Scheitel-Zufluss im Gerinne    iqzfmx =   1412  qzfmax =       0.139 [m**3/s]
 Scheitel-Zufluss im Vorland    iqzvmx =      0  qzvmax =       0.000 [m**3/s]

 Fuelle-Zufluss                   fuqz =   0.0038 [hm**3]
 Fuelle-zufluss im Gerinne       fuqzf =   0.0038 [hm**3]
 Fuelle-zufluss im Vorland       fuqzv =   0.0000 [hm**3]


 Kennwerte der Systemfunktionen
 -------------------------------

 Anzahl der Zeitschritte  ituh =     18
 Maximum u                imax =      3     umax = 0.269426
 Summe u                   suu = 0.999998   suuh = 1.000000


 tmax [d]:     4.91


 Kennwerte Ausflusswelle
 -----------------------

 Endordinate Ausfluss           qaend =   0.000
 Scheitel-Ausfluss              iqmax =   1415    qmax =       0.139 [m**3/s]

 Fuelle-Ausfluss                  fuq =   0.0038 [hm**3]
 Fuelle-Ausfluss im Gerinne      fuqa =   0.0038 [hm**3]

 Scheitel-Ausfluss im Gerinne  iqamax =   1415   qamax =       0.139 [m**3/s]


 Gesamtzuflusswelle (ohne Basisabfluss)  sqz =       12.685
 Gesamtabflusswelle    "       "         sq  =       12.685


 Keine angeschlossenen Teilgebiete an Strang      4519
 Auswertung des Stranges:         4522

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Abflussverzoegerung mit Kalinin-Miljukov Parametern

 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 dt [h]:   0.08      tmax [d]:     4.93


 Kennwerte Zuflusswelle
 ----------------------

 Scheitel-Zufluss               iqzmax =   1419   qzmax =       0.423 [m**3/s]
 Scheitel-Zufluss im Gerinne    iqzfmx =   1419  qzfmax =       0.423 [m**3/s]
 Scheitel-Zufluss im Vorland    iqzvmx =      0  qzvmax =       0.000 [m**3/s]

 Fuelle-Zufluss                   fuqz =   0.0126 [hm**3]
 Fuelle-zufluss im Gerinne       fuqzf =   0.0126 [hm**3]
 Fuelle-zufluss im Vorland       fuqzv =   0.0000 [hm**3]


 Kennwerte der Systemfunktionen
 -------------------------------

 Anzahl der Zeitschritte  ituh =     18
 Maximum u                imax =      3     umax = 0.269426
 Summe u                   suu = 0.999998   suuh = 1.000000


 tmax [d]:     4.94


 Kennwerte Ausflusswelle
 -----------------------

 Endordinate Ausfluss           qaend =   0.000
 Scheitel-Ausfluss              iqmax =   1422    qmax =       0.422 [m**3/s]

 Fuelle-Ausfluss                  fuq =   0.0126 [hm**3]
 Fuelle-Ausfluss im Gerinne      fuqa =   0.0126 [hm**3]

 Scheitel-Ausfluss im Gerinne  iqamax =   1422   qamax =       0.422 [m**3/s]


 Gesamtzuflusswelle (ohne Basisabfluss)  sqz =       41.929
 Gesamtabflusswelle    "       "         sq  =       41.929


 Keine angeschlossenen Teilgebiete an Strang      4522
 Auswertung des Stranges:         4524

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Abflussverzoegerung mit Kalinin-Miljukov Parametern

 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 dt [h]:   0.08      tmax [d]:     4.92


 Kennwerte Zuflusswelle
 ----------------------

 Scheitel-Zufluss               iqzmax =   1418   qzmax =       0.575 [m**3/s]
 Scheitel-Zufluss im Gerinne    iqzfmx =   1418  qzfmax =       0.575 [m**3/s]
 Scheitel-Zufluss im Vorland    iqzvmx =      0  qzvmax =       0.000 [m**3/s]

 Fuelle-Zufluss                   fuqz =   0.0185 [hm**3]
 Fuelle-zufluss im Gerinne       fuqzf =   0.0185 [hm**3]
 Fuelle-zufluss im Vorland       fuqzv =   0.0000 [hm**3]


 Kennwerte der Systemfunktionen
 -------------------------------

 Anzahl der Zeitschritte  ituh =     18
 Maximum u                imax =      3     umax = 0.269426
 Summe u                   suu = 0.999998   suuh = 1.000000


 tmax [d]:     4.93


 Kennwerte Ausflusswelle
 -----------------------

 Endordinate Ausfluss           qaend =   0.000
 Scheitel-Ausfluss              iqmax =   1421    qmax =       0.574 [m**3/s]

 Fuelle-Ausfluss                  fuq =   0.0185 [hm**3]
 Fuelle-Ausfluss im Gerinne      fuqa =   0.0185 [hm**3]

 Scheitel-Ausfluss im Gerinne  iqamax =   1421   qamax =       0.574 [m**3/s]


 Gesamtzuflusswelle (ohne Basisabfluss)  sqz =       61.829
 Gesamtabflusswelle    "       "         sq  =       61.829


 Keine angeschlossenen Teilgebiete an Strang      4524
 Auswertung des Stranges:         4525

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Aufruf der Speicherroutine 


 zufluss-fuelle [hm]        0.022120 speicher 4525
 zusaetzl.zufl im nachl.ast [hm]  0.000913

 speicher   0.023032 abfluss-fuelle [hm]      4525

 speicherinhaltsaenderung [hm]  0.000000
 Keine angeschlossenen Teilgebiete an Strang      4525
 Auswertung des Stranges:         4609

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Fiktiver Strang! Es erfolgt keine Abflussverzoegerung!
 Keine angeschlossenen Teilgebiete an Strang      4609
 Auswertung des Stranges:         4500

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.

 Keine angeschlossenen Teilgebiete an Strang      4500
 Auswertung des Stranges:         4501

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Abflussverzoegerung mit Kalinin-Miljukov Parametern

 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 dt [h]:   0.08      tmax [d]:     4.93


 Kennwerte Zuflusswelle
 ----------------------

 Scheitel-Zufluss               iqzmax =   1421   qzmax =       0.215 [m**3/s]
 Scheitel-Zufluss im Gerinne    iqzfmx =   1421  qzfmax =       0.215 [m**3/s]
 Scheitel-Zufluss im Vorland    iqzvmx =      0  qzvmax =       0.000 [m**3/s]

 Fuelle-Zufluss                   fuqz =   0.0085 [hm**3]
 Fuelle-zufluss im Gerinne       fuqzf =   0.0085 [hm**3]
 Fuelle-zufluss im Vorland       fuqzv =   0.0000 [hm**3]


 Kennwerte der Systemfunktionen
 -------------------------------

 Anzahl der Zeitschritte  ituh =     22
 Maximum u                imax =      1     umax = 0.578488
 Summe u                   suu = 0.757320   suuh = 0.999999


 tmax [d]:     4.94


 Kennwerte Ausflusswelle
 -----------------------

 Endordinate Ausfluss           qaend =   0.000
 Scheitel-Ausfluss              iqmax =   1422    qmax =       0.215 [m**3/s]

 Fuelle-Ausfluss                  fuq =   0.0085 [hm**3]
 Fuelle-Ausfluss im Gerinne      fuqa =   0.0085 [hm**3]

 Scheitel-Ausfluss im Gerinne  iqamax =   1422   qamax =       0.215 [m**3/s]


 Gesamtzuflusswelle (ohne Basisabfluss)  sqz =       28.202
 Gesamtabflusswelle    "       "         sq  =       28.202


 Keine angeschlossenen Teilgebiete an Strang      4501
 Auswertung des Stranges:         4502

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Aufruf der Speicherroutine 


 zufluss-fuelle [hm]        0.014354 speicher 4502
 zusaetzl.zufl im nachl.ast [hm]  0.000520

 speicher   0.014874 abfluss-fuelle [hm]      4502

 speicherinhaltsaenderung [hm]  0.000000
 Keine angeschlossenen Teilgebiete an Strang      4502
 Auswertung des Stranges:         4506

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Abflussverzoegerung mit Kalinin-Miljukov Parametern

 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 dt [h]:   0.08      tmax [d]:     4.94


 Kennwerte Zuflusswelle
 ----------------------

 Scheitel-Zufluss               iqzmax =   1423   qzmax =       0.402 [m**3/s]
 Scheitel-Zufluss im Gerinne    iqzfmx =   1454  qzfmax =       0.242 [m**3/s]
 Scheitel-Zufluss im Vorland    iqzvmx =   1423  qzvmax =       0.195 [m**3/s]

 Fuelle-Zufluss                   fuqz =   0.0149 [hm**3]
 Fuelle-zufluss im Gerinne       fuqzf =   0.0127 [hm**3]
 Fuelle-zufluss im Vorland       fuqzv =   0.0022 [hm**3]


 Kennwerte der Systemfunktionen
 -------------------------------

 Anzahl der Zeitschritte  ituh =     34
 Maximum u                imax =      3     umax = 0.173632
 Summe u                   suu = 1.000082   suuh = 1.000000


 tmax [d]:     4.94


 Kennwerte Ausflusswelle
 -----------------------


 Endordinate Ausfluss           qaend =   0.000

 Scheitel-Ausfluss              iqmax =   1422    qmax =       0.403 [m**3/s]


 Fuelle-Ausfluss                  fuq =   0.0149 [hm**3]

 Fuelle-Ausfluss im Gerinne      fuqa =   0.0127 [hm**3]

 Fuelle-Ausfluss im vorland      fuqa =   0.0022 [hm**3]


 Scheitel-Ausfluss im Gerinne  iqamax =   1455   qamax =       0.241 [m**3/s]

 Scheitel-Ausfluss im Vorland  iqamax =   1423   qamax =       0.195 [m**3/s]


 Gesamtzuflusswelle (ohne Basisabfluss)  sqz =       49.634
 Gesamtabflusswelle    "       "         sq  =       49.627


 Keine angeschlossenen Teilgebiete an Strang      4506
 Auswertung des Stranges:         4510

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Abflussverzoegerung mit Kalinin-Miljukov Parametern

 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 dt [h]:   0.08      tmax [d]:     4.93


 Kennwerte Zuflusswelle
 ----------------------

 Scheitel-Zufluss               iqzmax =   1421   qzmax =       0.696 [m**3/s]
 Scheitel-Zufluss im Gerinne    iqzfmx =   1421  qzfmax =       0.696 [m**3/s]
 Scheitel-Zufluss im Vorland    iqzvmx =      0  qzvmax =       0.000 [m**3/s]

 Fuelle-Zufluss                   fuqz =   0.0281 [hm**3]
 Fuelle-zufluss im Gerinne       fuqzf =   0.0281 [hm**3]
 Fuelle-zufluss im Vorland       fuqzv =   0.0000 [hm**3]


 Kennwerte der Systemfunktionen
 -------------------------------

 Anzahl der Zeitschritte  ituh =    357
 Maximum u                imax =      1     umax = 0.272856
 Summe u                   suu = 0.654153   suuh = 1.000000


 tmax [d]:     4.95


 Kennwerte Ausflusswelle
 -----------------------

 Endordinate Ausfluss           qaend =   0.000
 Scheitel-Ausfluss              iqmax =   1426    qmax =       0.665 [m**3/s]

 Fuelle-Ausfluss                  fuq =   0.0281 [hm**3]
 Fuelle-Ausfluss im Gerinne      fuqa =   0.0281 [hm**3]

 Scheitel-Ausfluss im Gerinne  iqamax =   1426   qamax =       0.665 [m**3/s]


 Gesamtzuflusswelle (ohne Basisabfluss)  sqz =       93.535
 Gesamtabflusswelle    "       "         sq  =       93.534


 Keine angeschlossenen Teilgebiete an Strang      4510
 Auswertung des Stranges:         4526

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Abflussverzoegerung mit Kalinin-Miljukov Parametern

 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 dt [h]:   0.08      tmax [d]:     4.92


 Kennwerte Zuflusswelle
 ----------------------

 Scheitel-Zufluss               iqzmax =   1418   qzmax =       1.215 [m**3/s]
 Scheitel-Zufluss im Gerinne    iqzfmx =   1418  qzfmax =       1.215 [m**3/s]
 Scheitel-Zufluss im Vorland    iqzvmx =      0  qzvmax =       0.000 [m**3/s]

 Fuelle-Zufluss                   fuqz =   0.0465 [hm**3]
 Fuelle-zufluss im Gerinne       fuqzf =   0.0465 [hm**3]
 Fuelle-zufluss im Vorland       fuqzv =   0.0000 [hm**3]


 Kennwerte der Systemfunktionen
 -------------------------------

 Anzahl der Zeitschritte  ituh =     27
 Maximum u                imax =      1     umax = 0.557957
 Summe u                   suu = 0.784427   suuh = 1.000000


 tmax [d]:     4.92


 Kennwerte Ausflusswelle
 -----------------------

 Endordinate Ausfluss           qaend =   0.000
 Scheitel-Ausfluss              iqmax =   1418    qmax =       1.213 [m**3/s]

 Fuelle-Ausfluss                  fuq =   0.0465 [hm**3]
 Fuelle-Ausfluss im Gerinne      fuqa =   0.0465 [hm**3]

 Scheitel-Ausfluss im Gerinne  iqamax =   1418   qamax =       1.213 [m**3/s]


 Gesamtzuflusswelle (ohne Basisabfluss)  sqz =      154.911
 Gesamtabflusswelle    "       "         sq  =      154.911


 Keine angeschlossenen Teilgebiete an Strang      4526
 Auswertung des Stranges:         4532

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Abflussverzoegerung mit Kalinin-Miljukov Parametern

 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 dt [h]:   0.08      tmax [d]:     4.94


 Kennwerte Zuflusswelle
 ----------------------

 Scheitel-Zufluss               iqzmax =   1423   qzmax =       1.770 [m**3/s]
 Scheitel-Zufluss im Gerinne    iqzfmx =   1423  qzfmax =       1.491 [m**3/s]
 Scheitel-Zufluss im Vorland    iqzvmx =   1423  qzvmax =       0.280 [m**3/s]

 Fuelle-Zufluss                   fuqz =   0.0721 [hm**3]
 Fuelle-zufluss im Gerinne       fuqzf =   0.0688 [hm**3]
 Fuelle-zufluss im Vorland       fuqzv =   0.0033 [hm**3]


 Kennwerte der Systemfunktionen
 -------------------------------

 Anzahl der Zeitschritte  ituh =     58
 Maximum u                imax =      1     umax = 0.450462
 Summe u                   suu = 0.778253   suuh = 0.999630


 tmax [d]:     4.95


 Kennwerte Ausflusswelle
 -----------------------


 Endordinate Ausfluss           qaend =   0.000

 Scheitel-Ausfluss              iqmax =   1427    qmax =       1.744 [m**3/s]


 Fuelle-Ausfluss                  fuq =   0.0721 [hm**3]

 Fuelle-Ausfluss im Gerinne      fuqa =   0.0688 [hm**3]

 Fuelle-Ausfluss im vorland      fuqa =   0.0033 [hm**3]


 Scheitel-Ausfluss im Gerinne  iqamax =   1428   qamax =       1.473 [m**3/s]

 Scheitel-Ausfluss im Vorland  iqamax =   1425   qamax =       0.273 [m**3/s]


 Gesamtzuflusswelle (ohne Basisabfluss)  sqz =      240.308
 Gesamtabflusswelle    "       "         sq  =      240.308


 Keine angeschlossenen Teilgebiete an Strang      4532
 Auswertung des Stranges:         4563

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Abflussverzoegerung mit Kalinin-Miljukov Parametern

 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 dt [h]:   0.08      tmax [d]:     4.95


 Kennwerte Zuflusswelle
 ----------------------

 Scheitel-Zufluss               iqzmax =   1425   qzmax =       1.878 [m**3/s]
 Scheitel-Zufluss im Gerinne    iqzfmx =   1425  qzfmax =       1.878 [m**3/s]
 Scheitel-Zufluss im Vorland    iqzvmx =      0  qzvmax =       0.000 [m**3/s]

 Fuelle-Zufluss                   fuqz =   0.0767 [hm**3]
 Fuelle-zufluss im Gerinne       fuqzf =   0.0767 [hm**3]
 Fuelle-zufluss im Vorland       fuqzv =   0.0000 [hm**3]


 Kennwerte der Systemfunktionen
 -------------------------------

 Anzahl der Zeitschritte  ituh =     27
 Maximum u                imax =      1     umax = 0.557957
 Summe u                   suu = 0.784427   suuh = 1.000000


 tmax [d]:     4.95


 Kennwerte Ausflusswelle
 -----------------------

 Endordinate Ausfluss           qaend =   0.000
 Scheitel-Ausfluss              iqmax =   1426    qmax =       1.876 [m**3/s]

 Fuelle-Ausfluss                  fuq =   0.0767 [hm**3]
 Fuelle-Ausfluss im Gerinne      fuqa =   0.0767 [hm**3]

 Scheitel-Ausfluss im Gerinne  iqamax =   1426   qamax =       1.876 [m**3/s]


 Gesamtzuflusswelle (ohne Basisabfluss)  sqz =      255.613
 Gesamtabflusswelle    "       "         sq  =      255.613


 Keine angeschlossenen Teilgebiete an Strang      4563
 Auswertung des Stranges:         4541

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.

 Keine angeschlossenen Teilgebiete an Strang      4541
 Auswertung des Stranges:         4534

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.

 Keine angeschlossenen Teilgebiete an Strang      4534
 Auswertung des Stranges:         4535

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Abflussverzoegerung mit Kalinin-Miljukov Parametern

 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 dt [h]:   0.08      tmax [d]:     4.80


 Kennwerte Zuflusswelle
 ----------------------

 Scheitel-Zufluss               iqzmax =   1383   qzmax =       0.512 [m**3/s]
 Scheitel-Zufluss im Gerinne    iqzfmx =   1383  qzfmax =       0.512 [m**3/s]
 Scheitel-Zufluss im Vorland    iqzvmx =      0  qzvmax =       0.000 [m**3/s]

 Fuelle-Zufluss                   fuqz =   0.0045 [hm**3]
 Fuelle-zufluss im Gerinne       fuqzf =   0.0045 [hm**3]
 Fuelle-zufluss im Vorland       fuqzv =   0.0000 [hm**3]


 Kennwerte der Systemfunktionen
 -------------------------------

 Anzahl der Zeitschritte  ituh =     18
 Maximum u                imax =      3     umax = 0.269426
 Summe u                   suu = 0.999998   suuh = 1.000000


 tmax [d]:     4.81


 Kennwerte Ausflusswelle
 -----------------------

 Endordinate Ausfluss           qaend =   0.000
 Scheitel-Ausfluss              iqmax =   1386    qmax =       0.468 [m**3/s]

 Fuelle-Ausfluss                  fuq =   0.0045 [hm**3]
 Fuelle-Ausfluss im Gerinne      fuqa =   0.0045 [hm**3]

 Scheitel-Ausfluss im Gerinne  iqamax =   1386   qamax =       0.468 [m**3/s]


 Gesamtzuflusswelle (ohne Basisabfluss)  sqz =       15.062
 Gesamtabflusswelle    "       "         sq  =       15.062


 Keine angeschlossenen Teilgebiete an Strang      4535
 Auswertung des Stranges:         4536

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Aufruf der Speicherroutine 


 zufluss-fuelle [hm]        0.006163 speicher 4536
 zusaetzl.zufl im nachl.ast [hm]  0.000068

 speicher   0.006231 abfluss-fuelle [hm]      4536

 speicherinhaltsaenderung [hm]  0.000000
 Keine angeschlossenen Teilgebiete an Strang      4536
 Auswertung des Stranges:         4612

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Fiktiver Strang! Es erfolgt keine Abflussverzoegerung!
 Keine angeschlossenen Teilgebiete an Strang      4612
 Auswertung des Stranges:         4537

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.

 Keine angeschlossenen Teilgebiete an Strang      4537
 Auswertung des Stranges:         4538

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Abflussverzoegerung mit Kalinin-Miljukov Parametern

 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 dt [h]:   0.08      tmax [d]:     4.83


 Kennwerte Zuflusswelle
 ----------------------

 Scheitel-Zufluss               iqzmax =   1390   qzmax =       0.033 [m**3/s]
 Scheitel-Zufluss im Gerinne    iqzfmx =   1390  qzfmax =       0.033 [m**3/s]
 Scheitel-Zufluss im Vorland    iqzvmx =      0  qzvmax =       0.000 [m**3/s]

 Fuelle-Zufluss                   fuqz =   0.0007 [hm**3]
 Fuelle-zufluss im Gerinne       fuqzf =   0.0007 [hm**3]
 Fuelle-zufluss im Vorland       fuqzv =   0.0000 [hm**3]


 Kennwerte der Systemfunktionen
 -------------------------------

 Anzahl der Zeitschritte  ituh =     25
 Maximum u                imax =      1     umax = 0.540740
 Summe u                   suu = 0.727210   suuh = 1.000000


 tmax [d]:     4.83


 Kennwerte Ausflusswelle
 -----------------------

 Endordinate Ausfluss           qaend =   0.000
 Scheitel-Ausfluss              iqmax =   1391    qmax =       0.033 [m**3/s]

 Fuelle-Ausfluss                  fuq =   0.0007 [hm**3]
 Fuelle-Ausfluss im Gerinne      fuqa =   0.0007 [hm**3]

 Scheitel-Ausfluss im Gerinne  iqamax =   1391   qamax =       0.033 [m**3/s]


 Gesamtzuflusswelle (ohne Basisabfluss)  sqz =        2.331
 Gesamtabflusswelle    "       "         sq  =        2.331


 Keine angeschlossenen Teilgebiete an Strang      4538
 Auswertung des Stranges:         4539

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Abflussverzoegerung mit Kalinin-Miljukov Parametern

 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 dt [h]:   0.08      tmax [d]:     4.82


 Kennwerte Zuflusswelle
 ----------------------

 Scheitel-Zufluss               iqzmax =   1388   qzmax =       0.516 [m**3/s]
 Scheitel-Zufluss im Gerinne    iqzfmx =   1388  qzfmax =       0.516 [m**3/s]
 Scheitel-Zufluss im Vorland    iqzvmx =      0  qzvmax =       0.000 [m**3/s]

 Fuelle-Zufluss                   fuqz =   0.0069 [hm**3]
 Fuelle-zufluss im Gerinne       fuqzf =   0.0069 [hm**3]
 Fuelle-zufluss im Vorland       fuqzv =   0.0000 [hm**3]


 Kennwerte der Systemfunktionen
 -------------------------------

 Anzahl der Zeitschritte  ituh =     25
 Maximum u                imax =      1     umax = 0.540740
 Summe u                   suu = 0.727210   suuh = 1.000000


 tmax [d]:     4.82


 Kennwerte Ausflusswelle
 -----------------------

 Endordinate Ausfluss           qaend =   0.000
 Scheitel-Ausfluss              iqmax =   1389    qmax =       0.494 [m**3/s]

 Fuelle-Ausfluss                  fuq =   0.0069 [hm**3]
 Fuelle-Ausfluss im Gerinne      fuqa =   0.0069 [hm**3]

 Scheitel-Ausfluss im Gerinne  iqamax =   1389   qamax =       0.494 [m**3/s]


 Gesamtzuflusswelle (ohne Basisabfluss)  sqz =       23.127
 Gesamtabflusswelle    "       "         sq  =       23.127


 Keine angeschlossenen Teilgebiete an Strang      4539
 Auswertung des Stranges:         4540

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Aufruf der Speicherroutine 


 zufluss-fuelle [hm]        0.018330 speicher 4540
 zusaetzl.zufl im nachl.ast [hm]  0.000162

 speicher   0.018458 abfluss-fuelle [hm]      4540

 speicherinhaltsaenderung [hm]  0.000000
 Keine angeschlossenen Teilgebiete an Strang      4540
 Auswertung des Stranges:         4613

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Fiktiver Strang! Es erfolgt keine Abflussverzoegerung!
 Keine angeschlossenen Teilgebiete an Strang      4613
 Auswertung des Stranges:         4546

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Abflussverzoegerung mit Kalinin-Miljukov Parametern

 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 dt [h]:   0.08      tmax [d]:     4.82


 Kennwerte Zuflusswelle
 ----------------------

 Scheitel-Zufluss               iqzmax =   1388   qzmax =       1.958 [m**3/s]
 Scheitel-Zufluss im Gerinne    iqzfmx =   1388  qzfmax =       1.566 [m**3/s]
 Scheitel-Zufluss im Vorland    iqzvmx =   1388  qzvmax =       0.392 [m**3/s]

 Fuelle-Zufluss                   fuqz =   0.0242 [hm**3]
 Fuelle-zufluss im Gerinne       fuqzf =   0.0223 [hm**3]
 Fuelle-zufluss im Vorland       fuqzv =   0.0019 [hm**3]


 Kennwerte der Systemfunktionen
 -------------------------------

 Anzahl der Zeitschritte  ituh =   2880
 Maximum u                imax =      1     umax = 0.000000
 Summe u                   suu = 0.000000   suuh = 0.000000


 tmax [d]:     4.82


 Kennwerte Ausflusswelle
 -----------------------


 Endordinate Ausfluss           qaend =   0.001

 Scheitel-Ausfluss              iqmax =   1389    qmax =       1.898 [m**3/s]


 Fuelle-Ausfluss                  fuq =   0.0242 [hm**3]

 Fuelle-Ausfluss im Gerinne      fuqa =   0.0223 [hm**3]

 Fuelle-Ausfluss im vorland      fuqa =   0.0019 [hm**3]


 Scheitel-Ausfluss im Gerinne  iqamax =   1389   qamax =       1.519 [m**3/s]

 Scheitel-Ausfluss im Vorland  iqamax =   1389   qamax =       0.379 [m**3/s]


 Gesamtzuflusswelle (ohne Basisabfluss)  sqz =       80.815
 Gesamtabflusswelle    "       "         sq  =       80.815


 Keine angeschlossenen Teilgebiete an Strang      4546
 Auswertung des Stranges:         4543

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.

 Keine angeschlossenen Teilgebiete an Strang      4543
 Auswertung des Stranges:         4544

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Abflussverzoegerung mit Kalinin-Miljukov Parametern

 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 dt [h]:   0.08      tmax [d]:     4.82


 Kennwerte Zuflusswelle
 ----------------------

 Scheitel-Zufluss               iqzmax =   1388   qzmax =       0.840 [m**3/s]
 Scheitel-Zufluss im Gerinne    iqzfmx =   1388  qzfmax =       0.672 [m**3/s]
 Scheitel-Zufluss im Vorland    iqzvmx =   1388  qzvmax =       0.168 [m**3/s]

 Fuelle-Zufluss                   fuqz =   0.0085 [hm**3]
 Fuelle-zufluss im Gerinne       fuqzf =   0.0080 [hm**3]
 Fuelle-zufluss im Vorland       fuqzv =   0.0005 [hm**3]


 Kennwerte der Systemfunktionen
 -------------------------------

 Anzahl der Zeitschritte  ituh =   2880
 Maximum u                imax =      1     umax = 0.000000
 Summe u                   suu = 0.000000   suuh = 0.000000


 tmax [d]:     4.82


 Kennwerte Ausflusswelle
 -----------------------


 Endordinate Ausfluss           qaend =   0.004

 Scheitel-Ausfluss              iqmax =   1389    qmax =       0.828 [m**3/s]


 Fuelle-Ausfluss                  fuq =   0.0085 [hm**3]

 Fuelle-Ausfluss im Gerinne      fuqa =   0.0080 [hm**3]

 Fuelle-Ausfluss im vorland      fuqa =   0.0005 [hm**3]


 Scheitel-Ausfluss im Gerinne  iqamax =   1389   qamax =       0.664 [m**3/s]

 Scheitel-Ausfluss im Vorland  iqamax =   1389   qamax =       0.164 [m**3/s]


 Gesamtzuflusswelle (ohne Basisabfluss)  sqz =       28.242
 Gesamtabflusswelle    "       "         sq  =       28.242


 Keine angeschlossenen Teilgebiete an Strang      4544
 Auswertung des Stranges:         4545

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Aufruf der Speicherroutine 


 zufluss-fuelle [hm]        0.011970 speicher 4545
 zusaetzl.zufl im nachl.ast [hm]  0.000008

 speicher   0.011978 abfluss-fuelle [hm]      4545
 abfluss-fuelle [hm]  0.0000 ueberlauf 

 speicherinhaltsaenderung [hm]  0.000000
 Keine angeschlossenen Teilgebiete an Strang      4545
 Auswertung des Stranges:         4547

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Abflussverzoegerung mit Kalinin-Miljukov Parametern

 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 dt [h]:   0.08      tmax [d]:     4.85


 Kennwerte Zuflusswelle
 ----------------------

 Scheitel-Zufluss               iqzmax =   1397   qzmax =       0.713 [m**3/s]
 Scheitel-Zufluss im Gerinne    iqzfmx =   1397  qzfmax =       0.713 [m**3/s]
 Scheitel-Zufluss im Vorland    iqzvmx =      0  qzvmax =       0.000 [m**3/s]

 Fuelle-Zufluss                   fuqz =   0.0120 [hm**3]
 Fuelle-zufluss im Gerinne       fuqzf =   0.0120 [hm**3]
 Fuelle-zufluss im Vorland       fuqzv =   0.0000 [hm**3]


 Kennwerte der Systemfunktionen
 -------------------------------

 Anzahl der Zeitschritte  ituh =     18
 Maximum u                imax =      3     umax = 0.269426
 Summe u                   suu = 0.999998   suuh = 1.000000


 tmax [d]:     4.86


 Kennwerte Ausflusswelle
 -----------------------

 Endordinate Ausfluss           qaend =   0.000
 Scheitel-Ausfluss              iqmax =   1401    qmax =       0.705 [m**3/s]

 Fuelle-Ausfluss                  fuq =   0.0120 [hm**3]
 Fuelle-Ausfluss im Gerinne      fuqa =   0.0120 [hm**3]

 Scheitel-Ausfluss im Gerinne  iqamax =   1401   qamax =       0.705 [m**3/s]


 Gesamtzuflusswelle (ohne Basisabfluss)  sqz =       39.943
 Gesamtabflusswelle    "       "         sq  =       39.943


 Keine angeschlossenen Teilgebiete an Strang      4547
 Auswertung des Stranges:         4548

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Abflussverzoegerung mit Kalinin-Miljukov Parametern

 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 dt [h]:   0.08      tmax [d]:     4.82


 Kennwerte Zuflusswelle
 ----------------------

 Scheitel-Zufluss               iqzmax =   1389   qzmax =       2.567 [m**3/s]
 Scheitel-Zufluss im Gerinne    iqzfmx =   1389  qzfmax =       2.053 [m**3/s]
 Scheitel-Zufluss im Vorland    iqzvmx =   1389  qzvmax =       0.513 [m**3/s]

 Fuelle-Zufluss                   fuqz =   0.0433 [hm**3]
 Fuelle-zufluss im Gerinne       fuqzf =   0.0391 [hm**3]
 Fuelle-zufluss im Vorland       fuqzv =   0.0042 [hm**3]


 Kennwerte der Systemfunktionen
 -------------------------------

 Anzahl der Zeitschritte  ituh =   2880
 Maximum u                imax =      1     umax = 0.000000
 Summe u                   suu = 0.000000   suuh = 0.000000


 tmax [d]:     4.83


 Kennwerte Ausflusswelle
 -----------------------


 Endordinate Ausfluss           qaend =   0.001

 Scheitel-Ausfluss              iqmax =   1390    qmax =       2.529 [m**3/s]


 Fuelle-Ausfluss                  fuq =   0.0433 [hm**3]

 Fuelle-Ausfluss im Gerinne      fuqa =   0.0391 [hm**3]

 Fuelle-Ausfluss im vorland      fuqa =   0.0042 [hm**3]


 Scheitel-Ausfluss im Gerinne  iqamax =   1390   qamax =       2.023 [m**3/s]

 Scheitel-Ausfluss im Vorland  iqamax =   1390   qamax =       0.506 [m**3/s]


 Gesamtzuflusswelle (ohne Basisabfluss)  sqz =      144.173
 Gesamtabflusswelle    "       "         sq  =      144.173


 Keine angeschlossenen Teilgebiete an Strang      4548
 Auswertung des Stranges:         4549

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.

 Keine angeschlossenen Teilgebiete an Strang      4549
 Auswertung des Stranges:         4550

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Aufruf der Speicherroutine 


 zufluss-fuelle [hm]        0.007885 speicher 4550
 zusaetzl.zufl im nachl.ast [hm]  0.000010

 speicher   0.007894 abfluss-fuelle [hm]      4550
 abfluss-fuelle [hm]  0.0000 ueberlauf 

 speicherinhaltsaenderung [hm]  0.000001
 Keine angeschlossenen Teilgebiete an Strang      4550
 Auswertung des Stranges:         4551

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Abflussverzoegerung mit Kalinin-Miljukov Parametern

 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 dt [h]:   0.08      tmax [d]:     4.88


 Kennwerte Zuflusswelle
 ----------------------

 Scheitel-Zufluss               iqzmax =   1406   qzmax =       0.207 [m**3/s]
 Scheitel-Zufluss im Gerinne    iqzfmx =   1406  qzfmax =       0.207 [m**3/s]
 Scheitel-Zufluss im Vorland    iqzvmx =      0  qzvmax =       0.000 [m**3/s]

 Fuelle-Zufluss                   fuqz =   0.0079 [hm**3]
 Fuelle-zufluss im Gerinne       fuqzf =   0.0079 [hm**3]
 Fuelle-zufluss im Vorland       fuqzv =   0.0000 [hm**3]


 Kennwerte der Systemfunktionen
 -------------------------------

 Anzahl der Zeitschritte  ituh =     25
 Maximum u                imax =      1     umax = 0.540740
 Summe u                   suu = 0.727210   suuh = 1.000000


 tmax [d]:     4.88


 Kennwerte Ausflusswelle
 -----------------------

 Endordinate Ausfluss           qaend =   0.000
 Scheitel-Ausfluss              iqmax =   1406    qmax =       0.207 [m**3/s]

 Fuelle-Ausfluss                  fuq =   0.0079 [hm**3]
 Fuelle-Ausfluss im Gerinne      fuqa =   0.0079 [hm**3]

 Scheitel-Ausfluss im Gerinne  iqamax =   1406   qamax =       0.207 [m**3/s]


 Gesamtzuflusswelle (ohne Basisabfluss)  sqz =       26.316
 Gesamtabflusswelle    "       "         sq  =       26.316


 Keine angeschlossenen Teilgebiete an Strang      4551
 Auswertung des Stranges:         4553

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Abflussverzoegerung mit Kalinin-Miljukov Parametern

 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 dt [h]:   0.08      tmax [d]:     4.82


 Kennwerte Zuflusswelle
 ----------------------

 Scheitel-Zufluss               iqzmax =   1389   qzmax =       3.738 [m**3/s]
 Scheitel-Zufluss im Gerinne    iqzfmx =   1389  qzfmax =       3.738 [m**3/s]
 Scheitel-Zufluss im Vorland    iqzvmx =      0  qzvmax =       0.000 [m**3/s]

 Fuelle-Zufluss                   fuqz =   0.0657 [hm**3]
 Fuelle-zufluss im Gerinne       fuqzf =   0.0657 [hm**3]
 Fuelle-zufluss im Vorland       fuqzv =   0.0000 [hm**3]


 Kennwerte der Systemfunktionen
 -------------------------------

 Anzahl der Zeitschritte  ituh =   2880
 Maximum u                imax =      1     umax = 0.000000
 Summe u                   suu = 0.000000   suuh = 0.000000


 tmax [d]:     0.00


 Kennwerte Ausflusswelle
 -----------------------


 Endordinate Ausfluss           qaend =   0.011

 Scheitel-Ausfluss              iqmax =   1392    qmax =       3.663 [m**3/s]


 Fuelle-Ausfluss                  fuq =   0.0657 [hm**3]

 Fuelle-Ausfluss im Gerinne      fuqa =   0.0657 [hm**3]

 Fuelle-Ausfluss im vorland      fuqa =   0.0000 [hm**3]


 Scheitel-Ausfluss im Gerinne  iqamax =   1392   qamax =       3.663 [m**3/s]

 Scheitel-Ausfluss im Vorland  iqamax =      0   qamax =       0.000 [m**3/s]


 Gesamtzuflusswelle (ohne Basisabfluss)  sqz =      219.115
 Gesamtabflusswelle    "       "         sq  =      219.118


 Keine angeschlossenen Teilgebiete an Strang      4553
 Auswertung des Stranges:         4559

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Abflussverzoegerung mit Kalinin-Miljukov Parametern

 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 dt [h]:   0.08      tmax [d]:     4.83


 Kennwerte Zuflusswelle
 ----------------------

 Scheitel-Zufluss               iqzmax =   1392   qzmax =       3.740 [m**3/s]
 Scheitel-Zufluss im Gerinne    iqzfmx =   1392  qzfmax =       2.992 [m**3/s]
 Scheitel-Zufluss im Vorland    iqzvmx =   1392  qzvmax =       0.748 [m**3/s]

 Fuelle-Zufluss                   fuqz =   0.0696 [hm**3]
 Fuelle-zufluss im Gerinne       fuqzf =   0.0621 [hm**3]
 Fuelle-zufluss im Vorland       fuqzv =   0.0076 [hm**3]


 Kennwerte der Systemfunktionen
 -------------------------------

 Anzahl der Zeitschritte  ituh =   2880
 Maximum u                imax =      1     umax = 0.000000
 Summe u                   suu = 0.000000   suuh = 0.000000


 tmax [d]:     4.83


 Kennwerte Ausflusswelle
 -----------------------


 Endordinate Ausfluss           qaend =   0.012

 Scheitel-Ausfluss              iqmax =   1392    qmax =       3.705 [m**3/s]


 Fuelle-Ausfluss                  fuq =   0.0696 [hm**3]

 Fuelle-Ausfluss im Gerinne      fuqa =   0.0621 [hm**3]

 Fuelle-Ausfluss im vorland      fuqa =   0.0076 [hm**3]


 Scheitel-Ausfluss im Gerinne  iqamax =   1392   qamax =       2.964 [m**3/s]

 Scheitel-Ausfluss im Vorland  iqamax =   1392   qamax =       0.741 [m**3/s]


 Gesamtzuflusswelle (ohne Basisabfluss)  sqz =      232.146
 Gesamtabflusswelle    "       "         sq  =      232.153


 Keine angeschlossenen Teilgebiete an Strang      4559
 Auswertung des Stranges:         4554

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.

 Keine angeschlossenen Teilgebiete an Strang      4554
 Auswertung des Stranges:         4555

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Aufruf der Speicherroutine 


 zufluss-fuelle [hm]        0.005798 speicher 4555
 zusaetzl.zufl im nachl.ast [hm]  0.000002

 speicher   0.005799 abfluss-fuelle [hm]      4555
 abfluss-fuelle [hm]  0.0000 ueberlauf 

 speicherinhaltsaenderung [hm]  0.000053
 Keine angeschlossenen Teilgebiete an Strang      4555
 Auswertung des Stranges:         4556

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Abflussverzoegerung mit Kalinin-Miljukov Parametern

 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 dt [h]:   0.08      tmax [d]:     4.84


 Kennwerte Zuflusswelle
 ----------------------

 Scheitel-Zufluss               iqzmax =   1394   qzmax =       0.347 [m**3/s]
 Scheitel-Zufluss im Gerinne    iqzfmx =   1394  qzfmax =       0.347 [m**3/s]
 Scheitel-Zufluss im Vorland    iqzvmx =      0  qzvmax =       0.000 [m**3/s]

 Fuelle-Zufluss                   fuqz =   0.0058 [hm**3]
 Fuelle-zufluss im Gerinne       fuqzf =   0.0058 [hm**3]
 Fuelle-zufluss im Vorland       fuqzv =   0.0000 [hm**3]


 Kennwerte der Systemfunktionen
 -------------------------------

 Anzahl der Zeitschritte  ituh =     25
 Maximum u                imax =      1     umax = 0.540740
 Summe u                   suu = 0.727210   suuh = 1.000000


 tmax [d]:     4.84


 Kennwerte Ausflusswelle
 -----------------------

 Endordinate Ausfluss           qaend =   0.000
 Scheitel-Ausfluss              iqmax =   1395    qmax =       0.345 [m**3/s]

 Fuelle-Ausfluss                  fuq =   0.0058 [hm**3]
 Fuelle-Ausfluss im Gerinne      fuqa =   0.0058 [hm**3]

 Scheitel-Ausfluss im Gerinne  iqamax =   1395   qamax =       0.345 [m**3/s]


 Gesamtzuflusswelle (ohne Basisabfluss)  sqz =       19.333
 Gesamtabflusswelle    "       "         sq  =       19.333


 Keine angeschlossenen Teilgebiete an Strang      4556
 Auswertung des Stranges:         4557

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Aufruf der Speicherroutine 


 zufluss-fuelle [hm]        0.017504 speicher 4557
 zusaetzl.zufl im nachl.ast [hm]  0.000033

 speicher   0.017533 abfluss-fuelle [hm]      4557
 abfluss-fuelle [hm]  0.0000 ueberlauf 

 speicherinhaltsaenderung [hm]  0.000006
 Keine angeschlossenen Teilgebiete an Strang      4557
 Auswertung des Stranges:         4558

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Abflussverzoegerung mit Kalinin-Miljukov Parametern

 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 dt [h]:   0.08      tmax [d]:     4.85


 Kennwerte Zuflusswelle
 ----------------------

 Scheitel-Zufluss               iqzmax =   1397   qzmax =       0.932 [m**3/s]
 Scheitel-Zufluss im Gerinne    iqzfmx =   1397  qzfmax =       0.746 [m**3/s]
 Scheitel-Zufluss im Vorland    iqzvmx =   1397  qzvmax =       0.186 [m**3/s]

 Fuelle-Zufluss                   fuqz =   0.0175 [hm**3]
 Fuelle-zufluss im Gerinne       fuqzf =   0.0163 [hm**3]
 Fuelle-zufluss im Vorland       fuqzv =   0.0012 [hm**3]


 Kennwerte der Systemfunktionen
 -------------------------------

 Anzahl der Zeitschritte  ituh =   2880
 Maximum u                imax =      1     umax = 0.000000
 Summe u                   suu = 0.000000   suuh = 0.000000


 tmax [d]:     4.85


 Kennwerte Ausflusswelle
 -----------------------


 Endordinate Ausfluss           qaend =   0.003

 Scheitel-Ausfluss              iqmax =   1398    qmax =       0.930 [m**3/s]


 Fuelle-Ausfluss                  fuq =   0.0175 [hm**3]

 Fuelle-Ausfluss im Gerinne      fuqa =   0.0163 [hm**3]

 Fuelle-Ausfluss im vorland      fuqa =   0.0012 [hm**3]


 Scheitel-Ausfluss im Gerinne  iqamax =   1398   qamax =       0.744 [m**3/s]

 Scheitel-Ausfluss im Vorland  iqamax =   1398   qamax =       0.186 [m**3/s]


 Gesamtzuflusswelle (ohne Basisabfluss)  sqz =       58.458
 Gesamtabflusswelle    "       "         sq  =       58.460


 Keine angeschlossenen Teilgebiete an Strang      4558
 Auswertung des Stranges:         4561

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Aufruf der Speicherroutine 


 zufluss-fuelle [hm]        0.103661 speicher 4561
 zusaetzl.zufl im nachl.ast [hm]  0.000570

 speicher   0.104225 abfluss-fuelle [hm]      4561
 abfluss-fuelle [hm]  0.0000 ueberlauf 

 speicherinhaltsaenderung [hm]  0.000002
 Keine angeschlossenen Teilgebiete an Strang      4561
 Auswertung des Stranges:         4562

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Abflussverzoegerung mit Kalinin-Miljukov Parametern

 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 dt [h]:   0.08      tmax [d]:     4.88


 Kennwerte Zuflusswelle
 ----------------------

 Scheitel-Zufluss               iqzmax =   1405   qzmax =       3.759 [m**3/s]
 Scheitel-Zufluss im Gerinne    iqzfmx =   1405  qzfmax =       3.007 [m**3/s]
 Scheitel-Zufluss im Vorland    iqzvmx =   1405  qzvmax =       0.752 [m**3/s]

 Fuelle-Zufluss                   fuqz =   0.1042 [hm**3]
 Fuelle-zufluss im Gerinne       fuqzf =   0.0910 [hm**3]
 Fuelle-zufluss im Vorland       fuqzv =   0.0132 [hm**3]


 Kennwerte der Systemfunktionen
 -------------------------------

 Anzahl der Zeitschritte  ituh =    109
 Maximum u                imax =     16     umax = 0.040608
 Summe u                   suu = 0.999995   suuh = 1.000000


 tmax [d]:     4.96


 Kennwerte Ausflusswelle
 -----------------------


 Endordinate Ausfluss           qaend =   0.012

 Scheitel-Ausfluss              iqmax =   1411    qmax =       3.518 [m**3/s]


 Fuelle-Ausfluss                  fuq =   0.1042 [hm**3]

 Fuelle-Ausfluss im Gerinne      fuqa =   0.0910 [hm**3]

 Fuelle-Ausfluss im vorland      fuqa =   0.0132 [hm**3]


 Scheitel-Ausfluss im Gerinne  iqamax =   1406   qamax =       3.005 [m**3/s]

 Scheitel-Ausfluss im Vorland  iqamax =   1428   qamax =       0.689 [m**3/s]


 Gesamtzuflusswelle (ohne Basisabfluss)  sqz =      347.439
 Gesamtabflusswelle    "       "         sq  =      347.447


 Keine angeschlossenen Teilgebiete an Strang      4562
 Auswertung des Stranges:         4565

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Abflussverzoegerung mit Kalinin-Miljukov Parametern

 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 dt [h]:   0.08      tmax [d]:     4.92


 Kennwerte Zuflusswelle
 ----------------------

 Scheitel-Zufluss               iqzmax =   1416   qzmax =       5.336 [m**3/s]
 Scheitel-Zufluss im Gerinne    iqzfmx =   1416  qzfmax =       2.753 [m**3/s]
 Scheitel-Zufluss im Vorland    iqzvmx =   1416  qzvmax =       2.584 [m**3/s]

 Fuelle-Zufluss                   fuqz =   0.1880 [hm**3]
 Fuelle-zufluss im Gerinne       fuqzf =   0.1335 [hm**3]
 Fuelle-zufluss im Vorland       fuqzv =   0.0545 [hm**3]


 Kennwerte der Systemfunktionen
 -------------------------------

 Anzahl der Zeitschritte  ituh =     95
 Maximum u                imax =     24     umax = 0.042923
 Summe u                   suu = 0.999996   suuh = 1.000000


 tmax [d]:     5.01


 Kennwerte Ausflusswelle
 -----------------------


 Endordinate Ausfluss           qaend =   0.000

 Scheitel-Ausfluss              iqmax =   1431    qmax =       4.781 [m**3/s]


 Fuelle-Ausfluss                  fuq =   0.1882 [hm**3]

 Fuelle-Ausfluss im Gerinne      fuqa =   0.1334 [hm**3]

 Fuelle-Ausfluss im vorland      fuqa =   0.0548 [hm**3]


 Scheitel-Ausfluss im Gerinne  iqamax =   1418   qamax =       2.735 [m**3/s]

 Scheitel-Ausfluss im Vorland  iqamax =   1442   qamax =       2.446 [m**3/s]


 Gesamtzuflusswelle (ohne Basisabfluss)  sqz =      626.742
 Gesamtabflusswelle    "       "         sq  =      627.169


 Keine angeschlossenen Teilgebiete an Strang      4565
 Auswertung des Stranges:         4569

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Abflussverzoegerung mit Kalinin-Miljukov Parametern

 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 dt [h]:   0.08      tmax [d]:     4.97


 Kennwerte Zuflusswelle
 ----------------------

 Scheitel-Zufluss               iqzmax =   1430   qzmax =       4.913 [m**3/s]
 Scheitel-Zufluss im Gerinne    iqzfmx =   1430  qzfmax =       2.523 [m**3/s]
 Scheitel-Zufluss im Vorland    iqzvmx =   1430  qzvmax =       2.389 [m**3/s]

 Fuelle-Zufluss                   fuqz =   0.1930 [hm**3]
 Fuelle-zufluss im Gerinne       fuqzf =   0.1386 [hm**3]
 Fuelle-zufluss im Vorland       fuqzv =   0.0544 [hm**3]


 Kennwerte der Systemfunktionen
 -------------------------------

 Anzahl der Zeitschritte  ituh =    113
 Maximum u                imax =     14     umax = 0.040531
 Summe u                   suu = 0.999992   suuh = 1.000000


 tmax [d]:     5.03


 Kennwerte Ausflusswelle
 -----------------------


 Endordinate Ausfluss           qaend =   0.000

 Scheitel-Ausfluss              iqmax =   1441    qmax =       4.469 [m**3/s]


 Fuelle-Ausfluss                  fuq =   0.1940 [hm**3]

 Fuelle-Ausfluss im Gerinne      fuqa =   0.1382 [hm**3]

 Fuelle-Ausfluss im vorland      fuqa =   0.0558 [hm**3]


 Scheitel-Ausfluss im Gerinne  iqamax =   1435   qamax =       2.408 [m**3/s]

 Scheitel-Ausfluss im Vorland  iqamax =   1448   qamax =       2.187 [m**3/s]


 Gesamtzuflusswelle (ohne Basisabfluss)  sqz =      643.168
 Gesamtabflusswelle    "       "         sq  =      646.708


 Keine angeschlossenen Teilgebiete an Strang      4569
 Auswertung des Stranges:         4584

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Fiktiver Strang! Es erfolgt keine Abflussverzoegerung!
 Keine angeschlossenen Teilgebiete an Strang      4584
 Auswertung des Stranges:         4618

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Abflussverzoegerung mit Kalinin-Miljukov Parametern

 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 dt [h]:   0.08      tmax [d]:     5.00


 Kennwerte Zuflusswelle
 ----------------------

 Scheitel-Zufluss               iqzmax =   1440   qzmax =       4.620 [m**3/s]
 Scheitel-Zufluss im Gerinne    iqzfmx =   1440  qzfmax =       2.335 [m**3/s]
 Scheitel-Zufluss im Vorland    iqzvmx =   1440  qzvmax =       2.286 [m**3/s]

 Fuelle-Zufluss                   fuqz =   0.2262 [hm**3]
 Fuelle-zufluss im Gerinne       fuqzf =   0.1748 [hm**3]
 Fuelle-zufluss im Vorland       fuqzv =   0.0515 [hm**3]


 Kennwerte der Systemfunktionen
 -------------------------------

 Anzahl der Zeitschritte  ituh =    126
 Maximum u                imax =     18     umax = 0.034861
 Summe u                   suu = 0.999994   suuh = 1.000000


 tmax [d]:     5.09


 Kennwerte Ausflusswelle
 -----------------------


 Endordinate Ausfluss           qaend =   0.000

 Scheitel-Ausfluss              iqmax =   1456    qmax =       4.171 [m**3/s]


 Fuelle-Ausfluss                  fuq =   0.2263 [hm**3]

 Fuelle-Ausfluss im Gerinne      fuqa =   0.1748 [hm**3]

 Fuelle-Ausfluss im vorland      fuqa =   0.0515 [hm**3]


 Scheitel-Ausfluss im Gerinne  iqamax =   1441   qamax =       2.330 [m**3/s]

 Scheitel-Ausfluss im Vorland  iqamax =   1467   qamax =       2.115 [m**3/s]


 Gesamtzuflusswelle (ohne Basisabfluss)  sqz =      754.149
 Gesamtabflusswelle    "       "         sq  =      754.222


 Keine angeschlossenen Teilgebiete an Strang      4618
 Auswertung des Stranges:         4588

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Abflussverzoegerung mit Kalinin-Miljukov Parametern

 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 dt [h]:   0.08      tmax [d]:     5.06


 Kennwerte Zuflusswelle
 ----------------------

 Scheitel-Zufluss               iqzmax =   1456   qzmax =       4.186 [m**3/s]
 Scheitel-Zufluss im Gerinne    iqzfmx =   1456  qzfmax =       2.115 [m**3/s]
 Scheitel-Zufluss im Vorland    iqzvmx =   1456  qzvmax =       2.071 [m**3/s]

 Fuelle-Zufluss                   fuqz =   0.2291 [hm**3]
 Fuelle-zufluss im Gerinne       fuqzf =   0.1771 [hm**3]
 Fuelle-zufluss im Vorland       fuqzv =   0.0520 [hm**3]


 Kennwerte der Systemfunktionen
 -------------------------------

 Anzahl der Zeitschritte  ituh =    126
 Maximum u                imax =     18     umax = 0.034861
 Summe u                   suu = 0.999994   suuh = 1.000000


 tmax [d]:     5.15


 Kennwerte Ausflusswelle
 -----------------------


 Endordinate Ausfluss           qaend =   0.000

 Scheitel-Ausfluss              iqmax =   1471    qmax =       3.828 [m**3/s]


 Fuelle-Ausfluss                  fuq =   0.2292 [hm**3]

 Fuelle-Ausfluss im Gerinne      fuqa =   0.1771 [hm**3]

 Fuelle-Ausfluss im vorland      fuqa =   0.0521 [hm**3]


 Scheitel-Ausfluss im Gerinne  iqamax =   1456   qamax =       2.112 [m**3/s]

 Scheitel-Ausfluss im Vorland  iqamax =   1482   qamax =       1.936 [m**3/s]


 Gesamtzuflusswelle (ohne Basisabfluss)  sqz =      763.799
 Gesamtabflusswelle    "       "         sq  =      763.868


 Keine angeschlossenen Teilgebiete an Strang      4588
 Auswertung des Stranges:         1070

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4593

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    1.11

 gesamtmenge an niederschlag (mm):       39.6

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:    126


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  8.000


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4593
 anzahl hydrotope:     126


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      39.6 mm
 interz.verd.:                       5.6 mm
 bestandsniederschlag:              32.0 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      16.0 mm
 aktuelle verdunstung:               9.3 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              32.0 mm
 overlandflow:                       0.0 mm
 [infiltration:                     32.0 mm]
 verdunstung (bodensp.):             3.7 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -28.4 mm
 fehler:                             0.0 mm


 24.0152111  -> zufluss grundwasserleiter in  4593
TG:    4593 -> TG:    4594
Prozent:0.10

TG:    4593 -> TG:    4596
Prozent:0.90


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:            8.4 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:          10.3 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                -1.2 mm
     pot.entnahme GWS:                -1.2 mm
 speicherinhaltsaenderung:            -0.7 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.855 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.855 qkm



 ISO: Normierungsfaktor   = 1.0002
 ISO: Summe normierter uh =   1.0000


 Anzahl der Zeitschritte in iso durch Nachlauf zu hoch geworden.
 Sie wird auf 460 begrenzt !  gebiet :  4593

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.855

GEBIET: Abflusswelle Interflow:

 ISO: Normierungsfaktor   = 1.0000
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.855

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV: Retentionskonstanten:   1.4       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =       1.00
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH =  264
ISOV:  fuellenberechnung
ISOV: Abflusz =          5335.190
ISOV: Niederschlag =     5335.189

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
ISOV: Retentionskonstanten:6000.0       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =   96602.20
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH = 2880
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1071

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4596

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    1.11

 gesamtmenge an niederschlag (mm):       39.6

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     47


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  9.700


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4596
 anzahl hydrotope:      47


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      39.6 mm
 interz.verd.:                       5.6 mm
 bestandsniederschlag:              32.1 mm
 differenz interz.speicher:         -1.9 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      15.8 mm
 aktuelle verdunstung:               8.7 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              32.1 mm
 overlandflow:                       0.0 mm
 [infiltration:                     32.1 mm]
 verdunstung (bodensp.):             3.1 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -29.0 mm
 fehler:                             0.0 mm


 47.7071991  -> zufluss grundwasserleiter in  4596
TG:    4596 -> TG:    4597
Prozent:1.00


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:           72.3 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:          77.5 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -5.2 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.198 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.198 qkm



 ISO: Normierungsfaktor   = 1.0002
 ISO: Summe normierter uh =   1.0000


 Anzahl der Zeitschritte in iso durch Nachlauf zu hoch geworden.
 Sie wird auf 460 begrenzt !  gebiet :  4596

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.198

GEBIET: Abflusswelle Interflow:

 ISO: Normierungsfaktor   = 1.0000
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.198

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV: Retentionskonstanten:   1.4       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =       1.00
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH =  264
ISOV:  fuellenberechnung
ISOV: Abflusz =          1491.623
ISOV: Niederschlag =     1491.624

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
ISOV: Retentionskonstanten:6000.0       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =   96602.20
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH = 2880
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1072

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4591

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    1.11

 gesamtmenge an niederschlag (mm):       39.6

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     85


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  4.000


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4591
 anzahl hydrotope:      85


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      39.6 mm
 interz.verd.:                       5.6 mm
 bestandsniederschlag:              32.0 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      16.1 mm
 aktuelle verdunstung:               9.1 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              32.0 mm
 overlandflow:                       0.0 mm
 [infiltration:                     32.0 mm]
 verdunstung (bodensp.):             3.5 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -28.5 mm
 fehler:                             0.0 mm


 0.00000000E+00  -> zufluss grundwasserleiter in  4591
TG:    4591 -> TG:    4594
Prozent:1.00


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:            0.0 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:           1.6 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                -1.5 mm
     pot.entnahme GWS:                -1.5 mm
 speicherinhaltsaenderung:            -0.2 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.379 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.379 qkm



 ISO: Normierungsfaktor   = 1.0002
 ISO: Summe normierter uh =   1.0000


 Anzahl der Zeitschritte in iso durch Nachlauf zu hoch geworden.
 Sie wird auf 460 begrenzt !  gebiet :  4591

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.379

GEBIET: Abflusswelle Interflow:

 ISO: Normierungsfaktor   = 1.0000
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.379

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV: Retentionskonstanten:   1.4       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =       1.00
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH =  264
ISOV:  fuellenberechnung
ISOV: Abflusz =          2607.389
ISOV: Niederschlag =     2607.394

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
ISOV: Retentionskonstanten:6000.0       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =   96602.20
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH = 2880
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1073

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4594

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    1.11

 gesamtmenge an niederschlag (mm):       39.6

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     61


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  7.500


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4594
 anzahl hydrotope:      61


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      39.6 mm
 interz.verd.:                       5.6 mm
 bestandsniederschlag:              32.0 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      16.1 mm
 aktuelle verdunstung:               8.9 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              32.0 mm
 overlandflow:                       0.0 mm
 [infiltration:                     32.0 mm]
 verdunstung (bodensp.):             3.3 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -28.8 mm
 fehler:                             0.0 mm


 entnahme gws [qbm/s]:       0.000
 4.97667789  -> zufluss grundwasserleiter in  4594
TG:    4594 -> TG:    4597
Prozent:1.00


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:            4.9 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:           5.7 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.2 mm
     pot.entnahme GWS:                 0.2 mm
 speicherinhaltsaenderung:            -1.0 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.307 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.307 qkm



 ISO: Normierungsfaktor   = 1.0002
 ISO: Summe normierter uh =   1.0000


 Anzahl der Zeitschritte in iso durch Nachlauf zu hoch geworden.
 Sie wird auf 460 begrenzt !  gebiet :  4594

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.307

GEBIET: Abflusswelle Interflow:

 ISO: Normierungsfaktor   = 1.0000
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.307

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV: Retentionskonstanten:   1.4       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =       1.00
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH =  264
ISOV:  fuellenberechnung
ISOV: Abflusz =          1901.652
ISOV: Niederschlag =     1901.652

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
ISOV: Retentionskonstanten:6000.0       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =   96602.20
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH = 2880
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         4589

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.

 Keine angeschlossenen Teilgebiete an Strang      4589
 Auswertung des Stranges:         4590

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Aufruf der Speicherroutine 


 zufluss-fuelle [hm]        0.003071 speicher 4590
 zusaetzl.zufl im nachl.ast [hm]  0.000092

 speicher   0.003163 abfluss-fuelle [hm]      4590

 speicherinhaltsaenderung [hm]  0.000057
 Keine angeschlossenen Teilgebiete an Strang      4590
 Auswertung des Stranges:         4594

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Abflussverzoegerung mit Kalinin-Miljukov Parametern

 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 dt [h]:   0.08      tmax [d]:     4.91


 Kennwerte Zuflusswelle
 ----------------------

 Scheitel-Zufluss               iqzmax =   1415   qzmax =       0.113 [m**3/s]
 Scheitel-Zufluss im Gerinne    iqzfmx =   1415  qzfmax =       0.113 [m**3/s]
 Scheitel-Zufluss im Vorland    iqzvmx =      0  qzvmax =       0.000 [m**3/s]

 Fuelle-Zufluss                   fuqz =   0.0032 [hm**3]
 Fuelle-zufluss im Gerinne       fuqzf =   0.0032 [hm**3]
 Fuelle-zufluss im Vorland       fuqzv =   0.0000 [hm**3]


 Kennwerte der Systemfunktionen
 -------------------------------

 Anzahl der Zeitschritte  ituh =     18
 Maximum u                imax =      3     umax = 0.269426
 Summe u                   suu = 0.999998   suuh = 1.000000


 tmax [d]:     4.92


 Kennwerte Ausflusswelle
 -----------------------

 Endordinate Ausfluss           qaend =   0.000
 Scheitel-Ausfluss              iqmax =   1418    qmax =       0.113 [m**3/s]

 Fuelle-Ausfluss                  fuq =   0.0032 [hm**3]
 Fuelle-Ausfluss im Gerinne      fuqa =   0.0032 [hm**3]

 Scheitel-Ausfluss im Gerinne  iqamax =   1418   qamax =       0.113 [m**3/s]


 Gesamtzuflusswelle (ohne Basisabfluss)  sqz =       10.546
 Gesamtabflusswelle    "       "         sq  =       10.546


 Keine angeschlossenen Teilgebiete an Strang      4594
 Auswertung des Stranges:         4591

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.

 Keine angeschlossenen Teilgebiete an Strang      4591
 Auswertung des Stranges:         4592

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Aufruf der Speicherroutine 


 zufluss-fuelle [hm]        0.002544 speicher 4592
 zusaetzl.zufl im nachl.ast [hm]  0.000076

 speicher   0.002620 abfluss-fuelle [hm]      4592

 speicherinhaltsaenderung [hm]  0.000000
 Keine angeschlossenen Teilgebiete an Strang      4592
 Auswertung des Stranges:         4593

 Abflussverzoegerung mit Kalinin-Miljukov Parametern

 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 dt [h]:   0.08      tmax [d]:     4.94


 Kennwerte Zuflusswelle
 ----------------------

 Scheitel-Zufluss               iqzmax =   1422   qzmax =       0.086 [m**3/s]
 Scheitel-Zufluss im Gerinne    iqzfmx =   1422  qzfmax =       0.086 [m**3/s]
 Scheitel-Zufluss im Vorland    iqzvmx =      0  qzvmax =       0.000 [m**3/s]

 Fuelle-Zufluss                   fuqz =   0.0026 [hm**3]
 Fuelle-zufluss im Gerinne       fuqzf =   0.0026 [hm**3]
 Fuelle-zufluss im Vorland       fuqzv =   0.0000 [hm**3]


 Kennwerte der Systemfunktionen
 -------------------------------

 Anzahl der Zeitschritte  ituh =     18
 Maximum u                imax =      3     umax = 0.269426
 Summe u                   suu = 0.999998   suuh = 1.000000


 tmax [d]:     4.95


 Kennwerte Ausflusswelle
 -----------------------

 Endordinate Ausfluss           qaend =   0.000
 Scheitel-Ausfluss              iqmax =   1425    qmax =       0.085 [m**3/s]

 Fuelle-Ausfluss                  fuq =   0.0026 [hm**3]
 Fuelle-Ausfluss im Gerinne      fuqa =   0.0026 [hm**3]

 Scheitel-Ausfluss im Gerinne  iqamax =   1425   qamax =       0.085 [m**3/s]


 Gesamtzuflusswelle (ohne Basisabfluss)  sqz =        8.732
 Gesamtabflusswelle    "       "         sq  =        8.732


 Keine angeschlossenen Teilgebiete an Strang      4593
 Auswertung des Stranges:         4595

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Aufruf der Speicherroutine 


 zufluss-fuelle [hm]        0.012554 speicher 4595
 zusaetzl.zufl im nachl.ast [hm]  0.000475

 speicher   0.013028 abfluss-fuelle [hm]      4595

 speicherinhaltsaenderung [hm]  0.000000
 Keine angeschlossenen Teilgebiete an Strang      4595
 Auswertung des Stranges:         4596

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Aufruf der Speicherroutine 


 zufluss-fuelle [hm]        0.012104 speicher 4596
 zusaetzl.zufl im nachl.ast [hm]  0.000932

 speicher   0.013036 abfluss-fuelle [hm]      4596

 speicherinhaltsaenderung [hm]  0.000000
 Keine angeschlossenen Teilgebiete an Strang      4596
 Auswertung des Stranges:         4622

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Abflussverzoegerung mit Kalinin-Miljukov Parametern

 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 dt [h]:   0.08      tmax [d]:     4.93


 Kennwerte Zuflusswelle
 ----------------------

 Scheitel-Zufluss               iqzmax =   1420   qzmax =       0.492 [m**3/s]
 Scheitel-Zufluss im Gerinne    iqzfmx =   1420  qzfmax =       0.492 [m**3/s]
 Scheitel-Zufluss im Vorland    iqzvmx =      0  qzvmax =       0.000 [m**3/s]

 Fuelle-Zufluss                   fuqz =   0.0145 [hm**3]
 Fuelle-zufluss im Gerinne       fuqzf =   0.0145 [hm**3]
 Fuelle-zufluss im Vorland       fuqzv =   0.0000 [hm**3]


 Kennwerte der Systemfunktionen
 -------------------------------

 Anzahl der Zeitschritte  ituh =     18
 Maximum u                imax =      3     umax = 0.269426
 Summe u                   suu = 0.999998   suuh = 1.000000


 tmax [d]:     4.94


 Kennwerte Ausflusswelle
 -----------------------

 Endordinate Ausfluss           qaend =   0.000
 Scheitel-Ausfluss              iqmax =   1423    qmax =       0.491 [m**3/s]

 Fuelle-Ausfluss                  fuq =   0.0145 [hm**3]
 Fuelle-Ausfluss im Gerinne      fuqa =   0.0145 [hm**3]

 Scheitel-Ausfluss im Gerinne  iqamax =   1423   qamax =       0.491 [m**3/s]


 Gesamtzuflusswelle (ohne Basisabfluss)  sqz =       48.437
 Gesamtabflusswelle    "       "         sq  =       48.437


 Keine angeschlossenen Teilgebiete an Strang      4622
 Auswertung des Stranges:         1074

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4597

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    1.11

 gesamtmenge an niederschlag (mm):       39.6

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     84


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  7.000


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4597
 anzahl hydrotope:      84


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      39.6 mm
 interz.verd.:                       5.6 mm
 bestandsniederschlag:              32.1 mm
 differenz interz.speicher:         -1.9 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      15.8 mm
 aktuelle verdunstung:               9.0 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              32.1 mm
 overlandflow:                       0.0 mm
 [infiltration:                     32.1 mm]
 verdunstung (bodensp.):             3.5 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -28.6 mm
 fehler:                             0.0 mm


 entnahme gws [qbm/s]:       0.000
 56.9824944  -> zufluss grundwasserleiter in  4597
TG:    4597 -> TG:    4599
Prozent:1.00


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:           63.7 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:          70.0 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.4 mm
     pot.entnahme GWS:                 0.4 mm
 speicherinhaltsaenderung:            -6.6 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.268 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.268 qkm



 ISO: Normierungsfaktor   = 1.0002
 ISO: Summe normierter uh =   1.0000


 Anzahl der Zeitschritte in iso durch Nachlauf zu hoch geworden.
 Sie wird auf 460 begrenzt !  gebiet :  4597

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.268

GEBIET: Abflusswelle Interflow:

 ISO: Normierungsfaktor   = 1.0000
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.268

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV: Retentionskonstanten:   1.4       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =       1.00
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH =  264
ISOV:  fuellenberechnung
ISOV: Abflusz =          2465.399
ISOV: Niederschlag =     2465.402

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
ISOV: Retentionskonstanten:6000.0       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =   96602.20
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH = 2880
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1075

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4598

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    1.11

 gesamtmenge an niederschlag (mm):       39.6

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     54


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  6.000


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4598
 anzahl hydrotope:      54


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      39.6 mm
 interz.verd.:                       5.7 mm
 bestandsniederschlag:              31.8 mm
 differenz interz.speicher:         -2.1 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      16.0 mm
 aktuelle verdunstung:               9.4 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              31.8 mm
 overlandflow:                       0.0 mm
 [infiltration:                     31.7 mm]
 verdunstung (bodensp.):             3.6 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -28.1 mm
 fehler:                             0.0 mm


 entnahme gws [qbm/s]:       0.000
 73.2415161  -> zufluss grundwasserleiter in  4598
TG:    4598 -> TG:    4599
Prozent:1.00


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:          199.4 mm
 abgabe basisabfluss:                 59.0 mm
        grundw. unterh.l.TG:         139.8 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.5 mm
     pot.entnahme GWS:                 0.5 mm
 speicherinhaltsaenderung:             0.0 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.110 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.110 qkm



 ISO: Normierungsfaktor   = 1.0002
 ISO: Summe normierter uh =   1.0000


 Anzahl der Zeitschritte in iso durch Nachlauf zu hoch geworden.
 Sie wird auf 460 begrenzt !  gebiet :  4598

fuellenberechnung in iso
abflusz =             1.640
niederschlag =        1.643
flaeche zft  =        1.000
flaeche eing.=        0.110

GEBIET: Abflusswelle Interflow:

 ISO: Normierungsfaktor   = 1.0000
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.110

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV: Retentionskonstanten:   1.4       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =       1.00
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH =  264
ISOV:  fuellenberechnung
ISOV: Abflusz =           616.469
ISOV: Niederschlag =      616.469

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
ISOV: Retentionskonstanten:6000.0       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =   96602.20
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH = 2880
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1076

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4599

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    1.11

 gesamtmenge an niederschlag (mm):       39.6

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     27


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 = 20.100


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4599
 anzahl hydrotope:      27


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      39.6 mm
 interz.verd.:                       5.6 mm
 bestandsniederschlag:              32.0 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      16.2 mm
 aktuelle verdunstung:              10.6 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              32.0 mm
 overlandflow:                       1.0 mm
 [infiltration:                     31.0 mm]
 verdunstung (bodensp.):             5.0 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -26.0 mm
 fehler:                             0.0 mm


 entnahme gws [qbm/s]:       0.000
 113.932121  -> zufluss grundwasserleiter in  4599

 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:         1313.8 mm
 abgabe basisabfluss:               1015.6 mm
        grundw. unterh.l.TG:         296.8 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 1.4 mm
     pot.entnahme GWS:                 1.4 mm
 speicherinhaltsaenderung:             0.0 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.026 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.026 qkm



 ISO: Normierungsfaktor   = 1.0002
 ISO: Summe normierter uh =   1.0000


 Anzahl der Zeitschritte in iso durch Nachlauf zu hoch geworden.
 Sie wird auf 460 begrenzt !  gebiet :  4599

fuellenberechnung in iso
abflusz =            25.170
niederschlag =       25.214
flaeche zft  =        1.000
flaeche eing.=        0.026

GEBIET: Abflusswelle Interflow:

 ISO: Normierungsfaktor   = 1.0000
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.026

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV: Retentionskonstanten:   2.5       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =       1.00
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH =  448
ISOV:  fuellenberechnung
ISOV: Abflusz =           259.255
ISOV: Niederschlag =      259.256

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
ISOV: Retentionskonstanten:6000.0       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =   96602.20
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH = 2880
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         4597

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Abflussverzoegerung mit Kalinin-Miljukov Parametern

 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 dt [h]:   0.08      tmax [d]:     5.11


 Kennwerte Zuflusswelle
 ----------------------

 Scheitel-Zufluss               iqzmax =   1471   qzmax =       3.836 [m**3/s]
 Scheitel-Zufluss im Gerinne    iqzfmx =   1471  qzfmax =       2.151 [m**3/s]
 Scheitel-Zufluss im Vorland    iqzvmx =   1471  qzvmax =       1.685 [m**3/s]

 Fuelle-Zufluss                   fuqz =   0.2309 [hm**3]
 Fuelle-zufluss im Gerinne       fuqzf =   0.1815 [hm**3]
 Fuelle-zufluss im Vorland       fuqzv =   0.0494 [hm**3]


 Kennwerte der Systemfunktionen
 -------------------------------

 Anzahl der Zeitschritte  ituh =      9
 Maximum u                imax =      1     umax = 0.725271
 Summe u                   suu = 1.005751   suuh = 1.000000


 tmax [d]:     5.11


 Kennwerte Ausflusswelle
 -----------------------


 Endordinate Ausfluss           qaend =   0.001

 Scheitel-Ausfluss              iqmax =   1471    qmax =       3.835 [m**3/s]


 Fuelle-Ausfluss                  fuq =   0.2309 [hm**3]

 Fuelle-Ausfluss im Gerinne      fuqa =   0.1815 [hm**3]

 Fuelle-Ausfluss im vorland      fuqa =   0.0494 [hm**3]


 Scheitel-Ausfluss im Gerinne  iqamax =   1471   qamax =       2.150 [m**3/s]

 Scheitel-Ausfluss im Vorland  iqamax =   1471   qamax =       1.685 [m**3/s]


 Gesamtzuflusswelle (ohne Basisabfluss)  sqz =      769.635
 Gesamtabflusswelle    "       "         sq  =      769.636


 Keine angeschlossenen Teilgebiete an Strang      4597
 Auswertung des Stranges:         4598

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Abflussverzoegerung mit Kalinin-Miljukov Parametern

 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 dt [h]:   0.08      tmax [d]:     5.10


 Kennwerte Zuflusswelle
 ----------------------

 Scheitel-Zufluss               iqzmax =   1469   qzmax =       4.071 [m**3/s]
 Scheitel-Zufluss im Gerinne    iqzfmx =   1469  qzfmax =       2.823 [m**3/s]
 Scheitel-Zufluss im Vorland    iqzvmx =   1469  qzvmax =       1.248 [m**3/s]

 Fuelle-Zufluss                   fuqz =   0.2551 [hm**3]
 Fuelle-zufluss im Gerinne       fuqzf =   0.2110 [hm**3]
 Fuelle-zufluss im Vorland       fuqzv =   0.0441 [hm**3]


 Kennwerte der Systemfunktionen
 -------------------------------

 Anzahl der Zeitschritte  ituh =     16
 Maximum u                imax =      1     umax = 0.517926
 Summe u                   suu = 0.610857   suuh = 0.999798


 tmax [d]:     5.10


 Kennwerte Ausflusswelle
 -----------------------


 Endordinate Ausfluss           qaend =   0.000

 Scheitel-Ausfluss              iqmax =   1469    qmax =       4.068 [m**3/s]


 Fuelle-Ausfluss                  fuq =   0.2550 [hm**3]

 Fuelle-Ausfluss im Gerinne      fuqa =   0.2110 [hm**3]

 Fuelle-Ausfluss im vorland      fuqa =   0.0441 [hm**3]


 Scheitel-Ausfluss im Gerinne  iqamax =   1470   qamax =       2.821 [m**3/s]

 Scheitel-Ausfluss im Vorland  iqamax =   1469   qamax =       1.248 [m**3/s]


 Gesamtzuflusswelle (ohne Basisabfluss)  sqz =      850.168
 Gesamtabflusswelle    "       "         sq  =      850.125


 Keine angeschlossenen Teilgebiete an Strang      4598
 Auswertung des Stranges:         4599

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Fiktiver Strang! Es erfolgt keine Abflussverzoegerung!
 Keine angeschlossenen Teilgebiete an Strang      4599
 Auswertung des Stranges:        10002

 Fiktiver Strang! Es erfolgt keine Abflussverzoegerung!
 Keine angeschlossenen Teilgebiete an Strang     10002


 ------------------------------------------------------------------
           Berechnung wurde ohne Fehler beendet!                   
 ------------------------------------------------------------------
