



          *****************************************************
          *****************************************************
          ****                                             ****
          ****      HAMBURG UNIVERSITY OF TECHNOLOGY       ****
          ****                                             ****
          **** Department of River and Coastal Engineering ****
          ****                                             ****
          ****                                             ****
          ****            K A L Y P S O - N A              ****
          ****                                             ****
          ****                                             ****
          ****           Rainfall-Runoff-Model             ****
          ****                                             ****
          ****                                             ****
          ****                                             ****
          ****     VERS.  2.0.6      STATUS: 01.08.2006    ****
          ****                                             ****
          ****                                             ****
          ****     Contact:          Dipl.-Ing J. H�bsch   ****
          ****                       j.huebsch@tuhh.de     ****
          *****************************************************
          *****************************************************




 Bearbeitung Fall / Berechnungseinstellungen aus Steuerungsdatei:
 ----------------------------------------------------------------
 2 .. we nat  1996 08 24 00 1996 08 30 22 start\we_nat_start.txt                                                         


 Anzahl der Straenge in der Netzdatei:    182

 Anzahl der Teilgebiete in der Netzdatei:  77



 K U R Z Z E I T S I M U L A T I O N
 Zyklus (iz):                         1
 Anfangsdatum Zyklus (idatsa):   960824
 Enddatum Zyklus (idatse):       960830
 Zeitschritte (idif):              1993


 ************************************************************************************
 *  Neuer Jahreszyklus                                                              *
 *      Jahr:    1996                                                              *
 *      Zyklus:     1                                                              *
 ************************************************************************************
 Auswertung des Stranges:         1000

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4503

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    1.61

 gesamtmenge an niederschlag (mm):       57.5

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     63


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  1.000


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4503
 anzahl hydrotope:      63


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      57.5 mm
 interz.verd.:                       6.7 mm
 bestandsniederschlag:              48.7 mm
 differenz interz.speicher:         -2.1 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      15.5 mm
 aktuelle verdunstung:               9.6 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              48.7 mm
 overlandflow:                       1.4 mm
 [infiltration:                     47.3 mm]
 verdunstung (bodensp.):             3.0 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -44.4 mm
 fehler:                             0.0 mm


 0.00000000E+00  -> zufluss grundwasserleiter in  4503
TG:    4503 -> TG:    4500
Prozent:0.20

TG:    4503 -> TG:    4501
Prozent:0.10

TG:    4503 -> TG:    4506
Prozent:0.20

TG:    4503 -> TG:    4504
Prozent:0.50


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:            0.0 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:           2.0 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                -0.9 mm
     pot.entnahme GWS:                -0.9 mm
 speicherinhaltsaenderung:            -1.1 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.872 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.872 qkm



 ISO: Normierungsfaktor   = 1.0001
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =          1192.740
niederschlag =     1192.745
flaeche zft  =        1.000
flaeche eing.=        0.872

GEBIET: Abflusswelle Interflow:

 ISO: Normierungsfaktor   = 1.0001
 ISO: Summe normierter uh =   1.0000


 Anzahl der Zeitschritte in iso durch Nachlauf zu hoch geworden.
 Sie wird auf 460 begrenzt !  gebiet :  4503

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.872

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV: Retentionskonstanten:   2.2       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =       1.00
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH =  400
ISOV:  fuellenberechnung
ISOV: Abflusz =          3466.003
ISOV: Niederschlag =     3466.000

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
ISOV: Retentionskonstanten:6000.0       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =   96602.20
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH = 2880
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1001

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4501

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    1.61

 gesamtmenge an niederschlag (mm):       57.5

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     18


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  1.000


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4501
 anzahl hydrotope:      18


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      57.5 mm
 interz.verd.:                       6.6 mm
 bestandsniederschlag:              48.8 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      15.7 mm
 aktuelle verdunstung:              11.6 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              48.8 mm
 overlandflow:                      24.1 mm
 [infiltration:                     24.7 mm]
 verdunstung (bodensp.):             5.0 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -19.7 mm
 fehler:                             0.0 mm


 0.575069070  -> zufluss grundwasserleiter in  4501
TG:    4501 -> TG:    4502
Prozent:0.80

TG:    4501 -> TG:    4506
Prozent:0.20


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:            1.5 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:           2.4 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -0.9 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.115 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.115 qkm



 ISO: Normierungsfaktor   = 1.0001
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =          2768.152
niederschlag =     2768.160
flaeche zft  =        1.000
flaeche eing.=        0.115

GEBIET: Abflusswelle Interflow:

 ISO: Normierungsfaktor   = 1.0001
 ISO: Summe normierter uh =   1.0000


 Anzahl der Zeitschritte in iso durch Nachlauf zu hoch geworden.
 Sie wird auf 460 begrenzt !  gebiet :  4501

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.115

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV: Retentionskonstanten:   2.0       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =       1.00
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH =  374
ISOV:  fuellenberechnung
ISOV: Abflusz =           134.450
ISOV: Niederschlag =      134.450

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
ISOV: Retentionskonstanten:6000.0       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =   96602.20
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH = 2880
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1002

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4506

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    1.61

 gesamtmenge an niederschlag (mm):       57.5

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     16


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  1.000


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4506
 anzahl hydrotope:      16


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      57.5 mm
 interz.verd.:                       6.6 mm
 bestandsniederschlag:              48.9 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      15.5 mm
 aktuelle verdunstung:              11.4 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              48.9 mm
 overlandflow:                      24.2 mm
 [infiltration:                     24.7 mm]
 verdunstung (bodensp.):             4.9 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -19.9 mm
 fehler:                             0.0 mm


 1.33030891  -> zufluss grundwasserleiter in  4506
TG:    4506 -> TG:    4510
Prozent:1.00


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:            2.0 mm
 abgabe basisabfluss:                  0.1 mm
        grundw. unterh.l.TG:           2.8 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -0.9 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.196 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.196 qkm



 ISO: Normierungsfaktor   = 1.0001
 ISO: Summe normierter uh =   1.0000


 Anzahl der Zeitschritte in iso durch Nachlauf zu hoch geworden.
 Sie wird auf 460 begrenzt !  gebiet :  4506

fuellenberechnung in iso
abflusz =          4739.665
niederschlag =     4739.696
flaeche zft  =        1.000
flaeche eing.=        0.196

GEBIET: Abflusswelle Interflow:

 ISO: Normierungsfaktor   = 1.0001
 ISO: Summe normierter uh =   1.0000


 Anzahl der Zeitschritte in iso durch Nachlauf zu hoch geworden.
 Sie wird auf 460 begrenzt !  gebiet :  4506

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.196

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV: Retentionskonstanten:   3.0       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =       1.00
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH =  544
ISOV:  fuellenberechnung
ISOV: Abflusz =            58.029
ISOV: Niederschlag =       58.029

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
ISOV: Retentionskonstanten:6000.0       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =   96602.20
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH = 2880
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1003

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4504

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    1.61

 gesamtmenge an niederschlag (mm):       57.5

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     86


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  1.250


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4504
 anzahl hydrotope:      86


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      57.5 mm
 interz.verd.:                       6.6 mm
 bestandsniederschlag:              48.9 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      16.0 mm
 aktuelle verdunstung:              10.3 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              48.9 mm
 overlandflow:                      10.7 mm
 [infiltration:                     38.2 mm]
 verdunstung (bodensp.):             3.7 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -34.4 mm
 fehler:                             0.0 mm


 2.87534523  -> zufluss grundwasserleiter in  4504
TG:    4504 -> TG:    4510
Prozent:0.20

TG:    4504 -> TG:    4509
Prozent:0.80


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:            1.4 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:           2.6 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -1.2 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.621 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.621 qkm



 ISO: Normierungsfaktor   = 1.0001
 ISO: Summe normierter uh =   1.0000


 Anzahl der Zeitschritte in iso durch Nachlauf zu hoch geworden.
 Sie wird auf 460 begrenzt !  gebiet :  4504

fuellenberechnung in iso
abflusz =          6666.249
niederschlag =     6666.269
flaeche zft  =        1.000
flaeche eing.=        0.621

GEBIET: Abflusswelle Interflow:

 ISO: Normierungsfaktor   = 1.0001
 ISO: Summe normierter uh =   1.0000


 Anzahl der Zeitschritte in iso durch Nachlauf zu hoch geworden.
 Sie wird auf 460 begrenzt !  gebiet :  4504

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.621

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV: Retentionskonstanten:   1.8       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =       1.00
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH =  334
ISOV:  fuellenberechnung
ISOV: Abflusz =          5278.642
ISOV: Niederschlag =     5278.642

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
ISOV: Retentionskonstanten:6000.0       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =   96602.20
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH = 2880
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1004

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4510

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    1.61

 gesamtmenge an niederschlag (mm):       57.5

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:    106


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  1.500


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4510
 anzahl hydrotope:     106


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      57.5 mm
 interz.verd.:                       6.6 mm
 bestandsniederschlag:              48.9 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      15.9 mm
 aktuelle verdunstung:              10.2 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              48.9 mm
 overlandflow:                       1.7 mm
 [infiltration:                     47.2 mm]
 verdunstung (bodensp.):             3.6 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -43.6 mm
 fehler:                             0.0 mm


 2.89805770  -> zufluss grundwasserleiter in  4510
TG:    4510 -> TG:    4511
Prozent:0.20

TG:    4510 -> TG:    4526
Prozent:0.80


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:            1.8 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:           5.7 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -3.8 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.478 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.478 qkm



 ISO: Normierungsfaktor   = 1.0002
 ISO: Summe normierter uh =   1.0000


 Anzahl der Zeitschritte in iso durch Nachlauf zu hoch geworden.
 Sie wird auf 460 begrenzt !  gebiet :  4510

fuellenberechnung in iso
abflusz =           809.104
niederschlag =      810.503
flaeche zft  =        1.000
flaeche eing.=        0.478

GEBIET: Abflusswelle Interflow:

 ISO: Normierungsfaktor   = 1.0000
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.478

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV: Retentionskonstanten:   1.4       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =       1.00
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH =  264
ISOV:  fuellenberechnung
ISOV: Abflusz =          3926.043
ISOV: Niederschlag =     3926.047

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
ISOV: Retentionskonstanten:6000.0       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =   96602.20
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH = 2880
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1005

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4502

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    1.61

 gesamtmenge an niederschlag (mm):       57.5

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     77


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  1.000


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4502
 anzahl hydrotope:      77


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      57.5 mm
 interz.verd.:                       6.6 mm
 bestandsniederschlag:              48.9 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      15.5 mm
 aktuelle verdunstung:               9.8 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              48.9 mm
 overlandflow:                       4.1 mm
 [infiltration:                     44.8 mm]
 verdunstung (bodensp.):             3.2 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -41.6 mm
 fehler:                             0.0 mm


 0.720679641  -> zufluss grundwasserleiter in  4502
TG:    4502 -> TG:    4520
Prozent:0.40

TG:    4502 -> TG:    4523
Prozent:0.60


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:            0.5 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:           1.8 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -1.2 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.413 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.413 qkm



 ISO: Normierungsfaktor   = 1.0001
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =          1704.247
niederschlag =     1704.251
flaeche zft  =        1.000
flaeche eing.=        0.413

GEBIET: Abflusswelle Interflow:

 ISO: Normierungsfaktor   = 1.0001
 ISO: Summe normierter uh =   1.0000


 Anzahl der Zeitschritte in iso durch Nachlauf zu hoch geworden.
 Sie wird auf 460 begrenzt !  gebiet :  4502

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.413

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV: Retentionskonstanten:   1.2       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =       1.00
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH =  239
ISOV:  fuellenberechnung
ISOV: Abflusz =          5252.616
ISOV: Niederschlag =     5252.617

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
ISOV: Retentionskonstanten:6000.0       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =   96602.20
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH = 2880
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1006

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4500

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    1.61

 gesamtmenge an niederschlag (mm):       57.5

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:    125


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  1.000


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4500
 anzahl hydrotope:     125


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      57.5 mm
 interz.verd.:                       6.6 mm
 bestandsniederschlag:              48.9 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      15.9 mm
 aktuelle verdunstung:               9.9 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              48.9 mm
 overlandflow:                       3.5 mm
 [infiltration:                     45.4 mm]
 verdunstung (bodensp.):             3.3 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -42.1 mm
 fehler:                             0.0 mm


 1.15013814  -> zufluss grundwasserleiter in  4500
TG:    4500 -> TG:    4516
Prozent:0.60

TG:    4500 -> TG:    4520
Prozent:0.40


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:            0.4 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:           2.2 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                -0.9 mm
     pot.entnahme GWS:                -0.9 mm
 speicherinhaltsaenderung:            -1.0 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.933 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.933 qkm



 ISO: Normierungsfaktor   = 1.0001
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =          3234.267
niederschlag =     3234.270
flaeche zft  =        1.000
flaeche eing.=        0.933

GEBIET: Abflusswelle Interflow:

 ISO: Normierungsfaktor   = 1.0001
 ISO: Summe normierter uh =   1.0000


 Anzahl der Zeitschritte in iso durch Nachlauf zu hoch geworden.
 Sie wird auf 460 begrenzt !  gebiet :  4500

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.933

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV: Retentionskonstanten:   2.0       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =       1.00
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH =  380
ISOV:  fuellenberechnung
ISOV: Abflusz =          9736.097
ISOV: Niederschlag =     9736.101

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
ISOV: Retentionskonstanten:6000.0       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =   96602.20
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH = 2880
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1007

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4512

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    1.61

 gesamtmenge an niederschlag (mm):       57.5

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     33


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  3.800


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4512
 anzahl hydrotope:      33


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      57.5 mm
 interz.verd.:                       6.6 mm
 bestandsniederschlag:              48.9 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      16.1 mm
 aktuelle verdunstung:               9.6 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              48.9 mm
 overlandflow:                       0.0 mm
 [infiltration:                     48.9 mm]
 verdunstung (bodensp.):             3.0 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -45.9 mm
 fehler:                             0.0 mm


 entnahme gws [qbm/s]:       0.001
 0.00000000E+00  -> zufluss grundwasserleiter in  4512
TG:    4512 -> TG:    4513
Prozent:0.10

TG:    4512 -> TG:    4514
Prozent:0.90


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:            0.0 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:           1.9 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 1.0 mm
     pot.entnahme GWS:                 1.0 mm
 speicherinhaltsaenderung:            -2.9 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.408 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.408 qkm



 ISO: Normierungsfaktor   = 1.0002
 ISO: Summe normierter uh =   1.0000


 Anzahl der Zeitschritte in iso durch Nachlauf zu hoch geworden.
 Sie wird auf 460 begrenzt !  gebiet :  4512

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.408

GEBIET: Abflusswelle Interflow:

 ISO: Normierungsfaktor   = 1.0000
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.408

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV: Retentionskonstanten:   1.4       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =       1.00
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH =  264
ISOV:  fuellenberechnung
ISOV: Abflusz =          3789.342
ISOV: Niederschlag =     3789.343

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
ISOV: Retentionskonstanten:6000.0       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =   96602.20
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH = 2880
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1008

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4513

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    1.61

 gesamtmenge an niederschlag (mm):       57.5

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     13


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  2.300


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4513
 anzahl hydrotope:      13


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      57.5 mm
 interz.verd.:                       6.6 mm
 bestandsniederschlag:              48.9 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      15.9 mm
 aktuelle verdunstung:               9.6 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              48.9 mm
 overlandflow:                       0.0 mm
 [infiltration:                     48.9 mm]
 verdunstung (bodensp.):             3.0 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -45.9 mm
 fehler:                             0.0 mm


 entnahme gws [qbm/s]:       0.000
 0.257184803  -> zufluss grundwasserleiter in  4513
TG:    4513 -> TG:    4516
Prozent:1.00


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:            0.4 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:           3.4 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.2 mm
     pot.entnahme GWS:                 0.2 mm
 speicherinhaltsaenderung:            -3.2 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.207 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.207 qkm



 ISO: Normierungsfaktor   = 1.0002
 ISO: Summe normierter uh =   1.0000


 Anzahl der Zeitschritte in iso durch Nachlauf zu hoch geworden.
 Sie wird auf 460 begrenzt !  gebiet :  4513

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.207

GEBIET: Abflusswelle Interflow:

 ISO: Normierungsfaktor   = 1.0000
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.207

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV: Retentionskonstanten:   1.4       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =       1.00
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH =  264
ISOV:  fuellenberechnung
ISOV: Abflusz =          1710.881
ISOV: Niederschlag =     1710.884

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
ISOV: Retentionskonstanten:6000.0       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =   96602.20
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH = 2880
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1009

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4516

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    1.61

 gesamtmenge an niederschlag (mm):       57.5

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     38


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  8.000


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4516
 anzahl hydrotope:      38


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      57.5 mm
 interz.verd.:                       6.6 mm
 bestandsniederschlag:              48.9 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      16.1 mm
 aktuelle verdunstung:               9.6 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              48.9 mm
 overlandflow:                       0.0 mm
 [infiltration:                     48.9 mm]
 verdunstung (bodensp.):             3.0 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -45.9 mm
 fehler:                             0.0 mm


 6.44798565  -> zufluss grundwasserleiter in  4516
TG:    4516 -> TG:    4519
Prozent:0.65

TG:    4516 -> TG:    4520
Prozent:0.35


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:            4.5 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:          10.2 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -5.7 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.429 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.429 qkm



 ISO: Normierungsfaktor   = 1.0002
 ISO: Summe normierter uh =   1.0000


 Anzahl der Zeitschritte in iso durch Nachlauf zu hoch geworden.
 Sie wird auf 460 begrenzt !  gebiet :  4516

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.429

GEBIET: Abflusswelle Interflow:

 ISO: Normierungsfaktor   = 1.0000
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.429

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV: Retentionskonstanten:   1.4       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =       1.00
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH =  264
ISOV:  fuellenberechnung
ISOV: Abflusz =          3562.102
ISOV: Niederschlag =     3562.102

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
ISOV: Retentionskonstanten:6000.0       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =   96602.20
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH = 2880
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1010

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4520

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    1.61

 gesamtmenge an niederschlag (mm):       57.5

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     47


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  5.000


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4520
 anzahl hydrotope:      47


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      57.5 mm
 interz.verd.:                       6.6 mm
 bestandsniederschlag:              48.9 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      16.1 mm
 aktuelle verdunstung:               9.7 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              48.9 mm
 overlandflow:                       0.0 mm
 [infiltration:                     48.9 mm]
 verdunstung (bodensp.):             3.1 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -45.8 mm
 fehler:                             0.0 mm


 8.81579304  -> zufluss grundwasserleiter in  4520
TG:    4520 -> TG:    4522
Prozent:0.10

TG:    4520 -> TG:    4524
Prozent:0.75

TG:    4520 -> TG:    4523
Prozent:0.15


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:            6.5 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:          13.1 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -6.5 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.404 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.404 qkm



 ISO: Normierungsfaktor   = 1.0002
 ISO: Summe normierter uh =   1.0000


 Anzahl der Zeitschritte in iso durch Nachlauf zu hoch geworden.
 Sie wird auf 460 begrenzt !  gebiet :  4520

fuellenberechnung in iso
abflusz =             2.447
niederschlag =        2.451
flaeche zft  =        1.000
flaeche eing.=        0.404

GEBIET: Abflusswelle Interflow:

 ISO: Normierungsfaktor   = 1.0000
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.404

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV: Retentionskonstanten:   1.4       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =       1.00
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH =  264
ISOV:  fuellenberechnung
ISOV: Abflusz =          3492.254
ISOV: Niederschlag =     3492.257

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
ISOV: Retentionskonstanten:6000.0       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =   96602.20
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH = 2880
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1011

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4523

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    1.61

 gesamtmenge an niederschlag (mm):       57.5

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     66


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  2.500


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4523
 anzahl hydrotope:      66


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      57.5 mm
 interz.verd.:                       6.6 mm
 bestandsniederschlag:              48.8 mm
 differenz interz.speicher:         -2.1 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      15.5 mm
 aktuelle verdunstung:               9.7 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              48.8 mm
 overlandflow:                       0.1 mm
 [infiltration:                     48.6 mm]
 verdunstung (bodensp.):             3.1 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -45.6 mm
 fehler:                             0.0 mm


 4.09409475  -> zufluss grundwasserleiter in  4523
TG:    4523 -> TG:    4526
Prozent:0.10

TG:    4523 -> TG:    4524
Prozent:0.90


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:            3.0 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:           7.5 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -4.6 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.416 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.416 qkm



 ISO: Normierungsfaktor   = 1.0002
 ISO: Summe normierter uh =   1.0000


 Anzahl der Zeitschritte in iso durch Nachlauf zu hoch geworden.
 Sie wird auf 460 begrenzt !  gebiet :  4523

fuellenberechnung in iso
abflusz =            47.057
niederschlag =       47.139
flaeche zft  =        1.000
flaeche eing.=        0.416

GEBIET: Abflusswelle Interflow:

 ISO: Normierungsfaktor   = 1.0000
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.416

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV: Retentionskonstanten:   1.4       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =       1.00
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH =  264
ISOV:  fuellenberechnung
ISOV: Abflusz =          2777.060
ISOV: Niederschlag =     2777.059

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
ISOV: Retentionskonstanten:6000.0       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =   96602.20
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH = 2880
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1012

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4526

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    1.61

 gesamtmenge an niederschlag (mm):       57.5

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     86


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  1.000


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4526
 anzahl hydrotope:      86


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      57.5 mm
 interz.verd.:                       6.7 mm
 bestandsniederschlag:              48.7 mm
 differenz interz.speicher:         -2.1 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      15.8 mm
 aktuelle verdunstung:              10.4 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              48.7 mm
 overlandflow:                       1.0 mm
 [infiltration:                     47.7 mm]
 verdunstung (bodensp.):             3.7 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -43.9 mm
 fehler:                             0.0 mm


 8.27566338  -> zufluss grundwasserleiter in  4526
TG:    4526 -> TG:    4532
Prozent:0.50

TG:    4526 -> TG:    4566
Prozent:0.20

TG:    4526 -> TG:    4567
Prozent:0.30


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:            4.1 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:           9.0 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -5.0 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.608 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.608 qkm



 ISO: Normierungsfaktor   = 1.0002
 ISO: Summe normierter uh =   1.0000


 Anzahl der Zeitschritte in iso durch Nachlauf zu hoch geworden.
 Sie wird auf 460 begrenzt !  gebiet :  4526

fuellenberechnung in iso
abflusz =           609.846
niederschlag =      610.901
flaeche zft  =        1.000
flaeche eing.=        0.608

GEBIET: Abflusswelle Interflow:

 ISO: Normierungsfaktor   = 1.0000
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.608

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV: Retentionskonstanten:   1.4       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =       1.00
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH =  264
ISOV:  fuellenberechnung
ISOV: Abflusz =          3444.389
ISOV: Niederschlag =     3444.389

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
ISOV: Retentionskonstanten:6000.0       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =   96602.20
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH = 2880
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1013

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4514

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    1.61

 gesamtmenge an niederschlag (mm):       57.5

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     96


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  8.000


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4514
 anzahl hydrotope:      96


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      57.5 mm
 interz.verd.:                       6.6 mm
 bestandsniederschlag:              48.9 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      16.1 mm
 aktuelle verdunstung:               9.7 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              48.9 mm
 overlandflow:                       0.1 mm
 [infiltration:                     48.8 mm]
 verdunstung (bodensp.):             3.1 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -45.7 mm
 fehler:                             0.0 mm


 2.31466365  -> zufluss grundwasserleiter in  4514
TG:    4514 -> TG:    4515
Prozent:0.15

TG:    4514 -> TG:    4518
Prozent:0.20

TG:    4514 -> TG:    4519
Prozent:0.65


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:            1.0 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:           5.3 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -4.3 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.701 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.701 qkm



 ISO: Normierungsfaktor   = 1.0002
 ISO: Summe normierter uh =   1.0000


 Anzahl der Zeitschritte in iso durch Nachlauf zu hoch geworden.
 Sie wird auf 460 begrenzt !  gebiet :  4514

fuellenberechnung in iso
abflusz =            52.169
niederschlag =       52.259
flaeche zft  =        1.000
flaeche eing.=        0.701

GEBIET: Abflusswelle Interflow:

 ISO: Normierungsfaktor   = 1.0000
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.701

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV: Retentionskonstanten:   1.4       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =       1.00
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH =  264
ISOV:  fuellenberechnung
ISOV: Abflusz =          7782.247
ISOV: Niederschlag =     7782.248

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
ISOV: Retentionskonstanten:6000.0       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =   96602.20
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH = 2880
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1014

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4515

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    1.61

 gesamtmenge an niederschlag (mm):       57.5

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     23


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  8.000


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4515
 anzahl hydrotope:      23


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      57.5 mm
 interz.verd.:                       6.2 mm
 bestandsniederschlag:              49.5 mm
 differenz interz.speicher:         -1.8 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      13.7 mm
 aktuelle verdunstung:               8.8 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              49.5 mm
 overlandflow:                       0.2 mm
 [infiltration:                     49.3 mm]
 verdunstung (bodensp.):             2.6 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -46.8 mm
 fehler:                             0.0 mm


 1.84850907  -> zufluss grundwasserleiter in  4515
TG:    4515 -> TG:    4519
Prozent:1.00


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:            9.3 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:          11.1 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -1.8 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.060 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.060 qkm



 ISO: Normierungsfaktor   = 1.0002
 ISO: Summe normierter uh =   1.0000


 Anzahl der Zeitschritte in iso durch Nachlauf zu hoch geworden.
 Sie wird auf 460 begrenzt !  gebiet :  4515

fuellenberechnung in iso
abflusz =            10.122
niederschlag =       10.139
flaeche zft  =        1.000
flaeche eing.=        0.060

GEBIET: Abflusswelle Interflow:

 ISO: Normierungsfaktor   = 1.0000
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.060

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV: Retentionskonstanten:   0.6       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =       1.00
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH =  125
ISOV:  fuellenberechnung
ISOV: Abflusz =          1312.543
ISOV: Niederschlag =     1312.545

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
ISOV: Retentionskonstanten:6000.0       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =   96602.20
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH = 2880
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1015

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4518

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    1.61

 gesamtmenge an niederschlag (mm):       57.5

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     15


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  2.000


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4518
 anzahl hydrotope:      15


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      57.5 mm
 interz.verd.:                       6.6 mm
 bestandsniederschlag:              48.9 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      15.6 mm
 aktuelle verdunstung:               9.6 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              48.9 mm
 overlandflow:                       0.0 mm
 [infiltration:                     48.9 mm]
 verdunstung (bodensp.):             3.0 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -45.9 mm
 fehler:                             0.0 mm


 2.46467853  -> zufluss grundwasserleiter in  4518
TG:    4518 -> TG:    4519
Prozent:1.00


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:           36.3 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:          43.0 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -6.6 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.020 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.020 qkm



 ISO: Normierungsfaktor   = 1.0002
 ISO: Summe normierter uh =   1.0000


 Anzahl der Zeitschritte in iso durch Nachlauf zu hoch geworden.
 Sie wird auf 460 begrenzt !  gebiet :  4518

fuellenberechnung in iso
abflusz =             0.230
niederschlag =        0.230
flaeche zft  =        1.000
flaeche eing.=        0.020

GEBIET: Abflusswelle Interflow:

 ISO: Normierungsfaktor   = 1.0000
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.020

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV: Retentionskonstanten:   0.6       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =       1.00
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH =  125
ISOV:  fuellenberechnung
ISOV: Abflusz =            51.775
ISOV: Niederschlag =       51.775

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
ISOV: Retentionskonstanten:6000.0       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =   96602.20
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH = 2880
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1016

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4519

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    1.61

 gesamtmenge an niederschlag (mm):       57.5

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     73


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  7.000


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4519
 anzahl hydrotope:      73


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      57.5 mm
 interz.verd.:                       6.5 mm
 bestandsniederschlag:              49.0 mm
 differenz interz.speicher:         -1.9 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      15.4 mm
 aktuelle verdunstung:               9.7 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              49.0 mm
 overlandflow:                       0.3 mm
 [infiltration:                     48.8 mm]
 verdunstung (bodensp.):             3.1 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -45.6 mm
 fehler:                             0.0 mm


 22.6299171  -> zufluss grundwasserleiter in  4519
TG:    4519 -> TG:    4522
Prozent:0.60

TG:    4519 -> TG:    4527
Prozent:0.20

TG:    4519 -> TG:    4530
Prozent:0.10

TG:    4519 -> TG:    4529
Prozent:0.10


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:           24.9 mm
 abgabe basisabfluss:                  4.7 mm
        grundw. unterh.l.TG:          21.2 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -1.0 mm
 fehler:                               0.1 mm


 flaechenanteile: 

   grundwasserleiter:                0.272 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.272 qkm



 ISO: Normierungsfaktor   = 1.0002
 ISO: Summe normierter uh =   1.0000


 Anzahl der Zeitschritte in iso durch Nachlauf zu hoch geworden.
 Sie wird auf 460 begrenzt !  gebiet :  4519

fuellenberechnung in iso
abflusz =            76.017
niederschlag =       76.149
flaeche zft  =        1.000
flaeche eing.=        0.272

GEBIET: Abflusswelle Interflow:

 ISO: Normierungsfaktor   = 1.0000
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.272

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV: Retentionskonstanten:   1.2       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =       1.00
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH =  236
ISOV:  fuellenberechnung
ISOV: Abflusz =          2485.670
ISOV: Niederschlag =     2485.673

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
ISOV: Retentionskonstanten:6000.0       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =   96602.20
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH = 2880
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1017

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4522

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    1.61

 gesamtmenge an niederschlag (mm):       57.5

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     19


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  5.000


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4522
 anzahl hydrotope:      19


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      57.5 mm
 interz.verd.:                       6.3 mm
 bestandsniederschlag:              49.4 mm
 differenz interz.speicher:         -1.8 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      14.0 mm
 aktuelle verdunstung:               9.2 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              49.4 mm
 overlandflow:                       0.6 mm
 [infiltration:                     48.8 mm]
 verdunstung (bodensp.):             2.9 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -45.9 mm
 fehler:                             0.0 mm


 13.2926903  -> zufluss grundwasserleiter in  4522
TG:    4522 -> TG:    4524
Prozent:0.60

TG:    4522 -> TG:    4532
Prozent:0.40


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:          111.2 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:         113.6 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -2.5 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.036 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.036 qkm



 ISO: Normierungsfaktor   = 1.0002
 ISO: Summe normierter uh =   1.0000


 Anzahl der Zeitschritte in iso durch Nachlauf zu hoch geworden.
 Sie wird auf 460 begrenzt !  gebiet :  4522

fuellenberechnung in iso
abflusz =            21.730
niederschlag =       21.767
flaeche zft  =        1.000
flaeche eing.=        0.036

GEBIET: Abflusswelle Interflow:

 ISO: Normierungsfaktor   = 1.0000
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.036

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV: Retentionskonstanten:   0.6       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =       1.00
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH =  125
ISOV:  fuellenberechnung
ISOV: Abflusz =           797.643
ISOV: Niederschlag =      797.643

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
ISOV: Retentionskonstanten:6000.0       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =   96602.20
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH = 2880
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1018

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4524

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    1.61

 gesamtmenge an niederschlag (mm):       57.5

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     41


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 = 10.000


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4524
 anzahl hydrotope:      41


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      57.5 mm
 interz.verd.:                       6.6 mm
 bestandsniederschlag:              48.4 mm
 differenz interz.speicher:         -2.5 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      14.8 mm
 aktuelle verdunstung:               9.8 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              48.4 mm
 overlandflow:                       0.3 mm
 [infiltration:                     48.0 mm]
 verdunstung (bodensp.):             3.2 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -44.9 mm
 fehler:                             0.0 mm


 30.7882748  -> zufluss grundwasserleiter in  4524
TG:    4524 -> TG:    4532
Prozent:1.00


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:           39.5 mm
 abgabe basisabfluss:                  9.9 mm
        grundw. unterh.l.TG:          30.4 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -0.9 mm
 fehler:                               0.1 mm


 flaechenanteile: 

   grundwasserleiter:                0.234 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.234 qkm



 ISO: Normierungsfaktor   = 1.0002
 ISO: Summe normierter uh =   1.0000


 Anzahl der Zeitschritte in iso durch Nachlauf zu hoch geworden.
 Sie wird auf 460 begrenzt !  gebiet :  4524

fuellenberechnung in iso
abflusz =            75.990
niederschlag =       76.121
flaeche zft  =        1.000
flaeche eing.=        0.234

GEBIET: Abflusswelle Interflow:

 ISO: Normierungsfaktor   = 1.0000
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.234

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV: Retentionskonstanten:   2.8       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =       1.00
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH =  500
ISOV:  fuellenberechnung
ISOV: Abflusz =           346.195
ISOV: Niederschlag =      346.196

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
ISOV: Retentionskonstanten:6000.0       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =   96602.20
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH = 2880
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1019

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4527

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    1.61

 gesamtmenge an niederschlag (mm):       57.5

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     14


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  1.000


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4527
 anzahl hydrotope:      14


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      57.5 mm
 interz.verd.:                       6.6 mm
 bestandsniederschlag:              48.9 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      16.1 mm
 aktuelle verdunstung:              10.3 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              48.9 mm
 overlandflow:                       0.7 mm
 [infiltration:                     48.1 mm]
 verdunstung (bodensp.):             3.7 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -44.4 mm
 fehler:                             0.0 mm


 3.84314227  -> zufluss grundwasserleiter in  4527
TG:    4527 -> TG:    4530
Prozent:0.30

TG:    4527 -> TG:    4529
Prozent:0.70


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:            7.8 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:          10.6 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -2.8 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.148 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.148 qkm



 ISO: Normierungsfaktor   = 1.0002
 ISO: Summe normierter uh =   1.0000


 Anzahl der Zeitschritte in iso durch Nachlauf zu hoch geworden.
 Sie wird auf 460 begrenzt !  gebiet :  4527

fuellenberechnung in iso
abflusz =           109.452
niederschlag =      109.641
flaeche zft  =        1.000
flaeche eing.=        0.148

GEBIET: Abflusswelle Interflow:

 ISO: Normierungsfaktor   = 1.0000
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.148

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV: Retentionskonstanten:   1.2       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =       1.00
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH =  236
ISOV:  fuellenberechnung
ISOV: Abflusz =          1581.722
ISOV: Niederschlag =     1581.721

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
ISOV: Retentionskonstanten:6000.0       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =   96602.20
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH = 2880
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1020

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4530

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    1.61

 gesamtmenge an niederschlag (mm):       57.5

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     67


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  2.500


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4530
 anzahl hydrotope:      67


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      57.5 mm
 interz.verd.:                       6.6 mm
 bestandsniederschlag:              48.9 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      16.0 mm
 aktuelle verdunstung:              10.4 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              48.9 mm
 overlandflow:                       0.7 mm
 [infiltration:                     48.2 mm]
 verdunstung (bodensp.):             3.8 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -44.4 mm
 fehler:                             0.0 mm


 3.48186660  -> zufluss grundwasserleiter in  4530
TG:    4530 -> TG:    4532
Prozent:0.70

TG:    4530 -> TG:    4563
Prozent:0.30


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:            3.8 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:           6.9 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -3.1 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.275 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.275 qkm



 ISO: Normierungsfaktor   = 1.0002
 ISO: Summe normierter uh =   1.0000


 Anzahl der Zeitschritte in iso durch Nachlauf zu hoch geworden.
 Sie wird auf 460 begrenzt !  gebiet :  4530

fuellenberechnung in iso
abflusz =           187.627
niederschlag =      187.952
flaeche zft  =        1.000
flaeche eing.=        0.275

GEBIET: Abflusswelle Interflow:

 ISO: Normierungsfaktor   = 1.0000
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.275

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV: Retentionskonstanten:   1.2       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =       1.00
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH =  236
ISOV:  fuellenberechnung
ISOV: Abflusz =          2442.312
ISOV: Niederschlag =     2442.313

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
ISOV: Retentionskonstanten:6000.0       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =   96602.20
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH = 2880
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1021

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4532

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    1.61

 gesamtmenge an niederschlag (mm):       57.5

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     85


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  8.000


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4532
 anzahl hydrotope:      85


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      57.5 mm
 interz.verd.:                       7.0 mm
 bestandsniederschlag:              47.9 mm
 differenz interz.speicher:         -2.6 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      15.6 mm
 aktuelle verdunstung:              10.4 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              47.9 mm
 overlandflow:                       0.4 mm
 [infiltration:                     47.5 mm]
 verdunstung (bodensp.):             3.3 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -44.2 mm
 fehler:                             0.0 mm


 42.7466660  -> zufluss grundwasserleiter in  4532
TG:    4532 -> TG:    4563
Prozent:0.25

TG:    4532 -> TG:    4565
Prozent:0.25

TG:    4532 -> TG:    4566
Prozent:0.50


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:            8.8 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:          12.1 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -3.3 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                1.464 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    1.464 qkm



 ISO: Normierungsfaktor   = 1.0002
 ISO: Summe normierter uh =   1.0000


 Anzahl der Zeitschritte in iso durch Nachlauf zu hoch geworden.
 Sie wird auf 460 begrenzt !  gebiet :  4532

fuellenberechnung in iso
abflusz =           549.754
niederschlag =      550.704
flaeche zft  =        1.000
flaeche eing.=        1.464

GEBIET: Abflusswelle Interflow:

 ISO: Normierungsfaktor   = 1.0000
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        1.464

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV: Retentionskonstanten:   3.1       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =       1.00
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH =  551
ISOV:  fuellenberechnung
ISOV: Abflusz =          1060.979
ISOV: Niederschlag =     1060.979

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
ISOV: Retentionskonstanten:6000.0       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =   96602.20
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH = 2880
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1022

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4534

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    1.61

 gesamtmenge an niederschlag (mm):       57.5

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     32


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  0.900
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  2.200


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4534
 anzahl hydrotope:      32


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      57.5 mm
 interz.verd.:                       6.6 mm
 bestandsniederschlag:              48.9 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      16.0 mm
 aktuelle verdunstung:               9.3 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              48.9 mm
 overlandflow:                       5.0 mm
 [infiltration:                     43.9 mm]
 verdunstung (bodensp.):             2.7 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -41.2 mm
 fehler:                             0.0 mm


 0.00000000E+00  -> zufluss grundwasserleiter in  4534
TG:    4534 -> TG:    4535
Prozent:0.50

TG:    4534 -> TG:    4542
Prozent:0.15

TG:    4534 -> TG:    4537
Prozent:0.35


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:            0.0 mm
 abgabe basisabfluss:                  1.3 mm
        grundw. unterh.l.TG:          11.8 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:               -13.1 mm
     pot.entnahme GWS:               -13.1 mm
 speicherinhaltsaenderung:             0.0 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.299 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.299 qkm



 ISO: Normierungsfaktor   = 1.0001
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =          1495.550
niederschlag =     1495.550
flaeche zft  =        1.000
flaeche eing.=        0.299

GEBIET: Abflusswelle Interflow:

 ISO: Normierungsfaktor   = 1.0000
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.299

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV: Retentionskonstanten:   0.2       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =       1.00
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH =   38
ISOV:  fuellenberechnung
ISOV: Abflusz =          3557.641
ISOV: Niederschlag =     3557.642

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
ISOV: Retentionskonstanten:6000.0       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =   96602.20
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH = 2880
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1023

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4542

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    1.61

 gesamtmenge an niederschlag (mm):       57.5

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     49


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  0.900
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  1.500


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4542
 anzahl hydrotope:      49


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      57.5 mm
 interz.verd.:                       6.6 mm
 bestandsniederschlag:              48.9 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      16.2 mm
 aktuelle verdunstung:               9.4 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              48.9 mm
 overlandflow:                       5.0 mm
 [infiltration:                     43.9 mm]
 verdunstung (bodensp.):             2.8 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -41.1 mm
 fehler:                             0.0 mm


 1.76380777  -> zufluss grundwasserleiter in  4542
TG:    4542 -> TG:    4543
Prozent:0.80

TG:    4542 -> TG:    4544
Prozent:0.20


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:            1.3 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:           3.3 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -2.0 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.395 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.395 qkm



 ISO: Normierungsfaktor   = 1.0001
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =          1977.634
niederschlag =     1977.633
flaeche zft  =        1.000
flaeche eing.=        0.395

GEBIET: Abflusswelle Interflow:

 ISO: Normierungsfaktor   = 1.0000
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.395

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV: Retentionskonstanten:   0.4       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =       1.00
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH =   90
ISOV:  fuellenberechnung
ISOV: Abflusz =          3077.044
ISOV: Niederschlag =     3077.043

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
ISOV: Retentionskonstanten:6000.0       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =   96602.20
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH = 2880
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1024

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4537

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    1.61

 gesamtmenge an niederschlag (mm):       57.5

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     19


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  0.900
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  2.700


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4537
 anzahl hydrotope:      19


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      57.5 mm
 interz.verd.:                       6.6 mm
 bestandsniederschlag:              48.9 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      16.1 mm
 aktuelle verdunstung:               9.4 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              48.9 mm
 overlandflow:                       5.0 mm
 [infiltration:                     43.9 mm]
 verdunstung (bodensp.):             2.7 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -41.1 mm
 fehler:                             0.0 mm


 4.11544704  -> zufluss grundwasserleiter in  4537
TG:    4537 -> TG:    4539
Prozent:0.90

TG:    4537 -> TG:    4543
Prozent:0.10


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:           19.4 mm
 abgabe basisabfluss:                  4.9 mm
        grundw. unterh.l.TG:          26.6 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:               -11.8 mm
     pot.entnahme GWS:               -11.8 mm
 speicherinhaltsaenderung:            -0.2 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.064 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.064 qkm



 ISO: Normierungsfaktor   = 1.0001
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =           318.379
niederschlag =      318.379
flaeche zft  =        1.000
flaeche eing.=        0.064

GEBIET: Abflusswelle Interflow:

 ISO: Normierungsfaktor   = 1.0000
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.064

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV: Retentionskonstanten:   0.5       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =       1.00
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH =  105
ISOV:  fuellenberechnung
ISOV: Abflusz =           508.741
ISOV: Niederschlag =      508.741

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
ISOV: Retentionskonstanten:6000.0       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =   96602.20
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH = 2880
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1025

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4543

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    1.61

 gesamtmenge an niederschlag (mm):       57.5

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     80


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  0.900
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  2.000


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4543
 anzahl hydrotope:      80


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      57.5 mm
 interz.verd.:                       6.6 mm
 bestandsniederschlag:              48.9 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      16.1 mm
 aktuelle verdunstung:               9.3 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              48.9 mm
 overlandflow:                       5.0 mm
 [infiltration:                     43.9 mm]
 verdunstung (bodensp.):             2.7 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -41.1 mm
 fehler:                             0.0 mm


 4.07773209  -> zufluss grundwasserleiter in  4543
TG:    4543 -> TG:    4544
Prozent:0.10

TG:    4543 -> TG:    4551
Prozent:0.50

TG:    4543 -> TG:    4549
Prozent:0.40


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:            1.3 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:           4.5 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -3.1 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.918 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.918 qkm



 ISO: Normierungsfaktor   = 1.0001
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =          4600.740
niederschlag =     4600.742
flaeche zft  =        1.000
flaeche eing.=        0.918

GEBIET: Abflusswelle Interflow:

 ISO: Normierungsfaktor   = 1.0000
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.918

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV: Retentionskonstanten:   0.4       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =       1.00
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH =   90
ISOV:  fuellenberechnung
ISOV: Abflusz =          8379.823
ISOV: Niederschlag =     8379.824

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
ISOV: Retentionskonstanten:6000.0       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =   96602.20
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH = 2880
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1026

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4549

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    1.61

 gesamtmenge an niederschlag (mm):       57.5

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     73


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  0.900
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  1.000


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4549
 anzahl hydrotope:      73


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      57.5 mm
 interz.verd.:                       6.6 mm
 bestandsniederschlag:              48.9 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      16.1 mm
 aktuelle verdunstung:               9.4 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              48.9 mm
 overlandflow:                       6.3 mm
 [infiltration:                     42.6 mm]
 verdunstung (bodensp.):             2.8 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -39.9 mm
 fehler:                             0.0 mm


 5.47681570  -> zufluss grundwasserleiter in  4549
TG:    4549 -> TG:    4551
Prozent:0.40

TG:    4549 -> TG:    4558
Prozent:0.60


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:            1.5 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:           6.1 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -4.6 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                1.076 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    1.076 qkm



 ISO: Normierungsfaktor   = 1.0001
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =          6725.417
niederschlag =     6725.430
flaeche zft  =        1.000
flaeche eing.=        1.076

GEBIET: Abflusswelle Interflow:

 ISO: Normierungsfaktor   = 1.0000
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        1.076

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV: Retentionskonstanten:   0.4       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =       1.00
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH =   86
ISOV:  fuellenberechnung
ISOV: Abflusz =          9363.565
ISOV: Niederschlag =     9363.553

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
ISOV: Retentionskonstanten:6000.0       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =   96602.20
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH = 2880
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1027

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4551

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    1.61

 gesamtmenge an niederschlag (mm):       57.5

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:    113


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  0.900
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  2.000


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4551
 anzahl hydrotope:     113


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      57.5 mm
 interz.verd.:                       6.6 mm
 bestandsniederschlag:              48.9 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      16.1 mm
 aktuelle verdunstung:               9.5 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              48.9 mm
 overlandflow:                      15.5 mm
 [infiltration:                     33.4 mm]
 verdunstung (bodensp.):             2.9 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -30.6 mm
 fehler:                             0.0 mm


 15.5802021  -> zufluss grundwasserleiter in  4551
TG:    4551 -> TG:    4553
Prozent:0.40

TG:    4551 -> TG:    4558
Prozent:0.30

TG:    4551 -> TG:    4552
Prozent:0.30


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:            7.3 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:          15.2 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -7.9 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.641 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.641 qkm



 ISO: Normierungsfaktor   = 1.0001
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =          9927.443
niederschlag =     9927.448
flaeche zft  =        1.000
flaeche eing.=        0.641

GEBIET: Abflusswelle Interflow:

 ISO: Normierungsfaktor   = 1.0000
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.641

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV: Retentionskonstanten:   0.4       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =       1.00
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH =   78
ISOV:  fuellenberechnung
ISOV: Abflusz =          5616.004
ISOV: Niederschlag =     5616.008

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
ISOV: Retentionskonstanten:6000.0       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =   96602.20
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH = 2880
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1028

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4552

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    1.61

 gesamtmenge an niederschlag (mm):       57.5

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     31


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  0.900
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  7.000


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4552
 anzahl hydrotope:      31


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      57.5 mm
 interz.verd.:                       6.6 mm
 bestandsniederschlag:              48.9 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      15.9 mm
 aktuelle verdunstung:               9.3 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              48.9 mm
 overlandflow:                      10.0 mm
 [infiltration:                     38.9 mm]
 verdunstung (bodensp.):             2.8 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -36.2 mm
 fehler:                             0.0 mm


 9.74566078  -> zufluss grundwasserleiter in  4552
TG:    4552 -> TG:    4553
Prozent:0.50

TG:    4552 -> TG:    4558
Prozent:0.50


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:           39.3 mm
 abgabe basisabfluss:                 17.6 mm
        grundw. unterh.l.TG:          22.5 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -1.0 mm
 fehler:                               0.2 mm


 flaechenanteile: 

   grundwasserleiter:                0.074 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.074 qkm



 ISO: Normierungsfaktor   = 1.0001
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =           743.007
niederschlag =      743.007
flaeche zft  =        1.000
flaeche eing.=        0.074

GEBIET: Abflusswelle Interflow:

 ISO: Normierungsfaktor   = 1.0000
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.074

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV: Retentionskonstanten:   0.2       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =       1.00
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH =   52
ISOV:  fuellenberechnung
ISOV: Abflusz =           968.510
ISOV: Niederschlag =      968.510

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
ISOV: Retentionskonstanten:6000.0       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =   96602.20
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH = 2880
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1029

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4553

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    1.61

 gesamtmenge an niederschlag (mm):       57.5

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     35


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  0.900
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 = 12.200


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4553
 anzahl hydrotope:      35


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      57.5 mm
 interz.verd.:                       6.6 mm
 bestandsniederschlag:              49.0 mm
 differenz interz.speicher:         -1.9 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      15.8 mm
 aktuelle verdunstung:               9.2 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              49.0 mm
 overlandflow:                       5.2 mm
 [infiltration:                     43.7 mm]
 verdunstung (bodensp.):             2.7 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -41.1 mm
 fehler:                             0.0 mm


 15.7821541  -> zufluss grundwasserleiter in  4553
TG:    4553 -> TG:    4558
Prozent:1.00


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:           78.5 mm
 abgabe basisabfluss:                 15.9 mm
        grundw. unterh.l.TG:          63.6 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -1.2 mm
 fehler:                               0.2 mm


 flaechenanteile: 

   grundwasserleiter:                0.060 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.060 qkm



 ISO: Normierungsfaktor   = 1.0001
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =           315.008
niederschlag =      315.009
flaeche zft  =        1.000
flaeche eing.=        0.060

GEBIET: Abflusswelle Interflow:

 ISO: Normierungsfaktor   = 1.0000
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.060

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV: Retentionskonstanten:   0.2       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =       1.00
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH =   36
ISOV:  fuellenberechnung
ISOV: Abflusz =           900.550
ISOV: Niederschlag =      900.550

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
ISOV: Retentionskonstanten:6000.0       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =   96602.20
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH = 2880
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1030

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4558

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    1.61

 gesamtmenge an niederschlag (mm):       57.5

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     90


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  0.900
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 = 10.000


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4558
 anzahl hydrotope:      90


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      57.5 mm
 interz.verd.:                       6.6 mm
 bestandsniederschlag:              48.9 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      15.9 mm
 aktuelle verdunstung:               9.8 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              48.9 mm
 overlandflow:                      18.3 mm
 [infiltration:                     30.6 mm]
 verdunstung (bodensp.):             3.2 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -27.4 mm
 fehler:                             0.0 mm


 38.4231071  -> zufluss grundwasserleiter in  4558
TG:    4558 -> TG:    4561
Prozent:0.50

TG:    4558 -> TG:    4564
Prozent:0.50


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:           28.8 mm
 abgabe basisabfluss:                  2.8 mm
        grundw. unterh.l.TG:          27.7 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -1.7 mm
 fehler:                               0.1 mm


 flaechenanteile: 

   grundwasserleiter:                0.400 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.400 qkm



 ISO: Normierungsfaktor   = 1.0001
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =          7303.674
niederschlag =     7303.669
flaeche zft  =        1.000
flaeche eing.=        0.400

GEBIET: Abflusswelle Interflow:

 ISO: Normierungsfaktor   = 1.0000
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.400

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV: Retentionskonstanten:   0.1       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =       1.00
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH =   32
ISOV:  fuellenberechnung
ISOV: Abflusz =          2743.397
ISOV: Niederschlag =     2743.399

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
ISOV: Retentionskonstanten:6000.0       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =   96602.20
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH = 2880
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1031

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4533

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    1.61

 gesamtmenge an niederschlag (mm):       57.5

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     26


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  0.900
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  0.500


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4533
 anzahl hydrotope:      26


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      57.5 mm
 interz.verd.:                       6.6 mm
 bestandsniederschlag:              48.9 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      16.1 mm
 aktuelle verdunstung:               9.3 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              48.9 mm
 overlandflow:                       5.0 mm
 [infiltration:                     43.9 mm]
 verdunstung (bodensp.):             2.7 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -41.2 mm
 fehler:                             0.0 mm


 entnahme gws [qbm/s]:       0.000
 0.00000000E+00  -> zufluss grundwasserleiter in  4533
TG:    4533 -> TG:    4535
Prozent:1.00


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:            0.0 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:           3.5 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.2 mm
     pot.entnahme GWS:                 0.2 mm
 speicherinhaltsaenderung:            -3.6 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.211 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.211 qkm



 ISO: Normierungsfaktor   = 1.0002
 ISO: Summe normierter uh =   1.0000


 Anzahl der Zeitschritte in iso durch Nachlauf zu hoch geworden.
 Sie wird auf 460 begrenzt !  gebiet :  4533

fuellenberechnung in iso
abflusz =          1053.413
niederschlag =     1055.236
flaeche zft  =        1.000
flaeche eing.=        0.211

GEBIET: Abflusswelle Interflow:

 ISO: Normierungsfaktor   = 1.0000
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.211

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV: Retentionskonstanten:   1.5       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =       1.00
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH =  291
ISOV:  fuellenberechnung
ISOV: Abflusz =          2106.832
ISOV: Niederschlag =     2106.831

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
ISOV: Retentionskonstanten:6000.0       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =   96602.20
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH = 2880
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1032

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4535

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    1.61

 gesamtmenge an niederschlag (mm):       57.5

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     16


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  0.900
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  2.500


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4535
 anzahl hydrotope:      16


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      57.5 mm
 interz.verd.:                       6.8 mm
 bestandsniederschlag:              48.5 mm
 differenz interz.speicher:         -2.2 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      16.2 mm
 aktuelle verdunstung:               9.6 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              48.5 mm
 overlandflow:                       5.0 mm
 [infiltration:                     43.5 mm]
 verdunstung (bodensp.):             2.8 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -40.7 mm
 fehler:                             0.0 mm


 8.30385113  -> zufluss grundwasserleiter in  4535
TG:    4535 -> TG:    4539
Prozent:1.00


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:            9.4 mm
 abgabe basisabfluss:                  3.9 mm
        grundw. unterh.l.TG:           5.9 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -0.5 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.266 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.266 qkm



 ISO: Normierungsfaktor   = 1.0001
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =          1338.976
niederschlag =     1338.977
flaeche zft  =        1.000
flaeche eing.=        0.266

GEBIET: Abflusswelle Interflow:

 ISO: Normierungsfaktor   = 1.0000
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.266

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV: Retentionskonstanten:   0.5       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =       1.00
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH =  105
ISOV:  fuellenberechnung
ISOV: Abflusz =           811.575
ISOV: Niederschlag =      811.575

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
ISOV: Retentionskonstanten:6000.0       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =   96602.20
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH = 2880
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1033

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4539

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    1.61

 gesamtmenge an niederschlag (mm):       57.5

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     66


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  0.900
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  8.000


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4539
 anzahl hydrotope:      66


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      57.5 mm
 interz.verd.:                       7.4 mm
 bestandsniederschlag:              47.2 mm
 differenz interz.speicher:         -2.9 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      16.4 mm
 aktuelle verdunstung:              10.0 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              47.2 mm
 overlandflow:                       5.0 mm
 [infiltration:                     42.2 mm]
 verdunstung (bodensp.):             2.6 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -39.5 mm
 fehler:                             0.0 mm


 entnahme gws [qbm/s]:       0.001
 10.3070755  -> zufluss grundwasserleiter in  4539
TG:    4539 -> TG:    4541
Prozent:0.70

TG:    4539 -> TG:    4547
Prozent:0.10

TG:    4539 -> TG:    4554
Prozent:0.20


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:            1.1 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:           5.2 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.1 mm
     pot.entnahme GWS:                 0.1 mm
 speicherinhaltsaenderung:            -4.3 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                2.864 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    2.864 qkm



 ISO: Normierungsfaktor   = 1.0001
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =         14457.018
niederschlag =    14457.040
flaeche zft  =        1.000
flaeche eing.=        2.864

GEBIET: Abflusswelle Interflow:

 ISO: Normierungsfaktor   = 1.0000
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        2.864

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV: Retentionskonstanten:   0.5       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =       1.00
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH =   95
ISOV:  fuellenberechnung
ISOV: Abflusz =         14826.180
ISOV: Niederschlag =    14826.167

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
ISOV: Retentionskonstanten:6000.0       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =   96602.20
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH = 2880
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1034

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4541

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    1.61

 gesamtmenge an niederschlag (mm):       57.5

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     46


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  0.900
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  5.000


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4541
 anzahl hydrotope:      46


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      57.5 mm
 interz.verd.:                       7.0 mm
 bestandsniederschlag:              48.1 mm
 differenz interz.speicher:         -2.4 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      16.1 mm
 aktuelle verdunstung:               9.9 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              48.1 mm
 overlandflow:                       9.3 mm
 [infiltration:                     38.8 mm]
 verdunstung (bodensp.):             2.9 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -35.9 mm
 fehler:                             0.0 mm


 34.7793770  -> zufluss grundwasserleiter in  4541
TG:    4541 -> TG:    4548
Prozent:0.20

TG:    4541 -> TG:    4554
Prozent:0.15

TG:    4541 -> TG:    4556
Prozent:0.65


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:           26.0 mm
 abgabe basisabfluss:                  3.6 mm
        grundw. unterh.l.TG:          22.9 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -0.5 mm
 fehler:                               0.1 mm


 flaechenanteile: 

   grundwasserleiter:                0.401 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.401 qkm



 ISO: Normierungsfaktor   = 1.0001
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =          3721.262
niederschlag =     3721.266
flaeche zft  =        1.000
flaeche eing.=        0.401

GEBIET: Abflusswelle Interflow:

 ISO: Normierungsfaktor   = 1.0000
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.401

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV: Retentionskonstanten:   0.3       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =       1.00
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH =   56
ISOV:  fuellenberechnung
ISOV: Abflusz =          4233.113
ISOV: Niederschlag =     4233.111

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
ISOV: Retentionskonstanten:6000.0       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =   96602.20
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH = 2880
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1035

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4547

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    1.61

 gesamtmenge an niederschlag (mm):       57.5

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     38


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  0.900
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  2.750


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4547
 anzahl hydrotope:      38


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      57.5 mm
 interz.verd.:                       6.6 mm
 bestandsniederschlag:              48.8 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      16.3 mm
 aktuelle verdunstung:              10.7 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              48.8 mm
 overlandflow:                      23.5 mm
 [infiltration:                     25.3 mm]
 verdunstung (bodensp.):             4.1 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -21.2 mm
 fehler:                             0.0 mm


 4.96848679  -> zufluss grundwasserleiter in  4547
TG:    4547 -> TG:    4548
Prozent:1.00


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:           13.2 mm
 abgabe basisabfluss:                  8.1 mm
        grundw. unterh.l.TG:          17.6 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:               -12.4 mm
     pot.entnahme GWS:               -12.4 mm
 speicherinhaltsaenderung:             0.0 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.113 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.113 qkm



 ISO: Normierungsfaktor   = 1.0001
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =          2648.390
niederschlag =     2648.393
flaeche zft  =        1.000
flaeche eing.=        0.113

GEBIET: Abflusswelle Interflow:

 ISO: Normierungsfaktor   = 1.0000
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.113

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV: Retentionskonstanten:   0.1       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =       1.00
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH =   26
ISOV:  fuellenberechnung
ISOV: Abflusz =          1679.846
ISOV: Niederschlag =     1679.846

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
ISOV: Retentionskonstanten:6000.0       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =   96602.20
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH = 2880
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1036

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4544

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    1.61

 gesamtmenge an niederschlag (mm):       57.5

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     49


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  0.900
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  2.000


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4544
 anzahl hydrotope:      49


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      57.5 mm
 interz.verd.:                       6.6 mm
 bestandsniederschlag:              48.9 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      16.2 mm
 aktuelle verdunstung:               9.6 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              48.9 mm
 overlandflow:                       8.2 mm
 [infiltration:                     40.7 mm]
 verdunstung (bodensp.):             3.0 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -37.7 mm
 fehler:                             0.0 mm


 2.24781537  -> zufluss grundwasserleiter in  4544
TG:    4544 -> TG:    4546
Prozent:1.00


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:            1.8 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:           4.9 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                -0.7 mm
     pot.entnahme GWS:                -0.7 mm
 speicherinhaltsaenderung:            -2.5 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.385 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.385 qkm



 ISO: Normierungsfaktor   = 1.0001
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =          3145.497
niederschlag =     3145.501
flaeche zft  =        1.000
flaeche eing.=        0.385

GEBIET: Abflusswelle Interflow:

 ISO: Normierungsfaktor   = 1.0000
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.385

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV: Retentionskonstanten:   0.3       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =       1.00
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH =   68
ISOV:  fuellenberechnung
ISOV: Abflusz =          3543.802
ISOV: Niederschlag =     3543.802

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
ISOV: Retentionskonstanten:6000.0       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =   96602.20
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH = 2880
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1037

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4546

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    1.61

 gesamtmenge an niederschlag (mm):       57.5

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     67


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  0.900
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  2.250


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4546
 anzahl hydrotope:      67


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      57.5 mm
 interz.verd.:                       6.6 mm
 bestandsniederschlag:              48.9 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      16.2 mm
 aktuelle verdunstung:               9.9 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              48.9 mm
 overlandflow:                      17.5 mm
 [infiltration:                     31.3 mm]
 verdunstung (bodensp.):             3.2 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -28.1 mm
 fehler:                             0.0 mm


 6.31676960  -> zufluss grundwasserleiter in  4546
TG:    4546 -> TG:    4548
Prozent:1.00


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:            8.8 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:          12.8 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -4.0 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.216 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.216 qkm



 ISO: Normierungsfaktor   = 1.0001
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =          3780.653
niederschlag =     3780.655
flaeche zft  =        1.000
flaeche eing.=        0.216

GEBIET: Abflusswelle Interflow:

 ISO: Normierungsfaktor   = 1.0000
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.216

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV: Retentionskonstanten:   0.2       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =       1.00
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH =   48
ISOV:  fuellenberechnung
ISOV: Abflusz =          1902.627
ISOV: Niederschlag =     1902.627

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
ISOV: Retentionskonstanten:6000.0       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =   96602.20
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH = 2880
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1038

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4548

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    1.61

 gesamtmenge an niederschlag (mm):       57.5

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:    125


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  0.900
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  2.000


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4548
 anzahl hydrotope:     125


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      57.5 mm
 interz.verd.:                       6.6 mm
 bestandsniederschlag:              48.9 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      16.2 mm
 aktuelle verdunstung:               9.8 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              48.9 mm
 overlandflow:                      11.6 mm
 [infiltration:                     37.2 mm]
 verdunstung (bodensp.):             3.1 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -34.1 mm
 fehler:                             0.0 mm


 21.9350929  -> zufluss grundwasserleiter in  4548
TG:    4548 -> TG:    4556
Prozent:0.50

TG:    4548 -> TG:    4559
Prozent:0.50


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:           13.6 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:          17.9 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -4.3 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.483 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.483 qkm



 ISO: Normierungsfaktor   = 1.0001
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =          5616.332
niederschlag =     5616.334
flaeche zft  =        1.000
flaeche eing.=        0.483

GEBIET: Abflusswelle Interflow:

 ISO: Normierungsfaktor   = 1.0000
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.483

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV: Retentionskonstanten:   0.2       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =       1.00
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH =   44
ISOV:  fuellenberechnung
ISOV: Abflusz =          4357.996
ISOV: Niederschlag =     4357.999

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
ISOV: Retentionskonstanten:6000.0       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =   96602.20
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH = 2880
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1039

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4554

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    1.61

 gesamtmenge an niederschlag (mm):       57.5

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     34


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  0.900
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  3.000


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4554
 anzahl hydrotope:      34


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      57.5 mm
 interz.verd.:                       6.7 mm
 bestandsniederschlag:              48.7 mm
 differenz interz.speicher:         -2.1 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      15.7 mm
 aktuelle verdunstung:               9.3 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              48.7 mm
 overlandflow:                       5.0 mm
 [infiltration:                     43.7 mm]
 verdunstung (bodensp.):             2.6 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -41.1 mm
 fehler:                             0.0 mm


 14.5307360  -> zufluss grundwasserleiter in  4554
TG:    4554 -> TG:    4556
Prozent:0.50

TG:    4554 -> TG:    4559
Prozent:0.50


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:            8.0 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:          12.4 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -4.4 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.547 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.547 qkm



 ISO: Normierungsfaktor   = 1.0000
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =          2736.272
niederschlag =     2736.274
flaeche zft  =        1.000
flaeche eing.=        0.547

GEBIET: Abflusswelle Interflow:

 ISO: Normierungsfaktor   = 1.0001
 ISO: Summe normierter uh =   1.0000


 Anzahl der Zeitschritte in iso durch Nachlauf zu hoch geworden.
 Sie wird auf 460 begrenzt !  gebiet :  4554

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.547

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV: Retentionskonstanten:   0.3       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =       1.00
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH =   62
ISOV:  fuellenberechnung
ISOV: Abflusz =          8069.546
ISOV: Niederschlag =     8069.540

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
ISOV: Retentionskonstanten:6000.0       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =   96602.20
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH = 2880
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1040

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4556

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    1.61

 gesamtmenge an niederschlag (mm):       57.5

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:    105


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  0.900
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 = 12.000


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4556
 anzahl hydrotope:     105


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      57.5 mm
 interz.verd.:                       6.6 mm
 bestandsniederschlag:              48.9 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      16.0 mm
 aktuelle verdunstung:               9.3 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              48.9 mm
 overlandflow:                       5.3 mm
 [infiltration:                     43.6 mm]
 verdunstung (bodensp.):             2.7 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -40.9 mm
 fehler:                             0.0 mm


 45.5907516  -> zufluss grundwasserleiter in  4556
TG:    4556 -> TG:    4559
Prozent:1.00


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:           15.1 mm
 abgabe basisabfluss:                  3.5 mm
        grundw. unterh.l.TG:          12.9 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                -0.6 mm
     pot.entnahme GWS:                -0.6 mm
 speicherinhaltsaenderung:            -0.9 mm
 fehler:                               0.2 mm


 flaechenanteile: 

   grundwasserleiter:                0.904 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.904 qkm



 ISO: Normierungsfaktor   = 1.0001
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =          4804.465
niederschlag =     4804.474
flaeche zft  =        1.000
flaeche eing.=        0.904

GEBIET: Abflusswelle Interflow:

 ISO: Normierungsfaktor   = 1.0000
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.904

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV: Retentionskonstanten:   0.6       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =       1.00
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH =  112
ISOV:  fuellenberechnung
ISOV: Abflusz =         11505.096
ISOV: Niederschlag =    11505.102

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
ISOV: Retentionskonstanten:6000.0       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =   96602.20
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH = 2880
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1041

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4559

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    1.61

 gesamtmenge an niederschlag (mm):       57.5

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:    121


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  0.900
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  4.000


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4559
 anzahl hydrotope:     121


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      57.5 mm
 interz.verd.:                       6.6 mm
 bestandsniederschlag:              48.9 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      15.9 mm
 aktuelle verdunstung:               9.4 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              48.9 mm
 overlandflow:                      12.4 mm
 [infiltration:                     36.5 mm]
 verdunstung (bodensp.):             2.8 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -33.7 mm
 fehler:                             0.0 mm


 64.6178284  -> zufluss grundwasserleiter in  4559
TG:    4559 -> TG:    4560
Prozent:0.10

TG:    4559 -> TG:    4564
Prozent:0.60

TG:    4559 -> TG:    4589
Prozent:0.30


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:           27.0 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:          34.1 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                -1.6 mm
     pot.entnahme GWS:                -1.6 mm
 speicherinhaltsaenderung:            -5.5 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.718 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.718 qkm



 ISO: Normierungsfaktor   = 1.0001
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =          8882.797
niederschlag =     8882.809
flaeche zft  =        1.000
flaeche eing.=        0.718

GEBIET: Abflusswelle Interflow:

 ISO: Normierungsfaktor   = 1.0000
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.718

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV: Retentionskonstanten:   0.5       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =       1.00
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH =  105
ISOV:  fuellenberechnung
ISOV: Abflusz =          7546.737
ISOV: Niederschlag =     7546.730

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
ISOV: Retentionskonstanten:6000.0       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =   96602.20
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH = 2880
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1042

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4560

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    1.61

 gesamtmenge an niederschlag (mm):       57.5

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:      4


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  0.900
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  7.500


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4560
 anzahl hydrotope:       4


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      57.5 mm
 interz.verd.:                       6.2 mm
 bestandsniederschlag:              49.5 mm
 differenz interz.speicher:         -1.7 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      13.5 mm
 aktuelle verdunstung:               8.1 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              49.5 mm
 overlandflow:                       4.9 mm
 [infiltration:                     44.6 mm]
 verdunstung (bodensp.):             1.9 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -42.7 mm
 fehler:                             0.0 mm


 8.15345573  -> zufluss grundwasserleiter in  4560
TG:    4560 -> TG:    4564
Prozent:1.00


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:           71.8 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:          79.7 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -7.9 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.034 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.034 qkm



 ISO: Normierungsfaktor   = 1.0001
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =           168.550
niederschlag =      168.550
flaeche zft  =        1.000
flaeche eing.=        0.034

GEBIET: Abflusswelle Interflow:

 ISO: Normierungsfaktor   = 1.0000
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.034

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV: Retentionskonstanten:   0.5       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =       1.00
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH =  105
ISOV:  fuellenberechnung
ISOV: Abflusz =           888.594
ISOV: Niederschlag =      888.594

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
ISOV: Retentionskonstanten:6000.0       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =   96602.20
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH = 2880
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1043

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4561

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    1.61

 gesamtmenge an niederschlag (mm):       57.5

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     28


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  0.900
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  6.300


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4561
 anzahl hydrotope:      28


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      57.5 mm
 interz.verd.:                       6.2 mm
 bestandsniederschlag:              49.4 mm
 differenz interz.speicher:         -1.8 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      13.8 mm
 aktuelle verdunstung:               8.8 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              49.4 mm
 overlandflow:                      22.0 mm
 [infiltration:                     27.5 mm]
 verdunstung (bodensp.):             2.5 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -24.9 mm
 fehler:                             0.0 mm


 18.4201660  -> zufluss grundwasserleiter in  4561
TG:    4561 -> TG:    4564
Prozent:0.90

TG:    4561 -> TG:    4565
Prozent:0.10


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:          101.7 mm
 abgabe basisabfluss:                 67.5 mm
        grundw. unterh.l.TG:          34.4 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -0.4 mm
 fehler:                               0.1 mm


 flaechenanteile: 

   grundwasserleiter:                0.054 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.054 qkm



 ISO: Normierungsfaktor   = 1.0001
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =          1193.680
niederschlag =     1193.681
flaeche zft  =        1.000
flaeche eing.=        0.054

GEBIET: Abflusswelle Interflow:

 ISO: Normierungsfaktor   = 1.0000
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.054

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV: Retentionskonstanten:   0.5       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =       1.00
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH =  105
ISOV:  fuellenberechnung
ISOV: Abflusz =          1261.276
ISOV: Niederschlag =     1261.275

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
ISOV: Retentionskonstanten:6000.0       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =   96602.20
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH = 2880
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1044

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4529

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    1.61

 gesamtmenge an niederschlag (mm):       57.5

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     23


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  3.000


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4529
 anzahl hydrotope:      23


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      57.5 mm
 interz.verd.:                       6.3 mm
 bestandsniederschlag:              49.3 mm
 differenz interz.speicher:         -1.8 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      13.8 mm
 aktuelle verdunstung:               9.0 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              49.3 mm
 overlandflow:                       0.5 mm
 [infiltration:                     48.8 mm]
 verdunstung (bodensp.):             2.7 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -46.0 mm
 fehler:                             0.0 mm


 5.56225872  -> zufluss grundwasserleiter in  4529
TG:    4529 -> TG:    4563
Prozent:1.00


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:           25.2 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:          26.5 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -1.3 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.066 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.066 qkm



 ISO: Normierungsfaktor   = 1.0002
 ISO: Summe normierter uh =   1.0000


 Anzahl der Zeitschritte in iso durch Nachlauf zu hoch geworden.
 Sie wird auf 460 begrenzt !  gebiet :  4529

fuellenberechnung in iso
abflusz =            35.197
niederschlag =       35.258
flaeche zft  =        1.000
flaeche eing.=        0.066

GEBIET: Abflusswelle Interflow:

 ISO: Normierungsfaktor   = 1.0000
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.066

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV: Retentionskonstanten:   0.6       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =       1.00
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH =  125
ISOV:  fuellenberechnung
ISOV: Abflusz =          1536.245
ISOV: Niederschlag =     1536.245

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
ISOV: Retentionskonstanten:6000.0       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =   96602.20
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH = 2880
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1045

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4563

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    1.61

 gesamtmenge an niederschlag (mm):       57.5

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     28


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  4.000


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4563
 anzahl hydrotope:      28


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      57.5 mm
 interz.verd.:                       6.8 mm
 bestandsniederschlag:              48.4 mm
 differenz interz.speicher:         -2.2 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      15.8 mm
 aktuelle verdunstung:              11.1 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              48.4 mm
 overlandflow:                       0.8 mm
 [infiltration:                     47.7 mm]
 verdunstung (bodensp.):             4.3 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -43.3 mm
 fehler:                             0.0 mm


 22.5295734  -> zufluss grundwasserleiter in  4563
TG:    4563 -> TG:    4564
Prozent:0.30

TG:    4563 -> TG:    4565
Prozent:0.70


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:           48.1 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:          49.8 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -1.8 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.141 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.141 qkm



 ISO: Normierungsfaktor   = 1.0002
 ISO: Summe normierter uh =   1.0000


 Anzahl der Zeitschritte in iso durch Nachlauf zu hoch geworden.
 Sie wird auf 460 begrenzt !  gebiet :  4563

fuellenberechnung in iso
abflusz =           106.414
niederschlag =      106.598
flaeche zft  =        1.000
flaeche eing.=        0.141

GEBIET: Abflusswelle Interflow:

 ISO: Normierungsfaktor   = 1.0000
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.141

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV: Retentionskonstanten:   1.4       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =       1.00
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH =  264
ISOV:  fuellenberechnung
ISOV: Abflusz =           610.682
ISOV: Niederschlag =      610.682

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
ISOV: Retentionskonstanten:6000.0       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =   96602.20
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH = 2880
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1046

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4564

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    1.61

 gesamtmenge an niederschlag (mm):       57.5

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:    108


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  8.500


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4564
 anzahl hydrotope:     108


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      57.5 mm
 interz.verd.:                       6.6 mm
 bestandsniederschlag:              48.9 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      16.0 mm
 aktuelle verdunstung:              10.5 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              48.9 mm
 overlandflow:                       0.5 mm
 [infiltration:                     48.4 mm]
 verdunstung (bodensp.):             3.8 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -44.6 mm
 fehler:                             0.0 mm


 89.0153732  -> zufluss grundwasserleiter in  4564
TG:    4564 -> TG:    4565
Prozent:0.40

TG:    4564 -> TG:    4566
Prozent:0.40

TG:    4564 -> TG:    4571
Prozent:0.20


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:           34.5 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:          35.5 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -1.0 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.773 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.773 qkm



 ISO: Normierungsfaktor   = 1.0002
 ISO: Summe normierter uh =   1.0000


 Anzahl der Zeitschritte in iso durch Nachlauf zu hoch geworden.
 Sie wird auf 460 begrenzt !  gebiet :  4564

fuellenberechnung in iso
abflusz =           358.321
niederschlag =      358.941
flaeche zft  =        1.000
flaeche eing.=        0.773

GEBIET: Abflusswelle Interflow:

 ISO: Normierungsfaktor   = 1.0000
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.773

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV: Retentionskonstanten:   1.4       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =       1.00
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH =  264
ISOV:  fuellenberechnung
ISOV: Abflusz =          6816.178
ISOV: Niederschlag =     6816.172

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
ISOV: Retentionskonstanten:6000.0       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =   96602.20
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH = 2880
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1047

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4562

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    1.61

 gesamtmenge an niederschlag (mm):       57.5

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:      7


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  0.900
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  3.500


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4562
 anzahl hydrotope:       7


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      57.5 mm
 interz.verd.:                       6.6 mm
 bestandsniederschlag:              48.9 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      15.5 mm
 aktuelle verdunstung:              10.9 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              48.9 mm
 overlandflow:                      28.9 mm
 [infiltration:                     20.0 mm]
 verdunstung (bodensp.):             4.3 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -15.7 mm
 fehler:                             0.0 mm


 0.00000000E+00  -> zufluss grundwasserleiter in  4562
TG:    4562 -> TG:    4565
Prozent:0.10


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:            0.0 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:           2.2 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -2.2 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.081 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.081 qkm



 ISO: Normierungsfaktor   = 1.0001
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =          2323.941
niederschlag =     2323.941
flaeche zft  =        1.000
flaeche eing.=        0.081

GEBIET: Abflusswelle Interflow:

 ISO: Normierungsfaktor   = 1.0000
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.081

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV: Retentionskonstanten:   0.3       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =       1.00
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH =   68
ISOV:  fuellenberechnung
ISOV: Abflusz =             4.000
ISOV: Niederschlag =        4.000

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
ISOV: Retentionskonstanten:6000.0       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =   96602.20
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH = 2880
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1048

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4565

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    1.61

 gesamtmenge an niederschlag (mm):       57.5

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     14


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  8.000


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4565
 anzahl hydrotope:      14


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      57.5 mm
 interz.verd.:                       7.9 mm
 bestandsniederschlag:              45.9 mm
 differenz interz.speicher:         -3.6 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      16.4 mm
 aktuelle verdunstung:              11.3 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              45.9 mm
 overlandflow:                       0.8 mm
 [infiltration:                     45.2 mm]
 verdunstung (bodensp.):             3.4 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -41.8 mm
 fehler:                             0.0 mm


 68.4345322  -> zufluss grundwasserleiter in  4565
TG:    4565 -> TG:    4566
Prozent:1.00


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:          121.8 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:         125.2 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -3.4 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.169 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.169 qkm



 ISO: Normierungsfaktor   = 1.0002
 ISO: Summe normierter uh =   1.0000


 Anzahl der Zeitschritte in iso durch Nachlauf zu hoch geworden.
 Sie wird auf 460 begrenzt !  gebiet :  4565

fuellenberechnung in iso
abflusz =           127.353
niederschlag =      127.574
flaeche zft  =        1.000
flaeche eing.=        0.169

GEBIET: Abflusswelle Interflow:

 ISO: Normierungsfaktor   = 1.0000
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.169

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV: Retentionskonstanten:   2.8       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =       1.00
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH =  500
ISOV:  fuellenberechnung
ISOV: Abflusz =           106.815
ISOV: Niederschlag =      106.815

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
ISOV: Retentionskonstanten:6000.0       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =   96602.20
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH = 2880
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1049

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4566

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    1.61

 gesamtmenge an niederschlag (mm):       57.5

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     54


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 = 14.500


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4566
 anzahl hydrotope:      54


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      57.5 mm
 interz.verd.:                       7.1 mm
 bestandsniederschlag:              47.9 mm
 differenz interz.speicher:         -2.5 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      16.3 mm
 aktuelle verdunstung:              10.7 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              47.9 mm
 overlandflow:                       0.6 mm
 [infiltration:                     47.3 mm]
 verdunstung (bodensp.):             3.6 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -43.7 mm
 fehler:                             0.0 mm


 140.165955  -> zufluss grundwasserleiter in  4566
TG:    4566 -> TG:    4567
Prozent:0.30

TG:    4566 -> TG:    4580
Prozent:0.50

TG:    4566 -> TG:    4587
Prozent:0.20


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:           46.0 mm
 abgabe basisabfluss:                 23.1 mm
        grundw. unterh.l.TG:          23.0 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -0.2 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.914 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.914 qkm



 ISO: Normierungsfaktor   = 1.0002
 ISO: Summe normierter uh =   1.0000


 Anzahl der Zeitschritte in iso durch Nachlauf zu hoch geworden.
 Sie wird auf 460 begrenzt !  gebiet :  4566

fuellenberechnung in iso
abflusz =           519.643
niederschlag =      520.542
flaeche zft  =        1.000
flaeche eing.=        0.914

GEBIET: Abflusswelle Interflow:

 ISO: Normierungsfaktor   = 1.0000
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.914

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV: Retentionskonstanten:   2.8       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =       1.00
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH =  500
ISOV:  fuellenberechnung
ISOV: Abflusz =          1406.713
ISOV: Niederschlag =     1406.716

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
ISOV: Retentionskonstanten:6000.0       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =   96602.20
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH = 2880
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1050

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4571

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    1.61

 gesamtmenge an niederschlag (mm):       57.5

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     21


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  1.000


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4571
 anzahl hydrotope:      21


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      57.5 mm
 interz.verd.:                       6.7 mm
 bestandsniederschlag:              48.8 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      16.3 mm
 aktuelle verdunstung:              10.8 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              48.8 mm
 overlandflow:                       0.5 mm
 [infiltration:                     48.3 mm]
 verdunstung (bodensp.):             4.1 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -44.1 mm
 fehler:                             0.0 mm


 18.3173828  -> zufluss grundwasserleiter in  4571
TG:    4571 -> TG:    4573
Prozent:0.20

TG:    4571 -> TG:    4580
Prozent:0.80


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:           34.5 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:          34.7 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -0.2 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.160 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.160 qkm



 ISO: Normierungsfaktor   = 1.0001
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =            87.492
niederschlag =       87.492
flaeche zft  =        1.000
flaeche eing.=        0.160

GEBIET: Abflusswelle Interflow:

 ISO: Normierungsfaktor   = 1.0000
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.160

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV: Retentionskonstanten:   0.7       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =       1.00
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH =  148
ISOV:  fuellenberechnung
ISOV: Abflusz =          1054.038
ISOV: Niederschlag =     1054.036

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
ISOV: Retentionskonstanten:1455.0       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =    1512.20
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH = 2880
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1051

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4589

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    1.61

 gesamtmenge an niederschlag (mm):       57.5

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     99


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  1.000


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4589
 anzahl hydrotope:      99


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      57.5 mm
 interz.verd.:                       6.6 mm
 bestandsniederschlag:              48.9 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      16.1 mm
 aktuelle verdunstung:              10.0 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              48.9 mm
 overlandflow:                       0.4 mm
 [infiltration:                     48.5 mm]
 verdunstung (bodensp.):             3.4 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -45.1 mm
 fehler:                             0.0 mm


 24.4603634  -> zufluss grundwasserleiter in  4589
TG:    4589 -> TG:    4572
Prozent:0.20

TG:    4589 -> TG:    4593
Prozent:0.80


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:           13.6 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:          16.6 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                -2.5 mm
     pot.entnahme GWS:                -2.5 mm
 speicherinhaltsaenderung:            -0.5 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.541 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.541 qkm



 ISO: Normierungsfaktor   = 1.0002
 ISO: Summe normierter uh =   1.0000


 Anzahl der Zeitschritte in iso durch Nachlauf zu hoch geworden.
 Sie wird auf 460 begrenzt !  gebiet :  4589

fuellenberechnung in iso
abflusz =           214.219
niederschlag =      214.590
flaeche zft  =        1.000
flaeche eing.=        0.541

GEBIET: Abflusswelle Interflow:

 ISO: Normierungsfaktor   = 1.0000
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.541

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV: Retentionskonstanten:   1.4       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =       1.00
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH =  264
ISOV:  fuellenberechnung
ISOV: Abflusz =          4574.844
ISOV: Niederschlag =     4574.847

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
ISOV: Retentionskonstanten:6000.0       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =   96602.20
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH = 2880
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1052

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4572

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    1.61

 gesamtmenge an niederschlag (mm):       57.5

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     35


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  1.000


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4572
 anzahl hydrotope:      35


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      57.5 mm
 interz.verd.:                       6.6 mm
 bestandsniederschlag:              48.8 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      16.2 mm
 aktuelle verdunstung:              10.3 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              48.8 mm
 overlandflow:                       0.4 mm
 [infiltration:                     48.4 mm]
 verdunstung (bodensp.):             3.7 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -44.7 mm
 fehler:                             0.0 mm


 6.00380278  -> zufluss grundwasserleiter in  4572
TG:    4572 -> TG:    4574
Prozent:0.50

TG:    4572 -> TG:    4573
Prozent:0.50


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:            6.6 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:           6.8 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -0.2 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.275 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.275 qkm



 ISO: Normierungsfaktor   = 1.0001
 ISO: Summe normierter uh =   1.0000


 Anzahl der Zeitschritte in iso durch Nachlauf zu hoch geworden.
 Sie wird auf 460 begrenzt !  gebiet :  4572

fuellenberechnung in iso
abflusz =           121.762
niederschlag =      121.762
flaeche zft  =        1.000
flaeche eing.=        0.275

GEBIET: Abflusswelle Interflow:

 ISO: Normierungsfaktor   = 1.0000
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.275

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV: Retentionskonstanten:   1.6       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =       1.00
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH =  299
ISOV:  fuellenberechnung
ISOV: Abflusz =          1274.286
ISOV: Niederschlag =     1274.288

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
ISOV: Retentionskonstanten:3273.0       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =   16076.66
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH = 2880
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1053

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4573

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    1.61

 gesamtmenge an niederschlag (mm):       57.5

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     21


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  1.000


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4573
 anzahl hydrotope:      21


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      57.5 mm
 interz.verd.:                       6.6 mm
 bestandsniederschlag:              48.9 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      16.2 mm
 aktuelle verdunstung:              11.6 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              48.9 mm
 overlandflow:                       0.7 mm
 [infiltration:                     48.2 mm]
 verdunstung (bodensp.):             4.9 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -43.3 mm
 fehler:                             0.0 mm


 6.77878523  -> zufluss grundwasserleiter in  4573
TG:    4573 -> TG:    4576
Prozent:0.50

TG:    4573 -> TG:    4578
Prozent:0.50


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:           22.4 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:          23.0 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -0.6 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.091 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.091 qkm



 ISO: Normierungsfaktor   = 1.0001
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =            62.022
niederschlag =       62.022
flaeche zft  =        1.000
flaeche eing.=        0.091

GEBIET: Abflusswelle Interflow:

 ISO: Normierungsfaktor   = 1.0000
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.091

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV: Retentionskonstanten:   0.7       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =       1.00
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH =  142
ISOV:  fuellenberechnung
ISOV: Abflusz =           664.940
ISOV: Niederschlag =      664.940

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
ISOV: Retentionskonstanten:1382.0       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =    1304.24
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH = 2880
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1054

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4576

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    1.61

 gesamtmenge an niederschlag (mm):       57.5

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     12


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  1.000


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4576
 anzahl hydrotope:      12


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      57.5 mm
 interz.verd.:                       6.6 mm
 bestandsniederschlag:              48.9 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      16.0 mm
 aktuelle verdunstung:              11.6 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              48.9 mm
 overlandflow:                       0.7 mm
 [infiltration:                     48.1 mm]
 verdunstung (bodensp.):             4.9 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -43.2 mm
 fehler:                             0.0 mm


 3.47443843  -> zufluss grundwasserleiter in  4576
TG:    4576 -> TG:    4578
Prozent:0.80

TG:    4576 -> TG:    4579
Prozent:0.20


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:           60.3 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:          60.2 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:             0.1 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.017 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.017 qkm



 ISO: Normierungsfaktor   = 1.0000
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =            12.894
niederschlag =       12.894
flaeche zft  =        1.000
flaeche eing.=        0.017

GEBIET: Abflusswelle Interflow:

 ISO: Normierungsfaktor   = 1.0001
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.017

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV: Retentionskonstanten:   0.3       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =       1.00
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH =   60
ISOV:  fuellenberechnung
ISOV: Abflusz =            43.820
ISOV: Niederschlag =       43.820

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
ISOV: Retentionskonstanten: 545.0       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =      97.39
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH = 2880
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1055

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4578

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    1.61

 gesamtmenge an niederschlag (mm):       57.5

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     15


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  1.000


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4578
 anzahl hydrotope:      15


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      57.5 mm
 interz.verd.:                       6.7 mm
 bestandsniederschlag:              48.7 mm
 differenz interz.speicher:         -2.1 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      16.3 mm
 aktuelle verdunstung:              11.6 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              48.7 mm
 overlandflow:                       0.7 mm
 [infiltration:                     48.0 mm]
 verdunstung (bodensp.):             4.9 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -43.1 mm
 fehler:                             0.0 mm


 6.25002670  -> zufluss grundwasserleiter in  4578
TG:    4578 -> TG:    4579
Prozent:0.80

TG:    4578 -> TG:    4580
Prozent:0.20


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:           85.6 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:          85.9 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -0.3 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.022 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.022 qkm



 ISO: Normierungsfaktor   = 1.0000
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =            14.566
niederschlag =       14.566
flaeche zft  =        1.000
flaeche eing.=        0.022

GEBIET: Abflusswelle Interflow:

 ISO: Normierungsfaktor   = 1.0001
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.022

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV: Retentionskonstanten:   0.3       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =       1.00
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH =   60
ISOV:  fuellenberechnung
ISOV: Abflusz =            82.721
ISOV: Niederschlag =       82.721

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
ISOV: Retentionskonstanten: 545.0       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =      97.39
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH = 2880
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1056

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4580

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    1.61

 gesamtmenge an niederschlag (mm):       57.5

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     31


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 = 10.000


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4580
 anzahl hydrotope:      31


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      57.5 mm
 interz.verd.:                       6.6 mm
 bestandsniederschlag:              48.9 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      16.0 mm
 aktuelle verdunstung:              10.5 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              48.9 mm
 overlandflow:                       0.3 mm
 [infiltration:                     48.6 mm]
 verdunstung (bodensp.):             3.9 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -44.7 mm
 fehler:                             0.0 mm


 51.0693474  -> zufluss grundwasserleiter in  4580
TG:    4580 -> TG:    4579
Prozent:0.10

TG:    4580 -> TG:    4584
Prozent:0.30

TG:    4580 -> TG:    4586
Prozent:0.60


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:          230.3 mm
 abgabe basisabfluss:                 73.2 mm
        grundw. unterh.l.TG:         157.3 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -0.3 mm
 fehler:                               0.1 mm


 flaechenanteile: 

   grundwasserleiter:                0.067 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.067 qkm



 ISO: Normierungsfaktor   = 1.0002
 ISO: Summe normierter uh =   1.0000


 Anzahl der Zeitschritte in iso durch Nachlauf zu hoch geworden.
 Sie wird auf 460 begrenzt !  gebiet :  4580

fuellenberechnung in iso
abflusz =            21.123
niederschlag =       21.160
flaeche zft  =        1.000
flaeche eing.=        0.067

GEBIET: Abflusswelle Interflow:

 ISO: Normierungsfaktor   = 1.0000
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.067

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV: Retentionskonstanten:   0.9       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =       1.00
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH =  181
ISOV:  fuellenberechnung
ISOV: Abflusz =           328.309
ISOV: Niederschlag =      328.309

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
ISOV: Retentionskonstanten:6000.0       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =   96602.20
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH = 2880
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1057

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4584

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    1.61

 gesamtmenge an niederschlag (mm):       57.5

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     21


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  5.000


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4584
 anzahl hydrotope:      21


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      57.5 mm
 interz.verd.:                       6.7 mm
 bestandsniederschlag:              48.8 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      16.4 mm
 aktuelle verdunstung:              10.1 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              48.8 mm
 overlandflow:                       0.1 mm
 [infiltration:                     48.7 mm]
 verdunstung (bodensp.):             3.4 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -45.3 mm
 fehler:                             0.0 mm


 10.4633913  -> zufluss grundwasserleiter in  4584
TG:    4584 -> TG:    4587
Prozent:1.00


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:           54.5 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:          54.7 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -0.2 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.058 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.058 qkm



 ISO: Normierungsfaktor   = 1.0001
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =             5.590
niederschlag =        5.590
flaeche zft  =        1.000
flaeche eing.=        0.058

GEBIET: Abflusswelle Interflow:

 ISO: Normierungsfaktor   = 1.0000
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.058

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV: Retentionskonstanten:   0.9       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =       1.00
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH =  168
ISOV:  fuellenberechnung
ISOV: Abflusz =           865.971
ISOV: Niederschlag =      865.971

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
ISOV: Retentionskonstanten:1667.0       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =    2238.97
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH = 2880
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1058

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4587

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    1.61

 gesamtmenge an niederschlag (mm):       57.5

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     15


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  5.000


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4587
 anzahl hydrotope:      15


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      57.5 mm
 interz.verd.:                       6.6 mm
 bestandsniederschlag:              48.9 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      16.0 mm
 aktuelle verdunstung:               9.6 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              48.9 mm
 overlandflow:                       0.0 mm
 [infiltration:                     48.9 mm]
 verdunstung (bodensp.):             3.0 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -45.9 mm
 fehler:                             0.0 mm


 24.5319424  -> zufluss grundwasserleiter in  4587
TG:    4587 -> TG:    4598
Prozent:1.00


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:          403.9 mm
 abgabe basisabfluss:                 44.1 mm
        grundw. unterh.l.TG:         360.1 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -0.4 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.018 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.018 qkm



 ISO: Normierungsfaktor   = 1.0001
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.018

GEBIET: Abflusswelle Interflow:

 ISO: Normierungsfaktor   = 1.0000
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.018

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV: Retentionskonstanten:   0.9       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =       1.00
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH =  168
ISOV:  fuellenberechnung
ISOV: Abflusz =           127.829
ISOV: Niederschlag =      127.829

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
ISOV: Retentionskonstanten:1667.0       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =    2238.97
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH = 2880
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1059

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4574

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    1.61

 gesamtmenge an niederschlag (mm):       57.5

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     26


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  1.000


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4574
 anzahl hydrotope:      26


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      57.5 mm
 interz.verd.:                       6.7 mm
 bestandsniederschlag:              48.7 mm
 differenz interz.speicher:         -2.1 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      16.2 mm
 aktuelle verdunstung:              10.2 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              48.7 mm
 overlandflow:                       0.2 mm
 [infiltration:                     48.5 mm]
 verdunstung (bodensp.):             3.6 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -45.0 mm
 fehler:                             0.0 mm


 3.09175181  -> zufluss grundwasserleiter in  4574
TG:    4574 -> TG:    4575
Prozent:1.00


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:           10.3 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:          10.7 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -0.4 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.090 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.090 qkm



 ISO: Normierungsfaktor   = 1.0001
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =            16.944
niederschlag =       16.944
flaeche zft  =        1.000
flaeche eing.=        0.090

GEBIET: Abflusswelle Interflow:

 ISO: Normierungsfaktor   = 1.0000
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.090

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV: Retentionskonstanten:   1.0       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =       1.00
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH =  190
ISOV:  fuellenberechnung
ISOV: Abflusz =           703.196
ISOV: Niederschlag =      703.197

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
ISOV: Retentionskonstanten:1891.0       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =    3227.00
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH = 2880
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1060

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4575

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    1.61

 gesamtmenge an niederschlag (mm):       57.5

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     16


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  1.000


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4575
 anzahl hydrotope:      16


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      57.5 mm
 interz.verd.:                       6.6 mm
 bestandsniederschlag:              48.9 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      16.0 mm
 aktuelle verdunstung:               9.7 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              48.9 mm
 overlandflow:                       0.0 mm
 [infiltration:                     48.9 mm]
 verdunstung (bodensp.):             3.1 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -45.8 mm
 fehler:                             0.0 mm


 3.20433426  -> zufluss grundwasserleiter in  4575
TG:    4575 -> TG:    4585
Prozent:1.00


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:           20.5 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:          20.6 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -0.2 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.047 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.047 qkm



 ISO: Normierungsfaktor   = 1.0000
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =             0.708
niederschlag =        0.708
flaeche zft  =        1.000
flaeche eing.=        0.047

GEBIET: Abflusswelle Interflow:

 ISO: Normierungsfaktor   = 1.0000
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.047

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV: Retentionskonstanten:   0.6       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =       1.00
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH =  124
ISOV:  fuellenberechnung
ISOV: Abflusz =           496.187
ISOV: Niederschlag =      496.187

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
ISOV: Retentionskonstanten:1200.0       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =     870.72
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH = 2880
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1061

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4579

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    1.61

 gesamtmenge an niederschlag (mm):       57.5

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     20


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  1.000


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4579
 anzahl hydrotope:      20


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      57.5 mm
 interz.verd.:                       6.6 mm
 bestandsniederschlag:              48.9 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      15.9 mm
 aktuelle verdunstung:              11.0 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              48.9 mm
 overlandflow:                       0.5 mm
 [infiltration:                     48.4 mm]
 verdunstung (bodensp.):             4.4 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -44.0 mm
 fehler:                             0.0 mm


 9.20037270  -> zufluss grundwasserleiter in  4579
TG:    4579 -> TG:    4585
Prozent:0.50

TG:    4579 -> TG:    4586
Prozent:0.50


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:          213.3 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:         213.9 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -0.6 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.013 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.013 qkm



 ISO: Normierungsfaktor   = 1.0000
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =             6.974
niederschlag =        6.974
flaeche zft  =        1.000
flaeche eing.=        0.013

GEBIET: Abflusswelle Interflow:

 ISO: Normierungsfaktor   = 1.0002
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.013

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV: Retentionskonstanten:   0.2       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =       1.00
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH =   42
ISOV:  fuellenberechnung
ISOV: Abflusz =           147.371
ISOV: Niederschlag =      147.371

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
ISOV: Retentionskonstanten: 364.0       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =      34.03
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH = 2880
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1062

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4585

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    1.61

 gesamtmenge an niederschlag (mm):       57.5

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     24


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  5.000


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4585
 anzahl hydrotope:      24


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      57.5 mm
 interz.verd.:                       6.6 mm
 bestandsniederschlag:              48.9 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      16.1 mm
 aktuelle verdunstung:              10.1 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              48.9 mm
 overlandflow:                       0.1 mm
 [infiltration:                     48.7 mm]
 verdunstung (bodensp.):             3.4 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -45.3 mm
 fehler:                             0.0 mm


 7.84610462  -> zufluss grundwasserleiter in  4585
TG:    4585 -> TG:    4596
Prozent:1.00


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:           40.9 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:          44.1 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -3.2 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.058 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.058 qkm



 ISO: Normierungsfaktor   = 1.0002
 ISO: Summe normierter uh =   1.0000


 Anzahl der Zeitschritte in iso durch Nachlauf zu hoch geworden.
 Sie wird auf 460 begrenzt !  gebiet :  4585

fuellenberechnung in iso
abflusz =             8.195
niederschlag =        8.198
flaeche zft  =        1.000
flaeche eing.=        0.058

GEBIET: Abflusswelle Interflow:

 ISO: Normierungsfaktor   = 1.0000
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.058

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV: Retentionskonstanten:   1.8       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =       1.00
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH =  335
ISOV:  fuellenberechnung
ISOV: Abflusz =           619.096
ISOV: Niederschlag =      619.096

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
ISOV: Retentionskonstanten:5000.0       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =   56239.74
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH = 2880
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1063

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4586

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    1.61

 gesamtmenge an niederschlag (mm):       57.5

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     44


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  5.000


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4586
 anzahl hydrotope:      44


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      57.5 mm
 interz.verd.:                       6.6 mm
 bestandsniederschlag:              48.9 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      16.0 mm
 aktuelle verdunstung:              10.6 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              48.9 mm
 overlandflow:                       0.4 mm
 [infiltration:                     48.5 mm]
 verdunstung (bodensp.):             4.0 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -44.6 mm
 fehler:                             0.0 mm


 25.5400829  -> zufluss grundwasserleiter in  4586
TG:    4586 -> TG:    4598
Prozent:0.50

TG:    4586 -> TG:    4596
Prozent:0.50


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:          132.9 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:         133.3 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -0.4 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.058 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.058 qkm



 ISO: Normierungsfaktor   = 1.0001
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =            20.832
niederschlag =       20.832
flaeche zft  =        1.000
flaeche eing.=        0.058

GEBIET: Abflusswelle Interflow:

 ISO: Normierungsfaktor   = 1.0000
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.058

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV: Retentionskonstanten:   0.9       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =       1.00
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH =  168
ISOV:  fuellenberechnung
ISOV: Abflusz =           553.572
ISOV: Niederschlag =      553.572

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
ISOV: Retentionskonstanten:1667.0       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =    2238.97
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH = 2880
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         4585

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.

 Keine angeschlossenen Teilgebiete an Strang      4585
 Auswertung des Stranges:         4587

 Abflussverzoegerung mit Kalinin-Miljukov Parametern

 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 dt [h]:   0.08      tmax [d]:     4.86


 Kennwerte Zuflusswelle
 ----------------------

 Scheitel-Zufluss               iqzmax =   1401   qzmax =       0.046 [m**3/s]
 Scheitel-Zufluss im Gerinne    iqzfmx =   1401  qzfmax =       0.046 [m**3/s]
 Scheitel-Zufluss im Vorland    iqzvmx =      0  qzvmax =       0.000 [m**3/s]

 Fuelle-Zufluss                   fuqz =   0.0012 [hm**3]
 Fuelle-zufluss im Gerinne       fuqzf =   0.0012 [hm**3]
 Fuelle-zufluss im Vorland       fuqzv =   0.0000 [hm**3]


 Kennwerte der Systemfunktionen
 -------------------------------

 Anzahl der Zeitschritte  ituh =     18
 Maximum u                imax =      3     umax = 0.269426
 Summe u                   suu = 0.999998   suuh = 1.000000


 tmax [d]:     4.88


 Kennwerte Ausflusswelle
 -----------------------

 Endordinate Ausfluss           qaend =   0.000
 Scheitel-Ausfluss              iqmax =   1404    qmax =       0.046 [m**3/s]

 Fuelle-Ausfluss                  fuq =   0.0012 [hm**3]
 Fuelle-Ausfluss im Gerinne      fuqa =   0.0012 [hm**3]

 Scheitel-Ausfluss im Gerinne  iqamax =   1404   qamax =       0.046 [m**3/s]


 Gesamtzuflusswelle (ohne Basisabfluss)  sqz =        4.006
 Gesamtabflusswelle    "       "         sq  =        4.006


 Keine angeschlossenen Teilgebiete an Strang      4587
 Auswertung des Stranges:         4621

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Fiktiver Strang! Es erfolgt keine Abflussverzoegerung!
 Keine angeschlossenen Teilgebiete an Strang      4621
 Auswertung des Stranges:         1064

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4507

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    1.61

 gesamtmenge an niederschlag (mm):       57.5

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     69


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  0.500


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4507
 anzahl hydrotope:      69


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      57.5 mm
 interz.verd.:                       6.6 mm
 bestandsniederschlag:              48.9 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      16.1 mm
 aktuelle verdunstung:              10.3 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              48.9 mm
 overlandflow:                       0.2 mm
 [infiltration:                     48.7 mm]
 verdunstung (bodensp.):             3.6 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        2.0 mm
 differenz bodenspeicher:          -43.0 mm
 fehler:                             0.0 mm


 0.00000000E+00  -> zufluss grundwasserleiter in  4507
TG:    4507 -> TG:    4508
Prozent:1.00


 aufteilung perkolation: 

 perkolation bodenspeicher:            2.0 mm

 abgabe grundw.speicher:               2.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  2.0 mm
        grundw. oberh.l.TG:            0.0 mm
 abgabe basisabfluss:                  0.7 mm
        grundw. unterh.l.TG:           2.9 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                -1.2 mm
     pot.entnahme GWS:                -1.2 mm
 speicherinhaltsaenderung:            -0.3 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.513 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.513 qkm



 ISO: Normierungsfaktor   = 1.0002
 ISO: Summe normierter uh =   1.0000


 Anzahl der Zeitschritte in iso durch Nachlauf zu hoch geworden.
 Sie wird auf 460 begrenzt !  gebiet :  4507

fuellenberechnung in iso
abflusz =           118.054
niederschlag =      118.258
flaeche zft  =        1.000
flaeche eing.=        0.513

GEBIET: Abflusswelle Interflow:

 ISO: Normierungsfaktor   = 1.0002
 ISO: Summe normierter uh =   1.0000


 Anzahl der Zeitschritte in iso durch Nachlauf zu hoch geworden.
 Sie wird auf 460 begrenzt !  gebiet :  4507

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.513

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV: Retentionskonstanten:   1.4       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =       1.00
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH =  264
ISOV:  fuellenberechnung
ISOV: Abflusz =          4355.330
ISOV: Niederschlag =     4355.331

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
ISOV: Retentionskonstanten:6000.0       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =   96602.20
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH = 2880
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1065

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4508

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    1.61

 gesamtmenge an niederschlag (mm):       57.5

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     56


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  1.000


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4508
 anzahl hydrotope:      56


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      57.5 mm
 interz.verd.:                       6.6 mm
 bestandsniederschlag:              48.9 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      16.0 mm
 aktuelle verdunstung:               9.8 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              48.9 mm
 overlandflow:                       0.2 mm
 [infiltration:                     48.7 mm]
 verdunstung (bodensp.):             3.2 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.9 mm
 differenz bodenspeicher:          -44.6 mm
 fehler:                             0.0 mm


 entnahme gws [qbm/s]:       0.000
 4.91823721  -> zufluss grundwasserleiter in  4508
TG:    4508 -> TG:    4509
Prozent:1.00


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.9 mm

 abgabe grundw.speicher:               0.9 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.9 mm
        grundw. oberh.l.TG:            3.8 mm
 abgabe basisabfluss:                  1.6 mm
        grundw. unterh.l.TG:           3.7 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.2 mm
     pot.entnahme GWS:                 0.2 mm
 speicherinhaltsaenderung:            -0.9 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.390 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.390 qkm



 ISO: Normierungsfaktor   = 1.0002
 ISO: Summe normierter uh =   1.0000


 Anzahl der Zeitschritte in iso durch Nachlauf zu hoch geworden.
 Sie wird auf 460 begrenzt !  gebiet :  4508

fuellenberechnung in iso
abflusz =            82.416
niederschlag =       82.558
flaeche zft  =        1.000
flaeche eing.=        0.390

GEBIET: Abflusswelle Interflow:

 ISO: Normierungsfaktor   = 1.0002
 ISO: Summe normierter uh =   1.0000


 Anzahl der Zeitschritte in iso durch Nachlauf zu hoch geworden.
 Sie wird auf 460 begrenzt !  gebiet :  4508

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.390

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV: Retentionskonstanten:   1.4       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =       1.00
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH =  264
ISOV:  fuellenberechnung
ISOV: Abflusz =          4165.701
ISOV: Niederschlag =     4165.702

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
ISOV: Retentionskonstanten:6000.0       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =   96602.20
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH = 2880
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1066

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4509

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    1.61

 gesamtmenge an niederschlag (mm):       57.5

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     83


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  1.500


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4509
 anzahl hydrotope:      83


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      57.5 mm
 interz.verd.:                       6.6 mm
 bestandsniederschlag:              48.9 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      16.0 mm
 aktuelle verdunstung:              10.0 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              48.9 mm
 overlandflow:                       0.4 mm
 [infiltration:                     48.5 mm]
 verdunstung (bodensp.):             3.4 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.2 mm
 differenz bodenspeicher:          -44.9 mm
 fehler:                             0.0 mm


 entnahme gws [qbm/s]:       0.000
 9.01979828  -> zufluss grundwasserleiter in  4509
TG:    4509 -> TG:    4511
Prozent:1.00


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.2 mm

 abgabe grundw.speicher:               0.2 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.2 mm
        grundw. oberh.l.TG:            3.4 mm
 abgabe basisabfluss:                  1.3 mm
        grundw. unterh.l.TG:           3.4 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -1.2 mm
 fehler:                               0.1 mm


 flaechenanteile: 

   grundwasserleiter:                0.801 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.801 qkm



 ISO: Normierungsfaktor   = 1.0002
 ISO: Summe normierter uh =   1.0000


 Anzahl der Zeitschritte in iso durch Nachlauf zu hoch geworden.
 Sie wird auf 460 begrenzt !  gebiet :  4509

fuellenberechnung in iso
abflusz =           353.498
niederschlag =      354.110
flaeche zft  =        1.000
flaeche eing.=        0.801

GEBIET: Abflusswelle Interflow:

 ISO: Normierungsfaktor   = 1.0002
 ISO: Summe normierter uh =   1.0000


 Anzahl der Zeitschritte in iso durch Nachlauf zu hoch geworden.
 Sie wird auf 460 begrenzt !  gebiet :  4509

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.801

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV: Retentionskonstanten:   1.4       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =       1.00
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH =  264
ISOV:  fuellenberechnung
ISOV: Abflusz =          7099.694
ISOV: Niederschlag =     7099.695

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
ISOV: Retentionskonstanten:6000.0       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =   96602.20
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH = 2880
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1067

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4511

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    1.61

 gesamtmenge an niederschlag (mm):       57.5

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     62


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  2.500


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4511
 anzahl hydrotope:      62


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      57.5 mm
 interz.verd.:                       6.6 mm
 bestandsniederschlag:              48.9 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      16.0 mm
 aktuelle verdunstung:              10.0 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              48.9 mm
 overlandflow:                       0.8 mm
 [infiltration:                     48.1 mm]
 verdunstung (bodensp.):             3.4 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -44.7 mm
 fehler:                             0.0 mm


 10.9381447  -> zufluss grundwasserleiter in  4511
TG:    4511 -> TG:    4567
Prozent:1.00


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:            9.6 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:          15.0 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -5.4 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.341 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.341 qkm



 ISO: Normierungsfaktor   = 1.0002
 ISO: Summe normierter uh =   1.0000


 Anzahl der Zeitschritte in iso durch Nachlauf zu hoch geworden.
 Sie wird auf 460 begrenzt !  gebiet :  4511

fuellenberechnung in iso
abflusz =           265.091
niederschlag =      265.549
flaeche zft  =        1.000
flaeche eing.=        0.341

GEBIET: Abflusswelle Interflow:

 ISO: Normierungsfaktor   = 1.0000
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.341

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV: Retentionskonstanten:   1.4       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =       1.00
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH =  264
ISOV:  fuellenberechnung
ISOV: Abflusz =          3592.173
ISOV: Niederschlag =     3592.174

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
ISOV: Retentionskonstanten:6000.0       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =   96602.20
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH = 2880
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1068

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4567

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    1.61

 gesamtmenge an niederschlag (mm):       57.5

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     67


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  6.000


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4567
 anzahl hydrotope:      67


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      57.5 mm
 interz.verd.:                       7.0 mm
 bestandsniederschlag:              47.9 mm
 differenz interz.speicher:         -2.5 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      16.3 mm
 aktuelle verdunstung:              10.5 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              47.9 mm
 overlandflow:                       1.0 mm
 [infiltration:                     46.9 mm]
 verdunstung (bodensp.):             3.4 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -43.5 mm
 fehler:                             0.0 mm


 43.6112938  -> zufluss grundwasserleiter in  4567
TG:    4567 -> TG:    4588
Prozent:1.00


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:           50.7 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:          53.3 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -2.6 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.258 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.258 qkm



 ISO: Normierungsfaktor   = 1.0002
 ISO: Summe normierter uh =   1.0000


 Anzahl der Zeitschritte in iso durch Nachlauf zu hoch geworden.
 Sie wird auf 460 begrenzt !  gebiet :  4567

fuellenberechnung in iso
abflusz =           268.529
niederschlag =      268.994
flaeche zft  =        1.000
flaeche eing.=        0.258

GEBIET: Abflusswelle Interflow:

 ISO: Normierungsfaktor   = 1.0000
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.258

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV: Retentionskonstanten:   1.4       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =       1.00
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH =  264
ISOV:  fuellenberechnung
ISOV: Abflusz =          1777.511
ISOV: Niederschlag =     1777.511

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
ISOV: Retentionskonstanten:6000.0       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =   96602.20
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH = 2880
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1069

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4588

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    1.61

 gesamtmenge an niederschlag (mm):       57.5

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     26


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  6.000


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4588
 anzahl hydrotope:      26


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      57.5 mm
 interz.verd.:                       6.6 mm
 bestandsniederschlag:              48.9 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      16.1 mm
 aktuelle verdunstung:               9.7 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              48.9 mm
 overlandflow:                       0.1 mm
 [infiltration:                     48.8 mm]
 verdunstung (bodensp.):             3.1 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -45.7 mm
 fehler:                             0.0 mm


 entnahme gws [qbm/s]:       0.000
 45.8445129  -> zufluss grundwasserleiter in  4588
TG:    4588 -> TG:    4598
Prozent:1.00


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:          119.3 mm
 abgabe basisabfluss:                 19.4 mm
        grundw. unterh.l.TG:         100.4 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.2 mm
     pot.entnahme GWS:                 0.2 mm
 speicherinhaltsaenderung:            -0.7 mm
 fehler:                               0.1 mm


 flaechenanteile: 

   grundwasserleiter:                0.115 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.115 qkm



 ISO: Normierungsfaktor   = 1.0002
 ISO: Summe normierter uh =   1.0000


 Anzahl der Zeitschritte in iso durch Nachlauf zu hoch geworden.
 Sie wird auf 460 begrenzt !  gebiet :  4588

fuellenberechnung in iso
abflusz =             8.363
niederschlag =        8.378
flaeche zft  =        1.000
flaeche eing.=        0.115

GEBIET: Abflusswelle Interflow:

 ISO: Normierungsfaktor   = 1.0000
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.115

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV: Retentionskonstanten:   2.8       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =       1.00
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH =  500
ISOV:  fuellenberechnung
ISOV: Abflusz =           889.513
ISOV: Niederschlag =      889.514

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
ISOV: Retentionskonstanten:6000.0       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =   96602.20
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH = 2880
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         4507

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.

 Keine angeschlossenen Teilgebiete an Strang      4507
 Auswertung des Stranges:         4508

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Abflussverzoegerung mit Kalinin-Miljukov Parametern

 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 dt [h]:   0.08      tmax [d]:     4.89


 Kennwerte Zuflusswelle
 ----------------------

 Scheitel-Zufluss               iqzmax =   1409   qzmax =       0.162 [m**3/s]
 Scheitel-Zufluss im Gerinne    iqzfmx =   1409  qzfmax =       0.162 [m**3/s]
 Scheitel-Zufluss im Vorland    iqzvmx =      0  qzvmax =       0.000 [m**3/s]

 Fuelle-Zufluss                   fuqz =   0.0048 [hm**3]
 Fuelle-zufluss im Gerinne       fuqzf =   0.0048 [hm**3]
 Fuelle-zufluss im Vorland       fuqzv =   0.0000 [hm**3]


 Kennwerte der Systemfunktionen
 -------------------------------

 Anzahl der Zeitschritte  ituh =     32
 Maximum u                imax =      1     umax = 0.248968
 Summe u                   suu = 1.001107   suuh = 1.000000


 tmax [d]:     4.90


 Kennwerte Ausflusswelle
 -----------------------

 Endordinate Ausfluss           qaend =   0.000
 Scheitel-Ausfluss              iqmax =   1410    qmax =       0.162 [m**3/s]

 Fuelle-Ausfluss                  fuq =   0.0048 [hm**3]
 Fuelle-Ausfluss im Gerinne      fuqa =   0.0048 [hm**3]

 Scheitel-Ausfluss im Gerinne  iqamax =   1410   qamax =       0.162 [m**3/s]


 Gesamtzuflusswelle (ohne Basisabfluss)  sqz =       16.138
 Gesamtabflusswelle    "       "         sq  =       16.138


 Keine angeschlossenen Teilgebiete an Strang      4508
 Auswertung des Stranges:         4509

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Abflussverzoegerung mit Kalinin-Miljukov Parametern

 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 dt [h]:   0.08      tmax [d]:     4.90


 Kennwerte Zuflusswelle
 ----------------------

 Scheitel-Zufluss               iqzmax =   1410   qzmax =       0.318 [m**3/s]
 Scheitel-Zufluss im Gerinne    iqzfmx =   1410  qzfmax =       0.318 [m**3/s]
 Scheitel-Zufluss im Vorland    iqzvmx =      0  qzvmax =       0.000 [m**3/s]

 Fuelle-Zufluss                   fuqz =   0.0097 [hm**3]
 Fuelle-zufluss im Gerinne       fuqzf =   0.0097 [hm**3]
 Fuelle-zufluss im Vorland       fuqzv =   0.0000 [hm**3]


 Kennwerte der Systemfunktionen
 -------------------------------

 Anzahl der Zeitschritte  ituh =     18
 Maximum u                imax =      3     umax = 0.269426
 Summe u                   suu = 0.999998   suuh = 1.000000


 tmax [d]:     4.91


 Kennwerte Ausflusswelle
 -----------------------

 Endordinate Ausfluss           qaend =   0.000
 Scheitel-Ausfluss              iqmax =   1413    qmax =       0.317 [m**3/s]

 Fuelle-Ausfluss                  fuq =   0.0097 [hm**3]
 Fuelle-Ausfluss im Gerinne      fuqa =   0.0097 [hm**3]

 Scheitel-Ausfluss im Gerinne  iqamax =   1413   qamax =       0.317 [m**3/s]


 Gesamtzuflusswelle (ohne Basisabfluss)  sqz =       32.396
 Gesamtabflusswelle    "       "         sq  =       32.396


 Keine angeschlossenen Teilgebiete an Strang      4509
 Auswertung des Stranges:         4605

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Fiktiver Strang! Es erfolgt keine Abflussverzoegerung!
 Keine angeschlossenen Teilgebiete an Strang      4605
 Auswertung des Stranges:         4503

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.

 Keine angeschlossenen Teilgebiete an Strang      4503
 Auswertung des Stranges:         4504

 Abflussverzoegerung mit Kalinin-Miljukov Parametern

 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 dt [h]:   0.08      tmax [d]:     4.94


 Kennwerte Zuflusswelle
 ----------------------

 Scheitel-Zufluss               iqzmax =   1422   qzmax =       0.113 [m**3/s]
 Scheitel-Zufluss im Gerinne    iqzfmx =   1422  qzfmax =       0.113 [m**3/s]
 Scheitel-Zufluss im Vorland    iqzvmx =      0  qzvmax =       0.000 [m**3/s]

 Fuelle-Zufluss                   fuqz =   0.0047 [hm**3]
 Fuelle-zufluss im Gerinne       fuqzf =   0.0047 [hm**3]
 Fuelle-zufluss im Vorland       fuqzv =   0.0000 [hm**3]


 Kennwerte der Systemfunktionen
 -------------------------------

 Anzahl der Zeitschritte  ituh =     18
 Maximum u                imax =      3     umax = 0.269426
 Summe u                   suu = 0.999998   suuh = 1.000000


 tmax [d]:     4.95


 Kennwerte Ausflusswelle
 -----------------------

 Endordinate Ausfluss           qaend =   0.000
 Scheitel-Ausfluss              iqmax =   1425    qmax =       0.113 [m**3/s]

 Fuelle-Ausfluss                  fuq =   0.0047 [hm**3]
 Fuelle-Ausfluss im Gerinne      fuqa =   0.0047 [hm**3]

 Scheitel-Ausfluss im Gerinne  iqamax =   1425   qamax =       0.113 [m**3/s]


 Gesamtzuflusswelle (ohne Basisabfluss)  sqz =       15.529
 Gesamtabflusswelle    "       "         sq  =       15.529


 Keine angeschlossenen Teilgebiete an Strang      4504
 Auswertung des Stranges:         4505

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Aufruf der Speicherroutine 


 zufluss-fuelle [hm]        0.015997 speicher 4505
 zusaetzl.zufl im nachl.ast [hm]  0.000629

 speicher   0.016625 abfluss-fuelle [hm]      4505

 speicherinhaltsaenderung [hm]  0.000000
 Keine angeschlossenen Teilgebiete an Strang      4505
 Auswertung des Stranges:         4603

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Fiktiver Strang! Es erfolgt keine Abflussverzoegerung!
 Keine angeschlossenen Teilgebiete an Strang      4603
 Auswertung des Stranges:         4580

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.

 Keine angeschlossenen Teilgebiete an Strang      4580
 Auswertung des Stranges:         4581

 Abflussverzoegerung mit Kalinin-Miljukov Parametern
 Keine angeschlossenen Teilgebiete an Strang      4581
 Auswertung des Stranges:         4626

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Fiktiver Strang! Es erfolgt keine Abflussverzoegerung!
 Keine angeschlossenen Teilgebiete an Strang      4626
 Auswertung des Stranges:         4571

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.

 Keine angeschlossenen Teilgebiete an Strang      4571
 Auswertung des Stranges:         4570

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.

 Keine angeschlossenen Teilgebiete an Strang      4570
 Auswertung des Stranges:         4572

 Abflussverzoegerung mit Kalinin-Miljukov Parametern
 Keine angeschlossenen Teilgebiete an Strang      4572
 Auswertung des Stranges:         4576

 Abflussverzoegerung mit Kalinin-Miljukov Parametern

 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 dt [h]:   0.08      tmax [d]:     4.85


 Kennwerte Zuflusswelle
 ----------------------

 Scheitel-Zufluss               iqzmax =   1398   qzmax =       0.106 [m**3/s]
 Scheitel-Zufluss im Gerinne    iqzfmx =   1398  qzfmax =       0.106 [m**3/s]
 Scheitel-Zufluss im Vorland    iqzvmx =      0  qzvmax =       0.000 [m**3/s]

 Fuelle-Zufluss                   fuqz =   0.0025 [hm**3]
 Fuelle-zufluss im Gerinne       fuqzf =   0.0025 [hm**3]
 Fuelle-zufluss im Vorland       fuqzv =   0.0000 [hm**3]


 Kennwerte der Systemfunktionen
 -------------------------------

 Anzahl der Zeitschritte  ituh =     18
 Maximum u                imax =      3     umax = 0.269426
 Summe u                   suu = 0.999998   suuh = 1.000000


 tmax [d]:     4.87


 Kennwerte Ausflusswelle
 -----------------------

 Endordinate Ausfluss           qaend =   0.000
 Scheitel-Ausfluss              iqmax =   1402    qmax =       0.105 [m**3/s]

 Fuelle-Ausfluss                  fuq =   0.0025 [hm**3]
 Fuelle-Ausfluss im Gerinne      fuqa =   0.0025 [hm**3]

 Scheitel-Ausfluss im Gerinne  iqamax =   1402   qamax =       0.105 [m**3/s]


 Gesamtzuflusswelle (ohne Basisabfluss)  sqz =        8.459
 Gesamtabflusswelle    "       "         sq  =        8.459


 Keine angeschlossenen Teilgebiete an Strang      4576
 Auswertung des Stranges:         4577

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Aufruf der Speicherroutine 


 zufluss-fuelle [hm]        0.004460 speicher 4577
 zusaetzl.zufl im nachl.ast [hm]  0.000081

 speicher   0.004540 abfluss-fuelle [hm]      4577

 speicherinhaltsaenderung [hm]  0.000006
 Keine angeschlossenen Teilgebiete an Strang      4577
 Auswertung des Stranges:         4578

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Abflussverzoegerung mit Kalinin-Miljukov Parametern

 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 dt [h]:   0.08      tmax [d]:     4.87


 Kennwerte Zuflusswelle
 ----------------------

 Scheitel-Zufluss               iqzmax =   1402   qzmax =       0.210 [m**3/s]
 Scheitel-Zufluss im Gerinne    iqzfmx =   1402  qzfmax =       0.210 [m**3/s]
 Scheitel-Zufluss im Vorland    iqzvmx =      0  qzvmax =       0.000 [m**3/s]

 Fuelle-Zufluss                   fuqz =   0.0045 [hm**3]
 Fuelle-zufluss im Gerinne       fuqzf =   0.0045 [hm**3]
 Fuelle-zufluss im Vorland       fuqzv =   0.0000 [hm**3]


 Kennwerte der Systemfunktionen
 -------------------------------

 Anzahl der Zeitschritte  ituh =     18
 Maximum u                imax =      3     umax = 0.269426
 Summe u                   suu = 0.999998   suuh = 1.000000


 tmax [d]:     4.88


 Kennwerte Ausflusswelle
 -----------------------

 Endordinate Ausfluss           qaend =   0.000
 Scheitel-Ausfluss              iqmax =   1406    qmax =       0.209 [m**3/s]

 Fuelle-Ausfluss                  fuq =   0.0045 [hm**3]
 Fuelle-Ausfluss im Gerinne      fuqa =   0.0045 [hm**3]

 Scheitel-Ausfluss im Gerinne  iqamax =   1406   qamax =       0.209 [m**3/s]


 Gesamtzuflusswelle (ohne Basisabfluss)  sqz =       15.137
 Gesamtabflusswelle    "       "         sq  =       15.137


 Keine angeschlossenen Teilgebiete an Strang      4578
 Auswertung des Stranges:         4579

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Fiktiver Strang! Es erfolgt keine Abflussverzoegerung!
 Keine angeschlossenen Teilgebiete an Strang      4579
 Auswertung des Stranges:         4620

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.

 Keine angeschlossenen Teilgebiete an Strang      4620
 Auswertung des Stranges:         4582

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Abflussverzoegerung mit Kalinin-Miljukov Parametern

 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 dt [h]:   0.08      tmax [d]:     4.88


 Kennwerte Zuflusswelle
 ----------------------

 Scheitel-Zufluss               iqzmax =   1405   qzmax =       0.211 [m**3/s]
 Scheitel-Zufluss im Gerinne    iqzfmx =   1405  qzfmax =       0.211 [m**3/s]
 Scheitel-Zufluss im Vorland    iqzvmx =      0  qzvmax =       0.000 [m**3/s]

 Fuelle-Zufluss                   fuqz =   0.0048 [hm**3]
 Fuelle-zufluss im Gerinne       fuqzf =   0.0048 [hm**3]
 Fuelle-zufluss im Vorland       fuqzv =   0.0000 [hm**3]


 Kennwerte der Systemfunktionen
 -------------------------------

 Anzahl der Zeitschritte  ituh =     18
 Maximum u                imax =      3     umax = 0.269426
 Summe u                   suu = 0.999998   suuh = 1.000000


 tmax [d]:     4.89


 Kennwerte Ausflusswelle
 -----------------------

 Endordinate Ausfluss           qaend =   0.000
 Scheitel-Ausfluss              iqmax =   1409    qmax =       0.210 [m**3/s]

 Fuelle-Ausfluss                  fuq =   0.0048 [hm**3]
 Fuelle-Ausfluss im Gerinne      fuqa =   0.0048 [hm**3]

 Scheitel-Ausfluss im Gerinne  iqamax =   1409   qamax =       0.210 [m**3/s]


 Gesamtzuflusswelle (ohne Basisabfluss)  sqz =       15.979
 Gesamtabflusswelle    "       "         sq  =       15.979


 Keine angeschlossenen Teilgebiete an Strang      4582
 Auswertung des Stranges:         4583

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Abflussverzoegerung mit Kalinin-Miljukov Parametern

 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 dt [h]:   0.08      tmax [d]:     4.89


 Kennwerte Zuflusswelle
 ----------------------

 Scheitel-Zufluss               iqzmax =   1408   qzmax =       0.233 [m**3/s]
 Scheitel-Zufluss im Gerinne    iqzfmx =   1408  qzfmax =       0.233 [m**3/s]
 Scheitel-Zufluss im Vorland    iqzvmx =      0  qzvmax =       0.000 [m**3/s]

 Fuelle-Zufluss                   fuqz =   0.0100 [hm**3]
 Fuelle-zufluss im Gerinne       fuqzf =   0.0100 [hm**3]
 Fuelle-zufluss im Vorland       fuqzv =   0.0000 [hm**3]


 Kennwerte der Systemfunktionen
 -------------------------------

 Anzahl der Zeitschritte  ituh =     18
 Maximum u                imax =      3     umax = 0.269426
 Summe u                   suu = 0.999998   suuh = 1.000000


 tmax [d]:     4.90


 Kennwerte Ausflusswelle
 -----------------------

 Endordinate Ausfluss           qaend =   0.000
 Scheitel-Ausfluss              iqmax =   1412    qmax =       0.233 [m**3/s]

 Fuelle-Ausfluss                  fuq =   0.0100 [hm**3]
 Fuelle-Ausfluss im Gerinne      fuqa =   0.0100 [hm**3]

 Scheitel-Ausfluss im Gerinne  iqamax =   1412   qamax =       0.233 [m**3/s]


 Gesamtzuflusswelle (ohne Basisabfluss)  sqz =       33.382
 Gesamtabflusswelle    "       "         sq  =       33.382


 Keine angeschlossenen Teilgebiete an Strang      4583
 Auswertung des Stranges:         4627

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Fiktiver Strang! Es erfolgt keine Abflussverzoegerung!
 Keine angeschlossenen Teilgebiete an Strang      4627
 Auswertung des Stranges:         4567

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.

 Keine angeschlossenen Teilgebiete an Strang      4567
 Auswertung des Stranges:         4568

 Aufruf der Speicherroutine 


 zufluss-fuelle [hm]        0.001974 speicher 4568
 zusaetzl.zufl im nachl.ast [hm]  0.000072

 speicher   0.002046 abfluss-fuelle [hm]      4568

 speicherinhaltsaenderung [hm]  0.000000
 Keine angeschlossenen Teilgebiete an Strang      4568
 Auswertung des Stranges:         4617

 Fiktiver Strang! Es erfolgt keine Abflussverzoegerung!
 Keine angeschlossenen Teilgebiete an Strang      4617
 Auswertung des Stranges:         4527

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.

 Keine angeschlossenen Teilgebiete an Strang      4527
 Auswertung des Stranges:         4528

 Aufruf der Speicherroutine 


 zufluss-fuelle [hm]        0.001648 speicher 4528
 zusaetzl.zufl im nachl.ast [hm]  0.000043

 speicher   0.001691 abfluss-fuelle [hm]      4528

 speicherinhaltsaenderung [hm]  0.000002
 Keine angeschlossenen Teilgebiete an Strang      4528
 Auswertung des Stranges:         4623

 Abflussverzoegerung mit Kalinin-Miljukov Parametern

 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 dt [h]:   0.08      tmax [d]:     4.94


 Kennwerte Zuflusswelle
 ----------------------

 Scheitel-Zufluss               iqzmax =   1422   qzmax =       0.054 [m**3/s]
 Scheitel-Zufluss im Gerinne    iqzfmx =   1422  qzfmax =       0.054 [m**3/s]
 Scheitel-Zufluss im Vorland    iqzvmx =      0  qzvmax =       0.000 [m**3/s]

 Fuelle-Zufluss                   fuqz =   0.0017 [hm**3]
 Fuelle-zufluss im Gerinne       fuqzf =   0.0017 [hm**3]
 Fuelle-zufluss im Vorland       fuqzv =   0.0000 [hm**3]


 Kennwerte der Systemfunktionen
 -------------------------------

 Anzahl der Zeitschritte  ituh =     18
 Maximum u                imax =      3     umax = 0.269426
 Summe u                   suu = 0.999998   suuh = 1.000000


 tmax [d]:     4.95


 Kennwerte Ausflusswelle
 -----------------------

 Endordinate Ausfluss           qaend =   0.000
 Scheitel-Ausfluss              iqmax =   1425    qmax =       0.054 [m**3/s]

 Fuelle-Ausfluss                  fuq =   0.0017 [hm**3]
 Fuelle-Ausfluss im Gerinne      fuqa =   0.0017 [hm**3]

 Scheitel-Ausfluss im Gerinne  iqamax =   1425   qamax =       0.054 [m**3/s]


 Gesamtzuflusswelle (ohne Basisabfluss)  sqz =        5.637
 Gesamtabflusswelle    "       "         sq  =        5.637


 Keine angeschlossenen Teilgebiete an Strang      4623
 Auswertung des Stranges:         4624

 Fiktiver Strang! Es erfolgt keine Abflussverzoegerung!
 Keine angeschlossenen Teilgebiete an Strang      4624
 Auswertung des Stranges:         4610

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.

 Keine angeschlossenen Teilgebiete an Strang      4610
 Auswertung des Stranges:         4531

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Aufruf der Speicherroutine 


 zufluss-fuelle [hm]        0.004125 speicher 4531
 zusaetzl.zufl im nachl.ast [hm]  0.000078

 speicher   0.004203 abfluss-fuelle [hm]      4531

 speicherinhaltsaenderung [hm]  0.000000
 Keine angeschlossenen Teilgebiete an Strang      4531
 Auswertung des Stranges:         4625

 Fiktiver Strang! Es erfolgt keine Abflussverzoegerung!
 Keine angeschlossenen Teilgebiete an Strang      4625
 Auswertung des Stranges:         4520

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.

 Keine angeschlossenen Teilgebiete an Strang      4520
 Auswertung des Stranges:         4521

 Aufruf der Speicherroutine 


 zufluss-fuelle [hm]        0.003393 speicher 4521
 zusaetzl.zufl im nachl.ast [hm]  0.000102

 speicher   0.003495 abfluss-fuelle [hm]      4521

 speicherinhaltsaenderung [hm]  0.000000
 Keine angeschlossenen Teilgebiete an Strang      4521
 Auswertung des Stranges:         4608

 Fiktiver Strang! Es erfolgt keine Abflussverzoegerung!
 Keine angeschlossenen Teilgebiete an Strang      4608
 Auswertung des Stranges:         4514

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.

 Keine angeschlossenen Teilgebiete an Strang      4514
 Auswertung des Stranges:         4515

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Abflussverzoegerung mit Kalinin-Miljukov Parametern

 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 dt [h]:   0.08      tmax [d]:     4.89


 Kennwerte Zuflusswelle
 ----------------------

 Scheitel-Zufluss               iqzmax =   1409   qzmax =       0.287 [m**3/s]
 Scheitel-Zufluss im Gerinne    iqzfmx =   1409  qzfmax =       0.287 [m**3/s]
 Scheitel-Zufluss im Vorland    iqzvmx =      0  qzvmax =       0.000 [m**3/s]

 Fuelle-Zufluss                   fuqz =   0.0078 [hm**3]
 Fuelle-zufluss im Gerinne       fuqzf =   0.0078 [hm**3]
 Fuelle-zufluss im Vorland       fuqzv =   0.0000 [hm**3]


 Kennwerte der Systemfunktionen
 -------------------------------

 Anzahl der Zeitschritte  ituh =     18
 Maximum u                imax =      3     umax = 0.269426
 Summe u                   suu = 0.999998   suuh = 1.000000


 tmax [d]:     4.91


 Kennwerte Ausflusswelle
 -----------------------

 Endordinate Ausfluss           qaend =   0.000
 Scheitel-Ausfluss              iqmax =   1413    qmax =       0.286 [m**3/s]

 Fuelle-Ausfluss                  fuq =   0.0078 [hm**3]
 Fuelle-Ausfluss im Gerinne      fuqa =   0.0078 [hm**3]

 Scheitel-Ausfluss im Gerinne  iqamax =   1413   qamax =       0.286 [m**3/s]


 Gesamtzuflusswelle (ohne Basisabfluss)  sqz =       26.124
 Gesamtabflusswelle    "       "         sq  =       26.124


 Keine angeschlossenen Teilgebiete an Strang      4515
 Auswertung des Stranges:         4516

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Aufruf der Speicherroutine 


 zufluss-fuelle [hm]        0.008897 speicher 4516
 zusaetzl.zufl im nachl.ast [hm]  0.000264

 speicher   0.009161 abfluss-fuelle [hm]      4516

 speicherinhaltsaenderung [hm]  0.000000
 Keine angeschlossenen Teilgebiete an Strang      4516
 Auswertung des Stranges:         4517

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Abflussverzoegerung mit Kalinin-Miljukov Parametern

 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 dt [h]:   0.08      tmax [d]:     4.89


 Kennwerte Zuflusswelle
 ----------------------

 Scheitel-Zufluss               iqzmax =   1409   qzmax =       0.330 [m**3/s]
 Scheitel-Zufluss im Gerinne    iqzfmx =   1409  qzfmax =       0.330 [m**3/s]
 Scheitel-Zufluss im Vorland    iqzvmx =      0  qzvmax =       0.000 [m**3/s]

 Fuelle-Zufluss                   fuqz =   0.0092 [hm**3]
 Fuelle-zufluss im Gerinne       fuqzf =   0.0092 [hm**3]
 Fuelle-zufluss im Vorland       fuqzv =   0.0000 [hm**3]


 Kennwerte der Systemfunktionen
 -------------------------------

 Anzahl der Zeitschritte  ituh =     18
 Maximum u                imax =      3     umax = 0.269426
 Summe u                   suu = 0.999998   suuh = 1.000000


 tmax [d]:     4.91


 Kennwerte Ausflusswelle
 -----------------------

 Endordinate Ausfluss           qaend =   0.000
 Scheitel-Ausfluss              iqmax =   1413    qmax =       0.329 [m**3/s]

 Fuelle-Ausfluss                  fuq =   0.0092 [hm**3]
 Fuelle-Ausfluss im Gerinne      fuqa =   0.0092 [hm**3]

 Scheitel-Ausfluss im Gerinne  iqamax =   1413   qamax =       0.329 [m**3/s]


 Gesamtzuflusswelle (ohne Basisabfluss)  sqz =       30.543
 Gesamtabflusswelle    "       "         sq  =       30.543


 Keine angeschlossenen Teilgebiete an Strang      4517
 Auswertung des Stranges:         4518

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Aufruf der Speicherroutine 


 zufluss-fuelle [hm]        0.008804 speicher 4518
 zusaetzl.zufl im nachl.ast [hm]  0.000412

 speicher   0.009215 abfluss-fuelle [hm]      4518

 speicherinhaltsaenderung [hm]  0.000054
 Keine angeschlossenen Teilgebiete an Strang      4518
 Auswertung des Stranges:         4607

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Fiktiver Strang! Es erfolgt keine Abflussverzoegerung!
 Keine angeschlossenen Teilgebiete an Strang      4607
 Auswertung des Stranges:         4512

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.

 Keine angeschlossenen Teilgebiete an Strang      4512
 Auswertung des Stranges:         4513

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Abflussverzoegerung mit Kalinin-Miljukov Parametern

 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 dt [h]:   0.08      tmax [d]:     4.89


 Kennwerte Zuflusswelle
 ----------------------

 Scheitel-Zufluss               iqzmax =   1409   qzmax =       0.139 [m**3/s]
 Scheitel-Zufluss im Gerinne    iqzfmx =   1409  qzfmax =       0.139 [m**3/s]
 Scheitel-Zufluss im Vorland    iqzvmx =      0  qzvmax =       0.000 [m**3/s]

 Fuelle-Zufluss                   fuqz =   0.0038 [hm**3]
 Fuelle-zufluss im Gerinne       fuqzf =   0.0038 [hm**3]
 Fuelle-zufluss im Vorland       fuqzv =   0.0000 [hm**3]


 Kennwerte der Systemfunktionen
 -------------------------------

 Anzahl der Zeitschritte  ituh =     18
 Maximum u                imax =      3     umax = 0.269426
 Summe u                   suu = 0.999998   suuh = 1.000000


 tmax [d]:     4.91


 Kennwerte Ausflusswelle
 -----------------------

 Endordinate Ausfluss           qaend =   0.000
 Scheitel-Ausfluss              iqmax =   1413    qmax =       0.139 [m**3/s]

 Fuelle-Ausfluss                  fuq =   0.0038 [hm**3]
 Fuelle-Ausfluss im Gerinne      fuqa =   0.0038 [hm**3]

 Scheitel-Ausfluss im Gerinne  iqamax =   1413   qamax =       0.139 [m**3/s]


 Gesamtzuflusswelle (ohne Basisabfluss)  sqz =       12.646
 Gesamtabflusswelle    "       "         sq  =       12.646


 Keine angeschlossenen Teilgebiete an Strang      4513
 Auswertung des Stranges:         4519

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Abflussverzoegerung mit Kalinin-Miljukov Parametern

 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 dt [h]:   0.08      tmax [d]:     4.90


 Kennwerte Zuflusswelle
 ----------------------

 Scheitel-Zufluss               iqzmax =   1412   qzmax =       0.202 [m**3/s]
 Scheitel-Zufluss im Gerinne    iqzfmx =   1412  qzfmax =       0.202 [m**3/s]
 Scheitel-Zufluss im Vorland    iqzvmx =      0  qzvmax =       0.000 [m**3/s]

 Fuelle-Zufluss                   fuqz =   0.0055 [hm**3]
 Fuelle-zufluss im Gerinne       fuqzf =   0.0055 [hm**3]
 Fuelle-zufluss im Vorland       fuqzv =   0.0000 [hm**3]


 Kennwerte der Systemfunktionen
 -------------------------------

 Anzahl der Zeitschritte  ituh =     18
 Maximum u                imax =      3     umax = 0.269426
 Summe u                   suu = 0.999998   suuh = 1.000000


 tmax [d]:     4.91


 Kennwerte Ausflusswelle
 -----------------------

 Endordinate Ausfluss           qaend =   0.000
 Scheitel-Ausfluss              iqmax =   1415    qmax =       0.201 [m**3/s]

 Fuelle-Ausfluss                  fuq =   0.0055 [hm**3]
 Fuelle-Ausfluss im Gerinne      fuqa =   0.0055 [hm**3]

 Scheitel-Ausfluss im Gerinne  iqamax =   1415   qamax =       0.201 [m**3/s]


 Gesamtzuflusswelle (ohne Basisabfluss)  sqz =       18.352
 Gesamtabflusswelle    "       "         sq  =       18.352


 Keine angeschlossenen Teilgebiete an Strang      4519
 Auswertung des Stranges:         4522

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Abflussverzoegerung mit Kalinin-Miljukov Parametern

 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 dt [h]:   0.08      tmax [d]:     4.93


 Kennwerte Zuflusswelle
 ----------------------

 Scheitel-Zufluss               iqzmax =   1419   qzmax =       0.612 [m**3/s]
 Scheitel-Zufluss im Gerinne    iqzfmx =   1419  qzfmax =       0.612 [m**3/s]
 Scheitel-Zufluss im Vorland    iqzvmx =      0  qzvmax =       0.000 [m**3/s]

 Fuelle-Zufluss                   fuqz =   0.0183 [hm**3]
 Fuelle-zufluss im Gerinne       fuqzf =   0.0183 [hm**3]
 Fuelle-zufluss im Vorland       fuqzv =   0.0000 [hm**3]


 Kennwerte der Systemfunktionen
 -------------------------------

 Anzahl der Zeitschritte  ituh =     18
 Maximum u                imax =      3     umax = 0.269426
 Summe u                   suu = 0.999998   suuh = 1.000000


 tmax [d]:     4.94


 Kennwerte Ausflusswelle
 -----------------------

 Endordinate Ausfluss           qaend =   0.000
 Scheitel-Ausfluss              iqmax =   1423    qmax =       0.610 [m**3/s]

 Fuelle-Ausfluss                  fuq =   0.0183 [hm**3]
 Fuelle-Ausfluss im Gerinne      fuqa =   0.0183 [hm**3]

 Scheitel-Ausfluss im Gerinne  iqamax =   1423   qamax =       0.610 [m**3/s]


 Gesamtzuflusswelle (ohne Basisabfluss)  sqz =       60.957
 Gesamtabflusswelle    "       "         sq  =       60.957


 Keine angeschlossenen Teilgebiete an Strang      4522
 Auswertung des Stranges:         4524

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Abflussverzoegerung mit Kalinin-Miljukov Parametern

 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 dt [h]:   0.08      tmax [d]:     4.92


 Kennwerte Zuflusswelle
 ----------------------

 Scheitel-Zufluss               iqzmax =   1418   qzmax =       0.830 [m**3/s]
 Scheitel-Zufluss im Gerinne    iqzfmx =   1418  qzfmax =       0.830 [m**3/s]
 Scheitel-Zufluss im Vorland    iqzvmx =      0  qzvmax =       0.000 [m**3/s]

 Fuelle-Zufluss                   fuqz =   0.0265 [hm**3]
 Fuelle-zufluss im Gerinne       fuqzf =   0.0265 [hm**3]
 Fuelle-zufluss im Vorland       fuqzv =   0.0000 [hm**3]


 Kennwerte der Systemfunktionen
 -------------------------------

 Anzahl der Zeitschritte  ituh =     18
 Maximum u                imax =      3     umax = 0.269426
 Summe u                   suu = 0.999998   suuh = 1.000000


 tmax [d]:     4.94


 Kennwerte Ausflusswelle
 -----------------------

 Endordinate Ausfluss           qaend =   0.000
 Scheitel-Ausfluss              iqmax =   1422    qmax =       0.829 [m**3/s]

 Fuelle-Ausfluss                  fuq =   0.0265 [hm**3]
 Fuelle-Ausfluss im Gerinne      fuqa =   0.0265 [hm**3]

 Scheitel-Ausfluss im Gerinne  iqamax =   1422   qamax =       0.829 [m**3/s]


 Gesamtzuflusswelle (ohne Basisabfluss)  sqz =       88.201
 Gesamtabflusswelle    "       "         sq  =       88.201


 Keine angeschlossenen Teilgebiete an Strang      4524
 Auswertung des Stranges:         4525

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Aufruf der Speicherroutine 


 zufluss-fuelle [hm]        0.030716 speicher 4525
 zusaetzl.zufl im nachl.ast [hm]  0.001322

 speicher   0.032036 abfluss-fuelle [hm]      4525

 speicherinhaltsaenderung [hm]  0.000000
 Keine angeschlossenen Teilgebiete an Strang      4525
 Auswertung des Stranges:         4609

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Fiktiver Strang! Es erfolgt keine Abflussverzoegerung!
 Keine angeschlossenen Teilgebiete an Strang      4609
 Auswertung des Stranges:         4500

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.

 Keine angeschlossenen Teilgebiete an Strang      4500
 Auswertung des Stranges:         4501

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Abflussverzoegerung mit Kalinin-Miljukov Parametern

 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 dt [h]:   0.08      tmax [d]:     4.93


 Kennwerte Zuflusswelle
 ----------------------

 Scheitel-Zufluss               iqzmax =   1420   qzmax =       0.330 [m**3/s]
 Scheitel-Zufluss im Gerinne    iqzfmx =   1441  qzfmax =       0.242 [m**3/s]
 Scheitel-Zufluss im Vorland    iqzvmx =   1420  qzvmax =       0.092 [m**3/s]

 Fuelle-Zufluss                   fuqz =   0.0130 [hm**3]
 Fuelle-zufluss im Gerinne       fuqzf =   0.0119 [hm**3]
 Fuelle-zufluss im Vorland       fuqzv =   0.0011 [hm**3]


 Kennwerte der Systemfunktionen
 -------------------------------

 Anzahl der Zeitschritte  ituh =     34
 Maximum u                imax =      3     umax = 0.173632
 Summe u                   suu = 1.000082   suuh = 1.000000


 tmax [d]:     4.93


 Kennwerte Ausflusswelle
 -----------------------


 Endordinate Ausfluss           qaend =   0.000

 Scheitel-Ausfluss              iqmax =   1420    qmax =       0.330 [m**3/s]


 Fuelle-Ausfluss                  fuq =   0.0130 [hm**3]

 Fuelle-Ausfluss im Gerinne      fuqa =   0.0119 [hm**3]

 Fuelle-Ausfluss im vorland      fuqa =   0.0011 [hm**3]


 Scheitel-Ausfluss im Gerinne  iqamax =   1442   qamax =       0.242 [m**3/s]

 Scheitel-Ausfluss im Vorland  iqamax =   1420   qamax =       0.092 [m**3/s]


 Gesamtzuflusswelle (ohne Basisabfluss)  sqz =       43.249
 Gesamtabflusswelle    "       "         sq  =       43.246


 Keine angeschlossenen Teilgebiete an Strang      4501
 Auswertung des Stranges:         4502

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Aufruf der Speicherroutine 


 zufluss-fuelle [hm]        0.022065 speicher 4502
 zusaetzl.zufl im nachl.ast [hm]  0.000772

 speicher   0.022837 abfluss-fuelle [hm]      4502

 speicherinhaltsaenderung [hm]  0.000000
 Keine angeschlossenen Teilgebiete an Strang      4502
 Auswertung des Stranges:         4506

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Abflussverzoegerung mit Kalinin-Miljukov Parametern

 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 dt [h]:   0.08      tmax [d]:     4.93


 Kennwerte Zuflusswelle
 ----------------------

 Scheitel-Zufluss               iqzmax =   1420   qzmax =       0.629 [m**3/s]
 Scheitel-Zufluss im Gerinne    iqzfmx =   1478  qzfmax =       0.242 [m**3/s]
 Scheitel-Zufluss im Vorland    iqzvmx =   1420  qzvmax =       0.521 [m**3/s]

 Fuelle-Zufluss                   fuqz =   0.0228 [hm**3]
 Fuelle-zufluss im Gerinne       fuqzf =   0.0142 [hm**3]
 Fuelle-zufluss im Vorland       fuqzv =   0.0086 [hm**3]


 Kennwerte der Systemfunktionen
 -------------------------------

 Anzahl der Zeitschritte  ituh =     34
 Maximum u                imax =      3     umax = 0.173632
 Summe u                   suu = 1.000082   suuh = 1.000000


 tmax [d]:     4.94


 Kennwerte Ausflusswelle
 -----------------------


 Endordinate Ausfluss           qaend =   0.000

 Scheitel-Ausfluss              iqmax =   1423    qmax =       0.626 [m**3/s]


 Fuelle-Ausfluss                  fuq =   0.0227 [hm**3]

 Fuelle-Ausfluss im Gerinne      fuqa =   0.0142 [hm**3]

 Fuelle-Ausfluss im vorland      fuqa =   0.0085 [hm**3]


 Scheitel-Ausfluss im Gerinne  iqamax =   1480   qamax =       0.241 [m**3/s]

 Scheitel-Ausfluss im Vorland  iqamax =   1424   qamax =       0.518 [m**3/s]


 Gesamtzuflusswelle (ohne Basisabfluss)  sqz =       76.166
 Gesamtabflusswelle    "       "         sq  =       75.826


 Keine angeschlossenen Teilgebiete an Strang      4506
 Auswertung des Stranges:         4510

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Abflussverzoegerung mit Kalinin-Miljukov Parametern

 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 dt [h]:   0.08      tmax [d]:     4.93


 Kennwerte Zuflusswelle
 ----------------------

 Scheitel-Zufluss               iqzmax =   1421   qzmax =       1.093 [m**3/s]
 Scheitel-Zufluss im Gerinne    iqzfmx =   1421  qzfmax =       1.093 [m**3/s]
 Scheitel-Zufluss im Vorland    iqzvmx =      0  qzvmax =       0.000 [m**3/s]

 Fuelle-Zufluss                   fuqz =   0.0442 [hm**3]
 Fuelle-zufluss im Gerinne       fuqzf =   0.0442 [hm**3]
 Fuelle-zufluss im Vorland       fuqzv =   0.0000 [hm**3]


 Kennwerte der Systemfunktionen
 -------------------------------

 Anzahl der Zeitschritte  ituh =    357
 Maximum u                imax =      1     umax = 0.272856
 Summe u                   suu = 0.654153   suuh = 1.000000


 tmax [d]:     4.95


 Kennwerte Ausflusswelle
 -----------------------

 Endordinate Ausfluss           qaend =   0.000
 Scheitel-Ausfluss              iqmax =   1426    qmax =       1.051 [m**3/s]

 Fuelle-Ausfluss                  fuq =   0.0442 [hm**3]
 Fuelle-Ausfluss im Gerinne      fuqa =   0.0442 [hm**3]

 Scheitel-Ausfluss im Gerinne  iqamax =   1426   qamax =       1.051 [m**3/s]


 Gesamtzuflusswelle (ohne Basisabfluss)  sqz =      147.310
 Gesamtabflusswelle    "       "         sq  =      147.309


 Keine angeschlossenen Teilgebiete an Strang      4510
 Auswertung des Stranges:         4526

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Abflussverzoegerung mit Kalinin-Miljukov Parametern

 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 dt [h]:   0.08      tmax [d]:     4.92


 Kennwerte Zuflusswelle
 ----------------------

 Scheitel-Zufluss               iqzmax =   1417   qzmax =       1.862 [m**3/s]
 Scheitel-Zufluss im Gerinne    iqzfmx =   1417  qzfmax =       1.862 [m**3/s]
 Scheitel-Zufluss im Vorland    iqzvmx =      0  qzvmax =       0.000 [m**3/s]

 Fuelle-Zufluss                   fuqz =   0.0710 [hm**3]
 Fuelle-zufluss im Gerinne       fuqzf =   0.0710 [hm**3]
 Fuelle-zufluss im Vorland       fuqzv =   0.0000 [hm**3]


 Kennwerte der Systemfunktionen
 -------------------------------

 Anzahl der Zeitschritte  ituh =     27
 Maximum u                imax =      1     umax = 0.557957
 Summe u                   suu = 0.784427   suuh = 1.000000


 tmax [d]:     4.92


 Kennwerte Ausflusswelle
 -----------------------

 Endordinate Ausfluss           qaend =   0.000
 Scheitel-Ausfluss              iqmax =   1418    qmax =       1.859 [m**3/s]

 Fuelle-Ausfluss                  fuq =   0.0710 [hm**3]
 Fuelle-Ausfluss im Gerinne      fuqa =   0.0710 [hm**3]

 Scheitel-Ausfluss im Gerinne  iqamax =   1418   qamax =       1.859 [m**3/s]


 Gesamtzuflusswelle (ohne Basisabfluss)  sqz =      236.625
 Gesamtabflusswelle    "       "         sq  =      236.625


 Keine angeschlossenen Teilgebiete an Strang      4526
 Auswertung des Stranges:         4532

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Abflussverzoegerung mit Kalinin-Miljukov Parametern

 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 dt [h]:   0.08      tmax [d]:     4.94


 Kennwerte Zuflusswelle
 ----------------------

 Scheitel-Zufluss               iqzmax =   1423   qzmax =       2.652 [m**3/s]
 Scheitel-Zufluss im Gerinne    iqzfmx =   1423  qzfmax =       1.710 [m**3/s]
 Scheitel-Zufluss im Vorland    iqzvmx =   1423  qzvmax =       0.942 [m**3/s]

 Fuelle-Zufluss                   fuqz =   0.1071 [hm**3]
 Fuelle-zufluss im Gerinne       fuqzf =   0.0934 [hm**3]
 Fuelle-zufluss im Vorland       fuqzv =   0.0138 [hm**3]


 Kennwerte der Systemfunktionen
 -------------------------------

 Anzahl der Zeitschritte  ituh =     58
 Maximum u                imax =      1     umax = 0.450462
 Summe u                   suu = 0.778253   suuh = 0.999630


 tmax [d]:     4.95


 Kennwerte Ausflusswelle
 -----------------------


 Endordinate Ausfluss           qaend =   0.000

 Scheitel-Ausfluss              iqmax =   1425    qmax =       2.619 [m**3/s]


 Fuelle-Ausfluss                  fuq =   0.1071 [hm**3]

 Fuelle-Ausfluss im Gerinne      fuqa =   0.0933 [hm**3]

 Fuelle-Ausfluss im vorland      fuqa =   0.0138 [hm**3]


 Scheitel-Ausfluss im Gerinne  iqamax =   1431   qamax =       1.700 [m**3/s]

 Scheitel-Ausfluss im Vorland  iqamax =   1425   qamax =       0.923 [m**3/s]


 Gesamtzuflusswelle (ohne Basisabfluss)  sqz =      357.068
 Gesamtabflusswelle    "       "         sq  =      356.955


 Keine angeschlossenen Teilgebiete an Strang      4532
 Auswertung des Stranges:         4563

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Abflussverzoegerung mit Kalinin-Miljukov Parametern

 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 dt [h]:   0.08      tmax [d]:     4.94


 Kennwerte Zuflusswelle
 ----------------------

 Scheitel-Zufluss               iqzmax =   1424   qzmax =       2.822 [m**3/s]
 Scheitel-Zufluss im Gerinne    iqzfmx =   1424  qzfmax =       2.822 [m**3/s]
 Scheitel-Zufluss im Vorland    iqzvmx =      0  qzvmax =       0.000 [m**3/s]

 Fuelle-Zufluss                   fuqz =   0.1146 [hm**3]
 Fuelle-zufluss im Gerinne       fuqzf =   0.1146 [hm**3]
 Fuelle-zufluss im Vorland       fuqzv =   0.0000 [hm**3]


 Kennwerte der Systemfunktionen
 -------------------------------

 Anzahl der Zeitschritte  ituh =     27
 Maximum u                imax =      1     umax = 0.557957
 Summe u                   suu = 0.784427   suuh = 1.000000


 tmax [d]:     4.95


 Kennwerte Ausflusswelle
 -----------------------

 Endordinate Ausfluss           qaend =   0.000
 Scheitel-Ausfluss              iqmax =   1425    qmax =       2.819 [m**3/s]

 Fuelle-Ausfluss                  fuq =   0.1146 [hm**3]
 Fuelle-Ausfluss im Gerinne      fuqa =   0.1146 [hm**3]

 Scheitel-Ausfluss im Gerinne  iqamax =   1425   qamax =       2.819 [m**3/s]


 Gesamtzuflusswelle (ohne Basisabfluss)  sqz =      382.050
 Gesamtabflusswelle    "       "         sq  =      382.050


 Keine angeschlossenen Teilgebiete an Strang      4563
 Auswertung des Stranges:         4541

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.

 Keine angeschlossenen Teilgebiete an Strang      4541
 Auswertung des Stranges:         4534

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.

 Keine angeschlossenen Teilgebiete an Strang      4534
 Auswertung des Stranges:         4535

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Abflussverzoegerung mit Kalinin-Miljukov Parametern

 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 dt [h]:   0.08      tmax [d]:     4.80


 Kennwerte Zuflusswelle
 ----------------------

 Scheitel-Zufluss               iqzmax =   1383   qzmax =       0.782 [m**3/s]
 Scheitel-Zufluss im Gerinne    iqzfmx =   1383  qzfmax =       0.782 [m**3/s]
 Scheitel-Zufluss im Vorland    iqzvmx =      0  qzvmax =       0.000 [m**3/s]

 Fuelle-Zufluss                   fuqz =   0.0086 [hm**3]
 Fuelle-zufluss im Gerinne       fuqzf =   0.0086 [hm**3]
 Fuelle-zufluss im Vorland       fuqzv =   0.0000 [hm**3]


 Kennwerte der Systemfunktionen
 -------------------------------

 Anzahl der Zeitschritte  ituh =     18
 Maximum u                imax =      3     umax = 0.269426
 Summe u                   suu = 0.999998   suuh = 1.000000


 tmax [d]:     4.81


 Kennwerte Ausflusswelle
 -----------------------

 Endordinate Ausfluss           qaend =   0.000
 Scheitel-Ausfluss              iqmax =   1386    qmax =       0.714 [m**3/s]

 Fuelle-Ausfluss                  fuq =   0.0086 [hm**3]
 Fuelle-Ausfluss im Gerinne      fuqa =   0.0086 [hm**3]

 Scheitel-Ausfluss im Gerinne  iqamax =   1386   qamax =       0.714 [m**3/s]


 Gesamtzuflusswelle (ohne Basisabfluss)  sqz =       28.687
 Gesamtabflusswelle    "       "         sq  =       28.687


 Keine angeschlossenen Teilgebiete an Strang      4535
 Auswertung des Stranges:         4536

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Aufruf der Speicherroutine 


 zufluss-fuelle [hm]        0.011623 speicher 4536
 zusaetzl.zufl im nachl.ast [hm]  0.000167

 speicher   0.011789 abfluss-fuelle [hm]      4536

 speicherinhaltsaenderung [hm]  0.000000
 Keine angeschlossenen Teilgebiete an Strang      4536
 Auswertung des Stranges:         4612

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Fiktiver Strang! Es erfolgt keine Abflussverzoegerung!
 Keine angeschlossenen Teilgebiete an Strang      4612
 Auswertung des Stranges:         4537

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.

 Keine angeschlossenen Teilgebiete an Strang      4537
 Auswertung des Stranges:         4538

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Abflussverzoegerung mit Kalinin-Miljukov Parametern

 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 dt [h]:   0.08      tmax [d]:     4.83


 Kennwerte Zuflusswelle
 ----------------------

 Scheitel-Zufluss               iqzmax =   1390   qzmax =       0.062 [m**3/s]
 Scheitel-Zufluss im Gerinne    iqzfmx =   1390  qzfmax =       0.062 [m**3/s]
 Scheitel-Zufluss im Vorland    iqzvmx =      0  qzvmax =       0.000 [m**3/s]

 Fuelle-Zufluss                   fuqz =   0.0011 [hm**3]
 Fuelle-zufluss im Gerinne       fuqzf =   0.0011 [hm**3]
 Fuelle-zufluss im Vorland       fuqzv =   0.0000 [hm**3]


 Kennwerte der Systemfunktionen
 -------------------------------

 Anzahl der Zeitschritte  ituh =     25
 Maximum u                imax =      1     umax = 0.540740
 Summe u                   suu = 0.727210   suuh = 1.000000


 tmax [d]:     4.83


 Kennwerte Ausflusswelle
 -----------------------

 Endordinate Ausfluss           qaend =   0.000
 Scheitel-Ausfluss              iqmax =   1391    qmax =       0.061 [m**3/s]

 Fuelle-Ausfluss                  fuq =   0.0011 [hm**3]
 Fuelle-Ausfluss im Gerinne      fuqa =   0.0011 [hm**3]

 Scheitel-Ausfluss im Gerinne  iqamax =   1391   qamax =       0.061 [m**3/s]


 Gesamtzuflusswelle (ohne Basisabfluss)  sqz =        3.823
 Gesamtabflusswelle    "       "         sq  =        3.823


 Keine angeschlossenen Teilgebiete an Strang      4538
 Auswertung des Stranges:         4539

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Abflussverzoegerung mit Kalinin-Miljukov Parametern

 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 dt [h]:   0.08      tmax [d]:     4.82


 Kennwerte Zuflusswelle
 ----------------------

 Scheitel-Zufluss               iqzmax =   1388   qzmax =       0.858 [m**3/s]
 Scheitel-Zufluss im Gerinne    iqzfmx =   1388  qzfmax =       0.686 [m**3/s]
 Scheitel-Zufluss im Vorland    iqzvmx =   1388  qzvmax =       0.172 [m**3/s]

 Fuelle-Zufluss                   fuqz =   0.0129 [hm**3]
 Fuelle-zufluss im Gerinne       fuqzf =   0.0126 [hm**3]
 Fuelle-zufluss im Vorland       fuqzv =   0.0004 [hm**3]


 Kennwerte der Systemfunktionen
 -------------------------------

 Anzahl der Zeitschritte  ituh =   2880
 Maximum u                imax =      1     umax = 0.000000
 Summe u                   suu = 0.000000   suuh = 0.000000


 tmax [d]:     4.82


 Kennwerte Ausflusswelle
 -----------------------


 Endordinate Ausfluss           qaend =   0.000

 Scheitel-Ausfluss              iqmax =   1389    qmax =       0.834 [m**3/s]


 Fuelle-Ausfluss                  fuq =   0.0129 [hm**3]

 Fuelle-Ausfluss im Gerinne      fuqa =   0.0126 [hm**3]

 Fuelle-Ausfluss im vorland      fuqa =   0.0004 [hm**3]


 Scheitel-Ausfluss im Gerinne  iqamax =   1389   qamax =       0.669 [m**3/s]

 Scheitel-Ausfluss im Vorland  iqamax =   1389   qamax =       0.165 [m**3/s]


 Gesamtzuflusswelle (ohne Basisabfluss)  sqz =       43.144
 Gesamtabflusswelle    "       "         sq  =       43.143


 Keine angeschlossenen Teilgebiete an Strang      4539
 Auswertung des Stranges:         4540

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Aufruf der Speicherroutine 


 zufluss-fuelle [hm]        0.041937 speicher 4540
 zusaetzl.zufl im nachl.ast [hm]  0.000292

 speicher   0.042156 abfluss-fuelle [hm]      4540

 speicherinhaltsaenderung [hm]  0.000000
 Keine angeschlossenen Teilgebiete an Strang      4540
 Auswertung des Stranges:         4613

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Fiktiver Strang! Es erfolgt keine Abflussverzoegerung!
 Keine angeschlossenen Teilgebiete an Strang      4613
 Auswertung des Stranges:         4546

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Abflussverzoegerung mit Kalinin-Miljukov Parametern

 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 dt [h]:   0.08      tmax [d]:     4.82


 Kennwerte Zuflusswelle
 ----------------------

 Scheitel-Zufluss               iqzmax =   1388   qzmax =       3.460 [m**3/s]
 Scheitel-Zufluss im Gerinne    iqzfmx =   1388  qzfmax =       2.768 [m**3/s]
 Scheitel-Zufluss im Vorland    iqzvmx =   1388  qzvmax =       0.692 [m**3/s]

 Fuelle-Zufluss                   fuqz =   0.0515 [hm**3]
 Fuelle-zufluss im Gerinne       fuqzf =   0.0466 [hm**3]
 Fuelle-zufluss im Vorland       fuqzv =   0.0050 [hm**3]


 Kennwerte der Systemfunktionen
 -------------------------------

 Anzahl der Zeitschritte  ituh =   2880
 Maximum u                imax =      1     umax = 0.000000
 Summe u                   suu = 0.000000   suuh = 0.000000


 tmax [d]:     4.82


 Kennwerte Ausflusswelle
 -----------------------


 Endordinate Ausfluss           qaend =   0.000

 Scheitel-Ausfluss              iqmax =   1389    qmax =       3.401 [m**3/s]


 Fuelle-Ausfluss                  fuq =   0.0515 [hm**3]

 Fuelle-Ausfluss im Gerinne      fuqa =   0.0466 [hm**3]

 Fuelle-Ausfluss im vorland      fuqa =   0.0050 [hm**3]


 Scheitel-Ausfluss im Gerinne  iqamax =   1389   qamax =       2.721 [m**3/s]

 Scheitel-Ausfluss im Vorland  iqamax =   1389   qamax =       0.680 [m**3/s]


 Gesamtzuflusswelle (ohne Basisabfluss)  sqz =      171.821
 Gesamtabflusswelle    "       "         sq  =      171.821


 Keine angeschlossenen Teilgebiete an Strang      4546
 Auswertung des Stranges:         4543

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.

 Keine angeschlossenen Teilgebiete an Strang      4543
 Auswertung des Stranges:         4544

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Abflussverzoegerung mit Kalinin-Miljukov Parametern

 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 dt [h]:   0.08      tmax [d]:     4.82


 Kennwerte Zuflusswelle
 ----------------------

 Scheitel-Zufluss               iqzmax =   1389   qzmax =       1.495 [m**3/s]
 Scheitel-Zufluss im Gerinne    iqzfmx =   1389  qzfmax =       1.196 [m**3/s]
 Scheitel-Zufluss im Vorland    iqzvmx =   1389  qzvmax =       0.299 [m**3/s]

 Fuelle-Zufluss                   fuqz =   0.0180 [hm**3]
 Fuelle-zufluss im Gerinne       fuqzf =   0.0165 [hm**3]
 Fuelle-zufluss im Vorland       fuqzv =   0.0015 [hm**3]


 Kennwerte der Systemfunktionen
 -------------------------------

 Anzahl der Zeitschritte  ituh =   2880
 Maximum u                imax =      1     umax = 0.000000
 Summe u                   suu = 0.000000   suuh = 0.000000


 tmax [d]:     4.82


 Kennwerte Ausflusswelle
 -----------------------


 Endordinate Ausfluss           qaend =   0.006

 Scheitel-Ausfluss              iqmax =   1389    qmax =       1.475 [m**3/s]


 Fuelle-Ausfluss                  fuq =   0.0180 [hm**3]

 Fuelle-Ausfluss im Gerinne      fuqa =   0.0165 [hm**3]

 Fuelle-Ausfluss im vorland      fuqa =   0.0015 [hm**3]


 Scheitel-Ausfluss im Gerinne  iqamax =   1389   qamax =       1.181 [m**3/s]

 Scheitel-Ausfluss im Vorland  iqamax =   1389   qamax =       0.295 [m**3/s]


 Gesamtzuflusswelle (ohne Basisabfluss)  sqz =       60.126
 Gesamtabflusswelle    "       "         sq  =       60.130


 Keine angeschlossenen Teilgebiete an Strang      4544
 Auswertung des Stranges:         4545

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Aufruf der Speicherroutine 


 zufluss-fuelle [hm]        0.024709 speicher 4545
 zusaetzl.zufl im nachl.ast [hm]  0.000019

 speicher   0.023297 abfluss-fuelle [hm]      4545
 abfluss-fuelle [hm]  0.0014 ueberlauf 

 speicherinhaltsaenderung [hm]  0.000000
 Keine angeschlossenen Teilgebiete an Strang      4545
 Auswertung des Stranges:         4547

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Abflussverzoegerung mit Kalinin-Miljukov Parametern

 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 dt [h]:   0.08      tmax [d]:     4.83


 Kennwerte Zuflusswelle
 ----------------------

 Scheitel-Zufluss               iqzmax =   1391   qzmax =       1.035 [m**3/s]
 Scheitel-Zufluss im Gerinne    iqzfmx =   1391  qzfmax =       1.035 [m**3/s]
 Scheitel-Zufluss im Vorland    iqzvmx =      0  qzvmax =       0.000 [m**3/s]

 Fuelle-Zufluss                   fuqz =   0.0233 [hm**3]
 Fuelle-zufluss im Gerinne       fuqzf =   0.0233 [hm**3]
 Fuelle-zufluss im Vorland       fuqzv =   0.0000 [hm**3]


 Kennwerte der Systemfunktionen
 -------------------------------

 Anzahl der Zeitschritte  ituh =   2880
 Maximum u                imax =      1     umax = 0.000000
 Summe u                   suu = 0.000000   suuh = 0.000000


 tmax [d]:     0.00


 Kennwerte Ausflusswelle
 -----------------------


 Endordinate Ausfluss           qaend =   0.007

 Scheitel-Ausfluss              iqmax =   1401    qmax =       1.035 [m**3/s]


 Fuelle-Ausfluss                  fuq =   0.0233 [hm**3]

 Fuelle-Ausfluss im Gerinne      fuqa =   0.0233 [hm**3]

 Fuelle-Ausfluss im vorland      fuqa =   0.0000 [hm**3]


 Scheitel-Ausfluss im Gerinne  iqamax =   1401   qamax =       1.035 [m**3/s]

 Scheitel-Ausfluss im Vorland  iqamax =      0   qamax =       0.000 [m**3/s]


 Gesamtzuflusswelle (ohne Basisabfluss)  sqz =       77.672
 Gesamtabflusswelle    "       "         sq  =       77.678


 Keine angeschlossenen Teilgebiete an Strang      4547
 Auswertung des Stranges:         4548

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Abflussverzoegerung mit Kalinin-Miljukov Parametern

 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 dt [h]:   0.08      tmax [d]:     4.83


 Kennwerte Zuflusswelle
 ----------------------

 Scheitel-Zufluss               iqzmax =   1390   qzmax =       4.572 [m**3/s]
 Scheitel-Zufluss im Gerinne    iqzfmx =   1390  qzfmax =       3.658 [m**3/s]
 Scheitel-Zufluss im Vorland    iqzvmx =   1390  qzvmax =       0.914 [m**3/s]

 Fuelle-Zufluss                   fuqz =   0.0858 [hm**3]
 Fuelle-zufluss im Gerinne       fuqzf =   0.0753 [hm**3]
 Fuelle-zufluss im Vorland       fuqzv =   0.0105 [hm**3]


 Kennwerte der Systemfunktionen
 -------------------------------

 Anzahl der Zeitschritte  ituh =   2880
 Maximum u                imax =      1     umax = 0.000000
 Summe u                   suu = 0.000000   suuh = 0.000000


 tmax [d]:     4.83


 Kennwerte Ausflusswelle
 -----------------------


 Endordinate Ausfluss           qaend =   0.001

 Scheitel-Ausfluss              iqmax =   1390    qmax =       4.515 [m**3/s]


 Fuelle-Ausfluss                  fuq =   0.0858 [hm**3]

 Fuelle-Ausfluss im Gerinne      fuqa =   0.0753 [hm**3]

 Fuelle-Ausfluss im vorland      fuqa =   0.0105 [hm**3]


 Scheitel-Ausfluss im Gerinne  iqamax =   1390   qamax =       3.612 [m**3/s]

 Scheitel-Ausfluss im Vorland  iqamax =   1390   qamax =       0.903 [m**3/s]


 Gesamtzuflusswelle (ohne Basisabfluss)  sqz =      285.911
 Gesamtabflusswelle    "       "         sq  =      285.912


 Keine angeschlossenen Teilgebiete an Strang      4548
 Auswertung des Stranges:         4549

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.

 Keine angeschlossenen Teilgebiete an Strang      4549
 Auswertung des Stranges:         4550

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Aufruf der Speicherroutine 


 zufluss-fuelle [hm]        0.016071 speicher 4550
 zusaetzl.zufl im nachl.ast [hm]  0.000019

 speicher   0.016090 abfluss-fuelle [hm]      4550
 abfluss-fuelle [hm]  0.0000 ueberlauf 

 speicherinhaltsaenderung [hm]  0.000001
 Keine angeschlossenen Teilgebiete an Strang      4550
 Auswertung des Stranges:         4551

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Abflussverzoegerung mit Kalinin-Miljukov Parametern

 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 dt [h]:   0.08      tmax [d]:     4.91


 Kennwerte Zuflusswelle
 ----------------------

 Scheitel-Zufluss               iqzmax =   1415   qzmax =       0.276 [m**3/s]
 Scheitel-Zufluss im Gerinne    iqzfmx =   1415  qzfmax =       0.276 [m**3/s]
 Scheitel-Zufluss im Vorland    iqzvmx =      0  qzvmax =       0.000 [m**3/s]

 Fuelle-Zufluss                   fuqz =   0.0161 [hm**3]
 Fuelle-zufluss im Gerinne       fuqzf =   0.0161 [hm**3]
 Fuelle-zufluss im Vorland       fuqzv =   0.0000 [hm**3]


 Kennwerte der Systemfunktionen
 -------------------------------

 Anzahl der Zeitschritte  ituh =     25
 Maximum u                imax =      1     umax = 0.540740
 Summe u                   suu = 0.727210   suuh = 1.000000


 tmax [d]:     4.92


 Kennwerte Ausflusswelle
 -----------------------

 Endordinate Ausfluss           qaend =   0.000
 Scheitel-Ausfluss              iqmax =   1416    qmax =       0.276 [m**3/s]

 Fuelle-Ausfluss                  fuq =   0.0161 [hm**3]
 Fuelle-Ausfluss im Gerinne      fuqa =   0.0161 [hm**3]

 Scheitel-Ausfluss im Gerinne  iqamax =   1416   qamax =       0.276 [m**3/s]


 Gesamtzuflusswelle (ohne Basisabfluss)  sqz =       53.635
 Gesamtabflusswelle    "       "         sq  =       53.634


 Keine angeschlossenen Teilgebiete an Strang      4551
 Auswertung des Stranges:         4553

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Abflussverzoegerung mit Kalinin-Miljukov Parametern

 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 dt [h]:   0.08      tmax [d]:     4.82


 Kennwerte Zuflusswelle
 ----------------------

 Scheitel-Zufluss               iqzmax =   1389   qzmax =       6.396 [m**3/s]
 Scheitel-Zufluss im Gerinne    iqzfmx =   1389  qzfmax =       6.396 [m**3/s]
 Scheitel-Zufluss im Vorland    iqzvmx =      0  qzvmax =       0.000 [m**3/s]

 Fuelle-Zufluss                   fuqz =   0.1274 [hm**3]
 Fuelle-zufluss im Gerinne       fuqzf =   0.1274 [hm**3]
 Fuelle-zufluss im Vorland       fuqzv =   0.0000 [hm**3]


 Kennwerte der Systemfunktionen
 -------------------------------

 Anzahl der Zeitschritte  ituh =   2880
 Maximum u                imax =      1     umax = 0.000000
 Summe u                   suu = 0.000000   suuh = 0.000000


 tmax [d]:     0.00


 Kennwerte Ausflusswelle
 -----------------------


 Endordinate Ausfluss           qaend =   0.004

 Scheitel-Ausfluss              iqmax =   1392    qmax =       6.294 [m**3/s]


 Fuelle-Ausfluss                  fuq =   0.1274 [hm**3]

 Fuelle-Ausfluss im Gerinne      fuqa =   0.1274 [hm**3]

 Fuelle-Ausfluss im vorland      fuqa =   0.0000 [hm**3]


 Scheitel-Ausfluss im Gerinne  iqamax =   1392   qamax =       6.294 [m**3/s]

 Scheitel-Ausfluss im Vorland  iqamax =      0   qamax =       0.000 [m**3/s]


 Gesamtzuflusswelle (ohne Basisabfluss)  sqz =      424.616
 Gesamtabflusswelle    "       "         sq  =      424.621


 Keine angeschlossenen Teilgebiete an Strang      4553
 Auswertung des Stranges:         4559

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Abflussverzoegerung mit Kalinin-Miljukov Parametern

 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 dt [h]:   0.08      tmax [d]:     4.83


 Kennwerte Zuflusswelle
 ----------------------

 Scheitel-Zufluss               iqzmax =   1392   qzmax =       6.431 [m**3/s]
 Scheitel-Zufluss im Gerinne    iqzfmx =   1392  qzfmax =       5.145 [m**3/s]
 Scheitel-Zufluss im Vorland    iqzvmx =   1392  qzvmax =       1.286 [m**3/s]

 Fuelle-Zufluss                   fuqz =   0.1326 [hm**3]
 Fuelle-zufluss im Gerinne       fuqzf =   0.1134 [hm**3]
 Fuelle-zufluss im Vorland       fuqzv =   0.0192 [hm**3]


 Kennwerte der Systemfunktionen
 -------------------------------

 Anzahl der Zeitschritte  ituh =   2880
 Maximum u                imax =      1     umax = 0.000000
 Summe u                   suu = 0.000000   suuh = 0.000000


 tmax [d]:     4.84


 Kennwerte Ausflusswelle
 -----------------------


 Endordinate Ausfluss           qaend =   0.005

 Scheitel-Ausfluss              iqmax =   1393    qmax =       6.360 [m**3/s]


 Fuelle-Ausfluss                  fuq =   0.1326 [hm**3]

 Fuelle-Ausfluss im Gerinne      fuqa =   0.1134 [hm**3]

 Fuelle-Ausfluss im vorland      fuqa =   0.0192 [hm**3]


 Scheitel-Ausfluss im Gerinne  iqamax =   1393   qamax =       5.088 [m**3/s]

 Scheitel-Ausfluss im Vorland  iqamax =   1393   qamax =       1.272 [m**3/s]


 Gesamtzuflusswelle (ohne Basisabfluss)  sqz =      441.986
 Gesamtabflusswelle    "       "         sq  =      441.987


 Keine angeschlossenen Teilgebiete an Strang      4559
 Auswertung des Stranges:         4554

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.

 Keine angeschlossenen Teilgebiete an Strang      4554
 Auswertung des Stranges:         4555

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Aufruf der Speicherroutine 


 zufluss-fuelle [hm]        0.010804 speicher 4555
 zusaetzl.zufl im nachl.ast [hm]  0.000003

 speicher   0.010806 abfluss-fuelle [hm]      4555
 abfluss-fuelle [hm]  0.0000 ueberlauf 

 speicherinhaltsaenderung [hm]  0.000053
 Keine angeschlossenen Teilgebiete an Strang      4555
 Auswertung des Stranges:         4556

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Abflussverzoegerung mit Kalinin-Miljukov Parametern

 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 dt [h]:   0.08      tmax [d]:     4.85


 Kennwerte Zuflusswelle
 ----------------------

 Scheitel-Zufluss               iqzmax =   1398   qzmax =       0.487 [m**3/s]
 Scheitel-Zufluss im Gerinne    iqzfmx =   1398  qzfmax =       0.487 [m**3/s]
 Scheitel-Zufluss im Vorland    iqzvmx =      0  qzvmax =       0.000 [m**3/s]

 Fuelle-Zufluss                   fuqz =   0.0108 [hm**3]
 Fuelle-zufluss im Gerinne       fuqzf =   0.0108 [hm**3]
 Fuelle-zufluss im Vorland       fuqzv =   0.0000 [hm**3]


 Kennwerte der Systemfunktionen
 -------------------------------

 Anzahl der Zeitschritte  ituh =     25
 Maximum u                imax =      1     umax = 0.540740
 Summe u                   suu = 0.727210   suuh = 1.000000


 tmax [d]:     4.85


 Kennwerte Ausflusswelle
 -----------------------

 Endordinate Ausfluss           qaend =   0.000
 Scheitel-Ausfluss              iqmax =   1398    qmax =       0.485 [m**3/s]

 Fuelle-Ausfluss                  fuq =   0.0108 [hm**3]
 Fuelle-Ausfluss im Gerinne      fuqa =   0.0108 [hm**3]

 Scheitel-Ausfluss im Gerinne  iqamax =   1398   qamax =       0.485 [m**3/s]


 Gesamtzuflusswelle (ohne Basisabfluss)  sqz =       36.024
 Gesamtabflusswelle    "       "         sq  =       36.025


 Keine angeschlossenen Teilgebiete an Strang      4556
 Auswertung des Stranges:         4557

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Aufruf der Speicherroutine 


 zufluss-fuelle [hm]        0.030278 speicher 4557
 zusaetzl.zufl im nachl.ast [hm]  0.000049

 speicher   0.030323 abfluss-fuelle [hm]      4557
 abfluss-fuelle [hm]  0.0000 ueberlauf 

 speicherinhaltsaenderung [hm]  0.000006
 Keine angeschlossenen Teilgebiete an Strang      4557
 Auswertung des Stranges:         4558

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Abflussverzoegerung mit Kalinin-Miljukov Parametern

 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 dt [h]:   0.08      tmax [d]:     4.87


 Kennwerte Zuflusswelle
 ----------------------

 Scheitel-Zufluss               iqzmax =   1403   qzmax =       1.224 [m**3/s]
 Scheitel-Zufluss im Gerinne    iqzfmx =   1403  qzfmax =       0.979 [m**3/s]
 Scheitel-Zufluss im Vorland    iqzvmx =   1403  qzvmax =       0.245 [m**3/s]

 Fuelle-Zufluss                   fuqz =   0.0303 [hm**3]
 Fuelle-zufluss im Gerinne       fuqzf =   0.0273 [hm**3]
 Fuelle-zufluss im Vorland       fuqzv =   0.0030 [hm**3]


 Kennwerte der Systemfunktionen
 -------------------------------

 Anzahl der Zeitschritte  ituh =   2880
 Maximum u                imax =      1     umax = 0.000000
 Summe u                   suu = 0.000000   suuh = 0.000000


 tmax [d]:     4.88


 Kennwerte Ausflusswelle
 -----------------------


 Endordinate Ausfluss           qaend =   0.003

 Scheitel-Ausfluss              iqmax =   1404    qmax =       1.223 [m**3/s]


 Fuelle-Ausfluss                  fuq =   0.0303 [hm**3]

 Fuelle-Ausfluss im Gerinne      fuqa =   0.0273 [hm**3]

 Fuelle-Ausfluss im vorland      fuqa =   0.0030 [hm**3]


 Scheitel-Ausfluss im Gerinne  iqamax =   1404   qamax =       0.978 [m**3/s]

 Scheitel-Ausfluss im Vorland  iqamax =   1404   qamax =       0.245 [m**3/s]


 Gesamtzuflusswelle (ohne Basisabfluss)  sqz =      101.090
 Gesamtabflusswelle    "       "         sq  =      101.093


 Keine angeschlossenen Teilgebiete an Strang      4558
 Auswertung des Stranges:         4561

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Aufruf der Speicherroutine 


 zufluss-fuelle [hm]        0.190600 speicher 4561
 zusaetzl.zufl im nachl.ast [hm]  0.000990

 speicher   0.173024 abfluss-fuelle [hm]      4561
 abfluss-fuelle [hm]  0.0181 ueberlauf 

 speicherinhaltsaenderung [hm]  0.000002
 Keine angeschlossenen Teilgebiete an Strang      4561
 Auswertung des Stranges:         4562

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Abflussverzoegerung mit Kalinin-Miljukov Parametern

 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 dt [h]:   0.08      tmax [d]:     4.84


 Kennwerte Zuflusswelle
 ----------------------

 Scheitel-Zufluss               iqzmax =   1394   qzmax =       4.052 [m**3/s]
 Scheitel-Zufluss im Gerinne    iqzfmx =   1394  qzfmax =       3.242 [m**3/s]
 Scheitel-Zufluss im Vorland    iqzvmx =   1422  qzvmax =       0.810 [m**3/s]

 Fuelle-Zufluss                   fuqz =   0.1730 [hm**3]
 Fuelle-zufluss im Gerinne       fuqzf =   0.1466 [hm**3]
 Fuelle-zufluss im Vorland       fuqzv =   0.0264 [hm**3]


 Kennwerte der Systemfunktionen
 -------------------------------

 Anzahl der Zeitschritte  ituh =    109
 Maximum u                imax =     16     umax = 0.040608
 Summe u                   suu = 0.999995   suuh = 1.000000


 tmax [d]:     5.00


 Kennwerte Ausflusswelle
 -----------------------


 Endordinate Ausfluss           qaend =   0.001

 Scheitel-Ausfluss              iqmax =   1425    qmax =       4.011 [m**3/s]


 Fuelle-Ausfluss                  fuq =   0.1730 [hm**3]

 Fuelle-Ausfluss im Gerinne      fuqa =   0.1466 [hm**3]

 Fuelle-Ausfluss im vorland      fuqa =   0.0264 [hm**3]


 Scheitel-Ausfluss im Gerinne  iqamax =   1417   qamax =       3.242 [m**3/s]

 Scheitel-Ausfluss im Vorland  iqamax =   1439   qamax =       0.800 [m**3/s]


 Gesamtzuflusswelle (ohne Basisabfluss)  sqz =      576.767
 Gesamtabflusswelle    "       "         sq  =      576.769


 Keine angeschlossenen Teilgebiete an Strang      4562
 Auswertung des Stranges:         4565

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Abflussverzoegerung mit Kalinin-Miljukov Parametern

 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 dt [h]:   0.08      tmax [d]:     4.95


 Kennwerte Zuflusswelle
 ----------------------

 Scheitel-Zufluss               iqzmax =   1425   qzmax =       6.957 [m**3/s]
 Scheitel-Zufluss im Gerinne    iqzfmx =   1425  qzfmax =       3.589 [m**3/s]
 Scheitel-Zufluss im Vorland    iqzvmx =   1425  qzvmax =       3.368 [m**3/s]

 Fuelle-Zufluss                   fuqz =   0.2968 [hm**3]
 Fuelle-zufluss im Gerinne       fuqzf =   0.1933 [hm**3]
 Fuelle-zufluss im Vorland       fuqzv =   0.1035 [hm**3]


 Kennwerte der Systemfunktionen
 -------------------------------

 Anzahl der Zeitschritte  ituh =     95
 Maximum u                imax =     24     umax = 0.042923
 Summe u                   suu = 0.999996   suuh = 1.000000


 tmax [d]:     5.04


 Kennwerte Ausflusswelle
 -----------------------


 Endordinate Ausfluss           qaend =   0.000

 Scheitel-Ausfluss              iqmax =   1439    qmax =       6.572 [m**3/s]


 Fuelle-Ausfluss                  fuq =   0.2969 [hm**3]

 Fuelle-Ausfluss im Gerinne      fuqa =   0.1931 [hm**3]

 Fuelle-Ausfluss im vorland      fuqa =   0.1038 [hm**3]


 Scheitel-Ausfluss im Gerinne  iqamax =   1427   qamax =       3.576 [m**3/s]

 Scheitel-Ausfluss im Vorland  iqamax =   1452   qamax =       3.276 [m**3/s]


 Gesamtzuflusswelle (ohne Basisabfluss)  sqz =      989.388
 Gesamtabflusswelle    "       "         sq  =      989.757


 Keine angeschlossenen Teilgebiete an Strang      4565
 Auswertung des Stranges:         4569

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Abflussverzoegerung mit Kalinin-Miljukov Parametern

 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 dt [h]:   0.08      tmax [d]:     4.99


 Kennwerte Zuflusswelle
 ----------------------

 Scheitel-Zufluss               iqzmax =   1438   qzmax =       6.731 [m**3/s]
 Scheitel-Zufluss im Gerinne    iqzfmx =   1438  qzfmax =       3.457 [m**3/s]
 Scheitel-Zufluss im Vorland    iqzvmx =   1438  qzvmax =       3.274 [m**3/s]

 Fuelle-Zufluss                   fuqz =   0.3044 [hm**3]
 Fuelle-zufluss im Gerinne       fuqzf =   0.2063 [hm**3]
 Fuelle-zufluss im Vorland       fuqzv =   0.0980 [hm**3]


 Kennwerte der Systemfunktionen
 -------------------------------

 Anzahl der Zeitschritte  ituh =    113
 Maximum u                imax =     14     umax = 0.040531
 Summe u                   suu = 0.999992   suuh = 1.000000


 tmax [d]:     5.07


 Kennwerte Ausflusswelle
 -----------------------


 Endordinate Ausfluss           qaend =   0.000

 Scheitel-Ausfluss              iqmax =   1453    qmax =       6.451 [m**3/s]


 Fuelle-Ausfluss                  fuq =   0.3054 [hm**3]

 Fuelle-Ausfluss im Gerinne      fuqa =   0.2059 [hm**3]

 Fuelle-Ausfluss im vorland      fuqa =   0.0995 [hm**3]


 Scheitel-Ausfluss im Gerinne  iqamax =   1447   qamax =       3.373 [m**3/s]

 Scheitel-Ausfluss im Vorland  iqamax =   1459   qamax =       3.146 [m**3/s]


 Gesamtzuflusswelle (ohne Basisabfluss)  sqz =     1014.541
 Gesamtabflusswelle    "       "         sq  =     1017.900


 Keine angeschlossenen Teilgebiete an Strang      4569
 Auswertung des Stranges:         4584

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Fiktiver Strang! Es erfolgt keine Abflussverzoegerung!
 Keine angeschlossenen Teilgebiete an Strang      4584
 Auswertung des Stranges:         4618

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Abflussverzoegerung mit Kalinin-Miljukov Parametern

 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 dt [h]:   0.08      tmax [d]:     5.04


 Kennwerte Zuflusswelle
 ----------------------

 Scheitel-Zufluss               iqzmax =   1452   qzmax =       6.620 [m**3/s]
 Scheitel-Zufluss im Gerinne    iqzfmx =   1452  qzfmax =       3.345 [m**3/s]
 Scheitel-Zufluss im Vorland    iqzvmx =   1452  qzvmax =       3.275 [m**3/s]

 Fuelle-Zufluss                   fuqz =   0.3414 [hm**3]
 Fuelle-zufluss im Gerinne       fuqzf =   0.2448 [hm**3]
 Fuelle-zufluss im Vorland       fuqzv =   0.0966 [hm**3]


 Kennwerte der Systemfunktionen
 -------------------------------

 Anzahl der Zeitschritte  ituh =    126
 Maximum u                imax =     18     umax = 0.034861
 Summe u                   suu = 0.999994   suuh = 1.000000


 tmax [d]:     5.13


 Kennwerte Ausflusswelle
 -----------------------


 Endordinate Ausfluss           qaend =   0.000

 Scheitel-Ausfluss              iqmax =   1466    qmax =       6.248 [m**3/s]


 Fuelle-Ausfluss                  fuq =   0.3414 [hm**3]

 Fuelle-Ausfluss im Gerinne      fuqa =   0.2448 [hm**3]

 Fuelle-Ausfluss im vorland      fuqa =   0.0967 [hm**3]


 Scheitel-Ausfluss im Gerinne  iqamax =   1453   qamax =       3.342 [m**3/s]

 Scheitel-Ausfluss im Vorland  iqamax =   1477   qamax =       3.132 [m**3/s]


 Gesamtzuflusswelle (ohne Basisabfluss)  sqz =     1138.027
 Gesamtabflusswelle    "       "         sq  =     1138.122


 Keine angeschlossenen Teilgebiete an Strang      4618
 Auswertung des Stranges:         4588

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Abflussverzoegerung mit Kalinin-Miljukov Parametern

 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 dt [h]:   0.08      tmax [d]:     5.09


 Kennwerte Zuflusswelle
 ----------------------

 Scheitel-Zufluss               iqzmax =   1465   qzmax =       6.267 [m**3/s]
 Scheitel-Zufluss im Gerinne    iqzfmx =   1465  qzfmax =       3.167 [m**3/s]
 Scheitel-Zufluss im Vorland    iqzvmx =   1465  qzvmax =       3.100 [m**3/s]

 Fuelle-Zufluss                   fuqz =   0.3446 [hm**3]
 Fuelle-zufluss im Gerinne       fuqzf =   0.2464 [hm**3]
 Fuelle-zufluss im Vorland       fuqzv =   0.0982 [hm**3]


 Kennwerte der Systemfunktionen
 -------------------------------

 Anzahl der Zeitschritte  ituh =    126
 Maximum u                imax =     18     umax = 0.034861
 Summe u                   suu = 0.999994   suuh = 1.000000


 tmax [d]:     5.17


 Kennwerte Ausflusswelle
 -----------------------


 Endordinate Ausfluss           qaend =   0.000

 Scheitel-Ausfluss              iqmax =   1478    qmax =       5.912 [m**3/s]


 Fuelle-Ausfluss                  fuq =   0.3446 [hm**3]

 Fuelle-Ausfluss im Gerinne      fuqa =   0.2464 [hm**3]

 Fuelle-Ausfluss im vorland      fuqa =   0.0982 [hm**3]


 Scheitel-Ausfluss im Gerinne  iqamax =   1466   qamax =       3.164 [m**3/s]

 Scheitel-Ausfluss im Vorland  iqamax =   1490   qamax =       2.965 [m**3/s]


 Gesamtzuflusswelle (ohne Basisabfluss)  sqz =     1148.635
 Gesamtabflusswelle    "       "         sq  =     1148.723


 Keine angeschlossenen Teilgebiete an Strang      4588
 Auswertung des Stranges:         1070

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4593

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    1.61

 gesamtmenge an niederschlag (mm):       57.5

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:    126


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  8.000


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4593
 anzahl hydrotope:     126


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      57.5 mm
 interz.verd.:                       6.6 mm
 bestandsniederschlag:              48.9 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      16.0 mm
 aktuelle verdunstung:              10.1 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              48.9 mm
 overlandflow:                       0.5 mm
 [infiltration:                     48.4 mm]
 verdunstung (bodensp.):             3.4 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -45.0 mm
 fehler:                             0.0 mm


 24.0152111  -> zufluss grundwasserleiter in  4593
TG:    4593 -> TG:    4594
Prozent:0.10

TG:    4593 -> TG:    4596
Prozent:0.90


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:            8.4 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:          10.3 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                -1.2 mm
     pot.entnahme GWS:                -1.2 mm
 speicherinhaltsaenderung:            -0.7 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.855 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.855 qkm



 ISO: Normierungsfaktor   = 1.0002
 ISO: Summe normierter uh =   1.0000


 Anzahl der Zeitschritte in iso durch Nachlauf zu hoch geworden.
 Sie wird auf 460 begrenzt !  gebiet :  4593

fuellenberechnung in iso
abflusz =           409.255
niederschlag =      409.964
flaeche zft  =        1.000
flaeche eing.=        0.855

GEBIET: Abflusswelle Interflow:

 ISO: Normierungsfaktor   = 1.0000
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.855

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV: Retentionskonstanten:   1.4       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =       1.00
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH =  264
ISOV:  fuellenberechnung
ISOV: Abflusz =          7738.425
ISOV: Niederschlag =     7738.426

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
ISOV: Retentionskonstanten:6000.0       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =   96602.20
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH = 2880
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1071

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4596

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    1.61

 gesamtmenge an niederschlag (mm):       57.5

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     47


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  9.700


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4596
 anzahl hydrotope:      47


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      57.5 mm
 interz.verd.:                       6.6 mm
 bestandsniederschlag:              49.0 mm
 differenz interz.speicher:         -1.9 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      15.8 mm
 aktuelle verdunstung:               9.5 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              49.0 mm
 overlandflow:                       0.0 mm
 [infiltration:                     49.0 mm]
 verdunstung (bodensp.):             3.0 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -46.0 mm
 fehler:                             0.0 mm


 47.7071991  -> zufluss grundwasserleiter in  4596
TG:    4596 -> TG:    4597
Prozent:1.00


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:           72.3 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:          77.5 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -5.2 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.198 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.198 qkm



 ISO: Normierungsfaktor   = 1.0002
 ISO: Summe normierter uh =   1.0000


 Anzahl der Zeitschritte in iso durch Nachlauf zu hoch geworden.
 Sie wird auf 460 begrenzt !  gebiet :  4596

fuellenberechnung in iso
abflusz =             0.274
niederschlag =        0.275
flaeche zft  =        1.000
flaeche eing.=        0.198

GEBIET: Abflusswelle Interflow:

 ISO: Normierungsfaktor   = 1.0000
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.198

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV: Retentionskonstanten:   1.4       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =       1.00
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH =  264
ISOV:  fuellenberechnung
ISOV: Abflusz =          2163.526
ISOV: Niederschlag =     2163.527

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
ISOV: Retentionskonstanten:6000.0       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =   96602.20
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH = 2880
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1072

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4591

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    1.61

 gesamtmenge an niederschlag (mm):       57.5

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     85


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  4.000


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4591
 anzahl hydrotope:      85


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      57.5 mm
 interz.verd.:                       6.6 mm
 bestandsniederschlag:              48.9 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      16.1 mm
 aktuelle verdunstung:              10.0 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              48.9 mm
 overlandflow:                       0.3 mm
 [infiltration:                     48.6 mm]
 verdunstung (bodensp.):             3.3 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -45.2 mm
 fehler:                             0.0 mm


 0.00000000E+00  -> zufluss grundwasserleiter in  4591
TG:    4591 -> TG:    4594
Prozent:1.00


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:            0.0 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:           1.6 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                -1.5 mm
     pot.entnahme GWS:                -1.5 mm
 speicherinhaltsaenderung:            -0.2 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.379 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.379 qkm



 ISO: Normierungsfaktor   = 1.0002
 ISO: Summe normierter uh =   1.0000


 Anzahl der Zeitschritte in iso durch Nachlauf zu hoch geworden.
 Sie wird auf 460 begrenzt !  gebiet :  4591

fuellenberechnung in iso
abflusz =           122.366
niederschlag =      122.578
flaeche zft  =        1.000
flaeche eing.=        0.379

GEBIET: Abflusswelle Interflow:

 ISO: Normierungsfaktor   = 1.0000
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.379

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV: Retentionskonstanten:   1.4       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =       1.00
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH =  264
ISOV:  fuellenberechnung
ISOV: Abflusz =          3781.897
ISOV: Niederschlag =     3781.895

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
ISOV: Retentionskonstanten:6000.0       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =   96602.20
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH = 2880
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1073

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4594

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    1.61

 gesamtmenge an niederschlag (mm):       57.5

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     61


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  7.500


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4594
 anzahl hydrotope:      61


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      57.5 mm
 interz.verd.:                       6.6 mm
 bestandsniederschlag:              48.9 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      16.1 mm
 aktuelle verdunstung:               9.7 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              48.9 mm
 overlandflow:                       0.1 mm
 [infiltration:                     48.8 mm]
 verdunstung (bodensp.):             3.1 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -45.7 mm
 fehler:                             0.0 mm


 entnahme gws [qbm/s]:       0.000
 4.97667789  -> zufluss grundwasserleiter in  4594
TG:    4594 -> TG:    4597
Prozent:1.00


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:            4.9 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:           5.7 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.2 mm
     pot.entnahme GWS:                 0.2 mm
 speicherinhaltsaenderung:            -1.0 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.307 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.307 qkm



 ISO: Normierungsfaktor   = 1.0002
 ISO: Summe normierter uh =   1.0000


 Anzahl der Zeitschritte in iso durch Nachlauf zu hoch geworden.
 Sie wird auf 460 begrenzt !  gebiet :  4594

fuellenberechnung in iso
abflusz =            31.558
niederschlag =       31.613
flaeche zft  =        1.000
flaeche eing.=        0.307

GEBIET: Abflusswelle Interflow:

 ISO: Normierungsfaktor   = 1.0000
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.307

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV: Retentionskonstanten:   1.4       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =       1.00
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH =  264
ISOV:  fuellenberechnung
ISOV: Abflusz =          2758.253
ISOV: Niederschlag =     2758.252

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
ISOV: Retentionskonstanten:6000.0       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =   96602.20
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH = 2880
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         4589

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.

 Keine angeschlossenen Teilgebiete an Strang      4589
 Auswertung des Stranges:         4590

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Aufruf der Speicherroutine 


 zufluss-fuelle [hm]        0.004643 speicher 4590
 zusaetzl.zufl im nachl.ast [hm]  0.000150

 speicher   0.004792 abfluss-fuelle [hm]      4590

 speicherinhaltsaenderung [hm]  0.000057
 Keine angeschlossenen Teilgebiete an Strang      4590
 Auswertung des Stranges:         4594

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Abflussverzoegerung mit Kalinin-Miljukov Parametern

 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 dt [h]:   0.08      tmax [d]:     4.92


 Kennwerte Zuflusswelle
 ----------------------

 Scheitel-Zufluss               iqzmax =   1416   qzmax =       0.165 [m**3/s]
 Scheitel-Zufluss im Gerinne    iqzfmx =   1416  qzfmax =       0.165 [m**3/s]
 Scheitel-Zufluss im Vorland    iqzvmx =      0  qzvmax =       0.000 [m**3/s]

 Fuelle-Zufluss                   fuqz =   0.0048 [hm**3]
 Fuelle-zufluss im Gerinne       fuqzf =   0.0048 [hm**3]
 Fuelle-zufluss im Vorland       fuqzv =   0.0000 [hm**3]


 Kennwerte der Systemfunktionen
 -------------------------------

 Anzahl der Zeitschritte  ituh =     18
 Maximum u                imax =      3     umax = 0.269426
 Summe u                   suu = 0.999998   suuh = 1.000000


 tmax [d]:     4.93


 Kennwerte Ausflusswelle
 -----------------------

 Endordinate Ausfluss           qaend =   0.000
 Scheitel-Ausfluss              iqmax =   1420    qmax =       0.165 [m**3/s]

 Fuelle-Ausfluss                  fuq =   0.0048 [hm**3]
 Fuelle-Ausfluss im Gerinne      fuqa =   0.0048 [hm**3]

 Scheitel-Ausfluss im Gerinne  iqamax =   1420   qamax =       0.165 [m**3/s]


 Gesamtzuflusswelle (ohne Basisabfluss)  sqz =       15.979
 Gesamtabflusswelle    "       "         sq  =       15.979


 Keine angeschlossenen Teilgebiete an Strang      4594
 Auswertung des Stranges:         4591

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.

 Keine angeschlossenen Teilgebiete an Strang      4591
 Auswertung des Stranges:         4592

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Aufruf der Speicherroutine 


 zufluss-fuelle [hm]        0.003789 speicher 4592
 zusaetzl.zufl im nachl.ast [hm]  0.000119

 speicher   0.003908 abfluss-fuelle [hm]      4592

 speicherinhaltsaenderung [hm]  0.000000
 Keine angeschlossenen Teilgebiete an Strang      4592
 Auswertung des Stranges:         4593

 Abflussverzoegerung mit Kalinin-Miljukov Parametern

 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 dt [h]:   0.08      tmax [d]:     4.93


 Kennwerte Zuflusswelle
 ----------------------

 Scheitel-Zufluss               iqzmax =   1421   qzmax =       0.127 [m**3/s]
 Scheitel-Zufluss im Gerinne    iqzfmx =   1421  qzfmax =       0.127 [m**3/s]
 Scheitel-Zufluss im Vorland    iqzvmx =      0  qzvmax =       0.000 [m**3/s]

 Fuelle-Zufluss                   fuqz =   0.0039 [hm**3]
 Fuelle-zufluss im Gerinne       fuqzf =   0.0039 [hm**3]
 Fuelle-zufluss im Vorland       fuqzv =   0.0000 [hm**3]


 Kennwerte der Systemfunktionen
 -------------------------------

 Anzahl der Zeitschritte  ituh =     18
 Maximum u                imax =      3     umax = 0.269426
 Summe u                   suu = 0.999998   suuh = 1.000000


 tmax [d]:     4.95


 Kennwerte Ausflusswelle
 -----------------------

 Endordinate Ausfluss           qaend =   0.000
 Scheitel-Ausfluss              iqmax =   1425    qmax =       0.127 [m**3/s]

 Fuelle-Ausfluss                  fuq =   0.0039 [hm**3]
 Fuelle-Ausfluss im Gerinne      fuqa =   0.0039 [hm**3]

 Scheitel-Ausfluss im Gerinne  iqamax =   1425   qamax =       0.127 [m**3/s]


 Gesamtzuflusswelle (ohne Basisabfluss)  sqz =       13.028
 Gesamtabflusswelle    "       "         sq  =       13.028


 Keine angeschlossenen Teilgebiete an Strang      4593
 Auswertung des Stranges:         4595

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Aufruf der Speicherroutine 


 zufluss-fuelle [hm]        0.018897 speicher 4595
 zusaetzl.zufl im nachl.ast [hm]  0.000750

 speicher   0.019646 abfluss-fuelle [hm]      4595

 speicherinhaltsaenderung [hm]  0.000000
 Keine angeschlossenen Teilgebiete an Strang      4595
 Auswertung des Stranges:         4596

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Aufruf der Speicherroutine 


 zufluss-fuelle [hm]        0.018312 speicher 4596
 zusaetzl.zufl im nachl.ast [hm]  0.001342

 speicher   0.019653 abfluss-fuelle [hm]      4596

 speicherinhaltsaenderung [hm]  0.000000
 Keine angeschlossenen Teilgebiete an Strang      4596
 Auswertung des Stranges:         4622

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Abflussverzoegerung mit Kalinin-Miljukov Parametern

 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 dt [h]:   0.08      tmax [d]:     4.92


 Kennwerte Zuflusswelle
 ----------------------

 Scheitel-Zufluss               iqzmax =   1418   qzmax =       0.731 [m**3/s]
 Scheitel-Zufluss im Gerinne    iqzfmx =   1418  qzfmax =       0.731 [m**3/s]
 Scheitel-Zufluss im Vorland    iqzvmx =      0  qzvmax =       0.000 [m**3/s]

 Fuelle-Zufluss                   fuqz =   0.0218 [hm**3]
 Fuelle-zufluss im Gerinne       fuqzf =   0.0218 [hm**3]
 Fuelle-zufluss im Vorland       fuqzv =   0.0000 [hm**3]


 Kennwerte der Systemfunktionen
 -------------------------------

 Anzahl der Zeitschritte  ituh =     18
 Maximum u                imax =      3     umax = 0.269426
 Summe u                   suu = 0.999998   suuh = 1.000000


 tmax [d]:     4.94


 Kennwerte Ausflusswelle
 -----------------------

 Endordinate Ausfluss           qaend =   0.000
 Scheitel-Ausfluss              iqmax =   1422    qmax =       0.729 [m**3/s]

 Fuelle-Ausfluss                  fuq =   0.0218 [hm**3]
 Fuelle-Ausfluss im Gerinne      fuqa =   0.0218 [hm**3]

 Scheitel-Ausfluss im Gerinne  iqamax =   1422   qamax =       0.729 [m**3/s]


 Gesamtzuflusswelle (ohne Basisabfluss)  sqz =       72.735
 Gesamtabflusswelle    "       "         sq  =       72.735


 Keine angeschlossenen Teilgebiete an Strang      4622
 Auswertung des Stranges:         1074

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4598

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    1.61

 gesamtmenge an niederschlag (mm):       57.5

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     54


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  6.000


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4598
 anzahl hydrotope:      54


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      57.5 mm
 interz.verd.:                       6.7 mm
 bestandsniederschlag:              48.6 mm
 differenz interz.speicher:         -2.1 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      16.0 mm
 aktuelle verdunstung:              10.1 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              48.6 mm
 overlandflow:                       0.2 mm
 [infiltration:                     48.4 mm]
 verdunstung (bodensp.):             3.4 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -45.0 mm
 fehler:                             0.0 mm


 entnahme gws [qbm/s]:       0.000
 73.2415161  -> zufluss grundwasserleiter in  4598
TG:    4598 -> TG:    4599
Prozent:1.00


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:          199.4 mm
 abgabe basisabfluss:                 59.0 mm
        grundw. unterh.l.TG:         139.8 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.5 mm
     pot.entnahme GWS:                 0.5 mm
 speicherinhaltsaenderung:             0.0 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.110 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.110 qkm



 ISO: Normierungsfaktor   = 1.0002
 ISO: Summe normierter uh =   1.0000


 Anzahl der Zeitschritte in iso durch Nachlauf zu hoch geworden.
 Sie wird auf 460 begrenzt !  gebiet :  4598

fuellenberechnung in iso
abflusz =            21.473
niederschlag =       21.510
flaeche zft  =        1.000
flaeche eing.=        0.110

GEBIET: Abflusswelle Interflow:

 ISO: Normierungsfaktor   = 1.0000
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.110

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV: Retentionskonstanten:   1.4       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =       1.00
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH =  264
ISOV:  fuellenberechnung
ISOV: Abflusz =           894.158
ISOV: Niederschlag =      894.158

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
ISOV: Retentionskonstanten:6000.0       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =   96602.20
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH = 2880
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1075

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4597

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    1.61

 gesamtmenge an niederschlag (mm):       57.5

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     84


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  7.000


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4597
 anzahl hydrotope:      84


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      57.5 mm
 interz.verd.:                       6.6 mm
 bestandsniederschlag:              49.0 mm
 differenz interz.speicher:         -1.9 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      15.8 mm
 aktuelle verdunstung:               9.9 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              49.0 mm
 overlandflow:                       0.2 mm
 [infiltration:                     48.8 mm]
 verdunstung (bodensp.):             3.3 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -45.5 mm
 fehler:                             0.0 mm


 entnahme gws [qbm/s]:       0.000
 56.9824944  -> zufluss grundwasserleiter in  4597
TG:    4597 -> TG:    4599
Prozent:1.00


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:           63.7 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:          70.0 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.4 mm
     pot.entnahme GWS:                 0.4 mm
 speicherinhaltsaenderung:            -6.6 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.268 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.268 qkm



 ISO: Normierungsfaktor   = 1.0002
 ISO: Summe normierter uh =   1.0000


 Anzahl der Zeitschritte in iso durch Nachlauf zu hoch geworden.
 Sie wird auf 460 begrenzt !  gebiet :  4597

fuellenberechnung in iso
abflusz =            41.142
niederschlag =       41.213
flaeche zft  =        1.000
flaeche eing.=        0.268

GEBIET: Abflusswelle Interflow:

 ISO: Normierungsfaktor   = 1.0000
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.268

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV: Retentionskonstanten:   1.4       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =       1.00
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH =  264
ISOV:  fuellenberechnung
ISOV: Abflusz =          3575.945
ISOV: Niederschlag =     3575.944

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
ISOV: Retentionskonstanten:6000.0       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =   96602.20
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH = 2880
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1076

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4599

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    1.61

 gesamtmenge an niederschlag (mm):       57.5

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     27


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 = 20.100


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4599
 anzahl hydrotope:      27


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      57.5 mm
 interz.verd.:                       6.6 mm
 bestandsniederschlag:              48.9 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      16.2 mm
 aktuelle verdunstung:              11.2 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              48.9 mm
 overlandflow:                       2.7 mm
 [infiltration:                     46.2 mm]
 verdunstung (bodensp.):             4.6 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -41.5 mm
 fehler:                             0.0 mm


 entnahme gws [qbm/s]:       0.000
 113.932121  -> zufluss grundwasserleiter in  4599

 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:         1313.8 mm
 abgabe basisabfluss:               1015.6 mm
        grundw. unterh.l.TG:         296.8 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 1.4 mm
     pot.entnahme GWS:                 1.4 mm
 speicherinhaltsaenderung:             0.0 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.026 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.026 qkm



 ISO: Normierungsfaktor   = 1.0002
 ISO: Summe normierter uh =   1.0000


 Anzahl der Zeitschritte in iso durch Nachlauf zu hoch geworden.
 Sie wird auf 460 begrenzt !  gebiet :  4599

fuellenberechnung in iso
abflusz =            70.461
niederschlag =       70.583
flaeche zft  =        1.000
flaeche eing.=        0.026

GEBIET: Abflusswelle Interflow:

 ISO: Normierungsfaktor   = 1.0000
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.026

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV: Retentionskonstanten:   2.5       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =       1.00
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH =  448
ISOV:  fuellenberechnung
ISOV: Abflusz =           376.037
ISOV: Niederschlag =      376.038

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
ISOV: Retentionskonstanten:6000.0       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =   96602.20
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH = 2880
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         4597

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Abflussverzoegerung mit Kalinin-Miljukov Parametern

 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 dt [h]:   0.08      tmax [d]:     5.13


 Kennwerte Zuflusswelle
 ----------------------

 Scheitel-Zufluss               iqzmax =   1478   qzmax =       5.921 [m**3/s]
 Scheitel-Zufluss im Gerinne    iqzfmx =   1478  qzfmax =       3.320 [m**3/s]
 Scheitel-Zufluss im Vorland    iqzvmx =   1478  qzvmax =       2.601 [m**3/s]

 Fuelle-Zufluss                   fuqz =   0.3468 [hm**3]
 Fuelle-zufluss im Gerinne       fuqzf =   0.2548 [hm**3]
 Fuelle-zufluss im Vorland       fuqzv =   0.0920 [hm**3]


 Kennwerte der Systemfunktionen
 -------------------------------

 Anzahl der Zeitschritte  ituh =      9
 Maximum u                imax =      1     umax = 0.725271
 Summe u                   suu = 1.005751   suuh = 1.000000


 tmax [d]:     5.13


 Kennwerte Ausflusswelle
 -----------------------


 Endordinate Ausfluss           qaend =   0.001

 Scheitel-Ausfluss              iqmax =   1479    qmax =       5.920 [m**3/s]


 Fuelle-Ausfluss                  fuq =   0.3468 [hm**3]

 Fuelle-Ausfluss im Gerinne      fuqa =   0.2548 [hm**3]

 Fuelle-Ausfluss im vorland      fuqa =   0.0920 [hm**3]


 Scheitel-Ausfluss im Gerinne  iqamax =   1479   qamax =       3.319 [m**3/s]

 Scheitel-Ausfluss im Vorland  iqamax =   1478   qamax =       2.601 [m**3/s]


 Gesamtzuflusswelle (ohne Basisabfluss)  sqz =     1155.924
 Gesamtabflusswelle    "       "         sq  =     1155.922


 Keine angeschlossenen Teilgebiete an Strang      4597
 Auswertung des Stranges:         4598

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Abflussverzoegerung mit Kalinin-Miljukov Parametern

 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 dt [h]:   0.08      tmax [d]:     5.13


 Kennwerte Zuflusswelle
 ----------------------

 Scheitel-Zufluss               iqzmax =   1476   qzmax =       6.177 [m**3/s]
 Scheitel-Zufluss im Gerinne    iqzfmx =   1476  qzfmax =       4.284 [m**3/s]
 Scheitel-Zufluss im Vorland    iqzvmx =   1476  qzvmax =       1.894 [m**3/s]

 Fuelle-Zufluss                   fuqz =   0.3797 [hm**3]
 Fuelle-zufluss im Gerinne       fuqzf =   0.2985 [hm**3]
 Fuelle-zufluss im Vorland       fuqzv =   0.0812 [hm**3]


 Kennwerte der Systemfunktionen
 -------------------------------

 Anzahl der Zeitschritte  ituh =     16
 Maximum u                imax =      1     umax = 0.517926
 Summe u                   suu = 0.610857   suuh = 0.999798


 tmax [d]:     5.13


 Kennwerte Ausflusswelle
 -----------------------


 Endordinate Ausfluss           qaend =   0.000

 Scheitel-Ausfluss              iqmax =   1477    qmax =       6.175 [m**3/s]


 Fuelle-Ausfluss                  fuq =   0.3797 [hm**3]

 Fuelle-Ausfluss im Gerinne      fuqa =   0.2985 [hm**3]

 Fuelle-Ausfluss im vorland      fuqa =   0.0812 [hm**3]


 Scheitel-Ausfluss im Gerinne  iqamax =   1477   qamax =       4.282 [m**3/s]

 Scheitel-Ausfluss im Vorland  iqamax =   1477   qamax =       1.893 [m**3/s]


 Gesamtzuflusswelle (ohne Basisabfluss)  sqz =     1265.578
 Gesamtabflusswelle    "       "         sq  =     1265.540


 Keine angeschlossenen Teilgebiete an Strang      4598
 Auswertung des Stranges:         4599

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Fiktiver Strang! Es erfolgt keine Abflussverzoegerung!
 Keine angeschlossenen Teilgebiete an Strang      4599
 Auswertung des Stranges:        10002

 Fiktiver Strang! Es erfolgt keine Abflussverzoegerung!
 Keine angeschlossenen Teilgebiete an Strang     10002


 ------------------------------------------------------------------
           Berechnung wurde ohne Fehler beendet!                   
 ------------------------------------------------------------------
