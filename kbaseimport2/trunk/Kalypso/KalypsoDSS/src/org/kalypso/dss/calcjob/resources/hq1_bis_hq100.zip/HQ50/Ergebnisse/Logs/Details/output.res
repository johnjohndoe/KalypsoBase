



          *****************************************************
          *****************************************************
          ****                                             ****
          ****      HAMBURG UNIVERSITY OF TECHNOLOGY       ****
          ****                                             ****
          **** Department of River and Coastal Engineering ****
          ****                                             ****
          ****                                             ****
          ****            K A L Y P S O - N A              ****
          ****                                             ****
          ****                                             ****
          ****           Rainfall-Runoff-Model             ****
          ****                                             ****
          ****                                             ****
          ****                                             ****
          ****     VERS.  2.0.6      STATUS: 01.08.2006    ****
          ****                                             ****
          ****                                             ****
          ****     Contact:          Dipl.-Ing J. H�bsch   ****
          ****                       j.huebsch@tuhh.de     ****
          *****************************************************
          *****************************************************




 Bearbeitung Fall / Berechnungseinstellungen aus Steuerungsdatei:
 ----------------------------------------------------------------
 2 .. we nat  1996 08 24 00 1996 08 30 22 start\we_nat_start.txt                                                         


 Anzahl der Straenge in der Netzdatei:    182

 Anzahl der Teilgebiete in der Netzdatei:  77



 K U R Z Z E I T S I M U L A T I O N
 Zyklus (iz):                         1
 Anfangsdatum Zyklus (idatsa):   960824
 Enddatum Zyklus (idatse):       960830
 Zeitschritte (idif):              1993


 ************************************************************************************
 *  Neuer Jahreszyklus                                                              *
 *      Jahr:    1996                                                              *
 *      Zyklus:     1                                                              *
 ************************************************************************************
 Auswertung des Stranges:         1000

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4503

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    2.69

 gesamtmenge an niederschlag (mm):       96.0

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     63


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  1.000


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4503
 anzahl hydrotope:      63


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      96.0 mm
 interz.verd.:                       7.5 mm
 bestandsniederschlag:              86.4 mm
 differenz interz.speicher:         -2.1 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      15.5 mm
 aktuelle verdunstung:              10.5 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              86.4 mm
 overlandflow:                       3.4 mm
 [infiltration:                     83.1 mm]
 verdunstung (bodensp.):             3.0 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -80.1 mm
 fehler:                             0.0 mm


 0.00000000E+00  -> zufluss grundwasserleiter in  4503
TG:    4503 -> TG:    4500
Prozent:0.20

TG:    4503 -> TG:    4501
Prozent:0.10

TG:    4503 -> TG:    4506
Prozent:0.20

TG:    4503 -> TG:    4504
Prozent:0.50


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:            0.0 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:           2.0 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                -0.9 mm
     pot.entnahme GWS:                -0.9 mm
 speicherinhaltsaenderung:            -1.1 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.872 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.872 qkm



 ISO: Normierungsfaktor   = 1.0001
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =          2935.389
niederschlag =     2935.386
flaeche zft  =        1.000
flaeche eing.=        0.872

GEBIET: Abflusswelle Interflow:

 ISO: Normierungsfaktor   = 1.0001
 ISO: Summe normierter uh =   1.0000


 Anzahl der Zeitschritte in iso durch Nachlauf zu hoch geworden.
 Sie wird auf 460 begrenzt !  gebiet :  4503

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.872

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV: Retentionskonstanten:   2.2       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =       1.00
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH =  400
ISOV:  fuellenberechnung
ISOV: Abflusz =          5791.024
ISOV: Niederschlag =     5791.021

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
ISOV: Retentionskonstanten:6000.0       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =   96602.20
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH = 2880
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1001

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4501

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    2.69

 gesamtmenge an niederschlag (mm):       96.0

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     18


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  1.000


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4501
 anzahl hydrotope:      18


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      96.0 mm
 interz.verd.:                       7.3 mm
 bestandsniederschlag:              86.7 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      15.7 mm
 aktuelle verdunstung:              12.0 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              86.7 mm
 overlandflow:                      47.9 mm
 [infiltration:                     38.7 mm]
 verdunstung (bodensp.):             4.6 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -34.1 mm
 fehler:                             0.0 mm


 0.575069070  -> zufluss grundwasserleiter in  4501
TG:    4501 -> TG:    4502
Prozent:0.80

TG:    4501 -> TG:    4506
Prozent:0.20


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:            1.5 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:           2.4 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -0.9 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.115 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.115 qkm



 ISO: Normierungsfaktor   = 1.0001
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =          5495.079
niederschlag =     5495.085
flaeche zft  =        1.000
flaeche eing.=        0.115

GEBIET: Abflusswelle Interflow:

 ISO: Normierungsfaktor   = 1.0001
 ISO: Summe normierter uh =   1.0000


 Anzahl der Zeitschritte in iso durch Nachlauf zu hoch geworden.
 Sie wird auf 460 begrenzt !  gebiet :  4501

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.115

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV: Retentionskonstanten:   2.0       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =       1.00
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH =  374
ISOV:  fuellenberechnung
ISOV: Abflusz =           224.640
ISOV: Niederschlag =      224.640

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
ISOV: Retentionskonstanten:6000.0       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =   96602.20
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH = 2880
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1002

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4506

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    2.69

 gesamtmenge an niederschlag (mm):       96.0

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     16


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  1.000


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4506
 anzahl hydrotope:      16


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      96.0 mm
 interz.verd.:                       7.3 mm
 bestandsniederschlag:              86.8 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      15.5 mm
 aktuelle verdunstung:              11.8 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              86.8 mm
 overlandflow:                      48.1 mm
 [infiltration:                     38.7 mm]
 verdunstung (bodensp.):             4.6 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -34.2 mm
 fehler:                             0.0 mm


 1.33020723  -> zufluss grundwasserleiter in  4506
TG:    4506 -> TG:    4510
Prozent:1.00


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:            2.0 mm
 abgabe basisabfluss:                  0.1 mm
        grundw. unterh.l.TG:           2.8 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -0.9 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.196 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.196 qkm



 ISO: Normierungsfaktor   = 1.0001
 ISO: Summe normierter uh =   1.0000


 Anzahl der Zeitschritte in iso durch Nachlauf zu hoch geworden.
 Sie wird auf 460 begrenzt !  gebiet :  4506

fuellenberechnung in iso
abflusz =          9413.758
niederschlag =     9414.364
flaeche zft  =        1.000
flaeche eing.=        0.196

GEBIET: Abflusswelle Interflow:

 ISO: Normierungsfaktor   = 1.0001
 ISO: Summe normierter uh =   1.0000


 Anzahl der Zeitschritte in iso durch Nachlauf zu hoch geworden.
 Sie wird auf 460 begrenzt !  gebiet :  4506

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.196

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV: Retentionskonstanten:   3.0       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =       1.00
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH =  544
ISOV:  fuellenberechnung
ISOV: Abflusz =            96.955
ISOV: Niederschlag =       96.955

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
ISOV: Retentionskonstanten:6000.0       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =   96602.20
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH = 2880
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1003

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4504

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    2.69

 gesamtmenge an niederschlag (mm):       96.0

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     86


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  1.250


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4504
 anzahl hydrotope:      86


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      96.0 mm
 interz.verd.:                       7.3 mm
 bestandsniederschlag:              86.7 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      16.0 mm
 aktuelle verdunstung:              11.0 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              86.7 mm
 overlandflow:                      23.3 mm
 [infiltration:                     63.5 mm]
 verdunstung (bodensp.):             3.7 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -59.8 mm
 fehler:                             0.0 mm


 2.87534523  -> zufluss grundwasserleiter in  4504
TG:    4504 -> TG:    4510
Prozent:0.20

TG:    4504 -> TG:    4509
Prozent:0.80


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:            1.4 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:           2.6 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -1.2 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.621 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.621 qkm



 ISO: Normierungsfaktor   = 1.0001
 ISO: Summe normierter uh =   1.0000


 Anzahl der Zeitschritte in iso durch Nachlauf zu hoch geworden.
 Sie wird auf 460 begrenzt !  gebiet :  4504

fuellenberechnung in iso
abflusz =         14445.876
niederschlag =    14446.363
flaeche zft  =        1.000
flaeche eing.=        0.621

GEBIET: Abflusswelle Interflow:

 ISO: Normierungsfaktor   = 1.0001
 ISO: Summe normierter uh =   1.0000


 Anzahl der Zeitschritte in iso durch Nachlauf zu hoch geworden.
 Sie wird auf 460 begrenzt !  gebiet :  4504

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.621

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV: Retentionskonstanten:   1.8       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =       1.00
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH =  334
ISOV:  fuellenberechnung
ISOV: Abflusz =          8819.586
ISOV: Niederschlag =     8819.595

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
ISOV: Retentionskonstanten:6000.0       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =   96602.20
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH = 2880
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1004

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4510

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    2.69

 gesamtmenge an niederschlag (mm):       96.0

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:    106


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  1.500


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4510
 anzahl hydrotope:     106


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      96.0 mm
 interz.verd.:                       7.3 mm
 bestandsniederschlag:              86.7 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      15.9 mm
 aktuelle verdunstung:              10.9 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              86.7 mm
 overlandflow:                       6.1 mm
 [infiltration:                     80.6 mm]
 verdunstung (bodensp.):             3.6 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -77.0 mm
 fehler:                             0.0 mm


 2.89685917  -> zufluss grundwasserleiter in  4510
TG:    4510 -> TG:    4511
Prozent:0.20

TG:    4510 -> TG:    4526
Prozent:0.80


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:            1.8 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:           5.7 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -3.8 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.478 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.478 qkm



 ISO: Normierungsfaktor   = 1.0002
 ISO: Summe normierter uh =   1.0000


 Anzahl der Zeitschritte in iso durch Nachlauf zu hoch geworden.
 Sie wird auf 460 begrenzt !  gebiet :  4510

fuellenberechnung in iso
abflusz =          2916.140
niederschlag =     2921.173
flaeche zft  =        1.000
flaeche eing.=        0.478

GEBIET: Abflusswelle Interflow:

 ISO: Normierungsfaktor   = 1.0000
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.478

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV: Retentionskonstanten:   1.4       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =       1.00
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH =  264
ISOV:  fuellenberechnung
ISOV: Abflusz =          6559.668
ISOV: Niederschlag =     6559.667

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
ISOV: Retentionskonstanten:6000.0       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =   96602.20
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH = 2880
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1005

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4502

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    2.69

 gesamtmenge an niederschlag (mm):       96.0

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     77


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  1.000


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4502
 anzahl hydrotope:      77


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      96.0 mm
 interz.verd.:                       7.3 mm
 bestandsniederschlag:              86.8 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      15.5 mm
 aktuelle verdunstung:              10.5 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              86.8 mm
 overlandflow:                       8.2 mm
 [infiltration:                     78.6 mm]
 verdunstung (bodensp.):             3.2 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -75.3 mm
 fehler:                             0.0 mm


 0.720275521  -> zufluss grundwasserleiter in  4502
TG:    4502 -> TG:    4520
Prozent:0.40

TG:    4502 -> TG:    4523
Prozent:0.60


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:            0.5 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:           1.8 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -1.2 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.413 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.413 qkm



 ISO: Normierungsfaktor   = 1.0001
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =          3385.116
niederschlag =     3385.116
flaeche zft  =        1.000
flaeche eing.=        0.413

GEBIET: Abflusswelle Interflow:

 ISO: Normierungsfaktor   = 1.0001
 ISO: Summe normierter uh =   1.0000


 Anzahl der Zeitschritte in iso durch Nachlauf zu hoch geworden.
 Sie wird auf 460 begrenzt !  gebiet :  4502

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.413

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV: Retentionskonstanten:   1.2       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =       1.00
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH =  239
ISOV:  fuellenberechnung
ISOV: Abflusz =          8776.102
ISOV: Niederschlag =     8776.110

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
ISOV: Retentionskonstanten:6000.0       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =   96602.20
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH = 2880
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1006

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4500

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    2.69

 gesamtmenge an niederschlag (mm):       96.0

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:    125


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  1.000


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4500
 anzahl hydrotope:     125


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      96.0 mm
 interz.verd.:                       7.3 mm
 bestandsniederschlag:              86.7 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      15.9 mm
 aktuelle verdunstung:              10.7 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              86.7 mm
 overlandflow:                       9.1 mm
 [infiltration:                     77.6 mm]
 verdunstung (bodensp.):             3.3 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -74.2 mm
 fehler:                             0.0 mm


 1.15013814  -> zufluss grundwasserleiter in  4500
TG:    4500 -> TG:    4516
Prozent:0.60

TG:    4500 -> TG:    4520
Prozent:0.40


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:            0.4 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:           2.2 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                -0.9 mm
     pot.entnahme GWS:                -0.9 mm
 speicherinhaltsaenderung:            -1.0 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.933 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.933 qkm



 ISO: Normierungsfaktor   = 1.0001
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =          8514.801
niederschlag =     8514.809
flaeche zft  =        1.000
flaeche eing.=        0.933

GEBIET: Abflusswelle Interflow:

 ISO: Normierungsfaktor   = 1.0001
 ISO: Summe normierter uh =   1.0000


 Anzahl der Zeitschritte in iso durch Nachlauf zu hoch geworden.
 Sie wird auf 460 begrenzt !  gebiet :  4500

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.933

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV: Retentionskonstanten:   2.0       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =       1.00
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH =  380
ISOV:  fuellenberechnung
ISOV: Abflusz =         16267.134
ISOV: Niederschlag =    16267.149

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
ISOV: Retentionskonstanten:6000.0       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =   96602.20
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH = 2880
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1007

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4512

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    2.69

 gesamtmenge an niederschlag (mm):       96.0

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     33


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  3.800


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4512
 anzahl hydrotope:      33


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      96.0 mm
 interz.verd.:                       7.3 mm
 bestandsniederschlag:              86.7 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      16.1 mm
 aktuelle verdunstung:              10.5 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              86.7 mm
 overlandflow:                       0.0 mm
 [infiltration:                     86.7 mm]
 verdunstung (bodensp.):             3.2 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -83.6 mm
 fehler:                             0.0 mm


 entnahme gws [qbm/s]:       0.001
 0.00000000E+00  -> zufluss grundwasserleiter in  4512
TG:    4512 -> TG:    4513
Prozent:0.10

TG:    4512 -> TG:    4514
Prozent:0.90


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:            0.0 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:           1.9 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 1.0 mm
     pot.entnahme GWS:                 1.0 mm
 speicherinhaltsaenderung:            -2.9 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.408 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.408 qkm



 ISO: Normierungsfaktor   = 1.0002
 ISO: Summe normierter uh =   1.0000


 Anzahl der Zeitschritte in iso durch Nachlauf zu hoch geworden.
 Sie wird auf 460 begrenzt !  gebiet :  4512

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.408

GEBIET: Abflusswelle Interflow:

 ISO: Normierungsfaktor   = 1.0000
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.408

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV: Retentionskonstanten:   1.4       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =       1.00
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH =  264
ISOV:  fuellenberechnung
ISOV: Abflusz =          6331.263
ISOV: Niederschlag =     6331.263

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
ISOV: Retentionskonstanten:6000.0       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =   96602.20
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH = 2880
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1008

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4513

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    2.69

 gesamtmenge an niederschlag (mm):       96.0

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     13


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  2.300


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4513
 anzahl hydrotope:      13


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      96.0 mm
 interz.verd.:                       7.3 mm
 bestandsniederschlag:              86.8 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      15.9 mm
 aktuelle verdunstung:              10.4 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              86.8 mm
 overlandflow:                       0.0 mm
 [infiltration:                     86.8 mm]
 verdunstung (bodensp.):             3.1 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -83.6 mm
 fehler:                             0.0 mm


 entnahme gws [qbm/s]:       0.000
 0.257184803  -> zufluss grundwasserleiter in  4513
TG:    4513 -> TG:    4516
Prozent:1.00


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:            0.4 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:           3.4 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.2 mm
     pot.entnahme GWS:                 0.2 mm
 speicherinhaltsaenderung:            -3.2 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.207 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.207 qkm



 ISO: Normierungsfaktor   = 1.0002
 ISO: Summe normierter uh =   1.0000


 Anzahl der Zeitschritte in iso durch Nachlauf zu hoch geworden.
 Sie wird auf 460 begrenzt !  gebiet :  4513

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.207

GEBIET: Abflusswelle Interflow:

 ISO: Normierungsfaktor   = 1.0000
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.207

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV: Retentionskonstanten:   1.4       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =       1.00
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH =  264
ISOV:  fuellenberechnung
ISOV: Abflusz =          2858.558
ISOV: Niederschlag =     2858.557

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
ISOV: Retentionskonstanten:6000.0       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =   96602.20
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH = 2880
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1009

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4516

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    2.69

 gesamtmenge an niederschlag (mm):       96.0

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     38


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  8.000


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4516
 anzahl hydrotope:      38


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      96.0 mm
 interz.verd.:                       7.3 mm
 bestandsniederschlag:              86.7 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      16.1 mm
 aktuelle verdunstung:              10.5 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              86.7 mm
 overlandflow:                       0.0 mm
 [infiltration:                     86.7 mm]
 verdunstung (bodensp.):             3.2 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -83.5 mm
 fehler:                             0.0 mm


 6.44798565  -> zufluss grundwasserleiter in  4516
TG:    4516 -> TG:    4519
Prozent:0.65

TG:    4516 -> TG:    4520
Prozent:0.35


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:            4.5 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:          10.2 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -5.7 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.429 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.429 qkm



 ISO: Normierungsfaktor   = 1.0002
 ISO: Summe normierter uh =   1.0000


 Anzahl der Zeitschritte in iso durch Nachlauf zu hoch geworden.
 Sie wird auf 460 begrenzt !  gebiet :  4516

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.429

GEBIET: Abflusswelle Interflow:

 ISO: Normierungsfaktor   = 1.0000
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.429

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV: Retentionskonstanten:   1.4       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =       1.00
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH =  264
ISOV:  fuellenberechnung
ISOV: Abflusz =          5951.589
ISOV: Niederschlag =     5951.587

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
ISOV: Retentionskonstanten:6000.0       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =   96602.20
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH = 2880
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1010

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4520

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    2.69

 gesamtmenge an niederschlag (mm):       96.0

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     47


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  5.000


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4520
 anzahl hydrotope:      47


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      96.0 mm
 interz.verd.:                       7.3 mm
 bestandsniederschlag:              86.7 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      16.1 mm
 aktuelle verdunstung:              10.6 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              86.7 mm
 overlandflow:                       0.1 mm
 [infiltration:                     86.6 mm]
 verdunstung (bodensp.):             3.2 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -83.4 mm
 fehler:                             0.0 mm


 8.81579685  -> zufluss grundwasserleiter in  4520
TG:    4520 -> TG:    4522
Prozent:0.10

TG:    4520 -> TG:    4524
Prozent:0.75

TG:    4520 -> TG:    4523
Prozent:0.15


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:            6.5 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:          13.1 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -6.5 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.404 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.404 qkm



 ISO: Normierungsfaktor   = 1.0002
 ISO: Summe normierter uh =   1.0000


 Anzahl der Zeitschritte in iso durch Nachlauf zu hoch geworden.
 Sie wird auf 460 begrenzt !  gebiet :  4520

fuellenberechnung in iso
abflusz =            36.310
niederschlag =       36.372
flaeche zft  =        1.000
flaeche eing.=        0.404

GEBIET: Abflusswelle Interflow:

 ISO: Normierungsfaktor   = 1.0000
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.404

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV: Retentionskonstanten:   1.4       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =       1.00
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH =  264
ISOV:  fuellenberechnung
ISOV: Abflusz =          5834.886
ISOV: Niederschlag =     5834.886

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
ISOV: Retentionskonstanten:6000.0       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =   96602.20
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH = 2880
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1011

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4523

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    2.69

 gesamtmenge an niederschlag (mm):       96.0

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     66


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  2.500


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4523
 anzahl hydrotope:      66


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      96.0 mm
 interz.verd.:                       7.4 mm
 bestandsniederschlag:              86.5 mm
 differenz interz.speicher:         -2.1 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      15.5 mm
 aktuelle verdunstung:              10.5 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              86.5 mm
 overlandflow:                       1.6 mm
 [infiltration:                     84.9 mm]
 verdunstung (bodensp.):             3.1 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -81.9 mm
 fehler:                             0.0 mm


 4.09409142  -> zufluss grundwasserleiter in  4523
TG:    4523 -> TG:    4526
Prozent:0.10

TG:    4523 -> TG:    4524
Prozent:0.90


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:            3.0 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:           7.5 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -4.6 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.416 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.416 qkm



 ISO: Normierungsfaktor   = 1.0002
 ISO: Summe normierter uh =   1.0000


 Anzahl der Zeitschritte in iso durch Nachlauf zu hoch geworden.
 Sie wird auf 460 begrenzt !  gebiet :  4523

fuellenberechnung in iso
abflusz =           646.939
niederschlag =      648.057
flaeche zft  =        1.000
flaeche eing.=        0.416

GEBIET: Abflusswelle Interflow:

 ISO: Normierungsfaktor   = 1.0000
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.416

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV: Retentionskonstanten:   1.4       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =       1.00
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH =  264
ISOV:  fuellenberechnung
ISOV: Abflusz =          4639.934
ISOV: Niederschlag =     4639.931

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
ISOV: Retentionskonstanten:6000.0       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =   96602.20
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH = 2880
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1012

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4526

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    2.69

 gesamtmenge an niederschlag (mm):       96.0

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     86


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  1.000


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4526
 anzahl hydrotope:      86


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      96.0 mm
 interz.verd.:                       7.5 mm
 bestandsniederschlag:              86.4 mm
 differenz interz.speicher:         -2.1 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      15.8 mm
 aktuelle verdunstung:              11.1 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              86.4 mm
 overlandflow:                       6.8 mm
 [infiltration:                     79.6 mm]
 verdunstung (bodensp.):             3.6 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -76.0 mm
 fehler:                             0.0 mm


 8.27559185  -> zufluss grundwasserleiter in  4526
TG:    4526 -> TG:    4532
Prozent:0.50

TG:    4526 -> TG:    4566
Prozent:0.20

TG:    4526 -> TG:    4567
Prozent:0.30


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:            4.1 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:           9.0 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -5.0 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.608 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.608 qkm



 ISO: Normierungsfaktor   = 1.0002
 ISO: Summe normierter uh =   1.0000


 Anzahl der Zeitschritte in iso durch Nachlauf zu hoch geworden.
 Sie wird auf 460 begrenzt !  gebiet :  4526

fuellenberechnung in iso
abflusz =          4116.838
niederschlag =     4123.956
flaeche zft  =        1.000
flaeche eing.=        0.608

GEBIET: Abflusswelle Interflow:

 ISO: Normierungsfaktor   = 1.0000
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.608

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV: Retentionskonstanten:   1.4       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =       1.00
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH =  264
ISOV:  fuellenberechnung
ISOV: Abflusz =          5754.911
ISOV: Niederschlag =     5754.910

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
ISOV: Retentionskonstanten:6000.0       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =   96602.20
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH = 2880
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1013

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4514

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    2.69

 gesamtmenge an niederschlag (mm):       96.0

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     96


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  8.000


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4514
 anzahl hydrotope:      96


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      96.0 mm
 interz.verd.:                       7.3 mm
 bestandsniederschlag:              86.7 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      16.1 mm
 aktuelle verdunstung:              10.6 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              86.7 mm
 overlandflow:                       1.0 mm
 [infiltration:                     85.7 mm]
 verdunstung (bodensp.):             3.2 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -82.5 mm
 fehler:                             0.0 mm


 2.31466365  -> zufluss grundwasserleiter in  4514
TG:    4514 -> TG:    4515
Prozent:0.15

TG:    4514 -> TG:    4518
Prozent:0.20

TG:    4514 -> TG:    4519
Prozent:0.65


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:            1.0 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:           5.3 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -4.3 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.701 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.701 qkm



 ISO: Normierungsfaktor   = 1.0002
 ISO: Summe normierter uh =   1.0000


 Anzahl der Zeitschritte in iso durch Nachlauf zu hoch geworden.
 Sie wird auf 460 begrenzt !  gebiet :  4514

fuellenberechnung in iso
abflusz =           713.533
niederschlag =      714.765
flaeche zft  =        1.000
flaeche eing.=        0.701

GEBIET: Abflusswelle Interflow:

 ISO: Normierungsfaktor   = 1.0000
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.701

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV: Retentionskonstanten:   1.4       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =       1.00
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH =  264
ISOV:  fuellenberechnung
ISOV: Abflusz =         13002.633
ISOV: Niederschlag =    13002.639

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
ISOV: Retentionskonstanten:6000.0       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =   96602.20
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH = 2880
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1014

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4515

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    2.69

 gesamtmenge an niederschlag (mm):       96.0

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     23


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  8.000


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4515
 anzahl hydrotope:      23


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      96.0 mm
 interz.verd.:                       6.9 mm
 bestandsniederschlag:              87.3 mm
 differenz interz.speicher:         -1.8 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      13.7 mm
 aktuelle verdunstung:               9.4 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              87.3 mm
 overlandflow:                       2.6 mm
 [infiltration:                     84.7 mm]
 verdunstung (bodensp.):             2.5 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -82.2 mm
 fehler:                             0.0 mm


 1.84852171  -> zufluss grundwasserleiter in  4515
TG:    4515 -> TG:    4519
Prozent:1.00


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:            9.3 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:          11.1 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -1.8 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.060 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.060 qkm



 ISO: Normierungsfaktor   = 1.0002
 ISO: Summe normierter uh =   1.0000


 Anzahl der Zeitschritte in iso durch Nachlauf zu hoch geworden.
 Sie wird auf 460 begrenzt !  gebiet :  4515

fuellenberechnung in iso
abflusz =           154.165
niederschlag =      154.432
flaeche zft  =        1.000
flaeche eing.=        0.060

GEBIET: Abflusswelle Interflow:

 ISO: Normierungsfaktor   = 1.0000
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.060

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV: Retentionskonstanten:   0.6       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =       1.00
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH =  125
ISOV:  fuellenberechnung
ISOV: Abflusz =          2193.010
ISOV: Niederschlag =     2193.009

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
ISOV: Retentionskonstanten:6000.0       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =   96602.20
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH = 2880
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1015

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4518

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    2.69

 gesamtmenge an niederschlag (mm):       96.0

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     15


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  2.000


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4518
 anzahl hydrotope:      15


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      96.0 mm
 interz.verd.:                       7.3 mm
 bestandsniederschlag:              86.8 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      15.6 mm
 aktuelle verdunstung:              10.4 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              86.8 mm
 overlandflow:                       0.2 mm
 [infiltration:                     86.6 mm]
 verdunstung (bodensp.):             3.1 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -83.5 mm
 fehler:                             0.0 mm


 2.46469569  -> zufluss grundwasserleiter in  4518
TG:    4518 -> TG:    4519
Prozent:1.00


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:           36.3 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:          43.0 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -6.6 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.020 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.020 qkm



 ISO: Normierungsfaktor   = 1.0002
 ISO: Summe normierter uh =   1.0000


 Anzahl der Zeitschritte in iso durch Nachlauf zu hoch geworden.
 Sie wird auf 460 begrenzt !  gebiet :  4518

fuellenberechnung in iso
abflusz =             3.145
niederschlag =        3.150
flaeche zft  =        1.000
flaeche eing.=        0.020

GEBIET: Abflusswelle Interflow:

 ISO: Normierungsfaktor   = 1.0000
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.020

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV: Retentionskonstanten:   0.6       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =       1.00
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH =  125
ISOV:  fuellenberechnung
ISOV: Abflusz =            86.507
ISOV: Niederschlag =       86.507

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
ISOV: Retentionskonstanten:6000.0       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =   96602.20
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH = 2880
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1016

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4519

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    2.69

 gesamtmenge an niederschlag (mm):       96.0

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     73


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  7.000


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4519
 anzahl hydrotope:      73


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      96.0 mm
 interz.verd.:                       7.2 mm
 bestandsniederschlag:              86.9 mm
 differenz interz.speicher:         -1.9 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      15.4 mm
 aktuelle verdunstung:              10.4 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              86.9 mm
 overlandflow:                       4.1 mm
 [infiltration:                     82.7 mm]
 verdunstung (bodensp.):             3.2 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -79.6 mm
 fehler:                             0.0 mm


 22.6299229  -> zufluss grundwasserleiter in  4519
TG:    4519 -> TG:    4522
Prozent:0.60

TG:    4519 -> TG:    4527
Prozent:0.20

TG:    4519 -> TG:    4530
Prozent:0.10

TG:    4519 -> TG:    4529
Prozent:0.10


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:           24.9 mm
 abgabe basisabfluss:                  4.7 mm
        grundw. unterh.l.TG:          21.2 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -1.0 mm
 fehler:                               0.1 mm


 flaechenanteile: 

   grundwasserleiter:                0.272 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.272 qkm



 ISO: Normierungsfaktor   = 1.0002
 ISO: Summe normierter uh =   1.0000


 Anzahl der Zeitschritte in iso durch Nachlauf zu hoch geworden.
 Sie wird auf 460 begrenzt !  gebiet :  4519

fuellenberechnung in iso
abflusz =          1123.361
niederschlag =     1125.300
flaeche zft  =        1.000
flaeche eing.=        0.272

GEBIET: Abflusswelle Interflow:

 ISO: Normierungsfaktor   = 1.0000
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.272

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV: Retentionskonstanten:   1.2       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =       1.00
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH =  236
ISOV:  fuellenberechnung
ISOV: Abflusz =          4153.080
ISOV: Niederschlag =     4153.083

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
ISOV: Retentionskonstanten:6000.0       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =   96602.20
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH = 2880
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1017

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4522

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    2.69

 gesamtmenge an niederschlag (mm):       96.0

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     19


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  5.000


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4522
 anzahl hydrotope:      19


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      96.0 mm
 interz.verd.:                       7.0 mm
 bestandsniederschlag:              87.2 mm
 differenz interz.speicher:         -1.8 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      14.0 mm
 aktuelle verdunstung:               9.7 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              87.2 mm
 overlandflow:                       9.6 mm
 [infiltration:                     77.6 mm]
 verdunstung (bodensp.):             2.7 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -74.9 mm
 fehler:                             0.0 mm


 13.2926006  -> zufluss grundwasserleiter in  4522
TG:    4522 -> TG:    4524
Prozent:0.60

TG:    4522 -> TG:    4532
Prozent:0.40


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:          111.2 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:         113.6 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -2.5 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.036 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.036 qkm



 ISO: Normierungsfaktor   = 1.0002
 ISO: Summe normierter uh =   1.0000


 Anzahl der Zeitschritte in iso durch Nachlauf zu hoch geworden.
 Sie wird auf 460 begrenzt !  gebiet :  4522

fuellenberechnung in iso
abflusz =           343.949
niederschlag =      344.543
flaeche zft  =        1.000
flaeche eing.=        0.036

GEBIET: Abflusswelle Interflow:

 ISO: Normierungsfaktor   = 1.0000
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.036

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV: Retentionskonstanten:   0.6       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =       1.00
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH =  125
ISOV:  fuellenberechnung
ISOV: Abflusz =          1332.707
ISOV: Niederschlag =     1332.708

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
ISOV: Retentionskonstanten:6000.0       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =   96602.20
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH = 2880
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1018

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4524

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    2.69

 gesamtmenge an niederschlag (mm):       96.0

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     41


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 = 10.000


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4524
 anzahl hydrotope:      41


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      96.0 mm
 interz.verd.:                       7.5 mm
 bestandsniederschlag:              86.0 mm
 differenz interz.speicher:         -2.5 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      14.8 mm
 aktuelle verdunstung:              10.5 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              86.0 mm
 overlandflow:                       4.3 mm
 [infiltration:                     81.7 mm]
 verdunstung (bodensp.):             3.0 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -78.8 mm
 fehler:                             0.0 mm


 30.7884293  -> zufluss grundwasserleiter in  4524
TG:    4524 -> TG:    4532
Prozent:1.00


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:           39.5 mm
 abgabe basisabfluss:                  9.9 mm
        grundw. unterh.l.TG:          30.4 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -0.9 mm
 fehler:                               0.1 mm


 flaechenanteile: 

   grundwasserleiter:                0.234 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.234 qkm



 ISO: Normierungsfaktor   = 1.0002
 ISO: Summe normierter uh =   1.0000


 Anzahl der Zeitschritte in iso durch Nachlauf zu hoch geworden.
 Sie wird auf 460 begrenzt !  gebiet :  4524

fuellenberechnung in iso
abflusz =           994.358
niederschlag =      996.076
flaeche zft  =        1.000
flaeche eing.=        0.234

GEBIET: Abflusswelle Interflow:

 ISO: Normierungsfaktor   = 1.0000
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.234

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV: Retentionskonstanten:   2.8       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =       1.00
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH =  500
ISOV:  fuellenberechnung
ISOV: Abflusz =           578.425
ISOV: Niederschlag =      578.426

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
ISOV: Retentionskonstanten:6000.0       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =   96602.20
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH = 2880
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1019

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4527

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    2.69

 gesamtmenge an niederschlag (mm):       96.0

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     14


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  1.000


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4527
 anzahl hydrotope:      14


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      96.0 mm
 interz.verd.:                       7.3 mm
 bestandsniederschlag:              86.7 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      16.1 mm
 aktuelle verdunstung:              11.0 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              86.7 mm
 overlandflow:                      10.1 mm
 [infiltration:                     76.6 mm]
 verdunstung (bodensp.):             3.6 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -73.0 mm
 fehler:                             0.0 mm


 3.84311342  -> zufluss grundwasserleiter in  4527
TG:    4527 -> TG:    4530
Prozent:0.30

TG:    4527 -> TG:    4529
Prozent:0.70


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:            7.8 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:          10.6 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -2.8 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.148 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.148 qkm



 ISO: Normierungsfaktor   = 1.0002
 ISO: Summe normierter uh =   1.0000


 Anzahl der Zeitschritte in iso durch Nachlauf zu hoch geworden.
 Sie wird auf 460 begrenzt !  gebiet :  4527

fuellenberechnung in iso
abflusz =          1491.047
niederschlag =     1493.623
flaeche zft  =        1.000
flaeche eing.=        0.148

GEBIET: Abflusswelle Interflow:

 ISO: Normierungsfaktor   = 1.0000
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.148

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV: Retentionskonstanten:   1.2       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =       1.00
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH =  236
ISOV:  fuellenberechnung
ISOV: Abflusz =          2642.753
ISOV: Niederschlag =     2642.752

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
ISOV: Retentionskonstanten:6000.0       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =   96602.20
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH = 2880
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1020

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4530

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    2.69

 gesamtmenge an niederschlag (mm):       96.0

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     67


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  2.500


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4530
 anzahl hydrotope:      67


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      96.0 mm
 interz.verd.:                       7.3 mm
 bestandsniederschlag:              86.7 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      16.0 mm
 aktuelle verdunstung:              11.0 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              86.7 mm
 overlandflow:                       9.4 mm
 [infiltration:                     77.4 mm]
 verdunstung (bodensp.):             3.7 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -73.7 mm
 fehler:                             0.0 mm


 3.48185444  -> zufluss grundwasserleiter in  4530
TG:    4530 -> TG:    4532
Prozent:0.70

TG:    4530 -> TG:    4563
Prozent:0.30


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:            3.8 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:           6.9 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -3.1 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.275 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.275 qkm



 ISO: Normierungsfaktor   = 1.0002
 ISO: Summe normierter uh =   1.0000


 Anzahl der Zeitschritte in iso durch Nachlauf zu hoch geworden.
 Sie wird auf 460 begrenzt !  gebiet :  4530

fuellenberechnung in iso
abflusz =          2569.298
niederschlag =     2573.735
flaeche zft  =        1.000
flaeche eing.=        0.275

GEBIET: Abflusswelle Interflow:

 ISO: Normierungsfaktor   = 1.0000
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.275

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV: Retentionskonstanten:   1.2       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =       1.00
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH =  236
ISOV:  fuellenberechnung
ISOV: Abflusz =          4080.632
ISOV: Niederschlag =     4080.634

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
ISOV: Retentionskonstanten:6000.0       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =   96602.20
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH = 2880
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1021

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4532

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    2.69

 gesamtmenge an niederschlag (mm):       96.0

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     85


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  8.000


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4532
 anzahl hydrotope:      85


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      96.0 mm
 interz.verd.:                       8.1 mm
 bestandsniederschlag:              85.4 mm
 differenz interz.speicher:         -2.6 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      15.6 mm
 aktuelle verdunstung:              11.2 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              85.4 mm
 overlandflow:                       5.4 mm
 [infiltration:                     79.9 mm]
 verdunstung (bodensp.):             3.1 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -76.8 mm
 fehler:                             0.0 mm


 42.7465210  -> zufluss grundwasserleiter in  4532
TG:    4532 -> TG:    4563
Prozent:0.25

TG:    4532 -> TG:    4565
Prozent:0.25

TG:    4532 -> TG:    4566
Prozent:0.50


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:            8.8 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:          12.1 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -3.3 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                1.464 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    1.464 qkm



 ISO: Normierungsfaktor   = 1.0002
 ISO: Summe normierter uh =   1.0000


 Anzahl der Zeitschritte in iso durch Nachlauf zu hoch geworden.
 Sie wird auf 460 begrenzt !  gebiet :  4532

fuellenberechnung in iso
abflusz =          7939.862
niederschlag =     7953.581
flaeche zft  =        1.000
flaeche eing.=        1.464

GEBIET: Abflusswelle Interflow:

 ISO: Normierungsfaktor   = 1.0000
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        1.464

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV: Retentionskonstanten:   3.1       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =       1.00
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH =  551
ISOV:  fuellenberechnung
ISOV: Abflusz =          1772.691
ISOV: Niederschlag =     1772.693

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
ISOV: Retentionskonstanten:6000.0       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =   96602.20
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH = 2880
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1022

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4534

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    2.69

 gesamtmenge an niederschlag (mm):       96.0

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     32


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  0.900
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  2.200


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4534
 anzahl hydrotope:      32


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      96.0 mm
 interz.verd.:                       7.4 mm
 bestandsniederschlag:              86.7 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      16.0 mm
 aktuelle verdunstung:              10.1 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              86.7 mm
 overlandflow:                      19.7 mm
 [infiltration:                     67.0 mm]
 verdunstung (bodensp.):             2.8 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -64.2 mm
 fehler:                             0.0 mm


 0.00000000E+00  -> zufluss grundwasserleiter in  4534
TG:    4534 -> TG:    4535
Prozent:0.50

TG:    4534 -> TG:    4542
Prozent:0.15

TG:    4534 -> TG:    4537
Prozent:0.35


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:            0.0 mm
 abgabe basisabfluss:                  1.3 mm
        grundw. unterh.l.TG:          11.8 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:               -13.1 mm
     pot.entnahme GWS:               -13.1 mm
 speicherinhaltsaenderung:             0.0 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.299 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.299 qkm



 ISO: Normierungsfaktor   = 1.0001
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =          5894.124
niederschlag =     5894.127
flaeche zft  =        1.000
flaeche eing.=        0.299

GEBIET: Abflusswelle Interflow:

 ISO: Normierungsfaktor   = 1.0000
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.299

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV: Retentionskonstanten:   0.2       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =       1.00
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH =   38
ISOV:  fuellenberechnung
ISOV: Abflusz =          5944.131
ISOV: Niederschlag =     5944.138

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
ISOV: Retentionskonstanten:6000.0       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =   96602.20
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH = 2880
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1023

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4542

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    2.69

 gesamtmenge an niederschlag (mm):       96.0

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     49


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  0.900
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  1.500


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4542
 anzahl hydrotope:      49


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      96.0 mm
 interz.verd.:                       7.3 mm
 bestandsniederschlag:              86.7 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      16.2 mm
 aktuelle verdunstung:              10.2 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              86.7 mm
 overlandflow:                      19.7 mm
 [infiltration:                     67.0 mm]
 verdunstung (bodensp.):             2.8 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -64.1 mm
 fehler:                             0.0 mm


 1.76380777  -> zufluss grundwasserleiter in  4542
TG:    4542 -> TG:    4543
Prozent:0.80

TG:    4542 -> TG:    4544
Prozent:0.20


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:            1.3 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:           3.3 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -2.0 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.395 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.395 qkm



 ISO: Normierungsfaktor   = 1.0001
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =          7793.380
niederschlag =     7793.380
flaeche zft  =        1.000
flaeche eing.=        0.395

GEBIET: Abflusswelle Interflow:

 ISO: Normierungsfaktor   = 1.0000
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.395

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV: Retentionskonstanten:   0.4       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =       1.00
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH =   90
ISOV:  fuellenberechnung
ISOV: Abflusz =          5141.142
ISOV: Niederschlag =     5141.148

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
ISOV: Retentionskonstanten:6000.0       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =   96602.20
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH = 2880
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1024

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4537

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    2.69

 gesamtmenge an niederschlag (mm):       96.0

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     19


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  0.900
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  2.700


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4537
 anzahl hydrotope:      19


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      96.0 mm
 interz.verd.:                       7.3 mm
 bestandsniederschlag:              86.7 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      16.1 mm
 aktuelle verdunstung:              10.2 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              86.7 mm
 overlandflow:                      19.7 mm
 [infiltration:                     67.0 mm]
 verdunstung (bodensp.):             2.8 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -64.2 mm
 fehler:                             0.0 mm


 4.11544704  -> zufluss grundwasserleiter in  4537
TG:    4537 -> TG:    4539
Prozent:0.90

TG:    4537 -> TG:    4543
Prozent:0.10


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:           19.4 mm
 abgabe basisabfluss:                  4.9 mm
        grundw. unterh.l.TG:          26.6 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:               -11.8 mm
     pot.entnahme GWS:               -11.8 mm
 speicherinhaltsaenderung:            -0.2 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.064 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.064 qkm



 ISO: Normierungsfaktor   = 1.0001
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =          1254.671
niederschlag =     1254.671
flaeche zft  =        1.000
flaeche eing.=        0.064

GEBIET: Abflusswelle Interflow:

 ISO: Normierungsfaktor   = 1.0000
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.064

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV: Retentionskonstanten:   0.5       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =       1.00
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH =  105
ISOV:  fuellenberechnung
ISOV: Abflusz =           850.007
ISOV: Niederschlag =      850.007

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
ISOV: Retentionskonstanten:6000.0       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =   96602.20
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH = 2880
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1025

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4543

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    2.69

 gesamtmenge an niederschlag (mm):       96.0

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     80


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  0.900
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  2.000


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4543
 anzahl hydrotope:      80


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      96.0 mm
 interz.verd.:                       7.3 mm
 bestandsniederschlag:              86.7 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      16.1 mm
 aktuelle verdunstung:              10.1 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              86.7 mm
 overlandflow:                      19.7 mm
 [infiltration:                     67.0 mm]
 verdunstung (bodensp.):             2.8 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -64.2 mm
 fehler:                             0.0 mm


 4.07773209  -> zufluss grundwasserleiter in  4543
TG:    4543 -> TG:    4544
Prozent:0.10

TG:    4543 -> TG:    4551
Prozent:0.50

TG:    4543 -> TG:    4549
Prozent:0.40


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:            1.3 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:           4.5 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -3.1 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.918 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.918 qkm



 ISO: Normierungsfaktor   = 1.0001
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =         18130.254
niederschlag =    18130.250
flaeche zft  =        1.000
flaeche eing.=        0.918

GEBIET: Abflusswelle Interflow:

 ISO: Normierungsfaktor   = 1.0000
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.918

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV: Retentionskonstanten:   0.4       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =       1.00
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH =   90
ISOV:  fuellenberechnung
ISOV: Abflusz =         14001.056
ISOV: Niederschlag =    14001.077

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
ISOV: Retentionskonstanten:6000.0       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =   96602.20
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH = 2880
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1026

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4549

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    2.69

 gesamtmenge an niederschlag (mm):       96.0

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     73


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  0.900
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  1.000


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4549
 anzahl hydrotope:      73


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      96.0 mm
 interz.verd.:                       7.3 mm
 bestandsniederschlag:              86.7 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      16.1 mm
 aktuelle verdunstung:              10.2 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              86.7 mm
 overlandflow:                      21.7 mm
 [infiltration:                     65.0 mm]
 verdunstung (bodensp.):             2.8 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -62.2 mm
 fehler:                             0.0 mm


 5.47681570  -> zufluss grundwasserleiter in  4549
TG:    4549 -> TG:    4551
Prozent:0.40

TG:    4549 -> TG:    4558
Prozent:0.60


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:            1.5 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:           6.1 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -4.6 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                1.076 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    1.076 qkm



 ISO: Normierungsfaktor   = 1.0001
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =         23332.633
niederschlag =    23332.619
flaeche zft  =        1.000
flaeche eing.=        1.076

GEBIET: Abflusswelle Interflow:

 ISO: Normierungsfaktor   = 1.0000
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        1.076

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV: Retentionskonstanten:   0.4       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =       1.00
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH =   86
ISOV:  fuellenberechnung
ISOV: Abflusz =         15644.693
ISOV: Niederschlag =    15644.694

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
ISOV: Retentionskonstanten:6000.0       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =   96602.20
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH = 2880
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1027

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4551

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    2.69

 gesamtmenge an niederschlag (mm):       96.0

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:    113


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  0.900
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  2.000


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4551
 anzahl hydrotope:     113


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      96.0 mm
 interz.verd.:                       7.3 mm
 bestandsniederschlag:              86.7 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      16.1 mm
 aktuelle verdunstung:              10.2 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              86.7 mm
 overlandflow:                      36.1 mm
 [infiltration:                     50.6 mm]
 verdunstung (bodensp.):             2.9 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -47.7 mm
 fehler:                             0.0 mm


 15.5802021  -> zufluss grundwasserleiter in  4551
TG:    4551 -> TG:    4553
Prozent:0.40

TG:    4551 -> TG:    4558
Prozent:0.30

TG:    4551 -> TG:    4552
Prozent:0.30


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:            7.3 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:          15.2 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -7.9 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.641 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.641 qkm



 ISO: Normierungsfaktor   = 1.0001
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =         23181.393
niederschlag =    23181.395
flaeche zft  =        1.000
flaeche eing.=        0.641

GEBIET: Abflusswelle Interflow:

 ISO: Normierungsfaktor   = 1.0000
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.641

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV: Retentionskonstanten:   0.4       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =       1.00
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH =   78
ISOV:  fuellenberechnung
ISOV: Abflusz =          9383.272
ISOV: Niederschlag =     9383.265

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
ISOV: Retentionskonstanten:6000.0       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =   96602.20
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH = 2880
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1028

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4552

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    2.69

 gesamtmenge an niederschlag (mm):       96.0

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     31


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  0.900
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  7.000


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4552
 anzahl hydrotope:      31


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      96.0 mm
 interz.verd.:                       7.3 mm
 bestandsniederschlag:              86.8 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      15.9 mm
 aktuelle verdunstung:              10.1 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              86.8 mm
 overlandflow:                      27.5 mm
 [infiltration:                     59.2 mm]
 verdunstung (bodensp.):             2.8 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -56.5 mm
 fehler:                             0.0 mm


 9.74566078  -> zufluss grundwasserleiter in  4552
TG:    4552 -> TG:    4553
Prozent:0.50

TG:    4552 -> TG:    4558
Prozent:0.50


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:           39.3 mm
 abgabe basisabfluss:                 17.6 mm
        grundw. unterh.l.TG:          22.5 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -1.0 mm
 fehler:                               0.2 mm


 flaechenanteile: 

   grundwasserleiter:                0.074 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.074 qkm



 ISO: Normierungsfaktor   = 1.0001
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =          2049.083
niederschlag =     2049.083
flaeche zft  =        1.000
flaeche eing.=        0.074

GEBIET: Abflusswelle Interflow:

 ISO: Normierungsfaktor   = 1.0000
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.074

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV: Retentionskonstanten:   0.2       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =       1.00
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH =   52
ISOV:  fuellenberechnung
ISOV: Abflusz =          1618.194
ISOV: Niederschlag =     1618.194

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
ISOV: Retentionskonstanten:6000.0       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =   96602.20
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH = 2880
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1029

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4553

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    2.69

 gesamtmenge an niederschlag (mm):       96.0

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     35


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  0.900
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 = 12.200


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4553
 anzahl hydrotope:      35


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      96.0 mm
 interz.verd.:                       7.3 mm
 bestandsniederschlag:              86.8 mm
 differenz interz.speicher:         -1.9 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      15.8 mm
 aktuelle verdunstung:              10.0 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              86.8 mm
 overlandflow:                      20.1 mm
 [infiltration:                     66.7 mm]
 verdunstung (bodensp.):             2.7 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -64.0 mm
 fehler:                             0.0 mm


 15.7821541  -> zufluss grundwasserleiter in  4553
TG:    4553 -> TG:    4558
Prozent:1.00


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:           78.5 mm
 abgabe basisabfluss:                 15.9 mm
        grundw. unterh.l.TG:          63.6 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -1.2 mm
 fehler:                               0.2 mm


 flaechenanteile: 

   grundwasserleiter:                0.060 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.060 qkm



 ISO: Normierungsfaktor   = 1.0001
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =          1210.731
niederschlag =     1210.732
flaeche zft  =        1.000
flaeche eing.=        0.060

GEBIET: Abflusswelle Interflow:

 ISO: Normierungsfaktor   = 1.0000
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.060

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV: Retentionskonstanten:   0.2       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =       1.00
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH =   36
ISOV:  fuellenberechnung
ISOV: Abflusz =          1504.645
ISOV: Niederschlag =     1504.645

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
ISOV: Retentionskonstanten:6000.0       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =   96602.20
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH = 2880
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1030

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4558

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    2.69

 gesamtmenge an niederschlag (mm):       96.0

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     90


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  0.900
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 = 10.000


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4558
 anzahl hydrotope:      90


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      96.0 mm
 interz.verd.:                       7.3 mm
 bestandsniederschlag:              86.7 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      15.9 mm
 aktuelle verdunstung:              10.5 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              86.7 mm
 overlandflow:                      40.7 mm
 [infiltration:                     46.0 mm]
 verdunstung (bodensp.):             3.1 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -42.9 mm
 fehler:                             0.0 mm


 38.4231071  -> zufluss grundwasserleiter in  4558
TG:    4558 -> TG:    4561
Prozent:0.50

TG:    4558 -> TG:    4564
Prozent:0.50


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:           28.8 mm
 abgabe basisabfluss:                  2.8 mm
        grundw. unterh.l.TG:          27.7 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -1.7 mm
 fehler:                               0.1 mm


 flaechenanteile: 

   grundwasserleiter:                0.400 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.400 qkm



 ISO: Normierungsfaktor   = 1.0001
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =         16273.797
niederschlag =    16273.801
flaeche zft  =        1.000
flaeche eing.=        0.400

GEBIET: Abflusswelle Interflow:

 ISO: Normierungsfaktor   = 1.0000
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.400

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV: Retentionskonstanten:   0.1       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =       1.00
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH =   32
ISOV:  fuellenberechnung
ISOV: Abflusz =          4583.693
ISOV: Niederschlag =     4583.692

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
ISOV: Retentionskonstanten:6000.0       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =   96602.20
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH = 2880
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1031

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4533

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    2.69

 gesamtmenge an niederschlag (mm):       96.0

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     26


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  0.900
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  0.500


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4533
 anzahl hydrotope:      26


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      96.0 mm
 interz.verd.:                       7.3 mm
 bestandsniederschlag:              86.7 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      16.1 mm
 aktuelle verdunstung:              10.1 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              86.7 mm
 overlandflow:                      19.7 mm
 [infiltration:                     67.0 mm]
 verdunstung (bodensp.):             2.8 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -64.2 mm
 fehler:                             0.0 mm


 entnahme gws [qbm/s]:       0.000
 0.00000000E+00  -> zufluss grundwasserleiter in  4533
TG:    4533 -> TG:    4535
Prozent:1.00


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:            0.0 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:           3.5 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.2 mm
     pot.entnahme GWS:                 0.2 mm
 speicherinhaltsaenderung:            -3.6 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.211 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.211 qkm



 ISO: Normierungsfaktor   = 1.0002
 ISO: Summe normierter uh =   1.0000


 Anzahl der Zeitschritte in iso durch Nachlauf zu hoch geworden.
 Sie wird auf 460 begrenzt !  gebiet :  4533

fuellenberechnung in iso
abflusz =          4151.532
niederschlag =     4158.703
flaeche zft  =        1.000
flaeche eing.=        0.211

GEBIET: Abflusswelle Interflow:

 ISO: Normierungsfaktor   = 1.0000
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.211

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV: Retentionskonstanten:   1.5       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =       1.00
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH =  291
ISOV:  fuellenberechnung
ISOV: Abflusz =          3520.111
ISOV: Niederschlag =     3520.110

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
ISOV: Retentionskonstanten:6000.0       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =   96602.20
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH = 2880
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1032

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4535

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    2.69

 gesamtmenge an niederschlag (mm):       96.0

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     16


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  0.900
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  2.500


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4535
 anzahl hydrotope:      16


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      96.0 mm
 interz.verd.:                       7.6 mm
 bestandsniederschlag:              86.3 mm
 differenz interz.speicher:         -2.2 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      16.2 mm
 aktuelle verdunstung:              10.4 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              86.3 mm
 overlandflow:                      19.8 mm
 [infiltration:                     66.5 mm]
 verdunstung (bodensp.):             2.8 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -63.7 mm
 fehler:                             0.0 mm


 8.30385113  -> zufluss grundwasserleiter in  4535
TG:    4535 -> TG:    4539
Prozent:1.00


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:            9.4 mm
 abgabe basisabfluss:                  3.9 mm
        grundw. unterh.l.TG:           5.9 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -0.5 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.266 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.266 qkm



 ISO: Normierungsfaktor   = 1.0001
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =          5268.114
niederschlag =     5268.119
flaeche zft  =        1.000
flaeche eing.=        0.266

GEBIET: Abflusswelle Interflow:

 ISO: Normierungsfaktor   = 1.0000
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.266

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV: Retentionskonstanten:   0.5       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =       1.00
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH =  105
ISOV:  fuellenberechnung
ISOV: Abflusz =          1355.986
ISOV: Niederschlag =     1355.986

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
ISOV: Retentionskonstanten:6000.0       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =   96602.20
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH = 2880
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1033

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4539

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    2.69

 gesamtmenge an niederschlag (mm):       96.0

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     66


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  0.900
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  8.000


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4539
 anzahl hydrotope:      66


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      96.0 mm
 interz.verd.:                       8.6 mm
 bestandsniederschlag:              84.5 mm
 differenz interz.speicher:         -2.9 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      16.4 mm
 aktuelle verdunstung:              11.0 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              84.5 mm
 overlandflow:                      19.7 mm
 [infiltration:                     64.8 mm]
 verdunstung (bodensp.):             2.4 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -62.4 mm
 fehler:                             0.0 mm


 entnahme gws [qbm/s]:       0.001
 10.3070755  -> zufluss grundwasserleiter in  4539
TG:    4539 -> TG:    4541
Prozent:0.70

TG:    4539 -> TG:    4547
Prozent:0.10

TG:    4539 -> TG:    4554
Prozent:0.20


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:            1.1 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:           5.2 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.1 mm
     pot.entnahme GWS:                 0.1 mm
 speicherinhaltsaenderung:            -4.3 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                2.864 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    2.864 qkm



 ISO: Normierungsfaktor   = 1.0001
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =         56525.289
niederschlag =    56525.414
flaeche zft  =        1.000
flaeche eing.=        2.864

GEBIET: Abflusswelle Interflow:

 ISO: Normierungsfaktor   = 1.0000
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        2.864

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV: Retentionskonstanten:   0.5       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =       1.00
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH =   95
ISOV:  fuellenberechnung
ISOV: Abflusz =         24771.697
ISOV: Niederschlag =    24771.664

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
ISOV: Retentionskonstanten:6000.0       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =   96602.20
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH = 2880
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1034

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4541

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    2.69

 gesamtmenge an niederschlag (mm):       96.0

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     46


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  0.900
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  5.000


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4541
 anzahl hydrotope:      46


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      96.0 mm
 interz.verd.:                       7.9 mm
 bestandsniederschlag:              85.7 mm
 differenz interz.speicher:         -2.4 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      16.1 mm
 aktuelle verdunstung:              10.7 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              85.7 mm
 overlandflow:                      26.5 mm
 [infiltration:                     59.2 mm]
 verdunstung (bodensp.):             2.8 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -56.4 mm
 fehler:                             0.0 mm


 34.7793770  -> zufluss grundwasserleiter in  4541
TG:    4541 -> TG:    4548
Prozent:0.20

TG:    4541 -> TG:    4554
Prozent:0.15

TG:    4541 -> TG:    4556
Prozent:0.65


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:           26.0 mm
 abgabe basisabfluss:                  3.6 mm
        grundw. unterh.l.TG:          22.9 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -0.5 mm
 fehler:                               0.1 mm


 flaechenanteile: 

   grundwasserleiter:                0.401 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.401 qkm



 ISO: Normierungsfaktor   = 1.0001
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =         10629.327
niederschlag =    10629.322
flaeche zft  =        1.000
flaeche eing.=        0.401

GEBIET: Abflusswelle Interflow:

 ISO: Normierungsfaktor   = 1.0000
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.401

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV: Retentionskonstanten:   0.3       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =       1.00
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH =   56
ISOV:  fuellenberechnung
ISOV: Abflusz =          7072.717
ISOV: Niederschlag =     7072.717

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
ISOV: Retentionskonstanten:6000.0       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =   96602.20
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH = 2880
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1035

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4547

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    2.69

 gesamtmenge an niederschlag (mm):       96.0

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     38


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  0.900
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  2.750


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4547
 anzahl hydrotope:      38


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      96.0 mm
 interz.verd.:                       7.4 mm
 bestandsniederschlag:              86.7 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      16.3 mm
 aktuelle verdunstung:              11.3 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              86.7 mm
 overlandflow:                      49.2 mm
 [infiltration:                     37.5 mm]
 verdunstung (bodensp.):             3.9 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -33.6 mm
 fehler:                             0.0 mm


 4.96848679  -> zufluss grundwasserleiter in  4547
TG:    4547 -> TG:    4548
Prozent:1.00


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:           13.2 mm
 abgabe basisabfluss:                  8.1 mm
        grundw. unterh.l.TG:          17.6 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:               -12.4 mm
     pot.entnahme GWS:               -12.4 mm
 speicherinhaltsaenderung:             0.0 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.113 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.113 qkm



 ISO: Normierungsfaktor   = 1.0001
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =          5539.383
niederschlag =     5539.381
flaeche zft  =        1.000
flaeche eing.=        0.113

GEBIET: Abflusswelle Interflow:

 ISO: Normierungsfaktor   = 1.0000
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.113

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV: Retentionskonstanten:   0.1       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =       1.00
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH =   26
ISOV:  fuellenberechnung
ISOV: Abflusz =          2806.697
ISOV: Niederschlag =     2806.698

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
ISOV: Retentionskonstanten:6000.0       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =   96602.20
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH = 2880
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1036

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4544

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    2.69

 gesamtmenge an niederschlag (mm):       96.0

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     49


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  0.900
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  2.000


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4544
 anzahl hydrotope:      49


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      96.0 mm
 interz.verd.:                       7.4 mm
 bestandsniederschlag:              86.7 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      16.2 mm
 aktuelle verdunstung:              10.4 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              86.7 mm
 overlandflow:                      24.8 mm
 [infiltration:                     61.9 mm]
 verdunstung (bodensp.):             3.0 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -58.9 mm
 fehler:                             0.0 mm


 2.24781537  -> zufluss grundwasserleiter in  4544
TG:    4544 -> TG:    4546
Prozent:1.00


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:            1.8 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:           4.9 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                -0.7 mm
     pot.entnahme GWS:                -0.7 mm
 speicherinhaltsaenderung:            -2.5 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.385 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.385 qkm



 ISO: Normierungsfaktor   = 1.0001
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =          9534.979
niederschlag =     9534.989
flaeche zft  =        1.000
flaeche eing.=        0.385

GEBIET: Abflusswelle Interflow:

 ISO: Normierungsfaktor   = 1.0000
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.385

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV: Retentionskonstanten:   0.3       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =       1.00
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH =   68
ISOV:  fuellenberechnung
ISOV: Abflusz =          5921.012
ISOV: Niederschlag =     5921.012

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
ISOV: Retentionskonstanten:6000.0       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =   96602.20
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH = 2880
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1037

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4546

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    2.69

 gesamtmenge an niederschlag (mm):       96.0

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     67


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  0.900
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  2.250


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4546
 anzahl hydrotope:      67


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      96.0 mm
 interz.verd.:                       7.3 mm
 bestandsniederschlag:              86.7 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      16.2 mm
 aktuelle verdunstung:              10.5 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              86.7 mm
 overlandflow:                      39.5 mm
 [infiltration:                     47.2 mm]
 verdunstung (bodensp.):             3.2 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -44.1 mm
 fehler:                             0.0 mm


 6.31676960  -> zufluss grundwasserleiter in  4546
TG:    4546 -> TG:    4548
Prozent:1.00


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:            8.8 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:          12.8 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -4.0 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.216 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.216 qkm



 ISO: Normierungsfaktor   = 1.0001
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =          8519.077
niederschlag =     8519.075
flaeche zft  =        1.000
flaeche eing.=        0.216

GEBIET: Abflusswelle Interflow:

 ISO: Normierungsfaktor   = 1.0000
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.216

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV: Retentionskonstanten:   0.2       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =       1.00
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH =   48
ISOV:  fuellenberechnung
ISOV: Abflusz =          3178.922
ISOV: Niederschlag =     3178.923

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
ISOV: Retentionskonstanten:6000.0       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =   96602.20
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH = 2880
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1038

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4548

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    2.69

 gesamtmenge an niederschlag (mm):       96.0

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:    125


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  0.900
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  2.000


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4548
 anzahl hydrotope:     125


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      96.0 mm
 interz.verd.:                       7.3 mm
 bestandsniederschlag:              86.7 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      16.2 mm
 aktuelle verdunstung:              10.5 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              86.7 mm
 overlandflow:                      30.3 mm
 [infiltration:                     56.5 mm]
 verdunstung (bodensp.):             3.1 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -53.3 mm
 fehler:                             0.0 mm


 21.9350929  -> zufluss grundwasserleiter in  4548
TG:    4548 -> TG:    4556
Prozent:0.50

TG:    4548 -> TG:    4559
Prozent:0.50


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:           13.6 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:          17.9 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -4.3 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.483 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.483 qkm



 ISO: Normierungsfaktor   = 1.0001
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =         14600.454
niederschlag =    14600.455
flaeche zft  =        1.000
flaeche eing.=        0.483

GEBIET: Abflusswelle Interflow:

 ISO: Normierungsfaktor   = 1.0000
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.483

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV: Retentionskonstanten:   0.2       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =       1.00
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH =   44
ISOV:  fuellenberechnung
ISOV: Abflusz =          7281.374
ISOV: Niederschlag =     7281.377

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
ISOV: Retentionskonstanten:6000.0       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =   96602.20
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH = 2880
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1039

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4554

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    2.69

 gesamtmenge an niederschlag (mm):       96.0

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     34


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  0.900
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  3.000


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4554
 anzahl hydrotope:      34


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      96.0 mm
 interz.verd.:                       7.5 mm
 bestandsniederschlag:              86.5 mm
 differenz interz.speicher:         -2.1 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      15.7 mm
 aktuelle verdunstung:              10.1 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              86.5 mm
 overlandflow:                      19.7 mm
 [infiltration:                     66.8 mm]
 verdunstung (bodensp.):             2.6 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -64.2 mm
 fehler:                             0.0 mm


 14.5307360  -> zufluss grundwasserleiter in  4554
TG:    4554 -> TG:    4556
Prozent:0.50

TG:    4554 -> TG:    4559
Prozent:0.50


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:            8.0 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:          12.4 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -4.4 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.547 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.547 qkm



 ISO: Normierungsfaktor   = 1.0000
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =         10784.442
niederschlag =    10784.438
flaeche zft  =        1.000
flaeche eing.=        0.547

GEBIET: Abflusswelle Interflow:

 ISO: Normierungsfaktor   = 1.0001
 ISO: Summe normierter uh =   1.0000


 Anzahl der Zeitschritte in iso durch Nachlauf zu hoch geworden.
 Sie wird auf 460 begrenzt !  gebiet :  4554

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.547

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV: Retentionskonstanten:   0.3       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =       1.00
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH =   62
ISOV:  fuellenberechnung
ISOV: Abflusz =         13482.629
ISOV: Niederschlag =    13482.649

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
ISOV: Retentionskonstanten:6000.0       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =   96602.20
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH = 2880
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1040

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4556

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    2.69

 gesamtmenge an niederschlag (mm):       96.0

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:    105


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  0.900
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 = 12.000


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4556
 anzahl hydrotope:     105


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      96.0 mm
 interz.verd.:                       7.3 mm
 bestandsniederschlag:              86.7 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      16.0 mm
 aktuelle verdunstung:              10.1 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              86.7 mm
 overlandflow:                      20.2 mm
 [infiltration:                     66.5 mm]
 verdunstung (bodensp.):             2.8 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -63.7 mm
 fehler:                             0.0 mm


 45.5907516  -> zufluss grundwasserleiter in  4556
TG:    4556 -> TG:    4559
Prozent:1.00


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:           15.1 mm
 abgabe basisabfluss:                  3.5 mm
        grundw. unterh.l.TG:          12.9 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                -0.6 mm
     pot.entnahme GWS:                -0.6 mm
 speicherinhaltsaenderung:            -0.9 mm
 fehler:                               0.2 mm


 flaechenanteile: 

   grundwasserleiter:                0.904 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.904 qkm



 ISO: Normierungsfaktor   = 1.0001
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =         18270.914
niederschlag =    18270.947
flaeche zft  =        1.000
flaeche eing.=        0.904

GEBIET: Abflusswelle Interflow:

 ISO: Normierungsfaktor   = 1.0000
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.904

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV: Retentionskonstanten:   0.6       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =       1.00
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH =  112
ISOV:  fuellenberechnung
ISOV: Abflusz =         19222.818
ISOV: Niederschlag =    19222.809

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
ISOV: Retentionskonstanten:6000.0       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =   96602.20
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH = 2880
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1041

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4559

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    2.69

 gesamtmenge an niederschlag (mm):       96.0

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:    121


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  0.900
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  4.000


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4559
 anzahl hydrotope:     121


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      96.0 mm
 interz.verd.:                       7.3 mm
 bestandsniederschlag:              86.8 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      15.9 mm
 aktuelle verdunstung:              10.1 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              86.8 mm
 overlandflow:                      31.3 mm
 [infiltration:                     55.5 mm]
 verdunstung (bodensp.):             2.8 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -52.7 mm
 fehler:                             0.0 mm


 64.6178284  -> zufluss grundwasserleiter in  4559
TG:    4559 -> TG:    4560
Prozent:0.10

TG:    4559 -> TG:    4564
Prozent:0.60

TG:    4559 -> TG:    4589
Prozent:0.30


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:           27.0 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:          34.1 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                -1.6 mm
     pot.entnahme GWS:                -1.6 mm
 speicherinhaltsaenderung:            -5.5 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.718 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.718 qkm



 ISO: Normierungsfaktor   = 1.0001
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =         22462.482
niederschlag =    22462.441
flaeche zft  =        1.000
flaeche eing.=        0.718

GEBIET: Abflusswelle Interflow:

 ISO: Normierungsfaktor   = 1.0000
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.718

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV: Retentionskonstanten:   0.5       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =       1.00
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH =  105
ISOV:  fuellenberechnung
ISOV: Abflusz =         12609.128
ISOV: Niederschlag =    12609.135

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
ISOV: Retentionskonstanten:6000.0       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =   96602.20
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH = 2880
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1042

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4560

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    2.69

 gesamtmenge an niederschlag (mm):       96.0

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:      4


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  0.900
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  7.500


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4560
 anzahl hydrotope:       4


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      96.0 mm
 interz.verd.:                       6.9 mm
 bestandsniederschlag:              87.4 mm
 differenz interz.speicher:         -1.7 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      13.5 mm
 aktuelle verdunstung:               8.8 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              87.4 mm
 overlandflow:                      19.6 mm
 [infiltration:                     67.8 mm]
 verdunstung (bodensp.):             1.9 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -66.0 mm
 fehler:                             0.0 mm


 8.15345573  -> zufluss grundwasserleiter in  4560
TG:    4560 -> TG:    4564
Prozent:1.00


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:           71.8 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:          79.7 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -7.9 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.034 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.034 qkm



 ISO: Normierungsfaktor   = 1.0001
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =           666.604
niederschlag =      666.603
flaeche zft  =        1.000
flaeche eing.=        0.034

GEBIET: Abflusswelle Interflow:

 ISO: Normierungsfaktor   = 1.0000
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.034

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV: Retentionskonstanten:   0.5       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =       1.00
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH =  105
ISOV:  fuellenberechnung
ISOV: Abflusz =          1484.671
ISOV: Niederschlag =     1484.670

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
ISOV: Retentionskonstanten:6000.0       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =   96602.20
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH = 2880
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1043

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4561

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    2.69

 gesamtmenge an niederschlag (mm):       96.0

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     28


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  0.900
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  6.300


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4561
 anzahl hydrotope:      28


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      96.0 mm
 interz.verd.:                       6.9 mm
 bestandsniederschlag:              87.3 mm
 differenz interz.speicher:         -1.8 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      13.8 mm
 aktuelle verdunstung:               9.3 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              87.3 mm
 overlandflow:                      46.6 mm
 [infiltration:                     40.7 mm]
 verdunstung (bodensp.):             2.4 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -38.3 mm
 fehler:                             0.0 mm


 18.4201660  -> zufluss grundwasserleiter in  4561
TG:    4561 -> TG:    4564
Prozent:0.90

TG:    4561 -> TG:    4565
Prozent:0.10


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:          101.7 mm
 abgabe basisabfluss:                 67.5 mm
        grundw. unterh.l.TG:          34.4 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -0.4 mm
 fehler:                               0.1 mm


 flaechenanteile: 

   grundwasserleiter:                0.054 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.054 qkm



 ISO: Normierungsfaktor   = 1.0001
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =          2533.370
niederschlag =     2533.375
flaeche zft  =        1.000
flaeche eing.=        0.054

GEBIET: Abflusswelle Interflow:

 ISO: Normierungsfaktor   = 1.0000
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.054

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV: Retentionskonstanten:   0.5       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =       1.00
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH =  105
ISOV:  fuellenberechnung
ISOV: Abflusz =          2107.347
ISOV: Niederschlag =     2107.348

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
ISOV: Retentionskonstanten:6000.0       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =   96602.20
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH = 2880
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1044

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4529

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    2.69

 gesamtmenge an niederschlag (mm):       96.0

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     23


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  3.000


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4529
 anzahl hydrotope:      23


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      96.0 mm
 interz.verd.:                       7.0 mm
 bestandsniederschlag:              87.1 mm
 differenz interz.speicher:         -1.8 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      13.8 mm
 aktuelle verdunstung:               9.6 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              87.1 mm
 overlandflow:                       8.5 mm
 [infiltration:                     78.6 mm]
 verdunstung (bodensp.):             2.6 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -76.1 mm
 fehler:                             0.0 mm


 5.56225014  -> zufluss grundwasserleiter in  4529
TG:    4529 -> TG:    4563
Prozent:1.00


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:           25.2 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:          26.5 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -1.3 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.066 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.066 qkm



 ISO: Normierungsfaktor   = 1.0002
 ISO: Summe normierter uh =   1.0000


 Anzahl der Zeitschritte in iso durch Nachlauf zu hoch geworden.
 Sie wird auf 460 begrenzt !  gebiet :  4529

fuellenberechnung in iso
abflusz =           561.073
niederschlag =      562.042
flaeche zft  =        1.000
flaeche eing.=        0.066

GEBIET: Abflusswelle Interflow:

 ISO: Normierungsfaktor   = 1.0000
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.066

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV: Retentionskonstanten:   0.6       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =       1.00
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH =  125
ISOV:  fuellenberechnung
ISOV: Abflusz =          2566.772
ISOV: Niederschlag =     2566.771

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
ISOV: Retentionskonstanten:6000.0       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =   96602.20
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH = 2880
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1045

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4563

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    2.69

 gesamtmenge an niederschlag (mm):       96.0

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     28


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  4.000


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4563
 anzahl hydrotope:      28


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      96.0 mm
 interz.verd.:                       7.7 mm
 bestandsniederschlag:              86.1 mm
 differenz interz.speicher:         -2.2 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      15.8 mm
 aktuelle verdunstung:              11.7 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              86.1 mm
 overlandflow:                      10.3 mm
 [infiltration:                     75.8 mm]
 verdunstung (bodensp.):             4.0 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -71.8 mm
 fehler:                             0.0 mm


 22.5192699  -> zufluss grundwasserleiter in  4563
TG:    4563 -> TG:    4564
Prozent:0.30

TG:    4563 -> TG:    4565
Prozent:0.70


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:           48.1 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:          49.8 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -1.8 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.141 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.141 qkm



 ISO: Normierungsfaktor   = 1.0002
 ISO: Summe normierter uh =   1.0000


 Anzahl der Zeitschritte in iso durch Nachlauf zu hoch geworden.
 Sie wird auf 460 begrenzt !  gebiet :  4563

fuellenberechnung in iso
abflusz =          1443.707
niederschlag =     1446.203
flaeche zft  =        1.000
flaeche eing.=        0.141

GEBIET: Abflusswelle Interflow:

 ISO: Normierungsfaktor   = 1.0000
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.141

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV: Retentionskonstanten:   1.4       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =       1.00
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH =  264
ISOV:  fuellenberechnung
ISOV: Abflusz =          1020.331
ISOV: Niederschlag =     1020.331

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
ISOV: Retentionskonstanten:6000.0       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =   96602.20
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH = 2880
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1046

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4564

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    2.69

 gesamtmenge an niederschlag (mm):       96.0

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:    108


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  8.500


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4564
 anzahl hydrotope:     108


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      96.0 mm
 interz.verd.:                       7.4 mm
 bestandsniederschlag:              86.7 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      16.0 mm
 aktuelle verdunstung:              11.1 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              86.7 mm
 overlandflow:                       6.6 mm
 [infiltration:                     80.1 mm]
 verdunstung (bodensp.):             3.8 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -76.3 mm
 fehler:                             0.0 mm


 89.0123215  -> zufluss grundwasserleiter in  4564
TG:    4564 -> TG:    4565
Prozent:0.40

TG:    4564 -> TG:    4566
Prozent:0.40

TG:    4564 -> TG:    4571
Prozent:0.20


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:           34.5 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:          35.5 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -1.0 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.773 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.773 qkm



 ISO: Normierungsfaktor   = 1.0002
 ISO: Summe normierter uh =   1.0000


 Anzahl der Zeitschritte in iso durch Nachlauf zu hoch geworden.
 Sie wird auf 460 begrenzt !  gebiet :  4564

fuellenberechnung in iso
abflusz =          5090.364
niederschlag =     5099.155
flaeche zft  =        1.000
flaeche eing.=        0.773

GEBIET: Abflusswelle Interflow:

 ISO: Normierungsfaktor   = 1.0000
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.773

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV: Retentionskonstanten:   1.4       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =       1.00
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH =  264
ISOV:  fuellenberechnung
ISOV: Abflusz =         11388.515
ISOV: Niederschlag =    11388.515

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
ISOV: Retentionskonstanten:6000.0       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =   96602.20
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH = 2880
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1047

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4562

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    2.69

 gesamtmenge an niederschlag (mm):       96.0

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:      7


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  0.900
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  3.500


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4562
 anzahl hydrotope:       7


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      96.0 mm
 interz.verd.:                       7.3 mm
 bestandsniederschlag:              86.7 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      15.5 mm
 aktuelle verdunstung:              11.4 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              86.7 mm
 overlandflow:                      57.9 mm
 [infiltration:                     28.9 mm]
 verdunstung (bodensp.):             4.1 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -24.8 mm
 fehler:                             0.0 mm


 0.00000000E+00  -> zufluss grundwasserleiter in  4562
TG:    4562 -> TG:    4565
Prozent:0.10


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:            0.0 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:           2.2 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -2.2 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.081 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.081 qkm



 ISO: Normierungsfaktor   = 1.0001
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =          4661.277
niederschlag =     4661.271
flaeche zft  =        1.000
flaeche eing.=        0.081

GEBIET: Abflusswelle Interflow:

 ISO: Normierungsfaktor   = 1.0000
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.081

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV: Retentionskonstanten:   0.3       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =       1.00
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH =   68
ISOV:  fuellenberechnung
ISOV: Abflusz =             6.684
ISOV: Niederschlag =        6.684

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
ISOV: Retentionskonstanten:6000.0       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =   96602.20
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH = 2880
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1048

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4565

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    2.69

 gesamtmenge an niederschlag (mm):       96.0

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     14


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  8.000


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4565
 anzahl hydrotope:      14


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      96.0 mm
 interz.verd.:                       9.5 mm
 bestandsniederschlag:              82.9 mm
 differenz interz.speicher:         -3.6 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      16.4 mm
 aktuelle verdunstung:              12.3 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              82.9 mm
 overlandflow:                      10.4 mm
 [infiltration:                     72.5 mm]
 verdunstung (bodensp.):             2.8 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -69.7 mm
 fehler:                             0.0 mm


 68.4154816  -> zufluss grundwasserleiter in  4565
TG:    4565 -> TG:    4566
Prozent:1.00


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:          121.8 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:         125.1 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -3.4 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.169 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.169 qkm



 ISO: Normierungsfaktor   = 1.0002
 ISO: Summe normierter uh =   1.0000


 Anzahl der Zeitschritte in iso durch Nachlauf zu hoch geworden.
 Sie wird auf 460 begrenzt !  gebiet :  4565

fuellenberechnung in iso
abflusz =          1742.052
niederschlag =     1745.065
flaeche zft  =        1.000
flaeche eing.=        0.169

GEBIET: Abflusswelle Interflow:

 ISO: Normierungsfaktor   = 1.0000
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.169

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV: Retentionskonstanten:   2.8       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =       1.00
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH =  500
ISOV:  fuellenberechnung
ISOV: Abflusz =           178.468
ISOV: Niederschlag =      178.468

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
ISOV: Retentionskonstanten:6000.0       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =   96602.20
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH = 2880
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1049

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4566

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    2.69

 gesamtmenge an niederschlag (mm):       96.0

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     54


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 = 14.500


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4566
 anzahl hydrotope:      54


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      96.0 mm
 interz.verd.:                       8.1 mm
 bestandsniederschlag:              85.4 mm
 differenz interz.speicher:         -2.5 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      16.3 mm
 aktuelle verdunstung:              11.5 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              85.4 mm
 overlandflow:                       7.7 mm
 [infiltration:                     77.6 mm]
 verdunstung (bodensp.):             3.4 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -74.2 mm
 fehler:                             0.0 mm


 140.124954  -> zufluss grundwasserleiter in  4566
TG:    4566 -> TG:    4567
Prozent:0.30

TG:    4566 -> TG:    4580
Prozent:0.50

TG:    4566 -> TG:    4587
Prozent:0.20


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:           46.0 mm
 abgabe basisabfluss:                 23.1 mm
        grundw. unterh.l.TG:          23.0 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -0.2 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.914 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.914 qkm



 ISO: Normierungsfaktor   = 1.0002
 ISO: Summe normierter uh =   1.0000


 Anzahl der Zeitschritte in iso durch Nachlauf zu hoch geworden.
 Sie wird auf 460 begrenzt !  gebiet :  4566

fuellenberechnung in iso
abflusz =          7068.289
niederschlag =     7080.510
flaeche zft  =        1.000
flaeche eing.=        0.914

GEBIET: Abflusswelle Interflow:

 ISO: Normierungsfaktor   = 1.0000
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.914

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV: Retentionskonstanten:   2.8       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =       1.00
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH =  500
ISOV:  fuellenberechnung
ISOV: Abflusz =          2350.349
ISOV: Niederschlag =     2350.350

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
ISOV: Retentionskonstanten:6000.0       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =   96602.20
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH = 2880
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1050

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4571

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    2.69

 gesamtmenge an niederschlag (mm):       96.0

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     21


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  1.000


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4571
 anzahl hydrotope:      21


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      96.0 mm
 interz.verd.:                       7.4 mm
 bestandsniederschlag:              86.7 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      16.3 mm
 aktuelle verdunstung:              11.4 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              86.7 mm
 overlandflow:                       7.7 mm
 [infiltration:                     79.0 mm]
 verdunstung (bodensp.):             4.0 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -74.9 mm
 fehler:                             0.0 mm


 18.3165398  -> zufluss grundwasserleiter in  4571
TG:    4571 -> TG:    4573
Prozent:0.20

TG:    4571 -> TG:    4580
Prozent:0.80


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:           34.5 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:          34.7 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -0.2 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.160 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.160 qkm



 ISO: Normierungsfaktor   = 1.0001
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =          1225.834
niederschlag =     1225.833
flaeche zft  =        1.000
flaeche eing.=        0.160

GEBIET: Abflusswelle Interflow:

 ISO: Normierungsfaktor   = 1.0000
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.160

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV: Retentionskonstanten:   0.7       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =       1.00
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH =  148
ISOV:  fuellenberechnung
ISOV: Abflusz =          1761.092
ISOV: Niederschlag =     1761.092

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
ISOV: Retentionskonstanten:1455.0       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =    1512.20
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH = 2880
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1051

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4589

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    2.69

 gesamtmenge an niederschlag (mm):       96.0

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     99


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  1.000


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4589
 anzahl hydrotope:      99


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      96.0 mm
 interz.verd.:                       7.3 mm
 bestandsniederschlag:              86.7 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      16.1 mm
 aktuelle verdunstung:              10.8 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              86.7 mm
 overlandflow:                       5.5 mm
 [infiltration:                     81.3 mm]
 verdunstung (bodensp.):             3.4 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -77.8 mm
 fehler:                             0.0 mm


 24.4603634  -> zufluss grundwasserleiter in  4589
TG:    4589 -> TG:    4572
Prozent:0.20

TG:    4589 -> TG:    4593
Prozent:0.80


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:           13.6 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:          16.6 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                -2.5 mm
     pot.entnahme GWS:                -2.5 mm
 speicherinhaltsaenderung:            -0.5 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.541 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.541 qkm



 ISO: Normierungsfaktor   = 1.0002
 ISO: Summe normierter uh =   1.0000


 Anzahl der Zeitschritte in iso durch Nachlauf zu hoch geworden.
 Sie wird auf 460 begrenzt !  gebiet :  4589

fuellenberechnung in iso
abflusz =          2956.310
niederschlag =     2961.417
flaeche zft  =        1.000
flaeche eing.=        0.541

GEBIET: Abflusswelle Interflow:

 ISO: Normierungsfaktor   = 1.0000
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.541

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV: Retentionskonstanten:   1.4       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =       1.00
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH =  264
ISOV:  fuellenberechnung
ISOV: Abflusz =          7643.692
ISOV: Niederschlag =     7643.692

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
ISOV: Retentionskonstanten:6000.0       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =   96602.20
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH = 2880
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1052

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4572

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    2.69

 gesamtmenge an niederschlag (mm):       96.0

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     35


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  1.000


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4572
 anzahl hydrotope:      35


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      96.0 mm
 interz.verd.:                       7.4 mm
 bestandsniederschlag:              86.7 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      16.2 mm
 aktuelle verdunstung:              11.0 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              86.7 mm
 overlandflow:                       6.1 mm
 [infiltration:                     80.6 mm]
 verdunstung (bodensp.):             3.6 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -77.0 mm
 fehler:                             0.0 mm


 6.00380278  -> zufluss grundwasserleiter in  4572
TG:    4572 -> TG:    4574
Prozent:0.50

TG:    4572 -> TG:    4573
Prozent:0.50


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:            6.6 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:           6.8 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -0.2 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.275 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.275 qkm



 ISO: Normierungsfaktor   = 1.0001
 ISO: Summe normierter uh =   1.0000


 Anzahl der Zeitschritte in iso durch Nachlauf zu hoch geworden.
 Sie wird auf 460 begrenzt !  gebiet :  4572

fuellenberechnung in iso
abflusz =          1666.071
niederschlag =     1666.072
flaeche zft  =        1.000
flaeche eing.=        0.275

GEBIET: Abflusswelle Interflow:

 ISO: Normierungsfaktor   = 1.0000
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.275

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV: Retentionskonstanten:   1.6       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =       1.00
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH =  299
ISOV:  fuellenberechnung
ISOV: Abflusz =          2129.089
ISOV: Niederschlag =     2129.090

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
ISOV: Retentionskonstanten:3273.0       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =   16076.66
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH = 2880
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1053

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4573

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    2.69

 gesamtmenge an niederschlag (mm):       96.0

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     21


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  1.000


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4573
 anzahl hydrotope:      21


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      96.0 mm
 interz.verd.:                       7.3 mm
 bestandsniederschlag:              86.7 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      16.2 mm
 aktuelle verdunstung:              12.0 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              86.7 mm
 overlandflow:                      10.2 mm
 [infiltration:                     76.6 mm]
 verdunstung (bodensp.):             4.7 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -71.9 mm
 fehler:                             0.0 mm


 6.77892065  -> zufluss grundwasserleiter in  4573
TG:    4573 -> TG:    4576
Prozent:0.50

TG:    4573 -> TG:    4578
Prozent:0.50


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:           22.4 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:          23.0 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -0.6 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.091 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.091 qkm



 ISO: Normierungsfaktor   = 1.0001
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =           922.146
niederschlag =      922.145
flaeche zft  =        1.000
flaeche eing.=        0.091

GEBIET: Abflusswelle Interflow:

 ISO: Normierungsfaktor   = 1.0000
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.091

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV: Retentionskonstanten:   0.7       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =       1.00
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH =  142
ISOV:  fuellenberechnung
ISOV: Abflusz =          1110.986
ISOV: Niederschlag =     1110.987

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
ISOV: Retentionskonstanten:1382.0       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =    1304.24
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH = 2880
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1054

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4576

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    2.69

 gesamtmenge an niederschlag (mm):       96.0

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     12


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  1.000


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4576
 anzahl hydrotope:      12


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      96.0 mm
 interz.verd.:                       7.3 mm
 bestandsniederschlag:              86.7 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      16.0 mm
 aktuelle verdunstung:              12.0 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              86.7 mm
 overlandflow:                      10.2 mm
 [infiltration:                     76.5 mm]
 verdunstung (bodensp.):             4.7 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -71.8 mm
 fehler:                             0.0 mm


 3.47444773  -> zufluss grundwasserleiter in  4576
TG:    4576 -> TG:    4578
Prozent:0.80

TG:    4576 -> TG:    4579
Prozent:0.20


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:           60.3 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:          60.2 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:             0.1 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.017 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.017 qkm



 ISO: Normierungsfaktor   = 1.0000
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =           176.733
niederschlag =      176.733
flaeche zft  =        1.000
flaeche eing.=        0.017

GEBIET: Abflusswelle Interflow:

 ISO: Normierungsfaktor   = 1.0001
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.017

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV: Retentionskonstanten:   0.3       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =       1.00
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH =   60
ISOV:  fuellenberechnung
ISOV: Abflusz =            73.216
ISOV: Niederschlag =       73.216

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
ISOV: Retentionskonstanten: 545.0       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =      97.39
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH = 2880
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1055

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4578

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    2.69

 gesamtmenge an niederschlag (mm):       96.0

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     15


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  1.000


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4578
 anzahl hydrotope:      15


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      96.0 mm
 interz.verd.:                       7.5 mm
 bestandsniederschlag:              86.4 mm
 differenz interz.speicher:         -2.1 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      16.3 mm
 aktuelle verdunstung:              12.1 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              86.4 mm
 overlandflow:                       9.7 mm
 [infiltration:                     76.7 mm]
 verdunstung (bodensp.):             4.6 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -72.1 mm
 fehler:                             0.0 mm


 6.25004005  -> zufluss grundwasserleiter in  4578
TG:    4578 -> TG:    4579
Prozent:0.80

TG:    4578 -> TG:    4580
Prozent:0.20


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:           85.6 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:          85.9 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -0.3 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.022 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.022 qkm



 ISO: Normierungsfaktor   = 1.0000
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =           212.645
niederschlag =      212.646
flaeche zft  =        1.000
flaeche eing.=        0.022

GEBIET: Abflusswelle Interflow:

 ISO: Normierungsfaktor   = 1.0001
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.022

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV: Retentionskonstanten:   0.3       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =       1.00
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH =   60
ISOV:  fuellenberechnung
ISOV: Abflusz =           138.211
ISOV: Niederschlag =      138.211

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
ISOV: Retentionskonstanten: 545.0       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =      97.39
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH = 2880
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1056

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4580

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    2.69

 gesamtmenge an niederschlag (mm):       96.0

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     31


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 = 10.000


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4580
 anzahl hydrotope:      31


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      96.0 mm
 interz.verd.:                       7.3 mm
 bestandsniederschlag:              86.7 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      16.0 mm
 aktuelle verdunstung:              11.2 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              86.7 mm
 overlandflow:                       4.7 mm
 [infiltration:                     82.0 mm]
 verdunstung (bodensp.):             3.8 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -78.2 mm
 fehler:                             0.0 mm


 51.0867615  -> zufluss grundwasserleiter in  4580
TG:    4580 -> TG:    4579
Prozent:0.10

TG:    4580 -> TG:    4584
Prozent:0.30

TG:    4580 -> TG:    4586
Prozent:0.60


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:          230.4 mm
 abgabe basisabfluss:                 73.3 mm
        grundw. unterh.l.TG:         157.3 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -0.2 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.067 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.067 qkm



 ISO: Normierungsfaktor   = 1.0002
 ISO: Summe normierter uh =   1.0000


 Anzahl der Zeitschritte in iso durch Nachlauf zu hoch geworden.
 Sie wird auf 460 begrenzt !  gebiet :  4580

fuellenberechnung in iso
abflusz =           314.849
niederschlag =      315.392
flaeche zft  =        1.000
flaeche eing.=        0.067

GEBIET: Abflusswelle Interflow:

 ISO: Normierungsfaktor   = 1.0000
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.067

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV: Retentionskonstanten:   0.9       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =       1.00
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH =  181
ISOV:  fuellenberechnung
ISOV: Abflusz =           548.540
ISOV: Niederschlag =      548.540

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
ISOV: Retentionskonstanten:6000.0       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =   96602.20
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH = 2880
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1057

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4584

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    2.69

 gesamtmenge an niederschlag (mm):       96.0

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     21


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  5.000


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4584
 anzahl hydrotope:      21


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      96.0 mm
 interz.verd.:                       7.4 mm
 bestandsniederschlag:              86.7 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      16.4 mm
 aktuelle verdunstung:              10.9 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              86.7 mm
 overlandflow:                       1.4 mm
 [infiltration:                     85.2 mm]
 verdunstung (bodensp.):             3.5 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -81.7 mm
 fehler:                             0.0 mm


 10.4620333  -> zufluss grundwasserleiter in  4584
TG:    4584 -> TG:    4587
Prozent:1.00


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:           54.5 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:          54.7 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -0.2 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.058 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.058 qkm



 ISO: Normierungsfaktor   = 1.0001
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =            82.820
niederschlag =       82.820
flaeche zft  =        1.000
flaeche eing.=        0.058

GEBIET: Abflusswelle Interflow:

 ISO: Normierungsfaktor   = 1.0000
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.058

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV: Retentionskonstanten:   0.9       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =       1.00
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH =  168
ISOV:  fuellenberechnung
ISOV: Abflusz =          1446.872
ISOV: Niederschlag =     1446.872

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
ISOV: Retentionskonstanten:1667.0       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =    2238.97
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH = 2880
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1058

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4587

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    2.69

 gesamtmenge an niederschlag (mm):       96.0

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     15


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  5.000


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4587
 anzahl hydrotope:      15


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      96.0 mm
 interz.verd.:                       7.3 mm
 bestandsniederschlag:              86.8 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      16.0 mm
 aktuelle verdunstung:              10.5 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              86.8 mm
 overlandflow:                       0.0 mm
 [infiltration:                     86.8 mm]
 verdunstung (bodensp.):             3.2 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -83.6 mm
 fehler:                             0.0 mm


 24.5377979  -> zufluss grundwasserleiter in  4587
TG:    4587 -> TG:    4598
Prozent:1.00


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:          404.0 mm
 abgabe basisabfluss:                 44.1 mm
        grundw. unterh.l.TG:         360.2 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -0.4 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.018 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.018 qkm



 ISO: Normierungsfaktor   = 1.0001
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.018

GEBIET: Abflusswelle Interflow:

 ISO: Normierungsfaktor   = 1.0000
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.018

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV: Retentionskonstanten:   0.9       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =       1.00
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH =  168
ISOV:  fuellenberechnung
ISOV: Abflusz =           213.577
ISOV: Niederschlag =      213.577

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
ISOV: Retentionskonstanten:1667.0       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =    2238.97
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH = 2880
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1059

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4574

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    2.69

 gesamtmenge an niederschlag (mm):       96.0

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     26


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  1.000


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4574
 anzahl hydrotope:      26


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      96.0 mm
 interz.verd.:                       7.4 mm
 bestandsniederschlag:              86.5 mm
 differenz interz.speicher:         -2.1 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      16.2 mm
 aktuelle verdunstung:              11.0 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              86.5 mm
 overlandflow:                       2.7 mm
 [infiltration:                     83.8 mm]
 verdunstung (bodensp.):             3.6 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -80.2 mm
 fehler:                             0.0 mm


 3.09172893  -> zufluss grundwasserleiter in  4574
TG:    4574 -> TG:    4575
Prozent:1.00


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:           10.3 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:          10.7 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -0.4 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.090 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.090 qkm



 ISO: Normierungsfaktor   = 1.0001
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =           245.746
niederschlag =      245.746
flaeche zft  =        1.000
flaeche eing.=        0.090

GEBIET: Abflusswelle Interflow:

 ISO: Normierungsfaktor   = 1.0000
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.090

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV: Retentionskonstanten:   1.0       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =       1.00
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH =  190
ISOV:  fuellenberechnung
ISOV: Abflusz =          1174.905
ISOV: Niederschlag =     1174.906

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
ISOV: Retentionskonstanten:1891.0       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =    3227.00
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH = 2880
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1060

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4575

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    2.69

 gesamtmenge an niederschlag (mm):       96.0

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     16


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  1.000


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4575
 anzahl hydrotope:      16


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      96.0 mm
 interz.verd.:                       7.3 mm
 bestandsniederschlag:              86.7 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      16.0 mm
 aktuelle verdunstung:              10.5 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              86.7 mm
 overlandflow:                       0.2 mm
 [infiltration:                     86.5 mm]
 verdunstung (bodensp.):             3.2 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -83.3 mm
 fehler:                             0.0 mm


 3.20433187  -> zufluss grundwasserleiter in  4575
TG:    4575 -> TG:    4585
Prozent:1.00


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:           20.5 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:          20.6 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -0.2 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.047 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.047 qkm



 ISO: Normierungsfaktor   = 1.0000
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =            11.056
niederschlag =       11.056
flaeche zft  =        1.000
flaeche eing.=        0.047

GEBIET: Abflusswelle Interflow:

 ISO: Normierungsfaktor   = 1.0000
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.047

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV: Retentionskonstanten:   0.6       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =       1.00
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH =  124
ISOV:  fuellenberechnung
ISOV: Abflusz =           829.034
ISOV: Niederschlag =      829.034

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
ISOV: Retentionskonstanten:1200.0       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =     870.72
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH = 2880
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1061

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4579

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    2.69

 gesamtmenge an niederschlag (mm):       96.0

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     20


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  1.000


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4579
 anzahl hydrotope:      20


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      96.0 mm
 interz.verd.:                       7.3 mm
 bestandsniederschlag:              86.8 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      15.9 mm
 aktuelle verdunstung:              11.5 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              86.8 mm
 overlandflow:                       8.1 mm
 [infiltration:                     78.7 mm]
 verdunstung (bodensp.):             4.2 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -74.5 mm
 fehler:                             0.0 mm


 9.19991493  -> zufluss grundwasserleiter in  4579
TG:    4579 -> TG:    4585
Prozent:0.50

TG:    4579 -> TG:    4586
Prozent:0.50


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:          213.2 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:         213.9 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -0.6 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.013 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.013 qkm



 ISO: Normierungsfaktor   = 1.0000
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =           104.273
niederschlag =      104.273
flaeche zft  =        1.000
flaeche eing.=        0.013

GEBIET: Abflusswelle Interflow:

 ISO: Normierungsfaktor   = 1.0002
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.013

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV: Retentionskonstanten:   0.2       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =       1.00
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH =   42
ISOV:  fuellenberechnung
ISOV: Abflusz =           246.228
ISOV: Niederschlag =      246.229

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
ISOV: Retentionskonstanten: 364.0       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =      34.03
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH = 2880
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1062

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4585

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    2.69

 gesamtmenge an niederschlag (mm):       96.0

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     24


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  5.000


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4585
 anzahl hydrotope:      24


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      96.0 mm
 interz.verd.:                       7.3 mm
 bestandsniederschlag:              86.7 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      16.1 mm
 aktuelle verdunstung:              10.9 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              86.7 mm
 overlandflow:                       2.1 mm
 [infiltration:                     84.6 mm]
 verdunstung (bodensp.):             3.5 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -81.1 mm
 fehler:                             0.0 mm


 7.84600163  -> zufluss grundwasserleiter in  4585
TG:    4585 -> TG:    4596
Prozent:1.00


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:           40.9 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:          44.1 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -3.2 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.058 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.058 qkm



 ISO: Normierungsfaktor   = 1.0002
 ISO: Summe normierter uh =   1.0000


 Anzahl der Zeitschritte in iso durch Nachlauf zu hoch geworden.
 Sie wird auf 460 begrenzt !  gebiet :  4585

fuellenberechnung in iso
abflusz =           122.126
niederschlag =      122.171
flaeche zft  =        1.000
flaeche eing.=        0.058

GEBIET: Abflusswelle Interflow:

 ISO: Normierungsfaktor   = 1.0000
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.058

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV: Retentionskonstanten:   1.8       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =       1.00
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH =  335
ISOV:  fuellenberechnung
ISOV: Abflusz =          1034.390
ISOV: Niederschlag =     1034.391

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
ISOV: Retentionskonstanten:5000.0       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =   56239.74
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH = 2880
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1063

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4586

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    2.69

 gesamtmenge an niederschlag (mm):       96.0

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     44


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  5.000


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4586
 anzahl hydrotope:      44


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      96.0 mm
 interz.verd.:                       7.3 mm
 bestandsniederschlag:              86.7 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      16.0 mm
 aktuelle verdunstung:              11.2 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              86.7 mm
 overlandflow:                       5.4 mm
 [infiltration:                     81.3 mm]
 verdunstung (bodensp.):             3.9 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -77.4 mm
 fehler:                             0.0 mm


 25.5372581  -> zufluss grundwasserleiter in  4586
TG:    4586 -> TG:    4598
Prozent:0.50

TG:    4586 -> TG:    4596
Prozent:0.50


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:          132.9 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:         133.3 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -0.5 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.058 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.058 qkm



 ISO: Normierungsfaktor   = 1.0001
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =           311.452
niederschlag =      311.452
flaeche zft  =        1.000
flaeche eing.=        0.058

GEBIET: Abflusswelle Interflow:

 ISO: Normierungsfaktor   = 1.0000
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.058

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV: Retentionskonstanten:   0.9       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =       1.00
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH =  168
ISOV:  fuellenberechnung
ISOV: Abflusz =           924.913
ISOV: Niederschlag =      924.913

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
ISOV: Retentionskonstanten:1667.0       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =    2238.97
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH = 2880
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         4585

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.

 Keine angeschlossenen Teilgebiete an Strang      4585
 Auswertung des Stranges:         4587

 Abflussverzoegerung mit Kalinin-Miljukov Parametern

 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 dt [h]:   0.08      tmax [d]:     4.86


 Kennwerte Zuflusswelle
 ----------------------

 Scheitel-Zufluss               iqzmax =   1400   qzmax =       0.089 [m**3/s]
 Scheitel-Zufluss im Gerinne    iqzfmx =   1400  qzfmax =       0.089 [m**3/s]
 Scheitel-Zufluss im Vorland    iqzvmx =      0  qzvmax =       0.000 [m**3/s]

 Fuelle-Zufluss                   fuqz =   0.0024 [hm**3]
 Fuelle-zufluss im Gerinne       fuqzf =   0.0024 [hm**3]
 Fuelle-zufluss im Vorland       fuqzv =   0.0000 [hm**3]


 Kennwerte der Systemfunktionen
 -------------------------------

 Anzahl der Zeitschritte  ituh =     18
 Maximum u                imax =      3     umax = 0.269426
 Summe u                   suu = 0.999998   suuh = 1.000000


 tmax [d]:     4.88


 Kennwerte Ausflusswelle
 -----------------------

 Endordinate Ausfluss           qaend =   0.000
 Scheitel-Ausfluss              iqmax =   1404    qmax =       0.089 [m**3/s]

 Fuelle-Ausfluss                  fuq =   0.0024 [hm**3]
 Fuelle-Ausfluss im Gerinne      fuqa =   0.0024 [hm**3]

 Scheitel-Ausfluss im Gerinne  iqamax =   1404   qamax =       0.089 [m**3/s]


 Gesamtzuflusswelle (ohne Basisabfluss)  sqz =        7.976
 Gesamtabflusswelle    "       "         sq  =        7.976


 Keine angeschlossenen Teilgebiete an Strang      4587
 Auswertung des Stranges:         4621

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Fiktiver Strang! Es erfolgt keine Abflussverzoegerung!
 Keine angeschlossenen Teilgebiete an Strang      4621
 Auswertung des Stranges:         1064

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4507

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    2.69

 gesamtmenge an niederschlag (mm):       96.0

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     69


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  0.500


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4507
 anzahl hydrotope:      69


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      96.0 mm
 interz.verd.:                       7.3 mm
 bestandsniederschlag:              86.7 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      16.1 mm
 aktuelle verdunstung:              11.0 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              86.7 mm
 overlandflow:                       3.4 mm
 [infiltration:                     83.3 mm]
 verdunstung (bodensp.):             3.7 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        2.0 mm
 differenz bodenspeicher:          -77.6 mm
 fehler:                             0.0 mm


 0.00000000E+00  -> zufluss grundwasserleiter in  4507
TG:    4507 -> TG:    4508
Prozent:1.00


 aufteilung perkolation: 

 perkolation bodenspeicher:            2.0 mm

 abgabe grundw.speicher:               2.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  2.0 mm
        grundw. oberh.l.TG:            0.0 mm
 abgabe basisabfluss:                  0.7 mm
        grundw. unterh.l.TG:           2.9 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                -1.2 mm
     pot.entnahme GWS:                -1.2 mm
 speicherinhaltsaenderung:            -0.3 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.513 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.513 qkm



 ISO: Normierungsfaktor   = 1.0002
 ISO: Summe normierter uh =   1.0000


 Anzahl der Zeitschritte in iso durch Nachlauf zu hoch geworden.
 Sie wird auf 460 begrenzt !  gebiet :  4507

fuellenberechnung in iso
abflusz =          1742.064
niederschlag =     1745.077
flaeche zft  =        1.000
flaeche eing.=        0.513

GEBIET: Abflusswelle Interflow:

 ISO: Normierungsfaktor   = 1.0002
 ISO: Summe normierter uh =   1.0000


 Anzahl der Zeitschritte in iso durch Nachlauf zu hoch geworden.
 Sie wird auf 460 begrenzt !  gebiet :  4507

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.513

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV: Retentionskonstanten:   1.4       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =       1.00
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH =  264
ISOV:  fuellenberechnung
ISOV: Abflusz =          7276.918
ISOV: Niederschlag =     7276.920

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
ISOV: Retentionskonstanten:6000.0       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =   96602.20
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH = 2880
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1065

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4508

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    2.69

 gesamtmenge an niederschlag (mm):       96.0

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     56


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  1.000


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4508
 anzahl hydrotope:      56


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      96.0 mm
 interz.verd.:                       7.3 mm
 bestandsniederschlag:              86.7 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      16.0 mm
 aktuelle verdunstung:              10.6 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              86.7 mm
 overlandflow:                       2.9 mm
 [infiltration:                     83.8 mm]
 verdunstung (bodensp.):             3.3 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.9 mm
 differenz bodenspeicher:          -79.7 mm
 fehler:                             0.0 mm


 entnahme gws [qbm/s]:       0.000
 4.91823721  -> zufluss grundwasserleiter in  4508
TG:    4508 -> TG:    4509
Prozent:1.00


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.9 mm

 abgabe grundw.speicher:               0.9 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.9 mm
        grundw. oberh.l.TG:            3.8 mm
 abgabe basisabfluss:                  1.6 mm
        grundw. unterh.l.TG:           3.7 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.2 mm
     pot.entnahme GWS:                 0.2 mm
 speicherinhaltsaenderung:            -0.9 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.390 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.390 qkm



 ISO: Normierungsfaktor   = 1.0002
 ISO: Summe normierter uh =   1.0000


 Anzahl der Zeitschritte in iso durch Nachlauf zu hoch geworden.
 Sie wird auf 460 begrenzt !  gebiet :  4508

fuellenberechnung in iso
abflusz =          1130.466
niederschlag =     1132.421
flaeche zft  =        1.000
flaeche eing.=        0.390

GEBIET: Abflusswelle Interflow:

 ISO: Normierungsfaktor   = 1.0002
 ISO: Summe normierter uh =   1.0000


 Anzahl der Zeitschritte in iso durch Nachlauf zu hoch geworden.
 Sie wird auf 460 begrenzt !  gebiet :  4508

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.390

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV: Retentionskonstanten:   1.4       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =       1.00
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH =  264
ISOV:  fuellenberechnung
ISOV: Abflusz =          6960.084
ISOV: Niederschlag =     6960.089

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
ISOV: Retentionskonstanten:6000.0       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =   96602.20
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH = 2880
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1066

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4509

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    2.69

 gesamtmenge an niederschlag (mm):       96.0

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     83


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  1.500


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4509
 anzahl hydrotope:      83


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      96.0 mm
 interz.verd.:                       7.3 mm
 bestandsniederschlag:              86.7 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      16.0 mm
 aktuelle verdunstung:              10.7 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              86.7 mm
 overlandflow:                       5.1 mm
 [infiltration:                     81.7 mm]
 verdunstung (bodensp.):             3.4 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.2 mm
 differenz bodenspeicher:          -78.1 mm
 fehler:                             0.0 mm


 entnahme gws [qbm/s]:       0.000
 9.01979828  -> zufluss grundwasserleiter in  4509
TG:    4509 -> TG:    4511
Prozent:1.00


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.2 mm

 abgabe grundw.speicher:               0.2 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.2 mm
        grundw. oberh.l.TG:            3.4 mm
 abgabe basisabfluss:                  1.3 mm
        grundw. unterh.l.TG:           3.4 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -1.2 mm
 fehler:                               0.1 mm


 flaechenanteile: 

   grundwasserleiter:                0.801 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.801 qkm



 ISO: Normierungsfaktor   = 1.0002
 ISO: Summe normierter uh =   1.0000


 Anzahl der Zeitschritte in iso durch Nachlauf zu hoch geworden.
 Sie wird auf 460 begrenzt !  gebiet :  4509

fuellenberechnung in iso
abflusz =          4056.017
niederschlag =     4063.023
flaeche zft  =        1.000
flaeche eing.=        0.801

GEBIET: Abflusswelle Interflow:

 ISO: Normierungsfaktor   = 1.0002
 ISO: Summe normierter uh =   1.0000


 Anzahl der Zeitschritte in iso durch Nachlauf zu hoch geworden.
 Sie wird auf 460 begrenzt !  gebiet :  4509

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.801

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV: Retentionskonstanten:   1.4       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =       1.00
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH =  264
ISOV:  fuellenberechnung
ISOV: Abflusz =         11862.232
ISOV: Niederschlag =    11862.224

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
ISOV: Retentionskonstanten:6000.0       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =   96602.20
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH = 2880
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         4507

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.

 Keine angeschlossenen Teilgebiete an Strang      4507
 Auswertung des Stranges:         4508

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Abflussverzoegerung mit Kalinin-Miljukov Parametern

 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 dt [h]:   0.08      tmax [d]:     4.89


 Kennwerte Zuflusswelle
 ----------------------

 Scheitel-Zufluss               iqzmax =   1409   qzmax =       0.290 [m**3/s]
 Scheitel-Zufluss im Gerinne    iqzfmx =   1409  qzfmax =       0.290 [m**3/s]
 Scheitel-Zufluss im Vorland    iqzvmx =      0  qzvmax =       0.000 [m**3/s]

 Fuelle-Zufluss                   fuqz =   0.0094 [hm**3]
 Fuelle-zufluss im Gerinne       fuqzf =   0.0094 [hm**3]
 Fuelle-zufluss im Vorland       fuqzv =   0.0000 [hm**3]


 Kennwerte der Systemfunktionen
 -------------------------------

 Anzahl der Zeitschritte  ituh =     32
 Maximum u                imax =      1     umax = 0.248968
 Summe u                   suu = 1.001107   suuh = 1.000000


 tmax [d]:     4.90


 Kennwerte Ausflusswelle
 -----------------------

 Endordinate Ausfluss           qaend =   0.000
 Scheitel-Ausfluss              iqmax =   1410    qmax =       0.290 [m**3/s]

 Fuelle-Ausfluss                  fuq =   0.0094 [hm**3]
 Fuelle-Ausfluss im Gerinne      fuqa =   0.0094 [hm**3]

 Scheitel-Ausfluss im Gerinne  iqamax =   1410   qamax =       0.290 [m**3/s]


 Gesamtzuflusswelle (ohne Basisabfluss)  sqz =       31.289
 Gesamtabflusswelle    "       "         sq  =       31.289


 Keine angeschlossenen Teilgebiete an Strang      4508
 Auswertung des Stranges:         4509

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Abflussverzoegerung mit Kalinin-Miljukov Parametern

 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 dt [h]:   0.08      tmax [d]:     4.89


 Kennwerte Zuflusswelle
 ----------------------

 Scheitel-Zufluss               iqzmax =   1409   qzmax =       0.561 [m**3/s]
 Scheitel-Zufluss im Gerinne    iqzfmx =   1409  qzfmax =       0.561 [m**3/s]
 Scheitel-Zufluss im Vorland    iqzvmx =      0  qzvmax =       0.000 [m**3/s]

 Fuelle-Zufluss                   fuqz =   0.0181 [hm**3]
 Fuelle-zufluss im Gerinne       fuqzf =   0.0181 [hm**3]
 Fuelle-zufluss im Vorland       fuqzv =   0.0000 [hm**3]


 Kennwerte der Systemfunktionen
 -------------------------------

 Anzahl der Zeitschritte  ituh =     18
 Maximum u                imax =      3     umax = 0.269426
 Summe u                   suu = 0.999998   suuh = 1.000000


 tmax [d]:     4.91


 Kennwerte Ausflusswelle
 -----------------------

 Endordinate Ausfluss           qaend =   0.000
 Scheitel-Ausfluss              iqmax =   1413    qmax =       0.560 [m**3/s]

 Fuelle-Ausfluss                  fuq =   0.0181 [hm**3]
 Fuelle-Ausfluss im Gerinne      fuqa =   0.0181 [hm**3]

 Scheitel-Ausfluss im Gerinne  iqamax =   1413   qamax =       0.560 [m**3/s]


 Gesamtzuflusswelle (ohne Basisabfluss)  sqz =       60.353
 Gesamtabflusswelle    "       "         sq  =       60.353


 Keine angeschlossenen Teilgebiete an Strang      4509
 Auswertung des Stranges:         4605

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Fiktiver Strang! Es erfolgt keine Abflussverzoegerung!
 Keine angeschlossenen Teilgebiete an Strang      4605
 Auswertung des Stranges:         4503

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.

 Keine angeschlossenen Teilgebiete an Strang      4503
 Auswertung des Stranges:         4504

 Abflussverzoegerung mit Kalinin-Miljukov Parametern

 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 dt [h]:   0.08      tmax [d]:     4.93


 Kennwerte Zuflusswelle
 ----------------------

 Scheitel-Zufluss               iqzmax =   1420   qzmax =       0.210 [m**3/s]
 Scheitel-Zufluss im Gerinne    iqzfmx =   1420  qzfmax =       0.210 [m**3/s]
 Scheitel-Zufluss im Vorland    iqzvmx =      0  qzvmax =       0.000 [m**3/s]

 Fuelle-Zufluss                   fuqz =   0.0087 [hm**3]
 Fuelle-zufluss im Gerinne       fuqzf =   0.0087 [hm**3]
 Fuelle-zufluss im Vorland       fuqzv =   0.0000 [hm**3]


 Kennwerte der Systemfunktionen
 -------------------------------

 Anzahl der Zeitschritte  ituh =     18
 Maximum u                imax =      3     umax = 0.269426
 Summe u                   suu = 0.999998   suuh = 1.000000


 tmax [d]:     4.94


 Kennwerte Ausflusswelle
 -----------------------

 Endordinate Ausfluss           qaend =   0.000
 Scheitel-Ausfluss              iqmax =   1423    qmax =       0.210 [m**3/s]

 Fuelle-Ausfluss                  fuq =   0.0087 [hm**3]
 Fuelle-Ausfluss im Gerinne      fuqa =   0.0087 [hm**3]

 Scheitel-Ausfluss im Gerinne  iqamax =   1423   qamax =       0.210 [m**3/s]


 Gesamtzuflusswelle (ohne Basisabfluss)  sqz =       29.088
 Gesamtabflusswelle    "       "         sq  =       29.088


 Keine angeschlossenen Teilgebiete an Strang      4504
 Auswertung des Stranges:         4505

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Aufruf der Speicherroutine 


 zufluss-fuelle [hm]        0.030639 speicher 4505
 zusaetzl.zufl im nachl.ast [hm]  0.001374

 speicher   0.032013 abfluss-fuelle [hm]      4505

 speicherinhaltsaenderung [hm]  0.000000
 Keine angeschlossenen Teilgebiete an Strang      4505
 Auswertung des Stranges:         4603

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Fiktiver Strang! Es erfolgt keine Abflussverzoegerung!
 Keine angeschlossenen Teilgebiete an Strang      4603
 Auswertung des Stranges:         1067

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4511

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    2.69

 gesamtmenge an niederschlag (mm):       96.0

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     62


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  2.500


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4511
 anzahl hydrotope:      62


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      96.0 mm
 interz.verd.:                       7.3 mm
 bestandsniederschlag:              86.7 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      16.0 mm
 aktuelle verdunstung:              10.8 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              86.7 mm
 overlandflow:                       4.7 mm
 [infiltration:                     82.1 mm]
 verdunstung (bodensp.):             3.4 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -78.6 mm
 fehler:                             0.0 mm


 10.9381199  -> zufluss grundwasserleiter in  4511
TG:    4511 -> TG:    4567
Prozent:1.00


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:            9.6 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:          15.0 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -5.4 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.341 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.341 qkm



 ISO: Normierungsfaktor   = 1.0002
 ISO: Summe normierter uh =   1.0000


 Anzahl der Zeitschritte in iso durch Nachlauf zu hoch geworden.
 Sie wird auf 460 begrenzt !  gebiet :  4511

fuellenberechnung in iso
abflusz =          1595.253
niederschlag =     1598.010
flaeche zft  =        1.000
flaeche eing.=        0.341

GEBIET: Abflusswelle Interflow:

 ISO: Normierungsfaktor   = 1.0000
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.341

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV: Retentionskonstanten:   1.4       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =       1.00
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH =  264
ISOV:  fuellenberechnung
ISOV: Abflusz =          6001.826
ISOV: Niederschlag =     6001.831

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
ISOV: Retentionskonstanten:6000.0       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =   96602.20
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH = 2880
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1068

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4567

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    2.69

 gesamtmenge an niederschlag (mm):       96.0

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     67


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  6.000


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4567
 anzahl hydrotope:      67


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      96.0 mm
 interz.verd.:                       8.0 mm
 bestandsniederschlag:              85.5 mm
 differenz interz.speicher:         -2.5 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      16.3 mm
 aktuelle verdunstung:              11.3 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              85.5 mm
 overlandflow:                       6.5 mm
 [infiltration:                     79.0 mm]
 verdunstung (bodensp.):             3.3 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -75.7 mm
 fehler:                             0.0 mm


 43.6215401  -> zufluss grundwasserleiter in  4567
TG:    4567 -> TG:    4588
Prozent:1.00


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:           50.7 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:          53.3 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -2.6 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.258 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.258 qkm



 ISO: Normierungsfaktor   = 1.0002
 ISO: Summe normierter uh =   1.0000


 Anzahl der Zeitschritte in iso durch Nachlauf zu hoch geworden.
 Sie wird auf 460 begrenzt !  gebiet :  4567

fuellenberechnung in iso
abflusz =          1670.066
niederschlag =     1672.951
flaeche zft  =        1.000
flaeche eing.=        0.258

GEBIET: Abflusswelle Interflow:

 ISO: Normierungsfaktor   = 1.0000
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.258

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV: Retentionskonstanten:   1.4       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =       1.00
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH =  264
ISOV:  fuellenberechnung
ISOV: Abflusz =          2969.875
ISOV: Niederschlag =     2969.877

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
ISOV: Retentionskonstanten:6000.0       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =   96602.20
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH = 2880
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1069

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4588

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    2.69

 gesamtmenge an niederschlag (mm):       96.0

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     26


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  6.000


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4588
 anzahl hydrotope:      26


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      96.0 mm
 interz.verd.:                       7.3 mm
 bestandsniederschlag:              86.7 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      16.1 mm
 aktuelle verdunstung:              10.6 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              86.7 mm
 overlandflow:                       0.3 mm
 [infiltration:                     86.5 mm]
 verdunstung (bodensp.):             3.2 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -83.2 mm
 fehler:                             0.0 mm


 entnahme gws [qbm/s]:       0.000
 45.8547363  -> zufluss grundwasserleiter in  4588
TG:    4588 -> TG:    4598
Prozent:1.00


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:          119.4 mm
 abgabe basisabfluss:                 19.4 mm
        grundw. unterh.l.TG:         100.4 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.2 mm
     pot.entnahme GWS:                 0.2 mm
 speicherinhaltsaenderung:            -0.7 mm
 fehler:                               0.1 mm


 flaechenanteile: 

   grundwasserleiter:                0.115 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.115 qkm



 ISO: Normierungsfaktor   = 1.0002
 ISO: Summe normierter uh =   1.0000


 Anzahl der Zeitschritte in iso durch Nachlauf zu hoch geworden.
 Sie wird auf 460 begrenzt !  gebiet :  4588

fuellenberechnung in iso
abflusz =            29.536
niederschlag =       29.587
flaeche zft  =        1.000
flaeche eing.=        0.115

GEBIET: Abflusswelle Interflow:

 ISO: Normierungsfaktor   = 1.0000
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.115

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV: Retentionskonstanten:   2.8       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =       1.00
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH =  500
ISOV:  fuellenberechnung
ISOV: Abflusz =          1486.204
ISOV: Niederschlag =     1486.207

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
ISOV: Retentionskonstanten:6000.0       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =   96602.20
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH = 2880
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         4580

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.

 Keine angeschlossenen Teilgebiete an Strang      4580
 Auswertung des Stranges:         4581

 Abflussverzoegerung mit Kalinin-Miljukov Parametern
 Keine angeschlossenen Teilgebiete an Strang      4581
 Auswertung des Stranges:         4626

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Fiktiver Strang! Es erfolgt keine Abflussverzoegerung!
 Keine angeschlossenen Teilgebiete an Strang      4626
 Auswertung des Stranges:         4571

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.

 Keine angeschlossenen Teilgebiete an Strang      4571
 Auswertung des Stranges:         4570

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.

 Keine angeschlossenen Teilgebiete an Strang      4570
 Auswertung des Stranges:         4572

 Abflussverzoegerung mit Kalinin-Miljukov Parametern
 Keine angeschlossenen Teilgebiete an Strang      4572
 Auswertung des Stranges:         4576

 Abflussverzoegerung mit Kalinin-Miljukov Parametern

 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 dt [h]:   0.08      tmax [d]:     4.85


 Kennwerte Zuflusswelle
 ----------------------

 Scheitel-Zufluss               iqzmax =   1396   qzmax =       0.259 [m**3/s]
 Scheitel-Zufluss im Gerinne    iqzfmx =   1396  qzfmax =       0.259 [m**3/s]
 Scheitel-Zufluss im Vorland    iqzvmx =      0  qzvmax =       0.000 [m**3/s]

 Fuelle-Zufluss                   fuqz =   0.0068 [hm**3]
 Fuelle-zufluss im Gerinne       fuqzf =   0.0068 [hm**3]
 Fuelle-zufluss im Vorland       fuqzv =   0.0000 [hm**3]


 Kennwerte der Systemfunktionen
 -------------------------------

 Anzahl der Zeitschritte  ituh =     18
 Maximum u                imax =      3     umax = 0.269426
 Summe u                   suu = 0.999998   suuh = 1.000000


 tmax [d]:     4.86


 Kennwerte Ausflusswelle
 -----------------------

 Endordinate Ausfluss           qaend =   0.000
 Scheitel-Ausfluss              iqmax =   1400    qmax =       0.258 [m**3/s]

 Fuelle-Ausfluss                  fuq =   0.0068 [hm**3]
 Fuelle-Ausfluss im Gerinne      fuqa =   0.0068 [hm**3]

 Scheitel-Ausfluss im Gerinne  iqamax =   1400   qamax =       0.258 [m**3/s]


 Gesamtzuflusswelle (ohne Basisabfluss)  sqz =       22.607
 Gesamtabflusswelle    "       "         sq  =       22.607


 Keine angeschlossenen Teilgebiete an Strang      4576
 Auswertung des Stranges:         4577

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Aufruf der Speicherroutine 


 zufluss-fuelle [hm]        0.011179 speicher 4577
 zusaetzl.zufl im nachl.ast [hm]  0.000149

 speicher   0.011327 abfluss-fuelle [hm]      4577

 speicherinhaltsaenderung [hm]  0.000006
 Keine angeschlossenen Teilgebiete an Strang      4577
 Auswertung des Stranges:         4578

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Abflussverzoegerung mit Kalinin-Miljukov Parametern

 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 dt [h]:   0.08      tmax [d]:     4.88


 Kennwerte Zuflusswelle
 ----------------------

 Scheitel-Zufluss               iqzmax =   1404   qzmax =       0.470 [m**3/s]
 Scheitel-Zufluss im Gerinne    iqzfmx =   1404  qzfmax =       0.470 [m**3/s]
 Scheitel-Zufluss im Vorland    iqzvmx =      0  qzvmax =       0.000 [m**3/s]

 Fuelle-Zufluss                   fuqz =   0.0113 [hm**3]
 Fuelle-zufluss im Gerinne       fuqzf =   0.0113 [hm**3]
 Fuelle-zufluss im Vorland       fuqzv =   0.0000 [hm**3]


 Kennwerte der Systemfunktionen
 -------------------------------

 Anzahl der Zeitschritte  ituh =     18
 Maximum u                imax =      3     umax = 0.269426
 Summe u                   suu = 0.999998   suuh = 1.000000


 tmax [d]:     4.89


 Kennwerte Ausflusswelle
 -----------------------

 Endordinate Ausfluss           qaend =   0.000
 Scheitel-Ausfluss              iqmax =   1408    qmax =       0.468 [m**3/s]

 Fuelle-Ausfluss                  fuq =   0.0113 [hm**3]
 Fuelle-Ausfluss im Gerinne      fuqa =   0.0113 [hm**3]

 Scheitel-Ausfluss im Gerinne  iqamax =   1408   qamax =       0.468 [m**3/s]


 Gesamtzuflusswelle (ohne Basisabfluss)  sqz =       37.761
 Gesamtabflusswelle    "       "         sq  =       37.761


 Keine angeschlossenen Teilgebiete an Strang      4578
 Auswertung des Stranges:         4579

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Fiktiver Strang! Es erfolgt keine Abflussverzoegerung!
 Keine angeschlossenen Teilgebiete an Strang      4579
 Auswertung des Stranges:         4620

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.

 Keine angeschlossenen Teilgebiete an Strang      4620
 Auswertung des Stranges:         4582

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Abflussverzoegerung mit Kalinin-Miljukov Parametern

 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 dt [h]:   0.08      tmax [d]:     4.89


 Kennwerte Zuflusswelle
 ----------------------

 Scheitel-Zufluss               iqzmax =   1407   qzmax =       0.484 [m**3/s]
 Scheitel-Zufluss im Gerinne    iqzfmx =   1407  qzfmax =       0.484 [m**3/s]
 Scheitel-Zufluss im Vorland    iqzvmx =      0  qzvmax =       0.000 [m**3/s]

 Fuelle-Zufluss                   fuqz =   0.0120 [hm**3]
 Fuelle-zufluss im Gerinne       fuqzf =   0.0120 [hm**3]
 Fuelle-zufluss im Vorland       fuqzv =   0.0000 [hm**3]


 Kennwerte der Systemfunktionen
 -------------------------------

 Anzahl der Zeitschritte  ituh =     18
 Maximum u                imax =      3     umax = 0.269426
 Summe u                   suu = 0.999998   suuh = 1.000000


 tmax [d]:     4.90


 Kennwerte Ausflusswelle
 -----------------------

 Endordinate Ausfluss           qaend =   0.000
 Scheitel-Ausfluss              iqmax =   1410    qmax =       0.482 [m**3/s]

 Fuelle-Ausfluss                  fuq =   0.0120 [hm**3]
 Fuelle-Ausfluss im Gerinne      fuqa =   0.0120 [hm**3]

 Scheitel-Ausfluss im Gerinne  iqamax =   1410   qamax =       0.482 [m**3/s]


 Gesamtzuflusswelle (ohne Basisabfluss)  sqz =       40.102
 Gesamtabflusswelle    "       "         sq  =       40.102


 Keine angeschlossenen Teilgebiete an Strang      4582
 Auswertung des Stranges:         4583

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Abflussverzoegerung mit Kalinin-Miljukov Parametern

 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 dt [h]:   0.08      tmax [d]:     4.90


 Kennwerte Zuflusswelle
 ----------------------

 Scheitel-Zufluss               iqzmax =   1410   qzmax =       0.518 [m**3/s]
 Scheitel-Zufluss im Gerinne    iqzfmx =   1410  qzfmax =       0.518 [m**3/s]
 Scheitel-Zufluss im Vorland    iqzvmx =      0  qzvmax =       0.000 [m**3/s]

 Fuelle-Zufluss                   fuqz =   0.0178 [hm**3]
 Fuelle-zufluss im Gerinne       fuqzf =   0.0178 [hm**3]
 Fuelle-zufluss im Vorland       fuqzv =   0.0000 [hm**3]


 Kennwerte der Systemfunktionen
 -------------------------------

 Anzahl der Zeitschritte  ituh =     18
 Maximum u                imax =      3     umax = 0.269426
 Summe u                   suu = 0.999998   suuh = 1.000000


 tmax [d]:     4.91


 Kennwerte Ausflusswelle
 -----------------------

 Endordinate Ausfluss           qaend =   0.000
 Scheitel-Ausfluss              iqmax =   1413    qmax =       0.516 [m**3/s]

 Fuelle-Ausfluss                  fuq =   0.0178 [hm**3]
 Fuelle-Ausfluss im Gerinne      fuqa =   0.0178 [hm**3]

 Scheitel-Ausfluss im Gerinne  iqamax =   1413   qamax =       0.516 [m**3/s]


 Gesamtzuflusswelle (ohne Basisabfluss)  sqz =       59.231
 Gesamtabflusswelle    "       "         sq  =       59.231


 Keine angeschlossenen Teilgebiete an Strang      4583
 Auswertung des Stranges:         4627

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Fiktiver Strang! Es erfolgt keine Abflussverzoegerung!
 Keine angeschlossenen Teilgebiete an Strang      4627
 Auswertung des Stranges:         4567

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.

 Keine angeschlossenen Teilgebiete an Strang      4567
 Auswertung des Stranges:         4568

 Aufruf der Speicherroutine 


 zufluss-fuelle [hm]        0.004425 speicher 4568
 zusaetzl.zufl im nachl.ast [hm]  0.000215

 speicher   0.004640 abfluss-fuelle [hm]      4568

 speicherinhaltsaenderung [hm]  0.000000
 Keine angeschlossenen Teilgebiete an Strang      4568
 Auswertung des Stranges:         4617

 Fiktiver Strang! Es erfolgt keine Abflussverzoegerung!
 Keine angeschlossenen Teilgebiete an Strang      4617
 Auswertung des Stranges:         4527

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.

 Keine angeschlossenen Teilgebiete an Strang      4527
 Auswertung des Stranges:         4528

 Aufruf der Speicherroutine 


 zufluss-fuelle [hm]        0.003961 speicher 4528
 zusaetzl.zufl im nachl.ast [hm]  0.000173

 speicher   0.004134 abfluss-fuelle [hm]      4528

 speicherinhaltsaenderung [hm]  0.000002
 Keine angeschlossenen Teilgebiete an Strang      4528
 Auswertung des Stranges:         4623

 Abflussverzoegerung mit Kalinin-Miljukov Parametern

 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 dt [h]:   0.08      tmax [d]:     4.98


 Kennwerte Zuflusswelle
 ----------------------

 Scheitel-Zufluss               iqzmax =   1433   qzmax =       0.081 [m**3/s]
 Scheitel-Zufluss im Gerinne    iqzfmx =   1433  qzfmax =       0.081 [m**3/s]
 Scheitel-Zufluss im Vorland    iqzvmx =      0  qzvmax =       0.000 [m**3/s]

 Fuelle-Zufluss                   fuqz =   0.0041 [hm**3]
 Fuelle-zufluss im Gerinne       fuqzf =   0.0041 [hm**3]
 Fuelle-zufluss im Vorland       fuqzv =   0.0000 [hm**3]


 Kennwerte der Systemfunktionen
 -------------------------------

 Anzahl der Zeitschritte  ituh =     18
 Maximum u                imax =      3     umax = 0.269426
 Summe u                   suu = 0.999998   suuh = 1.000000


 tmax [d]:     4.99


 Kennwerte Ausflusswelle
 -----------------------

 Endordinate Ausfluss           qaend =   0.000
 Scheitel-Ausfluss              iqmax =   1436    qmax =       0.081 [m**3/s]

 Fuelle-Ausfluss                  fuq =   0.0041 [hm**3]
 Fuelle-Ausfluss im Gerinne      fuqa =   0.0041 [hm**3]

 Scheitel-Ausfluss im Gerinne  iqamax =   1436   qamax =       0.081 [m**3/s]


 Gesamtzuflusswelle (ohne Basisabfluss)  sqz =       13.779
 Gesamtabflusswelle    "       "         sq  =       13.779


 Keine angeschlossenen Teilgebiete an Strang      4623
 Auswertung des Stranges:         4624

 Fiktiver Strang! Es erfolgt keine Abflussverzoegerung!
 Keine angeschlossenen Teilgebiete an Strang      4624
 Auswertung des Stranges:         4610

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.

 Keine angeschlossenen Teilgebiete an Strang      4610
 Auswertung des Stranges:         4531

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Aufruf der Speicherroutine 


 zufluss-fuelle [hm]        0.009436 speicher 4531
 zusaetzl.zufl im nachl.ast [hm]  0.000343

 speicher   0.009778 abfluss-fuelle [hm]      4531

 speicherinhaltsaenderung [hm]  0.000002
 Keine angeschlossenen Teilgebiete an Strang      4531
 Auswertung des Stranges:         4625

 Fiktiver Strang! Es erfolgt keine Abflussverzoegerung!
 Keine angeschlossenen Teilgebiete an Strang      4625
 Auswertung des Stranges:         4520

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.

 Keine angeschlossenen Teilgebiete an Strang      4520
 Auswertung des Stranges:         4521

 Aufruf der Speicherroutine 


 zufluss-fuelle [hm]        0.005699 speicher 4521
 zusaetzl.zufl im nachl.ast [hm]  0.000172

 speicher   0.005871 abfluss-fuelle [hm]      4521

 speicherinhaltsaenderung [hm]  0.000000
 Keine angeschlossenen Teilgebiete an Strang      4521
 Auswertung des Stranges:         4608

 Fiktiver Strang! Es erfolgt keine Abflussverzoegerung!
 Keine angeschlossenen Teilgebiete an Strang      4608
 Auswertung des Stranges:         4514

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.

 Keine angeschlossenen Teilgebiete an Strang      4514
 Auswertung des Stranges:         4515

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Abflussverzoegerung mit Kalinin-Miljukov Parametern

 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 dt [h]:   0.08      tmax [d]:     4.89


 Kennwerte Zuflusswelle
 ----------------------

 Scheitel-Zufluss               iqzmax =   1409   qzmax =       0.488 [m**3/s]
 Scheitel-Zufluss im Gerinne    iqzfmx =   1409  qzfmax =       0.488 [m**3/s]
 Scheitel-Zufluss im Vorland    iqzvmx =      0  qzvmax =       0.000 [m**3/s]

 Fuelle-Zufluss                   fuqz =   0.0137 [hm**3]
 Fuelle-zufluss im Gerinne       fuqzf =   0.0137 [hm**3]
 Fuelle-zufluss im Vorland       fuqzv =   0.0000 [hm**3]


 Kennwerte der Systemfunktionen
 -------------------------------

 Anzahl der Zeitschritte  ituh =     18
 Maximum u                imax =      3     umax = 0.269426
 Summe u                   suu = 0.999998   suuh = 1.000000


 tmax [d]:     4.91


 Kennwerte Ausflusswelle
 -----------------------

 Endordinate Ausfluss           qaend =   0.000
 Scheitel-Ausfluss              iqmax =   1413    qmax =       0.486 [m**3/s]

 Fuelle-Ausfluss                  fuq =   0.0137 [hm**3]
 Fuelle-Ausfluss im Gerinne      fuqa =   0.0137 [hm**3]

 Scheitel-Ausfluss im Gerinne  iqamax =   1413   qamax =       0.486 [m**3/s]


 Gesamtzuflusswelle (ohne Basisabfluss)  sqz =       45.728
 Gesamtabflusswelle    "       "         sq  =       45.728


 Keine angeschlossenen Teilgebiete an Strang      4515
 Auswertung des Stranges:         4516

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Aufruf der Speicherroutine 


 zufluss-fuelle [hm]        0.015566 speicher 4516
 zusaetzl.zufl im nachl.ast [hm]  0.000501

 speicher   0.016066 abfluss-fuelle [hm]      4516

 speicherinhaltsaenderung [hm]  0.000000
 Keine angeschlossenen Teilgebiete an Strang      4516
 Auswertung des Stranges:         4517

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Abflussverzoegerung mit Kalinin-Miljukov Parametern

 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 dt [h]:   0.08      tmax [d]:     4.90


 Kennwerte Zuflusswelle
 ----------------------

 Scheitel-Zufluss               iqzmax =   1410   qzmax =       0.560 [m**3/s]
 Scheitel-Zufluss im Gerinne    iqzfmx =   1410  qzfmax =       0.560 [m**3/s]
 Scheitel-Zufluss im Vorland    iqzvmx =      0  qzvmax =       0.000 [m**3/s]

 Fuelle-Zufluss                   fuqz =   0.0161 [hm**3]
 Fuelle-zufluss im Gerinne       fuqzf =   0.0161 [hm**3]
 Fuelle-zufluss im Vorland       fuqzv =   0.0000 [hm**3]


 Kennwerte der Systemfunktionen
 -------------------------------

 Anzahl der Zeitschritte  ituh =     18
 Maximum u                imax =      3     umax = 0.269426
 Summe u                   suu = 0.999998   suuh = 1.000000


 tmax [d]:     4.91


 Kennwerte Ausflusswelle
 -----------------------

 Endordinate Ausfluss           qaend =   0.000
 Scheitel-Ausfluss              iqmax =   1413    qmax =       0.558 [m**3/s]

 Fuelle-Ausfluss                  fuq =   0.0161 [hm**3]
 Fuelle-Ausfluss im Gerinne      fuqa =   0.0161 [hm**3]

 Scheitel-Ausfluss im Gerinne  iqamax =   1413   qamax =       0.558 [m**3/s]


 Gesamtzuflusswelle (ohne Basisabfluss)  sqz =       53.561
 Gesamtabflusswelle    "       "         sq  =       53.561


 Keine angeschlossenen Teilgebiete an Strang      4517
 Auswertung des Stranges:         4518

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Aufruf der Speicherroutine 


 zufluss-fuelle [hm]        0.015450 speicher 4518
 zusaetzl.zufl im nachl.ast [hm]  0.000709

 speicher   0.016154 abfluss-fuelle [hm]      4518

 speicherinhaltsaenderung [hm]  0.000054
 Keine angeschlossenen Teilgebiete an Strang      4518
 Auswertung des Stranges:         4607

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Fiktiver Strang! Es erfolgt keine Abflussverzoegerung!
 Keine angeschlossenen Teilgebiete an Strang      4607
 Auswertung des Stranges:         4512

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.

 Keine angeschlossenen Teilgebiete an Strang      4512
 Auswertung des Stranges:         4513

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Abflussverzoegerung mit Kalinin-Miljukov Parametern

 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 dt [h]:   0.08      tmax [d]:     4.89


 Kennwerte Zuflusswelle
 ----------------------

 Scheitel-Zufluss               iqzmax =   1409   qzmax =       0.233 [m**3/s]
 Scheitel-Zufluss im Gerinne    iqzfmx =   1409  qzfmax =       0.233 [m**3/s]
 Scheitel-Zufluss im Vorland    iqzvmx =      0  qzvmax =       0.000 [m**3/s]

 Fuelle-Zufluss                   fuqz =   0.0063 [hm**3]
 Fuelle-zufluss im Gerinne       fuqzf =   0.0063 [hm**3]
 Fuelle-zufluss im Vorland       fuqzv =   0.0000 [hm**3]


 Kennwerte der Systemfunktionen
 -------------------------------

 Anzahl der Zeitschritte  ituh =     18
 Maximum u                imax =      3     umax = 0.269426
 Summe u                   suu = 0.999998   suuh = 1.000000


 tmax [d]:     4.91


 Kennwerte Ausflusswelle
 -----------------------

 Endordinate Ausfluss           qaend =   0.000
 Scheitel-Ausfluss              iqmax =   1413    qmax =       0.232 [m**3/s]

 Fuelle-Ausfluss                  fuq =   0.0063 [hm**3]
 Fuelle-Ausfluss im Gerinne      fuqa =   0.0063 [hm**3]

 Scheitel-Ausfluss im Gerinne  iqamax =   1413   qamax =       0.232 [m**3/s]


 Gesamtzuflusswelle (ohne Basisabfluss)  sqz =       21.115
 Gesamtabflusswelle    "       "         sq  =       21.115


 Keine angeschlossenen Teilgebiete an Strang      4513
 Auswertung des Stranges:         4519

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Abflussverzoegerung mit Kalinin-Miljukov Parametern

 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 dt [h]:   0.08      tmax [d]:     4.90


 Kennwerte Zuflusswelle
 ----------------------

 Scheitel-Zufluss               iqzmax =   1412   qzmax =       0.337 [m**3/s]
 Scheitel-Zufluss im Gerinne    iqzfmx =   1412  qzfmax =       0.337 [m**3/s]
 Scheitel-Zufluss im Vorland    iqzvmx =      0  qzvmax =       0.000 [m**3/s]

 Fuelle-Zufluss                   fuqz =   0.0092 [hm**3]
 Fuelle-zufluss im Gerinne       fuqzf =   0.0092 [hm**3]
 Fuelle-zufluss im Vorland       fuqzv =   0.0000 [hm**3]


 Kennwerte der Systemfunktionen
 -------------------------------

 Anzahl der Zeitschritte  ituh =     18
 Maximum u                imax =      3     umax = 0.269426
 Summe u                   suu = 0.999998   suuh = 1.000000


 tmax [d]:     4.91


 Kennwerte Ausflusswelle
 -----------------------

 Endordinate Ausfluss           qaend =   0.000
 Scheitel-Ausfluss              iqmax =   1415    qmax =       0.336 [m**3/s]

 Fuelle-Ausfluss                  fuq =   0.0092 [hm**3]
 Fuelle-Ausfluss im Gerinne      fuqa =   0.0092 [hm**3]

 Scheitel-Ausfluss im Gerinne  iqamax =   1415   qamax =       0.336 [m**3/s]


 Gesamtzuflusswelle (ohne Basisabfluss)  sqz =       30.647
 Gesamtabflusswelle    "       "         sq  =       30.647


 Keine angeschlossenen Teilgebiete an Strang      4519
 Auswertung des Stranges:         4522

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Abflussverzoegerung mit Kalinin-Miljukov Parametern

 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 dt [h]:   0.08      tmax [d]:     4.91


 Kennwerte Zuflusswelle
 ----------------------

 Scheitel-Zufluss               iqzmax =   1413   qzmax =       1.112 [m**3/s]
 Scheitel-Zufluss im Gerinne    iqzfmx =   1413  qzfmax =       1.112 [m**3/s]
 Scheitel-Zufluss im Vorland    iqzvmx =      0  qzvmax =       0.000 [m**3/s]

 Fuelle-Zufluss                   fuqz =   0.0313 [hm**3]
 Fuelle-zufluss im Gerinne       fuqzf =   0.0313 [hm**3]
 Fuelle-zufluss im Vorland       fuqzv =   0.0000 [hm**3]


 Kennwerte der Systemfunktionen
 -------------------------------

 Anzahl der Zeitschritte  ituh =   2880
 Maximum u                imax =      0     umax = 0.000000
 Summe u                   suu = 0.000000   suuh = 0.000000


 tmax [d]:     0.00


 Kennwerte Ausflusswelle
 -----------------------


 Endordinate Ausfluss           qaend =   0.001

 Scheitel-Ausfluss              iqmax =   1416    qmax =       1.109 [m**3/s]


 Fuelle-Ausfluss                  fuq =   0.0313 [hm**3]

 Fuelle-Ausfluss im Gerinne      fuqa =   0.0313 [hm**3]

 Fuelle-Ausfluss im vorland      fuqa =   0.0000 [hm**3]


 Scheitel-Ausfluss im Gerinne  iqamax =   1416   qamax =       1.109 [m**3/s]

 Scheitel-Ausfluss im Vorland  iqamax =      0   qamax =       0.000 [m**3/s]


 Gesamtzuflusswelle (ohne Basisabfluss)  sqz =      104.346
 Gesamtabflusswelle    "       "         sq  =      104.347


 Keine angeschlossenen Teilgebiete an Strang      4522
 Auswertung des Stranges:         4524

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Abflussverzoegerung mit Kalinin-Miljukov Parametern

 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 dt [h]:   0.08      tmax [d]:     4.91


 Kennwerte Zuflusswelle
 ----------------------

 Scheitel-Zufluss               iqzmax =   1413   qzmax =       1.532 [m**3/s]
 Scheitel-Zufluss im Gerinne    iqzfmx =   1413  qzfmax =       1.532 [m**3/s]
 Scheitel-Zufluss im Vorland    iqzvmx =      0  qzvmax =       0.000 [m**3/s]

 Fuelle-Zufluss                   fuqz =   0.0454 [hm**3]
 Fuelle-zufluss im Gerinne       fuqzf =   0.0454 [hm**3]
 Fuelle-zufluss im Vorland       fuqzv =   0.0000 [hm**3]


 Kennwerte der Systemfunktionen
 -------------------------------

 Anzahl der Zeitschritte  ituh =   2880
 Maximum u                imax =      0     umax = 0.000000
 Summe u                   suu = 0.000000   suuh = 0.000000


 tmax [d]:     0.00


 Kennwerte Ausflusswelle
 -----------------------


 Endordinate Ausfluss           qaend =   0.001

 Scheitel-Ausfluss              iqmax =   1416    qmax =       1.528 [m**3/s]


 Fuelle-Ausfluss                  fuq =   0.0454 [hm**3]

 Fuelle-Ausfluss im Gerinne      fuqa =   0.0454 [hm**3]

 Fuelle-Ausfluss im vorland      fuqa =   0.0000 [hm**3]


 Scheitel-Ausfluss im Gerinne  iqamax =   1416   qamax =       1.528 [m**3/s]

 Scheitel-Ausfluss im Vorland  iqamax =      0   qamax =       0.000 [m**3/s]


 Gesamtzuflusswelle (ohne Basisabfluss)  sqz =      151.416
 Gesamtabflusswelle    "       "         sq  =      151.417


 Keine angeschlossenen Teilgebiete an Strang      4524
 Auswertung des Stranges:         4525

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Aufruf der Speicherroutine 


 zufluss-fuelle [hm]        0.052278 speicher 4525
 zusaetzl.zufl im nachl.ast [hm]  0.002338

 speicher   0.054614 abfluss-fuelle [hm]      4525

 speicherinhaltsaenderung [hm]  0.000000
 Keine angeschlossenen Teilgebiete an Strang      4525
 Auswertung des Stranges:         4609

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Fiktiver Strang! Es erfolgt keine Abflussverzoegerung!
 Keine angeschlossenen Teilgebiete an Strang      4609
 Auswertung des Stranges:         4500

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.

 Keine angeschlossenen Teilgebiete an Strang      4500
 Auswertung des Stranges:         4501

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Abflussverzoegerung mit Kalinin-Miljukov Parametern

 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 dt [h]:   0.08      tmax [d]:     4.92


 Kennwerte Zuflusswelle
 ----------------------

 Scheitel-Zufluss               iqzmax =   1418   qzmax =       0.623 [m**3/s]
 Scheitel-Zufluss im Gerinne    iqzfmx =   1482  qzfmax =       0.242 [m**3/s]
 Scheitel-Zufluss im Vorland    iqzvmx =   1418  qzvmax =       0.516 [m**3/s]

 Fuelle-Zufluss                   fuqz =   0.0248 [hm**3]
 Fuelle-zufluss im Gerinne       fuqzf =   0.0142 [hm**3]
 Fuelle-zufluss im Vorland       fuqzv =   0.0106 [hm**3]


 Kennwerte der Systemfunktionen
 -------------------------------

 Anzahl der Zeitschritte  ituh =     34
 Maximum u                imax =      3     umax = 0.173632
 Summe u                   suu = 1.000082   suuh = 1.000000


 tmax [d]:     4.93


 Kennwerte Ausflusswelle
 -----------------------


 Endordinate Ausfluss           qaend =   0.000

 Scheitel-Ausfluss              iqmax =   1421    qmax =       0.622 [m**3/s]


 Fuelle-Ausfluss                  fuq =   0.0247 [hm**3]

 Fuelle-Ausfluss im Gerinne      fuqa =   0.0142 [hm**3]

 Fuelle-Ausfluss im vorland      fuqa =   0.0105 [hm**3]


 Scheitel-Ausfluss im Gerinne  iqamax =   1483   qamax =       0.241 [m**3/s]

 Scheitel-Ausfluss im Vorland  iqamax =   1421   qamax =       0.514 [m**3/s]


 Gesamtzuflusswelle (ohne Basisabfluss)  sqz =       82.617
 Gesamtabflusswelle    "       "         sq  =       82.429


 Keine angeschlossenen Teilgebiete an Strang      4501
 Auswertung des Stranges:         4502

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Aufruf der Speicherroutine 


 zufluss-fuelle [hm]        0.041014 speicher 4502
 zusaetzl.zufl im nachl.ast [hm]  0.001599

 speicher   0.042613 abfluss-fuelle [hm]      4502

 speicherinhaltsaenderung [hm]  0.000000
 Keine angeschlossenen Teilgebiete an Strang      4502
 Auswertung des Stranges:         4506

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Abflussverzoegerung mit Kalinin-Miljukov Parametern

 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 dt [h]:   0.08      tmax [d]:     4.93


 Kennwerte Zuflusswelle
 ----------------------

 Scheitel-Zufluss               iqzmax =   1420   qzmax =       1.142 [m**3/s]
 Scheitel-Zufluss im Gerinne    iqzfmx =   1511  qzfmax =       0.242 [m**3/s]
 Scheitel-Zufluss im Vorland    iqzvmx =   1420  qzvmax =       0.945 [m**3/s]

 Fuelle-Zufluss                   fuqz =   0.0426 [hm**3]
 Fuelle-zufluss im Gerinne       fuqzf =   0.0206 [hm**3]
 Fuelle-zufluss im Vorland       fuqzv =   0.0220 [hm**3]


 Kennwerte der Systemfunktionen
 -------------------------------

 Anzahl der Zeitschritte  ituh =     34
 Maximum u                imax =      3     umax = 0.173632
 Summe u                   suu = 1.000082   suuh = 1.000000


 tmax [d]:     4.94


 Kennwerte Ausflusswelle
 -----------------------


 Endordinate Ausfluss           qaend =   0.000

 Scheitel-Ausfluss              iqmax =   1423    qmax =       1.138 [m**3/s]


 Fuelle-Ausfluss                  fuq =   0.0423 [hm**3]

 Fuelle-Ausfluss im Gerinne      fuqa =   0.0206 [hm**3]

 Fuelle-Ausfluss im vorland      fuqa =   0.0217 [hm**3]


 Scheitel-Ausfluss im Gerinne  iqamax =   1513   qamax =       0.241 [m**3/s]

 Scheitel-Ausfluss im Vorland  iqamax =   1424   qamax =       0.941 [m**3/s]


 Gesamtzuflusswelle (ohne Basisabfluss)  sqz =      142.077
 Gesamtabflusswelle    "       "         sq  =      140.961


 Keine angeschlossenen Teilgebiete an Strang      4506
 Auswertung des Stranges:         4510

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Abflussverzoegerung mit Kalinin-Miljukov Parametern

 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 dt [h]:   0.08      tmax [d]:     4.93


 Kennwerte Zuflusswelle
 ----------------------

 Scheitel-Zufluss               iqzmax =   1420   qzmax =       2.009 [m**3/s]
 Scheitel-Zufluss im Gerinne    iqzfmx =   1420  qzfmax =       1.990 [m**3/s]
 Scheitel-Zufluss im Vorland    iqzvmx =   1420  qzvmax =       0.018 [m**3/s]

 Fuelle-Zufluss                   fuqz =   0.0838 [hm**3]
 Fuelle-zufluss im Gerinne       fuqzf =   0.0837 [hm**3]
 Fuelle-zufluss im Vorland       fuqzv =   0.0001 [hm**3]


 Kennwerte der Systemfunktionen
 -------------------------------

 Anzahl der Zeitschritte  ituh =    119
 Maximum u                imax =      1     umax = 0.368774
 Summe u                   suu = 0.870027   suuh = 1.000000


 tmax [d]:     4.94


 Kennwerte Ausflusswelle
 -----------------------


 Endordinate Ausfluss           qaend =   0.000

 Scheitel-Ausfluss              iqmax =   1426    qmax =       1.918 [m**3/s]


 Fuelle-Ausfluss                  fuq =   0.0836 [hm**3]

 Fuelle-Ausfluss im Gerinne      fuqa =   0.0835 [hm**3]

 Fuelle-Ausfluss im vorland      fuqa =   0.0001 [hm**3]


 Scheitel-Ausfluss im Gerinne  iqamax =   1427   qamax =       1.904 [m**3/s]

 Scheitel-Ausfluss im Vorland  iqamax =   1422   qamax =       0.016 [m**3/s]


 Gesamtzuflusswelle (ohne Basisabfluss)  sqz =      279.447
 Gesamtabflusswelle    "       "         sq  =      278.781


 Keine angeschlossenen Teilgebiete an Strang      4510
 Auswertung des Stranges:         4526

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Abflussverzoegerung mit Kalinin-Miljukov Parametern

 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 dt [h]:   0.08      tmax [d]:     4.92


 Kennwerte Zuflusswelle
 ----------------------

 Scheitel-Zufluss               iqzmax =   1417   qzmax =       3.378 [m**3/s]
 Scheitel-Zufluss im Gerinne    iqzfmx =   1417  qzfmax =       3.378 [m**3/s]
 Scheitel-Zufluss im Vorland    iqzvmx =      0  qzvmax =       0.000 [m**3/s]

 Fuelle-Zufluss                   fuqz =   0.1358 [hm**3]
 Fuelle-zufluss im Gerinne       fuqzf =   0.1358 [hm**3]
 Fuelle-zufluss im Vorland       fuqzv =   0.0000 [hm**3]


 Kennwerte der Systemfunktionen
 -------------------------------

 Anzahl der Zeitschritte  ituh =     27
 Maximum u                imax =      1     umax = 0.557957
 Summe u                   suu = 0.784427   suuh = 1.000000


 tmax [d]:     4.92


 Kennwerte Ausflusswelle
 -----------------------

 Endordinate Ausfluss           qaend =   0.000
 Scheitel-Ausfluss              iqmax =   1418    qmax =       3.374 [m**3/s]

 Fuelle-Ausfluss                  fuq =   0.1358 [hm**3]
 Fuelle-Ausfluss im Gerinne      fuqa =   0.1358 [hm**3]

 Scheitel-Ausfluss im Gerinne  iqamax =   1418   qamax =       3.374 [m**3/s]


 Gesamtzuflusswelle (ohne Basisabfluss)  sqz =      452.532
 Gesamtabflusswelle    "       "         sq  =      452.532


 Keine angeschlossenen Teilgebiete an Strang      4526
 Auswertung des Stranges:         4532

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Abflussverzoegerung mit Kalinin-Miljukov Parametern

 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 dt [h]:   0.08      tmax [d]:     4.93


 Kennwerte Zuflusswelle
 ----------------------

 Scheitel-Zufluss               iqzmax =   1421   qzmax =       4.654 [m**3/s]
 Scheitel-Zufluss im Gerinne    iqzfmx =   1421  qzfmax =       2.333 [m**3/s]
 Scheitel-Zufluss im Vorland    iqzvmx =   1421  qzvmax =       2.321 [m**3/s]

 Fuelle-Zufluss                   fuqz =   0.2003 [hm**3]
 Fuelle-zufluss im Gerinne       fuqzf =   0.1491 [hm**3]
 Fuelle-zufluss im Vorland       fuqzv =   0.0512 [hm**3]


 Kennwerte der Systemfunktionen
 -------------------------------

 Anzahl der Zeitschritte  ituh =     58
 Maximum u                imax =      1     umax = 0.450462
 Summe u                   suu = 0.778253   suuh = 0.999630


 tmax [d]:     4.94


 Kennwerte Ausflusswelle
 -----------------------


 Endordinate Ausfluss           qaend =   0.001

 Scheitel-Ausfluss              iqmax =   1424    qmax =       4.600 [m**3/s]


 Fuelle-Ausfluss                  fuq =   0.2004 [hm**3]

 Fuelle-Ausfluss im Gerinne      fuqa =   0.1491 [hm**3]

 Fuelle-Ausfluss im vorland      fuqa =   0.0513 [hm**3]


 Scheitel-Ausfluss im Gerinne  iqamax =   1425   qamax =       2.296 [m**3/s]

 Scheitel-Ausfluss im Vorland  iqamax =   1423   qamax =       2.307 [m**3/s]


 Gesamtzuflusswelle (ohne Basisabfluss)  sqz =      667.616
 Gesamtabflusswelle    "       "         sq  =      667.892


 Keine angeschlossenen Teilgebiete an Strang      4532
 Auswertung des Stranges:         4563

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Abflussverzoegerung mit Kalinin-Miljukov Parametern

 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 dt [h]:   0.08      tmax [d]:     4.94


 Kennwerte Zuflusswelle
 ----------------------

 Scheitel-Zufluss               iqzmax =   1423   qzmax =       5.047 [m**3/s]
 Scheitel-Zufluss im Gerinne    iqzfmx =   1423  qzfmax =       4.359 [m**3/s]
 Scheitel-Zufluss im Vorland    iqzvmx =   1423  qzvmax =       0.687 [m**3/s]

 Fuelle-Zufluss                   fuqz =   0.2240 [hm**3]
 Fuelle-zufluss im Gerinne       fuqzf =   0.2169 [hm**3]
 Fuelle-zufluss im Vorland       fuqzv =   0.0072 [hm**3]


 Kennwerte der Systemfunktionen
 -------------------------------

 Anzahl der Zeitschritte  ituh =     68
 Maximum u                imax =      1     umax = 0.284769
 Summe u                   suu = 0.990478   suuh = 1.000000


 tmax [d]:     4.95


 Kennwerte Ausflusswelle
 -----------------------


 Endordinate Ausfluss           qaend =   0.001

 Scheitel-Ausfluss              iqmax =   1426    qmax =       5.007 [m**3/s]


 Fuelle-Ausfluss                  fuq =   0.2240 [hm**3]

 Fuelle-Ausfluss im Gerinne      fuqa =   0.2169 [hm**3]

 Fuelle-Ausfluss im vorland      fuqa =   0.0072 [hm**3]


 Scheitel-Ausfluss im Gerinne  iqamax =   1424   qamax =       4.358 [m**3/s]

 Scheitel-Ausfluss im Vorland  iqamax =   1427   qamax =       0.654 [m**3/s]


 Gesamtzuflusswelle (ohne Basisabfluss)  sqz =      746.712
 Gesamtabflusswelle    "       "         sq  =      746.711


 Keine angeschlossenen Teilgebiete an Strang      4563
 Auswertung des Stranges:         4541

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.

 Keine angeschlossenen Teilgebiete an Strang      4541
 Auswertung des Stranges:         4534

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.

 Keine angeschlossenen Teilgebiete an Strang      4534
 Auswertung des Stranges:         4535

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Abflussverzoegerung mit Kalinin-Miljukov Parametern

 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 dt [h]:   0.08      tmax [d]:     4.80


 Kennwerte Zuflusswelle
 ----------------------

 Scheitel-Zufluss               iqzmax =   1383   qzmax =       1.406 [m**3/s]
 Scheitel-Zufluss im Gerinne    iqzfmx =   1383  qzfmax =       1.406 [m**3/s]
 Scheitel-Zufluss im Vorland    iqzvmx =      0  qzvmax =       0.000 [m**3/s]

 Fuelle-Zufluss                   fuqz =   0.0199 [hm**3]
 Fuelle-zufluss im Gerinne       fuqzf =   0.0199 [hm**3]
 Fuelle-zufluss im Vorland       fuqzv =   0.0000 [hm**3]


 Kennwerte der Systemfunktionen
 -------------------------------

 Anzahl der Zeitschritte  ituh =   2880
 Maximum u                imax =      1     umax = 0.000000
 Summe u                   suu = 0.000000   suuh = 0.000000


 tmax [d]:     0.00


 Kennwerte Ausflusswelle
 -----------------------


 Endordinate Ausfluss           qaend =   0.002

 Scheitel-Ausfluss              iqmax =   1386    qmax =       1.308 [m**3/s]


 Fuelle-Ausfluss                  fuq =   0.0199 [hm**3]

 Fuelle-Ausfluss im Gerinne      fuqa =   0.0199 [hm**3]

 Fuelle-Ausfluss im vorland      fuqa =   0.0000 [hm**3]


 Scheitel-Ausfluss im Gerinne  iqamax =   1386   qamax =       1.308 [m**3/s]

 Scheitel-Ausfluss im Vorland  iqamax =      0   qamax =       0.000 [m**3/s]


 Gesamtzuflusswelle (ohne Basisabfluss)  sqz =       66.341
 Gesamtabflusswelle    "       "         sq  =       66.342


 Keine angeschlossenen Teilgebiete an Strang      4535
 Auswertung des Stranges:         4536

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Aufruf der Speicherroutine 


 zufluss-fuelle [hm]        0.027235 speicher 4536
 zusaetzl.zufl im nachl.ast [hm]  0.000325

 speicher   0.027543 abfluss-fuelle [hm]      4536

 speicherinhaltsaenderung [hm]  0.000000
 Keine angeschlossenen Teilgebiete an Strang      4536
 Auswertung des Stranges:         4612

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Fiktiver Strang! Es erfolgt keine Abflussverzoegerung!
 Keine angeschlossenen Teilgebiete an Strang      4612
 Auswertung des Stranges:         4537

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.

 Keine angeschlossenen Teilgebiete an Strang      4537
 Auswertung des Stranges:         4538

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Abflussverzoegerung mit Kalinin-Miljukov Parametern

 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 dt [h]:   0.08      tmax [d]:     4.83


 Kennwerte Zuflusswelle
 ----------------------

 Scheitel-Zufluss               iqzmax =   1390   qzmax =       0.138 [m**3/s]
 Scheitel-Zufluss im Gerinne    iqzfmx =   1390  qzfmax =       0.138 [m**3/s]
 Scheitel-Zufluss im Vorland    iqzvmx =      0  qzvmax =       0.000 [m**3/s]

 Fuelle-Zufluss                   fuqz =   0.0024 [hm**3]
 Fuelle-zufluss im Gerinne       fuqzf =   0.0024 [hm**3]
 Fuelle-zufluss im Vorland       fuqzv =   0.0000 [hm**3]


 Kennwerte der Systemfunktionen
 -------------------------------

 Anzahl der Zeitschritte  ituh =     25
 Maximum u                imax =      1     umax = 0.540740
 Summe u                   suu = 0.727210   suuh = 1.000000


 tmax [d]:     4.83


 Kennwerte Ausflusswelle
 -----------------------

 Endordinate Ausfluss           qaend =   0.000
 Scheitel-Ausfluss              iqmax =   1391    qmax =       0.135 [m**3/s]

 Fuelle-Ausfluss                  fuq =   0.0024 [hm**3]
 Fuelle-Ausfluss im Gerinne      fuqa =   0.0024 [hm**3]

 Scheitel-Ausfluss im Gerinne  iqamax =   1391   qamax =       0.135 [m**3/s]


 Gesamtzuflusswelle (ohne Basisabfluss)  sqz =        8.053
 Gesamtabflusswelle    "       "         sq  =        8.053


 Keine angeschlossenen Teilgebiete an Strang      4538
 Auswertung des Stranges:         4539

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Abflussverzoegerung mit Kalinin-Miljukov Parametern

 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 dt [h]:   0.08      tmax [d]:     4.82


 Kennwerte Zuflusswelle
 ----------------------

 Scheitel-Zufluss               iqzmax =   1387   qzmax =       1.754 [m**3/s]
 Scheitel-Zufluss im Gerinne    iqzfmx =   1387  qzfmax =       1.403 [m**3/s]
 Scheitel-Zufluss im Vorland    iqzvmx =   1387  qzvmax =       0.351 [m**3/s]

 Fuelle-Zufluss                   fuqz =   0.0300 [hm**3]
 Fuelle-zufluss im Gerinne       fuqzf =   0.0279 [hm**3]
 Fuelle-zufluss im Vorland       fuqzv =   0.0021 [hm**3]


 Kennwerte der Systemfunktionen
 -------------------------------

 Anzahl der Zeitschritte  ituh =   2880
 Maximum u                imax =      1     umax = 0.000000
 Summe u                   suu = 0.000000   suuh = 0.000000


 tmax [d]:     4.82


 Kennwerte Ausflusswelle
 -----------------------


 Endordinate Ausfluss           qaend =   0.002

 Scheitel-Ausfluss              iqmax =   1388    qmax =       1.689 [m**3/s]


 Fuelle-Ausfluss                  fuq =   0.0300 [hm**3]

 Fuelle-Ausfluss im Gerinne      fuqa =   0.0279 [hm**3]

 Fuelle-Ausfluss im vorland      fuqa =   0.0021 [hm**3]


 Scheitel-Ausfluss im Gerinne  iqamax =   1388   qamax =       1.352 [m**3/s]

 Scheitel-Ausfluss im Vorland  iqamax =   1388   qamax =       0.337 [m**3/s]


 Gesamtzuflusswelle (ohne Basisabfluss)  sqz =       99.882
 Gesamtabflusswelle    "       "         sq  =       99.883


 Keine angeschlossenen Teilgebiete an Strang      4539
 Auswertung des Stranges:         4540

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Aufruf der Speicherroutine 


 zufluss-fuelle [hm]        0.110737 speicher 4540
 zusaetzl.zufl im nachl.ast [hm]  0.000528

 speicher   0.111227 abfluss-fuelle [hm]      4540

 speicherinhaltsaenderung [hm]  0.000000
 Keine angeschlossenen Teilgebiete an Strang      4540
 Auswertung des Stranges:         4613

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Fiktiver Strang! Es erfolgt keine Abflussverzoegerung!
 Keine angeschlossenen Teilgebiete an Strang      4613
 Auswertung des Stranges:         4546

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Abflussverzoegerung mit Kalinin-Miljukov Parametern

 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 dt [h]:   0.08      tmax [d]:     4.82


 Kennwerte Zuflusswelle
 ----------------------

 Scheitel-Zufluss               iqzmax =   1388   qzmax =       7.373 [m**3/s]
 Scheitel-Zufluss im Gerinne    iqzfmx =   1388  qzfmax =       5.898 [m**3/s]
 Scheitel-Zufluss im Vorland    iqzvmx =   1388  qzvmax =       1.475 [m**3/s]

 Fuelle-Zufluss                   fuqz =   0.1304 [hm**3]
 Fuelle-zufluss im Gerinne       fuqzf =   0.1110 [hm**3]
 Fuelle-zufluss im Vorland       fuqzv =   0.0193 [hm**3]


 Kennwerte der Systemfunktionen
 -------------------------------

 Anzahl der Zeitschritte  ituh =   2880
 Maximum u                imax =      1     umax = 0.000000
 Summe u                   suu = 0.000000   suuh = 0.000000


 tmax [d]:     4.82


 Kennwerte Ausflusswelle
 -----------------------


 Endordinate Ausfluss           qaend =   0.002

 Scheitel-Ausfluss              iqmax =   1389    qmax =       7.269 [m**3/s]


 Fuelle-Ausfluss                  fuq =   0.1304 [hm**3]

 Fuelle-Ausfluss im Gerinne      fuqa =   0.1110 [hm**3]

 Fuelle-Ausfluss im vorland      fuqa =   0.0193 [hm**3]


 Scheitel-Ausfluss im Gerinne  iqamax =   1389   qamax =       5.816 [m**3/s]

 Scheitel-Ausfluss im Vorland  iqamax =   1389   qamax =       1.454 [m**3/s]


 Gesamtzuflusswelle (ohne Basisabfluss)  sqz =      434.548
 Gesamtabflusswelle    "       "         sq  =      434.550


 Keine angeschlossenen Teilgebiete an Strang      4546
 Auswertung des Stranges:         4543

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.

 Keine angeschlossenen Teilgebiete an Strang      4543
 Auswertung des Stranges:         4544

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Abflussverzoegerung mit Kalinin-Miljukov Parametern

 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 dt [h]:   0.08      tmax [d]:     4.82


 Kennwerte Zuflusswelle
 ----------------------

 Scheitel-Zufluss               iqzmax =   1389   qzmax =       3.218 [m**3/s]
 Scheitel-Zufluss im Gerinne    iqzfmx =   1389  qzfmax =       2.575 [m**3/s]
 Scheitel-Zufluss im Vorland    iqzvmx =   1389  qzvmax =       0.644 [m**3/s]

 Fuelle-Zufluss                   fuqz =   0.0451 [hm**3]
 Fuelle-zufluss im Gerinne       fuqzf =   0.0398 [hm**3]
 Fuelle-zufluss im Vorland       fuqzv =   0.0052 [hm**3]


 Kennwerte der Systemfunktionen
 -------------------------------

 Anzahl der Zeitschritte  ituh =   2880
 Maximum u                imax =      1     umax = 0.000000
 Summe u                   suu = 0.000000   suuh = 0.000000


 tmax [d]:     4.83


 Kennwerte Ausflusswelle
 -----------------------


 Endordinate Ausfluss           qaend =   0.005

 Scheitel-Ausfluss              iqmax =   1390    qmax =       3.171 [m**3/s]


 Fuelle-Ausfluss                  fuq =   0.0451 [hm**3]

 Fuelle-Ausfluss im Gerinne      fuqa =   0.0398 [hm**3]

 Fuelle-Ausfluss im vorland      fuqa =   0.0052 [hm**3]


 Scheitel-Ausfluss im Gerinne  iqamax =   1390   qamax =       2.537 [m**3/s]

 Scheitel-Ausfluss im Vorland  iqamax =   1390   qamax =       0.634 [m**3/s]


 Gesamtzuflusswelle (ohne Basisabfluss)  sqz =      150.227
 Gesamtabflusswelle    "       "         sq  =      150.231


 Keine angeschlossenen Teilgebiete an Strang      4544
 Auswertung des Stranges:         4545

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Aufruf der Speicherroutine 


 zufluss-fuelle [hm]        0.060417 speicher 4545
 zusaetzl.zufl im nachl.ast [hm]  0.000108

 speicher   0.044375 abfluss-fuelle [hm]      4545
 abfluss-fuelle [hm]  0.0158 ueberlauf 

 speicherinhaltsaenderung [hm]  0.000000
 Keine angeschlossenen Teilgebiete an Strang      4545
 Auswertung des Stranges:         4547

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Abflussverzoegerung mit Kalinin-Miljukov Parametern

 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 dt [h]:   0.08      tmax [d]:     4.84


 Kennwerte Zuflusswelle
 ----------------------

 Scheitel-Zufluss               iqzmax =   1393   qzmax =       1.035 [m**3/s]
 Scheitel-Zufluss im Gerinne    iqzfmx =   1393  qzfmax =       1.035 [m**3/s]
 Scheitel-Zufluss im Vorland    iqzvmx =      0  qzvmax =       0.000 [m**3/s]

 Fuelle-Zufluss                   fuqz =   0.0444 [hm**3]
 Fuelle-zufluss im Gerinne       fuqzf =   0.0444 [hm**3]
 Fuelle-zufluss im Vorland       fuqzv =   0.0000 [hm**3]


 Kennwerte der Systemfunktionen
 -------------------------------

 Anzahl der Zeitschritte  ituh =   2880
 Maximum u                imax =      1     umax = 0.000000
 Summe u                   suu = 0.000000   suuh = 0.000000


 tmax [d]:     0.00


 Kennwerte Ausflusswelle
 -----------------------


 Endordinate Ausfluss           qaend =   0.007

 Scheitel-Ausfluss              iqmax =   1401    qmax =       1.035 [m**3/s]


 Fuelle-Ausfluss                  fuq =   0.0444 [hm**3]

 Fuelle-Ausfluss im Gerinne      fuqa =   0.0444 [hm**3]

 Fuelle-Ausfluss im vorland      fuqa =   0.0000 [hm**3]


 Scheitel-Ausfluss im Gerinne  iqamax =   1401   qamax =       1.035 [m**3/s]

 Scheitel-Ausfluss im Vorland  iqamax =      0   qamax =       0.000 [m**3/s]


 Gesamtzuflusswelle (ohne Basisabfluss)  sqz =      147.931
 Gesamtabflusswelle    "       "         sq  =      147.935


 Keine angeschlossenen Teilgebiete an Strang      4547
 Auswertung des Stranges:         4548

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Abflussverzoegerung mit Kalinin-Miljukov Parametern

 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 dt [h]:   0.08      tmax [d]:     4.82


 Kennwerte Zuflusswelle
 ----------------------

 Scheitel-Zufluss               iqzmax =   1389   qzmax =       9.258 [m**3/s]
 Scheitel-Zufluss im Gerinne    iqzfmx =   1389  qzfmax =       7.406 [m**3/s]
 Scheitel-Zufluss im Vorland    iqzvmx =   1389  qzvmax =       1.852 [m**3/s]

 Fuelle-Zufluss                   fuqz =   0.1957 [hm**3]
 Fuelle-zufluss im Gerinne       fuqzf =   0.1644 [hm**3]
 Fuelle-zufluss im Vorland       fuqzv =   0.0313 [hm**3]


 Kennwerte der Systemfunktionen
 -------------------------------

 Anzahl der Zeitschritte  ituh =   2880
 Maximum u                imax =      1     umax = 0.000000
 Summe u                   suu = 0.000000   suuh = 0.000000


 tmax [d]:     4.82


 Kennwerte Ausflusswelle
 -----------------------


 Endordinate Ausfluss           qaend =   0.000

 Scheitel-Ausfluss              iqmax =   1389    qmax =       9.120 [m**3/s]


 Fuelle-Ausfluss                  fuq =   0.1957 [hm**3]

 Fuelle-Ausfluss im Gerinne      fuqa =   0.1644 [hm**3]

 Fuelle-Ausfluss im vorland      fuqa =   0.0313 [hm**3]


 Scheitel-Ausfluss im Gerinne  iqamax =   1389   qamax =       7.296 [m**3/s]

 Scheitel-Ausfluss im Vorland  iqamax =   1389   qamax =       1.824 [m**3/s]


 Gesamtzuflusswelle (ohne Basisabfluss)  sqz =      652.339
 Gesamtabflusswelle    "       "         sq  =      652.340


 Keine angeschlossenen Teilgebiete an Strang      4548
 Auswertung des Stranges:         4549

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.

 Keine angeschlossenen Teilgebiete an Strang      4549
 Auswertung des Stranges:         4550

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Aufruf der Speicherroutine 


 zufluss-fuelle [hm]        0.038883 speicher 4550
 zusaetzl.zufl im nachl.ast [hm]  0.000096

 speicher   0.024646 abfluss-fuelle [hm]      4550
 abfluss-fuelle [hm]  0.0142 ueberlauf 

 speicherinhaltsaenderung [hm]  0.000001
 Keine angeschlossenen Teilgebiete an Strang      4550
 Auswertung des Stranges:         4551

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Abflussverzoegerung mit Kalinin-Miljukov Parametern

 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 dt [h]:   0.08      tmax [d]:     4.83


 Kennwerte Zuflusswelle
 ----------------------

 Scheitel-Zufluss               iqzmax =   1390   qzmax =       0.276 [m**3/s]
 Scheitel-Zufluss im Gerinne    iqzfmx =   1390  qzfmax =       0.276 [m**3/s]
 Scheitel-Zufluss im Vorland    iqzvmx =      0  qzvmax =       0.000 [m**3/s]

 Fuelle-Zufluss                   fuqz =   0.0246 [hm**3]
 Fuelle-zufluss im Gerinne       fuqzf =   0.0246 [hm**3]
 Fuelle-zufluss im Vorland       fuqzv =   0.0000 [hm**3]


 Kennwerte der Systemfunktionen
 -------------------------------

 Anzahl der Zeitschritte  ituh =     25
 Maximum u                imax =      1     umax = 0.540740
 Summe u                   suu = 0.727210   suuh = 1.000000


 tmax [d]:     4.92


 Kennwerte Ausflusswelle
 -----------------------

 Endordinate Ausfluss           qaend =   0.000
 Scheitel-Ausfluss              iqmax =   1417    qmax =       0.276 [m**3/s]

 Fuelle-Ausfluss                  fuq =   0.0246 [hm**3]
 Fuelle-Ausfluss im Gerinne      fuqa =   0.0246 [hm**3]

 Scheitel-Ausfluss im Gerinne  iqamax =   1417   qamax =       0.276 [m**3/s]


 Gesamtzuflusswelle (ohne Basisabfluss)  sqz =       82.154
 Gesamtabflusswelle    "       "         sq  =       82.154


 Keine angeschlossenen Teilgebiete an Strang      4551
 Auswertung des Stranges:         4553

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Abflussverzoegerung mit Kalinin-Miljukov Parametern

 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 dt [h]:   0.08      tmax [d]:     4.82


 Kennwerte Zuflusswelle
 ----------------------

 Scheitel-Zufluss               iqzmax =   1389   qzmax =      12.779 [m**3/s]
 Scheitel-Zufluss im Gerinne    iqzfmx =   1389  qzfmax =      12.779 [m**3/s]
 Scheitel-Zufluss im Vorland    iqzvmx =      0  qzvmax =       0.000 [m**3/s]

 Fuelle-Zufluss                   fuqz =   0.2748 [hm**3]
 Fuelle-zufluss im Gerinne       fuqzf =   0.2748 [hm**3]
 Fuelle-zufluss im Vorland       fuqzv =   0.0000 [hm**3]


 Kennwerte der Systemfunktionen
 -------------------------------

 Anzahl der Zeitschritte  ituh =   2880
 Maximum u                imax =      1     umax = 0.000000
 Summe u                   suu = 0.000000   suuh = 0.000000


 tmax [d]:     0.00


 Kennwerte Ausflusswelle
 -----------------------


 Endordinate Ausfluss           qaend =   0.008

 Scheitel-Ausfluss              iqmax =   1392    qmax =      12.520 [m**3/s]


 Fuelle-Ausfluss                  fuq =   0.2748 [hm**3]

 Fuelle-Ausfluss im Gerinne      fuqa =   0.2748 [hm**3]

 Fuelle-Ausfluss im vorland      fuqa =   0.0000 [hm**3]


 Scheitel-Ausfluss im Gerinne  iqamax =   1392   qamax =      12.520 [m**3/s]

 Scheitel-Ausfluss im Vorland  iqamax =      0   qamax =       0.000 [m**3/s]


 Gesamtzuflusswelle (ohne Basisabfluss)  sqz =      915.993
 Gesamtabflusswelle    "       "         sq  =      915.995


 Keine angeschlossenen Teilgebiete an Strang      4553
 Auswertung des Stranges:         4559

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Abflussverzoegerung mit Kalinin-Miljukov Parametern

 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 dt [h]:   0.08      tmax [d]:     4.83


 Kennwerte Zuflusswelle
 ----------------------

 Scheitel-Zufluss               iqzmax =   1392   qzmax =      12.815 [m**3/s]
 Scheitel-Zufluss im Gerinne    iqzfmx =   1392  qzfmax =      10.252 [m**3/s]
 Scheitel-Zufluss im Vorland    iqzvmx =   1392  qzvmax =       2.563 [m**3/s]

 Fuelle-Zufluss                   fuqz =   0.2835 [hm**3]
 Fuelle-zufluss im Gerinne       fuqzf =   0.2351 [hm**3]
 Fuelle-zufluss im Vorland       fuqzv =   0.0483 [hm**3]


 Kennwerte der Systemfunktionen
 -------------------------------

 Anzahl der Zeitschritte  ituh =   2880
 Maximum u                imax =      1     umax = 0.000000
 Summe u                   suu = 0.000000   suuh = 0.000000


 tmax [d]:     4.83


 Kennwerte Ausflusswelle
 -----------------------


 Endordinate Ausfluss           qaend =   0.008

 Scheitel-Ausfluss              iqmax =   1392    qmax =      12.677 [m**3/s]


 Fuelle-Ausfluss                  fuq =   0.2835 [hm**3]

 Fuelle-Ausfluss im Gerinne      fuqa =   0.2351 [hm**3]

 Fuelle-Ausfluss im vorland      fuqa =   0.0483 [hm**3]


 Scheitel-Ausfluss im Gerinne  iqamax =   1392   qamax =      10.141 [m**3/s]

 Scheitel-Ausfluss im Vorland  iqamax =   1392   qamax =       2.535 [m**3/s]


 Gesamtzuflusswelle (ohne Basisabfluss)  sqz =      944.876
 Gesamtabflusswelle    "       "         sq  =      944.877


 Keine angeschlossenen Teilgebiete an Strang      4559
 Auswertung des Stranges:         4554

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.

 Keine angeschlossenen Teilgebiete an Strang      4554
 Auswertung des Stranges:         4555

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Aufruf der Speicherroutine 


 zufluss-fuelle [hm]        0.024264 speicher 4555
 zusaetzl.zufl im nachl.ast [hm]  0.000004

 speicher   0.023604 abfluss-fuelle [hm]      4555
 abfluss-fuelle [hm]  0.0006 ueberlauf 

 speicherinhaltsaenderung [hm]  0.000053
 Keine angeschlossenen Teilgebiete an Strang      4555
 Auswertung des Stranges:         4556

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Abflussverzoegerung mit Kalinin-Miljukov Parametern

 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 dt [h]:   0.08      tmax [d]:     4.85


 Kennwerte Zuflusswelle
 ----------------------

 Scheitel-Zufluss               iqzmax =   1397   qzmax =       0.733 [m**3/s]
 Scheitel-Zufluss im Gerinne    iqzfmx =   1437  qzfmax =       0.609 [m**3/s]
 Scheitel-Zufluss im Vorland    iqzvmx =   1397  qzvmax =       0.147 [m**3/s]

 Fuelle-Zufluss                   fuqz =   0.0236 [hm**3]
 Fuelle-zufluss im Gerinne       fuqzf =   0.0220 [hm**3]
 Fuelle-zufluss im Vorland       fuqzv =   0.0016 [hm**3]


 Kennwerte der Systemfunktionen
 -------------------------------

 Anzahl der Zeitschritte  ituh =   2880
 Maximum u                imax =      1     umax = 0.000000
 Summe u                   suu = 0.000000   suuh = 0.000000


 tmax [d]:     4.88


 Kennwerte Ausflusswelle
 -----------------------


 Endordinate Ausfluss           qaend =   0.003

 Scheitel-Ausfluss              iqmax =   1404    qmax =       0.733 [m**3/s]


 Fuelle-Ausfluss                  fuq =   0.0236 [hm**3]

 Fuelle-Ausfluss im Gerinne      fuqa =   0.0220 [hm**3]

 Fuelle-Ausfluss im vorland      fuqa =   0.0016 [hm**3]


 Scheitel-Ausfluss im Gerinne  iqamax =   1437   qamax =       0.608 [m**3/s]

 Scheitel-Ausfluss im Vorland  iqamax =   1405   qamax =       0.147 [m**3/s]


 Gesamtzuflusswelle (ohne Basisabfluss)  sqz =       78.682
 Gesamtabflusswelle    "       "         sq  =       78.682


 Keine angeschlossenen Teilgebiete an Strang      4556
 Auswertung des Stranges:         4557

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Aufruf der Speicherroutine 


 zufluss-fuelle [hm]        0.064216 speicher 4557
 zusaetzl.zufl im nachl.ast [hm]  0.000091

 speicher   0.060816 abfluss-fuelle [hm]      4557
 abfluss-fuelle [hm]  0.0034 ueberlauf 

 speicherinhaltsaenderung [hm]  0.000006
 Keine angeschlossenen Teilgebiete an Strang      4557
 Auswertung des Stranges:         4558

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Abflussverzoegerung mit Kalinin-Miljukov Parametern

 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 dt [h]:   0.08      tmax [d]:     4.84


 Kennwerte Zuflusswelle
 ----------------------

 Scheitel-Zufluss               iqzmax =   1395   qzmax =       1.730 [m**3/s]
 Scheitel-Zufluss im Gerinne    iqzfmx =   1395  qzfmax =       1.384 [m**3/s]
 Scheitel-Zufluss im Vorland    iqzvmx =   1395  qzvmax =       0.346 [m**3/s]

 Fuelle-Zufluss                   fuqz =   0.0608 [hm**3]
 Fuelle-zufluss im Gerinne       fuqzf =   0.0529 [hm**3]
 Fuelle-zufluss im Vorland       fuqzv =   0.0079 [hm**3]


 Kennwerte der Systemfunktionen
 -------------------------------

 Anzahl der Zeitschritte  ituh =   2880
 Maximum u                imax =      1     umax = 0.000000
 Summe u                   suu = 0.000000   suuh = 0.000000


 tmax [d]:     4.91


 Kennwerte Ausflusswelle
 -----------------------


 Endordinate Ausfluss           qaend =   0.001

 Scheitel-Ausfluss              iqmax =   1413    qmax =       1.730 [m**3/s]


 Fuelle-Ausfluss                  fuq =   0.0608 [hm**3]

 Fuelle-Ausfluss im Gerinne      fuqa =   0.0529 [hm**3]

 Fuelle-Ausfluss im vorland      fuqa =   0.0079 [hm**3]


 Scheitel-Ausfluss im Gerinne  iqamax =   1413   qamax =       1.384 [m**3/s]

 Scheitel-Ausfluss im Vorland  iqamax =   1413   qamax =       0.346 [m**3/s]


 Gesamtzuflusswelle (ohne Basisabfluss)  sqz =      202.735
 Gesamtabflusswelle    "       "         sq  =      202.735


 Keine angeschlossenen Teilgebiete an Strang      4558
 Auswertung des Stranges:         4561

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Aufruf der Speicherroutine 


 zufluss-fuelle [hm]        0.400147 speicher 4561
 zusaetzl.zufl im nachl.ast [hm]  0.003349

 speicher   0.284776 abfluss-fuelle [hm]      4561
 abfluss-fuelle [hm]  0.1177 ueberlauf 

 speicherinhaltsaenderung [hm]  0.000002
 Keine angeschlossenen Teilgebiete an Strang      4561
 Auswertung des Stranges:         4562

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Abflussverzoegerung mit Kalinin-Miljukov Parametern

 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 dt [h]:   0.08      tmax [d]:     4.82


 Kennwerte Zuflusswelle
 ----------------------

 Scheitel-Zufluss               iqzmax =   1388   qzmax =       4.052 [m**3/s]
 Scheitel-Zufluss im Gerinne    iqzfmx =   1388  qzfmax =       3.242 [m**3/s]
 Scheitel-Zufluss im Vorland    iqzvmx =   1473  qzvmax =       0.810 [m**3/s]

 Fuelle-Zufluss                   fuqz =   0.2848 [hm**3]
 Fuelle-zufluss im Gerinne       fuqzf =   0.2377 [hm**3]
 Fuelle-zufluss im Vorland       fuqzv =   0.0471 [hm**3]


 Kennwerte der Systemfunktionen
 -------------------------------

 Anzahl der Zeitschritte  ituh =    109
 Maximum u                imax =     16     umax = 0.040608
 Summe u                   suu = 0.999995   suuh = 1.000000


 tmax [d]:     5.13


 Kennwerte Ausflusswelle
 -----------------------


 Endordinate Ausfluss           qaend =   0.001

 Scheitel-Ausfluss              iqmax =   1473    qmax =       4.052 [m**3/s]


 Fuelle-Ausfluss                  fuq =   0.2848 [hm**3]

 Fuelle-Ausfluss im Gerinne      fuqa =   0.2377 [hm**3]

 Fuelle-Ausfluss im vorland      fuqa =   0.0471 [hm**3]


 Scheitel-Ausfluss im Gerinne  iqamax =   1411   qamax =       3.242 [m**3/s]

 Scheitel-Ausfluss im Vorland  iqamax =   1477   qamax =       0.810 [m**3/s]


 Gesamtzuflusswelle (ohne Basisabfluss)  sqz =      949.275
 Gesamtabflusswelle    "       "         sq  =      949.277


 Keine angeschlossenen Teilgebiete an Strang      4562
 Auswertung des Stranges:         4565

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Abflussverzoegerung mit Kalinin-Miljukov Parametern

 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 dt [h]:   0.08      tmax [d]:     4.95


 Kennwerte Zuflusswelle
 ----------------------

 Scheitel-Zufluss               iqzmax =   1425   qzmax =       9.278 [m**3/s]
 Scheitel-Zufluss im Gerinne    iqzfmx =   1425  qzfmax =       4.786 [m**3/s]
 Scheitel-Zufluss im Vorland    iqzvmx =   1425  qzvmax =       4.492 [m**3/s]

 Fuelle-Zufluss                   fuqz =   0.5242 [hm**3]
 Fuelle-zufluss im Gerinne       fuqzf =   0.3170 [hm**3]
 Fuelle-zufluss im Vorland       fuqzv =   0.2072 [hm**3]


 Kennwerte der Systemfunktionen
 -------------------------------

 Anzahl der Zeitschritte  ituh =     95
 Maximum u                imax =     24     umax = 0.042923
 Summe u                   suu = 0.999996   suuh = 1.000000


 tmax [d]:     5.05


 Kennwerte Ausflusswelle
 -----------------------


 Endordinate Ausfluss           qaend =   0.000

 Scheitel-Ausfluss              iqmax =   1443    qmax =       8.901 [m**3/s]


 Fuelle-Ausfluss                  fuq =   0.5244 [hm**3]

 Fuelle-Ausfluss im Gerinne      fuqa =   0.3168 [hm**3]

 Fuelle-Ausfluss im vorland      fuqa =   0.2076 [hm**3]


 Scheitel-Ausfluss im Gerinne  iqamax =   1428   qamax =       4.774 [m**3/s]

 Scheitel-Ausfluss im Vorland  iqamax =   1454   qamax =       4.401 [m**3/s]


 Gesamtzuflusswelle (ohne Basisabfluss)  sqz =     1747.465
 Gesamtabflusswelle    "       "         sq  =     1748.050


 Keine angeschlossenen Teilgebiete an Strang      4565
 Auswertung des Stranges:         4569

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Abflussverzoegerung mit Kalinin-Miljukov Parametern

 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 dt [h]:   0.08      tmax [d]:     5.00


 Kennwerte Zuflusswelle
 ----------------------

 Scheitel-Zufluss               iqzmax =   1441   qzmax =       9.209 [m**3/s]
 Scheitel-Zufluss im Gerinne    iqzfmx =   1441  qzfmax =       4.730 [m**3/s]
 Scheitel-Zufluss im Vorland    iqzvmx =   1441  qzvmax =       4.479 [m**3/s]

 Fuelle-Zufluss                   fuqz =   0.5428 [hm**3]
 Fuelle-zufluss im Gerinne       fuqzf =   0.3384 [hm**3]
 Fuelle-zufluss im Vorland       fuqzv =   0.2044 [hm**3]


 Kennwerte der Systemfunktionen
 -------------------------------

 Anzahl der Zeitschritte  ituh =    113
 Maximum u                imax =     14     umax = 0.040531
 Summe u                   suu = 0.999992   suuh = 1.000000


 tmax [d]:     5.08


 Kennwerte Ausflusswelle
 -----------------------


 Endordinate Ausfluss           qaend =   0.000

 Scheitel-Ausfluss              iqmax =   1457    qmax =       8.949 [m**3/s]


 Fuelle-Ausfluss                  fuq =   0.5443 [hm**3]

 Fuelle-Ausfluss im Gerinne      fuqa =   0.3377 [hm**3]

 Fuelle-Ausfluss im vorland      fuqa =   0.2066 [hm**3]


 Scheitel-Ausfluss im Gerinne  iqamax =   1450   qamax =       4.650 [m**3/s]

 Scheitel-Ausfluss im Vorland  iqamax =   1463   qamax =       4.362 [m**3/s]


 Gesamtzuflusswelle (ohne Basisabfluss)  sqz =     1809.475
 Gesamtabflusswelle    "       "         sq  =     1814.405


 Keine angeschlossenen Teilgebiete an Strang      4569
 Auswertung des Stranges:         4584

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Fiktiver Strang! Es erfolgt keine Abflussverzoegerung!
 Keine angeschlossenen Teilgebiete an Strang      4584
 Auswertung des Stranges:         4618

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Abflussverzoegerung mit Kalinin-Miljukov Parametern

 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 dt [h]:   0.08      tmax [d]:     5.05


 Kennwerte Zuflusswelle
 ----------------------

 Scheitel-Zufluss               iqzmax =   1455   qzmax =       9.339 [m**3/s]
 Scheitel-Zufluss im Gerinne    iqzfmx =   1455  qzfmax =       4.719 [m**3/s]
 Scheitel-Zufluss im Vorland    iqzvmx =   1455  qzvmax =       4.620 [m**3/s]

 Fuelle-Zufluss                   fuqz =   0.5989 [hm**3]
 Fuelle-zufluss im Gerinne       fuqzf =   0.3967 [hm**3]
 Fuelle-zufluss im Vorland       fuqzv =   0.2021 [hm**3]


 Kennwerte der Systemfunktionen
 -------------------------------

 Anzahl der Zeitschritte  ituh =    126
 Maximum u                imax =     18     umax = 0.034861
 Summe u                   suu = 0.999994   suuh = 1.000000


 tmax [d]:     5.14


 Kennwerte Ausflusswelle
 -----------------------


 Endordinate Ausfluss           qaend =   0.000

 Scheitel-Ausfluss              iqmax =   1470    qmax =       8.989 [m**3/s]


 Fuelle-Ausfluss                  fuq =   0.5989 [hm**3]

 Fuelle-Ausfluss im Gerinne      fuqa =   0.3967 [hm**3]

 Fuelle-Ausfluss im vorland      fuqa =   0.2022 [hm**3]


 Scheitel-Ausfluss im Gerinne  iqamax =   1456   qamax =       4.716 [m**3/s]

 Scheitel-Ausfluss im Vorland  iqamax =   1481   qamax =       4.489 [m**3/s]


 Gesamtzuflusswelle (ohne Basisabfluss)  sqz =     1996.202
 Gesamtabflusswelle    "       "         sq  =     1996.284


 Keine angeschlossenen Teilgebiete an Strang      4618
 Auswertung des Stranges:         4588

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Abflussverzoegerung mit Kalinin-Miljukov Parametern

 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 dt [h]:   0.08      tmax [d]:     5.10


 Kennwerte Zuflusswelle
 ----------------------

 Scheitel-Zufluss               iqzmax =   1470   qzmax =       9.018 [m**3/s]
 Scheitel-Zufluss im Gerinne    iqzfmx =   1470  qzfmax =       4.557 [m**3/s]
 Scheitel-Zufluss im Vorland    iqzvmx =   1470  qzvmax =       4.461 [m**3/s]

 Fuelle-Zufluss                   fuqz =   0.6027 [hm**3]
 Fuelle-zufluss im Gerinne       fuqzf =   0.3989 [hm**3]
 Fuelle-zufluss im Vorland       fuqzv =   0.2037 [hm**3]


 Kennwerte der Systemfunktionen
 -------------------------------

 Anzahl der Zeitschritte  ituh =    126
 Maximum u                imax =     18     umax = 0.034861
 Summe u                   suu = 0.999994   suuh = 1.000000


 tmax [d]:     5.19


 Kennwerte Ausflusswelle
 -----------------------


 Endordinate Ausfluss           qaend =   0.000

 Scheitel-Ausfluss              iqmax =   1485    qmax =       8.718 [m**3/s]


 Fuelle-Ausfluss                  fuq =   0.6027 [hm**3]

 Fuelle-Ausfluss im Gerinne      fuqa =   0.3989 [hm**3]

 Fuelle-Ausfluss im vorland      fuqa =   0.2038 [hm**3]


 Scheitel-Ausfluss im Gerinne  iqamax =   1471   qamax =       4.554 [m**3/s]

 Scheitel-Ausfluss im Vorland  iqamax =   1496   qamax =       4.348 [m**3/s]


 Gesamtzuflusswelle (ohne Basisabfluss)  sqz =     2008.861
 Gesamtabflusswelle    "       "         sq  =     2008.940


 Keine angeschlossenen Teilgebiete an Strang      4588
 Auswertung des Stranges:         1070

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4593

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    2.69

 gesamtmenge an niederschlag (mm):       96.0

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:    126


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  8.000


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4593
 anzahl hydrotope:     126


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      96.0 mm
 interz.verd.:                       7.3 mm
 bestandsniederschlag:              86.7 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      16.0 mm
 aktuelle verdunstung:              10.8 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              86.7 mm
 overlandflow:                       6.6 mm
 [infiltration:                     80.2 mm]
 verdunstung (bodensp.):             3.4 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -76.7 mm
 fehler:                             0.0 mm


 24.0152111  -> zufluss grundwasserleiter in  4593
TG:    4593 -> TG:    4594
Prozent:0.10

TG:    4593 -> TG:    4596
Prozent:0.90


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:            8.4 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:          10.3 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                -1.2 mm
     pot.entnahme GWS:                -1.2 mm
 speicherinhaltsaenderung:            -0.7 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.855 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.855 qkm



 ISO: Normierungsfaktor   = 1.0002
 ISO: Summe normierter uh =   1.0000


 Anzahl der Zeitschritte in iso durch Nachlauf zu hoch geworden.
 Sie wird auf 460 begrenzt !  gebiet :  4593

fuellenberechnung in iso
abflusz =          5606.035
niederschlag =     5615.722
flaeche zft  =        1.000
flaeche eing.=        0.855

GEBIET: Abflusswelle Interflow:

 ISO: Normierungsfaktor   = 1.0000
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.855

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV: Retentionskonstanten:   1.4       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =       1.00
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH =  264
ISOV:  fuellenberechnung
ISOV: Abflusz =         12929.420
ISOV: Niederschlag =    12929.424

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
ISOV: Retentionskonstanten:6000.0       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =   96602.20
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH = 2880
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1071

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4596

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    2.69

 gesamtmenge an niederschlag (mm):       96.0

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     47


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  9.700


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4596
 anzahl hydrotope:      47


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      96.0 mm
 interz.verd.:                       7.3 mm
 bestandsniederschlag:              86.8 mm
 differenz interz.speicher:         -1.9 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      15.8 mm
 aktuelle verdunstung:              10.4 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              86.8 mm
 overlandflow:                       0.0 mm
 [infiltration:                     86.8 mm]
 verdunstung (bodensp.):             3.1 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -83.7 mm
 fehler:                             0.0 mm


 47.7078056  -> zufluss grundwasserleiter in  4596
TG:    4596 -> TG:    4597
Prozent:1.00


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:           72.3 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:          77.5 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -5.2 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.198 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.198 qkm



 ISO: Normierungsfaktor   = 1.0002
 ISO: Summe normierter uh =   1.0000


 Anzahl der Zeitschritte in iso durch Nachlauf zu hoch geworden.
 Sie wird auf 460 begrenzt !  gebiet :  4596

fuellenberechnung in iso
abflusz =             4.068
niederschlag =        4.075
flaeche zft  =        1.000
flaeche eing.=        0.198

GEBIET: Abflusswelle Interflow:

 ISO: Normierungsfaktor   = 1.0000
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.198

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV: Retentionskonstanten:   1.4       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =       1.00
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH =  264
ISOV:  fuellenberechnung
ISOV: Abflusz =          3614.836
ISOV: Niederschlag =     3614.835

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
ISOV: Retentionskonstanten:6000.0       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =   96602.20
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH = 2880
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1072

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4591

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    2.69

 gesamtmenge an niederschlag (mm):       96.0

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     85


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  4.000


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4591
 anzahl hydrotope:      85


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      96.0 mm
 interz.verd.:                       7.3 mm
 bestandsniederschlag:              86.7 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      16.1 mm
 aktuelle verdunstung:              10.7 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              86.7 mm
 overlandflow:                       4.4 mm
 [infiltration:                     82.3 mm]
 verdunstung (bodensp.):             3.4 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -78.9 mm
 fehler:                             0.0 mm


 0.00000000E+00  -> zufluss grundwasserleiter in  4591
TG:    4591 -> TG:    4594
Prozent:1.00


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:            0.0 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:           1.6 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                -1.5 mm
     pot.entnahme GWS:                -1.5 mm
 speicherinhaltsaenderung:            -0.2 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.379 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.379 qkm



 ISO: Normierungsfaktor   = 1.0002
 ISO: Summe normierter uh =   1.0000


 Anzahl der Zeitschritte in iso durch Nachlauf zu hoch geworden.
 Sie wird auf 460 begrenzt !  gebiet :  4591

fuellenberechnung in iso
abflusz =          1678.038
niederschlag =     1680.940
flaeche zft  =        1.000
flaeche eing.=        0.379

GEBIET: Abflusswelle Interflow:

 ISO: Normierungsfaktor   = 1.0000
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.379

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV: Retentionskonstanten:   1.4       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =       1.00
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH =  264
ISOV:  fuellenberechnung
ISOV: Abflusz =          6318.818
ISOV: Niederschlag =     6318.819

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
ISOV: Retentionskonstanten:6000.0       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =   96602.20
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH = 2880
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1073

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4594

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    2.69

 gesamtmenge an niederschlag (mm):       96.0

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     61


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  7.500


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4594
 anzahl hydrotope:      61


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      96.0 mm
 interz.verd.:                       7.3 mm
 bestandsniederschlag:              86.7 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      16.1 mm
 aktuelle verdunstung:              10.6 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              86.7 mm
 overlandflow:                       1.4 mm
 [infiltration:                     85.3 mm]
 verdunstung (bodensp.):             3.3 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -82.0 mm
 fehler:                             0.0 mm


 entnahme gws [qbm/s]:       0.000
 4.97669458  -> zufluss grundwasserleiter in  4594
TG:    4594 -> TG:    4597
Prozent:1.00


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:            4.9 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:           5.7 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.2 mm
     pot.entnahme GWS:                 0.2 mm
 speicherinhaltsaenderung:            -1.0 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.307 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.307 qkm



 ISO: Normierungsfaktor   = 1.0002
 ISO: Summe normierter uh =   1.0000


 Anzahl der Zeitschritte in iso durch Nachlauf zu hoch geworden.
 Sie wird auf 460 begrenzt !  gebiet :  4594

fuellenberechnung in iso
abflusz =           439.275
niederschlag =      440.034
flaeche zft  =        1.000
flaeche eing.=        0.307

GEBIET: Abflusswelle Interflow:

 ISO: Normierungsfaktor   = 1.0000
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.307

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV: Retentionskonstanten:   1.4       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =       1.00
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH =  264
ISOV:  fuellenberechnung
ISOV: Abflusz =          4608.510
ISOV: Niederschlag =     4608.509

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
ISOV: Retentionskonstanten:6000.0       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =   96602.20
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH = 2880
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         4589

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.

 Keine angeschlossenen Teilgebiete an Strang      4589
 Auswertung des Stranges:         4590

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Aufruf der Speicherroutine 


 zufluss-fuelle [hm]        0.010153 speicher 4590
 zusaetzl.zufl im nachl.ast [hm]  0.000450

 speicher   0.010602 abfluss-fuelle [hm]      4590

 speicherinhaltsaenderung [hm]  0.000057
 Keine angeschlossenen Teilgebiete an Strang      4590
 Auswertung des Stranges:         4594

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Abflussverzoegerung mit Kalinin-Miljukov Parametern

 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 dt [h]:   0.08      tmax [d]:     4.93


 Kennwerte Zuflusswelle
 ----------------------

 Scheitel-Zufluss               iqzmax =   1420   qzmax =       0.294 [m**3/s]
 Scheitel-Zufluss im Gerinne    iqzfmx =   1420  qzfmax =       0.294 [m**3/s]
 Scheitel-Zufluss im Vorland    iqzvmx =      0  qzvmax =       0.000 [m**3/s]

 Fuelle-Zufluss                   fuqz =   0.0106 [hm**3]
 Fuelle-zufluss im Gerinne       fuqzf =   0.0106 [hm**3]
 Fuelle-zufluss im Vorland       fuqzv =   0.0000 [hm**3]


 Kennwerte der Systemfunktionen
 -------------------------------

 Anzahl der Zeitschritte  ituh =     18
 Maximum u                imax =      3     umax = 0.269426
 Summe u                   suu = 0.999998   suuh = 1.000000


 tmax [d]:     4.94


 Kennwerte Ausflusswelle
 -----------------------

 Endordinate Ausfluss           qaend =   0.000
 Scheitel-Ausfluss              iqmax =   1424    qmax =       0.294 [m**3/s]

 Fuelle-Ausfluss                  fuq =   0.0106 [hm**3]
 Fuelle-Ausfluss im Gerinne      fuqa =   0.0106 [hm**3]

 Scheitel-Ausfluss im Gerinne  iqamax =   1424   qamax =       0.294 [m**3/s]


 Gesamtzuflusswelle (ohne Basisabfluss)  sqz =       35.345
 Gesamtabflusswelle    "       "         sq  =       35.345


 Keine angeschlossenen Teilgebiete an Strang      4594
 Auswertung des Stranges:         4591

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.

 Keine angeschlossenen Teilgebiete an Strang      4591
 Auswertung des Stranges:         4592

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Aufruf der Speicherroutine 


 zufluss-fuelle [hm]        0.007687 speicher 4592
 zusaetzl.zufl im nachl.ast [hm]  0.000313

 speicher   0.008000 abfluss-fuelle [hm]      4592

 speicherinhaltsaenderung [hm]  0.000000
 Keine angeschlossenen Teilgebiete an Strang      4592
 Auswertung des Stranges:         4593

 Abflussverzoegerung mit Kalinin-Miljukov Parametern

 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 dt [h]:   0.08      tmax [d]:     4.93


 Kennwerte Zuflusswelle
 ----------------------

 Scheitel-Zufluss               iqzmax =   1419   qzmax =       0.237 [m**3/s]
 Scheitel-Zufluss im Gerinne    iqzfmx =   1419  qzfmax =       0.237 [m**3/s]
 Scheitel-Zufluss im Vorland    iqzvmx =      0  qzvmax =       0.000 [m**3/s]

 Fuelle-Zufluss                   fuqz =   0.0080 [hm**3]
 Fuelle-zufluss im Gerinne       fuqzf =   0.0080 [hm**3]
 Fuelle-zufluss im Vorland       fuqzv =   0.0000 [hm**3]


 Kennwerte der Systemfunktionen
 -------------------------------

 Anzahl der Zeitschritte  ituh =     18
 Maximum u                imax =      3     umax = 0.269426
 Summe u                   suu = 0.999998   suuh = 1.000000


 tmax [d]:     4.94


 Kennwerte Ausflusswelle
 -----------------------

 Endordinate Ausfluss           qaend =   0.000
 Scheitel-Ausfluss              iqmax =   1422    qmax =       0.237 [m**3/s]

 Fuelle-Ausfluss                  fuq =   0.0080 [hm**3]
 Fuelle-Ausfluss im Gerinne      fuqa =   0.0080 [hm**3]

 Scheitel-Ausfluss im Gerinne  iqamax =   1422   qamax =       0.237 [m**3/s]


 Gesamtzuflusswelle (ohne Basisabfluss)  sqz =       26.665
 Gesamtabflusswelle    "       "         sq  =       26.665


 Keine angeschlossenen Teilgebiete an Strang      4593
 Auswertung des Stranges:         4595

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Aufruf der Speicherroutine 


 zufluss-fuelle [hm]        0.040201 speicher 4595
 zusaetzl.zufl im nachl.ast [hm]  0.001991

 speicher   0.042189 abfluss-fuelle [hm]      4595

 speicherinhaltsaenderung [hm]  0.000003
 Keine angeschlossenen Teilgebiete an Strang      4595
 Auswertung des Stranges:         4596

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Aufruf der Speicherroutine 


 zufluss-fuelle [hm]        0.039436 speicher 4596
 zusaetzl.zufl im nachl.ast [hm]  0.002760

 speicher   0.042195 abfluss-fuelle [hm]      4596

 speicherinhaltsaenderung [hm]  0.000001
 Keine angeschlossenen Teilgebiete an Strang      4596
 Auswertung des Stranges:         4622

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Abflussverzoegerung mit Kalinin-Miljukov Parametern

 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 dt [h]:   0.08      tmax [d]:     4.93


 Kennwerte Zuflusswelle
 ----------------------

 Scheitel-Zufluss               iqzmax =   1420   qzmax =       1.311 [m**3/s]
 Scheitel-Zufluss im Gerinne    iqzfmx =   1420  qzfmax =       1.311 [m**3/s]
 Scheitel-Zufluss im Vorland    iqzvmx =      0  qzvmax =       0.000 [m**3/s]

 Fuelle-Zufluss                   fuqz =   0.0458 [hm**3]
 Fuelle-zufluss im Gerinne       fuqzf =   0.0458 [hm**3]
 Fuelle-zufluss im Vorland       fuqzv =   0.0000 [hm**3]


 Kennwerte der Systemfunktionen
 -------------------------------

 Anzahl der Zeitschritte  ituh =   2880
 Maximum u                imax =     18     umax = 0.000000
 Summe u                   suu = 0.000000   suuh = 0.000000


 tmax [d]:     0.00


 Kennwerte Ausflusswelle
 -----------------------


 Endordinate Ausfluss           qaend =   0.001

 Scheitel-Ausfluss              iqmax =   1423    qmax =       1.308 [m**3/s]


 Fuelle-Ausfluss                  fuq =   0.0458 [hm**3]

 Fuelle-Ausfluss im Gerinne      fuqa =   0.0458 [hm**3]

 Fuelle-Ausfluss im vorland      fuqa =   0.0000 [hm**3]


 Scheitel-Ausfluss im Gerinne  iqamax =   1423   qamax =       1.308 [m**3/s]

 Scheitel-Ausfluss im Vorland  iqamax =      0   qamax =       0.000 [m**3/s]


 Gesamtzuflusswelle (ohne Basisabfluss)  sqz =      152.724
 Gesamtabflusswelle    "       "         sq  =      152.724


 Keine angeschlossenen Teilgebiete an Strang      4622
 Auswertung des Stranges:         1074

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4598

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    2.69

 gesamtmenge an niederschlag (mm):       96.0

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     54


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  6.000


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4598
 anzahl hydrotope:      54


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      96.0 mm
 interz.verd.:                       7.5 mm
 bestandsniederschlag:              86.4 mm
 differenz interz.speicher:         -2.1 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      16.0 mm
 aktuelle verdunstung:              10.9 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              86.4 mm
 overlandflow:                       2.3 mm
 [infiltration:                     84.0 mm]
 verdunstung (bodensp.):             3.4 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -80.6 mm
 fehler:                             0.0 mm


 entnahme gws [qbm/s]:       0.000
 73.2440414  -> zufluss grundwasserleiter in  4598
TG:    4598 -> TG:    4599
Prozent:1.00


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:          199.4 mm
 abgabe basisabfluss:                 59.0 mm
        grundw. unterh.l.TG:         139.8 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.5 mm
     pot.entnahme GWS:                 0.5 mm
 speicherinhaltsaenderung:             0.0 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.110 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.110 qkm



 ISO: Normierungsfaktor   = 1.0002
 ISO: Summe normierter uh =   1.0000


 Anzahl der Zeitschritte in iso durch Nachlauf zu hoch geworden.
 Sie wird auf 460 begrenzt !  gebiet :  4598

fuellenberechnung in iso
abflusz =           256.863
niederschlag =      257.307
flaeche zft  =        1.000
flaeche eing.=        0.110

GEBIET: Abflusswelle Interflow:

 ISO: Normierungsfaktor   = 1.0000
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.110

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV: Retentionskonstanten:   1.4       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =       1.00
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH =  264
ISOV:  fuellenberechnung
ISOV: Abflusz =          1493.968
ISOV: Niederschlag =     1493.967

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
ISOV: Retentionskonstanten:6000.0       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =   96602.20
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH = 2880
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1075

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4597

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    2.69

 gesamtmenge an niederschlag (mm):       96.0

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     84


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  7.000


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4597
 anzahl hydrotope:      84


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      96.0 mm
 interz.verd.:                       7.3 mm
 bestandsniederschlag:              86.8 mm
 differenz interz.speicher:         -1.9 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      15.8 mm
 aktuelle verdunstung:              10.6 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              86.8 mm
 overlandflow:                       2.3 mm
 [infiltration:                     84.5 mm]
 verdunstung (bodensp.):             3.3 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -81.2 mm
 fehler:                             0.0 mm


 entnahme gws [qbm/s]:       0.000
 56.9823647  -> zufluss grundwasserleiter in  4597
TG:    4597 -> TG:    4599
Prozent:1.00


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:           63.7 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:          70.0 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.4 mm
     pot.entnahme GWS:                 0.4 mm
 speicherinhaltsaenderung:            -6.6 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.268 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.268 qkm



 ISO: Normierungsfaktor   = 1.0002
 ISO: Summe normierter uh =   1.0000


 Anzahl der Zeitschritte in iso durch Nachlauf zu hoch geworden.
 Sie wird auf 460 begrenzt !  gebiet :  4597

fuellenberechnung in iso
abflusz =           607.739
niederschlag =      608.789
flaeche zft  =        1.000
flaeche eing.=        0.268

GEBIET: Abflusswelle Interflow:

 ISO: Normierungsfaktor   = 1.0000
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.268

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV: Retentionskonstanten:   1.4       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =       1.00
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH =  264
ISOV:  fuellenberechnung
ISOV: Abflusz =          5974.719
ISOV: Niederschlag =     5974.715

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
ISOV: Retentionskonstanten:6000.0       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =   96602.20
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH = 2880
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1076

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4599

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    2.69

 gesamtmenge an niederschlag (mm):       96.0

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     27


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 = 20.100


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4599
 anzahl hydrotope:      27


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      96.0 mm
 interz.verd.:                       7.4 mm
 bestandsniederschlag:              86.7 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      16.2 mm
 aktuelle verdunstung:              11.8 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              86.7 mm
 overlandflow:                      12.5 mm
 [infiltration:                     74.2 mm]
 verdunstung (bodensp.):             4.4 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -69.7 mm
 fehler:                             0.0 mm


 entnahme gws [qbm/s]:       0.000
 113.934357  -> zufluss grundwasserleiter in  4599

 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:         1313.9 mm
 abgabe basisabfluss:               1015.6 mm
        grundw. unterh.l.TG:         296.8 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 1.4 mm
     pot.entnahme GWS:                 1.4 mm
 speicherinhaltsaenderung:             0.0 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.026 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.026 qkm



 ISO: Normierungsfaktor   = 1.0002
 ISO: Summe normierter uh =   1.0000


 Anzahl der Zeitschritte in iso durch Nachlauf zu hoch geworden.
 Sie wird auf 460 begrenzt !  gebiet :  4599

fuellenberechnung in iso
abflusz =           325.847
niederschlag =      326.410
flaeche zft  =        1.000
flaeche eing.=        0.026

GEBIET: Abflusswelle Interflow:

 ISO: Normierungsfaktor   = 1.0000
 ISO: Summe normierter uh =   1.0000

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.026

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV: Retentionskonstanten:   2.5       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =       1.00
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH =  448
ISOV:  fuellenberechnung
ISOV: Abflusz =           628.286
ISOV: Niederschlag =      628.286

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
ISOV: Retentionskonstanten:6000.0       0.0       0.0
ISOV: Speicheranzahl:         3.0       0.0       3.0
ISOV: Aufteilngsfaktor:      1.00      0.00
 ISOV: Normierungsfaktor =   96602.20
 ISOV: Summe normierter UH-Ordinaten =     1.0000
 ISOV: Anz. Zeitschritte UH = 2880
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         4597

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Abflussverzoegerung mit Kalinin-Miljukov Parametern

 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 dt [h]:   0.08      tmax [d]:     5.15


 Kennwerte Zuflusswelle
 ----------------------

 Scheitel-Zufluss               iqzmax =   1484   qzmax =       8.734 [m**3/s]
 Scheitel-Zufluss im Gerinne    iqzfmx =   1484  qzfmax =       4.897 [m**3/s]
 Scheitel-Zufluss im Vorland    iqzvmx =   1484  qzvmax =       3.837 [m**3/s]

 Fuelle-Zufluss                   fuqz =   0.6061 [hm**3]
 Fuelle-zufluss im Gerinne       fuqzf =   0.4149 [hm**3]
 Fuelle-zufluss im Vorland       fuqzv =   0.1912 [hm**3]


 Kennwerte der Systemfunktionen
 -------------------------------

 Anzahl der Zeitschritte  ituh =      9
 Maximum u                imax =      1     umax = 0.725271
 Summe u                   suu = 1.005751   suuh = 1.000000


 tmax [d]:     5.16


 Kennwerte Ausflusswelle
 -----------------------


 Endordinate Ausfluss           qaend =   0.002

 Scheitel-Ausfluss              iqmax =   1485    qmax =       8.733 [m**3/s]


 Fuelle-Ausfluss                  fuq =   0.6061 [hm**3]

 Fuelle-Ausfluss im Gerinne      fuqa =   0.4149 [hm**3]

 Fuelle-Ausfluss im vorland      fuqa =   0.1912 [hm**3]


 Scheitel-Ausfluss im Gerinne  iqamax =   1485   qamax =       4.896 [m**3/s]

 Scheitel-Ausfluss im Vorland  iqamax =   1485   qamax =       3.837 [m**3/s]


 Gesamtzuflusswelle (ohne Basisabfluss)  sqz =     2020.376
 Gesamtabflusswelle    "       "         sq  =     2020.375


 Keine angeschlossenen Teilgebiete an Strang      4597
 Auswertung des Stranges:         4598

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Abflussverzoegerung mit Kalinin-Miljukov Parametern

 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 dt [h]:   0.08      tmax [d]:     5.13


 Kennwerte Zuflusswelle
 ----------------------

 Scheitel-Zufluss               iqzmax =   1478   qzmax =       9.202 [m**3/s]
 Scheitel-Zufluss im Gerinne    iqzfmx =   1478  qzfmax =       6.381 [m**3/s]
 Scheitel-Zufluss im Vorland    iqzvmx =   1478  qzvmax =       2.821 [m**3/s]

 Fuelle-Zufluss                   fuqz =   0.6668 [hm**3]
 Fuelle-zufluss im Gerinne       fuqzf =   0.5032 [hm**3]
 Fuelle-zufluss im Vorland       fuqzv =   0.1636 [hm**3]


 Kennwerte der Systemfunktionen
 -------------------------------

 Anzahl der Zeitschritte  ituh =     16
 Maximum u                imax =      1     umax = 0.517926
 Summe u                   suu = 0.610857   suuh = 0.999798


 tmax [d]:     5.14


 Kennwerte Ausflusswelle
 -----------------------


 Endordinate Ausfluss           qaend =   0.000

 Scheitel-Ausfluss              iqmax =   1479    qmax =       9.200 [m**3/s]


 Fuelle-Ausfluss                  fuq =   0.6668 [hm**3]

 Fuelle-Ausfluss im Gerinne      fuqa =   0.5032 [hm**3]

 Fuelle-Ausfluss im vorland      fuqa =   0.1636 [hm**3]


 Scheitel-Ausfluss im Gerinne  iqamax =   1479   qamax =       6.380 [m**3/s]

 Scheitel-Ausfluss im Vorland  iqamax =   1479   qamax =       2.821 [m**3/s]


 Gesamtzuflusswelle (ohne Basisabfluss)  sqz =     2222.698
 Gesamtabflusswelle    "       "         sq  =     2222.610


 Keine angeschlossenen Teilgebiete an Strang      4598
 Auswertung des Stranges:         4599

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Fiktiver Strang! Es erfolgt keine Abflussverzoegerung!
 Keine angeschlossenen Teilgebiete an Strang      4599
 Auswertung des Stranges:        10002

 Fiktiver Strang! Es erfolgt keine Abflussverzoegerung!
 Keine angeschlossenen Teilgebiete an Strang     10002


 ------------------------------------------------------------------
           Berechnung wurde ohne Fehler beendet!                   
 ------------------------------------------------------------------
