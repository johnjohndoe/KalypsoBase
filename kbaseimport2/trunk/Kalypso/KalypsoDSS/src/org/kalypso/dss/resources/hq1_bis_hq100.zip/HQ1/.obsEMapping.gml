<?xml version="1.0" encoding="UTF-8"?>
<MappingCollection fid="ID1" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns="http://org.kalypso.updateObservationMapping" xmlns:obslink="obslink.zml.kalypso.org" xmlns:gml="http://www.opengis.net/gml" xsi:schemaLocation="http://org.kalypso.updateObservationMapping ">
  <mappingMember>
    <MappingObservation fid="MappingObservation2">
      <gml:name>E_Fuhlsbuettel</gml:name>
      <point>
        <gml:Point srsName="EPSG:31467">
          <gml:coordinates cs="," decimal="." ts=" ">3566183.9853144297,5945670.160055787</gml:coordinates>
        </gml:Point>
      </point>
      <inObservationLink>
        <TimeseriesLink xmlns:ns1="http://www.w3.org/1999/xlink" xmlns="obslink.zml.kalypso.org" ns1:href="project:/.model/zeitreihen/Klima/E_Fuhlsbuettel.zml" ns1:type="simple" linktype="zml"/>
      </inObservationLink>
      <outObservationLink/>
    </MappingObservation>
  </mappingMember>
</MappingCollection>
