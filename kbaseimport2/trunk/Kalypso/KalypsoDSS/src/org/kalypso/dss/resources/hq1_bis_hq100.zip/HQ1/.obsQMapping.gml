<?xml version="1.0" encoding="UTF-8"?>
<MappingCollection fid="ID1" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns="http://org.kalypso.updateObservationMapping" xmlns:obslink="obslink.zml.kalypso.org" xmlns:gml="http://www.opengis.net/gml" xsi:schemaLocation="http://org.kalypso.updateObservationMapping ">
  <mappingMember>
    <MappingObservation fid="MappingObservation1">
      <gml:name>Niendorferstrasse</gml:name>
      <inObservationLink>
        <TimeseriesLink xmlns:ns1="http://www.w3.org/1999/xlink" xmlns="obslink.zml.kalypso.org" ns1:href="project:/.model/zeitreihen/Pegel/Kurzzeitwerte(5min)/Niendorferstrasse.zml"/>
      </inObservationLink>
      <outObservationLink/>
    </MappingObservation>
  </mappingMember>
  <mappingMember>
    <MappingObservation fid="MappingObservation2">
      <gml:name>Olloweg</gml:name>
      <inObservationLink>
        <TimeseriesLink xmlns:ns1="http://www.w3.org/1999/xlink" xmlns="obslink.zml.kalypso.org" ns1:href="project:/.model/zeitreihen/Pegel/Kurzzeitwerte(5min)/Olloweg.zml"/>
      </inObservationLink>
      <outObservationLink/>
    </MappingObservation>
  </mappingMember>
  <mappingMember>
    <MappingObservation fid="MappingObservation4">
      <gml:name>Wendlohstrasse</gml:name>
      <inObservationLink>
        <TimeseriesLink xmlns:ns1="http://www.w3.org/1999/xlink" xmlns="obslink.zml.kalypso.org" ns1:href="project:/.model/zeitreihen/Pegel/Kurzzeitwerte(5min)/Wendlohstrasse.zml"/>
      </inObservationLink>
      <outObservationLink/>
    </MappingObservation>
  </mappingMember>
  <mappingMember>
    <MappingObservation fid="MappingObservation5">
      <gml:name>Schippelmoorgraben</gml:name>
      <inObservationLink>
        <TimeseriesLink xmlns:ns1="http://www.w3.org/1999/xlink" xmlns="obslink.zml.kalypso.org" ns1:href="project:/.model/zeitreihen/Pegel/Kurzzeitwerte(5min)/Schippelmoorgraben.zml"/>
      </inObservationLink>
      <outObservationLink/>
    </MappingObservation>
  </mappingMember>
</MappingCollection>
