<?xml version="1.0" encoding="UTF-8"?>
<ns2:Parameter xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:ns1="http://www.opengis.net/gml" xmlns:xs="http://www.w3.org/2001/XMLSchema-instance" xmlns:ns2="http://www.tuhh.de/parameter" ns1:fid="Parameter0">
 <ns2:snowMember>
  <ns2:Snow ns1:fid="Snow_snowtyp2">
   <ns1:name>snowtyp2</ns1:name>
   <ns2:xwwo>0.2</ns2:xwwo>
   <ns2:xwwmax>0.45</ns2:xwwmax>
   <ns2:xsnotem>0.25</ns2:xsnotem>
   <ns2:xsnorad>0.35</ns2:xsnorad>
   <ns2:xh0>0.0</ns2:xh0>
  </ns2:Snow>
 </ns2:snowMember>
 <ns2:snowMember>
  <ns2:Snow ns1:fid="Snow_snowtyp1">
   <ns1:name>snowtyp1</ns1:name>
   <ns2:xwwo>0.2</ns2:xwwo>
   <ns2:xwwmax>0.45</ns2:xwwmax>
   <ns2:xsnotem>0.15</ns2:xsnotem>
   <ns2:xsnorad>0.25</ns2:xsnorad>
   <ns2:xh0>0.0</ns2:xh0>
  </ns2:Snow>
 </ns2:snowMember>
 <ns2:soilLayerMember>
  <ns2:SoilLayer ns1:fid="SoilLayer_mulde">
   <ns1:description>Schicht für die Mulde (MRS)</ns1:description>
   <ns1:name>mulde</ns1:name>
   <ns2:typwp>1.0</ns2:typwp>
   <ns2:typfk>2.0</ns2:typfk>
   <ns2:typbfm>100.0</ns2:typbfm>
   <ns2:typkf>864000.0</ns2:typkf>
   <ns2:typbf0>0.75</ns2:typbf0>
  </ns2:SoilLayer>
 </ns2:soilLayerMember>
 <ns2:soilLayerMember>
  <ns2:SoilLayer ns1:fid="SoilLayer_S22">
   <ns1:name>S22</ns1:name>
   <ns2:typwp>13.2</ns2:typwp>
   <ns2:typfk>45.2</ns2:typfk>
   <ns2:typbfm>52.6</ns2:typbfm>
   <ns2:typkf>89.0</ns2:typkf>
   <ns2:typbf0>0.75</ns2:typbf0>
  </ns2:SoilLayer>
 </ns2:soilLayerMember>
 <ns2:soilLayerMember>
  <ns2:SoilLayer ns1:fid="SoilLayer_S23">
   <ns1:name>S23</ns1:name>
   <ns2:typwp>17.0</ns2:typwp>
   <ns2:typfk>45.2</ns2:typfk>
   <ns2:typbfm>50.9</ns2:typbfm>
   <ns2:typkf>89.0</ns2:typkf>
   <ns2:typbf0>0.75</ns2:typbf0>
  </ns2:SoilLayer>
 </ns2:soilLayerMember>
 <ns2:soilLayerMember>
  <ns2:SoilLayer ns1:fid="SoilLayer_S26">
   <ns1:name>S26</ns1:name>
   <ns2:typwp>6.5</ns2:typwp>
   <ns2:typfk>18.5</ns2:typfk>
   <ns2:typbfm>41.0</ns2:typbfm>
   <ns2:typkf>3490.0</ns2:typkf>
   <ns2:typbf0>0.75</ns2:typbf0>
  </ns2:SoilLayer>
 </ns2:soilLayerMember>
 <ns2:soilLayerMember>
  <ns2:SoilLayer ns1:fid="SoilLayer_S27">
   <ns1:name>S27</ns1:name>
   <ns2:typwp>6.0</ns2:typwp>
   <ns2:typfk>16.5</ns2:typfk>
   <ns2:typbfm>36.0</ns2:typbfm>
   <ns2:typkf>1260.0</ns2:typkf>
   <ns2:typbf0>0.75</ns2:typbf0>
  </ns2:SoilLayer>
 </ns2:soilLayerMember>
 <ns2:soilLayerMember>
  <ns2:SoilLayer ns1:fid="SoilLayer_S30">
   <ns1:name>S30</ns1:name>
   <ns2:typwp>6.5</ns2:typwp>
   <ns2:typfk>18.5</ns2:typfk>
   <ns2:typbfm>41.0</ns2:typbfm>
   <ns2:typkf>3490.0</ns2:typkf>
   <ns2:typbf0>0.75</ns2:typbf0>
  </ns2:SoilLayer>
 </ns2:soilLayerMember>
 <ns2:soilLayerMember>
  <ns2:SoilLayer ns1:fid="SoilLayer_S31">
   <ns1:name>S31</ns1:name>
   <ns2:typwp>6.0</ns2:typwp>
   <ns2:typfk>16.5</ns2:typfk>
   <ns2:typbfm>46.0</ns2:typbfm>
   <ns2:typkf>2290.0</ns2:typkf>
   <ns2:typbf0>0.75</ns2:typbf0>
  </ns2:SoilLayer>
 </ns2:soilLayerMember>
 <ns2:soilLayerMember>
  <ns2:SoilLayer ns1:fid="SoilLayer_Hn">
   <ns1:name>Hn</ns1:name>
   <ns2:typwp>18.0</ns2:typwp>
   <ns2:typfk>78.0</ns2:typfk>
   <ns2:typbfm>90.0</ns2:typbfm>
   <ns2:typkf>240.0</ns2:typkf>
   <ns2:typbf0>0.75</ns2:typbf0>
  </ns2:SoilLayer>
 </ns2:soilLayerMember>
 <ns2:soilLayerMember>
  <ns2:SoilLayer ns1:fid="SoilLayer_Ls2">
   <ns1:name>Ls2</ns1:name>
   <ns2:typwp>19.5</ns2:typwp>
   <ns2:typfk>40.5</ns2:typfk>
   <ns2:typbfm>50.0</ns2:typbfm>
   <ns2:typkf>410.0</ns2:typkf>
   <ns2:typbf0>0.75</ns2:typbf0>
  </ns2:SoilLayer>
 </ns2:soilLayerMember>
 <ns2:soilLayerMember>
  <ns2:SoilLayer ns1:fid="SoilLayer_mS">
   <ns1:name>mS</ns1:name>
   <ns2:typwp>4.5</ns2:typwp>
   <ns2:typfk>13.5</ns2:typfk>
   <ns2:typbfm>41.5</ns2:typbfm>
   <ns2:typkf>6530.0</ns2:typkf>
   <ns2:typbf0>0.75</ns2:typbf0>
  </ns2:SoilLayer>
 </ns2:soilLayerMember>
 <ns2:soilLayerMember>
  <ns2:SoilLayer ns1:fid="SoilLayer_mSgsld2">
   <ns1:name>mSgsld2</ns1:name>
   <ns2:typwp>4.0</ns2:typwp>
   <ns2:typfk>15.0</ns2:typfk>
   <ns2:typbfm>41.0</ns2:typbfm>
   <ns2:typkf>5810.0</ns2:typkf>
   <ns2:typbf0>0.75</ns2:typbf0>
  </ns2:SoilLayer>
 </ns2:soilLayerMember>
 <ns2:soilLayerMember>
  <ns2:SoilLayer ns1:fid="SoilLayer_Tu">
   <ns1:name>Tu</ns1:name>
   <ns2:typwp>26.0</ns2:typwp>
   <ns2:typfk>41.5</ns2:typfk>
   <ns2:typbfm>46.0</ns2:typbfm>
   <ns2:typkf>130.0</ns2:typkf>
   <ns2:typbf0>0.75</ns2:typbf0>
  </ns2:SoilLayer>
 </ns2:soilLayerMember>
 <ns2:soilLayerMember>
  <ns2:SoilLayer ns1:fid="SoilLayer_Ut">
   <ns1:name>Ut</ns1:name>
   <ns2:typwp>12.5</ns2:typwp>
   <ns2:typfk>36.0</ns2:typfk>
   <ns2:typbfm>40.5</ns2:typbfm>
   <ns2:typkf>80.0</ns2:typkf>
   <ns2:typbf0>0.75</ns2:typbf0>
  </ns2:SoilLayer>
 </ns2:soilLayerMember>
 <ns2:soilLayerMember>
  <ns2:SoilLayer ns1:fid="SoilLayer_mSfsld2">
   <ns1:name>mSfsld2</ns1:name>
   <ns2:typwp>4.5</ns2:typwp>
   <ns2:typfk>19.0</ns2:typfk>
   <ns2:typbfm>42.0</ns2:typbfm>
   <ns2:typkf>3110.0</ns2:typkf>
   <ns2:typbf0>0.75</ns2:typbf0>
  </ns2:SoilLayer>
 </ns2:soilLayerMember>
 <ns2:soilLayerMember>
  <ns2:SoilLayer ns1:fid="SoilLayer_mSfsld3">
   <ns1:name>mSfsld3</ns1:name>
   <ns2:typwp>3.5</ns2:typwp>
   <ns2:typfk>16.0</ns2:typfk>
   <ns2:typbfm>35.5</ns2:typbfm>
   <ns2:typkf>2210.0</ns2:typkf>
   <ns2:typbf0>0.75</ns2:typbf0>
  </ns2:SoilLayer>
 </ns2:soilLayerMember>
 <ns2:soilLayerMember>
  <ns2:SoilLayer ns1:fid="SoilLayer_mS-Sl22">
   <ns1:name>mS-Sl22</ns1:name>
   <ns2:typwp>5.5</ns2:typwp>
   <ns2:typfk>20.0</ns2:typfk>
   <ns2:typbfm>45.5</ns2:typbfm>
   <ns2:typkf>2680.0</ns2:typkf>
   <ns2:typbf0>0.75</ns2:typbf0>
  </ns2:SoilLayer>
 </ns2:soilLayerMember>
 <ns2:soilLayerMember>
  <ns2:SoilLayer ns1:fid="SoilLayer_mS-Sl23">
   <ns1:name>mS-Sl23</ns1:name>
   <ns2:typwp>5.0</ns2:typwp>
   <ns2:typfk>17.5</ns2:typfk>
   <ns2:typbfm>38.5</ns2:typbfm>
   <ns2:typkf>2380.0</ns2:typkf>
   <ns2:typbf0>0.75</ns2:typbf0>
  </ns2:SoilLayer>
 </ns2:soilLayerMember>
 <ns2:soilLayerMember>
  <ns2:SoilLayer ns1:fid="SoilLayer_Sl2ld2">
   <ns1:name>Sl2ld2</ns1:name>
   <ns2:typwp>7.0</ns2:typwp>
   <ns2:typfk>26.0</ns2:typfk>
   <ns2:typbfm>50.0</ns2:typbfm>
   <ns2:typkf>1090.0</ns2:typkf>
   <ns2:typbf0>0.75</ns2:typbf0>
  </ns2:SoilLayer>
 </ns2:soilLayerMember>
 <ns2:soilLayerMember>
  <ns2:SoilLayer ns1:fid="SoilLayer_Sl2Ls32">
   <ns1:name>Sl2Ls32</ns1:name>
   <ns2:typwp>15.0</ns2:typwp>
   <ns2:typfk>37.0</ns2:typfk>
   <ns2:typbfm>51.0</ns2:typbfm>
   <ns2:typkf>310.0</ns2:typkf>
   <ns2:typbf0>0.75</ns2:typbf0>
  </ns2:SoilLayer>
 </ns2:soilLayerMember>
 <ns2:soilLayerMember>
  <ns2:SoilLayer ns1:fid="SoilLayer_Sl2Ls33">
   <ns1:name>Sl2Ls33</ns1:name>
   <ns2:typwp>13.5</ns2:typwp>
   <ns2:typfk>31.0</ns2:typfk>
   <ns2:typbfm>42.0</ns2:typbfm>
   <ns2:typkf>280.0</ns2:typkf>
   <ns2:typbf0>0.75</ns2:typbf0>
  </ns2:SoilLayer>
 </ns2:soilLayerMember>
 <ns2:soilLayerMember>
  <ns2:SoilLayer ns1:fid="SoilLayer_Sl2Ls35">
   <ns1:name>Sl2Ls35</ns1:name>
   <ns2:typwp>12.0</ns2:typwp>
   <ns2:typfk>27.0</ns2:typfk>
   <ns2:typbfm>35.0</ns2:typbfm>
   <ns2:typkf>275.0</ns2:typkf>
   <ns2:typbf0>0.75</ns2:typbf0>
  </ns2:SoilLayer>
 </ns2:soilLayerMember>
 <ns2:soilLayerMember>
  <ns2:SoilLayer ns1:fid="SoilLayer_Ls4ld3">
   <ns1:name>Ls4ld3</ns1:name>
   <ns2:typwp>15.0</ns2:typwp>
   <ns2:typfk>32.0</ns2:typfk>
   <ns2:typbfm>43.0</ns2:typbfm>
   <ns2:typkf>140.0</ns2:typkf>
   <ns2:typbf0>0.75</ns2:typbf0>
  </ns2:SoilLayer>
 </ns2:soilLayerMember>
 <ns2:soilLayerMember>
  <ns2:SoilLayer ns1:fid="SoilLayer_Hnz4SV3">
   <ns1:name>Hnz4SV3</ns1:name>
   <ns2:typwp>20.0</ns2:typwp>
   <ns2:typfk>80.0</ns2:typfk>
   <ns2:typbfm>90.0</ns2:typbfm>
   <ns2:typkf>200.0</ns2:typkf>
   <ns2:typbf0>0.75</ns2:typbf0>
  </ns2:SoilLayer>
 </ns2:soilLayerMember>
 <ns2:soilLayerMember>
  <ns2:SoilLayer ns1:fid="SoilLayer_Hn-mSfs">
   <ns1:name>Hn-mSfs</ns1:name>
   <ns2:typwp>11.5</ns2:typwp>
   <ns2:typfk>56.0</ns2:typfk>
   <ns2:typbfm>73.0</ns2:typbfm>
   <ns2:typkf>400.0</ns2:typkf>
   <ns2:typbf0>0.75</ns2:typbf0>
  </ns2:SoilLayer>
 </ns2:soilLayerMember>
 <ns2:soilLayerMember>
  <ns2:SoilLayer ns1:fid="SoilLayer_Ls2ld2">
   <ns1:name>Ls2ld2</ns1:name>
   <ns2:typwp>19.0</ns2:typwp>
   <ns2:typfk>40.0</ns2:typfk>
   <ns2:typbfm>53.0</ns2:typbfm>
   <ns2:typkf>410.0</ns2:typkf>
   <ns2:typbf0>0.75</ns2:typbf0>
  </ns2:SoilLayer>
 </ns2:soilLayerMember>
 <ns2:soilLayerMember>
  <ns2:SoilLayer ns1:fid="SoilLayer_Su2ld2">
   <ns1:name>Su2ld2</ns1:name>
   <ns2:typwp>6.0</ns2:typwp>
   <ns2:typfk>26.0</ns2:typfk>
   <ns2:typbfm>50.0</ns2:typbfm>
   <ns2:typkf>1570.0</ns2:typkf>
   <ns2:typbf0>0.75</ns2:typbf0>
  </ns2:SoilLayer>
 </ns2:soilLayerMember>
 <ns2:soilLayerMember>
  <ns2:SoilLayer ns1:fid="SoilLayer_Su2ld3">
   <ns1:name>Su2ld3</ns1:name>
   <ns2:typwp>5.0</ns2:typwp>
   <ns2:typfk>23.0</ns2:typfk>
   <ns2:typbfm>44.0</ns2:typbfm>
   <ns2:typkf>888.0</ns2:typkf>
   <ns2:typbf0>0.75</ns2:typbf0>
  </ns2:SoilLayer>
 </ns2:soilLayerMember>
 <ns2:soilLayerMember>
  <ns2:SoilLayer ns1:fid="SoilLayer_mSld2">
   <ns1:name>mSld2</ns1:name>
   <ns2:typwp>5.0</ns2:typwp>
   <ns2:typfk>14.0</ns2:typfk>
   <ns2:typbfm>50.0</ns2:typbfm>
   <ns2:typkf>6530.0</ns2:typkf>
   <ns2:typbf0>0.75</ns2:typbf0>
  </ns2:SoilLayer>
 </ns2:soilLayerMember>
 <ns2:soilLayerMember>
  <ns2:SoilLayer ns1:fid="SoilLayer_gSld2">
   <ns1:name>gSld2</ns1:name>
   <ns2:typwp>4.0</ns2:typwp>
   <ns2:typfk>12.0</ns2:typfk>
   <ns2:typbfm>50.0</ns2:typbfm>
   <ns2:typkf>9290.0</ns2:typkf>
   <ns2:typbf0>0.75</ns2:typbf0>
  </ns2:SoilLayer>
 </ns2:soilLayerMember>
 <ns2:soilLayerMember>
  <ns2:SoilLayer ns1:fid="SoilLayer_gSld3">
   <ns1:name>gSld3</ns1:name>
   <ns2:typwp>3.0</ns2:typwp>
   <ns2:typfk>8.0</ns2:typfk>
   <ns2:typbfm>41.0</ns2:typbfm>
   <ns2:typkf>7830.0</ns2:typkf>
   <ns2:typbf0>0.75</ns2:typbf0>
  </ns2:SoilLayer>
 </ns2:soilLayerMember>
 <ns2:soilLayerMember>
  <ns2:SoilLayer ns1:fid="SoilLayer_Sl2ld3">
   <ns1:name>Sl2ld3</ns1:name>
   <ns2:typwp>6.5</ns2:typwp>
   <ns2:typfk>24.0</ns2:typfk>
   <ns2:typbfm>36.5</ns2:typbfm>
   <ns2:typkf>490.0</ns2:typkf>
   <ns2:typbf0>0.75</ns2:typbf0>
  </ns2:SoilLayer>
 </ns2:soilLayerMember>
 <ns2:soilLayerMember>
  <ns2:SoilLayer ns1:fid="SoilLayer_Ulsld3">
   <ns1:name>Ulsld3</ns1:name>
   <ns2:typwp>13.0</ns2:typwp>
   <ns2:typfk>35.0</ns2:typfk>
   <ns2:typbfm>43.0</ns2:typbfm>
   <ns2:typkf>140.0</ns2:typkf>
   <ns2:typbf0>0.75</ns2:typbf0>
  </ns2:SoilLayer>
 </ns2:soilLayerMember>
 <ns2:soilLayerMember>
  <ns2:SoilLayer ns1:fid="SoilLayer_mSgsld3">
   <ns1:name>mSgsld3</ns1:name>
   <ns2:typwp>3.0</ns2:typwp>
   <ns2:typfk>11.0</ns2:typfk>
   <ns2:typbfm>34.5</ns2:typbfm>
   <ns2:typkf>2810.0</ns2:typkf>
   <ns2:typbf0>0.75</ns2:typbf0>
  </ns2:SoilLayer>
 </ns2:soilLayerMember>
 <ns2:soilLayerMember>
  <ns2:SoilLayer ns1:fid="SoilLayer_Tu3ld3">
   <ns1:name>Tu3ld3</ns1:name>
   <ns2:typwp>26.0</ns2:typwp>
   <ns2:typfk>41.5</ns2:typfk>
   <ns2:typbfm>46.0</ns2:typbfm>
   <ns2:typkf>130.0</ns2:typkf>
   <ns2:typbf0>0.75</ns2:typbf0>
  </ns2:SoilLayer>
 </ns2:soilLayerMember>
 <ns2:soilLayerMember>
  <ns2:SoilLayer ns1:fid="SoilLayer_mSld3">
   <ns1:name>mSld3</ns1:name>
   <ns2:typwp>4.0</ns2:typwp>
   <ns2:typfk>10.0</ns2:typfk>
   <ns2:typbfm>42.0</ns2:typbfm>
   <ns2:typkf>4270.0</ns2:typkf>
   <ns2:typbf0>0.75</ns2:typbf0>
  </ns2:SoilLayer>
 </ns2:soilLayerMember>
 <ns2:soilLayerMember>
  <ns2:SoilLayer ns1:fid="SoilLayer_Ls3ld3">
   <ns1:name>Ls3ld3</ns1:name>
   <ns2:typwp>17.0</ns2:typwp>
   <ns2:typfk>33.0</ns2:typfk>
   <ns2:typbfm>42.0</ns2:typbfm>
   <ns2:typkf>70.0</ns2:typkf>
   <ns2:typbf0>0.75</ns2:typbf0>
  </ns2:SoilLayer>
 </ns2:soilLayerMember>
 <ns2:soilLayerMember>
  <ns2:SoilLayer ns1:fid="SoilLayer_Tt">
   <ns1:name>Tt</ns1:name>
   <ns2:typwp>36.0</ns2:typwp>
   <ns2:typfk>56.0</ns2:typfk>
   <ns2:typbfm>64.0</ns2:typbfm>
   <ns2:typkf>20.0</ns2:typkf>
   <ns2:typbf0>0.75</ns2:typbf0>
  </ns2:SoilLayer>
 </ns2:soilLayerMember>
 <ns2:soilLayerMember>
  <ns2:SoilLayer ns1:fid="SoilLayer_Hn">
   <ns1:name>Hn</ns1:name>
   <ns2:typwp>18.0</ns2:typwp>
   <ns2:typfk>78.0</ns2:typfk>
   <ns2:typbfm>90.0</ns2:typbfm>
   <ns2:typkf>240.0</ns2:typkf>
   <ns2:typbf0>0.75</ns2:typbf0>
  </ns2:SoilLayer>
 </ns2:soilLayerMember>
 <ns2:soilLayerMember>
  <ns2:SoilLayer ns1:fid="SoilLayer_Ls2ld3">
   <ns1:name>Ls2ld3</ns1:name>
   <ns2:typwp>18.0</ns2:typwp>
   <ns2:typfk>34.0</ns2:typfk>
   <ns2:typbfm>43.0</ns2:typbfm>
   <ns2:typkf>200.0</ns2:typkf>
   <ns2:typbf0>0.75</ns2:typbf0>
  </ns2:SoilLayer>
 </ns2:soilLayerMember>
 <ns2:soilLayerMember>
  <ns2:SoilLayer ns1:fid="SoilLayer_Lu">
   <ns1:name>Lu</ns1:name>
   <ns2:typwp>19.0</ns2:typwp>
   <ns2:typfk>36.0</ns2:typfk>
   <ns2:typbfm>43.0</ns2:typbfm>
   <ns2:typkf>180.0</ns2:typkf>
   <ns2:typbf0>0.75</ns2:typbf0>
  </ns2:SoilLayer>
 </ns2:soilLayerMember>
 <ns2:soilLayerMember>
  <ns2:SoilLayer ns1:fid="SoilLayer_Sl4ld3">
   <ns1:name>Sl4ld3</ns1:name>
   <ns2:typwp>11.5</ns2:typwp>
   <ns2:typfk>28.5</ns2:typfk>
   <ns2:typbfm>38.5</ns2:typbfm>
   <ns2:typkf>210.0</ns2:typkf>
   <ns2:typbf0>0.75</ns2:typbf0>
  </ns2:SoilLayer>
 </ns2:soilLayerMember>
 <ns2:soilLayerMember>
  <ns2:SoilLayer ns1:fid="SoilLayer_Lt3ld3">
   <ns1:name>Lt3ld3</ns1:name>
   <ns2:typwp>29.0</ns2:typwp>
   <ns2:typfk>43.0</ns2:typfk>
   <ns2:typbfm>49.0</ns2:typbfm>
   <ns2:typkf>100.0</ns2:typkf>
   <ns2:typbf0>0.75</ns2:typbf0>
  </ns2:SoilLayer>
 </ns2:soilLayerMember>
 <ns2:soilLayerMember>
  <ns2:SoilLayer ns1:fid="SoilLayer_S1">
   <ns1:name>S1</ns1:name>
   <ns2:typwp>7.6</ns2:typwp>
   <ns2:typfk>22.6</ns2:typfk>
   <ns2:typbfm>42.2</ns2:typbfm>
   <ns2:typkf>2836.0</ns2:typkf>
   <ns2:typbf0>0.75</ns2:typbf0>
  </ns2:SoilLayer>
 </ns2:soilLayerMember>
 <ns2:soilLayerMember>
  <ns2:SoilLayer ns1:fid="SoilLayer_S2">
   <ns1:name>S2</ns1:name>
   <ns2:typwp>7.2</ns2:typwp>
   <ns2:typfk>21.0</ns2:typfk>
   <ns2:typbfm>38.2</ns2:typbfm>
   <ns2:typkf>1876.0</ns2:typkf>
   <ns2:typbf0>0.75</ns2:typbf0>
  </ns2:SoilLayer>
 </ns2:soilLayerMember>
 <ns2:soilLayerMember>
  <ns2:SoilLayer ns1:fid="SoilLayer_S3">
   <ns1:name>S3</ns1:name>
   <ns2:typwp>8.7</ns2:typwp>
   <ns2:typfk>26.7</ns2:typfk>
   <ns2:typbfm>43.4</ns2:typbfm>
   <ns2:typkf>2182.0</ns2:typkf>
   <ns2:typbf0>0.75</ns2:typbf0>
  </ns2:SoilLayer>
 </ns2:soilLayerMember>
 <ns2:soilLayerMember>
  <ns2:SoilLayer ns1:fid="SoilLayer_S4">
   <ns1:name>S4</ns1:name>
   <ns2:typwp>9.6</ns2:typwp>
   <ns2:typfk>24.4</ns2:typfk>
   <ns2:typbfm>39.1</ns2:typbfm>
   <ns2:typkf>1458.0</ns2:typkf>
   <ns2:typbf0>0.75</ns2:typbf0>
  </ns2:SoilLayer>
 </ns2:soilLayerMember>
 <ns2:soilLayerMember>
  <ns2:SoilLayer ns1:fid="SoilLayer_S5">
   <ns1:name>S5</ns1:name>
   <ns2:typwp>12.0</ns2:typwp>
   <ns2:typfk>39.0</ns2:typfk>
   <ns2:typbfm>47.0</ns2:typbfm>
   <ns2:typkf>220.0</ns2:typkf>
   <ns2:typbf0>0.75</ns2:typbf0>
  </ns2:SoilLayer>
 </ns2:soilLayerMember>
 <ns2:soilLayerMember>
  <ns2:SoilLayer ns1:fid="SoilLayer_S6">
   <ns1:name>S6</ns1:name>
   <ns2:typwp>7.5</ns2:typwp>
   <ns2:typfk>33.0</ns2:typfk>
   <ns2:typbfm>38.0</ns2:typbfm>
   <ns2:typkf>100.0</ns2:typkf>
   <ns2:typbf0>0.75</ns2:typbf0>
  </ns2:SoilLayer>
 </ns2:soilLayerMember>
 <ns2:soilLayerMember>
  <ns2:SoilLayer ns1:fid="SoilLayer_S7">
   <ns1:name>S7</ns1:name>
   <ns2:typwp>7.9</ns2:typwp>
   <ns2:typfk>26.4</ns2:typfk>
   <ns2:typbfm>43.0</ns2:typbfm>
   <ns2:typkf>1636.0</ns2:typkf>
   <ns2:typbf0>0.75</ns2:typbf0>
  </ns2:SoilLayer>
 </ns2:soilLayerMember>
 <ns2:soilLayerMember>
  <ns2:SoilLayer ns1:fid="SoilLayer_S8">
   <ns1:name>S8</ns1:name>
   <ns2:typwp>13.0</ns2:typwp>
   <ns2:typfk>26.6</ns2:typfk>
   <ns2:typbfm>39.6</ns2:typbfm>
   <ns2:typkf>816.0</ns2:typkf>
   <ns2:typbf0>0.75</ns2:typbf0>
  </ns2:SoilLayer>
 </ns2:soilLayerMember>
 <ns2:soilLayerMember>
  <ns2:SoilLayer ns1:fid="SoilLayer_S9">
   <ns1:name>S9</ns1:name>
   <ns2:typwp>8.3</ns2:typwp>
   <ns2:typfk>29.3</ns2:typfk>
   <ns2:typbfm>43.6</ns2:typbfm>
   <ns2:typkf>873.0</ns2:typkf>
   <ns2:typbf0>0.75</ns2:typbf0>
  </ns2:SoilLayer>
 </ns2:soilLayerMember>
 <ns2:soilLayerMember>
  <ns2:SoilLayer ns1:fid="SoilLayer_S10">
   <ns1:name>S10</ns1:name>
   <ns2:typwp>18.7</ns2:typwp>
   <ns2:typfk>35.2</ns2:typfk>
   <ns2:typbfm>41.0</ns2:typbfm>
   <ns2:typkf>148.0</ns2:typkf>
   <ns2:typbf0>0.75</ns2:typbf0>
  </ns2:SoilLayer>
 </ns2:soilLayerMember>
 <ns2:soilLayerMember>
  <ns2:SoilLayer ns1:fid="SoilLayer_S11">
   <ns1:name>S11</ns1:name>
   <ns2:typwp>13.9</ns2:typwp>
   <ns2:typfk>39.4</ns2:typfk>
   <ns2:typbfm>47.8</ns2:typbfm>
   <ns2:typkf>268.0</ns2:typkf>
   <ns2:typbf0>0.75</ns2:typbf0>
  </ns2:SoilLayer>
 </ns2:soilLayerMember>
 <ns2:soilLayerMember>
  <ns2:SoilLayer ns1:fid="SoilLayer_S12">
   <ns1:name>S12</ns1:name>
   <ns2:typwp>9.1</ns2:typwp>
   <ns2:typfk>31.9</ns2:typfk>
   <ns2:typbfm>39.4</ns2:typbfm>
   <ns2:typkf>244.0</ns2:typkf>
   <ns2:typbf0>0.75</ns2:typbf0>
  </ns2:SoilLayer>
 </ns2:soilLayerMember>
 <ns2:soilLayerMember>
  <ns2:SoilLayer ns1:fid="SoilLayer_S13">
   <ns1:name>S13</ns1:name>
   <ns2:typwp>17.4</ns2:typwp>
   <ns2:typfk>45.9</ns2:typfk>
   <ns2:typbfm>56.3</ns2:typbfm>
   <ns2:typkf>274.0</ns2:typkf>
   <ns2:typbf0>0.75</ns2:typbf0>
  </ns2:SoilLayer>
 </ns2:soilLayerMember>
 <ns2:soilLayerMember>
  <ns2:SoilLayer ns1:fid="SoilLayer_S14">
   <ns1:name>S14</ns1:name>
   <ns2:typwp>14.3</ns2:typwp>
   <ns2:typfk>41.7</ns2:typfk>
   <ns2:typbfm>50.0</ns2:typbfm>
   <ns2:typkf>190.0</ns2:typkf>
   <ns2:typbf0>0.75</ns2:typbf0>
  </ns2:SoilLayer>
 </ns2:soilLayerMember>
 <ns2:soilLayerMember>
  <ns2:SoilLayer ns1:fid="SoilLayer_S15">
   <ns1:name>S15</ns1:name>
   <ns2:typwp>24.6</ns2:typwp>
   <ns2:typfk>55.1</ns2:typfk>
   <ns2:typbfm>68.7</ns2:typbfm>
   <ns2:typkf>346.0</ns2:typkf>
   <ns2:typbf0>0.75</ns2:typbf0>
  </ns2:SoilLayer>
 </ns2:soilLayerMember>
 <ns2:soilLayerMember>
  <ns2:SoilLayer ns1:fid="SoilLayer_S16">
   <ns1:name>S16</ns1:name>
   <ns2:typwp>17.4</ns2:typwp>
   <ns2:typfk>45.9</ns2:typfk>
   <ns2:typbfm>56.3</ns2:typbfm>
   <ns2:typkf>274.0</ns2:typkf>
   <ns2:typbf0>0.75</ns2:typbf0>
  </ns2:SoilLayer>
 </ns2:soilLayerMember>
 <ns2:soilLayerMember>
  <ns2:SoilLayer ns1:fid="SoilLayer_Xs">
   <ns1:name>Xs</ns1:name>
   <ns2:typwp>4.0</ns2:typwp>
   <ns2:typfk>12.0</ns2:typfk>
   <ns2:typbfm>50.0</ns2:typbfm>
   <ns2:typkf>9290.0</ns2:typkf>
   <ns2:typbf0>0.75</ns2:typbf0>
  </ns2:SoilLayer>
 </ns2:soilLayerMember>
 <ns2:soilLayerMember>
  <ns2:SoilLayer ns1:fid="SoilLayer_Sl3ld2">
   <ns1:name>Sl3ld2</ns1:name>
   <ns2:typwp>9.0</ns2:typwp>
   <ns2:typfk>27.0</ns2:typfk>
   <ns2:typbfm>42.0</ns2:typbfm>
   <ns2:typkf>470.0</ns2:typkf>
   <ns2:typbf0>0.75</ns2:typbf0>
  </ns2:SoilLayer>
 </ns2:soilLayerMember>
 <ns2:soilLayerMember>
  <ns2:SoilLayer ns1:fid="SoilLayer_Sl3ld3">
   <ns1:name>Sl3ld3</ns1:name>
   <ns2:typwp>8.0</ns2:typwp>
   <ns2:typfk>25.0</ns2:typfk>
   <ns2:typbfm>35.0</ns2:typbfm>
   <ns2:typkf>330.0</ns2:typkf>
   <ns2:typbf0>0.75</ns2:typbf0>
  </ns2:SoilLayer>
 </ns2:soilLayerMember>
 <ns2:soiltypeMember>
  <ns2:Soiltype ns1:fid="Soiltype_mrsp">
   <ns1:description>Standard Mulden Rigolen Element</ns1:description>
   <ns1:name>mrsp</ns1:name>
   <ns2:soilLayerParameterMember>
    <ns2:SoilLayerParameter ns1:fid="SoilLayerParameter1">
     <ns2:soilLayerLink xlink:href="#SoilLayer_mulde"/>
     <ns2:xtief>4.0</ns2:xtief>
     <ns2:xret>false</ns2:xret>
    </ns2:SoilLayerParameter>
   </ns2:soilLayerParameterMember>
   <ns2:soilLayerParameterMember>
    <ns2:SoilLayerParameter ns1:fid="SoilLayerParameter2">
     <ns2:soilLayerLink xlink:href="#SoilLayer_Sl4ld3"/>
     <ns2:xtief>3.0</ns2:xtief>
     <ns2:xret>false</ns2:xret>
    </ns2:SoilLayerParameter>
   </ns2:soilLayerParameterMember>
   <ns2:soilLayerParameterMember>
    <ns2:SoilLayerParameter ns1:fid="SoilLayerParameter3">
     <ns2:soilLayerLink xlink:href="#SoilLayer_mSfsld2"/>
     <ns2:xtief>6.0</ns2:xtief>
     <ns2:xret>false</ns2:xret>
    </ns2:SoilLayerParameter>
   </ns2:soilLayerParameterMember>
   <ns2:soilLayerParameterMember>
    <ns2:SoilLayerParameter ns1:fid="SoilLayerParameter4">
     <ns2:soilLayerLink xlink:href="#SoilLayer_mSfsld2"/>
     <ns2:xtief>2.0</ns2:xtief>
     <ns2:xret>false</ns2:xret>
    </ns2:SoilLayerParameter>
   </ns2:soilLayerParameterMember>
  </ns2:Soiltype>
 </ns2:soiltypeMember>
 <ns2:soiltypeMember>
  <ns2:Soiltype ns1:fid="Soiltype_3S227S233">
   <ns1:description>Tarpenbek</ns1:description>
   <ns1:name>3S227S233</ns1:name>
   <ns2:soilLayerParameterMember>
    <ns2:SoilLayerParameter ns1:fid="SoilLayerParameter1">
     <ns2:soilLayerLink xlink:href="#SoilLayer_S22"/>
     <ns2:xtief>3.0</ns2:xtief>
     <ns2:xret>true</ns2:xret>
    </ns2:SoilLayerParameter>
   </ns2:soilLayerParameterMember>
   <ns2:soilLayerParameterMember>
    <ns2:SoilLayerParameter ns1:fid="SoilLayerParameter2">
     <ns2:soilLayerLink xlink:href="#SoilLayer_S23"/>
     <ns2:xtief>7.0</ns2:xtief>
     <ns2:xret>true</ns2:xret>
    </ns2:SoilLayerParameter>
   </ns2:soilLayerParameterMember>
   <ns2:soilLayerParameterMember>
    <ns2:SoilLayerParameter ns1:fid="SoilLayerParameter3">
     <ns2:soilLayerLink xlink:href="#SoilLayer_mSfsld3"/>
     <ns2:xtief>30.0</ns2:xtief>
     <ns2:xret>false</ns2:xret>
    </ns2:SoilLayerParameter>
   </ns2:soilLayerParameterMember>
  </ns2:Soiltype>
 </ns2:soiltypeMember>
 <ns2:soiltypeMember>
  <ns2:Soiltype ns1:fid="Soiltype_3S267S273">
   <ns1:description>Tarpenbek</ns1:description>
   <ns1:name>3S267S273</ns1:name>
   <ns2:soilLayerParameterMember>
    <ns2:SoilLayerParameter ns1:fid="SoilLayerParameter4">
     <ns2:soilLayerLink xlink:href="#SoilLayer_S26"/>
     <ns2:xtief>3.0</ns2:xtief>
     <ns2:xret>true</ns2:xret>
    </ns2:SoilLayerParameter>
   </ns2:soilLayerParameterMember>
   <ns2:soilLayerParameterMember>
    <ns2:SoilLayerParameter ns1:fid="SoilLayerParameter5">
     <ns2:soilLayerLink xlink:href="#SoilLayer_S27"/>
     <ns2:xtief>7.0</ns2:xtief>
     <ns2:xret>true</ns2:xret>
    </ns2:SoilLayerParameter>
   </ns2:soilLayerParameterMember>
   <ns2:soilLayerParameterMember>
    <ns2:SoilLayerParameter ns1:fid="SoilLayerParameter6">
     <ns2:soilLayerLink xlink:href="#SoilLayer_mSfsld3"/>
     <ns2:xtief>30.0</ns2:xtief>
     <ns2:xret>false</ns2:xret>
    </ns2:SoilLayerParameter>
   </ns2:soilLayerParameterMember>
  </ns2:Soiltype>
 </ns2:soiltypeMember>
 <ns2:soiltypeMember>
  <ns2:Soiltype ns1:fid="Soiltype_3S307S311a">
   <ns1:description>Tarpenbek</ns1:description>
   <ns1:name>3S307S311a</ns1:name>
   <ns2:soilLayerParameterMember>
    <ns2:SoilLayerParameter ns1:fid="SoilLayerParameter7">
     <ns2:soilLayerLink xlink:href="#SoilLayer_S30"/>
     <ns2:xtief>3.0</ns2:xtief>
     <ns2:xret>true</ns2:xret>
    </ns2:SoilLayerParameter>
   </ns2:soilLayerParameterMember>
   <ns2:soilLayerParameterMember>
    <ns2:SoilLayerParameter ns1:fid="SoilLayerParameter8">
     <ns2:soilLayerLink xlink:href="#SoilLayer_S31"/>
     <ns2:xtief>7.0</ns2:xtief>
     <ns2:xret>true</ns2:xret>
    </ns2:SoilLayerParameter>
   </ns2:soilLayerParameterMember>
   <ns2:soilLayerParameterMember>
    <ns2:SoilLayerParameter ns1:fid="SoilLayerParameter9">
     <ns2:soilLayerLink xlink:href="#SoilLayer_mSgsld2"/>
     <ns2:xtief>5.0</ns2:xtief>
     <ns2:xret>false</ns2:xret>
    </ns2:SoilLayerParameter>
   </ns2:soilLayerParameterMember>
  </ns2:Soiltype>
 </ns2:soiltypeMember>
 <ns2:soiltypeMember>
  <ns2:Soiltype ns1:fid="Soiltype_5Hn5Hn1a">
   <ns1:description>Tarpenbek, Falkengraben  Torf über Prof. 1a</ns1:description>
   <ns1:name>5Hn5Hn1a</ns1:name>
   <ns2:soilLayerParameterMember>
    <ns2:SoilLayerParameter ns1:fid="SoilLayerParameter10">
     <ns2:soilLayerLink xlink:href="#SoilLayer_Hn"/>
     <ns2:xtief>5.0</ns2:xtief>
     <ns2:xret>true</ns2:xret>
    </ns2:SoilLayerParameter>
   </ns2:soilLayerParameterMember>
   <ns2:soilLayerParameterMember>
    <ns2:SoilLayerParameter ns1:fid="SoilLayerParameter11">
     <ns2:soilLayerLink xlink:href="#SoilLayer_Hn"/>
     <ns2:xtief>5.0</ns2:xtief>
     <ns2:xret>true</ns2:xret>
    </ns2:SoilLayerParameter>
   </ns2:soilLayerParameterMember>
   <ns2:soilLayerParameterMember>
    <ns2:SoilLayerParameter ns1:fid="SoilLayerParameter12">
     <ns2:soilLayerLink xlink:href="#SoilLayer_mSgsld2"/>
     <ns2:xtief>5.0</ns2:xtief>
     <ns2:xret>false</ns2:xret>
    </ns2:SoilLayerParameter>
   </ns2:soilLayerParameterMember>
  </ns2:Soiltype>
 </ns2:soiltypeMember>
 <ns2:soiltypeMember>
  <ns2:Soiltype ns1:fid="Soiltype_5Hn5Hn2a">
   <ns1:description>Tarpenbek</ns1:description>
   <ns1:name>5Hn5Hn2a</ns1:name>
   <ns2:soilLayerParameterMember>
    <ns2:SoilLayerParameter ns1:fid="SoilLayerParameter13">
     <ns2:soilLayerLink xlink:href="#SoilLayer_Hn"/>
     <ns2:xtief>5.0</ns2:xtief>
     <ns2:xret>true</ns2:xret>
    </ns2:SoilLayerParameter>
   </ns2:soilLayerParameterMember>
   <ns2:soilLayerParameterMember>
    <ns2:SoilLayerParameter ns1:fid="SoilLayerParameter14">
     <ns2:soilLayerLink xlink:href="#SoilLayer_Hn"/>
     <ns2:xtief>5.0</ns2:xtief>
     <ns2:xret>true</ns2:xret>
    </ns2:SoilLayerParameter>
   </ns2:soilLayerParameterMember>
   <ns2:soilLayerParameterMember>
    <ns2:SoilLayerParameter ns1:fid="SoilLayerParameter15">
     <ns2:soilLayerLink xlink:href="#SoilLayer_mSfsld2"/>
     <ns2:xtief>5.0</ns2:xtief>
     <ns2:xret>false</ns2:xret>
    </ns2:SoilLayerParameter>
   </ns2:soilLayerParameterMember>
  </ns2:Soiltype>
 </ns2:soiltypeMember>
 <ns2:soiltypeMember>
  <ns2:Soiltype ns1:fid="Soiltype_5Hn5Hn3">
   <ns1:description>Tarpenbek</ns1:description>
   <ns1:name>5Hn5Hn3</ns1:name>
   <ns2:soilLayerParameterMember>
    <ns2:SoilLayerParameter ns1:fid="SoilLayerParameter16">
     <ns2:soilLayerLink xlink:href="#SoilLayer_Hn"/>
     <ns2:xtief>5.0</ns2:xtief>
     <ns2:xret>true</ns2:xret>
    </ns2:SoilLayerParameter>
   </ns2:soilLayerParameterMember>
   <ns2:soilLayerParameterMember>
    <ns2:SoilLayerParameter ns1:fid="SoilLayerParameter17">
     <ns2:soilLayerLink xlink:href="#SoilLayer_Hn"/>
     <ns2:xtief>5.0</ns2:xtief>
     <ns2:xret>true</ns2:xret>
    </ns2:SoilLayerParameter>
   </ns2:soilLayerParameterMember>
   <ns2:soilLayerParameterMember>
    <ns2:SoilLayerParameter ns1:fid="SoilLayerParameter18">
     <ns2:soilLayerLink xlink:href="#SoilLayer_mSfsld3"/>
     <ns2:xtief>30.0</ns2:xtief>
     <ns2:xret>false</ns2:xret>
    </ns2:SoilLayerParameter>
   </ns2:soilLayerParameterMember>
  </ns2:Soiltype>
 </ns2:soiltypeMember>
 <ns2:soiltypeMember>
  <ns2:Soiltype ns1:fid="Soiltype_5Ls25Ls21a">
   <ns1:description>Tarpenbek, Falkengraben  Schwach sandiger Lehm über Prof. 1a</ns1:description>
   <ns1:name>5Ls25Ls21a</ns1:name>
   <ns2:soilLayerParameterMember>
    <ns2:SoilLayerParameter ns1:fid="SoilLayerParameter19">
     <ns2:soilLayerLink xlink:href="#SoilLayer_Ls2"/>
     <ns2:xtief>5.0</ns2:xtief>
     <ns2:xret>true</ns2:xret>
    </ns2:SoilLayerParameter>
   </ns2:soilLayerParameterMember>
   <ns2:soilLayerParameterMember>
    <ns2:SoilLayerParameter ns1:fid="SoilLayerParameter20">
     <ns2:soilLayerLink xlink:href="#SoilLayer_Ls2"/>
     <ns2:xtief>5.0</ns2:xtief>
     <ns2:xret>true</ns2:xret>
    </ns2:SoilLayerParameter>
   </ns2:soilLayerParameterMember>
   <ns2:soilLayerParameterMember>
    <ns2:SoilLayerParameter ns1:fid="SoilLayerParameter21">
     <ns2:soilLayerLink xlink:href="#SoilLayer_mSgsld2"/>
     <ns2:xtief>5.0</ns2:xtief>
     <ns2:xret>false</ns2:xret>
    </ns2:SoilLayerParameter>
   </ns2:soilLayerParameterMember>
  </ns2:Soiltype>
 </ns2:soiltypeMember>
 <ns2:soiltypeMember>
  <ns2:Soiltype ns1:fid="Soiltype_5Ls25Ls22a">
   <ns1:description>Tarpenbek</ns1:description>
   <ns1:name>5Ls25Ls22a</ns1:name>
   <ns2:soilLayerParameterMember>
    <ns2:SoilLayerParameter ns1:fid="SoilLayerParameter22">
     <ns2:soilLayerLink xlink:href="#SoilLayer_Ls2"/>
     <ns2:xtief>5.0</ns2:xtief>
     <ns2:xret>true</ns2:xret>
    </ns2:SoilLayerParameter>
   </ns2:soilLayerParameterMember>
   <ns2:soilLayerParameterMember>
    <ns2:SoilLayerParameter ns1:fid="SoilLayerParameter23">
     <ns2:soilLayerLink xlink:href="#SoilLayer_Ls2"/>
     <ns2:xtief>5.0</ns2:xtief>
     <ns2:xret>true</ns2:xret>
    </ns2:SoilLayerParameter>
   </ns2:soilLayerParameterMember>
   <ns2:soilLayerParameterMember>
    <ns2:SoilLayerParameter ns1:fid="SoilLayerParameter24">
     <ns2:soilLayerLink xlink:href="#SoilLayer_mSfsld2"/>
     <ns2:xtief>5.0</ns2:xtief>
     <ns2:xret>false</ns2:xret>
    </ns2:SoilLayerParameter>
   </ns2:soilLayerParameterMember>
  </ns2:Soiltype>
 </ns2:soiltypeMember>
 <ns2:soiltypeMember>
  <ns2:Soiltype ns1:fid="Soiltype_5Ls25Ls23">
   <ns1:description>Tarpenbek</ns1:description>
   <ns1:name>5Ls25Ls23</ns1:name>
   <ns2:soilLayerParameterMember>
    <ns2:SoilLayerParameter ns1:fid="SoilLayerParameter25">
     <ns2:soilLayerLink xlink:href="#SoilLayer_Ls2"/>
     <ns2:xtief>5.0</ns2:xtief>
     <ns2:xret>true</ns2:xret>
    </ns2:SoilLayerParameter>
   </ns2:soilLayerParameterMember>
   <ns2:soilLayerParameterMember>
    <ns2:SoilLayerParameter ns1:fid="SoilLayerParameter26">
     <ns2:soilLayerLink xlink:href="#SoilLayer_Ls2"/>
     <ns2:xtief>5.0</ns2:xtief>
     <ns2:xret>true</ns2:xret>
    </ns2:SoilLayerParameter>
   </ns2:soilLayerParameterMember>
   <ns2:soilLayerParameterMember>
    <ns2:SoilLayerParameter ns1:fid="SoilLayerParameter27">
     <ns2:soilLayerLink xlink:href="#SoilLayer_mSfsld3"/>
     <ns2:xtief>30.0</ns2:xtief>
     <ns2:xret>false</ns2:xret>
    </ns2:SoilLayerParameter>
   </ns2:soilLayerParameterMember>
  </ns2:Soiltype>
 </ns2:soiltypeMember>
 <ns2:soiltypeMember>
  <ns2:Soiltype ns1:fid="Soiltype_5mS5Ls21a">
   <ns1:description>Tarpenbek</ns1:description>
   <ns1:name>5mS5Ls21a</ns1:name>
   <ns2:soilLayerParameterMember>
    <ns2:SoilLayerParameter ns1:fid="SoilLayerParameter28">
     <ns2:soilLayerLink xlink:href="#SoilLayer_mS"/>
     <ns2:xtief>5.0</ns2:xtief>
     <ns2:xret>true</ns2:xret>
    </ns2:SoilLayerParameter>
   </ns2:soilLayerParameterMember>
   <ns2:soilLayerParameterMember>
    <ns2:SoilLayerParameter ns1:fid="SoilLayerParameter29">
     <ns2:soilLayerLink xlink:href="#SoilLayer_Ls2"/>
     <ns2:xtief>5.0</ns2:xtief>
     <ns2:xret>true</ns2:xret>
    </ns2:SoilLayerParameter>
   </ns2:soilLayerParameterMember>
   <ns2:soilLayerParameterMember>
    <ns2:SoilLayerParameter ns1:fid="SoilLayerParameter30">
     <ns2:soilLayerLink xlink:href="#SoilLayer_mSgsld2"/>
     <ns2:xtief>5.0</ns2:xtief>
     <ns2:xret>false</ns2:xret>
    </ns2:SoilLayerParameter>
   </ns2:soilLayerParameterMember>
  </ns2:Soiltype>
 </ns2:soiltypeMember>
 <ns2:soiltypeMember>
  <ns2:Soiltype ns1:fid="Soiltype_5mS5Ls22a">
   <ns1:description>Tarpenbek</ns1:description>
   <ns1:name>5mS5Ls22a</ns1:name>
   <ns2:soilLayerParameterMember>
    <ns2:SoilLayerParameter ns1:fid="SoilLayerParameter31">
     <ns2:soilLayerLink xlink:href="#SoilLayer_mS"/>
     <ns2:xtief>5.0</ns2:xtief>
     <ns2:xret>true</ns2:xret>
    </ns2:SoilLayerParameter>
   </ns2:soilLayerParameterMember>
   <ns2:soilLayerParameterMember>
    <ns2:SoilLayerParameter ns1:fid="SoilLayerParameter32">
     <ns2:soilLayerLink xlink:href="#SoilLayer_Ls2"/>
     <ns2:xtief>5.0</ns2:xtief>
     <ns2:xret>true</ns2:xret>
    </ns2:SoilLayerParameter>
   </ns2:soilLayerParameterMember>
   <ns2:soilLayerParameterMember>
    <ns2:SoilLayerParameter ns1:fid="SoilLayerParameter33">
     <ns2:soilLayerLink xlink:href="#SoilLayer_mSfsld2"/>
     <ns2:xtief>5.0</ns2:xtief>
     <ns2:xret>false</ns2:xret>
    </ns2:SoilLayerParameter>
   </ns2:soilLayerParameterMember>
  </ns2:Soiltype>
 </ns2:soiltypeMember>
 <ns2:soiltypeMember>
  <ns2:Soiltype ns1:fid="Soiltype_5mS5Ls23">
   <ns1:description>Tarpenbek</ns1:description>
   <ns1:name>5mS5Ls23</ns1:name>
   <ns2:soilLayerParameterMember>
    <ns2:SoilLayerParameter ns1:fid="SoilLayerParameter34">
     <ns2:soilLayerLink xlink:href="#SoilLayer_mS"/>
     <ns2:xtief>5.0</ns2:xtief>
     <ns2:xret>true</ns2:xret>
    </ns2:SoilLayerParameter>
   </ns2:soilLayerParameterMember>
   <ns2:soilLayerParameterMember>
    <ns2:SoilLayerParameter ns1:fid="SoilLayerParameter35">
     <ns2:soilLayerLink xlink:href="#SoilLayer_Ls2"/>
     <ns2:xtief>5.0</ns2:xtief>
     <ns2:xret>true</ns2:xret>
    </ns2:SoilLayerParameter>
   </ns2:soilLayerParameterMember>
   <ns2:soilLayerParameterMember>
    <ns2:SoilLayerParameter ns1:fid="SoilLayerParameter36">
     <ns2:soilLayerLink xlink:href="#SoilLayer_mSfsld3"/>
     <ns2:xtief>30.0</ns2:xtief>
     <ns2:xret>false</ns2:xret>
    </ns2:SoilLayerParameter>
   </ns2:soilLayerParameterMember>
  </ns2:Soiltype>
 </ns2:soiltypeMember>
 <ns2:soiltypeMember>
  <ns2:Soiltype ns1:fid="Soiltype_5mS5mS1a">
   <ns1:description>Tarpenbek, Falkengraben  Mittelsand über Prof. 1a</ns1:description>
   <ns1:name>5mS5mS1a</ns1:name>
   <ns2:soilLayerParameterMember>
    <ns2:SoilLayerParameter ns1:fid="SoilLayerParameter37">
     <ns2:soilLayerLink xlink:href="#SoilLayer_mS"/>
     <ns2:xtief>5.0</ns2:xtief>
     <ns2:xret>true</ns2:xret>
    </ns2:SoilLayerParameter>
   </ns2:soilLayerParameterMember>
   <ns2:soilLayerParameterMember>
    <ns2:SoilLayerParameter ns1:fid="SoilLayerParameter38">
     <ns2:soilLayerLink xlink:href="#SoilLayer_mS"/>
     <ns2:xtief>5.0</ns2:xtief>
     <ns2:xret>true</ns2:xret>
    </ns2:SoilLayerParameter>
   </ns2:soilLayerParameterMember>
   <ns2:soilLayerParameterMember>
    <ns2:SoilLayerParameter ns1:fid="SoilLayerParameter39">
     <ns2:soilLayerLink xlink:href="#SoilLayer_mSgsld2"/>
     <ns2:xtief>5.0</ns2:xtief>
     <ns2:xret>false</ns2:xret>
    </ns2:SoilLayerParameter>
   </ns2:soilLayerParameterMember>
  </ns2:Soiltype>
 </ns2:soiltypeMember>
 <ns2:soiltypeMember>
  <ns2:Soiltype ns1:fid="Soiltype_5mS5mS2a">
   <ns1:description>Tarpenbek, Falkengraben  Mittelsand über Prof. 2a</ns1:description>
   <ns1:name>5mS5mS2a</ns1:name>
   <ns2:soilLayerParameterMember>
    <ns2:SoilLayerParameter ns1:fid="SoilLayerParameter40">
     <ns2:soilLayerLink xlink:href="#SoilLayer_mS"/>
     <ns2:xtief>5.0</ns2:xtief>
     <ns2:xret>true</ns2:xret>
    </ns2:SoilLayerParameter>
   </ns2:soilLayerParameterMember>
   <ns2:soilLayerParameterMember>
    <ns2:SoilLayerParameter ns1:fid="SoilLayerParameter41">
     <ns2:soilLayerLink xlink:href="#SoilLayer_mS"/>
     <ns2:xtief>5.0</ns2:xtief>
     <ns2:xret>true</ns2:xret>
    </ns2:SoilLayerParameter>
   </ns2:soilLayerParameterMember>
   <ns2:soilLayerParameterMember>
    <ns2:SoilLayerParameter ns1:fid="SoilLayerParameter42">
     <ns2:soilLayerLink xlink:href="#SoilLayer_mSfsld2"/>
     <ns2:xtief>5.0</ns2:xtief>
     <ns2:xret>false</ns2:xret>
    </ns2:SoilLayerParameter>
   </ns2:soilLayerParameterMember>
  </ns2:Soiltype>
 </ns2:soiltypeMember>
 <ns2:soiltypeMember>
  <ns2:Soiltype ns1:fid="Soiltype_5mS5mS3">
   <ns1:description>Tarpenbek, Falkengraben  Mittelsand über Prof. 3</ns1:description>
   <ns1:name>5mS5mS3</ns1:name>
   <ns2:soilLayerParameterMember>
    <ns2:SoilLayerParameter ns1:fid="SoilLayerParameter43">
     <ns2:soilLayerLink xlink:href="#SoilLayer_mS"/>
     <ns2:xtief>5.0</ns2:xtief>
     <ns2:xret>true</ns2:xret>
    </ns2:SoilLayerParameter>
   </ns2:soilLayerParameterMember>
   <ns2:soilLayerParameterMember>
    <ns2:SoilLayerParameter ns1:fid="SoilLayerParameter44">
     <ns2:soilLayerLink xlink:href="#SoilLayer_mS"/>
     <ns2:xtief>5.0</ns2:xtief>
     <ns2:xret>true</ns2:xret>
    </ns2:SoilLayerParameter>
   </ns2:soilLayerParameterMember>
   <ns2:soilLayerParameterMember>
    <ns2:SoilLayerParameter ns1:fid="SoilLayerParameter45">
     <ns2:soilLayerLink xlink:href="#SoilLayer_mSfsld3"/>
     <ns2:xtief>30.0</ns2:xtief>
     <ns2:xret>false</ns2:xret>
    </ns2:SoilLayerParameter>
   </ns2:soilLayerParameterMember>
  </ns2:Soiltype>
 </ns2:soiltypeMember>
 <ns2:soiltypeMember>
  <ns2:Soiltype ns1:fid="Soiltype_5Tu5Tu2a">
   <ns1:description>Tarpenbek</ns1:description>
   <ns1:name>5Tu5Tu2a</ns1:name>
   <ns2:soilLayerParameterMember>
    <ns2:SoilLayerParameter ns1:fid="SoilLayerParameter46">
     <ns2:soilLayerLink xlink:href="#SoilLayer_Tu"/>
     <ns2:xtief>5.0</ns2:xtief>
     <ns2:xret>true</ns2:xret>
    </ns2:SoilLayerParameter>
   </ns2:soilLayerParameterMember>
   <ns2:soilLayerParameterMember>
    <ns2:SoilLayerParameter ns1:fid="SoilLayerParameter47">
     <ns2:soilLayerLink xlink:href="#SoilLayer_Tu"/>
     <ns2:xtief>5.0</ns2:xtief>
     <ns2:xret>true</ns2:xret>
    </ns2:SoilLayerParameter>
   </ns2:soilLayerParameterMember>
   <ns2:soilLayerParameterMember>
    <ns2:SoilLayerParameter ns1:fid="SoilLayerParameter48">
     <ns2:soilLayerLink xlink:href="#SoilLayer_mSfsld2"/>
     <ns2:xtief>5.0</ns2:xtief>
     <ns2:xret>false</ns2:xret>
    </ns2:SoilLayerParameter>
   </ns2:soilLayerParameterMember>
  </ns2:Soiltype>
 </ns2:soiltypeMember>
 <ns2:soiltypeMember>
  <ns2:Soiltype ns1:fid="Soiltype_5Tu5Tu3">
   <ns1:description>Tarpenbek</ns1:description>
   <ns1:name>5Tu5Tu3</ns1:name>
   <ns2:soilLayerParameterMember>
    <ns2:SoilLayerParameter ns1:fid="SoilLayerParameter49">
     <ns2:soilLayerLink xlink:href="#SoilLayer_Tu"/>
     <ns2:xtief>5.0</ns2:xtief>
     <ns2:xret>true</ns2:xret>
    </ns2:SoilLayerParameter>
   </ns2:soilLayerParameterMember>
   <ns2:soilLayerParameterMember>
    <ns2:SoilLayerParameter ns1:fid="SoilLayerParameter50">
     <ns2:soilLayerLink xlink:href="#SoilLayer_Tu"/>
     <ns2:xtief>5.0</ns2:xtief>
     <ns2:xret>true</ns2:xret>
    </ns2:SoilLayerParameter>
   </ns2:soilLayerParameterMember>
   <ns2:soilLayerParameterMember>
    <ns2:SoilLayerParameter ns1:fid="SoilLayerParameter51">
     <ns2:soilLayerLink xlink:href="#SoilLayer_mSfsld3"/>
     <ns2:xtief>30.0</ns2:xtief>
     <ns2:xret>false</ns2:xret>
    </ns2:SoilLayerParameter>
   </ns2:soilLayerParameterMember>
  </ns2:Soiltype>
 </ns2:soiltypeMember>
 <ns2:soiltypeMember>
  <ns2:Soiltype ns1:fid="Soiltype_5Ut5Hn1a">
   <ns1:description>Tarpenbek</ns1:description>
   <ns1:name>5Ut5Hn1a</ns1:name>
   <ns2:soilLayerParameterMember>
    <ns2:SoilLayerParameter ns1:fid="SoilLayerParameter52">
     <ns2:soilLayerLink xlink:href="#SoilLayer_Ut"/>
     <ns2:xtief>5.0</ns2:xtief>
     <ns2:xret>true</ns2:xret>
    </ns2:SoilLayerParameter>
   </ns2:soilLayerParameterMember>
   <ns2:soilLayerParameterMember>
    <ns2:SoilLayerParameter ns1:fid="SoilLayerParameter53">
     <ns2:soilLayerLink xlink:href="#SoilLayer_Hn"/>
     <ns2:xtief>5.0</ns2:xtief>
     <ns2:xret>true</ns2:xret>
    </ns2:SoilLayerParameter>
   </ns2:soilLayerParameterMember>
   <ns2:soilLayerParameterMember>
    <ns2:SoilLayerParameter ns1:fid="SoilLayerParameter54">
     <ns2:soilLayerLink xlink:href="#SoilLayer_mSgsld2"/>
     <ns2:xtief>5.0</ns2:xtief>
     <ns2:xret>false</ns2:xret>
    </ns2:SoilLayerParameter>
   </ns2:soilLayerParameterMember>
  </ns2:Soiltype>
 </ns2:soiltypeMember>
 <ns2:soiltypeMember>
  <ns2:Soiltype ns1:fid="Soiltype_5Ut5Hn2a">
   <ns1:description>Tarpenbek</ns1:description>
   <ns1:name>5Ut5Hn2a</ns1:name>
   <ns2:soilLayerParameterMember>
    <ns2:SoilLayerParameter ns1:fid="SoilLayerParameter55">
     <ns2:soilLayerLink xlink:href="#SoilLayer_Ut"/>
     <ns2:xtief>5.0</ns2:xtief>
     <ns2:xret>true</ns2:xret>
    </ns2:SoilLayerParameter>
   </ns2:soilLayerParameterMember>
   <ns2:soilLayerParameterMember>
    <ns2:SoilLayerParameter ns1:fid="SoilLayerParameter56">
     <ns2:soilLayerLink xlink:href="#SoilLayer_Hn"/>
     <ns2:xtief>5.0</ns2:xtief>
     <ns2:xret>true</ns2:xret>
    </ns2:SoilLayerParameter>
   </ns2:soilLayerParameterMember>
   <ns2:soilLayerParameterMember>
    <ns2:SoilLayerParameter ns1:fid="SoilLayerParameter57">
     <ns2:soilLayerLink xlink:href="#SoilLayer_mSfsld2"/>
     <ns2:xtief>5.0</ns2:xtief>
     <ns2:xret>false</ns2:xret>
    </ns2:SoilLayerParameter>
   </ns2:soilLayerParameterMember>
  </ns2:Soiltype>
 </ns2:soiltypeMember>
 <ns2:soiltypeMember>
  <ns2:Soiltype ns1:fid="Soiltype_5Ut5Hn3">
   <ns1:description>Tarpenbek</ns1:description>
   <ns1:name>5Ut5Hn3</ns1:name>
   <ns2:soilLayerParameterMember>
    <ns2:SoilLayerParameter ns1:fid="SoilLayerParameter58">
     <ns2:soilLayerLink xlink:href="#SoilLayer_Ut"/>
     <ns2:xtief>5.0</ns2:xtief>
     <ns2:xret>true</ns2:xret>
    </ns2:SoilLayerParameter>
   </ns2:soilLayerParameterMember>
   <ns2:soilLayerParameterMember>
    <ns2:SoilLayerParameter ns1:fid="SoilLayerParameter59">
     <ns2:soilLayerLink xlink:href="#SoilLayer_Hn"/>
     <ns2:xtief>5.0</ns2:xtief>
     <ns2:xret>true</ns2:xret>
    </ns2:SoilLayerParameter>
   </ns2:soilLayerParameterMember>
   <ns2:soilLayerParameterMember>
    <ns2:SoilLayerParameter ns1:fid="SoilLayerParameter60">
     <ns2:soilLayerLink xlink:href="#SoilLayer_mSfsld3"/>
     <ns2:xtief>30.0</ns2:xtief>
     <ns2:xret>false</ns2:xret>
    </ns2:SoilLayerParameter>
   </ns2:soilLayerParameterMember>
  </ns2:Soiltype>
 </ns2:soiltypeMember>
 <ns2:soiltypeMember>
  <ns2:Soiltype ns1:fid="Soiltype_mS-Sl2_1">
   <ns1:description>Kollau Feinsand. Mittelsand-schwach lehm. Sand ueber Prof.1</ns1:description>
   <ns1:name>mS-Sl2_1</ns1:name>
   <ns2:soilLayerParameterMember>
    <ns2:SoilLayerParameter ns1:fid="SoilLayerParameter61">
     <ns2:soilLayerLink xlink:href="#SoilLayer_mS-Sl22"/>
     <ns2:xtief>8.0</ns2:xtief>
     <ns2:xret>true</ns2:xret>
    </ns2:SoilLayerParameter>
   </ns2:soilLayerParameterMember>
   <ns2:soilLayerParameterMember>
    <ns2:SoilLayerParameter ns1:fid="SoilLayerParameter62">
     <ns2:soilLayerLink xlink:href="#SoilLayer_mSgsld2"/>
     <ns2:xtief>2.0</ns2:xtief>
     <ns2:xret>true</ns2:xret>
    </ns2:SoilLayerParameter>
   </ns2:soilLayerParameterMember>
   <ns2:soilLayerParameterMember>
    <ns2:SoilLayerParameter ns1:fid="SoilLayerParameter63">
     <ns2:soilLayerLink xlink:href="#SoilLayer_mSgsld2"/>
     <ns2:xtief>2.0</ns2:xtief>
     <ns2:xret>true</ns2:xret>
    </ns2:SoilLayerParameter>
   </ns2:soilLayerParameterMember>
   <ns2:soilLayerParameterMember>
    <ns2:SoilLayerParameter ns1:fid="SoilLayerParameter64">
     <ns2:soilLayerLink xlink:href="#SoilLayer_mSgsld2"/>
     <ns2:xtief>1.0</ns2:xtief>
     <ns2:xret>true</ns2:xret>
    </ns2:SoilLayerParameter>
   </ns2:soilLayerParameterMember>
  </ns2:Soiltype>
 </ns2:soiltypeMember>
 <ns2:soiltypeMember>
  <ns2:Soiltype ns1:fid="Soiltype_Sl2-Ls3_1">
   <ns1:description>Kollau Schwach lehm. Sand- mittel sandiger Lehm ueber Prof.1</ns1:description>
   <ns1:name>Sl2-Ls3_1</ns1:name>
   <ns2:soilLayerParameterMember>
    <ns2:SoilLayerParameter ns1:fid="SoilLayerParameter65">
     <ns2:soilLayerLink xlink:href="#SoilLayer_Sl2Ls32"/>
     <ns2:xtief>8.0</ns2:xtief>
     <ns2:xret>true</ns2:xret>
    </ns2:SoilLayerParameter>
   </ns2:soilLayerParameterMember>
   <ns2:soilLayerParameterMember>
    <ns2:SoilLayerParameter ns1:fid="SoilLayerParameter66">
     <ns2:soilLayerLink xlink:href="#SoilLayer_mSgsld2"/>
     <ns2:xtief>2.0</ns2:xtief>
     <ns2:xret>true</ns2:xret>
    </ns2:SoilLayerParameter>
   </ns2:soilLayerParameterMember>
   <ns2:soilLayerParameterMember>
    <ns2:SoilLayerParameter ns1:fid="SoilLayerParameter67">
     <ns2:soilLayerLink xlink:href="#SoilLayer_mSgsld2"/>
     <ns2:xtief>2.0</ns2:xtief>
     <ns2:xret>true</ns2:xret>
    </ns2:SoilLayerParameter>
   </ns2:soilLayerParameterMember>
   <ns2:soilLayerParameterMember>
    <ns2:SoilLayerParameter ns1:fid="SoilLayerParameter68">
     <ns2:soilLayerLink xlink:href="#SoilLayer_mSgsld2"/>
     <ns2:xtief>1.0</ns2:xtief>
     <ns2:xret>true</ns2:xret>
    </ns2:SoilLayerParameter>
   </ns2:soilLayerParameterMember>
  </ns2:Soiltype>
 </ns2:soiltypeMember>
 <ns2:soiltypeMember>
  <ns2:Soiltype ns1:fid="Soiltype_Hn-mSfs_1">
   <ns1:description>Kollau Niedermoortorf-feinsandiger Mittelsand ueber Profil 1</ns1:description>
   <ns1:name>Hn-mSfs_1</ns1:name>
   <ns2:soilLayerParameterMember>
    <ns2:SoilLayerParameter ns1:fid="SoilLayerParameter69">
     <ns2:soilLayerLink xlink:href="#SoilLayer_Hn-mSfs"/>
     <ns2:xtief>8.0</ns2:xtief>
     <ns2:xret>true</ns2:xret>
    </ns2:SoilLayerParameter>
   </ns2:soilLayerParameterMember>
   <ns2:soilLayerParameterMember>
    <ns2:SoilLayerParameter ns1:fid="SoilLayerParameter70">
     <ns2:soilLayerLink xlink:href="#SoilLayer_mSgsld2"/>
     <ns2:xtief>2.0</ns2:xtief>
     <ns2:xret>true</ns2:xret>
    </ns2:SoilLayerParameter>
   </ns2:soilLayerParameterMember>
   <ns2:soilLayerParameterMember>
    <ns2:SoilLayerParameter ns1:fid="SoilLayerParameter71">
     <ns2:soilLayerLink xlink:href="#SoilLayer_mSgsld2"/>
     <ns2:xtief>2.0</ns2:xtief>
     <ns2:xret>true</ns2:xret>
    </ns2:SoilLayerParameter>
   </ns2:soilLayerParameterMember>
   <ns2:soilLayerParameterMember>
    <ns2:SoilLayerParameter ns1:fid="SoilLayerParameter72">
     <ns2:soilLayerLink xlink:href="#SoilLayer_mSgsld2"/>
     <ns2:xtief>1.0</ns2:xtief>
     <ns2:xret>true</ns2:xret>
    </ns2:SoilLayerParameter>
   </ns2:soilLayerParameterMember>
  </ns2:Soiltype>
 </ns2:soiltypeMember>
 <ns2:soiltypeMember>
  <ns2:Soiltype ns1:fid="Soiltype_Hnz4_1">
   <ns1:description>Kollau Niedermoortorf ueber Profil 1</ns1:description>
   <ns1:name>Hnz4_1</ns1:name>
   <ns2:soilLayerParameterMember>
    <ns2:SoilLayerParameter ns1:fid="SoilLayerParameter73">
     <ns2:soilLayerLink xlink:href="#SoilLayer_Hnz4SV3"/>
     <ns2:xtief>8.0</ns2:xtief>
     <ns2:xret>true</ns2:xret>
    </ns2:SoilLayerParameter>
   </ns2:soilLayerParameterMember>
   <ns2:soilLayerParameterMember>
    <ns2:SoilLayerParameter ns1:fid="SoilLayerParameter74">
     <ns2:soilLayerLink xlink:href="#SoilLayer_mSgsld2"/>
     <ns2:xtief>2.0</ns2:xtief>
     <ns2:xret>false</ns2:xret>
    </ns2:SoilLayerParameter>
   </ns2:soilLayerParameterMember>
   <ns2:soilLayerParameterMember>
    <ns2:SoilLayerParameter ns1:fid="SoilLayerParameter75">
     <ns2:soilLayerLink xlink:href="#SoilLayer_mSgsld2"/>
     <ns2:xtief>2.0</ns2:xtief>
     <ns2:xret>false</ns2:xret>
    </ns2:SoilLayerParameter>
   </ns2:soilLayerParameterMember>
   <ns2:soilLayerParameterMember>
    <ns2:SoilLayerParameter ns1:fid="SoilLayerParameter76">
     <ns2:soilLayerLink xlink:href="#SoilLayer_mSgsld2"/>
     <ns2:xtief>1.0</ns2:xtief>
     <ns2:xret>false</ns2:xret>
    </ns2:SoilLayerParameter>
   </ns2:soilLayerParameterMember>
  </ns2:Soiltype>
 </ns2:soiltypeMember>
 <ns2:soiltypeMember>
  <ns2:Soiltype ns1:fid="Soiltype_mS-Sl2_2">
   <ns1:description>Kollau  Feinsand. Mittelsand-schwach lehm. Sand ueber Prof.2</ns1:description>
   <ns1:name>mS-Sl2_2</ns1:name>
   <ns2:soilLayerParameterMember>
    <ns2:SoilLayerParameter ns1:fid="SoilLayerParameter77">
     <ns2:soilLayerLink xlink:href="#SoilLayer_mS-Sl22"/>
     <ns2:xtief>8.0</ns2:xtief>
     <ns2:xret>true</ns2:xret>
    </ns2:SoilLayerParameter>
   </ns2:soilLayerParameterMember>
   <ns2:soilLayerParameterMember>
    <ns2:SoilLayerParameter ns1:fid="SoilLayerParameter78">
     <ns2:soilLayerLink xlink:href="#SoilLayer_mSfsld2"/>
     <ns2:xtief>3.0</ns2:xtief>
     <ns2:xret>true</ns2:xret>
    </ns2:SoilLayerParameter>
   </ns2:soilLayerParameterMember>
   <ns2:soilLayerParameterMember>
    <ns2:SoilLayerParameter ns1:fid="SoilLayerParameter79">
     <ns2:soilLayerLink xlink:href="#SoilLayer_mSfsld2"/>
     <ns2:xtief>2.0</ns2:xtief>
     <ns2:xret>true</ns2:xret>
    </ns2:SoilLayerParameter>
   </ns2:soilLayerParameterMember>
   <ns2:soilLayerParameterMember>
    <ns2:SoilLayerParameter ns1:fid="SoilLayerParameter80">
     <ns2:soilLayerLink xlink:href="#SoilLayer_Ls4ld3"/>
     <ns2:xtief>5.0</ns2:xtief>
     <ns2:xret>false</ns2:xret>
    </ns2:SoilLayerParameter>
   </ns2:soilLayerParameterMember>
  </ns2:Soiltype>
 </ns2:soiltypeMember>
 <ns2:soiltypeMember>
  <ns2:Soiltype ns1:fid="Soiltype_Sl2_2">
   <ns1:description>Kollau  Schwach lehmiger Sand ueber Profil 2</ns1:description>
   <ns1:name>Sl2_2</ns1:name>
   <ns2:soilLayerParameterMember>
    <ns2:SoilLayerParameter ns1:fid="SoilLayerParameter81">
     <ns2:soilLayerLink xlink:href="#SoilLayer_Sl2ld2"/>
     <ns2:xtief>8.0</ns2:xtief>
     <ns2:xret>true</ns2:xret>
    </ns2:SoilLayerParameter>
   </ns2:soilLayerParameterMember>
   <ns2:soilLayerParameterMember>
    <ns2:SoilLayerParameter ns1:fid="SoilLayerParameter82">
     <ns2:soilLayerLink xlink:href="#SoilLayer_mSfsld2"/>
     <ns2:xtief>3.0</ns2:xtief>
     <ns2:xret>true</ns2:xret>
    </ns2:SoilLayerParameter>
   </ns2:soilLayerParameterMember>
   <ns2:soilLayerParameterMember>
    <ns2:SoilLayerParameter ns1:fid="SoilLayerParameter83">
     <ns2:soilLayerLink xlink:href="#SoilLayer_mSfsld2"/>
     <ns2:xtief>2.0</ns2:xtief>
     <ns2:xret>true</ns2:xret>
    </ns2:SoilLayerParameter>
   </ns2:soilLayerParameterMember>
   <ns2:soilLayerParameterMember>
    <ns2:SoilLayerParameter ns1:fid="SoilLayerParameter84">
     <ns2:soilLayerLink xlink:href="#SoilLayer_Ls4ld3"/>
     <ns2:xtief>5.0</ns2:xtief>
     <ns2:xret>false</ns2:xret>
    </ns2:SoilLayerParameter>
   </ns2:soilLayerParameterMember>
  </ns2:Soiltype>
 </ns2:soiltypeMember>
 <ns2:soiltypeMember>
  <ns2:Soiltype ns1:fid="Soiltype_Sl2-Ls3_2">
   <ns1:description>Kollau  Schwach lehm. Sand- mittel sandiger Lehm ueber Prof.2</ns1:description>
   <ns1:name>Sl2-Ls3_2</ns1:name>
   <ns2:soilLayerParameterMember>
    <ns2:SoilLayerParameter ns1:fid="SoilLayerParameter85">
     <ns2:soilLayerLink xlink:href="#SoilLayer_Sl2Ls32"/>
     <ns2:xtief>8.0</ns2:xtief>
     <ns2:xret>true</ns2:xret>
    </ns2:SoilLayerParameter>
   </ns2:soilLayerParameterMember>
   <ns2:soilLayerParameterMember>
    <ns2:SoilLayerParameter ns1:fid="SoilLayerParameter86">
     <ns2:soilLayerLink xlink:href="#SoilLayer_mSfsld2"/>
     <ns2:xtief>3.0</ns2:xtief>
     <ns2:xret>true</ns2:xret>
    </ns2:SoilLayerParameter>
   </ns2:soilLayerParameterMember>
   <ns2:soilLayerParameterMember>
    <ns2:SoilLayerParameter ns1:fid="SoilLayerParameter87">
     <ns2:soilLayerLink xlink:href="#SoilLayer_mSfsld2"/>
     <ns2:xtief>2.0</ns2:xtief>
     <ns2:xret>true</ns2:xret>
    </ns2:SoilLayerParameter>
   </ns2:soilLayerParameterMember>
   <ns2:soilLayerParameterMember>
    <ns2:SoilLayerParameter ns1:fid="SoilLayerParameter88">
     <ns2:soilLayerLink xlink:href="#SoilLayer_Ls4ld3"/>
     <ns2:xtief>5.0</ns2:xtief>
     <ns2:xret>false</ns2:xret>
    </ns2:SoilLayerParameter>
   </ns2:soilLayerParameterMember>
  </ns2:Soiltype>
 </ns2:soiltypeMember>
 <ns2:soiltypeMember>
  <ns2:Soiltype ns1:fid="Soiltype_Hn-mSfs_2">
   <ns1:description>Kollau  Niedermoortorf-feinsandiger Mittelsand ueber Profil 2</ns1:description>
   <ns1:name>Hn-mSfs_2</ns1:name>
   <ns2:soilLayerParameterMember>
    <ns2:SoilLayerParameter ns1:fid="SoilLayerParameter89">
     <ns2:soilLayerLink xlink:href="#SoilLayer_Hn-mSfs"/>
     <ns2:xtief>8.0</ns2:xtief>
     <ns2:xret>true</ns2:xret>
    </ns2:SoilLayerParameter>
   </ns2:soilLayerParameterMember>
   <ns2:soilLayerParameterMember>
    <ns2:SoilLayerParameter ns1:fid="SoilLayerParameter90">
     <ns2:soilLayerLink xlink:href="#SoilLayer_mSfsld2"/>
     <ns2:xtief>3.0</ns2:xtief>
     <ns2:xret>true</ns2:xret>
    </ns2:SoilLayerParameter>
   </ns2:soilLayerParameterMember>
   <ns2:soilLayerParameterMember>
    <ns2:SoilLayerParameter ns1:fid="SoilLayerParameter91">
     <ns2:soilLayerLink xlink:href="#SoilLayer_mSfsld2"/>
     <ns2:xtief>2.0</ns2:xtief>
     <ns2:xret>true</ns2:xret>
    </ns2:SoilLayerParameter>
   </ns2:soilLayerParameterMember>
   <ns2:soilLayerParameterMember>
    <ns2:SoilLayerParameter ns1:fid="SoilLayerParameter92">
     <ns2:soilLayerLink xlink:href="#SoilLayer_Ls4ld3"/>
     <ns2:xtief>5.0</ns2:xtief>
     <ns2:xret>false</ns2:xret>
    </ns2:SoilLayerParameter>
   </ns2:soilLayerParameterMember>
  </ns2:Soiltype>
 </ns2:soiltypeMember>
 <ns2:soiltypeMember>
  <ns2:Soiltype ns1:fid="Soiltype_Hnz4_2">
   <ns1:description>Kollau  Niedermoortorf ueber Profil 2</ns1:description>
   <ns1:name>Hnz4_2</ns1:name>
   <ns2:soilLayerParameterMember>
    <ns2:SoilLayerParameter ns1:fid="SoilLayerParameter93">
     <ns2:soilLayerLink xlink:href="#SoilLayer_Hnz4SV3"/>
     <ns2:xtief>8.0</ns2:xtief>
     <ns2:xret>true</ns2:xret>
    </ns2:SoilLayerParameter>
   </ns2:soilLayerParameterMember>
   <ns2:soilLayerParameterMember>
    <ns2:SoilLayerParameter ns1:fid="SoilLayerParameter94">
     <ns2:soilLayerLink xlink:href="#SoilLayer_mSfsld2"/>
     <ns2:xtief>3.0</ns2:xtief>
     <ns2:xret>true</ns2:xret>
    </ns2:SoilLayerParameter>
   </ns2:soilLayerParameterMember>
   <ns2:soilLayerParameterMember>
    <ns2:SoilLayerParameter ns1:fid="SoilLayerParameter95">
     <ns2:soilLayerLink xlink:href="#SoilLayer_mSfsld2"/>
     <ns2:xtief>2.0</ns2:xtief>
     <ns2:xret>true</ns2:xret>
    </ns2:SoilLayerParameter>
   </ns2:soilLayerParameterMember>
   <ns2:soilLayerParameterMember>
    <ns2:SoilLayerParameter ns1:fid="SoilLayerParameter96">
     <ns2:soilLayerLink xlink:href="#SoilLayer_Ls4ld3"/>
     <ns2:xtief>5.0</ns2:xtief>
     <ns2:xret>false</ns2:xret>
    </ns2:SoilLayerParameter>
   </ns2:soilLayerParameterMember>
  </ns2:Soiltype>
 </ns2:soiltypeMember>
 <ns2:soiltypeMember>
  <ns2:Soiltype ns1:fid="Soiltype_mSfs_3">
   <ns1:description>Kollau  Feinsandiger Mittelsand ueber Profil 3</ns1:description>
   <ns1:name>mSfs_3</ns1:name>
   <ns2:soilLayerParameterMember>
    <ns2:SoilLayerParameter ns1:fid="SoilLayerParameter97">
     <ns2:soilLayerLink xlink:href="#SoilLayer_mSfsld2"/>
     <ns2:xtief>8.0</ns2:xtief>
     <ns2:xret>true</ns2:xret>
    </ns2:SoilLayerParameter>
   </ns2:soilLayerParameterMember>
   <ns2:soilLayerParameterMember>
    <ns2:SoilLayerParameter ns1:fid="SoilLayerParameter98">
     <ns2:soilLayerLink xlink:href="#SoilLayer_mSfsld2"/>
     <ns2:xtief>10.0</ns2:xtief>
     <ns2:xret>true</ns2:xret>
    </ns2:SoilLayerParameter>
   </ns2:soilLayerParameterMember>
   <ns2:soilLayerParameterMember>
    <ns2:SoilLayerParameter ns1:fid="SoilLayerParameter99">
     <ns2:soilLayerLink xlink:href="#SoilLayer_mSfsld3"/>
     <ns2:xtief>20.0</ns2:xtief>
     <ns2:xret>false</ns2:xret>
    </ns2:SoilLayerParameter>
   </ns2:soilLayerParameterMember>
   <ns2:soilLayerParameterMember>
    <ns2:SoilLayerParameter ns1:fid="SoilLayerParameter100">
     <ns2:soilLayerLink xlink:href="#SoilLayer_Ls4ld3"/>
     <ns2:xtief>5.0</ns2:xtief>
     <ns2:xret>false</ns2:xret>
    </ns2:SoilLayerParameter>
   </ns2:soilLayerParameterMember>
  </ns2:Soiltype>
 </ns2:soiltypeMember>
 <ns2:soiltypeMember>
  <ns2:Soiltype ns1:fid="Soiltype_mS-Sl2_3">
   <ns1:description>Kollau  Feinsand. Mittelsand-schwach lehm. Sand ueber Prof.3</ns1:description>
   <ns1:name>mS-Sl2_3</ns1:name>
   <ns2:soilLayerParameterMember>
    <ns2:SoilLayerParameter ns1:fid="SoilLayerParameter101">
     <ns2:soilLayerLink xlink:href="#SoilLayer_mS-Sl22"/>
     <ns2:xtief>8.0</ns2:xtief>
     <ns2:xret>true</ns2:xret>
    </ns2:SoilLayerParameter>
   </ns2:soilLayerParameterMember>
   <ns2:soilLayerParameterMember>
    <ns2:SoilLayerParameter ns1:fid="SoilLayerParameter102">
     <ns2:soilLayerLink xlink:href="#SoilLayer_mSfsld2"/>
     <ns2:xtief>10.0</ns2:xtief>
     <ns2:xret>true</ns2:xret>
    </ns2:SoilLayerParameter>
   </ns2:soilLayerParameterMember>
   <ns2:soilLayerParameterMember>
    <ns2:SoilLayerParameter ns1:fid="SoilLayerParameter103">
     <ns2:soilLayerLink xlink:href="#SoilLayer_mSfsld3"/>
     <ns2:xtief>20.0</ns2:xtief>
     <ns2:xret>false</ns2:xret>
    </ns2:SoilLayerParameter>
   </ns2:soilLayerParameterMember>
   <ns2:soilLayerParameterMember>
    <ns2:SoilLayerParameter ns1:fid="SoilLayerParameter104">
     <ns2:soilLayerLink xlink:href="#SoilLayer_Ls4ld3"/>
     <ns2:xtief>5.0</ns2:xtief>
     <ns2:xret>false</ns2:xret>
    </ns2:SoilLayerParameter>
   </ns2:soilLayerParameterMember>
  </ns2:Soiltype>
 </ns2:soiltypeMember>
 <ns2:soiltypeMember>
  <ns2:Soiltype ns1:fid="Soiltype_Sl2_3">
   <ns1:description>Kollau  Schwach lehmiger Sand ueber Profil 3</ns1:description>
   <ns1:name>Sl2_3</ns1:name>
   <ns2:soilLayerParameterMember>
    <ns2:SoilLayerParameter ns1:fid="SoilLayerParameter105">
     <ns2:soilLayerLink xlink:href="#SoilLayer_Sl2ld2"/>
     <ns2:xtief>8.0</ns2:xtief>
     <ns2:xret>true</ns2:xret>
    </ns2:SoilLayerParameter>
   </ns2:soilLayerParameterMember>
   <ns2:soilLayerParameterMember>
    <ns2:SoilLayerParameter ns1:fid="SoilLayerParameter106">
     <ns2:soilLayerLink xlink:href="#SoilLayer_mSfsld2"/>
     <ns2:xtief>10.0</ns2:xtief>
     <ns2:xret>true</ns2:xret>
    </ns2:SoilLayerParameter>
   </ns2:soilLayerParameterMember>
   <ns2:soilLayerParameterMember>
    <ns2:SoilLayerParameter ns1:fid="SoilLayerParameter107">
     <ns2:soilLayerLink xlink:href="#SoilLayer_mSfsld3"/>
     <ns2:xtief>20.0</ns2:xtief>
     <ns2:xret>false</ns2:xret>
    </ns2:SoilLayerParameter>
   </ns2:soilLayerParameterMember>
   <ns2:soilLayerParameterMember>
    <ns2:SoilLayerParameter ns1:fid="SoilLayerParameter108">
     <ns2:soilLayerLink xlink:href="#SoilLayer_Ls4ld3"/>
     <ns2:xtief>5.0</ns2:xtief>
     <ns2:xret>false</ns2:xret>
    </ns2:SoilLayerParameter>
   </ns2:soilLayerParameterMember>
  </ns2:Soiltype>
 </ns2:soiltypeMember>
 <ns2:soiltypeMember>
  <ns2:Soiltype ns1:fid="Soiltype_Sl2-Ls3_3">
   <ns1:description>Kollau  Schwach lehm. Sand- mittel sandiger Lehm ueber Prof.3</ns1:description>
   <ns1:name>Sl2-Ls3_3</ns1:name>
   <ns2:soilLayerParameterMember>
    <ns2:SoilLayerParameter ns1:fid="SoilLayerParameter109">
     <ns2:soilLayerLink xlink:href="#SoilLayer_Sl2Ls32"/>
     <ns2:xtief>8.0</ns2:xtief>
     <ns2:xret>true</ns2:xret>
    </ns2:SoilLayerParameter>
   </ns2:soilLayerParameterMember>
   <ns2:soilLayerParameterMember>
    <ns2:SoilLayerParameter ns1:fid="SoilLayerParameter110">
     <ns2:soilLayerLink xlink:href="#SoilLayer_mSfsld2"/>
     <ns2:xtief>10.0</ns2:xtief>
     <ns2:xret>true</ns2:xret>
    </ns2:SoilLayerParameter>
   </ns2:soilLayerParameterMember>
   <ns2:soilLayerParameterMember>
    <ns2:SoilLayerParameter ns1:fid="SoilLayerParameter111">
     <ns2:soilLayerLink xlink:href="#SoilLayer_mSfsld3"/>
     <ns2:xtief>20.0</ns2:xtief>
     <ns2:xret>false</ns2:xret>
    </ns2:SoilLayerParameter>
   </ns2:soilLayerParameterMember>
   <ns2:soilLayerParameterMember>
    <ns2:SoilLayerParameter ns1:fid="SoilLayerParameter112">
     <ns2:soilLayerLink xlink:href="#SoilLayer_Ls4ld3"/>
     <ns2:xtief>5.0</ns2:xtief>
     <ns2:xret>false</ns2:xret>
    </ns2:SoilLayerParameter>
   </ns2:soilLayerParameterMember>
  </ns2:Soiltype>
 </ns2:soiltypeMember>
 <ns2:soiltypeMember>
  <ns2:Soiltype ns1:fid="Soiltype_Hn-mSfs_3">
   <ns1:description>Kollau  Niedermoortorf-feinsandiger Mittelsand ueber Profil 3</ns1:description>
   <ns1:name>Hn-mSfs_3</ns1:name>
   <ns2:soilLayerParameterMember>
    <ns2:SoilLayerParameter ns1:fid="SoilLayerParameter113">
     <ns2:soilLayerLink xlink:href="#SoilLayer_Hn-mSfs"/>
     <ns2:xtief>8.0</ns2:xtief>
     <ns2:xret>true</ns2:xret>
    </ns2:SoilLayerParameter>
   </ns2:soilLayerParameterMember>
   <ns2:soilLayerParameterMember>
    <ns2:SoilLayerParameter ns1:fid="SoilLayerParameter114">
     <ns2:soilLayerLink xlink:href="#SoilLayer_mSfsld2"/>
     <ns2:xtief>10.0</ns2:xtief>
     <ns2:xret>true</ns2:xret>
    </ns2:SoilLayerParameter>
   </ns2:soilLayerParameterMember>
   <ns2:soilLayerParameterMember>
    <ns2:SoilLayerParameter ns1:fid="SoilLayerParameter115">
     <ns2:soilLayerLink xlink:href="#SoilLayer_mSfsld3"/>
     <ns2:xtief>20.0</ns2:xtief>
     <ns2:xret>false</ns2:xret>
    </ns2:SoilLayerParameter>
   </ns2:soilLayerParameterMember>
   <ns2:soilLayerParameterMember>
    <ns2:SoilLayerParameter ns1:fid="SoilLayerParameter116">
     <ns2:soilLayerLink xlink:href="#SoilLayer_Ls4ld3"/>
     <ns2:xtief>5.0</ns2:xtief>
     <ns2:xret>false</ns2:xret>
    </ns2:SoilLayerParameter>
   </ns2:soilLayerParameterMember>
  </ns2:Soiltype>
 </ns2:soiltypeMember>
 <ns2:soiltypeMember>
  <ns2:Soiltype ns1:fid="Soiltype_Hnz4_3">
   <ns1:description>Kollau  Niedermoortorf ueber Profil 3</ns1:description>
   <ns1:name>Hnz4_3</ns1:name>
   <ns2:soilLayerParameterMember>
    <ns2:SoilLayerParameter ns1:fid="SoilLayerParameter117">
     <ns2:soilLayerLink xlink:href="#SoilLayer_Hnz4SV3"/>
     <ns2:xtief>8.0</ns2:xtief>
     <ns2:xret>true</ns2:xret>
    </ns2:SoilLayerParameter>
   </ns2:soilLayerParameterMember>
   <ns2:soilLayerParameterMember>
    <ns2:SoilLayerParameter ns1:fid="SoilLayerParameter118">
     <ns2:soilLayerLink xlink:href="#SoilLayer_mSfsld2"/>
     <ns2:xtief>10.0</ns2:xtief>
     <ns2:xret>true</ns2:xret>
    </ns2:SoilLayerParameter>
   </ns2:soilLayerParameterMember>
   <ns2:soilLayerParameterMember>
    <ns2:SoilLayerParameter ns1:fid="SoilLayerParameter119">
     <ns2:soilLayerLink xlink:href="#SoilLayer_mSfsld3"/>
     <ns2:xtief>20.0</ns2:xtief>
     <ns2:xret>false</ns2:xret>
    </ns2:SoilLayerParameter>
   </ns2:soilLayerParameterMember>
   <ns2:soilLayerParameterMember>
    <ns2:SoilLayerParameter ns1:fid="SoilLayerParameter120">
     <ns2:soilLayerLink xlink:href="#SoilLayer_Ls4ld3"/>
     <ns2:xtief>5.0</ns2:xtief>
     <ns2:xret>false</ns2:xret>
    </ns2:SoilLayerParameter>
   </ns2:soilLayerParameterMember>
  </ns2:Soiltype>
 </ns2:soiltypeMember>
 <ns2:soiltypeMember>
  <ns2:Soiltype ns1:fid="Soiltype_mS-Sl2_4">
   <ns1:description>Kollau  Feinsand. Mittelsand-schwach lehm. Sand ueber Prof.4</ns1:description>
   <ns1:name>mS-Sl2_4</ns1:name>
   <ns2:soilLayerParameterMember>
    <ns2:SoilLayerParameter ns1:fid="SoilLayerParameter121">
     <ns2:soilLayerLink xlink:href="#SoilLayer_mS-Sl22"/>
     <ns2:xtief>8.0</ns2:xtief>
     <ns2:xret>true</ns2:xret>
    </ns2:SoilLayerParameter>
   </ns2:soilLayerParameterMember>
   <ns2:soilLayerParameterMember>
    <ns2:SoilLayerParameter ns1:fid="SoilLayerParameter122">
     <ns2:soilLayerLink xlink:href="#SoilLayer_mSfsld2"/>
     <ns2:xtief>3.0</ns2:xtief>
     <ns2:xret>true</ns2:xret>
    </ns2:SoilLayerParameter>
   </ns2:soilLayerParameterMember>
   <ns2:soilLayerParameterMember>
    <ns2:SoilLayerParameter ns1:fid="SoilLayerParameter123">
     <ns2:soilLayerLink xlink:href="#SoilLayer_mSfsld2"/>
     <ns2:xtief>2.0</ns2:xtief>
     <ns2:xret>true</ns2:xret>
    </ns2:SoilLayerParameter>
   </ns2:soilLayerParameterMember>
   <ns2:soilLayerParameterMember>
    <ns2:SoilLayerParameter ns1:fid="SoilLayerParameter124">
     <ns2:soilLayerLink xlink:href="#SoilLayer_Ls4ld3"/>
     <ns2:xtief>5.0</ns2:xtief>
     <ns2:xret>false</ns2:xret>
    </ns2:SoilLayerParameter>
   </ns2:soilLayerParameterMember>
  </ns2:Soiltype>
 </ns2:soiltypeMember>
 <ns2:soiltypeMember>
  <ns2:Soiltype ns1:fid="Soiltype_mS-Sl2_5">
   <ns1:description>Kollau  Feinsand. Mittelsand-schwach lehm. Sand ueber Prof.5</ns1:description>
   <ns1:name>mS-Sl2_5</ns1:name>
   <ns2:soilLayerParameterMember>
    <ns2:SoilLayerParameter ns1:fid="SoilLayerParameter125">
     <ns2:soilLayerLink xlink:href="#SoilLayer_mS-Sl22"/>
     <ns2:xtief>8.0</ns2:xtief>
     <ns2:xret>true</ns2:xret>
    </ns2:SoilLayerParameter>
   </ns2:soilLayerParameterMember>
   <ns2:soilLayerParameterMember>
    <ns2:SoilLayerParameter ns1:fid="SoilLayerParameter126">
     <ns2:soilLayerLink xlink:href="#SoilLayer_mSfsld2"/>
     <ns2:xtief>10.0</ns2:xtief>
     <ns2:xret>true</ns2:xret>
    </ns2:SoilLayerParameter>
   </ns2:soilLayerParameterMember>
   <ns2:soilLayerParameterMember>
    <ns2:SoilLayerParameter ns1:fid="SoilLayerParameter127">
     <ns2:soilLayerLink xlink:href="#SoilLayer_mSfsld3"/>
     <ns2:xtief>20.0</ns2:xtief>
     <ns2:xret>false</ns2:xret>
    </ns2:SoilLayerParameter>
   </ns2:soilLayerParameterMember>
   <ns2:soilLayerParameterMember>
    <ns2:SoilLayerParameter ns1:fid="SoilLayerParameter128">
     <ns2:soilLayerLink xlink:href="#SoilLayer_Ls4ld3"/>
     <ns2:xtief>5.0</ns2:xtief>
     <ns2:xret>false</ns2:xret>
    </ns2:SoilLayerParameter>
   </ns2:soilLayerParameterMember>
  </ns2:Soiltype>
 </ns2:soiltypeMember>
 <ns2:soiltypeMember>
  <ns2:Soiltype ns1:fid="Soiltype_Hn-mSfs_5">
   <ns1:description>Kollau  Niedermoortorf-feinsandiger Mittelsand ueber Prof.5</ns1:description>
   <ns1:name>Hn-mSfs_5</ns1:name>
   <ns2:soilLayerParameterMember>
    <ns2:SoilLayerParameter ns1:fid="SoilLayerParameter129">
     <ns2:soilLayerLink xlink:href="#SoilLayer_Hn-mSfs"/>
     <ns2:xtief>8.0</ns2:xtief>
     <ns2:xret>true</ns2:xret>
    </ns2:SoilLayerParameter>
   </ns2:soilLayerParameterMember>
   <ns2:soilLayerParameterMember>
    <ns2:SoilLayerParameter ns1:fid="SoilLayerParameter130">
     <ns2:soilLayerLink xlink:href="#SoilLayer_mSfsld2"/>
     <ns2:xtief>10.0</ns2:xtief>
     <ns2:xret>true</ns2:xret>
    </ns2:SoilLayerParameter>
   </ns2:soilLayerParameterMember>
   <ns2:soilLayerParameterMember>
    <ns2:SoilLayerParameter ns1:fid="SoilLayerParameter131">
     <ns2:soilLayerLink xlink:href="#SoilLayer_mSfsld3"/>
     <ns2:xtief>20.0</ns2:xtief>
     <ns2:xret>false</ns2:xret>
    </ns2:SoilLayerParameter>
   </ns2:soilLayerParameterMember>
   <ns2:soilLayerParameterMember>
    <ns2:SoilLayerParameter ns1:fid="SoilLayerParameter132">
     <ns2:soilLayerLink xlink:href="#SoilLayer_Ls4ld3"/>
     <ns2:xtief>5.0</ns2:xtief>
     <ns2:xret>false</ns2:xret>
    </ns2:SoilLayerParameter>
   </ns2:soilLayerParameterMember>
  </ns2:Soiltype>
 </ns2:soiltypeMember>
 <ns2:soiltypeMember>
  <ns2:Soiltype ns1:fid="Soiltype_1Hn9mSf1b">
   <ns1:description>Falkengraben Torf über feinsandigem Mittelsand ueber Prof.1b</ns1:description>
   <ns1:name>1Hn9mSf1b</ns1:name>
   <ns2:soilLayerParameterMember>
    <ns2:SoilLayerParameter ns1:fid="SoilLayerParameter133">
     <ns2:soilLayerLink xlink:href="#SoilLayer_Hnz4SV3"/>
     <ns2:xtief>1.0</ns2:xtief>
     <ns2:xret>true</ns2:xret>
    </ns2:SoilLayerParameter>
   </ns2:soilLayerParameterMember>
   <ns2:soilLayerParameterMember>
    <ns2:SoilLayerParameter ns1:fid="SoilLayerParameter134">
     <ns2:soilLayerLink xlink:href="#SoilLayer_mSfsld3"/>
     <ns2:xtief>9.0</ns2:xtief>
     <ns2:xret>true</ns2:xret>
    </ns2:SoilLayerParameter>
   </ns2:soilLayerParameterMember>
   <ns2:soilLayerParameterMember>
    <ns2:SoilLayerParameter ns1:fid="SoilLayerParameter135">
     <ns2:soilLayerLink xlink:href="#SoilLayer_mSgsld2"/>
     <ns2:xtief>5.0</ns2:xtief>
     <ns2:xret>false</ns2:xret>
    </ns2:SoilLayerParameter>
   </ns2:soilLayerParameterMember>
  </ns2:Soiltype>
 </ns2:soiltypeMember>
 <ns2:soiltypeMember>
  <ns2:Soiltype ns1:fid="Soiltype_2Hn8mSf1b">
   <ns1:description>Falkengraben  Torf über feinsandigem Mittelsand ueber Prof.1b</ns1:description>
   <ns1:name>2Hn8mSf1b</ns1:name>
   <ns2:soilLayerParameterMember>
    <ns2:SoilLayerParameter ns1:fid="SoilLayerParameter136">
     <ns2:soilLayerLink xlink:href="#SoilLayer_Hnz4SV3"/>
     <ns2:xtief>2.0</ns2:xtief>
     <ns2:xret>true</ns2:xret>
    </ns2:SoilLayerParameter>
   </ns2:soilLayerParameterMember>
   <ns2:soilLayerParameterMember>
    <ns2:SoilLayerParameter ns1:fid="SoilLayerParameter137">
     <ns2:soilLayerLink xlink:href="#SoilLayer_mSfsld3"/>
     <ns2:xtief>8.0</ns2:xtief>
     <ns2:xret>true</ns2:xret>
    </ns2:SoilLayerParameter>
   </ns2:soilLayerParameterMember>
   <ns2:soilLayerParameterMember>
    <ns2:SoilLayerParameter ns1:fid="SoilLayerParameter138">
     <ns2:soilLayerLink xlink:href="#SoilLayer_mSgsld2"/>
     <ns2:xtief>5.0</ns2:xtief>
     <ns2:xret>false</ns2:xret>
    </ns2:SoilLayerParameter>
   </ns2:soilLayerParameterMember>
  </ns2:Soiltype>
 </ns2:soiltypeMember>
 <ns2:soiltypeMember>
  <ns2:Soiltype ns1:fid="Soiltype_2Hn8mSf6">
   <ns1:description>Falkengraben  Torf über feinsandigem Mittelsand ueber Prof.6</ns1:description>
   <ns1:name>2Hn8mSf6</ns1:name>
   <ns2:soilLayerParameterMember>
    <ns2:SoilLayerParameter ns1:fid="SoilLayerParameter139">
     <ns2:soilLayerLink xlink:href="#SoilLayer_Hnz4SV3"/>
     <ns2:xtief>2.0</ns2:xtief>
     <ns2:xret>true</ns2:xret>
    </ns2:SoilLayerParameter>
   </ns2:soilLayerParameterMember>
   <ns2:soilLayerParameterMember>
    <ns2:SoilLayerParameter ns1:fid="SoilLayerParameter140">
     <ns2:soilLayerLink xlink:href="#SoilLayer_mSfsld3"/>
     <ns2:xtief>8.0</ns2:xtief>
     <ns2:xret>true</ns2:xret>
    </ns2:SoilLayerParameter>
   </ns2:soilLayerParameterMember>
   <ns2:soilLayerParameterMember>
    <ns2:SoilLayerParameter ns1:fid="SoilLayerParameter141">
     <ns2:soilLayerLink xlink:href="#SoilLayer_mSgsld2"/>
     <ns2:xtief>5.0</ns2:xtief>
     <ns2:xret>false</ns2:xret>
    </ns2:SoilLayerParameter>
   </ns2:soilLayerParameterMember>
  </ns2:Soiltype>
 </ns2:soiltypeMember>
 <ns2:soiltypeMember>
  <ns2:Soiltype ns1:fid="Soiltype_3mSf7Hn1b">
   <ns1:description>Falkengraben  Feinsandiger Mittelsand über Torf über Prof. 1b</ns1:description>
   <ns1:name>3mSf7Hn1b</ns1:name>
   <ns2:soilLayerParameterMember>
    <ns2:SoilLayerParameter ns1:fid="SoilLayerParameter142">
     <ns2:soilLayerLink xlink:href="#SoilLayer_mSfsld2"/>
     <ns2:xtief>3.0</ns2:xtief>
     <ns2:xret>true</ns2:xret>
    </ns2:SoilLayerParameter>
   </ns2:soilLayerParameterMember>
   <ns2:soilLayerParameterMember>
    <ns2:SoilLayerParameter ns1:fid="SoilLayerParameter143">
     <ns2:soilLayerLink xlink:href="#SoilLayer_Hnz4SV3"/>
     <ns2:xtief>7.0</ns2:xtief>
     <ns2:xret>true</ns2:xret>
    </ns2:SoilLayerParameter>
   </ns2:soilLayerParameterMember>
   <ns2:soilLayerParameterMember>
    <ns2:SoilLayerParameter ns1:fid="SoilLayerParameter144">
     <ns2:soilLayerLink xlink:href="#SoilLayer_mSgsld2"/>
     <ns2:xtief>5.0</ns2:xtief>
     <ns2:xret>false</ns2:xret>
    </ns2:SoilLayerParameter>
   </ns2:soilLayerParameterMember>
  </ns2:Soiltype>
 </ns2:soiltypeMember>
 <ns2:soiltypeMember>
  <ns2:Soiltype ns1:fid="Soiltype_4Hn6mSf1a">
   <ns1:description>Falkengraben   Torf über feinsandigem Mittelsand ueber Prof.1a</ns1:description>
   <ns1:name>4Hn6mSf1a</ns1:name>
   <ns2:soilLayerParameterMember>
    <ns2:SoilLayerParameter ns1:fid="SoilLayerParameter145">
     <ns2:soilLayerLink xlink:href="#SoilLayer_Hnz4SV3"/>
     <ns2:xtief>4.0</ns2:xtief>
     <ns2:xret>true</ns2:xret>
    </ns2:SoilLayerParameter>
   </ns2:soilLayerParameterMember>
   <ns2:soilLayerParameterMember>
    <ns2:SoilLayerParameter ns1:fid="SoilLayerParameter146">
     <ns2:soilLayerLink xlink:href="#SoilLayer_mSfsld3"/>
     <ns2:xtief>6.0</ns2:xtief>
     <ns2:xret>true</ns2:xret>
    </ns2:SoilLayerParameter>
   </ns2:soilLayerParameterMember>
   <ns2:soilLayerParameterMember>
    <ns2:SoilLayerParameter ns1:fid="SoilLayerParameter147">
     <ns2:soilLayerLink xlink:href="#SoilLayer_mSgsld2"/>
     <ns2:xtief>5.0</ns2:xtief>
     <ns2:xret>false</ns2:xret>
    </ns2:SoilLayerParameter>
   </ns2:soilLayerParameterMember>
  </ns2:Soiltype>
 </ns2:soiltypeMember>
 <ns2:soiltypeMember>
  <ns2:Soiltype ns1:fid="Soiltype_4Hn6mSf6">
   <ns1:description>Falkengraben   Torf über feinsandigem Mittelsand ueber Prof.6</ns1:description>
   <ns1:name>4Hn6mSf6</ns1:name>
   <ns2:soilLayerParameterMember>
    <ns2:SoilLayerParameter ns1:fid="SoilLayerParameter148">
     <ns2:soilLayerLink xlink:href="#SoilLayer_Hnz4SV3"/>
     <ns2:xtief>4.0</ns2:xtief>
     <ns2:xret>true</ns2:xret>
    </ns2:SoilLayerParameter>
   </ns2:soilLayerParameterMember>
   <ns2:soilLayerParameterMember>
    <ns2:SoilLayerParameter ns1:fid="SoilLayerParameter149">
     <ns2:soilLayerLink xlink:href="#SoilLayer_mSfsld3"/>
     <ns2:xtief>6.0</ns2:xtief>
     <ns2:xret>true</ns2:xret>
    </ns2:SoilLayerParameter>
   </ns2:soilLayerParameterMember>
   <ns2:soilLayerParameterMember>
    <ns2:SoilLayerParameter ns1:fid="SoilLayerParameter150">
     <ns2:soilLayerLink xlink:href="#SoilLayer_mSfsld2"/>
     <ns2:xtief>5.0</ns2:xtief>
     <ns2:xret>false</ns2:xret>
    </ns2:SoilLayerParameter>
   </ns2:soilLayerParameterMember>
  </ns2:Soiltype>
 </ns2:soiltypeMember>
 <ns2:soiltypeMember>
  <ns2:Soiltype ns1:fid="Soiltype_4mSf6Sl21a">
   <ns1:description>Falkengraben   Feinsandiger Mittelsand über lehmigem Sand über Prof. 1a</ns1:description>
   <ns1:name>4mSf6Sl21a</ns1:name>
   <ns2:soilLayerParameterMember>
    <ns2:SoilLayerParameter ns1:fid="SoilLayerParameter151">
     <ns2:soilLayerLink xlink:href="#SoilLayer_mSfsld2"/>
     <ns2:xtief>4.0</ns2:xtief>
     <ns2:xret>true</ns2:xret>
    </ns2:SoilLayerParameter>
   </ns2:soilLayerParameterMember>
   <ns2:soilLayerParameterMember>
    <ns2:SoilLayerParameter ns1:fid="SoilLayerParameter152">
     <ns2:soilLayerLink xlink:href="#SoilLayer_Sl2ld3"/>
     <ns2:xtief>6.0</ns2:xtief>
     <ns2:xret>true</ns2:xret>
    </ns2:SoilLayerParameter>
   </ns2:soilLayerParameterMember>
   <ns2:soilLayerParameterMember>
    <ns2:SoilLayerParameter ns1:fid="SoilLayerParameter153">
     <ns2:soilLayerLink xlink:href="#SoilLayer_mSgsld2"/>
     <ns2:xtief>5.0</ns2:xtief>
     <ns2:xret>false</ns2:xret>
    </ns2:SoilLayerParameter>
   </ns2:soilLayerParameterMember>
  </ns2:Soiltype>
 </ns2:soiltypeMember>
 <ns2:soiltypeMember>
  <ns2:Soiltype ns1:fid="Soiltype_4mSf6Sl27">
   <ns1:description>Falkengraben   Feinsandiger Mittelsand über lehmigem Sand über Prof. 7</ns1:description>
   <ns1:name>4mSf6Sl27</ns1:name>
   <ns2:soilLayerParameterMember>
    <ns2:SoilLayerParameter ns1:fid="SoilLayerParameter154">
     <ns2:soilLayerLink xlink:href="#SoilLayer_mSfsld2"/>
     <ns2:xtief>4.0</ns2:xtief>
     <ns2:xret>true</ns2:xret>
    </ns2:SoilLayerParameter>
   </ns2:soilLayerParameterMember>
   <ns2:soilLayerParameterMember>
    <ns2:SoilLayerParameter ns1:fid="SoilLayerParameter155">
     <ns2:soilLayerLink xlink:href="#SoilLayer_Sl2ld3"/>
     <ns2:xtief>6.0</ns2:xtief>
     <ns2:xret>true</ns2:xret>
    </ns2:SoilLayerParameter>
   </ns2:soilLayerParameterMember>
   <ns2:soilLayerParameterMember>
    <ns2:SoilLayerParameter ns1:fid="SoilLayerParameter156">
     <ns2:soilLayerLink xlink:href="#SoilLayer_mSfsld2"/>
     <ns2:xtief>5.0</ns2:xtief>
     <ns2:xret>false</ns2:xret>
    </ns2:SoilLayerParameter>
   </ns2:soilLayerParameterMember>
  </ns2:Soiltype>
 </ns2:soiltypeMember>
 <ns2:soiltypeMember>
  <ns2:Soiltype ns1:fid="Soiltype_4mSf6Xs1a">
   <ns1:description>Falkengraben   Feinsandiger Mittelsand über steinigem Sand über Prof. 1a</ns1:description>
   <ns1:name>4mSf6Xs1a</ns1:name>
   <ns2:soilLayerParameterMember>
    <ns2:SoilLayerParameter ns1:fid="SoilLayerParameter157">
     <ns2:soilLayerLink xlink:href="#SoilLayer_mSfsld2"/>
     <ns2:xtief>4.0</ns2:xtief>
     <ns2:xret>true</ns2:xret>
    </ns2:SoilLayerParameter>
   </ns2:soilLayerParameterMember>
   <ns2:soilLayerParameterMember>
    <ns2:SoilLayerParameter ns1:fid="SoilLayerParameter158">
     <ns2:soilLayerLink xlink:href="#SoilLayer_Xs"/>
     <ns2:xtief>6.0</ns2:xtief>
     <ns2:xret>true</ns2:xret>
    </ns2:SoilLayerParameter>
   </ns2:soilLayerParameterMember>
   <ns2:soilLayerParameterMember>
    <ns2:SoilLayerParameter ns1:fid="SoilLayerParameter159">
     <ns2:soilLayerLink xlink:href="#SoilLayer_mSgsld2"/>
     <ns2:xtief>5.0</ns2:xtief>
     <ns2:xret>false</ns2:xret>
    </ns2:SoilLayerParameter>
   </ns2:soilLayerParameterMember>
  </ns2:Soiltype>
 </ns2:soiltypeMember>
 <ns2:soiltypeMember>
  <ns2:Soiltype ns1:fid="Soiltype_4mSf6Xs1b">
   <ns1:description>Falkengraben   Feinsandiger Mittelsand über steinigem Sand über Prof. 1b</ns1:description>
   <ns1:name>4mSf6Xs1b</ns1:name>
   <ns2:soilLayerParameterMember>
    <ns2:SoilLayerParameter ns1:fid="SoilLayerParameter160">
     <ns2:soilLayerLink xlink:href="#SoilLayer_mSfsld2"/>
     <ns2:xtief>4.0</ns2:xtief>
     <ns2:xret>true</ns2:xret>
    </ns2:SoilLayerParameter>
   </ns2:soilLayerParameterMember>
   <ns2:soilLayerParameterMember>
    <ns2:SoilLayerParameter ns1:fid="SoilLayerParameter161">
     <ns2:soilLayerLink xlink:href="#SoilLayer_Xs"/>
     <ns2:xtief>6.0</ns2:xtief>
     <ns2:xret>true</ns2:xret>
    </ns2:SoilLayerParameter>
   </ns2:soilLayerParameterMember>
   <ns2:soilLayerParameterMember>
    <ns2:SoilLayerParameter ns1:fid="SoilLayerParameter162">
     <ns2:soilLayerLink xlink:href="#SoilLayer_mSgsld2"/>
     <ns2:xtief>5.0</ns2:xtief>
     <ns2:xret>false</ns2:xret>
    </ns2:SoilLayerParameter>
   </ns2:soilLayerParameterMember>
  </ns2:Soiltype>
 </ns2:soiltypeMember>
 <ns2:soiltypeMember>
  <ns2:Soiltype ns1:fid="Soiltype_4mSf6Xs6">
   <ns1:description>Falkengraben   Feinsandiger Mittelsand über steinigem Sand über Prof. 6</ns1:description>
   <ns1:name>4mSf6Xs6</ns1:name>
   <ns2:soilLayerParameterMember>
    <ns2:SoilLayerParameter ns1:fid="SoilLayerParameter163">
     <ns2:soilLayerLink xlink:href="#SoilLayer_mSfsld2"/>
     <ns2:xtief>4.0</ns2:xtief>
     <ns2:xret>true</ns2:xret>
    </ns2:SoilLayerParameter>
   </ns2:soilLayerParameterMember>
   <ns2:soilLayerParameterMember>
    <ns2:SoilLayerParameter ns1:fid="SoilLayerParameter164">
     <ns2:soilLayerLink xlink:href="#SoilLayer_Xs"/>
     <ns2:xtief>6.0</ns2:xtief>
     <ns2:xret>true</ns2:xret>
    </ns2:SoilLayerParameter>
   </ns2:soilLayerParameterMember>
   <ns2:soilLayerParameterMember>
    <ns2:SoilLayerParameter ns1:fid="SoilLayerParameter165">
     <ns2:soilLayerLink xlink:href="#SoilLayer_mSfsld2"/>
     <ns2:xtief>5.0</ns2:xtief>
     <ns2:xret>false</ns2:xret>
    </ns2:SoilLayerParameter>
   </ns2:soilLayerParameterMember>
  </ns2:Soiltype>
 </ns2:soiltypeMember>
 <ns2:soiltypeMember>
  <ns2:Soiltype ns1:fid="Soiltype_5gS5gS1a">
   <ns1:description>Falkengraben   Grobsand über Prof. 1a</ns1:description>
   <ns1:name>5gS5gS1a</ns1:name>
   <ns2:soilLayerParameterMember>
    <ns2:SoilLayerParameter ns1:fid="SoilLayerParameter166">
     <ns2:soilLayerLink xlink:href="#SoilLayer_gSld2"/>
     <ns2:xtief>5.0</ns2:xtief>
     <ns2:xret>true</ns2:xret>
    </ns2:SoilLayerParameter>
   </ns2:soilLayerParameterMember>
   <ns2:soilLayerParameterMember>
    <ns2:SoilLayerParameter ns1:fid="SoilLayerParameter167">
     <ns2:soilLayerLink xlink:href="#SoilLayer_gSld3"/>
     <ns2:xtief>5.0</ns2:xtief>
     <ns2:xret>true</ns2:xret>
    </ns2:SoilLayerParameter>
   </ns2:soilLayerParameterMember>
   <ns2:soilLayerParameterMember>
    <ns2:SoilLayerParameter ns1:fid="SoilLayerParameter168">
     <ns2:soilLayerLink xlink:href="#SoilLayer_mSgsld2"/>
     <ns2:xtief>5.0</ns2:xtief>
     <ns2:xret>false</ns2:xret>
    </ns2:SoilLayerParameter>
   </ns2:soilLayerParameterMember>
  </ns2:Soiltype>
 </ns2:soiltypeMember>
 <ns2:soiltypeMember>
  <ns2:Soiltype ns1:fid="Soiltype_5Hn5Hn1b">
   <ns1:description>Falkengraben  Torf über Prof. 1b</ns1:description>
   <ns1:name>5Hn5Hn1b</ns1:name>
   <ns2:soilLayerParameterMember>
    <ns2:SoilLayerParameter ns1:fid="SoilLayerParameter169">
     <ns2:soilLayerLink xlink:href="#SoilLayer_Hnz4SV3"/>
     <ns2:xtief>5.0</ns2:xtief>
     <ns2:xret>true</ns2:xret>
    </ns2:SoilLayerParameter>
   </ns2:soilLayerParameterMember>
   <ns2:soilLayerParameterMember>
    <ns2:SoilLayerParameter ns1:fid="SoilLayerParameter170">
     <ns2:soilLayerLink xlink:href="#SoilLayer_Hnz4SV3"/>
     <ns2:xtief>5.0</ns2:xtief>
     <ns2:xret>true</ns2:xret>
    </ns2:SoilLayerParameter>
   </ns2:soilLayerParameterMember>
   <ns2:soilLayerParameterMember>
    <ns2:SoilLayerParameter ns1:fid="SoilLayerParameter171">
     <ns2:soilLayerLink xlink:href="#SoilLayer_mSgsld2"/>
     <ns2:xtief>5.0</ns2:xtief>
     <ns2:xret>false</ns2:xret>
    </ns2:SoilLayerParameter>
   </ns2:soilLayerParameterMember>
  </ns2:Soiltype>
 </ns2:soiltypeMember>
 <ns2:soiltypeMember>
  <ns2:Soiltype ns1:fid="Soiltype_5Hn5Hn2b">
   <ns1:description>Falkengraben  Torf über Prof. 2b</ns1:description>
   <ns1:name>5Hn5Hn2b</ns1:name>
   <ns2:soilLayerParameterMember>
    <ns2:SoilLayerParameter ns1:fid="SoilLayerParameter172">
     <ns2:soilLayerLink xlink:href="#SoilLayer_Hnz4SV3"/>
     <ns2:xtief>5.0</ns2:xtief>
     <ns2:xret>true</ns2:xret>
    </ns2:SoilLayerParameter>
   </ns2:soilLayerParameterMember>
   <ns2:soilLayerParameterMember>
    <ns2:SoilLayerParameter ns1:fid="SoilLayerParameter173">
     <ns2:soilLayerLink xlink:href="#SoilLayer_Hnz4SV3"/>
     <ns2:xtief>5.0</ns2:xtief>
     <ns2:xret>true</ns2:xret>
    </ns2:SoilLayerParameter>
   </ns2:soilLayerParameterMember>
   <ns2:soilLayerParameterMember>
    <ns2:SoilLayerParameter ns1:fid="SoilLayerParameter174">
     <ns2:soilLayerLink xlink:href="#SoilLayer_mSfsld2"/>
     <ns2:xtief>5.0</ns2:xtief>
     <ns2:xret>false</ns2:xret>
    </ns2:SoilLayerParameter>
   </ns2:soilLayerParameterMember>
  </ns2:Soiltype>
 </ns2:soiltypeMember>
 <ns2:soiltypeMember>
  <ns2:Soiltype ns1:fid="Soiltype_5Hn5Hn6">
   <ns1:description>Falkengraben Torf über Prof. 6</ns1:description>
   <ns1:name>5Hn5Hn6</ns1:name>
   <ns2:soilLayerParameterMember>
    <ns2:SoilLayerParameter ns1:fid="SoilLayerParameter175">
     <ns2:soilLayerLink xlink:href="#SoilLayer_Hnz4SV3"/>
     <ns2:xtief>5.0</ns2:xtief>
     <ns2:xret>true</ns2:xret>
    </ns2:SoilLayerParameter>
   </ns2:soilLayerParameterMember>
   <ns2:soilLayerParameterMember>
    <ns2:SoilLayerParameter ns1:fid="SoilLayerParameter176">
     <ns2:soilLayerLink xlink:href="#SoilLayer_Hnz4SV3"/>
     <ns2:xtief>5.0</ns2:xtief>
     <ns2:xret>true</ns2:xret>
    </ns2:SoilLayerParameter>
   </ns2:soilLayerParameterMember>
   <ns2:soilLayerParameterMember>
    <ns2:SoilLayerParameter ns1:fid="SoilLayerParameter177">
     <ns2:soilLayerLink xlink:href="#SoilLayer_mSfsld2"/>
     <ns2:xtief>5.0</ns2:xtief>
     <ns2:xret>false</ns2:xret>
    </ns2:SoilLayerParameter>
   </ns2:soilLayerParameterMember>
  </ns2:Soiltype>
 </ns2:soiltypeMember>
 <ns2:soiltypeMember>
  <ns2:Soiltype ns1:fid="Soiltype_5Hn5mSf6">
   <ns1:description>Falkengraben  Torf über feinsandigem Mittelsand über Prof. 6</ns1:description>
   <ns1:name>5Hn5mSf6</ns1:name>
   <ns2:soilLayerParameterMember>
    <ns2:SoilLayerParameter ns1:fid="SoilLayerParameter178">
     <ns2:soilLayerLink xlink:href="#SoilLayer_Hnz4SV3"/>
     <ns2:xtief>5.0</ns2:xtief>
     <ns2:xret>true</ns2:xret>
    </ns2:SoilLayerParameter>
   </ns2:soilLayerParameterMember>
   <ns2:soilLayerParameterMember>
    <ns2:SoilLayerParameter ns1:fid="SoilLayerParameter179">
     <ns2:soilLayerLink xlink:href="#SoilLayer_mSfsld3"/>
     <ns2:xtief>5.0</ns2:xtief>
     <ns2:xret>true</ns2:xret>
    </ns2:SoilLayerParameter>
   </ns2:soilLayerParameterMember>
   <ns2:soilLayerParameterMember>
    <ns2:SoilLayerParameter ns1:fid="SoilLayerParameter180">
     <ns2:soilLayerLink xlink:href="#SoilLayer_mSfsld2"/>
     <ns2:xtief>5.0</ns2:xtief>
     <ns2:xret>false</ns2:xret>
    </ns2:SoilLayerParameter>
   </ns2:soilLayerParameterMember>
  </ns2:Soiltype>
 </ns2:soiltypeMember>
 <ns2:soiltypeMember>
  <ns2:Soiltype ns1:fid="Soiltype_5Ls25Ls24">
   <ns1:description>Falkengraben  Schwach sandiger Lehm über Prof. 4</ns1:description>
   <ns1:name>5Ls25Ls24</ns1:name>
   <ns2:soilLayerParameterMember>
    <ns2:SoilLayerParameter ns1:fid="SoilLayerParameter181">
     <ns2:soilLayerLink xlink:href="#SoilLayer_Ls2ld2"/>
     <ns2:xtief>5.0</ns2:xtief>
     <ns2:xret>true</ns2:xret>
    </ns2:SoilLayerParameter>
   </ns2:soilLayerParameterMember>
   <ns2:soilLayerParameterMember>
    <ns2:SoilLayerParameter ns1:fid="SoilLayerParameter182">
     <ns2:soilLayerLink xlink:href="#SoilLayer_Ls2ld3"/>
     <ns2:xtief>5.0</ns2:xtief>
     <ns2:xret>true</ns2:xret>
    </ns2:SoilLayerParameter>
   </ns2:soilLayerParameterMember>
   <ns2:soilLayerParameterMember>
    <ns2:SoilLayerParameter ns1:fid="SoilLayerParameter183">
     <ns2:soilLayerLink xlink:href="#SoilLayer_mSfsld2"/>
     <ns2:xtief>5.0</ns2:xtief>
     <ns2:xret>false</ns2:xret>
    </ns2:SoilLayerParameter>
   </ns2:soilLayerParameterMember>
  </ns2:Soiltype>
 </ns2:soiltypeMember>
 <ns2:soiltypeMember>
  <ns2:Soiltype ns1:fid="Soiltype_5Ls25Ls27">
   <ns1:description>Falkengraben  Schwach sandiger Lehm über Prof. 7</ns1:description>
   <ns1:name>5Ls25Ls27</ns1:name>
   <ns2:soilLayerParameterMember>
    <ns2:SoilLayerParameter ns1:fid="SoilLayerParameter184">
     <ns2:soilLayerLink xlink:href="#SoilLayer_Ls2ld2"/>
     <ns2:xtief>5.0</ns2:xtief>
     <ns2:xret>true</ns2:xret>
    </ns2:SoilLayerParameter>
   </ns2:soilLayerParameterMember>
   <ns2:soilLayerParameterMember>
    <ns2:SoilLayerParameter ns1:fid="SoilLayerParameter185">
     <ns2:soilLayerLink xlink:href="#SoilLayer_Ls2ld3"/>
     <ns2:xtief>5.0</ns2:xtief>
     <ns2:xret>true</ns2:xret>
    </ns2:SoilLayerParameter>
   </ns2:soilLayerParameterMember>
   <ns2:soilLayerParameterMember>
    <ns2:SoilLayerParameter ns1:fid="SoilLayerParameter186">
     <ns2:soilLayerLink xlink:href="#SoilLayer_mSfsld2"/>
     <ns2:xtief>5.0</ns2:xtief>
     <ns2:xret>false</ns2:xret>
    </ns2:SoilLayerParameter>
   </ns2:soilLayerParameterMember>
  </ns2:Soiltype>
 </ns2:soiltypeMember>
 <ns2:soiltypeMember>
  <ns2:Soiltype ns1:fid="Soiltype_5mS5mS4">
   <ns1:description>Falkengraben  Mittelsand über Prof. 4</ns1:description>
   <ns1:name>5mS5mS4</ns1:name>
   <ns2:soilLayerParameterMember>
    <ns2:SoilLayerParameter ns1:fid="SoilLayerParameter187">
     <ns2:soilLayerLink xlink:href="#SoilLayer_mSld2"/>
     <ns2:xtief>5.0</ns2:xtief>
     <ns2:xret>true</ns2:xret>
    </ns2:SoilLayerParameter>
   </ns2:soilLayerParameterMember>
   <ns2:soilLayerParameterMember>
    <ns2:SoilLayerParameter ns1:fid="SoilLayerParameter188">
     <ns2:soilLayerLink xlink:href="#SoilLayer_mSld3"/>
     <ns2:xtief>5.0</ns2:xtief>
     <ns2:xret>true</ns2:xret>
    </ns2:SoilLayerParameter>
   </ns2:soilLayerParameterMember>
   <ns2:soilLayerParameterMember>
    <ns2:SoilLayerParameter ns1:fid="SoilLayerParameter189">
     <ns2:soilLayerLink xlink:href="#SoilLayer_mSfsld2"/>
     <ns2:xtief>5.0</ns2:xtief>
     <ns2:xret>false</ns2:xret>
    </ns2:SoilLayerParameter>
   </ns2:soilLayerParameterMember>
  </ns2:Soiltype>
 </ns2:soiltypeMember>
 <ns2:soiltypeMember>
  <ns2:Soiltype ns1:fid="Soiltype_5mS5mS7">
   <ns1:description>Falkengraben  Mittelsand über Prof. 7</ns1:description>
   <ns1:name>5mS5mS7</ns1:name>
   <ns2:soilLayerParameterMember>
    <ns2:SoilLayerParameter ns1:fid="SoilLayerParameter190">
     <ns2:soilLayerLink xlink:href="#SoilLayer_mSld2"/>
     <ns2:xtief>5.0</ns2:xtief>
     <ns2:xret>true</ns2:xret>
    </ns2:SoilLayerParameter>
   </ns2:soilLayerParameterMember>
   <ns2:soilLayerParameterMember>
    <ns2:SoilLayerParameter ns1:fid="SoilLayerParameter191">
     <ns2:soilLayerLink xlink:href="#SoilLayer_mSld3"/>
     <ns2:xtief>5.0</ns2:xtief>
     <ns2:xret>true</ns2:xret>
    </ns2:SoilLayerParameter>
   </ns2:soilLayerParameterMember>
   <ns2:soilLayerParameterMember>
    <ns2:SoilLayerParameter ns1:fid="SoilLayerParameter192">
     <ns2:soilLayerLink xlink:href="#SoilLayer_mSfsld2"/>
     <ns2:xtief>5.0</ns2:xtief>
     <ns2:xret>false</ns2:xret>
    </ns2:SoilLayerParameter>
   </ns2:soilLayerParameterMember>
  </ns2:Soiltype>
 </ns2:soiltypeMember>
 <ns2:soiltypeMember>
  <ns2:Soiltype ns1:fid="Soiltype_5mSf5mSf1a">
   <ns1:description>Falkengraben  feinsandiger Mittelsand über Prof. 1a</ns1:description>
   <ns1:name>5mSf5mSf1a</ns1:name>
   <ns2:soilLayerParameterMember>
    <ns2:SoilLayerParameter ns1:fid="SoilLayerParameter193">
     <ns2:soilLayerLink xlink:href="#SoilLayer_mSfsld2"/>
     <ns2:xtief>5.0</ns2:xtief>
     <ns2:xret>true</ns2:xret>
    </ns2:SoilLayerParameter>
   </ns2:soilLayerParameterMember>
   <ns2:soilLayerParameterMember>
    <ns2:SoilLayerParameter ns1:fid="SoilLayerParameter194">
     <ns2:soilLayerLink xlink:href="#SoilLayer_mSfsld3"/>
     <ns2:xtief>5.0</ns2:xtief>
     <ns2:xret>true</ns2:xret>
    </ns2:SoilLayerParameter>
   </ns2:soilLayerParameterMember>
   <ns2:soilLayerParameterMember>
    <ns2:SoilLayerParameter ns1:fid="SoilLayerParameter195">
     <ns2:soilLayerLink xlink:href="#SoilLayer_mSgsld2"/>
     <ns2:xtief>5.0</ns2:xtief>
     <ns2:xret>false</ns2:xret>
    </ns2:SoilLayerParameter>
   </ns2:soilLayerParameterMember>
  </ns2:Soiltype>
 </ns2:soiltypeMember>
 <ns2:soiltypeMember>
  <ns2:Soiltype ns1:fid="Soiltype_5mSf5mSf1b">
   <ns1:description>Falkengraben  feinsandiger Mittelsand über Prof. 1b</ns1:description>
   <ns1:name>5mSf5mSf1b</ns1:name>
   <ns2:soilLayerParameterMember>
    <ns2:SoilLayerParameter ns1:fid="SoilLayerParameter196">
     <ns2:soilLayerLink xlink:href="#SoilLayer_mSfsld2"/>
     <ns2:xtief>5.0</ns2:xtief>
     <ns2:xret>true</ns2:xret>
    </ns2:SoilLayerParameter>
   </ns2:soilLayerParameterMember>
   <ns2:soilLayerParameterMember>
    <ns2:SoilLayerParameter ns1:fid="SoilLayerParameter197">
     <ns2:soilLayerLink xlink:href="#SoilLayer_mSfsld3"/>
     <ns2:xtief>5.0</ns2:xtief>
     <ns2:xret>true</ns2:xret>
    </ns2:SoilLayerParameter>
   </ns2:soilLayerParameterMember>
   <ns2:soilLayerParameterMember>
    <ns2:SoilLayerParameter ns1:fid="SoilLayerParameter198">
     <ns2:soilLayerLink xlink:href="#SoilLayer_mSgsld2"/>
     <ns2:xtief>5.0</ns2:xtief>
     <ns2:xret>false</ns2:xret>
    </ns2:SoilLayerParameter>
   </ns2:soilLayerParameterMember>
  </ns2:Soiltype>
 </ns2:soiltypeMember>
 <ns2:soiltypeMember>
  <ns2:Soiltype ns1:fid="Soiltype_5mSf5mSf2a">
   <ns1:description>Falkengraben  feinsandiger Mittelsand über Prof. 2a</ns1:description>
   <ns1:name>5mSf5mSf2a</ns1:name>
   <ns2:soilLayerParameterMember>
    <ns2:SoilLayerParameter ns1:fid="SoilLayerParameter199">
     <ns2:soilLayerLink xlink:href="#SoilLayer_mSfsld2"/>
     <ns2:xtief>5.0</ns2:xtief>
     <ns2:xret>true</ns2:xret>
    </ns2:SoilLayerParameter>
   </ns2:soilLayerParameterMember>
   <ns2:soilLayerParameterMember>
    <ns2:SoilLayerParameter ns1:fid="SoilLayerParameter200">
     <ns2:soilLayerLink xlink:href="#SoilLayer_mSfsld3"/>
     <ns2:xtief>5.0</ns2:xtief>
     <ns2:xret>true</ns2:xret>
    </ns2:SoilLayerParameter>
   </ns2:soilLayerParameterMember>
   <ns2:soilLayerParameterMember>
    <ns2:SoilLayerParameter ns1:fid="SoilLayerParameter201">
     <ns2:soilLayerLink xlink:href="#SoilLayer_mSfsld2"/>
     <ns2:xtief>5.0</ns2:xtief>
     <ns2:xret>false</ns2:xret>
    </ns2:SoilLayerParameter>
   </ns2:soilLayerParameterMember>
  </ns2:Soiltype>
 </ns2:soiltypeMember>
 <ns2:soiltypeMember>
  <ns2:Soiltype ns1:fid="Soiltype_5mSf5mSf3">
   <ns1:description>Falkengraben  feinsandiger Mittelsand über Prof. 3</ns1:description>
   <ns1:name>5mSf5mSf3</ns1:name>
   <ns2:soilLayerParameterMember>
    <ns2:SoilLayerParameter ns1:fid="SoilLayerParameter202">
     <ns2:soilLayerLink xlink:href="#SoilLayer_mSfsld2"/>
     <ns2:xtief>5.0</ns2:xtief>
     <ns2:xret>true</ns2:xret>
    </ns2:SoilLayerParameter>
   </ns2:soilLayerParameterMember>
   <ns2:soilLayerParameterMember>
    <ns2:SoilLayerParameter ns1:fid="SoilLayerParameter203">
     <ns2:soilLayerLink xlink:href="#SoilLayer_mSfsld3"/>
     <ns2:xtief>5.0</ns2:xtief>
     <ns2:xret>true</ns2:xret>
    </ns2:SoilLayerParameter>
   </ns2:soilLayerParameterMember>
   <ns2:soilLayerParameterMember>
    <ns2:SoilLayerParameter ns1:fid="SoilLayerParameter204">
     <ns2:soilLayerLink xlink:href="#SoilLayer_mSfsld2"/>
     <ns2:xtief>5.0</ns2:xtief>
     <ns2:xret>false</ns2:xret>
    </ns2:SoilLayerParameter>
   </ns2:soilLayerParameterMember>
  </ns2:Soiltype>
 </ns2:soiltypeMember>
 <ns2:soiltypeMember>
  <ns2:Soiltype ns1:fid="Soiltype_5mSf5mSf6">
   <ns1:description>Falkengraben  feinsandiger Mittelsand über Prof. 6</ns1:description>
   <ns1:name>5mSf5mSf6</ns1:name>
   <ns2:soilLayerParameterMember>
    <ns2:SoilLayerParameter ns1:fid="SoilLayerParameter205">
     <ns2:soilLayerLink xlink:href="#SoilLayer_mSfsld2"/>
     <ns2:xtief>5.0</ns2:xtief>
     <ns2:xret>true</ns2:xret>
    </ns2:SoilLayerParameter>
   </ns2:soilLayerParameterMember>
   <ns2:soilLayerParameterMember>
    <ns2:SoilLayerParameter ns1:fid="SoilLayerParameter206">
     <ns2:soilLayerLink xlink:href="#SoilLayer_mSfsld3"/>
     <ns2:xtief>5.0</ns2:xtief>
     <ns2:xret>true</ns2:xret>
    </ns2:SoilLayerParameter>
   </ns2:soilLayerParameterMember>
   <ns2:soilLayerParameterMember>
    <ns2:SoilLayerParameter ns1:fid="SoilLayerParameter207">
     <ns2:soilLayerLink xlink:href="#SoilLayer_mSfsld2"/>
     <ns2:xtief>5.0</ns2:xtief>
     <ns2:xret>false</ns2:xret>
    </ns2:SoilLayerParameter>
   </ns2:soilLayerParameterMember>
  </ns2:Soiltype>
 </ns2:soiltypeMember>
 <ns2:soiltypeMember>
  <ns2:Soiltype ns1:fid="Soiltype_5mSf5mSf7">
   <ns1:description>Falkengraben  feinsandiger Mittelsand über Prof. 7</ns1:description>
   <ns1:name>5mSf5mSf7</ns1:name>
   <ns2:soilLayerParameterMember>
    <ns2:SoilLayerParameter ns1:fid="SoilLayerParameter208">
     <ns2:soilLayerLink xlink:href="#SoilLayer_mSfsld2"/>
     <ns2:xtief>5.0</ns2:xtief>
     <ns2:xret>true</ns2:xret>
    </ns2:SoilLayerParameter>
   </ns2:soilLayerParameterMember>
   <ns2:soilLayerParameterMember>
    <ns2:SoilLayerParameter ns1:fid="SoilLayerParameter209">
     <ns2:soilLayerLink xlink:href="#SoilLayer_mSfsld3"/>
     <ns2:xtief>5.0</ns2:xtief>
     <ns2:xret>true</ns2:xret>
    </ns2:SoilLayerParameter>
   </ns2:soilLayerParameterMember>
   <ns2:soilLayerParameterMember>
    <ns2:SoilLayerParameter ns1:fid="SoilLayerParameter210">
     <ns2:soilLayerLink xlink:href="#SoilLayer_mSfsld2"/>
     <ns2:xtief>5.0</ns2:xtief>
     <ns2:xret>false</ns2:xret>
    </ns2:SoilLayerParameter>
   </ns2:soilLayerParameterMember>
  </ns2:Soiltype>
 </ns2:soiltypeMember>
 <ns2:soiltypeMember>
  <ns2:Soiltype ns1:fid="Soiltype_5Sl25Sl27">
   <ns1:description>Falkengraben  Schwach lehmiger Sand über Prof. 7</ns1:description>
   <ns1:name>5Sl25Sl27</ns1:name>
   <ns2:soilLayerParameterMember>
    <ns2:SoilLayerParameter ns1:fid="SoilLayerParameter211">
     <ns2:soilLayerLink xlink:href="#SoilLayer_Sl2ld2"/>
     <ns2:xtief>5.0</ns2:xtief>
     <ns2:xret>true</ns2:xret>
    </ns2:SoilLayerParameter>
   </ns2:soilLayerParameterMember>
   <ns2:soilLayerParameterMember>
    <ns2:SoilLayerParameter ns1:fid="SoilLayerParameter212">
     <ns2:soilLayerLink xlink:href="#SoilLayer_Sl2ld3"/>
     <ns2:xtief>5.0</ns2:xtief>
     <ns2:xret>true</ns2:xret>
    </ns2:SoilLayerParameter>
   </ns2:soilLayerParameterMember>
   <ns2:soilLayerParameterMember>
    <ns2:SoilLayerParameter ns1:fid="SoilLayerParameter213">
     <ns2:soilLayerLink xlink:href="#SoilLayer_mSfsld2"/>
     <ns2:xtief>5.0</ns2:xtief>
     <ns2:xret>false</ns2:xret>
    </ns2:SoilLayerParameter>
   </ns2:soilLayerParameterMember>
  </ns2:Soiltype>
 </ns2:soiltypeMember>
 <ns2:soiltypeMember>
  <ns2:Soiltype ns1:fid="Soiltype_5Sl35Sl31a">
   <ns1:description>Falkengraben  Mittellehmiger Sand über Prof. 1a</ns1:description>
   <ns1:name>5Sl35Sl31a</ns1:name>
   <ns2:soilLayerParameterMember>
    <ns2:SoilLayerParameter ns1:fid="SoilLayerParameter214">
     <ns2:soilLayerLink xlink:href="#SoilLayer_Sl3ld2"/>
     <ns2:xtief>5.0</ns2:xtief>
     <ns2:xret>true</ns2:xret>
    </ns2:SoilLayerParameter>
   </ns2:soilLayerParameterMember>
   <ns2:soilLayerParameterMember>
    <ns2:SoilLayerParameter ns1:fid="SoilLayerParameter215">
     <ns2:soilLayerLink xlink:href="#SoilLayer_Sl3ld3"/>
     <ns2:xtief>5.0</ns2:xtief>
     <ns2:xret>true</ns2:xret>
    </ns2:SoilLayerParameter>
   </ns2:soilLayerParameterMember>
   <ns2:soilLayerParameterMember>
    <ns2:SoilLayerParameter ns1:fid="SoilLayerParameter216">
     <ns2:soilLayerLink xlink:href="#SoilLayer_mSgsld2"/>
     <ns2:xtief>5.0</ns2:xtief>
     <ns2:xret>false</ns2:xret>
    </ns2:SoilLayerParameter>
   </ns2:soilLayerParameterMember>
  </ns2:Soiltype>
 </ns2:soiltypeMember>
 <ns2:soiltypeMember>
  <ns2:Soiltype ns1:fid="Soiltype_5Sl35Sl32a">
   <ns1:description>Falkengraben  Mittellehmiger Sand über Prof. 2a</ns1:description>
   <ns1:name>5Sl35Sl32a</ns1:name>
   <ns2:soilLayerParameterMember>
    <ns2:SoilLayerParameter ns1:fid="SoilLayerParameter217">
     <ns2:soilLayerLink xlink:href="#SoilLayer_Sl3ld2"/>
     <ns2:xtief>5.0</ns2:xtief>
     <ns2:xret>true</ns2:xret>
    </ns2:SoilLayerParameter>
   </ns2:soilLayerParameterMember>
   <ns2:soilLayerParameterMember>
    <ns2:SoilLayerParameter ns1:fid="SoilLayerParameter218">
     <ns2:soilLayerLink xlink:href="#SoilLayer_Sl3ld3"/>
     <ns2:xtief>5.0</ns2:xtief>
     <ns2:xret>true</ns2:xret>
    </ns2:SoilLayerParameter>
   </ns2:soilLayerParameterMember>
   <ns2:soilLayerParameterMember>
    <ns2:SoilLayerParameter ns1:fid="SoilLayerParameter219">
     <ns2:soilLayerLink xlink:href="#SoilLayer_mSfsld2"/>
     <ns2:xtief>5.0</ns2:xtief>
     <ns2:xret>false</ns2:xret>
    </ns2:SoilLayerParameter>
   </ns2:soilLayerParameterMember>
  </ns2:Soiltype>
 </ns2:soiltypeMember>
 <ns2:soiltypeMember>
  <ns2:Soiltype ns1:fid="Soiltype_5Sl35Sl33">
   <ns1:description>Falkengraben  Mittellehmiger Sand über Prof. 3</ns1:description>
   <ns1:name>5Sl35Sl33</ns1:name>
   <ns2:soilLayerParameterMember>
    <ns2:SoilLayerParameter ns1:fid="SoilLayerParameter220">
     <ns2:soilLayerLink xlink:href="#SoilLayer_Sl3ld2"/>
     <ns2:xtief>5.0</ns2:xtief>
     <ns2:xret>true</ns2:xret>
    </ns2:SoilLayerParameter>
   </ns2:soilLayerParameterMember>
   <ns2:soilLayerParameterMember>
    <ns2:SoilLayerParameter ns1:fid="SoilLayerParameter221">
     <ns2:soilLayerLink xlink:href="#SoilLayer_Sl3ld3"/>
     <ns2:xtief>5.0</ns2:xtief>
     <ns2:xret>true</ns2:xret>
    </ns2:SoilLayerParameter>
   </ns2:soilLayerParameterMember>
   <ns2:soilLayerParameterMember>
    <ns2:SoilLayerParameter ns1:fid="SoilLayerParameter222">
     <ns2:soilLayerLink xlink:href="#SoilLayer_mSfsld3"/>
     <ns2:xtief>5.0</ns2:xtief>
     <ns2:xret>false</ns2:xret>
    </ns2:SoilLayerParameter>
   </ns2:soilLayerParameterMember>
  </ns2:Soiltype>
 </ns2:soiltypeMember>
 <ns2:soiltypeMember>
  <ns2:Soiltype ns1:fid="Soiltype_5Su25mSf1a">
   <ns1:description>Falkengraben  Schw. schl. Sand Ã¼. feins. Mittelsand Ã¼ber Prof. 1a</ns1:description>
   <ns1:name>5Su25mSf1a</ns1:name>
   <ns2:soilLayerParameterMember>
    <ns2:SoilLayerParameter ns1:fid="SoilLayerParameter223">
     <ns2:soilLayerLink xlink:href="#SoilLayer_Su2ld2"/>
     <ns2:xtief>5.0</ns2:xtief>
     <ns2:xret>true</ns2:xret>
    </ns2:SoilLayerParameter>
   </ns2:soilLayerParameterMember>
   <ns2:soilLayerParameterMember>
    <ns2:SoilLayerParameter ns1:fid="SoilLayerParameter224">
     <ns2:soilLayerLink xlink:href="#SoilLayer_mSfsld3"/>
     <ns2:xtief>5.0</ns2:xtief>
     <ns2:xret>true</ns2:xret>
    </ns2:SoilLayerParameter>
   </ns2:soilLayerParameterMember>
   <ns2:soilLayerParameterMember>
    <ns2:SoilLayerParameter ns1:fid="SoilLayerParameter225">
     <ns2:soilLayerLink xlink:href="#SoilLayer_mSgsld2"/>
     <ns2:xtief>5.0</ns2:xtief>
     <ns2:xret>false</ns2:xret>
    </ns2:SoilLayerParameter>
   </ns2:soilLayerParameterMember>
  </ns2:Soiltype>
 </ns2:soiltypeMember>
 <ns2:soiltypeMember>
  <ns2:Soiltype ns1:fid="Soiltype_5Su25mSf1b">
   <ns1:description>Falkengraben  Schw. schl. Sand ü. feins. Mittelsand über Prof. 1b</ns1:description>
   <ns1:name>5Su25mSf1b</ns1:name>
   <ns2:soilLayerParameterMember>
    <ns2:SoilLayerParameter ns1:fid="SoilLayerParameter226">
     <ns2:soilLayerLink xlink:href="#SoilLayer_Su2ld2"/>
     <ns2:xtief>5.0</ns2:xtief>
     <ns2:xret>true</ns2:xret>
    </ns2:SoilLayerParameter>
   </ns2:soilLayerParameterMember>
   <ns2:soilLayerParameterMember>
    <ns2:SoilLayerParameter ns1:fid="SoilLayerParameter227">
     <ns2:soilLayerLink xlink:href="#SoilLayer_mSfsld3"/>
     <ns2:xtief>5.0</ns2:xtief>
     <ns2:xret>true</ns2:xret>
    </ns2:SoilLayerParameter>
   </ns2:soilLayerParameterMember>
   <ns2:soilLayerParameterMember>
    <ns2:SoilLayerParameter ns1:fid="SoilLayerParameter228">
     <ns2:soilLayerLink xlink:href="#SoilLayer_mSgsld2"/>
     <ns2:xtief>5.0</ns2:xtief>
     <ns2:xret>false</ns2:xret>
    </ns2:SoilLayerParameter>
   </ns2:soilLayerParameterMember>
  </ns2:Soiltype>
 </ns2:soiltypeMember>
 <ns2:soiltypeMember>
  <ns2:Soiltype ns1:fid="Soiltype_5Su25mSf2a">
   <ns1:description>Falkengraben  Schw. schl. Sand ü. feins. Mittelsand über Prof. 2a</ns1:description>
   <ns1:name>5Su25mSf2a</ns1:name>
   <ns2:soilLayerParameterMember>
    <ns2:SoilLayerParameter ns1:fid="SoilLayerParameter229">
     <ns2:soilLayerLink xlink:href="#SoilLayer_Su2ld2"/>
     <ns2:xtief>5.0</ns2:xtief>
     <ns2:xret>true</ns2:xret>
    </ns2:SoilLayerParameter>
   </ns2:soilLayerParameterMember>
   <ns2:soilLayerParameterMember>
    <ns2:SoilLayerParameter ns1:fid="SoilLayerParameter230">
     <ns2:soilLayerLink xlink:href="#SoilLayer_mSfsld3"/>
     <ns2:xtief>5.0</ns2:xtief>
     <ns2:xret>true</ns2:xret>
    </ns2:SoilLayerParameter>
   </ns2:soilLayerParameterMember>
   <ns2:soilLayerParameterMember>
    <ns2:SoilLayerParameter ns1:fid="SoilLayerParameter231">
     <ns2:soilLayerLink xlink:href="#SoilLayer_mSfsld2"/>
     <ns2:xtief>5.0</ns2:xtief>
     <ns2:xret>false</ns2:xret>
    </ns2:SoilLayerParameter>
   </ns2:soilLayerParameterMember>
  </ns2:Soiltype>
 </ns2:soiltypeMember>
 <ns2:soiltypeMember>
  <ns2:Soiltype ns1:fid="Soiltype_5Su25mSf3">
   <ns1:description>Falkengraben  Schw. schl. Sand ü. feins. Mittelsand über Prof. 3</ns1:description>
   <ns1:name>5Su25mSf3</ns1:name>
   <ns2:soilLayerParameterMember>
    <ns2:SoilLayerParameter ns1:fid="SoilLayerParameter232">
     <ns2:soilLayerLink xlink:href="#SoilLayer_Su2ld2"/>
     <ns2:xtief>5.0</ns2:xtief>
     <ns2:xret>true</ns2:xret>
    </ns2:SoilLayerParameter>
   </ns2:soilLayerParameterMember>
   <ns2:soilLayerParameterMember>
    <ns2:SoilLayerParameter ns1:fid="SoilLayerParameter233">
     <ns2:soilLayerLink xlink:href="#SoilLayer_mSfsld3"/>
     <ns2:xtief>5.0</ns2:xtief>
     <ns2:xret>true</ns2:xret>
    </ns2:SoilLayerParameter>
   </ns2:soilLayerParameterMember>
   <ns2:soilLayerParameterMember>
    <ns2:SoilLayerParameter ns1:fid="SoilLayerParameter234">
     <ns2:soilLayerLink xlink:href="#SoilLayer_mSfsld3"/>
     <ns2:xtief>5.0</ns2:xtief>
     <ns2:xret>false</ns2:xret>
    </ns2:SoilLayerParameter>
   </ns2:soilLayerParameterMember>
  </ns2:Soiltype>
 </ns2:soiltypeMember>
 <ns2:soiltypeMember>
  <ns2:Soiltype ns1:fid="Soiltype_5Su25mSf7">
   <ns1:description>Falkengraben  Schw. schl. Sand ü. feins. Mittelsand über Prof. 7</ns1:description>
   <ns1:name>5Su25mSf7</ns1:name>
   <ns2:soilLayerParameterMember>
    <ns2:SoilLayerParameter ns1:fid="SoilLayerParameter235">
     <ns2:soilLayerLink xlink:href="#SoilLayer_Su2ld2"/>
     <ns2:xtief>5.0</ns2:xtief>
     <ns2:xret>true</ns2:xret>
    </ns2:SoilLayerParameter>
   </ns2:soilLayerParameterMember>
   <ns2:soilLayerParameterMember>
    <ns2:SoilLayerParameter ns1:fid="SoilLayerParameter236">
     <ns2:soilLayerLink xlink:href="#SoilLayer_mSfsld3"/>
     <ns2:xtief>5.0</ns2:xtief>
     <ns2:xret>true</ns2:xret>
    </ns2:SoilLayerParameter>
   </ns2:soilLayerParameterMember>
   <ns2:soilLayerParameterMember>
    <ns2:SoilLayerParameter ns1:fid="SoilLayerParameter237">
     <ns2:soilLayerLink xlink:href="#SoilLayer_mSfsld2"/>
     <ns2:xtief>5.0</ns2:xtief>
     <ns2:xret>false</ns2:xret>
    </ns2:SoilLayerParameter>
   </ns2:soilLayerParameterMember>
  </ns2:Soiltype>
 </ns2:soiltypeMember>
 <ns2:soiltypeMember>
  <ns2:Soiltype ns1:fid="Soiltype_5Su25Su21a">
   <ns1:description>Falkengraben  Schwach schluffiger Sand über Prof. 1a</ns1:description>
   <ns1:name>5Su25Su21a</ns1:name>
   <ns2:soilLayerParameterMember>
    <ns2:SoilLayerParameter ns1:fid="SoilLayerParameter238">
     <ns2:soilLayerLink xlink:href="#SoilLayer_Su2ld2"/>
     <ns2:xtief>5.0</ns2:xtief>
     <ns2:xret>true</ns2:xret>
    </ns2:SoilLayerParameter>
   </ns2:soilLayerParameterMember>
   <ns2:soilLayerParameterMember>
    <ns2:SoilLayerParameter ns1:fid="SoilLayerParameter239">
     <ns2:soilLayerLink xlink:href="#SoilLayer_mSfsld3"/>
     <ns2:xtief>5.0</ns2:xtief>
     <ns2:xret>true</ns2:xret>
    </ns2:SoilLayerParameter>
   </ns2:soilLayerParameterMember>
   <ns2:soilLayerParameterMember>
    <ns2:SoilLayerParameter ns1:fid="SoilLayerParameter240">
     <ns2:soilLayerLink xlink:href="#SoilLayer_mSgsld2"/>
     <ns2:xtief>5.0</ns2:xtief>
     <ns2:xret>false</ns2:xret>
    </ns2:SoilLayerParameter>
   </ns2:soilLayerParameterMember>
  </ns2:Soiltype>
 </ns2:soiltypeMember>
 <ns2:soiltypeMember>
  <ns2:Soiltype ns1:fid="Soiltype_5Su25Su22a">
   <ns1:description>Falkengraben  Schwach schluffiger Sand über Prof. 2a</ns1:description>
   <ns1:name>5Su25Su22a</ns1:name>
   <ns2:soilLayerParameterMember>
    <ns2:SoilLayerParameter ns1:fid="SoilLayerParameter241">
     <ns2:soilLayerLink xlink:href="#SoilLayer_Su2ld2"/>
     <ns2:xtief>5.0</ns2:xtief>
     <ns2:xret>true</ns2:xret>
    </ns2:SoilLayerParameter>
   </ns2:soilLayerParameterMember>
   <ns2:soilLayerParameterMember>
    <ns2:SoilLayerParameter ns1:fid="SoilLayerParameter242">
     <ns2:soilLayerLink xlink:href="#SoilLayer_mSfsld3"/>
     <ns2:xtief>5.0</ns2:xtief>
     <ns2:xret>true</ns2:xret>
    </ns2:SoilLayerParameter>
   </ns2:soilLayerParameterMember>
   <ns2:soilLayerParameterMember>
    <ns2:SoilLayerParameter ns1:fid="SoilLayerParameter243">
     <ns2:soilLayerLink xlink:href="#SoilLayer_mSfsld3"/>
     <ns2:xtief>5.0</ns2:xtief>
     <ns2:xret>false</ns2:xret>
    </ns2:SoilLayerParameter>
   </ns2:soilLayerParameterMember>
  </ns2:Soiltype>
 </ns2:soiltypeMember>
 <ns2:soiltypeMember>
  <ns2:Soiltype ns1:fid="Soiltype_5Su25Su27">
   <ns1:description>Falkengraben  Schwach schluffiger Sand über Prof. 7</ns1:description>
   <ns1:name>5Su25Su27</ns1:name>
   <ns2:soilLayerParameterMember>
    <ns2:SoilLayerParameter ns1:fid="SoilLayerParameter244">
     <ns2:soilLayerLink xlink:href="#SoilLayer_Su2ld2"/>
     <ns2:xtief>5.0</ns2:xtief>
     <ns2:xret>true</ns2:xret>
    </ns2:SoilLayerParameter>
   </ns2:soilLayerParameterMember>
   <ns2:soilLayerParameterMember>
    <ns2:SoilLayerParameter ns1:fid="SoilLayerParameter245">
     <ns2:soilLayerLink xlink:href="#SoilLayer_mSfsld3"/>
     <ns2:xtief>5.0</ns2:xtief>
     <ns2:xret>true</ns2:xret>
    </ns2:SoilLayerParameter>
   </ns2:soilLayerParameterMember>
   <ns2:soilLayerParameterMember>
    <ns2:SoilLayerParameter ns1:fid="SoilLayerParameter246">
     <ns2:soilLayerLink xlink:href="#SoilLayer_mSfsld2"/>
     <ns2:xtief>5.0</ns2:xtief>
     <ns2:xret>false</ns2:xret>
    </ns2:SoilLayerParameter>
   </ns2:soilLayerParameterMember>
  </ns2:Soiltype>
 </ns2:soiltypeMember>
 <ns2:soiltypeMember>
  <ns2:Soiltype ns1:fid="Soiltype_2mSf8Hn6">
   <ns1:description>Falkengraben  feins. Mittelsand über Torf über Prof. 6</ns1:description>
   <ns1:name>2mSf8Hn6</ns1:name>
   <ns2:soilLayerParameterMember>
    <ns2:SoilLayerParameter ns1:fid="SoilLayerParameter247">
     <ns2:soilLayerLink xlink:href="#SoilLayer_mSfsld2"/>
     <ns2:xtief>2.0</ns2:xtief>
     <ns2:xret>true</ns2:xret>
    </ns2:SoilLayerParameter>
   </ns2:soilLayerParameterMember>
   <ns2:soilLayerParameterMember>
    <ns2:SoilLayerParameter ns1:fid="SoilLayerParameter248">
     <ns2:soilLayerLink xlink:href="#SoilLayer_Hnz4SV3"/>
     <ns2:xtief>8.0</ns2:xtief>
     <ns2:xret>true</ns2:xret>
    </ns2:SoilLayerParameter>
   </ns2:soilLayerParameterMember>
   <ns2:soilLayerParameterMember>
    <ns2:SoilLayerParameter ns1:fid="SoilLayerParameter249">
     <ns2:soilLayerLink xlink:href="#SoilLayer_mSfsld2"/>
     <ns2:xtief>5.0</ns2:xtief>
     <ns2:xret>false</ns2:xret>
    </ns2:SoilLayerParameter>
   </ns2:soilLayerParameterMember>
  </ns2:Soiltype>
 </ns2:soiltypeMember>
 <ns2:landuseMember>
  <ns2:Landuse ns1:fid="Landuse_BPlan_10">
   <ns1:description>Industriegebiet und Gewerbegebiet</ns1:description>
   <ns1:name>BPlan_10</ns1:name>
   <ns2:idealLandUsePeriodLink xlink:href="#IdealLandUse_1"/>
   <ns2:sealingLink xlink:href="#Sealing26"/>
  </ns2:Landuse>
 </ns2:landuseMember>
 <ns2:landuseMember>
  <ns2:Landuse ns1:fid="Landuse_BPlan_8">
   <ns1:description>Sondergebiet Erholung</ns1:description>
   <ns1:name>BPlan_08</ns1:name>
   <ns2:idealLandUsePeriodLink xlink:href="#IdealLandUse_1"/>
   <ns2:sealingLink xlink:href="#Sealing28"/>
  </ns2:Landuse>
 </ns2:landuseMember>
 <ns2:landuseMember>
  <ns2:Landuse ns1:fid="Landuse_BPlan_7">
   <ns1:description>Mischgebiet</ns1:description>
   <ns1:name>BPlan_07</ns1:name>
   <ns2:idealLandUsePeriodLink xlink:href="#IdealLandUse_1"/>
   <ns2:sealingLink xlink:href="#Sealing29"/>
  </ns2:Landuse>
 </ns2:landuseMember>
 <ns2:landuseMember>
  <ns2:Landuse ns1:fid="Landuse_BPlan_6">
   <ns1:description>Dorfgebiet</ns1:description>
   <ns1:name>BPlan_06</ns1:name>
   <ns2:idealLandUsePeriodLink xlink:href="#IdealLandUse_1"/>
   <ns2:sealingLink xlink:href="#Sealing28"/>
  </ns2:Landuse>
 </ns2:landuseMember>
 <ns2:landuseMember>
  <ns2:Landuse ns1:fid="Landuse_BPlan_5">
   <ns1:description>Besonders Wohngebiet</ns1:description>
   <ns1:name>BPlan_05</ns1:name>
   <ns2:idealLandUsePeriodLink xlink:href="#IdealLandUse_1"/>
   <ns2:sealingLink xlink:href="#Sealing29"/>
  </ns2:Landuse>
 </ns2:landuseMember>
 <ns2:landuseMember>
  <ns2:Landuse ns1:fid="Landuse_BPlan_4">
   <ns1:description>Allgemeines Wohngebiet</ns1:description>
   <ns1:name>BPlan_04</ns1:name>
   <ns2:idealLandUsePeriodLink xlink:href="#IdealLandUse_1"/>
   <ns2:sealingLink xlink:href="#Sealing29"/>
  </ns2:Landuse>
 </ns2:landuseMember>
 <ns2:landuseMember>
  <ns2:Landuse ns1:fid="Landuse_BPlan_3">
   <ns1:description>Reines Wohngebiet</ns1:description>
   <ns1:name>BPlan_03</ns1:name>
   <ns2:idealLandUsePeriodLink xlink:href="#IdealLandUse_1"/>
   <ns2:sealingLink xlink:href="#Sealing29"/>
  </ns2:Landuse>
 </ns2:landuseMember>
 <ns2:landuseMember>
  <ns2:Landuse ns1:fid="Landuse_BPlan_2">
   <ns1:description>Kleinsiedlungsgebiet</ns1:description>
   <ns1:name>BPlan_02</ns1:name>
   <ns2:idealLandUsePeriodLink xlink:href="#IdealLandUse_1"/>
   <ns2:sealingLink xlink:href="#Sealing27"/>
  </ns2:Landuse>
 </ns2:landuseMember>
 <ns2:landuseMember>
  <ns2:Landuse ns1:fid="Landuse_BPlan_1">
   <ns1:description>Kerngebiet</ns1:description>
   <ns1:name>BPlan_01</ns1:name>
   <ns2:idealLandUsePeriodLink xlink:href="#IdealLandUse_1"/>
   <ns2:sealingLink xlink:href="#Sealing30"/>
  </ns2:Landuse>
 </ns2:landuseMember>
 <ns2:landuseMember>
  <ns2:Landuse ns1:fid="Landuse_ALB_111">
   <ns1:description>Gebäude- und Freifläche;öffentliche Zwecke;öffentlich (Verwaltung)</ns1:description>
   <ns1:name>ALB_111</ns1:name>
   <ns2:idealLandUsePeriodLink xlink:href="#IdealLandUse_1"/>
   <ns2:sealingLink xlink:href="#Sealing7"/>
  </ns2:Landuse>
 </ns2:landuseMember>
 <ns2:landuseMember>
  <ns2:Landuse ns1:fid="Landuse_ALB_112">
   <ns1:description>Gebäude- und Freifläche;öffentliche Zwecke;öffentlich (Bildung und Forschung)</ns1:description>
   <ns1:name>ALB_112</ns1:name>
   <ns2:idealLandUsePeriodLink xlink:href="#IdealLandUse_1"/>
   <ns2:sealingLink xlink:href="#Sealing6"/>
  </ns2:Landuse>
 </ns2:landuseMember>
 <ns2:landuseMember>
  <ns2:Landuse ns1:fid="Landuse_ALB_113">
   <ns1:description>Gebäude- und Freifläche;öffentliche Zwecke;öffentlich (Kultur)</ns1:description>
   <ns1:name>ALB_113</ns1:name>
   <ns2:idealLandUsePeriodLink xlink:href="#IdealLandUse_1"/>
   <ns2:sealingLink xlink:href="#Sealing6"/>
  </ns2:Landuse>
 </ns2:landuseMember>
 <ns2:landuseMember>
  <ns2:Landuse ns1:fid="Landuse_ALB_114">
   <ns1:description>Gebäude- und Freifläche;öffentliche Zwecke;öffentlich (Kirche)</ns1:description>
   <ns1:name>ALB_114</ns1:name>
   <ns2:idealLandUsePeriodLink xlink:href="#IdealLandUse_1"/>
   <ns2:sealingLink xlink:href="#Sealing1"/>
  </ns2:Landuse>
 </ns2:landuseMember>
 <ns2:landuseMember>
  <ns2:Landuse ns1:fid="Landuse_ALB_115">
   <ns1:description>Gebäude- und Freifläche;öffentliche Zwecke;öffentlich (Gesundheit)</ns1:description>
   <ns1:name>ALB_115</ns1:name>
   <ns2:idealLandUsePeriodLink xlink:href="#IdealLandUse_1"/>
   <ns2:sealingLink xlink:href="#Sealing7"/>
  </ns2:Landuse>
 </ns2:landuseMember>
 <ns2:landuseMember>
  <ns2:Landuse ns1:fid="Landuse_ALB_116">
   <ns1:description>Gebäude- und Freifläche;öffentliche Zwecke;öffentlich (Soziales)</ns1:description>
   <ns1:name>ALB_116</ns1:name>
   <ns2:idealLandUsePeriodLink xlink:href="#IdealLandUse_1"/>
   <ns2:sealingLink xlink:href="#Sealing7"/>
  </ns2:Landuse>
 </ns2:landuseMember>
 <ns2:landuseMember>
  <ns2:Landuse ns1:fid="Landuse_ALB_117">
   <ns1:description>Gebäude- und Freifläche;öffentliche Zwecke;öffentlich (Sicherheit und Ordnung)</ns1:description>
   <ns1:name>ALB_117</ns1:name>
   <ns2:idealLandUsePeriodLink xlink:href="#IdealLandUse_1"/>
   <ns2:sealingLink xlink:href="#Sealing7"/>
  </ns2:Landuse>
 </ns2:landuseMember>
 <ns2:landuseMember>
  <ns2:Landuse ns1:fid="Landuse_ALB_118">
   <ns1:description>Gebäude- und Freifläche;öffentliche Zwecke;öffentlich (Friedhof)</ns1:description>
   <ns1:name>ALB_118</ns1:name>
   <ns2:idealLandUsePeriodLink xlink:href="#IdealLandUse_1"/>
   <ns2:sealingLink xlink:href="#Sealing12"/>
  </ns2:Landuse>
 </ns2:landuseMember>
 <ns2:landuseMember>
  <ns2:Landuse ns1:fid="Landuse_ALB_119">
   <ns1:description>Gebäude- und Freifläche;öffentliche Zwecke;öffentlich (andere Einrichtung)</ns1:description>
   <ns1:name>ALB_119</ns1:name>
   <ns2:idealLandUsePeriodLink xlink:href="#IdealLandUse_1"/>
   <ns2:sealingLink xlink:href="#Sealing6"/>
  </ns2:Landuse>
 </ns2:landuseMember>
 <ns2:landuseMember>
  <ns2:Landuse ns1:fid="Landuse_ALB_138">
   <ns1:description>Gebäude- und Freifläche;Wohnen;Wohnen (behelfsmäßig)</ns1:description>
   <ns1:name>ALB_138</ns1:name>
   <ns2:idealLandUsePeriodLink xlink:href="#IdealLandUse_1"/>
   <ns2:sealingLink xlink:href="#Sealing1"/>
  </ns2:Landuse>
 </ns2:landuseMember>
 <ns2:landuseMember>
  <ns2:Landuse ns1:fid="Landuse_ALB_139_1">
   <ns1:description>Gebäude- und Freifläche;Wohnen;Wohnen</ns1:description>
   <ns1:name>ALB_139_1</ns1:name>
   <ns2:idealLandUsePeriodLink xlink:href="#IdealLandUse_1"/>
   <ns2:sealingLink xlink:href="#Sealing1"/>
  </ns2:Landuse>
 </ns2:landuseMember>
 <ns2:landuseMember>
  <ns2:Landuse ns1:fid="Landuse_ALB_139_2">
   <ns1:description>Gebäude- und Freifläche;Wohnen;Wohnen</ns1:description>
   <ns1:name>ALB_139_2</ns1:name>
   <ns2:idealLandUsePeriodLink xlink:href="#IdealLandUse_1"/>
   <ns2:sealingLink xlink:href="#Sealing2"/>
  </ns2:Landuse>
 </ns2:landuseMember>
 <ns2:landuseMember>
  <ns2:Landuse ns1:fid="Landuse_ALB_139-3">
   <ns1:description>Gebäude- und Freifläche;Wohnen;Wohnen</ns1:description>
   <ns1:name>ALB_139_3</ns1:name>
   <ns2:idealLandUsePeriodLink xlink:href="#IdealLandUse_1"/>
   <ns2:sealingLink xlink:href="#Sealing3"/>
  </ns2:Landuse>
 </ns2:landuseMember>
 <ns2:landuseMember>
  <ns2:Landuse ns1:fid="Landuse_ALB_139_4">
   <ns1:description>Gebäude- und Freifläche;Wohnen;Wohnen</ns1:description>
   <ns1:name>ALB_139_4</ns1:name>
   <ns2:idealLandUsePeriodLink xlink:href="#IdealLandUse_1"/>
   <ns2:sealingLink xlink:href="#Sealing4"/>
  </ns2:Landuse>
 </ns2:landuseMember>
 <ns2:landuseMember>
  <ns2:Landuse ns1:fid="Landuse_ALB_139_5">
   <ns1:description>Gebäude- und Freifläche;Wohnen;Wohnen</ns1:description>
   <ns1:name>ALB_139_5</ns1:name>
   <ns2:idealLandUsePeriodLink xlink:href="#IdealLandUse_1"/>
   <ns2:sealingLink xlink:href="#Sealing5"/>
  </ns2:Landuse>
 </ns2:landuseMember>
 <ns2:landuseMember>
  <ns2:Landuse ns1:fid="Landuse_ALB_140">
   <ns1:description>Gebäude- und Freifläche;Handel und Dienstleistungen;Handel und Dienstleistungen</ns1:description>
   <ns1:name>ALB_140</ns1:name>
   <ns2:idealLandUsePeriodLink xlink:href="#IdealLandUse_1"/>
   <ns2:sealingLink xlink:href="#Sealing9"/>
  </ns2:Landuse>
 </ns2:landuseMember>
 <ns2:landuseMember>
  <ns2:Landuse ns1:fid="Landuse_ALB_141">
   <ns1:description>Gebäude- und Freifläche;Handel und Dienstleistungen;Handel und Dienstl.(Verw.,freie Berufe)</ns1:description>
   <ns1:name>ALB_141</ns1:name>
   <ns2:idealLandUsePeriodLink xlink:href="#IdealLandUse_1"/>
   <ns2:sealingLink xlink:href="#Sealing9"/>
  </ns2:Landuse>
 </ns2:landuseMember>
 <ns2:landuseMember>
  <ns2:Landuse ns1:fid="Landuse_ALB_142">
   <ns1:description>Gebäude- und Freifläche;Handel und Dienstleistungen;Handel und Dienstleistungen (Bank,Kredit)</ns1:description>
   <ns1:name>ALB_142</ns1:name>
   <ns2:idealLandUsePeriodLink xlink:href="#IdealLandUse_1"/>
   <ns2:sealingLink xlink:href="#Sealing9"/>
  </ns2:Landuse>
 </ns2:landuseMember>
 <ns2:landuseMember>
  <ns2:Landuse ns1:fid="Landuse_ALB_143">
   <ns1:description>Gebäude- und Freifläche;Handel und Dienstleistungen;Handel und Dienstleistungen(Versicherung)</ns1:description>
   <ns1:name>ALB_143</ns1:name>
   <ns2:idealLandUsePeriodLink xlink:href="#IdealLandUse_1"/>
   <ns2:sealingLink xlink:href="#Sealing9"/>
  </ns2:Landuse>
 </ns2:landuseMember>
 <ns2:landuseMember>
  <ns2:Landuse ns1:fid="Landuse_ALB_144">
   <ns1:description>Gebäude- und Freifläche;Handel und Dienstleistungen;Handel und Dienstleistungen (Handel)</ns1:description>
   <ns1:name>ALB_144</ns1:name>
   <ns2:idealLandUsePeriodLink xlink:href="#IdealLandUse_1"/>
   <ns2:sealingLink xlink:href="#Sealing9"/>
  </ns2:Landuse>
 </ns2:landuseMember>
 <ns2:landuseMember>
  <ns2:Landuse ns1:fid="Landuse_ALB_145">
   <ns1:description>Gebäude- und Freifläche;Handel und Dienstleistungen;Handel und Dienstl. (Messe, Ausstellung)</ns1:description>
   <ns1:name>ALB_145</ns1:name>
   <ns2:idealLandUsePeriodLink xlink:href="#IdealLandUse_1"/>
   <ns2:sealingLink xlink:href="#Sealing9"/>
  </ns2:Landuse>
 </ns2:landuseMember>
 <ns2:landuseMember>
  <ns2:Landuse ns1:fid="Landuse_ALB_146">
   <ns1:description>Gebäude- und Freifläche;Handel und Dienstleistungen;Handel und Dienstleistungen(Beherbergung)</ns1:description>
   <ns1:name>ALB_146</ns1:name>
   <ns2:idealLandUsePeriodLink xlink:href="#IdealLandUse_1"/>
   <ns2:sealingLink xlink:href="#Sealing9"/>
  </ns2:Landuse>
 </ns2:landuseMember>
 <ns2:landuseMember>
  <ns2:Landuse ns1:fid="Landuse_ALB_147">
   <ns1:description>Gebäude- und Freifläche;Handel und Dienstleistungen;Handel und Dienstleistungen(Restauration)</ns1:description>
   <ns1:name>ALB_147</ns1:name>
   <ns2:idealLandUsePeriodLink xlink:href="#IdealLandUse_1"/>
   <ns2:sealingLink xlink:href="#Sealing9"/>
  </ns2:Landuse>
 </ns2:landuseMember>
 <ns2:landuseMember>
  <ns2:Landuse ns1:fid="Landuse_ALB_148">
   <ns1:description>Gebäude- und Freifläche;Handel und Dienstleistungen;Handel und Dienstleistungen (Vergnügung)</ns1:description>
   <ns1:name>ALB_148</ns1:name>
   <ns2:idealLandUsePeriodLink xlink:href="#IdealLandUse_1"/>
   <ns2:sealingLink xlink:href="#Sealing9"/>
  </ns2:Landuse>
 </ns2:landuseMember>
 <ns2:landuseMember>
  <ns2:Landuse ns1:fid="Landuse_ALB_149">
   <ns1:description>Gebäude- und Freifläche;Handel und Dienstleistungen;Handel und Dienstl.(andere Einrichtung)</ns1:description>
   <ns1:name>ALB_149</ns1:name>
   <ns2:idealLandUsePeriodLink xlink:href="#IdealLandUse_1"/>
   <ns2:sealingLink xlink:href="#Sealing9"/>
  </ns2:Landuse>
 </ns2:landuseMember>
 <ns2:landuseMember>
  <ns2:Landuse ns1:fid="Landuse_ALB_170">
   <ns1:description>Gebäude- und Freifläche;Gewerbe und Industrie;Gewerbe und Industrie</ns1:description>
   <ns1:name>ALB_170</ns1:name>
   <ns2:idealLandUsePeriodLink xlink:href="#IdealLandUse_1"/>
   <ns2:sealingLink xlink:href="#Sealing8"/>
  </ns2:Landuse>
 </ns2:landuseMember>
 <ns2:landuseMember>
  <ns2:Landuse ns1:fid="Landuse_ALB_171">
   <ns1:description>Gebäude- und Freifläche;Gewerbe und Industrie;Gewerbe und Industrie (Produktion)</ns1:description>
   <ns1:name>ALB_171</ns1:name>
   <ns2:idealLandUsePeriodLink xlink:href="#IdealLandUse_1"/>
   <ns2:sealingLink xlink:href="#Sealing8"/>
  </ns2:Landuse>
 </ns2:landuseMember>
 <ns2:landuseMember>
  <ns2:Landuse ns1:fid="Landuse_ALB_172">
   <ns1:description>Gebäude- und Freifläche;Gewerbe und Industrie;Gewerbe und Industrie (Handwerk)</ns1:description>
   <ns1:name>ALB_172</ns1:name>
   <ns2:idealLandUsePeriodLink xlink:href="#IdealLandUse_1"/>
   <ns2:sealingLink xlink:href="#Sealing8"/>
  </ns2:Landuse>
 </ns2:landuseMember>
 <ns2:landuseMember>
  <ns2:Landuse ns1:fid="Landuse_ALB_173">
   <ns1:description>Gebäude- und Freifläche;Gewerbe und Industrie;Gewerbe und Industrie (Tankstelle)</ns1:description>
   <ns1:name>ALB_173</ns1:name>
   <ns2:idealLandUsePeriodLink xlink:href="#IdealLandUse_1"/>
   <ns2:sealingLink xlink:href="#Sealing8"/>
  </ns2:Landuse>
 </ns2:landuseMember>
 <ns2:landuseMember>
  <ns2:Landuse ns1:fid="Landuse_ALB_174">
   <ns1:description>Gebäude- und Freifläche;Gewerbe und Industrie;Gewerbe und Industrie (Lagerung)</ns1:description>
   <ns1:name>ALB_174</ns1:name>
   <ns2:idealLandUsePeriodLink xlink:href="#IdealLandUse_1"/>
   <ns2:sealingLink xlink:href="#Sealing8"/>
  </ns2:Landuse>
 </ns2:landuseMember>
 <ns2:landuseMember>
  <ns2:Landuse ns1:fid="Landuse_ALB_175">
   <ns1:description>Gebäude- und Freifläche;Gewerbe und Industrie;Gewerbe und Industrie (Transport)</ns1:description>
   <ns1:name>ALB_175</ns1:name>
   <ns2:idealLandUsePeriodLink xlink:href="#IdealLandUse_1"/>
   <ns2:sealingLink xlink:href="#Sealing8"/>
  </ns2:Landuse>
 </ns2:landuseMember>
 <ns2:landuseMember>
  <ns2:Landuse ns1:fid="Landuse_ALB_176">
   <ns1:description>Gebäude- und Freifläche;Gewerbe und Industrie;Gewerbe und Industrie (Forschung)</ns1:description>
   <ns1:name>ALB_176</ns1:name>
   <ns2:idealLandUsePeriodLink xlink:href="#IdealLandUse_1"/>
   <ns2:sealingLink xlink:href="#Sealing8"/>
  </ns2:Landuse>
 </ns2:landuseMember>
 <ns2:landuseMember>
  <ns2:Landuse ns1:fid="Landuse_ALB_177">
   <ns1:description>Gebäude- und Freifläche;Gewerbe und Industrie;Gewerbe und Industrie (Grundstoff)</ns1:description>
   <ns1:name>ALB_177</ns1:name>
   <ns2:idealLandUsePeriodLink xlink:href="#IdealLandUse_1"/>
   <ns2:sealingLink xlink:href="#Sealing8"/>
  </ns2:Landuse>
 </ns2:landuseMember>
 <ns2:landuseMember>
  <ns2:Landuse ns1:fid="Landuse_ALB_178">
   <ns1:description>Gebäude- und Freifläche;Gewerbe und Industrie;Gewerbe und Industrie (Sozialeinrichtung)</ns1:description>
   <ns1:name>ALB_178</ns1:name>
   <ns2:idealLandUsePeriodLink xlink:href="#IdealLandUse_1"/>
   <ns2:sealingLink xlink:href="#Sealing8"/>
  </ns2:Landuse>
 </ns2:landuseMember>
 <ns2:landuseMember>
  <ns2:Landuse ns1:fid="Landuse_ALB_179">
   <ns1:description>Gebäude und Freifläche;Gewerbe und Industrie;Gewerbe und Industrie(andere Einrichtung)</ns1:description>
   <ns1:name>ALB_179</ns1:name>
   <ns2:idealLandUsePeriodLink xlink:href="#IdealLandUse_1"/>
   <ns2:sealingLink xlink:href="#Sealing8"/>
  </ns2:Landuse>
 </ns2:landuseMember>
 <ns2:landuseMember>
  <ns2:Landuse ns1:fid="Landuse_ALB_200">
   <ns1:description>Gebäude- und Freifläche</ns1:description>
   <ns1:name>ALB_200</ns1:name>
   <ns2:idealLandUsePeriodLink xlink:href="#IdealLandUse_1"/>
   <ns2:sealingLink xlink:href="#Sealing9"/>
  </ns2:Landuse>
 </ns2:landuseMember>
 <ns2:landuseMember>
  <ns2:Landuse ns1:fid="Landuse_ALB_211">
   <ns1:description>Gebäude- und Freifläche;Mischnutzung mit Wohnen;Mischnutzung mit Wohnen(Wohnen m.öffentl)</ns1:description>
   <ns1:name>ALB_211</ns1:name>
   <ns2:idealLandUsePeriodLink xlink:href="#IdealLandUse_1"/>
   <ns2:sealingLink xlink:href="#Sealing4"/>
  </ns2:Landuse>
 </ns2:landuseMember>
 <ns2:landuseMember>
  <ns2:Landuse ns1:fid="Landuse_ALB_212">
   <ns1:description>Gebäude- und Freifläche;Mischnutzung mit Wohnen;Mischnutz.Wohnen(Wohnen/Handel/Dienstl.)</ns1:description>
   <ns1:name>ALB_212</ns1:name>
   <ns2:idealLandUsePeriodLink xlink:href="#IdealLandUse_1"/>
   <ns2:sealingLink xlink:href="#Sealing9"/>
  </ns2:Landuse>
 </ns2:landuseMember>
 <ns2:landuseMember>
  <ns2:Landuse ns1:fid="Landuse_ALB_213">
   <ns1:description>Gebäude- und Freifläche;Mischnutzung mit Wohnen;Mischnutz.Wohnen(Wohnen/Gewerbe/Industr.)</ns1:description>
   <ns1:name>ALB_213</ns1:name>
   <ns2:idealLandUsePeriodLink xlink:href="#IdealLandUse_1"/>
   <ns2:sealingLink xlink:href="#Sealing9"/>
  </ns2:Landuse>
 </ns2:landuseMember>
 <ns2:landuseMember>
  <ns2:Landuse ns1:fid="Landuse_ALB_216">
   <ns1:description>Gebäude- und Freifläche;Mischnutzung mit Wohnen;Mischnutz.Wohnen(Gewerbe/Industr./Wohnen)</ns1:description>
   <ns1:name>ALB_216</ns1:name>
   <ns2:idealLandUsePeriodLink xlink:href="#IdealLandUse_1"/>
   <ns2:sealingLink xlink:href="#Sealing9"/>
  </ns2:Landuse>
 </ns2:landuseMember>
 <ns2:landuseMember>
  <ns2:Landuse ns1:fid="Landuse_ALB_219">
   <ns1:description>Gebäude- und Freifläche;Mischnutzung mit Wohnen;Mischnutz.m.Wohnen(and.Mischn.m.Wohnen)</ns1:description>
   <ns1:name>ALB_219</ns1:name>
   <ns2:idealLandUsePeriodLink xlink:href="#IdealLandUse_1"/>
   <ns2:sealingLink xlink:href="#Sealing5"/>
  </ns2:Landuse>
 </ns2:landuseMember>
 <ns2:landuseMember>
  <ns2:Landuse ns1:fid="Landuse_ALB_231">
   <ns1:description>Gebäude- und Freifläche;zu Verkehrsanlagen;zu Verkehrsanlagen (Straße)</ns1:description>
   <ns1:name>ALB_231</ns1:name>
   <ns2:idealLandUsePeriodLink xlink:href="#IdealLandUse_2"/>
   <ns2:sealingLink xlink:href="#Sealing19"/>
  </ns2:Landuse>
 </ns2:landuseMember>
 <ns2:landuseMember>
  <ns2:Landuse ns1:fid="Landuse_ALB_232">
   <ns1:description>Gebäude- und Freifläche;zu Verkehrsanlagen;zu Verkehrsanlagen (Schiene)</ns1:description>
   <ns1:name>ALB_232</ns1:name>
   <ns2:idealLandUsePeriodLink xlink:href="#IdealLandUse_1"/>
   <ns2:sealingLink xlink:href="#Sealing11"/>
  </ns2:Landuse>
 </ns2:landuseMember>
 <ns2:landuseMember>
  <ns2:Landuse ns1:fid="Landuse_ALB_233">
   <ns1:description>Gebäude- und Freifläche;zu Verkehrsanlagen;zu Verkehrsanlagen (Luftfahrt)</ns1:description>
   <ns1:name>ALB_233</ns1:name>
   <ns2:idealLandUsePeriodLink xlink:href="#IdealLandUse_1"/>
   <ns2:sealingLink xlink:href="#Sealing25"/>
  </ns2:Landuse>
 </ns2:landuseMember>
 <ns2:landuseMember>
  <ns2:Landuse ns1:fid="Landuse_ALB_236">
   <ns1:description>Gebäude- und Freifläche;zu Verkehrsanlagen;zu Verkehrsanlagen (Parken)</ns1:description>
   <ns1:name>ALB_236</ns1:name>
   <ns2:idealLandUsePeriodLink xlink:href="#IdealLandUse_2"/>
   <ns2:sealingLink xlink:href="#Sealing19"/>
  </ns2:Landuse>
 </ns2:landuseMember>
 <ns2:landuseMember>
  <ns2:Landuse ns1:fid="Landuse_ALB_251">
   <ns1:description>Gebäude- und Freifläche;zu Versorgungsanlagen;zu Versorgungsanlagen (Wasser)</ns1:description>
   <ns1:name>ALB_251</ns1:name>
   <ns2:idealLandUsePeriodLink xlink:href="#IdealLandUse_1"/>
   <ns2:sealingLink xlink:href="#Sealing17"/>
  </ns2:Landuse>
 </ns2:landuseMember>
 <ns2:landuseMember>
  <ns2:Landuse ns1:fid="Landuse_ALB_252">
   <ns1:description>Gebäude- und Freifläche;zu Versorgungsanlagen;zu Versorgungsanlagen (Elektrizität)</ns1:description>
   <ns1:name>ALB_252</ns1:name>
   <ns2:idealLandUsePeriodLink xlink:href="#IdealLandUse_1"/>
   <ns2:sealingLink xlink:href="#Sealing12"/>
  </ns2:Landuse>
 </ns2:landuseMember>
 <ns2:landuseMember>
  <ns2:Landuse ns1:fid="Landuse_ALB_254">
   <ns1:description>Gebäude- und Freifläche;zu Versorgungsanlagen;zu Versorgungsanlagen(Funk- u. Fernmeld.)</ns1:description>
   <ns1:name>ALB_254</ns1:name>
   <ns2:idealLandUsePeriodLink xlink:href="#IdealLandUse_1"/>
   <ns2:sealingLink xlink:href="#Sealing8"/>
  </ns2:Landuse>
 </ns2:landuseMember>
 <ns2:landuseMember>
  <ns2:Landuse ns1:fid="Landuse_ALB_259">
   <ns1:description>Gebäude- und Freifläche;zu Versorgungsanlagen;zu Versorgungsanlagen (andere Vers.anl.)</ns1:description>
   <ns1:name>ALB_259</ns1:name>
   <ns2:idealLandUsePeriodLink xlink:href="#IdealLandUse_1"/>
   <ns2:sealingLink xlink:href="#Sealing8"/>
  </ns2:Landuse>
 </ns2:landuseMember>
 <ns2:landuseMember>
  <ns2:Landuse ns1:fid="Landuse_ALB_261">
   <ns1:description>Gebäude- und Freifläche;zu Entsorgungsanlagen;zu Entsorgungsanl. (Abwasserbeseitigung)</ns1:description>
   <ns1:name>ALB_261</ns1:name>
   <ns2:idealLandUsePeriodLink xlink:href="#IdealLandUse_1"/>
   <ns2:sealingLink xlink:href="#Sealing8"/>
  </ns2:Landuse>
 </ns2:landuseMember>
 <ns2:landuseMember>
  <ns2:Landuse ns1:fid="Landuse_ALB_262">
   <ns1:description>Gebäude- und Freifläche;zu Entsorgungsanlagen;zu Entsorgungsanlagen (Abfallbeseitigung)</ns1:description>
   <ns1:name>ALB_262</ns1:name>
   <ns2:idealLandUsePeriodLink xlink:href="#IdealLandUse_1"/>
   <ns2:sealingLink xlink:href="#Sealing8"/>
  </ns2:Landuse>
 </ns2:landuseMember>
 <ns2:landuseMember>
  <ns2:Landuse ns1:fid="Landuse_ALB_269">
   <ns1:description>Gebäude- und Freifläche;zu Entsorgungsanlagen;zu Entsorgungsanlagen(andere Ents.anl.)</ns1:description>
   <ns1:name>ALB_269</ns1:name>
   <ns2:idealLandUsePeriodLink xlink:href="#IdealLandUse_1"/>
   <ns2:sealingLink xlink:href="#Sealing8"/>
  </ns2:Landuse>
 </ns2:landuseMember>
 <ns2:landuseMember>
  <ns2:Landuse ns1:fid="Landuse_ALB_271">
   <ns1:description>Gebäude- und Freifläche;Land- und Forstwirtschaft;Land- und Forstwirtschaft (Wohnen)</ns1:description>
   <ns1:name>ALB_271</ns1:name>
   <ns2:idealLandUsePeriodLink xlink:href="#IdealLandUse_1"/>
   <ns2:sealingLink xlink:href="#Sealing2"/>
  </ns2:Landuse>
 </ns2:landuseMember>
 <ns2:landuseMember>
  <ns2:Landuse ns1:fid="Landuse_ALB_272">
   <ns1:description>Gebäude- und Freifläche;Land- und Forstwirtschaft;Land- und Forstwirtschaft (Betrieb)</ns1:description>
   <ns1:name>ALB_272</ns1:name>
   <ns2:idealLandUsePeriodLink xlink:href="#IdealLandUse_1"/>
   <ns2:sealingLink xlink:href="#Sealing9"/>
  </ns2:Landuse>
 </ns2:landuseMember>
 <ns2:landuseMember>
  <ns2:Landuse ns1:fid="Landuse_ALB_273">
   <ns1:description>Gebäude- und Freifläche;Land- und Forstwirtschaft;Land- u.Forstwirtsch.(Wohnen/Betrieb)</ns1:description>
   <ns1:name>ALB_273</ns1:name>
   <ns2:idealLandUsePeriodLink xlink:href="#IdealLandUse_1"/>
   <ns2:sealingLink xlink:href="#Sealing9"/>
  </ns2:Landuse>
 </ns2:landuseMember>
 <ns2:landuseMember>
  <ns2:Landuse ns1:fid="Landuse_ALB_274">
   <ns1:description>Gebäude- und Freifläche;Land- und Forstwirtschaft;Land- und Forstwirtschaft (Gewächshaus)</ns1:description>
   <ns1:name>ALB_274</ns1:name>
   <ns2:idealLandUsePeriodLink xlink:href="#IdealLandUse_1"/>
   <ns2:sealingLink xlink:href="#Sealing9"/>
  </ns2:Landuse>
 </ns2:landuseMember>
 <ns2:landuseMember>
  <ns2:Landuse ns1:fid="Landuse_ALB_279">
   <ns1:description>Gebäude- und Freifläche;Land- und Forstwirtschaft;Land- u.Forstwirtsch.(andere Einrichtung)</ns1:description>
   <ns1:name>ALB_279</ns1:name>
   <ns2:idealLandUsePeriodLink xlink:href="#IdealLandUse_5"/>
   <ns2:sealingLink xlink:href="#Sealing16"/>
  </ns2:Landuse>
 </ns2:landuseMember>
 <ns2:landuseMember>
  <ns2:Landuse ns1:fid="Landuse_ALB_281">
   <ns1:description>Gebäude- und Freifläche;Erholung;Erholung (Sport)</ns1:description>
   <ns1:name>ALB_281</ns1:name>
   <ns2:idealLandUsePeriodLink xlink:href="#IdealLandUse_1"/>
   <ns2:sealingLink xlink:href="#Sealing10"/>
  </ns2:Landuse>
 </ns2:landuseMember>
 <ns2:landuseMember>
  <ns2:Landuse ns1:fid="Landuse_ALB_282">
   <ns1:description>Gebäude- und Freifläche;Erholung;Erholung (Bad)</ns1:description>
   <ns1:name>ALB_282</ns1:name>
   <ns2:idealLandUsePeriodLink xlink:href="#IdealLandUse_1"/>
   <ns2:sealingLink xlink:href="#Sealing9"/>
  </ns2:Landuse>
 </ns2:landuseMember>
 <ns2:landuseMember>
  <ns2:Landuse ns1:fid="Landuse_ALB_283">
   <ns1:description>Gebäude- und Freifläche;Erholung;Erholung (Stadion)</ns1:description>
   <ns1:name>ALB_283</ns1:name>
   <ns2:idealLandUsePeriodLink xlink:href="#IdealLandUse_1"/>
   <ns2:sealingLink xlink:href="#Sealing10"/>
  </ns2:Landuse>
 </ns2:landuseMember>
 <ns2:landuseMember>
  <ns2:Landuse ns1:fid="Landuse_ALB_284">
   <ns1:description>Gebäude- und Freifläche;Erholung;Erholung (Kur)</ns1:description>
   <ns1:name>ALB_284</ns1:name>
   <ns2:idealLandUsePeriodLink xlink:href="#IdealLandUse_1"/>
   <ns2:sealingLink xlink:href="#Sealing6"/>
  </ns2:Landuse>
 </ns2:landuseMember>
 <ns2:landuseMember>
  <ns2:Landuse ns1:fid="Landuse_ALB_286">
   <ns1:description>Gebäude- und Freifläche;Erholung;Erholung (Wochenendhaus)</ns1:description>
   <ns1:name>ALB_286</ns1:name>
   <ns2:idealLandUsePeriodLink xlink:href="#IdealLandUse_1"/>
   <ns2:sealingLink xlink:href="#Sealing12"/>
  </ns2:Landuse>
 </ns2:landuseMember>
 <ns2:landuseMember>
  <ns2:Landuse ns1:fid="Landuse_ALB_287">
   <ns1:description>Gebäude- und Freifläche;Erholung;Erholung (Zoologie)</ns1:description>
   <ns1:name>ALB_287</ns1:name>
   <ns2:idealLandUsePeriodLink xlink:href="#IdealLandUse_1"/>
   <ns2:sealingLink xlink:href="#Sealing12"/>
  </ns2:Landuse>
 </ns2:landuseMember>
 <ns2:landuseMember>
  <ns2:Landuse ns1:fid="Landuse_ALB_289">
   <ns1:description>Gebäude- und Freifläche;Erholung;Erholung (andere Erholungseinrichtung)</ns1:description>
   <ns1:name>ALB_289</ns1:name>
   <ns2:idealLandUsePeriodLink xlink:href="#IdealLandUse_1"/>
   <ns2:sealingLink xlink:href="#Sealing12"/>
  </ns2:Landuse>
 </ns2:landuseMember>
 <ns2:landuseMember>
  <ns2:Landuse ns1:fid="Landuse_ALB_291">
   <ns1:description>Gebäude- und Freifläche;ungenutzt;ungenutzt (Bauplatz)</ns1:description>
   <ns1:name>ALB_291</ns1:name>
   <ns2:idealLandUsePeriodLink xlink:href="#IdealLandUse_1"/>
   <ns2:sealingLink xlink:href="#Sealing12"/>
  </ns2:Landuse>
 </ns2:landuseMember>
 <ns2:landuseMember>
  <ns2:Landuse ns1:fid="Landuse_ALB_292">
   <ns1:description>Gebäude- und Freifläche;ungenutzt;ungenutzt(Fläche mit ungenutztem Gebäude)</ns1:description>
   <ns1:name>ALB_292</ns1:name>
   <ns2:idealLandUsePeriodLink xlink:href="#IdealLandUse_1"/>
   <ns2:sealingLink xlink:href="#Sealing12"/>
  </ns2:Landuse>
 </ns2:landuseMember>
 <ns2:landuseMember>
  <ns2:Landuse ns1:fid="Landuse_ALB_299">
   <ns1:description>Gebäude- und Freifläche;ungenutzt;ungenutzt (andere Freifläche)</ns1:description>
   <ns1:name>ALB_299</ns1:name>
   <ns2:idealLandUsePeriodLink xlink:href="#IdealLandUse_1"/>
   <ns2:sealingLink xlink:href="#Sealing12"/>
  </ns2:Landuse>
 </ns2:landuseMember>
 <ns2:landuseMember>
  <ns2:Landuse ns1:fid="Landuse_ALB_311">
   <ns1:description>Betriebsfläche;Abbauland;Abbauland (Sand)</ns1:description>
   <ns1:name>ALB_311</ns1:name>
   <ns2:idealLandUsePeriodLink xlink:href="#IdealLandUse_4"/>
   <ns2:sealingLink xlink:href="#Sealing14"/>
  </ns2:Landuse>
 </ns2:landuseMember>
 <ns2:landuseMember>
  <ns2:Landuse ns1:fid="Landuse_ALB_312">
   <ns1:description>Betriebsfläche;Abbauland;Abbauland (Kies)</ns1:description>
   <ns1:name>ALB_312</ns1:name>
   <ns2:idealLandUsePeriodLink xlink:href="#IdealLandUse_4"/>
   <ns2:sealingLink xlink:href="#Sealing14"/>
  </ns2:Landuse>
 </ns2:landuseMember>
 <ns2:landuseMember>
  <ns2:Landuse ns1:fid="Landuse_ALB_321">
   <ns1:description>Betriebsfläche;Halde;Halde (Erde)</ns1:description>
   <ns1:name>ALB_321</ns1:name>
   <ns2:idealLandUsePeriodLink xlink:href="#IdealLandUse_4"/>
   <ns2:sealingLink xlink:href="#Sealing14"/>
  </ns2:Landuse>
 </ns2:landuseMember>
 <ns2:landuseMember>
  <ns2:Landuse ns1:fid="Landuse_ALB_324">
   <ns1:description>Betriebsfläche;Halde;Halde (Abraum)</ns1:description>
   <ns1:name>ALB_324</ns1:name>
   <ns2:idealLandUsePeriodLink xlink:href="#IdealLandUse_4"/>
   <ns2:sealingLink xlink:href="#Sealing14"/>
  </ns2:Landuse>
 </ns2:landuseMember>
 <ns2:landuseMember>
  <ns2:Landuse ns1:fid="Landuse_ALB_329">
   <ns1:description>Betriebsfläche;Halde;Halde (andere Aufschüttung)</ns1:description>
   <ns1:name>ALB_329</ns1:name>
   <ns2:idealLandUsePeriodLink xlink:href="#IdealLandUse_6"/>
   <ns2:sealingLink xlink:href="#Sealing15"/>
  </ns2:Landuse>
 </ns2:landuseMember>
 <ns2:landuseMember>
  <ns2:Landuse ns1:fid="Landuse_ALB_333">
   <ns1:description>Betriebsfläche;Lagerplatz;Lagerplatz (Baustoffe)</ns1:description>
   <ns1:name>ALB_333</ns1:name>
   <ns2:idealLandUsePeriodLink xlink:href="#IdealLandUse_4"/>
   <ns2:sealingLink xlink:href="#Sealing14"/>
  </ns2:Landuse>
 </ns2:landuseMember>
 <ns2:landuseMember>
  <ns2:Landuse ns1:fid="Landuse_ALB_334">
   <ns1:description>Betriebsfläche;Lagerplatz;Lagerplatz (Schrott, Altmaterial)</ns1:description>
   <ns1:name>ALB_334</ns1:name>
   <ns2:idealLandUsePeriodLink xlink:href="#IdealLandUse_2"/>
   <ns2:sealingLink xlink:href="#Sealing19"/>
  </ns2:Landuse>
 </ns2:landuseMember>
 <ns2:landuseMember>
  <ns2:Landuse ns1:fid="Landuse_ALB_335">
   <ns1:description>Betriebsfläche;Lagerplatz;Lagerplatz (Ausstellung)</ns1:description>
   <ns1:name>ALB_335</ns1:name>
   <ns2:idealLandUsePeriodLink xlink:href="#IdealLandUse_1"/>
   <ns2:sealingLink xlink:href="#Sealing9"/>
  </ns2:Landuse>
 </ns2:landuseMember>
 <ns2:landuseMember>
  <ns2:Landuse ns1:fid="Landuse_ALB_336">
   <ns1:description>Betriebsfläche;Lagerplatz;Lagerplatz (Betrieb)</ns1:description>
   <ns1:name>ALB_336</ns1:name>
   <ns2:idealLandUsePeriodLink xlink:href="#IdealLandUse_1"/>
   <ns2:sealingLink xlink:href="#Sealing7"/>
  </ns2:Landuse>
 </ns2:landuseMember>
 <ns2:landuseMember>
  <ns2:Landuse ns1:fid="Landuse_ALB_339">
   <ns1:description>Betriebsfläche;Lagerplatz;Lagerplatz (anderer Lagerplatz)</ns1:description>
   <ns1:name>ALB_339</ns1:name>
   <ns2:idealLandUsePeriodLink xlink:href="#IdealLandUse_1"/>
   <ns2:sealingLink xlink:href="#Sealing8"/>
  </ns2:Landuse>
 </ns2:landuseMember>
 <ns2:landuseMember>
  <ns2:Landuse ns1:fid="Landuse_ALB_341">
   <ns1:description>Betriebsfläche;Versorgungsanlage;Versorgungsanlage (Wasser)</ns1:description>
   <ns1:name>ALB_341</ns1:name>
   <ns2:idealLandUsePeriodLink xlink:href="#IdealLandUse_5"/>
   <ns2:sealingLink xlink:href="#Sealing16"/>
  </ns2:Landuse>
 </ns2:landuseMember>
 <ns2:landuseMember>
  <ns2:Landuse ns1:fid="Landuse_ALB_351">
   <ns1:description>Betriebsfläche;Entsorgungsanlage;Entsorgungsanlage (Abfall)</ns1:description>
   <ns1:name>ALB_351</ns1:name>
   <ns2:idealLandUsePeriodLink xlink:href="#IdealLandUse_1"/>
   <ns2:sealingLink xlink:href="#Sealing19"/>
  </ns2:Landuse>
 </ns2:landuseMember>
 <ns2:landuseMember>
  <ns2:Landuse ns1:fid="Landuse_ALB_353">
   <ns1:description>Betriebsfläche;Entsorgungsanlage;Entsorgungsanlage (Abwasser)</ns1:description>
   <ns1:name>ALB_353</ns1:name>
   <ns2:idealLandUsePeriodLink xlink:href="#IdealLandUse_1"/>
   <ns2:sealingLink xlink:href="#Sealing9"/>
  </ns2:Landuse>
 </ns2:landuseMember>
 <ns2:landuseMember>
  <ns2:Landuse ns1:fid="Landuse_ALB_361">
   <ns1:description>Betriebsfläche;ungenutzt;ungenutzt (Erweiterung/Neuansiedlung)</ns1:description>
   <ns1:name>ALB_361</ns1:name>
   <ns2:idealLandUsePeriodLink xlink:href="#IdealLandUse_1"/>
   <ns2:sealingLink xlink:href="#Sealing9"/>
  </ns2:Landuse>
 </ns2:landuseMember>
 <ns2:landuseMember>
  <ns2:Landuse ns1:fid="Landuse_ALB_410">
   <ns1:description>Erholungsfläche;Sportfläche;Sportfläche</ns1:description>
   <ns1:name>ALB_410</ns1:name>
   <ns2:idealLandUsePeriodLink xlink:href="#IdealLandUse_1"/>
   <ns2:sealingLink xlink:href="#Sealing10"/>
  </ns2:Landuse>
 </ns2:landuseMember>
 <ns2:landuseMember>
  <ns2:Landuse ns1:fid="Landuse_ALB_411">
   <ns1:description>Erholungsfläche;Sportfläche;Sportfläche (Sportplatz)</ns1:description>
   <ns1:name>ALB_411</ns1:name>
   <ns2:idealLandUsePeriodLink xlink:href="#IdealLandUse_1"/>
   <ns2:sealingLink xlink:href="#Sealing10"/>
  </ns2:Landuse>
 </ns2:landuseMember>
 <ns2:landuseMember>
  <ns2:Landuse ns1:fid="Landuse_ALB_412">
   <ns1:description>Erholungsfläche;Sportfläche;Sportfläche (Golfplatz)</ns1:description>
   <ns1:name>ALB_412</ns1:name>
   <ns2:idealLandUsePeriodLink xlink:href="#IdealLandUse_1"/>
   <ns2:sealingLink xlink:href="#Sealing13"/>
  </ns2:Landuse>
 </ns2:landuseMember>
 <ns2:landuseMember>
  <ns2:Landuse ns1:fid="Landuse_ALB_413">
   <ns1:description>Erholungsfläche;Sportfläche;Sportfläche (Rennbahn)</ns1:description>
   <ns1:name>ALB_413</ns1:name>
   <ns2:idealLandUsePeriodLink xlink:href="#IdealLandUse_1"/>
   <ns2:sealingLink xlink:href="#Sealing10"/>
  </ns2:Landuse>
 </ns2:landuseMember>
 <ns2:landuseMember>
  <ns2:Landuse ns1:fid="Landuse_ALB_414">
   <ns1:description>Erholungsfläche;Sportfläche;Sportfläche (Reitplatz)</ns1:description>
   <ns1:name>ALB_414</ns1:name>
   <ns2:idealLandUsePeriodLink xlink:href="#IdealLandUse_1"/>
   <ns2:sealingLink xlink:href="#Sealing12"/>
  </ns2:Landuse>
 </ns2:landuseMember>
 <ns2:landuseMember>
  <ns2:Landuse ns1:fid="Landuse_ALB_415">
   <ns1:description>Erholungsfläche;Sportfläche;Sportfläche (Schießstand)</ns1:description>
   <ns1:name>ALB_415</ns1:name>
   <ns2:idealLandUsePeriodLink xlink:href="#IdealLandUse_1"/>
   <ns2:sealingLink xlink:href="#Sealing10"/>
  </ns2:Landuse>
 </ns2:landuseMember>
 <ns2:landuseMember>
  <ns2:Landuse ns1:fid="Landuse_ALB_416">
   <ns1:description>Erholungsfläche;Sportfläche;Sportfläche (Freibad)</ns1:description>
   <ns1:name>ALB_416</ns1:name>
   <ns2:idealLandUsePeriodLink xlink:href="#IdealLandUse_1"/>
   <ns2:sealingLink xlink:href="#Sealing10"/>
  </ns2:Landuse>
 </ns2:landuseMember>
 <ns2:landuseMember>
  <ns2:Landuse ns1:fid="Landuse_ALB_418">
   <ns1:description>Erholungsfläche;Sportfläche;Sportfläche (Tennisplatz)</ns1:description>
   <ns1:name>ALB_418</ns1:name>
   <ns2:idealLandUsePeriodLink xlink:href="#IdealLandUse_1"/>
   <ns2:sealingLink xlink:href="#Sealing5"/>
  </ns2:Landuse>
 </ns2:landuseMember>
 <ns2:landuseMember>
  <ns2:Landuse ns1:fid="Landuse_ALB_420">
   <ns1:description>Erholungsfläche;Grünanlage;Grünanlage</ns1:description>
   <ns1:name>ALB_420</ns1:name>
   <ns2:idealLandUsePeriodLink xlink:href="#IdealLandUse_1"/>
   <ns2:sealingLink xlink:href="#Sealing12"/>
  </ns2:Landuse>
 </ns2:landuseMember>
 <ns2:landuseMember>
  <ns2:Landuse ns1:fid="Landuse_ALB_421">
   <ns1:description>Erholungsfläche;Grünanlage;Grünanlage (Park)</ns1:description>
   <ns1:name>ALB_421</ns1:name>
   <ns2:idealLandUsePeriodLink xlink:href="#IdealLandUse_1"/>
   <ns2:sealingLink xlink:href="#Sealing12"/>
  </ns2:Landuse>
 </ns2:landuseMember>
 <ns2:landuseMember>
  <ns2:Landuse ns1:fid="Landuse_ALB_422">
   <ns1:description>Erholungsfläche;Grünanlage;Grünanlage (Spielplatz,Bolzplatz)</ns1:description>
   <ns1:name>ALB_422</ns1:name>
   <ns2:idealLandUsePeriodLink xlink:href="#IdealLandUse_1"/>
   <ns2:sealingLink xlink:href="#Sealing12"/>
  </ns2:Landuse>
 </ns2:landuseMember>
 <ns2:landuseMember>
  <ns2:Landuse ns1:fid="Landuse_ALB_423">
   <ns1:description>Erholungsfläche;Grünanlage;Grünanlage (Zoologischer Garten)</ns1:description>
   <ns1:name>ALB_423</ns1:name>
   <ns2:idealLandUsePeriodLink xlink:href="#IdealLandUse_1"/>
   <ns2:sealingLink xlink:href="#Sealing12"/>
  </ns2:Landuse>
 </ns2:landuseMember>
 <ns2:landuseMember>
  <ns2:Landuse ns1:fid="Landuse_ALB_424">
   <ns1:description>Erholungsfläche;Grünanlage;Grünanlage (Wildgehege)</ns1:description>
   <ns1:name>ALB_424</ns1:name>
   <ns2:idealLandUsePeriodLink xlink:href="#IdealLandUse_1"/>
   <ns2:sealingLink xlink:href="#Sealing12"/>
  </ns2:Landuse>
 </ns2:landuseMember>
 <ns2:landuseMember>
  <ns2:Landuse ns1:fid="Landuse_ALB_425">
   <ns1:description>Erholungsfläche;Grünanlage;Grünanlage (Botanischer Garten)</ns1:description>
   <ns1:name>ALB_425</ns1:name>
   <ns2:idealLandUsePeriodLink xlink:href="#IdealLandUse_5"/>
   <ns2:sealingLink xlink:href="#Sealing16"/>
  </ns2:Landuse>
 </ns2:landuseMember>
 <ns2:landuseMember>
  <ns2:Landuse ns1:fid="Landuse_ALB_426">
   <ns1:description>Erholungsfläche;Grünanlage;Grünanlage (Kleingarten)</ns1:description>
   <ns1:name>ALB_426</ns1:name>
   <ns2:idealLandUsePeriodLink xlink:href="#IdealLandUse_1"/>
   <ns2:sealingLink xlink:href="#Sealing13"/>
  </ns2:Landuse>
 </ns2:landuseMember>
 <ns2:landuseMember>
  <ns2:Landuse ns1:fid="Landuse_ALB_427">
   <ns1:description>Erholungsfläche;Grünanlage;Grünanlage (Wochenendplatz)</ns1:description>
   <ns1:name>ALB_427</ns1:name>
   <ns2:idealLandUsePeriodLink xlink:href="#IdealLandUse_1"/>
   <ns2:sealingLink xlink:href="#Sealing13"/>
  </ns2:Landuse>
 </ns2:landuseMember>
 <ns2:landuseMember>
  <ns2:Landuse ns1:fid="Landuse_ALB_428">
   <ns1:description>Erholungsfläche;Grünanlage;Grünanlage (Garten)</ns1:description>
   <ns1:name>ALB_428</ns1:name>
   <ns2:idealLandUsePeriodLink xlink:href="#IdealLandUse_1"/>
   <ns2:sealingLink xlink:href="#Sealing12"/>
  </ns2:Landuse>
 </ns2:landuseMember>
 <ns2:landuseMember>
  <ns2:Landuse ns1:fid="Landuse_ALB_429">
   <ns1:description>Erholungsfläche;Grünanlage;Grünanlage (andere Grünanlagen)</ns1:description>
   <ns1:name>ALB_429</ns1:name>
   <ns2:idealLandUsePeriodLink xlink:href="#IdealLandUse_1"/>
   <ns2:sealingLink xlink:href="#Sealing12"/>
  </ns2:Landuse>
 </ns2:landuseMember>
 <ns2:landuseMember>
  <ns2:Landuse ns1:fid="Landuse_ALB_431">
   <ns1:description>Erholungsfläche;Campingplatz;Campingplatz</ns1:description>
   <ns1:name>ALB_431</ns1:name>
   <ns2:idealLandUsePeriodLink xlink:href="#IdealLandUse_1"/>
   <ns2:sealingLink xlink:href="#Sealing12"/>
  </ns2:Landuse>
 </ns2:landuseMember>
 <ns2:landuseMember>
  <ns2:Landuse ns1:fid="Landuse_ALB_500">
   <ns1:description>Verkehrsfläche</ns1:description>
   <ns1:name>ALB_500</ns1:name>
   <ns2:idealLandUsePeriodLink xlink:href="#IdealLandUse_2"/>
   <ns2:sealingLink xlink:href="#Sealing19"/>
  </ns2:Landuse>
 </ns2:landuseMember>
 <ns2:landuseMember>
  <ns2:Landuse ns1:fid="Landuse_ALB_510">
   <ns1:description>Verkehrsfläche;Straße;Straße</ns1:description>
   <ns1:name>ALB_510</ns1:name>
   <ns2:idealLandUsePeriodLink xlink:href="#IdealLandUse_2"/>
   <ns2:sealingLink xlink:href="#Sealing19"/>
  </ns2:Landuse>
 </ns2:landuseMember>
 <ns2:landuseMember>
  <ns2:Landuse ns1:fid="Landuse_ALB_511">
   <ns1:description>Verkehrsfläche;Straße;Straße (mehrbahnig)</ns1:description>
   <ns1:name>ALB_511</ns1:name>
   <ns2:idealLandUsePeriodLink xlink:href="#IdealLandUse_2"/>
   <ns2:sealingLink xlink:href="#Sealing19"/>
  </ns2:Landuse>
 </ns2:landuseMember>
 <ns2:landuseMember>
  <ns2:Landuse ns1:fid="Landuse_ALB_512">
   <ns1:description>Verkehrsfläche;Straße;Straße (einbahnig)</ns1:description>
   <ns1:name>ALB_512</ns1:name>
   <ns2:idealLandUsePeriodLink xlink:href="#IdealLandUse_2"/>
   <ns2:sealingLink xlink:href="#Sealing19"/>
  </ns2:Landuse>
 </ns2:landuseMember>
 <ns2:landuseMember>
  <ns2:Landuse ns1:fid="Landuse_ALB_513">
   <ns1:description>Verkehrsfläche;Straße;Straße (Fußgängerzone)</ns1:description>
   <ns1:name>ALB_513</ns1:name>
   <ns2:idealLandUsePeriodLink xlink:href="#IdealLandUse_2"/>
   <ns2:sealingLink xlink:href="#Sealing19"/>
  </ns2:Landuse>
 </ns2:landuseMember>
 <ns2:landuseMember>
  <ns2:Landuse ns1:fid="Landuse_ALB_514">
   <ns1:description>Verkehrsfläche;Straße;Straße (Gehweg an Straße)</ns1:description>
   <ns1:name>ALB_514</ns1:name>
   <ns2:idealLandUsePeriodLink xlink:href="#IdealLandUse_2"/>
   <ns2:sealingLink xlink:href="#Sealing19"/>
  </ns2:Landuse>
 </ns2:landuseMember>
 <ns2:landuseMember>
  <ns2:Landuse ns1:fid="Landuse_ALB_516">
   <ns1:description>Verkehrsfläche;Straße;Straße (Radweg an Straße)</ns1:description>
   <ns1:name>ALB_516</ns1:name>
   <ns2:idealLandUsePeriodLink xlink:href="#IdealLandUse_2"/>
   <ns2:sealingLink xlink:href="#Sealing19"/>
  </ns2:Landuse>
 </ns2:landuseMember>
 <ns2:landuseMember>
  <ns2:Landuse ns1:fid="Landuse_ALB_520">
   <ns1:description>Verkehrsfläche;Weg;Weg</ns1:description>
   <ns1:name>ALB_520</ns1:name>
   <ns2:idealLandUsePeriodLink xlink:href="#IdealLandUse_2"/>
   <ns2:sealingLink xlink:href="#Sealing21"/>
  </ns2:Landuse>
 </ns2:landuseMember>
 <ns2:landuseMember>
  <ns2:Landuse ns1:fid="Landuse_ALB_521">
   <ns1:description>Verkehrsfläche;Weg;Weg (Fahrweg)</ns1:description>
   <ns1:name>ALB_521</ns1:name>
   <ns2:idealLandUsePeriodLink xlink:href="#IdealLandUse_2"/>
   <ns2:sealingLink xlink:href="#Sealing21"/>
  </ns2:Landuse>
 </ns2:landuseMember>
 <ns2:landuseMember>
  <ns2:Landuse ns1:fid="Landuse_ALB_522">
   <ns1:description>Verkehrsfläche;Weg;Weg (Fußweg)</ns1:description>
   <ns1:name>ALB_522</ns1:name>
   <ns2:idealLandUsePeriodLink xlink:href="#IdealLandUse_2"/>
   <ns2:sealingLink xlink:href="#Sealing21"/>
  </ns2:Landuse>
 </ns2:landuseMember>
 <ns2:landuseMember>
  <ns2:Landuse ns1:fid="Landuse_ALB_523">
   <ns1:description>Verkehrsfläche;Weg;Weg (Gang)</ns1:description>
   <ns1:name>ALB_523</ns1:name>
   <ns2:idealLandUsePeriodLink xlink:href="#IdealLandUse_2"/>
   <ns2:sealingLink xlink:href="#Sealing21"/>
  </ns2:Landuse>
 </ns2:landuseMember>
 <ns2:landuseMember>
  <ns2:Landuse ns1:fid="Landuse_ALB_525">
   <ns1:description>Verkehrsfläche;Weg;Weg (Fuß- und Radweg)</ns1:description>
   <ns1:name>ALB_525</ns1:name>
   <ns2:idealLandUsePeriodLink xlink:href="#IdealLandUse_2"/>
   <ns2:sealingLink xlink:href="#Sealing21"/>
  </ns2:Landuse>
 </ns2:landuseMember>
 <ns2:landuseMember>
  <ns2:Landuse ns1:fid="Landuse_ALB_531">
   <ns1:description>Verkehrsfläche;Platz;Platz (Parkplatz)</ns1:description>
   <ns1:name>ALB_531</ns1:name>
   <ns2:idealLandUsePeriodLink xlink:href="#IdealLandUse_2"/>
   <ns2:sealingLink xlink:href="#Sealing21"/>
  </ns2:Landuse>
 </ns2:landuseMember>
 <ns2:landuseMember>
  <ns2:Landuse ns1:fid="Landuse_ALB_533">
   <ns1:description>Verkehrsfläche;Platz;Platz (Marktplatz)</ns1:description>
   <ns1:name>ALB_533</ns1:name>
   <ns2:idealLandUsePeriodLink xlink:href="#IdealLandUse_2"/>
   <ns2:sealingLink xlink:href="#Sealing21"/>
  </ns2:Landuse>
 </ns2:landuseMember>
 <ns2:landuseMember>
  <ns2:Landuse ns1:fid="Landuse_ALB_534">
   <ns1:description>Verkehrsfläche;Platz;Platz (Mehrzweckplatz)</ns1:description>
   <ns1:name>ALB_534</ns1:name>
   <ns2:idealLandUsePeriodLink xlink:href="#IdealLandUse_2"/>
   <ns2:sealingLink xlink:href="#Sealing21"/>
  </ns2:Landuse>
 </ns2:landuseMember>
 <ns2:landuseMember>
  <ns2:Landuse ns1:fid="Landuse_ALB_541">
   <ns1:description>Verkehrsfläche;Bahngelände;Bahngelände (Eisenbahn)</ns1:description>
   <ns1:name>ALB_541</ns1:name>
   <ns2:idealLandUsePeriodLink xlink:href="#IdealLandUse_1"/>
   <ns2:sealingLink xlink:href="#Sealing11"/>
  </ns2:Landuse>
 </ns2:landuseMember>
 <ns2:landuseMember>
  <ns2:Landuse ns1:fid="Landuse_ALB_545">
   <ns1:description>Verkehrsfläche;Bahngelände;Bahngelände (U-Bahn)</ns1:description>
   <ns1:name>ALB_545</ns1:name>
   <ns2:idealLandUsePeriodLink xlink:href="#IdealLandUse_1"/>
   <ns2:sealingLink xlink:href="#Sealing11"/>
  </ns2:Landuse>
 </ns2:landuseMember>
 <ns2:landuseMember>
  <ns2:Landuse ns1:fid="Landuse_ALB_548">
   <ns1:description>Verkehrsfläche;Bahngelände;Bahngelände (S-Bahn)</ns1:description>
   <ns1:name>ALB_548</ns1:name>
   <ns2:idealLandUsePeriodLink xlink:href="#IdealLandUse_1"/>
   <ns2:sealingLink xlink:href="#Sealing11"/>
  </ns2:Landuse>
 </ns2:landuseMember>
 <ns2:landuseMember>
  <ns2:Landuse ns1:fid="Landuse_ALB_551">
   <ns1:description>Verkehrsfläche;Flugplatz;Flugplatz (Flughafen)</ns1:description>
   <ns1:name>ALB_551</ns1:name>
   <ns2:idealLandUsePeriodLink xlink:href="#IdealLandUse_1"/>
   <ns2:sealingLink xlink:href="#Sealing25"/>
  </ns2:Landuse>
 </ns2:landuseMember>
 <ns2:landuseMember>
  <ns2:Landuse ns1:fid="Landuse_ALB_591">
   <ns1:description>Verkehrsfläche;Verkehrsbegleitfläche;Verkehrsbegleitfläche (Begleitfl. Straße)</ns1:description>
   <ns1:name>ALB_591</ns1:name>
   <ns2:idealLandUsePeriodLink xlink:href="#IdealLandUse_1"/>
   <ns2:sealingLink xlink:href="#Sealing12"/>
  </ns2:Landuse>
 </ns2:landuseMember>
 <ns2:landuseMember>
  <ns2:Landuse ns1:fid="Landuse_ALB_594">
   <ns1:description>Verkehrsfläche;Verkehrsbegleitfläche;Verkehrsbegleitfl.(Begleitfl.Wasserstr.)</ns1:description>
   <ns1:name>ALB_594</ns1:name>
   <ns2:idealLandUsePeriodLink xlink:href="#IdealLandUse_1"/>
   <ns2:sealingLink xlink:href="#Sealing12"/>
  </ns2:Landuse>
 </ns2:landuseMember>
 <ns2:landuseMember>
  <ns2:Landuse ns1:fid="Landuse_ALB_611">
   <ns1:description>Landwirtschaftsfläche;Ackerland;Ackerland (Ackerland)</ns1:description>
   <ns1:name>ALB_611</ns1:name>
   <ns2:idealLandUsePeriodLink xlink:href="#IdealLandUse_4"/>
   <ns2:sealingLink xlink:href="#Sealing14"/>
  </ns2:Landuse>
 </ns2:landuseMember>
 <ns2:landuseMember>
  <ns2:Landuse ns1:fid="Landuse_ALB_620">
   <ns1:description>Landwirtschaftsfläche;Grünland;Grünland</ns1:description>
   <ns1:name>ALB_620</ns1:name>
   <ns2:idealLandUsePeriodLink xlink:href="#IdealLandUse_6"/>
   <ns2:sealingLink xlink:href="#Sealing15"/>
  </ns2:Landuse>
 </ns2:landuseMember>
 <ns2:landuseMember>
  <ns2:Landuse ns1:fid="Landuse_ALB_621">
   <ns1:description>Landwirtschaftsfläche;Grünland;Grünland (Grünland)</ns1:description>
   <ns1:name>ALB_621</ns1:name>
   <ns2:idealLandUsePeriodLink xlink:href="#IdealLandUse_6"/>
   <ns2:sealingLink xlink:href="#Sealing15"/>
  </ns2:Landuse>
 </ns2:landuseMember>
 <ns2:landuseMember>
  <ns2:Landuse ns1:fid="Landuse_ALB_631">
   <ns1:description>Landwirtschaftsfläche;Gartenland;Gartenland (Gartenland)</ns1:description>
   <ns1:name>ALB_631</ns1:name>
   <ns2:idealLandUsePeriodLink xlink:href="#IdealLandUse_4"/>
   <ns2:sealingLink xlink:href="#Sealing14"/>
  </ns2:Landuse>
 </ns2:landuseMember>
 <ns2:landuseMember>
  <ns2:Landuse ns1:fid="Landuse_ALB_632">
   <ns1:description>Landwirtschaftsfläche;Gartenland;Gartenland (Baumschule)</ns1:description>
   <ns1:name>ALB_632</ns1:name>
   <ns2:idealLandUsePeriodLink xlink:href="#IdealLandUse_4"/>
   <ns2:sealingLink xlink:href="#Sealing14"/>
  </ns2:Landuse>
 </ns2:landuseMember>
 <ns2:landuseMember>
  <ns2:Landuse ns1:fid="Landuse_ALB_651">
   <ns1:description>Landwirtschaftsfläche;Moor;Moor</ns1:description>
   <ns1:name>ALB_651</ns1:name>
   <ns2:idealLandUsePeriodLink xlink:href="#IdealLandUse_8"/>
   <ns2:sealingLink xlink:href="#Sealing18"/>
  </ns2:Landuse>
 </ns2:landuseMember>
 <ns2:landuseMember>
  <ns2:Landuse ns1:fid="Landuse_ALB_661">
   <ns1:description>Landwirtschaftsfläche;Heide;Heide</ns1:description>
   <ns1:name>ALB_661</ns1:name>
   <ns2:idealLandUsePeriodLink xlink:href="#IdealLandUse_6"/>
   <ns2:sealingLink xlink:href="#Sealing15"/>
  </ns2:Landuse>
 </ns2:landuseMember>
 <ns2:landuseMember>
  <ns2:Landuse ns1:fid="Landuse_ALB_691">
   <ns1:description>Landwirtschaftsfläche;Brachland;Brachland (Ackerland-brach)</ns1:description>
   <ns1:name>ALB_691</ns1:name>
   <ns2:idealLandUsePeriodLink xlink:href="#IdealLandUse_6"/>
   <ns2:sealingLink xlink:href="#Sealing15"/>
  </ns2:Landuse>
 </ns2:landuseMember>
 <ns2:landuseMember>
  <ns2:Landuse ns1:fid="Landuse_ALB_692">
   <ns1:description>Landwirtschaftsfläche;Brachland;Brachland (Grünland-brach)</ns1:description>
   <ns1:name>ALB_692</ns1:name>
   <ns2:idealLandUsePeriodLink xlink:href="#IdealLandUse_6"/>
   <ns2:sealingLink xlink:href="#Sealing15"/>
  </ns2:Landuse>
 </ns2:landuseMember>
 <ns2:landuseMember>
  <ns2:Landuse ns1:fid="Landuse_ALB_710">
   <ns1:description>Waldfläche;Laubwald;Laubwald</ns1:description>
   <ns1:name>ALB_710</ns1:name>
   <ns2:idealLandUsePeriodLink xlink:href="#IdealLandUse_5"/>
   <ns2:sealingLink xlink:href="#Sealing16"/>
  </ns2:Landuse>
 </ns2:landuseMember>
 <ns2:landuseMember>
  <ns2:Landuse ns1:fid="Landuse_ALB_711">
   <ns1:description>Waldfläche;Laubwald;Laubwald</ns1:description>
   <ns1:name>ALB_711</ns1:name>
   <ns2:idealLandUsePeriodLink xlink:href="#IdealLandUse_5"/>
   <ns2:sealingLink xlink:href="#Sealing16"/>
  </ns2:Landuse>
 </ns2:landuseMember>
 <ns2:landuseMember>
  <ns2:Landuse ns1:fid="Landuse_ALB_721">
   <ns1:description>Waldfläche;Nadelwald;Nadelwald</ns1:description>
   <ns1:name>ALB_721</ns1:name>
   <ns2:idealLandUsePeriodLink xlink:href="#IdealLandUse_7"/>
   <ns2:sealingLink xlink:href="#Sealing23"/>
  </ns2:Landuse>
 </ns2:landuseMember>
 <ns2:landuseMember>
  <ns2:Landuse ns1:fid="Landuse_ALB_731">
   <ns1:description>Waldfläche;Mischwald;Mischwald</ns1:description>
   <ns1:name>ALB_731</ns1:name>
   <ns2:idealLandUsePeriodLink xlink:href="#IdealLandUse_3"/>
   <ns2:sealingLink xlink:href="#Sealing17"/>
  </ns2:Landuse>
 </ns2:landuseMember>
 <ns2:landuseMember>
  <ns2:Landuse ns1:fid="Landuse_ALB_741">
   <ns1:description>Waldfläche;Gehölz;Gehölz</ns1:description>
   <ns1:name>ALB_741</ns1:name>
   <ns2:idealLandUsePeriodLink xlink:href="#IdealLandUse_5"/>
   <ns2:sealingLink xlink:href="#Sealing16"/>
  </ns2:Landuse>
 </ns2:landuseMember>
 <ns2:landuseMember>
  <ns2:Landuse ns1:fid="Landuse_ALB_811">
   <ns1:description>Wasserfläche;Fluss;Fluss</ns1:description>
   <ns1:name>ALB_811</ns1:name>
   <ns2:idealLandUsePeriodLink xlink:href="#IdealLandUse_8"/>
   <ns2:sealingLink xlink:href="#Sealing18"/>
  </ns2:Landuse>
 </ns2:landuseMember>
 <ns2:landuseMember>
  <ns2:Landuse ns1:fid="Landuse_ALB_812">
   <ns1:description>Wasserfläche;Fluss;Fluss (Altwasser)</ns1:description>
   <ns1:name>ALB_812</ns1:name>
   <ns2:idealLandUsePeriodLink xlink:href="#IdealLandUse_8"/>
   <ns2:sealingLink xlink:href="#Sealing18"/>
  </ns2:Landuse>
 </ns2:landuseMember>
 <ns2:landuseMember>
  <ns2:Landuse ns1:fid="Landuse_ALB_841">
   <ns1:description>Wasserfläche;Bach;Bach</ns1:description>
   <ns1:name>ALB_841</ns1:name>
   <ns2:idealLandUsePeriodLink xlink:href="#IdealLandUse_8"/>
   <ns2:sealingLink xlink:href="#Sealing18"/>
  </ns2:Landuse>
 </ns2:landuseMember>
 <ns2:landuseMember>
  <ns2:Landuse ns1:fid="Landuse_ALB_851">
   <ns1:description>Wasserfläche;Graben;Graben</ns1:description>
   <ns1:name>ALB_851</ns1:name>
   <ns2:idealLandUsePeriodLink xlink:href="#IdealLandUse_8"/>
   <ns2:sealingLink xlink:href="#Sealing18"/>
  </ns2:Landuse>
 </ns2:landuseMember>
 <ns2:landuseMember>
  <ns2:Landuse ns1:fid="Landuse_ALB_861">
   <ns1:description>Wasserfläche;See;See (Natürlicher See)</ns1:description>
   <ns1:name>ALB_861</ns1:name>
   <ns2:idealLandUsePeriodLink xlink:href="#IdealLandUse_8"/>
   <ns2:sealingLink xlink:href="#Sealing18"/>
  </ns2:Landuse>
 </ns2:landuseMember>
 <ns2:landuseMember>
  <ns2:Landuse ns1:fid="Landuse_ALB_864">
   <ns1:description>Wasserfläche;See;See (Speicherbecken)</ns1:description>
   <ns1:name>ALB_864</ns1:name>
   <ns2:idealLandUsePeriodLink xlink:href="#IdealLandUse_8"/>
   <ns2:sealingLink xlink:href="#Sealing22"/>
  </ns2:Landuse>
 </ns2:landuseMember>
 <ns2:landuseMember>
  <ns2:Landuse ns1:fid="Landuse_ALB_881">
   <ns1:description>Wasserfläche;Teich, Weiher;Teich, Weiher</ns1:description>
   <ns1:name>ALB_881</ns1:name>
   <ns2:idealLandUsePeriodLink xlink:href="#IdealLandUse_8"/>
   <ns2:sealingLink xlink:href="#Sealing18"/>
  </ns2:Landuse>
 </ns2:landuseMember>
 <ns2:landuseMember>
  <ns2:Landuse ns1:fid="Landuse_ALB_891">
   <ns1:description>Wasserfläche;Sumpf;Sumpf</ns1:description>
   <ns1:name>ALB_891</ns1:name>
   <ns2:idealLandUsePeriodLink xlink:href="#IdealLandUse_8"/>
   <ns2:sealingLink xlink:href="#Sealing18"/>
  </ns2:Landuse>
 </ns2:landuseMember>
 <ns2:landuseMember>
  <ns2:Landuse ns1:fid="Landuse_ALB_912">
   <ns1:description>Flächen anderer Nutzung;Übungsgelände;Übungsgelände (Dressurplatz)</ns1:description>
   <ns1:name>ALB_912</ns1:name>
   <ns2:idealLandUsePeriodLink xlink:href="#IdealLandUse_6"/>
   <ns2:sealingLink xlink:href="#Sealing15"/>
  </ns2:Landuse>
 </ns2:landuseMember>
 <ns2:landuseMember>
  <ns2:Landuse ns1:fid="Landuse_ALB_922">
   <ns1:description>Flächen anderer Nutzung;Schutzfläche;Schutzfläche (TP)</ns1:description>
   <ns1:name>ALB_922</ns1:name>
   <ns2:idealLandUsePeriodLink xlink:href="#IdealLandUse_5"/>
   <ns2:sealingLink xlink:href="#Sealing16"/>
  </ns2:Landuse>
 </ns2:landuseMember>
 <ns2:landuseMember>
  <ns2:Landuse ns1:fid="Landuse_ALB_923">
   <ns1:description>Flächen anderer Nutzung;Schutzfläche;Schutzfläche (Rückhaltebecken)</ns1:description>
   <ns1:name>ALB_923</ns1:name>
   <ns2:idealLandUsePeriodLink xlink:href="#IdealLandUse_6"/>
   <ns2:sealingLink xlink:href="#Sealing15"/>
  </ns2:Landuse>
 </ns2:landuseMember>
 <ns2:landuseMember>
  <ns2:Landuse ns1:fid="Landuse_ALB_924">
   <ns1:description>Flächen anderer Nutzung;Schutzfläche;Schutzfläche (Lärmschutz)</ns1:description>
   <ns1:name>ALB_924</ns1:name>
   <ns2:idealLandUsePeriodLink xlink:href="#IdealLandUse_1"/>
   <ns2:sealingLink xlink:href="#Sealing20"/>
  </ns2:Landuse>
 </ns2:landuseMember>
 <ns2:landuseMember>
  <ns2:Landuse ns1:fid="Landuse_ALB_926">
   <ns1:description>Flächen anderer Nutzung;Schutzfläche;Schutzfläche(Deich, Hochwasserschutzanl.)</ns1:description>
   <ns1:name>ALB_926</ns1:name>
   <ns2:idealLandUsePeriodLink xlink:href="#IdealLandUse_1"/>
   <ns2:sealingLink xlink:href="#Sealing12"/>
  </ns2:Landuse>
 </ns2:landuseMember>
 <ns2:landuseMember>
  <ns2:Landuse ns1:fid="Landuse_ALB_933">
   <ns1:description>Flächen anderer Nutzung;Historische Anlage;Historische Anlage (Denkmal)</ns1:description>
   <ns1:name>ALB_933</ns1:name>
   <ns2:idealLandUsePeriodLink xlink:href="#IdealLandUse_5"/>
   <ns2:sealingLink xlink:href="#Sealing16"/>
  </ns2:Landuse>
 </ns2:landuseMember>
 <ns2:landuseMember>
  <ns2:Landuse ns1:fid="Landuse_ALB_939">
   <ns1:description>Flächen anderer Nutzung;Historische Anlage;Historische Anlage (andere hist. Anlage)</ns1:description>
   <ns1:name>ALB_939</ns1:name>
   <ns2:idealLandUsePeriodLink xlink:href="#IdealLandUse_1"/>
   <ns2:sealingLink xlink:href="#Sealing10"/>
  </ns2:Landuse>
 </ns2:landuseMember>
 <ns2:landuseMember>
  <ns2:Landuse ns1:fid="Landuse_ALB_941">
   <ns1:description>Flächen anderer Nutzung;Friedhof;Friedhof</ns1:description>
   <ns1:name>ALB_941</ns1:name>
   <ns2:idealLandUsePeriodLink xlink:href="#IdealLandUse_1"/>
   <ns2:sealingLink xlink:href="#Sealing12"/>
  </ns2:Landuse>
 </ns2:landuseMember>
 <ns2:landuseMember>
  <ns2:Landuse ns1:fid="Landuse_ALB_942">
   <ns1:description>Flächen anderer Nutzung;Friedhof;Friedhof (Park)</ns1:description>
   <ns1:name>ALB_942</ns1:name>
   <ns2:idealLandUsePeriodLink xlink:href="#IdealLandUse_1"/>
   <ns2:sealingLink xlink:href="#Sealing12"/>
  </ns2:Landuse>
 </ns2:landuseMember>
 <ns2:landuseMember>
  <ns2:Landuse ns1:fid="Landuse_ALB_951">
   <ns1:description>Flächen anderer Nutzung;Unland;Unland (Felsen, Steinriegel)</ns1:description>
   <ns1:name>ALB_951</ns1:name>
   <ns2:idealLandUsePeriodLink xlink:href="#IdealLandUse_6"/>
   <ns2:sealingLink xlink:href="#Sealing15"/>
  </ns2:Landuse>
 </ns2:landuseMember>
 <ns2:landuseMember>
  <ns2:Landuse ns1:fid="Landuse_ALB_959">
   <ns1:description>Flächen anderer Nutzung;Unland;Unland (anderes Unland)</ns1:description>
   <ns1:name>ALB_959</ns1:name>
   <ns2:idealLandUsePeriodLink xlink:href="#IdealLandUse_6"/>
   <ns2:sealingLink xlink:href="#Sealing15"/>
  </ns2:Landuse>
 </ns2:landuseMember>
 <ns2:landuseMember>
  <ns2:Landuse ns1:fid="Landuse_ALB_999">
   <ns1:description>Tatsächliche Nutzung;nicht erfasst;nicht erfasst</ns1:description>
   <ns1:name>ALB_999</ns1:name>
   <ns2:idealLandUsePeriodLink xlink:href="#IdealLandUse_1"/>
   <ns2:sealingLink xlink:href="#Sealing20"/>
  </ns2:Landuse>
 </ns2:landuseMember>
 <ns2:landuseMember>
  <ns2:Landuse ns1:fid="Landuse_1">
   <ns1:description>Einzelhaus</ns1:description>
   <ns1:name>1</ns1:name>
   <ns2:idealLandUsePeriodLink xlink:href="#IdealLandUse_1"/>
   <ns2:sealingLink xlink:href="#Sealing1"/>
  </ns2:Landuse>
 </ns2:landuseMember>
 <ns2:landuseMember>
  <ns2:Landuse ns1:fid="Landuse_2">
   <ns1:description>Neue Zeilenbebauung</ns1:description>
   <ns1:name>2</ns1:name>
   <ns2:idealLandUsePeriodLink xlink:href="#IdealLandUse_1"/>
   <ns2:sealingLink xlink:href="#Sealing2"/>
  </ns2:Landuse>
 </ns2:landuseMember>
 <ns2:landuseMember>
  <ns2:Landuse ns1:fid="Landuse_3">
   <ns1:description>Hochhaus</ns1:description>
   <ns1:name>3</ns1:name>
   <ns2:idealLandUsePeriodLink xlink:href="#IdealLandUse_1"/>
   <ns2:sealingLink xlink:href="#Sealing3"/>
  </ns2:Landuse>
 </ns2:landuseMember>
 <ns2:landuseMember>
  <ns2:Landuse ns1:fid="Landuse_4">
   <ns1:description>Neue Randbebauung</ns1:description>
   <ns1:name>4</ns1:name>
   <ns2:idealLandUsePeriodLink xlink:href="#IdealLandUse_1"/>
   <ns2:sealingLink xlink:href="#Sealing4"/>
  </ns2:Landuse>
 </ns2:landuseMember>
 <ns2:landuseMember>
  <ns2:Landuse ns1:fid="Landuse_5">
   <ns1:description>Blockbebauung mit Neubauten</ns1:description>
   <ns1:name>5</ns1:name>
   <ns2:idealLandUsePeriodLink xlink:href="#IdealLandUse_1"/>
   <ns2:sealingLink xlink:href="#Sealing5"/>
  </ns2:Landuse>
 </ns2:landuseMember>
 <ns2:landuseMember>
  <ns2:Landuse ns1:fid="Landuse_6">
   <ns1:description>Grosse Bildungseinrichtungen</ns1:description>
   <ns1:name>6</ns1:name>
   <ns2:idealLandUsePeriodLink xlink:href="#IdealLandUse_1"/>
   <ns2:sealingLink xlink:href="#Sealing6"/>
  </ns2:Landuse>
 </ns2:landuseMember>
 <ns2:landuseMember>
  <ns2:Landuse ns1:fid="Landuse_7">
   <ns1:description>Verwaltung</ns1:description>
   <ns1:name>7</ns1:name>
   <ns2:idealLandUsePeriodLink xlink:href="#IdealLandUse_1"/>
   <ns2:sealingLink xlink:href="#Sealing7"/>
  </ns2:Landuse>
 </ns2:landuseMember>
 <ns2:landuseMember>
  <ns2:Landuse ns1:fid="Landuse_8">
   <ns1:description>Industrie</ns1:description>
   <ns1:name>8</ns1:name>
   <ns2:idealLandUsePeriodLink xlink:href="#IdealLandUse_1"/>
   <ns2:sealingLink xlink:href="#Sealing8"/>
  </ns2:Landuse>
 </ns2:landuseMember>
 <ns2:landuseMember>
  <ns2:Landuse ns1:fid="Landuse_9">
   <ns1:description>Sonstiges Gewerbe</ns1:description>
   <ns1:name>9</ns1:name>
   <ns2:idealLandUsePeriodLink xlink:href="#IdealLandUse_1"/>
   <ns2:sealingLink xlink:href="#Sealing9"/>
  </ns2:Landuse>
 </ns2:landuseMember>
 <ns2:landuseMember>
  <ns2:Landuse ns1:fid="Landuse_10">
   <ns1:description>Sportanlagen, Deichanlagen</ns1:description>
   <ns1:name>10</ns1:name>
   <ns2:idealLandUsePeriodLink xlink:href="#IdealLandUse_1"/>
   <ns2:sealingLink xlink:href="#Sealing10"/>
  </ns2:Landuse>
 </ns2:landuseMember>
 <ns2:landuseMember>
  <ns2:Landuse ns1:fid="Landuse_11">
   <ns1:description>Schienenverkehrsflächen</ns1:description>
   <ns1:name>11</ns1:name>
   <ns2:idealLandUsePeriodLink xlink:href="#IdealLandUse_1"/>
   <ns2:sealingLink xlink:href="#Sealing11"/>
  </ns2:Landuse>
 </ns2:landuseMember>
 <ns2:landuseMember>
  <ns2:Landuse ns1:fid="Landuse_12">
   <ns1:description>Grün-u.Parkanlagen</ns1:description>
   <ns1:name>12</ns1:name>
   <ns2:idealLandUsePeriodLink xlink:href="#IdealLandUse_1"/>
   <ns2:sealingLink xlink:href="#Sealing12"/>
  </ns2:Landuse>
 </ns2:landuseMember>
 <ns2:landuseMember>
  <ns2:Landuse ns1:fid="Landuse_13">
   <ns1:description>Kleingartenanlagen</ns1:description>
   <ns1:name>13</ns1:name>
   <ns2:idealLandUsePeriodLink xlink:href="#IdealLandUse_1"/>
   <ns2:sealingLink xlink:href="#Sealing13"/>
  </ns2:Landuse>
 </ns2:landuseMember>
 <ns2:landuseMember>
  <ns2:Landuse ns1:fid="Landuse_14">
   <ns1:description>Acker-u.Gartenland</ns1:description>
   <ns1:name>14</ns1:name>
   <ns2:idealLandUsePeriodLink xlink:href="#IdealLandUse_4"/>
   <ns2:sealingLink xlink:href="#Sealing14"/>
  </ns2:Landuse>
 </ns2:landuseMember>
 <ns2:landuseMember>
  <ns2:Landuse ns1:fid="Landuse_15">
   <ns1:description>Grünland</ns1:description>
   <ns1:name>15</ns1:name>
   <ns2:idealLandUsePeriodLink xlink:href="#IdealLandUse_6"/>
   <ns2:sealingLink xlink:href="#Sealing15"/>
  </ns2:Landuse>
 </ns2:landuseMember>
 <ns2:landuseMember>
  <ns2:Landuse ns1:fid="Landuse_16">
   <ns1:description>Laubwald</ns1:description>
   <ns1:name>16</ns1:name>
   <ns2:idealLandUsePeriodLink xlink:href="#IdealLandUse_5"/>
   <ns2:sealingLink xlink:href="#Sealing16"/>
  </ns2:Landuse>
 </ns2:landuseMember>
 <ns2:landuseMember>
  <ns2:Landuse ns1:fid="Landuse_17">
   <ns1:description>Mischwald</ns1:description>
   <ns1:name>17</ns1:name>
   <ns2:idealLandUsePeriodLink xlink:href="#IdealLandUse_3"/>
   <ns2:sealingLink xlink:href="#Sealing17"/>
  </ns2:Landuse>
 </ns2:landuseMember>
 <ns2:landuseMember>
  <ns2:Landuse ns1:fid="Landuse_18">
   <ns1:description>Wasserflächen</ns1:description>
   <ns1:name>18</ns1:name>
   <ns2:idealLandUsePeriodLink xlink:href="#IdealLandUse_8"/>
   <ns2:sealingLink xlink:href="#Sealing18"/>
  </ns2:Landuse>
 </ns2:landuseMember>
 <ns2:landuseMember>
  <ns2:Landuse ns1:fid="Landuse_19">
   <ns1:description>Straßen und Plätze</ns1:description>
   <ns1:name>19</ns1:name>
   <ns2:idealLandUsePeriodLink xlink:href="#IdealLandUse_2"/>
   <ns2:sealingLink xlink:href="#Sealing19"/>
  </ns2:Landuse>
 </ns2:landuseMember>
 <ns2:landuseMember>
  <ns2:Landuse ns1:fid="Landuse_20">
   <ns1:description>Nutzung unbekannt</ns1:description>
   <ns1:name>20</ns1:name>
   <ns2:idealLandUsePeriodLink xlink:href="#IdealLandUse_1"/>
   <ns2:sealingLink xlink:href="#Sealing20"/>
  </ns2:Landuse>
 </ns2:landuseMember>
 <ns2:landuseMember>
  <ns2:Landuse ns1:fid="Landuse_21">
   <ns1:description>Wege</ns1:description>
   <ns1:name>21</ns1:name>
   <ns2:idealLandUsePeriodLink xlink:href="#IdealLandUse_2"/>
   <ns2:sealingLink xlink:href="#Sealing21"/>
  </ns2:Landuse>
 </ns2:landuseMember>
 <ns2:landuseMember>
  <ns2:Landuse ns1:fid="Landuse_22">
   <ns1:description>Wasserflächen RHB's</ns1:description>
   <ns1:name>22</ns1:name>
   <ns2:idealLandUsePeriodLink xlink:href="#IdealLandUse_8"/>
   <ns2:sealingLink xlink:href="#Sealing22"/>
  </ns2:Landuse>
 </ns2:landuseMember>
 <ns2:landuseMember>
  <ns2:Landuse ns1:fid="Landuse_23">
   <ns1:description>Nadelwald</ns1:description>
   <ns1:name>23</ns1:name>
   <ns2:idealLandUsePeriodLink xlink:href="#IdealLandUse_7"/>
   <ns2:sealingLink xlink:href="#Sealing23"/>
  </ns2:Landuse>
 </ns2:landuseMember>
 <ns2:landuseMember>
  <ns2:Landuse ns1:fid="Landuse_24">
   <ns1:description>Gehölz, Gebüsch</ns1:description>
   <ns1:name>24</ns1:name>
   <ns2:idealLandUsePeriodLink xlink:href="#IdealLandUse_3"/>
   <ns2:sealingLink xlink:href="#Sealing24"/>
  </ns2:Landuse>
 </ns2:landuseMember>
 <ns2:landuseMember>
  <ns2:Landuse ns1:fid="Landuse_25">
   <ns1:description>Flughafengelände</ns1:description>
   <ns1:name>25</ns1:name>
   <ns2:idealLandUsePeriodLink xlink:href="#IdealLandUse_1"/>
   <ns2:sealingLink xlink:href="#Sealing25"/>
  </ns2:Landuse>
 </ns2:landuseMember>
 <ns2:idealLandUseMember>
  <ns2:IdealLandUse ns1:fid="IdealLandUse_1">
   <ns1:description>als Mischtyp Garten</ns1:description>
   <ns1:name>natürliche Flächen von Bebauungstypen</ns1:name>
   <idealLandUseZML xmlns="http://www.tuhh.de/parameter">&lt;?xml version="1.0" encoding="UTF-8" standalone="yes"?&gt;
&lt;ns3:observation editable="true" xmlns:ns3="zml.kalypso.org" xmlns:xlink="http://www.w3.org/1999/xlink"&gt;
    &lt;ns3:name&gt;Bebauung&lt;/ns3:name&gt;
    &lt;ns3:metadataList&gt;
        &lt;ns3:metadata value="Bebauung" name="Name"/&gt;
        &lt;ns3:metadata value="UTC" name="Zeitzone"/&gt;
    &lt;/ns3:metadataList&gt;
    &lt;ns3:axis unit="-" type="KC" name="Cropfactor" key="false" datatype="TYPE=double"&gt;
        &lt;ns3:valueArray separator=";"&gt;1.0;1.0;1.0;1.0;1.0;1.05;1.1;1.1;1.1;1.1;1.1;1.0;1.0&lt;/ns3:valueArray&gt;
    &lt;/ns3:axis&gt;
    &lt;ns3:axis unit="d" type="date" name="Datum" key="true" datatype="TYPE=date#FORMAT=yyyy-MM-dd'T'HH:mm:ss"&gt;
        &lt;ns3:valueArray separator=";"&gt;2000-11-15T11:00:00;2000-12-15T11:00:00;2001-01-15T11:00:00;2001-02-15T11:00:00;2001-03-15T11:00:00;2001-04-15T10:00:00;2001-05-15T10:00:00;2001-06-15T10:00:00;2001-07-15T10:00:00;2001-08-15T10:00:00;2001-09-15T10:00:00;2001-10-15T10:00:00;2001-11-15T11:00:00&lt;/ns3:valueArray&gt;
    &lt;/ns3:axis&gt;
    &lt;ns3:axis unit="mm" type="LAI" name="Interzeptionspeicherinhalt" key="false" datatype="TYPE=double"&gt;
        &lt;ns3:valueArray separator=";"&gt;2.0;2.0;2.0;2.0;2.0;2.0;2.0;2.0;2.0;2.0;2.0;2.0;2.0&lt;/ns3:valueArray&gt;
    &lt;/ns3:axis&gt;
    &lt;ns3:axis unit="m" type="WT" name="Wurzeltiefe" key="false" datatype="TYPE=double"&gt;
        &lt;ns3:valueArray separator=";"&gt;0.6;0.6;0.6;0.6;0.6;0.65;0.65;0.65;0.65;0.7;0.65;0.65;0.6&lt;/ns3:valueArray&gt;
    &lt;/ns3:axis&gt;
&lt;/ns3:observation&gt;

</idealLandUseZML>
  </ns2:IdealLandUse>
 </ns2:idealLandUseMember>
 <ns2:idealLandUseMember>
  <ns2:IdealLandUse ns1:fid="IdealLandUse_2">
   <ns1:description>als Mischtyp</ns1:description>
   <ns1:name>Straßen und  Wege</ns1:name>
   <idealLandUseZML xmlns="http://www.tuhh.de/parameter">&lt;?xml version="1.0" encoding="UTF-8" standalone="yes"?&gt;
&lt;ns3:observation editable="true" xmlns:ns3="zml.kalypso.org" xmlns:xlink="http://www.w3.org/1999/xlink"&gt;
    &lt;ns3:name&gt;Strassen und Wege&lt;/ns3:name&gt;
    &lt;ns3:metadataList&gt;
        &lt;ns3:metadata value="Strassen und Wege" name="Name"/&gt;
        &lt;ns3:metadata value="UTC" name="Zeitzone"/&gt;
    &lt;/ns3:metadataList&gt;
    &lt;ns3:axis unit="-" type="KC" name="Cropfactor" key="false" datatype="TYPE=double"&gt;
        &lt;ns3:valueArray separator=";"&gt;0.75;0.75;0.75;0.75;0.9;0.95;1.15;1.35;1.3;1.0;0.75;0.75;0.75&lt;/ns3:valueArray&gt;
    &lt;/ns3:axis&gt;
    &lt;ns3:axis unit="d" type="date" name="Datum" key="true" datatype="TYPE=date#FORMAT=yyyy-MM-dd'T'HH:mm:ss"&gt;
        &lt;ns3:valueArray separator=";"&gt;2000-11-15T11:00:00;2000-12-15T11:00:00;2001-01-15T11:00:00;2001-02-15T11:00:00;2001-03-15T11:00:00;2001-04-15T10:00:00;2001-05-15T10:00:00;2001-06-15T10:00:00;2001-07-15T10:00:00;2001-08-15T10:00:00;2001-09-15T10:00:00;2001-10-15T10:00:00;2001-11-15T11:00:00&lt;/ns3:valueArray&gt;
    &lt;/ns3:axis&gt;
    &lt;ns3:axis unit="mm" type="LAI" name="Interzeptionspeicherinhalt" key="false" datatype="TYPE=double"&gt;
        &lt;ns3:valueArray separator=";"&gt;1.0;1.0;1.0;1.0;1.0;2.0;2.5;2.5;2.5;2.5;1.0;1.0;1.0&lt;/ns3:valueArray&gt;
    &lt;/ns3:axis&gt;
    &lt;ns3:axis unit="m" type="WT" name="Wurzeltiefe" key="false" datatype="TYPE=double"&gt;
        &lt;ns3:valueArray separator=";"&gt;0.4;0.35;0.35;0.35;0.35;0.5;0.52;0.55;0.55;0.55;0.35;0.45;0.4&lt;/ns3:valueArray&gt;
    &lt;/ns3:axis&gt;
&lt;/ns3:observation&gt;

</idealLandUseZML>
  </ns2:IdealLandUse>
 </ns2:idealLandUseMember>
 <ns2:idealLandUseMember>
  <ns2:IdealLandUse ns1:fid="IdealLandUse_3">
   <ns1:description>als Mischtyp aus Nadelwald und Laubwald</ns1:description>
   <ns1:name>Mischwald</ns1:name>
   <idealLandUseZML xmlns="http://www.tuhh.de/parameter">&lt;?xml version="1.0" encoding="UTF-8" standalone="yes"?&gt;
&lt;ns3:observation editable="true" xmlns:ns3="zml.kalypso.org" xmlns:xlink="http://www.w3.org/1999/xlink"&gt;
    &lt;ns3:name&gt;Mischwald&lt;/ns3:name&gt;
    &lt;ns3:metadataList&gt;
        &lt;ns3:metadata value="Mischwald" name="Name"/&gt;
        &lt;ns3:metadata value="UTC" name="Zeitzone"/&gt;
    &lt;/ns3:metadataList&gt;
    &lt;ns3:axis unit="-" type="KC" name="Cropfactor" key="false" datatype="TYPE=double"&gt;
        &lt;ns3:valueArray separator=";"&gt;1.0;0.95;0.95;0.95;0.95;0.95;1.0;1.05;1.1;1.1;1.1;1.0;1.0&lt;/ns3:valueArray&gt;
    &lt;/ns3:axis&gt;
    &lt;ns3:axis unit="d" type="date" name="Datum" key="true" datatype="TYPE=date#FORMAT=yyyy-MM-dd'T'HH:mm:ss"&gt;
        &lt;ns3:valueArray separator=";"&gt;2000-11-15T11:00:00;2000-12-15T11:00:00;2001-01-15T11:00:00;2001-02-15T11:00:00;2001-03-15T11:00:00;2001-04-15T10:00:00;2001-05-15T10:00:00;2001-06-15T10:00:00;2001-07-15T10:00:00;2001-08-15T10:00:00;2001-09-15T10:00:00;2001-10-15T10:00:00;2001-11-15T11:00:00&lt;/ns3:valueArray&gt;
    &lt;/ns3:axis&gt;
    &lt;ns3:axis unit="mm" type="LAI" name="Interzeptionspeicherinhalt" key="false" datatype="TYPE=double"&gt;
        &lt;ns3:valueArray separator=";"&gt;2.0;2.0;2.0;2.0;2.0;2.5;4.0;4.0;4.0;4.0;4.0;3.5;2.0&lt;/ns3:valueArray&gt;
    &lt;/ns3:axis&gt;
    &lt;ns3:axis unit="m" type="WT" name="Wurzeltiefe" key="false" datatype="TYPE=double"&gt;
        &lt;ns3:valueArray separator=";"&gt;0.75;0.75;0.75;0.75;0.75;0.75;0.8;0.8;0.8;0.8;0.8;0.8;0.75&lt;/ns3:valueArray&gt;
    &lt;/ns3:axis&gt;
&lt;/ns3:observation&gt;

</idealLandUseZML>
  </ns2:IdealLandUse>
 </ns2:idealLandUseMember>
 <ns2:idealLandUseMember>
  <ns2:IdealLandUse ns1:fid="IdealLandUse_4">
   <ns1:description>Winterweizen nach DVWK 238</ns1:description>
   <ns1:name>Acker</ns1:name>
   <idealLandUseZML xmlns="http://www.tuhh.de/parameter">&lt;?xml version="1.0" encoding="UTF-8" standalone="yes"?&gt;
&lt;ns3:observation editable="true" xmlns:ns3="zml.kalypso.org" xmlns:xlink="http://www.w3.org/1999/xlink"&gt;
    &lt;ns3:name&gt;Acker&lt;/ns3:name&gt;
    &lt;ns3:metadataList&gt;
        &lt;ns3:metadata value="Acker" name="Name"/&gt;
        &lt;ns3:metadata value="UTC" name="Zeitzone"/&gt;
    &lt;/ns3:metadataList&gt;
    &lt;ns3:axis unit="-" type="KC" name="Cropfactor" key="false" datatype="TYPE=double"&gt;
        &lt;ns3:valueArray separator=";"&gt;0.65;0.65;0.65;0.65;0.9;0.95;1.15;1.35;1.3;1.0;0.9;0.7;0.65&lt;/ns3:valueArray&gt;
    &lt;/ns3:axis&gt;
    &lt;ns3:axis unit="d" type="date" name="Datum" key="true" datatype="TYPE=date#FORMAT=yyyy-MM-dd'T'HH:mm:ss"&gt;
        &lt;ns3:valueArray separator=";"&gt;2000-11-15T11:00:00;2000-12-15T11:00:00;2001-01-15T11:00:00;2001-02-15T11:00:00;2001-03-15T11:00:00;2001-04-15T10:00:00;2001-05-15T10:00:00;2001-06-15T10:00:00;2001-07-15T10:00:00;2001-08-15T10:00:00;2001-09-15T10:00:00;2001-10-15T10:00:00;2001-11-15T11:00:00&lt;/ns3:valueArray&gt;
    &lt;/ns3:axis&gt;
    &lt;ns3:axis unit="mm" type="LAI" name="Interzeptionspeicherinhalt" key="false" datatype="TYPE=double"&gt;
        &lt;ns3:valueArray separator=";"&gt;1.0;1.0;1.0;1.0;1.0;2.0;2.5;2.5;2.5;2.5;1.0;1.0;1.0&lt;/ns3:valueArray&gt;
    &lt;/ns3:axis&gt;
    &lt;ns3:axis unit="m" type="WT" name="Wurzeltiefe" key="false" datatype="TYPE=double"&gt;
        &lt;ns3:valueArray separator=";"&gt;0.3;0.3;0.3;0.3;0.3;0.3;0.3;0.4;0.45;0.5;0.55;0.4;0.3&lt;/ns3:valueArray&gt;
    &lt;/ns3:axis&gt;
&lt;/ns3:observation&gt;

</idealLandUseZML>
  </ns2:IdealLandUse>
 </ns2:idealLandUseMember>
 <ns2:idealLandUseMember>
  <ns2:IdealLandUse ns1:fid="IdealLandUse_5">
   <ns1:description>nach Disse</ns1:description>
   <ns1:name>Laubwald</ns1:name>
   <idealLandUseZML xmlns="http://www.tuhh.de/parameter">&lt;?xml version="1.0" encoding="UTF-8" standalone="yes"?&gt;
&lt;ns3:observation editable="true" xmlns:ns3="zml.kalypso.org" xmlns:xlink="http://www.w3.org/1999/xlink"&gt;
    &lt;ns3:name&gt;Laubwald&lt;/ns3:name&gt;
    &lt;ns3:metadataList&gt;
        &lt;ns3:metadata value="Laubwald" name="Name"/&gt;
        &lt;ns3:metadata value="UTC" name="Zeitzone"/&gt;
    &lt;/ns3:metadataList&gt;
    &lt;ns3:axis unit="-" type="KC" name="Cropfactor" key="false" datatype="TYPE=double"&gt;
        &lt;ns3:valueArray separator=";"&gt;1.0;0.9;0.9;0.9;0.9;0.95;1.0;1.05;1.1;1.1;1.1;1.0;1.0&lt;/ns3:valueArray&gt;
    &lt;/ns3:axis&gt;
    &lt;ns3:axis unit="d" type="date" name="Datum" key="true" datatype="TYPE=date#FORMAT=yyyy-MM-dd'T'HH:mm:ss"&gt;
        &lt;ns3:valueArray separator=";"&gt;2000-11-15T11:00:00;2000-12-15T11:00:00;2001-01-15T11:00:00;2001-02-15T11:00:00;2001-03-15T11:00:00;2001-04-15T10:00:00;2001-05-15T10:00:00;2001-06-15T10:00:00;2001-07-15T10:00:00;2001-08-15T10:00:00;2001-09-15T10:00:00;2001-10-15T10:00:00;2001-11-15T11:00:00&lt;/ns3:valueArray&gt;
    &lt;/ns3:axis&gt;
    &lt;ns3:axis unit="mm" type="LAI" name="Interzeptionspeicherinhalt" key="false" datatype="TYPE=double"&gt;
        &lt;ns3:valueArray separator=";"&gt;2.0;2.0;2.0;2.0;2.0;2.5;4.0;4.0;4.0;4.0;4.0;3.5;2.0&lt;/ns3:valueArray&gt;
    &lt;/ns3:axis&gt;
    &lt;ns3:axis unit="m" type="WT" name="Wurzeltiefe" key="false" datatype="TYPE=double"&gt;
        &lt;ns3:valueArray separator=";"&gt;0.85;0.75;0.75;0.75;0.75;0.75;0.75;0.75;0.8;0.85;0.85;0.85;0.85&lt;/ns3:valueArray&gt;
    &lt;/ns3:axis&gt;
&lt;/ns3:observation&gt;

</idealLandUseZML>
  </ns2:IdealLandUse>
 </ns2:idealLandUseMember>
 <ns2:idealLandUseMember>
  <ns2:IdealLandUse ns1:fid="IdealLandUse_6">
   <ns1:description>nach Disse und DVWK 238</ns1:description>
   <ns1:name>Gruenland</ns1:name>
   <idealLandUseZML xmlns="http://www.tuhh.de/parameter">&lt;?xml version="1.0" encoding="UTF-8" standalone="yes"?&gt;
&lt;ns3:observation editable="true" xmlns:ns3="zml.kalypso.org" xmlns:xlink="http://www.w3.org/1999/xlink"&gt;
    &lt;ns3:name&gt;Gruenland&lt;/ns3:name&gt;
    &lt;ns3:metadataList&gt;
        &lt;ns3:metadata value="Gruenland" name="Name"/&gt;
        &lt;ns3:metadata value="UTC" name="Zeitzone"/&gt;
    &lt;/ns3:metadataList&gt;
    &lt;ns3:axis unit="-" type="KC" name="Cropfactor" key="false" datatype="TYPE=double"&gt;
        &lt;ns3:valueArray separator=";"&gt;1.0;1.0;1.0;1.0;1.0;1.0;1.05;1.1;1.1;1.05;1.05;1.0;1.0&lt;/ns3:valueArray&gt;
    &lt;/ns3:axis&gt;
    &lt;ns3:axis unit="d" type="date" name="Datum" key="true" datatype="TYPE=date#FORMAT=yyyy-MM-dd'T'HH:mm:ss"&gt;
        &lt;ns3:valueArray separator=";"&gt;2000-11-15T11:00:00;2000-12-15T11:00:00;2001-01-15T11:00:00;2001-02-15T11:00:00;2001-03-15T11:00:00;2001-04-15T10:00:00;2001-05-15T10:00:00;2001-06-15T10:00:00;2001-07-15T10:00:00;2001-08-15T10:00:00;2001-09-15T10:00:00;2001-10-15T10:00:00;2001-11-15T11:00:00&lt;/ns3:valueArray&gt;
    &lt;/ns3:axis&gt;
    &lt;ns3:axis unit="mm" type="LAI" name="Interzeptionspeicherinhalt" key="false" datatype="TYPE=double"&gt;
        &lt;ns3:valueArray separator=";"&gt;2.0;2.0;2.0;2.0;2.0;2.0;2.0;2.0;2.0;2.0;2.0;2.0;2.0&lt;/ns3:valueArray&gt;
    &lt;/ns3:axis&gt;
    &lt;ns3:axis unit="m" type="WT" name="Wurzeltiefe" key="false" datatype="TYPE=double"&gt;
        &lt;ns3:valueArray separator=";"&gt;0.41;0.4;0.4;0.4;0.4;0.41;0.42;0.44;0.45;0.5;0.45;0.43;0.41&lt;/ns3:valueArray&gt;
    &lt;/ns3:axis&gt;
&lt;/ns3:observation&gt;

</idealLandUseZML>
  </ns2:IdealLandUse>
 </ns2:idealLandUseMember>
 <ns2:idealLandUseMember>
  <ns2:IdealLandUse ns1:fid="IdealLandUse_7">
   <ns1:description>nach Disse</ns1:description>
   <ns1:name>Nadelwald</ns1:name>
   <idealLandUseZML xmlns="http://www.tuhh.de/parameter">&lt;?xml version="1.0" encoding="UTF-8" standalone="yes"?&gt;
&lt;ns3:observation editable="true" xmlns:ns3="zml.kalypso.org" xmlns:xlink="http://www.w3.org/1999/xlink"&gt;
    &lt;ns3:name&gt;Nadelwald&lt;/ns3:name&gt;
    &lt;ns3:metadataList&gt;
        &lt;ns3:metadata value="Nadelwald" name="Name"/&gt;
        &lt;ns3:metadata value="UTC" name="Zeitzone"/&gt;
    &lt;/ns3:metadataList&gt;
    &lt;ns3:axis unit="-" type="KC" name="Cropfactor" key="false" datatype="TYPE=double"&gt;
        &lt;ns3:valueArray separator=";"&gt;0.95;0.9;0.9;0.9;0.9;0.93;0.97;1.0;1.0;1.0;1.0;1.0;0.95&lt;/ns3:valueArray&gt;
    &lt;/ns3:axis&gt;
    &lt;ns3:axis unit="d" type="date" name="Datum" key="true" datatype="TYPE=date#FORMAT=yyyy-MM-dd'T'HH:mm:ss"&gt;
        &lt;ns3:valueArray separator=";"&gt;2000-11-15T11:00:00;2000-12-15T11:00:00;2001-01-15T11:00:00;2001-02-15T11:00:00;2001-03-15T11:00:00;2001-04-15T10:00:00;2001-05-15T10:00:00;2001-06-15T10:00:00;2001-07-15T10:00:00;2001-08-15T10:00:00;2001-09-15T10:00:00;2001-10-15T10:00:00;2001-11-15T11:00:00&lt;/ns3:valueArray&gt;
    &lt;/ns3:axis&gt;
    &lt;ns3:axis unit="mm" type="LAI" name="Interzeptionspeicherinhalt" key="false" datatype="TYPE=double"&gt;
        &lt;ns3:valueArray separator=";"&gt;5.0;5.0;5.0;5.0;5.0;5.0;5.0;5.0;5.2;5.5;5.7;5.3;5.0&lt;/ns3:valueArray&gt;
    &lt;/ns3:axis&gt;
    &lt;ns3:axis unit="m" type="WT" name="Wurzeltiefe" key="false" datatype="TYPE=double"&gt;
        &lt;ns3:valueArray separator=";"&gt;0.75;0.75;0.75;0.75;0.75;0.75;0.85;0.85;0.85;0.85;0.85;0.8;0.75&lt;/ns3:valueArray&gt;
    &lt;/ns3:axis&gt;
&lt;/ns3:observation&gt;

</idealLandUseZML>
  </ns2:IdealLandUse>
 </ns2:idealLandUseMember>
 <ns2:idealLandUseMember>
  <ns2:IdealLandUse ns1:fid="IdealLandUse_8">
   <ns1:name>Gewaesser</ns1:name>
   <idealLandUseZML xmlns="http://www.tuhh.de/parameter">&lt;?xml version="1.0" encoding="UTF-8" standalone="yes"?&gt;
&lt;ns3:observation editable="true" xmlns:ns3="zml.kalypso.org" xmlns:xlink="http://www.w3.org/1999/xlink"&gt;
    &lt;ns3:name&gt;Gewaesser&lt;/ns3:name&gt;
    &lt;ns3:metadataList&gt;
        &lt;ns3:metadata value="Gewaesser" name="Name"/&gt;
        &lt;ns3:metadata value="UTC" name="Zeitzone"/&gt;
    &lt;/ns3:metadataList&gt;
    &lt;ns3:axis unit="-" type="KC" name="Cropfactor" key="false" datatype="TYPE=double"&gt;
        &lt;ns3:valueArray separator=";"&gt;0.65;0.65;0.65;0.65;0.9;0.95;1.15;1.35;1.3;1.0;0.65;0.65;0.65&lt;/ns3:valueArray&gt;
    &lt;/ns3:axis&gt;
    &lt;ns3:axis unit="d" type="date" name="Datum" key="true" datatype="TYPE=date#FORMAT=yyyy-MM-dd'T'HH:mm:ss"&gt;
        &lt;ns3:valueArray separator=";"&gt;2000-11-15T11:00:00;2000-12-15T11:00:00;2001-01-15T11:00:00;2001-02-15T11:00:00;2001-03-15T11:00:00;2001-04-15T10:00:00;2001-05-15T10:00:00;2001-06-15T10:00:00;2001-07-15T10:00:00;2001-08-15T10:00:00;2001-09-15T10:00:00;2001-10-15T10:00:00;2001-11-15T11:00:00&lt;/ns3:valueArray&gt;
    &lt;/ns3:axis&gt;
    &lt;ns3:axis unit="mm" type="LAI" name="Interzeptionspeicherinhalt" key="false" datatype="TYPE=double"&gt;
        &lt;ns3:valueArray separator=";"&gt;1.0;1.0;1.0;1.0;1.0;2.0;2.5;2.5;2.5;2.5;1.0;1.0;1.0&lt;/ns3:valueArray&gt;
    &lt;/ns3:axis&gt;
    &lt;ns3:axis unit="m" type="WT" name="Wurzeltiefe" key="false" datatype="TYPE=double"&gt;
        &lt;ns3:valueArray separator=";"&gt;0.4;0.35;0.35;0.35;0.35;0.5;0.52;0.55;0.55;0.55;0.35;0.45;0.4&lt;/ns3:valueArray&gt;
    &lt;/ns3:axis&gt;
&lt;/ns3:observation&gt;

</idealLandUseZML>
  </ns2:IdealLandUse>
 </ns2:idealLandUseMember>
 <ns2:sealingMember>
  <ns2:Sealing ns1:fid="Sealing29">
   <ns1:description>Wohngebiet BPlan Versiegelungsgrad</ns1:description>
   <ns1:name>WG_GRZ</ns1:name>
   <ns2:m_vers>0.5</ns2:m_vers>
  </ns2:Sealing>
 </ns2:sealingMember>
 <ns2:sealingMember>
  <ns2:Sealing ns1:fid="Sealing28">
   <ns1:description>Dorfgebiet BPlan Versiegelungsgrad</ns1:description>
   <ns1:name>DG_GRZ</ns1:name>
   <ns2:m_vers>0.2</ns2:m_vers>
  </ns2:Sealing>
 </ns2:sealingMember>
 <ns2:sealingMember>
  <ns2:Sealing ns1:fid="Sealing27">
   <ns1:description>Kleinsiedlung BPlan Versiegelungsgrad</ns1:description>
   <ns1:name>KS_GRZ</ns1:name>
   <ns2:m_vers>0.4</ns2:m_vers>
  </ns2:Sealing>
 </ns2:sealingMember>
 <ns2:sealingMember>
  <ns2:Sealing ns1:fid="Sealing30">
   <ns1:description>Kerngebiet BPlan Versiegelungsgrad</ns1:description>
   <ns1:name>KG_GRZ</ns1:name>
   <ns2:m_vers>0.7</ns2:m_vers>
  </ns2:Sealing>
 </ns2:sealingMember>
 <ns2:sealingMember>
  <ns2:Sealing ns1:fid="Sealing26">
   <ns1:description>Industrie u. Gewerbe BPlan Versiegelungsgrad</ns1:description>
   <ns1:name>IG_GRZ</ns1:name>
   <ns2:m_vers>0.8</ns2:m_vers>
  </ns2:Sealing>
 </ns2:sealingMember>
 <ns2:sealingMember>
  <ns2:Sealing ns1:fid="Sealing25">
   <ns1:description>Flughafengelände</ns1:description>
   <ns1:name>Klasse25</ns1:name>
   <ns2:m_vers>0.48</ns2:m_vers>
  </ns2:Sealing>
 </ns2:sealingMember>
 <ns2:sealingMember>
  <ns2:Sealing ns1:fid="Sealing24">
   <ns1:description>Gehölz, Gebüsch</ns1:description>
   <ns1:name>Klasse24</ns1:name>
   <ns2:m_vers>0.0</ns2:m_vers>
  </ns2:Sealing>
 </ns2:sealingMember>
 <ns2:sealingMember>
  <ns2:Sealing ns1:fid="Sealing23">
   <ns1:description>Nadelwald</ns1:description>
   <ns1:name>Klasse23</ns1:name>
   <ns2:m_vers>0.0</ns2:m_vers>
  </ns2:Sealing>
 </ns2:sealingMember>
 <ns2:sealingMember>
  <ns2:Sealing ns1:fid="Sealing22">
   <ns1:description>Wasserflächen RHB's</ns1:description>
   <ns1:name>Klasse22</ns1:name>
   <ns2:m_vers>1.0</ns2:m_vers>
  </ns2:Sealing>
 </ns2:sealingMember>
 <ns2:sealingMember>
  <ns2:Sealing ns1:fid="Sealing21">
   <ns1:description>Wege</ns1:description>
   <ns1:name>Klasse21</ns1:name>
   <ns2:m_vers>0.0</ns2:m_vers>
  </ns2:Sealing>
 </ns2:sealingMember>
 <ns2:sealingMember>
  <ns2:Sealing ns1:fid="Sealing20">
   <ns1:description>Nutzung unbekannt</ns1:description>
   <ns1:name>Klasse20</ns1:name>
   <ns2:m_vers>0.561</ns2:m_vers>
  </ns2:Sealing>
 </ns2:sealingMember>
 <ns2:sealingMember>
  <ns2:Sealing ns1:fid="Sealing19">
   <ns1:description>Straßen und Plätze</ns1:description>
   <ns1:name>Klasse19</ns1:name>
   <ns2:m_vers>0.95</ns2:m_vers>
  </ns2:Sealing>
 </ns2:sealingMember>
 <ns2:sealingMember>
  <ns2:Sealing ns1:fid="Sealing18">
   <ns1:description>Wasserflächen</ns1:description>
   <ns1:name>Klasse18</ns1:name>
   <ns2:m_vers>0.0</ns2:m_vers>
  </ns2:Sealing>
 </ns2:sealingMember>
 <ns2:sealingMember>
  <ns2:Sealing ns1:fid="Sealing17">
   <ns1:description>Mischwald</ns1:description>
   <ns1:name>Klasse17</ns1:name>
   <ns2:m_vers>0.0</ns2:m_vers>
  </ns2:Sealing>
 </ns2:sealingMember>
 <ns2:sealingMember>
  <ns2:Sealing ns1:fid="Sealing16">
   <ns1:description>Laubwald</ns1:description>
   <ns1:name>Klasse16</ns1:name>
   <ns2:m_vers>0.0</ns2:m_vers>
  </ns2:Sealing>
 </ns2:sealingMember>
 <ns2:sealingMember>
  <ns2:Sealing ns1:fid="Sealing15">
   <ns1:description>Grünland</ns1:description>
   <ns1:name>Klasse15</ns1:name>
   <ns2:m_vers>0.0</ns2:m_vers>
  </ns2:Sealing>
 </ns2:sealingMember>
 <ns2:sealingMember>
  <ns2:Sealing ns1:fid="Sealing14">
   <ns1:description>Acker-u.Gartenland</ns1:description>
   <ns1:name>Klasse14</ns1:name>
   <ns2:m_vers>0.0</ns2:m_vers>
  </ns2:Sealing>
 </ns2:sealingMember>
 <ns2:sealingMember>
  <ns2:Sealing ns1:fid="Sealing13">
   <ns1:description>Kleingartenanlagen</ns1:description>
   <ns1:name>Klasse13</ns1:name>
   <ns2:m_vers>0.029</ns2:m_vers>
  </ns2:Sealing>
 </ns2:sealingMember>
 <ns2:sealingMember>
  <ns2:Sealing ns1:fid="Sealing12">
   <ns1:description>Grün-u.Parkanlagen</ns1:description>
   <ns1:name>Klasse12</ns1:name>
   <ns2:m_vers>0.196</ns2:m_vers>
  </ns2:Sealing>
 </ns2:sealingMember>
 <ns2:sealingMember>
  <ns2:Sealing ns1:fid="Sealing11">
   <ns1:description>Schienenverkehrsflächen</ns1:description>
   <ns1:name>Klasse11</ns1:name>
   <ns2:m_vers>0.137</ns2:m_vers>
  </ns2:Sealing>
 </ns2:sealingMember>
 <ns2:sealingMember>
  <ns2:Sealing ns1:fid="Sealing10">
   <ns1:description>Sportanlagen, Deichanlagen</ns1:description>
   <ns1:name>Klasse10</ns1:name>
   <ns2:m_vers>0.356</ns2:m_vers>
  </ns2:Sealing>
 </ns2:sealingMember>
 <ns2:sealingMember>
  <ns2:Sealing ns1:fid="Sealing9">
   <ns1:description>Sonstiges Gewerbe</ns1:description>
   <ns1:name>Klasse9</ns1:name>
   <ns2:m_vers>0.729</ns2:m_vers>
  </ns2:Sealing>
 </ns2:sealingMember>
 <ns2:sealingMember>
  <ns2:Sealing ns1:fid="Sealing8">
   <ns1:description>Industrie</ns1:description>
   <ns1:name>Klasse8</ns1:name>
   <ns2:m_vers>0.708</ns2:m_vers>
  </ns2:Sealing>
 </ns2:sealingMember>
 <ns2:sealingMember>
  <ns2:Sealing ns1:fid="Sealing7">
   <ns1:description>Verwaltung</ns1:description>
   <ns1:name>Klasse7</ns1:name>
   <ns2:m_vers>0.782</ns2:m_vers>
  </ns2:Sealing>
 </ns2:sealingMember>
 <ns2:sealingMember>
  <ns2:Sealing ns1:fid="Sealing6">
   <ns1:description>Grosse Bildungseinrichtungen</ns1:description>
   <ns1:name>Klasse6</ns1:name>
   <ns2:m_vers>0.59</ns2:m_vers>
  </ns2:Sealing>
 </ns2:sealingMember>
 <ns2:sealingMember>
  <ns2:Sealing ns1:fid="Sealing5">
   <ns1:description>Blockbebauung mit Neubauten</ns1:description>
   <ns1:name>Klasse5</ns1:name>
   <ns2:m_vers>0.808</ns2:m_vers>
  </ns2:Sealing>
 </ns2:sealingMember>
 <ns2:sealingMember>
  <ns2:Sealing ns1:fid="Sealing4">
   <ns1:description>Neue Randbebauung</ns1:description>
   <ns1:name>Klasse4</ns1:name>
   <ns2:m_vers>0.606</ns2:m_vers>
  </ns2:Sealing>
 </ns2:sealingMember>
 <ns2:sealingMember>
  <ns2:Sealing ns1:fid="Sealing3">
   <ns1:description>Hochhaus</ns1:description>
   <ns1:name>Klasse3</ns1:name>
   <ns2:m_vers>0.503</ns2:m_vers>
  </ns2:Sealing>
 </ns2:sealingMember>
 <ns2:sealingMember>
  <ns2:Sealing ns1:fid="Sealing2">
   <ns1:description>Neue Zeilenbebauung</ns1:description>
   <ns1:name>Klasse2</ns1:name>
   <ns2:m_vers>0.408</ns2:m_vers>
  </ns2:Sealing>
 </ns2:sealingMember>
 <ns2:sealingMember>
  <ns2:Sealing ns1:fid="Sealing1">
   <ns1:description>Einzelhaus</ns1:description>
   <ns1:name>Klasse1</ns1:name>
   <ns2:m_vers>0.278</ns2:m_vers>
  </ns2:Sealing>
 </ns2:sealingMember>
</ns2:Parameter>
