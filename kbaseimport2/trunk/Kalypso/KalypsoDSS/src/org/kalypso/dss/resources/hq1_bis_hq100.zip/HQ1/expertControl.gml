<?xml version="1.0" encoding="UTF-8"?>

 <ns0:NAModellControl xmlns:gml2="http://www.opengis.net/gml" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:ns0="org.kalypso.namodell.control" fid="ID000000">
  <description xmlns="org.kalypso.namodell.control">Beschreibung</description>

  <name xmlns="org.kalypso.namodell.control">Berechnung im Experten-Modus</name>

  <tmp xmlns="org.kalypso.namodell.control">false</tmp>

  <pre xmlns="org.kalypso.namodell.control">false</pre>

  <sch xmlns="org.kalypso.namodell.control">false</sch>

  <bof xmlns="org.kalypso.namodell.control">false</bof>

  <bsp xmlns="org.kalypso.namodell.control">false</bsp>

  <gws xmlns="org.kalypso.namodell.control">true</gws>

  <qgs xmlns="org.kalypso.namodell.control">true</qgs>

  <qgg xmlns="org.kalypso.namodell.control">true</qgg>

  <qna xmlns="org.kalypso.namodell.control">true</qna>

  <qif xmlns="org.kalypso.namodell.control">true</qif>

  <qvs xmlns="org.kalypso.namodell.control">true</qvs>

  <qbs xmlns="org.kalypso.namodell.control">true</qbs>

  <qt1 xmlns="org.kalypso.namodell.control">false</qt1>

  <qtg xmlns="org.kalypso.namodell.control">false</qtg>

  <qgw xmlns="org.kalypso.namodell.control">true</qgw>

  <vet xmlns="org.kalypso.namodell.control">false</vet>

  <hyd xmlns="org.kalypso.namodell.control">false</hyd>

  <bil xmlns="org.kalypso.namodell.control">true</bil>

  <nmq xmlns="org.kalypso.namodell.control">false</nmq>

  <spi xmlns="org.kalypso.namodell.control">true</spi>

  <sup xmlns="org.kalypso.namodell.control">true</sup>

  <automaticCallibration xmlns="org.kalypso.namodell.control">false</automaticCallibration>

  <Catchments xmlns="org.kalypso.namodell.control">//:Catchment</Catchments>

  <KMChannels xmlns="org.kalypso.namodell.control">//:KMChannel</KMChannels>

 </ns0:NAModellControl>
