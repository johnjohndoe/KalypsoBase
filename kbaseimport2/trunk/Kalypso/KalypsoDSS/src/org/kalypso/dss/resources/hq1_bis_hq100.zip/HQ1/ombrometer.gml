<?xml version="1.0" encoding="UTF-8"?>
<OmbrometerCollection fid="ID000000" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns="http://org.kalypso.ombrometer" xmlns:obslink="obslink.zml.kalypso.org" xmlns:gml="http://www.opengis.net/gml" xsi:schemaLocation="http://org.kalypso.ombrometer project:/.model/schema/ombrometer.xsd">
  <ombrometerMember>
    <Ombrometer fid="ID3375">
      <gml:description>Fuhlsbuettel_kz</gml:description>
      <gml:name>N_Fuhlsbuettel_kz</gml:name>
      <Ort>
        <gml:Point srsName="EPSG:31467">
          <gml:coordinates cs="," decimal="." ts=" ">3566183.9853144297,5945670.160055787</gml:coordinates>
        </gml:Point>
      </Ort>
      <DWDID>0</DWDID>
      <NRepository>
        <TimeseriesLink xmlns:ns1="http://www.w3.org/1999/xlink" xmlns="obslink.zml.kalypso.org" ns1:href="project:/.model/Zeitreihen/Ombrometer/Kurzzeitwerte/N_Fuhlsbuettel_kz.zml"/>
      </NRepository>
      <N/>
      <TRepository/>
      <T/>
    </Ombrometer>
  </ombrometerMember>
</OmbrometerCollection>
