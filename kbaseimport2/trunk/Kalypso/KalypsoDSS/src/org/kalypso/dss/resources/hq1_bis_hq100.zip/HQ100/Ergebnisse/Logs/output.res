



          *****************************************************
          *****************************************************
          ****                                             ****
          ****      HAMBURG UNIVERSITY OF TECHNOLOGY       ****
          ****                                             ****
          **** Department of River and Coastal Engineering ****
          ****                                             ****
          ****                                             ****
          ****            K A L Y P S O - N A              ****
          ****                                             ****
          ****                                             ****
          ****           Rainfall-Runoff-Model             ****
          ****                                             ****
          ****                                             ****
          ****                                             ****
          ****     VERS.  2.0.4      STATUS: 01.03.2006    ****
          ****                                             ****
          ****                                             ****
          ****     Contact:          Dipl.-Ing J. H�bsch   ****
          ****                       j.huebsch@tuhh.de     ****
          *****************************************************
          *****************************************************




 Bearbeitung Fall / Berechnungseinstellungen aus Steuerungsdatei:
 ----------------------------------------------------------------
 2 .. we nat  1996 08 24 00 1996 08 30 23 start\we_nat_start.txt                                                         


 Anzahl der Straenge in der Netzdatei:    182

 Anzahl der Teilgebiete in der Netzdatei:  77



 K U R Z Z E I T S I M U L A T I O N
 Zyklus (iz):                         1
 Anfangsdatum Zyklus (idatsa):   960824
 Enddatum Zyklus (idatse):       960830
 Zeitschritte (idif):              2005


 ************************************************************************************
 *  Neuer Jahreszyklus                                                              *
 *      Jahr:    1996                                                              *
 *      Zyklus:     1                                                              *
 ************************************************************************************
 Auswertung des Stranges:         1000

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4503

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    2.97

 gesamtmenge an niederschlag (mm):      106.0

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     63


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  1.000


vers. flaeche  =      0.08
natur. flaeche =      0.87
gesamtflaeche  =      0.95




-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4503
 anzahl hydrotope:      63


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)     106.0 mm
 interz.verd.:                       7.7 mm
 bestandsniederschlag:              96.2 mm
 differenz interz.speicher:         -2.1 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      15.5 mm
 aktuelle verdunstung:              10.6 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              96.2 mm
 overlandflow:                       4.0 mm
 [infiltration:                     92.3 mm]
 kapilarer aufstieg:                 0.0 mm
 verdunstung (bodensp.):             3.0 mm
 lateral. abfluss (interflow):       0.2 mm
 perkolation:                        0.1 mm
 differenz bodenspeicher:          -89.1 mm
 fehler:                             0.0 mm



 aufteilung perkolation: 

 perkolation bodenspeicher:            0.1 mm

 abgabe grundw.speicher:               0.1 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.1 mm
        grundw. oberh.l.TG:            0.0 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:           2.0 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                -0.9 mm
     pot.entnahme GWS:                -0.9 mm
 speicherinhaltsaenderung:            -1.0 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.872 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.872 qkm


fuellenberechnung in iso
abflusz =          3477.517
niederschlag =     3477.517
flaeche zft  =        1.000
flaeche eing.=        0.872

GEBIET: Abflusswelle Interflow:

 Anzahl der Zeitschritte in iso durch Nachlauf zu hoch geworden.
 Sie wird auf 460 begrenzt !  gebiet :  4503

fuellenberechnung in iso
abflusz =           148.092
niederschlag =      148.093
flaeche zft  =        1.000
flaeche eing.=        0.872

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV:  fuellenberechnung
ISOV: Abflusz =          6393.798
ISOV: Niederschlag =     6393.803

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1001

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4501

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    2.97

 gesamtmenge an niederschlag (mm):      106.0

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     18


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  1.000


vers. flaeche  =      0.00
natur. flaeche =      0.11
gesamtflaeche  =      0.12




-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4501
 anzahl hydrotope:      18


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)     106.0 mm
 interz.verd.:                       7.5 mm
 bestandsniederschlag:              96.5 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      15.7 mm
 aktuelle verdunstung:              12.0 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              96.5 mm
 overlandflow:                      54.9 mm
 [infiltration:                     41.7 mm]
 kapilarer aufstieg:                 0.0 mm
 verdunstung (bodensp.):             4.6 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -37.1 mm
 fehler:                             0.0 mm



 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:            1.5 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:           2.4 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -0.8 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.115 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.115 qkm


fuellenberechnung in iso
abflusz =          6288.935
niederschlag =     6288.937
flaeche zft  =        1.000
flaeche eing.=        0.115

GEBIET: Abflusswelle Interflow:

 Anzahl der Zeitschritte in iso durch Nachlauf zu hoch geworden.
 Sie wird auf 460 begrenzt !  gebiet :  4501

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.115

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV:  fuellenberechnung
ISOV: Abflusz =           248.023
ISOV: Niederschlag =      248.023

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1002

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4506

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    2.97

 gesamtmenge an niederschlag (mm):      106.0

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     16


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  1.000


vers. flaeche  =      0.00
natur. flaeche =      0.20
gesamtflaeche  =      0.20




-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4506
 anzahl hydrotope:      16


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)     106.0 mm
 interz.verd.:                       7.4 mm
 bestandsniederschlag:              96.6 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      15.5 mm
 aktuelle verdunstung:              11.9 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              96.6 mm
 overlandflow:                      55.0 mm
 [infiltration:                     41.6 mm]
 kapilarer aufstieg:                 0.0 mm
 verdunstung (bodensp.):             4.5 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.1 mm
 differenz bodenspeicher:          -37.1 mm
 fehler:                             0.0 mm



 aufteilung perkolation: 

 perkolation bodenspeicher:            0.1 mm

 abgabe grundw.speicher:               0.1 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.1 mm
        grundw. oberh.l.TG:            2.1 mm
 abgabe basisabfluss:                  0.1 mm
        grundw. unterh.l.TG:           2.8 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -0.9 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.196 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.196 qkm



 Anzahl der Zeitschritte in iso durch Nachlauf zu hoch geworden.
 Sie wird auf 460 begrenzt !  gebiet :  4506

fuellenberechnung in iso
abflusz =         10773.792
niederschlag =    10774.668
flaeche zft  =        1.000
flaeche eing.=        0.196

GEBIET: Abflusswelle Interflow:

 Anzahl der Zeitschritte in iso durch Nachlauf zu hoch geworden.
 Sie wird auf 460 begrenzt !  gebiet :  4506

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.196

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV:  fuellenberechnung
ISOV: Abflusz =           107.047
ISOV: Niederschlag =      107.047

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1003

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4504

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    2.97

 gesamtmenge an niederschlag (mm):      106.0

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     86


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  1.250


vers. flaeche  =      0.11
natur. flaeche =      0.62
gesamtflaeche  =      0.74




-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4504
 anzahl hydrotope:      86


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)     106.0 mm
 interz.verd.:                       7.5 mm
 bestandsniederschlag:              96.6 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      16.0 mm
 aktuelle verdunstung:              11.1 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              96.6 mm
 overlandflow:                      26.8 mm
 [infiltration:                     69.8 mm]
 kapilarer aufstieg:                 0.0 mm
 verdunstung (bodensp.):             3.7 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -66.1 mm
 fehler:                             0.0 mm



 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:            1.4 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:           2.6 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -1.2 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.621 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.621 qkm



 Anzahl der Zeitschritte in iso durch Nachlauf zu hoch geworden.
 Sie wird auf 460 begrenzt !  gebiet :  4504

fuellenberechnung in iso
abflusz =         16636.295
niederschlag =    16637.020
flaeche zft  =        1.000
flaeche eing.=        0.621

GEBIET: Abflusswelle Interflow:

 Anzahl der Zeitschritte in iso durch Nachlauf zu hoch geworden.
 Sie wird auf 460 begrenzt !  gebiet :  4504

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.621

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV:  fuellenberechnung
ISOV: Abflusz =          9737.612
ISOV: Niederschlag =     9737.619

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1004

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4510

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    2.97

 gesamtmenge an niederschlag (mm):      106.0

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:    106


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  1.500


vers. flaeche  =      0.09
natur. flaeche =      0.48
gesamtflaeche  =      0.56




-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4510
 anzahl hydrotope:     106


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)     106.0 mm
 interz.verd.:                       7.5 mm
 bestandsniederschlag:              96.6 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      15.9 mm
 aktuelle verdunstung:              11.1 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              96.6 mm
 overlandflow:                       7.4 mm
 [infiltration:                     89.2 mm]
 kapilarer aufstieg:                 0.0 mm
 verdunstung (bodensp.):             3.6 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -85.5 mm
 fehler:                             0.0 mm



 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:            1.8 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:           5.7 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -3.9 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.478 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.478 qkm



 Anzahl der Zeitschritte in iso durch Nachlauf zu hoch geworden.
 Sie wird auf 460 begrenzt !  gebiet :  4510

fuellenberechnung in iso
abflusz =          3541.092
niederschlag =     3547.204
flaeche zft  =        1.000
flaeche eing.=        0.478

GEBIET: Abflusswelle Interflow:
fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.478

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV:  fuellenberechnung
ISOV: Abflusz =          7242.465
ISOV: Niederschlag =     7242.458

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1005

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4502

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    2.97

 gesamtmenge an niederschlag (mm):      106.0

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     77


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  1.000


vers. flaeche  =      0.11
natur. flaeche =      0.41
gesamtflaeche  =      0.53




-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4502
 anzahl hydrotope:      77


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)     106.0 mm
 interz.verd.:                       7.4 mm
 bestandsniederschlag:              96.6 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      15.5 mm
 aktuelle verdunstung:              10.7 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              96.6 mm
 overlandflow:                       9.4 mm
 [infiltration:                     87.2 mm]
 kapilarer aufstieg:                 0.0 mm
 verdunstung (bodensp.):             3.2 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -84.0 mm
 fehler:                             0.0 mm



 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:            0.5 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:           1.8 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -1.2 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.413 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.413 qkm


fuellenberechnung in iso
abflusz =          3873.910
niederschlag =     3873.914
flaeche zft  =        1.000
flaeche eing.=        0.413

GEBIET: Abflusswelle Interflow:

 Anzahl der Zeitschritte in iso durch Nachlauf zu hoch geworden.
 Sie wird auf 460 begrenzt !  gebiet :  4502

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.413

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV:  fuellenberechnung
ISOV: Abflusz =          9689.600
ISOV: Niederschlag =     9689.608

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1006

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4500

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    2.97

 gesamtmenge an niederschlag (mm):      106.0

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:    125


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  1.000


vers. flaeche  =      0.21
natur. flaeche =      0.93
gesamtflaeche  =      1.14




-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4500
 anzahl hydrotope:     125


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)     106.0 mm
 interz.verd.:                       7.5 mm
 bestandsniederschlag:              96.6 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      15.9 mm
 aktuelle verdunstung:              10.8 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              96.6 mm
 overlandflow:                      10.9 mm
 [infiltration:                     85.6 mm]
 kapilarer aufstieg:                 0.0 mm
 verdunstung (bodensp.):             3.4 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.2 mm
 differenz bodenspeicher:          -82.1 mm
 fehler:                             0.0 mm



 aufteilung perkolation: 

 perkolation bodenspeicher:            0.2 mm

 abgabe grundw.speicher:               0.2 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.2 mm
        grundw. oberh.l.TG:            0.4 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:           2.2 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                -0.9 mm
     pot.entnahme GWS:                -0.9 mm
 speicherinhaltsaenderung:            -0.8 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.933 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.933 qkm


fuellenberechnung in iso
abflusz =         10196.771
niederschlag =    10196.768
flaeche zft  =        1.000
flaeche eing.=        0.933

GEBIET: Abflusswelle Interflow:

 Anzahl der Zeitschritte in iso durch Nachlauf zu hoch geworden.
 Sie wird auf 460 begrenzt !  gebiet :  4500

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.933

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV:  fuellenberechnung
ISOV: Abflusz =         17960.375
ISOV: Niederschlag =    17960.383

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1007

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4512

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    2.97

 gesamtmenge an niederschlag (mm):      106.0

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     33


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  3.800


vers. flaeche  =      0.08
natur. flaeche =      0.41
gesamtflaeche  =      0.49


 entnahme gws [qbm/s]:       0.001


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4512
 anzahl hydrotope:      33


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)     106.0 mm
 interz.verd.:                       7.5 mm
 bestandsniederschlag:              96.6 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      16.1 mm
 aktuelle verdunstung:              10.7 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              96.6 mm
 overlandflow:                       0.0 mm
 [infiltration:                     96.6 mm]
 kapilarer aufstieg:                 0.0 mm
 verdunstung (bodensp.):             3.2 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.1 mm
 differenz bodenspeicher:          -93.2 mm
 fehler:                             0.0 mm



 aufteilung perkolation: 

 perkolation bodenspeicher:            0.1 mm

 abgabe grundw.speicher:               0.1 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.1 mm
        grundw. oberh.l.TG:            0.0 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:           1.9 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 1.0 mm
     pot.entnahme GWS:                 1.0 mm
 speicherinhaltsaenderung:            -2.8 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.408 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.408 qkm



 Anzahl der Zeitschritte in iso durch Nachlauf zu hoch geworden.
 Sie wird auf 460 begrenzt !  gebiet :  4512

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.408

GEBIET: Abflusswelle Interflow:
fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.408

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV:  fuellenberechnung
ISOV: Abflusz =          6990.282
ISOV: Niederschlag =     6990.279

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1008

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4513

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    2.97

 gesamtmenge an niederschlag (mm):      106.0

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     13


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  2.300


vers. flaeche  =      0.04
natur. flaeche =      0.21
gesamtflaeche  =      0.24


 entnahme gws [qbm/s]:       0.000


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4513
 anzahl hydrotope:      13


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)     106.0 mm
 interz.verd.:                       7.4 mm
 bestandsniederschlag:              96.6 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      15.9 mm
 aktuelle verdunstung:              10.6 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              96.6 mm
 overlandflow:                       0.0 mm
 [infiltration:                     96.6 mm]
 kapilarer aufstieg:                 0.0 mm
 verdunstung (bodensp.):             3.2 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.2 mm
 differenz bodenspeicher:          -93.3 mm
 fehler:                             0.0 mm



 aufteilung perkolation: 

 perkolation bodenspeicher:            0.2 mm

 abgabe grundw.speicher:               0.2 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.2 mm
        grundw. oberh.l.TG:            0.4 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:           3.4 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.2 mm
     pot.entnahme GWS:                 0.2 mm
 speicherinhaltsaenderung:            -3.1 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.207 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.207 qkm



 Anzahl der Zeitschritte in iso durch Nachlauf zu hoch geworden.
 Sie wird auf 460 begrenzt !  gebiet :  4513

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.207

GEBIET: Abflusswelle Interflow:
fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.207

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV:  fuellenberechnung
ISOV: Abflusz =          3156.101
ISOV: Niederschlag =     3156.102

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1009

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4516

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    2.97

 gesamtmenge an niederschlag (mm):      106.0

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     38


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  8.000


vers. flaeche  =      0.08
natur. flaeche =      0.43
gesamtflaeche  =      0.51




-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4516
 anzahl hydrotope:      38


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)     106.0 mm
 interz.verd.:                       7.5 mm
 bestandsniederschlag:              96.6 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      16.1 mm
 aktuelle verdunstung:              10.7 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              96.6 mm
 overlandflow:                       0.0 mm
 [infiltration:                     96.6 mm]
 kapilarer aufstieg:                 0.0 mm
 verdunstung (bodensp.):             3.2 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.2 mm
 differenz bodenspeicher:          -93.2 mm
 fehler:                             0.0 mm



 aufteilung perkolation: 

 perkolation bodenspeicher:            0.2 mm

 abgabe grundw.speicher:               0.2 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.2 mm
        grundw. oberh.l.TG:            4.5 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:          10.3 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -5.6 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.429 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.429 qkm



 Anzahl der Zeitschritte in iso durch Nachlauf zu hoch geworden.
 Sie wird auf 460 begrenzt !  gebiet :  4516

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.429

GEBIET: Abflusswelle Interflow:
fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.429

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV:  fuellenberechnung
ISOV: Abflusz =          6571.083
ISOV: Niederschlag =     6571.083

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1010

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4520

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    2.97

 gesamtmenge an niederschlag (mm):      106.0

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     47


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  5.000


vers. flaeche  =      0.08
natur. flaeche =      0.40
gesamtflaeche  =      0.48




-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4520
 anzahl hydrotope:      47


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)     106.0 mm
 interz.verd.:                       7.5 mm
 bestandsniederschlag:              96.6 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      16.1 mm
 aktuelle verdunstung:              10.7 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              96.6 mm
 overlandflow:                       0.1 mm
 [infiltration:                     96.5 mm]
 kapilarer aufstieg:                 0.0 mm
 verdunstung (bodensp.):             3.3 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -93.2 mm
 fehler:                             0.0 mm



 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:            6.6 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:          13.2 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -6.6 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.404 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.404 qkm



 Anzahl der Zeitschritte in iso durch Nachlauf zu hoch geworden.
 Sie wird auf 460 begrenzt !  gebiet :  4520

fuellenberechnung in iso
abflusz =            45.090
niederschlag =       45.168
flaeche zft  =        1.000
flaeche eing.=        0.404

GEBIET: Abflusswelle Interflow:
fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.404

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV:  fuellenberechnung
ISOV: Abflusz =          6442.238
ISOV: Niederschlag =     6442.239

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1011

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4523

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    2.97

 gesamtmenge an niederschlag (mm):      106.0

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     66


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  2.500


vers. flaeche  =      0.06
natur. flaeche =      0.42
gesamtflaeche  =      0.48




-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4523
 anzahl hydrotope:      66


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)     106.0 mm
 interz.verd.:                       7.6 mm
 bestandsniederschlag:              96.3 mm
 differenz interz.speicher:         -2.1 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      15.5 mm
 aktuelle verdunstung:              10.7 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              96.3 mm
 overlandflow:                       1.9 mm
 [infiltration:                     94.4 mm]
 kapilarer aufstieg:                 0.0 mm
 verdunstung (bodensp.):             3.1 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.1 mm
 differenz bodenspeicher:          -91.2 mm
 fehler:                             0.0 mm



 aufteilung perkolation: 

 perkolation bodenspeicher:            0.1 mm

 abgabe grundw.speicher:               0.1 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.1 mm
        grundw. oberh.l.TG:            3.0 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:           7.6 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -4.5 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.416 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.416 qkm



 Anzahl der Zeitschritte in iso durch Nachlauf zu hoch geworden.
 Sie wird auf 460 begrenzt !  gebiet :  4523

fuellenberechnung in iso
abflusz =           802.481
niederschlag =      803.867
flaeche zft  =        1.000
flaeche eing.=        0.416

GEBIET: Abflusswelle Interflow:
fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.416

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV:  fuellenberechnung
ISOV: Abflusz =          5122.901
ISOV: Niederschlag =     5122.897

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1012

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4526

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    2.97

 gesamtmenge an niederschlag (mm):      106.0

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     86


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  1.000


vers. flaeche  =      0.07
natur. flaeche =      0.61
gesamtflaeche  =      0.68




-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4526
 anzahl hydrotope:      86


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)     106.0 mm
 interz.verd.:                       7.7 mm
 bestandsniederschlag:              96.2 mm
 differenz interz.speicher:         -2.1 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      15.8 mm
 aktuelle verdunstung:              11.3 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              96.2 mm
 overlandflow:                       8.4 mm
 [infiltration:                     87.9 mm]
 kapilarer aufstieg:                 0.0 mm
 verdunstung (bodensp.):             3.6 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -84.2 mm
 fehler:                             0.0 mm



 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:            4.1 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:           9.1 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -4.9 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.608 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.608 qkm



 Anzahl der Zeitschritte in iso durch Nachlauf zu hoch geworden.
 Sie wird auf 460 begrenzt !  gebiet :  4526

fuellenberechnung in iso
abflusz =          5069.083
niederschlag =     5077.840
flaeche zft  =        1.000
flaeche eing.=        0.608

GEBIET: Abflusswelle Interflow:
fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.608

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV:  fuellenberechnung
ISOV: Abflusz =          6353.936
ISOV: Niederschlag =     6353.934

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1013

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4514

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    2.97

 gesamtmenge an niederschlag (mm):      106.0

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     96


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  8.000


vers. flaeche  =      0.17
natur. flaeche =      0.70
gesamtflaeche  =      0.87




-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4514
 anzahl hydrotope:      96


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)     106.0 mm
 interz.verd.:                       7.5 mm
 bestandsniederschlag:              96.6 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      16.1 mm
 aktuelle verdunstung:              10.7 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              96.6 mm
 overlandflow:                       1.3 mm
 [infiltration:                     95.3 mm]
 kapilarer aufstieg:                 0.0 mm
 verdunstung (bodensp.):             3.3 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.1 mm
 differenz bodenspeicher:          -91.9 mm
 fehler:                             0.0 mm



 aufteilung perkolation: 

 perkolation bodenspeicher:            0.1 mm

 abgabe grundw.speicher:               0.1 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.1 mm
        grundw. oberh.l.TG:            1.0 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:           5.3 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -4.2 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.701 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.701 qkm



 Anzahl der Zeitschritte in iso durch Nachlauf zu hoch geworden.
 Sie wird auf 460 begrenzt !  gebiet :  4514

fuellenberechnung in iso
abflusz =           885.050
niederschlag =      886.578
flaeche zft  =        1.000
flaeche eing.=        0.701

GEBIET: Abflusswelle Interflow:
fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.701

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV:  fuellenberechnung
ISOV: Abflusz =         14356.068
ISOV: Niederschlag =    14356.076

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1014

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4515

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    2.97

 gesamtmenge an niederschlag (mm):      106.0

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     23


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  8.000


vers. flaeche  =      0.03
natur. flaeche =      0.06
gesamtflaeche  =      0.09




-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4515
 anzahl hydrotope:      23


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)     106.0 mm
 interz.verd.:                       7.1 mm
 bestandsniederschlag:              97.2 mm
 differenz interz.speicher:         -1.8 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      13.7 mm
 aktuelle verdunstung:               9.6 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              97.2 mm
 overlandflow:                       3.2 mm
 [infiltration:                     94.0 mm]
 kapilarer aufstieg:                 0.0 mm
 verdunstung (bodensp.):             2.5 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.1 mm
 differenz bodenspeicher:          -91.4 mm
 fehler:                             0.0 mm



 aufteilung perkolation: 

 perkolation bodenspeicher:            0.1 mm

 abgabe grundw.speicher:               0.1 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.1 mm
        grundw. oberh.l.TG:            9.4 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:          11.2 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -1.8 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.060 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.060 qkm



 Anzahl der Zeitschritte in iso durch Nachlauf zu hoch geworden.
 Sie wird auf 460 begrenzt !  gebiet :  4515

fuellenberechnung in iso
abflusz =           191.515
niederschlag =      191.846
flaeche zft  =        1.000
flaeche eing.=        0.060

GEBIET: Abflusswelle Interflow:
fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.060

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV:  fuellenberechnung
ISOV: Abflusz =          2421.279
ISOV: Niederschlag =     2421.278

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1015

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4518

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    2.97

 gesamtmenge an niederschlag (mm):      106.0

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     15


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  2.000


vers. flaeche  =      0.00
natur. flaeche =      0.02
gesamtflaeche  =      0.02




-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4518
 anzahl hydrotope:      15


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)     106.0 mm
 interz.verd.:                       7.4 mm
 bestandsniederschlag:              96.7 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      15.6 mm
 aktuelle verdunstung:              10.5 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              96.7 mm
 overlandflow:                       0.2 mm
 [infiltration:                     96.5 mm]
 kapilarer aufstieg:                 0.0 mm
 verdunstung (bodensp.):             3.1 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.1 mm
 differenz bodenspeicher:          -93.2 mm
 fehler:                             0.0 mm



 aufteilung perkolation: 

 perkolation bodenspeicher:            0.1 mm

 abgabe grundw.speicher:               0.1 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.1 mm
        grundw. oberh.l.TG:           36.6 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:          43.2 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -6.5 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.020 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.020 qkm



 Anzahl der Zeitschritte in iso durch Nachlauf zu hoch geworden.
 Sie wird auf 460 begrenzt !  gebiet :  4518

fuellenberechnung in iso
abflusz =             3.900
niederschlag =        3.907
flaeche zft  =        1.000
flaeche eing.=        0.020

GEBIET: Abflusswelle Interflow:
fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.020

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV:  fuellenberechnung
ISOV: Abflusz =            95.511
ISOV: Niederschlag =       95.511

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1016

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4519

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    2.97

 gesamtmenge an niederschlag (mm):      106.0

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     73


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  7.000


vers. flaeche  =      0.05
natur. flaeche =      0.27
gesamtflaeche  =      0.33




-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4519
 anzahl hydrotope:      73


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)     106.0 mm
 interz.verd.:                       7.4 mm
 bestandsniederschlag:              96.7 mm
 differenz interz.speicher:         -1.9 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      15.4 mm
 aktuelle verdunstung:              10.6 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              96.7 mm
 overlandflow:                       5.1 mm
 [infiltration:                     91.6 mm]
 kapilarer aufstieg:                 0.0 mm
 verdunstung (bodensp.):             3.2 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.1 mm
 differenz bodenspeicher:          -88.3 mm
 fehler:                             0.0 mm



 aufteilung perkolation: 

 perkolation bodenspeicher:            0.1 mm

 abgabe grundw.speicher:               0.1 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.1 mm
        grundw. oberh.l.TG:           25.1 mm
 abgabe basisabfluss:                  4.8 mm
        grundw. unterh.l.TG:          21.3 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -1.0 mm
 fehler:                               0.1 mm


 flaechenanteile: 

   grundwasserleiter:                0.272 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.272 qkm



 Anzahl der Zeitschritte in iso durch Nachlauf zu hoch geworden.
 Sie wird auf 460 begrenzt !  gebiet :  4519

fuellenberechnung in iso
abflusz =          1394.967
niederschlag =     1397.376
flaeche zft  =        1.000
flaeche eing.=        0.272

GEBIET: Abflusswelle Interflow:
fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.272

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV:  fuellenberechnung
ISOV: Abflusz =          4585.370
ISOV: Niederschlag =     4585.374

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1017

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4522

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    2.97

 gesamtmenge an niederschlag (mm):      106.0

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     19


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  5.000


vers. flaeche  =      0.02
natur. flaeche =      0.04
gesamtflaeche  =      0.05




-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4522
 anzahl hydrotope:      19


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)     106.0 mm
 interz.verd.:                       7.1 mm
 bestandsniederschlag:              97.1 mm
 differenz interz.speicher:         -1.8 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      14.0 mm
 aktuelle verdunstung:               9.8 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              97.1 mm
 overlandflow:                      11.9 mm
 [infiltration:                     85.1 mm]
 kapilarer aufstieg:                 0.0 mm
 verdunstung (bodensp.):             2.7 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -82.4 mm
 fehler:                             0.0 mm



 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:          111.8 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:         114.1 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -2.3 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.036 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.036 qkm



 Anzahl der Zeitschritte in iso durch Nachlauf zu hoch geworden.
 Sie wird auf 460 begrenzt !  gebiet :  4522

fuellenberechnung in iso
abflusz =           427.597
niederschlag =      428.336
flaeche zft  =        1.000
flaeche eing.=        0.036

GEBIET: Abflusswelle Interflow:
fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.036

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV:  fuellenberechnung
ISOV: Abflusz =          1471.680
ISOV: Niederschlag =     1471.683

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1018

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4524

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    2.97

 gesamtmenge an niederschlag (mm):      106.0

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     41


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 = 10.000


vers. flaeche  =      0.01
natur. flaeche =      0.23
gesamtflaeche  =      0.24




-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4524
 anzahl hydrotope:      41


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)     106.0 mm
 interz.verd.:                       7.7 mm
 bestandsniederschlag:              95.8 mm
 differenz interz.speicher:         -2.5 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      14.8 mm
 aktuelle verdunstung:              10.6 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              95.8 mm
 overlandflow:                       5.3 mm
 [infiltration:                     90.5 mm]
 kapilarer aufstieg:                 0.0 mm
 verdunstung (bodensp.):             2.9 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -87.6 mm
 fehler:                             0.0 mm



 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:           39.7 mm
 abgabe basisabfluss:                 10.0 mm
        grundw. unterh.l.TG:          30.6 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -0.9 mm
 fehler:                               0.1 mm


 flaechenanteile: 

   grundwasserleiter:                0.234 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.234 qkm



 Anzahl der Zeitschritte in iso durch Nachlauf zu hoch geworden.
 Sie wird auf 460 begrenzt !  gebiet :  4524

fuellenberechnung in iso
abflusz =          1232.499
niederschlag =     1234.628
flaeche zft  =        1.000
flaeche eing.=        0.234

GEBIET: Abflusswelle Interflow:
fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.234

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV:  fuellenberechnung
ISOV: Abflusz =           638.633
ISOV: Niederschlag =      638.634

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1019

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4527

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    2.97

 gesamtmenge an niederschlag (mm):      106.0

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     14


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  1.000


vers. flaeche  =      0.03
natur. flaeche =      0.15
gesamtflaeche  =      0.18




-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4527
 anzahl hydrotope:      14


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)     106.0 mm
 interz.verd.:                       7.5 mm
 bestandsniederschlag:              96.6 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      16.1 mm
 aktuelle verdunstung:              11.1 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              96.6 mm
 overlandflow:                      12.5 mm
 [infiltration:                     84.0 mm]
 kapilarer aufstieg:                 0.0 mm
 verdunstung (bodensp.):             3.6 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -80.4 mm
 fehler:                             0.0 mm



 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:            7.9 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:          10.6 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -2.8 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.148 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.148 qkm



 Anzahl der Zeitschritte in iso durch Nachlauf zu hoch geworden.
 Sie wird auf 460 begrenzt !  gebiet :  4527

fuellenberechnung in iso
abflusz =          1849.348
niederschlag =     1852.543
flaeche zft  =        1.000
flaeche eing.=        0.148

GEBIET: Abflusswelle Interflow:
fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.148

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV:  fuellenberechnung
ISOV: Abflusz =          2917.835
ISOV: Niederschlag =     2917.834

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1020

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4530

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    2.97

 gesamtmenge an niederschlag (mm):      106.0

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     67


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  2.500


vers. flaeche  =      0.05
natur. flaeche =      0.28
gesamtflaeche  =      0.33




-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4530
 anzahl hydrotope:      67


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)     106.0 mm
 interz.verd.:                       7.5 mm
 bestandsniederschlag:              96.6 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      16.0 mm
 aktuelle verdunstung:              11.1 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              96.6 mm
 overlandflow:                      11.6 mm
 [infiltration:                     85.0 mm]
 kapilarer aufstieg:                 0.0 mm
 verdunstung (bodensp.):             3.7 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -81.3 mm
 fehler:                             0.0 mm



 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:            3.8 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:           7.0 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -3.1 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.275 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.275 qkm



 Anzahl der Zeitschritte in iso durch Nachlauf zu hoch geworden.
 Sie wird auf 460 begrenzt !  gebiet :  4530

fuellenberechnung in iso
abflusz =          3186.937
niederschlag =     3192.443
flaeche zft  =        1.000
flaeche eing.=        0.275

GEBIET: Abflusswelle Interflow:
fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.275

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV:  fuellenberechnung
ISOV: Abflusz =          4505.386
ISOV: Niederschlag =     4505.384

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1021

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4532

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    2.97

 gesamtmenge an niederschlag (mm):      106.0

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     85


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  8.000


vers. flaeche  =      0.02
natur. flaeche =      1.46
gesamtflaeche  =      1.49




-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4532
 anzahl hydrotope:      85


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)     106.0 mm
 interz.verd.:                       8.4 mm
 bestandsniederschlag:              95.1 mm
 differenz interz.speicher:         -2.6 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      15.6 mm
 aktuelle verdunstung:              11.4 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              95.1 mm
 overlandflow:                       6.7 mm
 [infiltration:                     88.4 mm]
 kapilarer aufstieg:                 0.0 mm
 verdunstung (bodensp.):             3.0 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.1 mm
 differenz bodenspeicher:          -85.3 mm
 fehler:                             0.0 mm



 aufteilung perkolation: 

 perkolation bodenspeicher:            0.1 mm

 abgabe grundw.speicher:               0.1 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.1 mm
        grundw. oberh.l.TG:            8.8 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:          12.2 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -3.3 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                1.464 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    1.464 qkm



 Anzahl der Zeitschritte in iso durch Nachlauf zu hoch geworden.
 Sie wird auf 460 begrenzt !  gebiet :  4532

fuellenberechnung in iso
abflusz =          9856.149
niederschlag =     9873.176
flaeche zft  =        1.000
flaeche eing.=        1.464

GEBIET: Abflusswelle Interflow:
fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        1.464

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV:  fuellenberechnung
ISOV: Abflusz =          1957.208
ISOV: Niederschlag =     1957.210

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1022

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4534

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    2.97

 gesamtmenge an niederschlag (mm):      106.0

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     32


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  0.900
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  2.200


vers. flaeche  =      0.08
natur. flaeche =      0.30
gesamtflaeche  =      0.38




-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4534
 anzahl hydrotope:      32


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)     106.0 mm
 interz.verd.:                       7.5 mm
 bestandsniederschlag:              96.5 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      16.0 mm
 aktuelle verdunstung:              10.3 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              96.5 mm
 overlandflow:                      24.7 mm
 [infiltration:                     71.8 mm]
 kapilarer aufstieg:                 0.0 mm
 verdunstung (bodensp.):             2.8 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -69.1 mm
 fehler:                             0.0 mm



 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:            0.0 mm
 abgabe basisabfluss:                  1.3 mm
        grundw. unterh.l.TG:          11.9 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:               -13.2 mm
     pot.entnahme GWS:               -13.2 mm
 speicherinhaltsaenderung:             0.0 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.299 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.299 qkm


fuellenberechnung in iso
abflusz =          7382.096
niederschlag =     7382.094
flaeche zft  =        1.000
flaeche eing.=        0.299

GEBIET: Abflusswelle Interflow:
fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.299

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV:  fuellenberechnung
ISOV: Abflusz =          6562.854
ISOV: Niederschlag =     6562.854

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1023

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4542

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    2.97

 gesamtmenge an niederschlag (mm):      106.0

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     49


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  0.900
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  1.500


vers. flaeche  =      0.07
natur. flaeche =      0.39
gesamtflaeche  =      0.46




-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4542
 anzahl hydrotope:      49


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)     106.0 mm
 interz.verd.:                       7.5 mm
 bestandsniederschlag:              96.6 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      16.2 mm
 aktuelle verdunstung:              10.3 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              96.6 mm
 overlandflow:                      24.7 mm
 [infiltration:                     71.8 mm]
 kapilarer aufstieg:                 0.0 mm
 verdunstung (bodensp.):             2.8 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -69.0 mm
 fehler:                             0.0 mm



 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:            1.3 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:           3.4 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -2.0 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.395 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.395 qkm


fuellenberechnung in iso
abflusz =          9760.157
niederschlag =     9760.145
flaeche zft  =        1.000
flaeche eing.=        0.395

GEBIET: Abflusswelle Interflow:
fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.395

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV:  fuellenberechnung
ISOV: Abflusz =          5676.286
ISOV: Niederschlag =     5676.286

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1024

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4537

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    2.97

 gesamtmenge an niederschlag (mm):      106.0

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     19


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  0.900
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  2.700


vers. flaeche  =      0.01
natur. flaeche =      0.06
gesamtflaeche  =      0.07




-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4537
 anzahl hydrotope:      19


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)     106.0 mm
 interz.verd.:                       7.5 mm
 bestandsniederschlag:              96.6 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      16.1 mm
 aktuelle verdunstung:              10.3 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              96.6 mm
 overlandflow:                      24.7 mm
 [infiltration:                     71.9 mm]
 kapilarer aufstieg:                 0.0 mm
 verdunstung (bodensp.):             2.8 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -69.0 mm
 fehler:                             0.0 mm



 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:           19.5 mm
 abgabe basisabfluss:                  4.9 mm
        grundw. unterh.l.TG:          26.7 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:               -11.9 mm
     pot.entnahme GWS:               -11.9 mm
 speicherinhaltsaenderung:            -0.2 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.064 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.064 qkm


fuellenberechnung in iso
abflusz =          1571.298
niederschlag =     1571.299
flaeche zft  =        1.000
flaeche eing.=        0.064

GEBIET: Abflusswelle Interflow:
fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.064

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV:  fuellenberechnung
ISOV: Abflusz =           938.484
ISOV: Niederschlag =      938.484

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1025

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4543

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    2.97

 gesamtmenge an niederschlag (mm):      106.0

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     80


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  0.900
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  2.000


vers. flaeche  =      0.18
natur. flaeche =      0.92
gesamtflaeche  =      1.10




-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4543
 anzahl hydrotope:      80


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)     106.0 mm
 interz.verd.:                       7.5 mm
 bestandsniederschlag:              96.6 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      16.1 mm
 aktuelle verdunstung:              10.3 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              96.6 mm
 overlandflow:                      24.7 mm
 [infiltration:                     71.9 mm]
 kapilarer aufstieg:                 0.0 mm
 verdunstung (bodensp.):             2.8 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -69.0 mm
 fehler:                             0.0 mm



 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:            1.3 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:           4.5 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -3.2 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.918 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.918 qkm


fuellenberechnung in iso
abflusz =         22705.393
niederschlag =    22705.410
flaeche zft  =        1.000
flaeche eing.=        0.918

GEBIET: Abflusswelle Interflow:
fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.918

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV:  fuellenberechnung
ISOV: Abflusz =         15458.436
ISOV: Niederschlag =    15458.438

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1026

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4549

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    2.97

 gesamtmenge an niederschlag (mm):      106.0

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     73


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  0.900
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  1.000


vers. flaeche  =      0.20
natur. flaeche =      1.08
gesamtflaeche  =      1.28




-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4549
 anzahl hydrotope:      73


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)     106.0 mm
 interz.verd.:                       7.5 mm
 bestandsniederschlag:              96.6 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      16.1 mm
 aktuelle verdunstung:              10.3 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              96.6 mm
 overlandflow:                      26.8 mm
 [infiltration:                     69.7 mm]
 kapilarer aufstieg:                 0.0 mm
 verdunstung (bodensp.):             2.8 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -66.9 mm
 fehler:                             0.0 mm



 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:            1.5 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:           6.1 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -4.6 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                1.076 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    1.076 qkm


fuellenberechnung in iso
abflusz =         28876.770
niederschlag =    28876.791
flaeche zft  =        1.000
flaeche eing.=        1.076

GEBIET: Abflusswelle Interflow:
fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        1.076

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV:  fuellenberechnung
ISOV: Abflusz =         17273.129
ISOV: Niederschlag =    17273.143

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1027

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4551

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    2.97

 gesamtmenge an niederschlag (mm):      106.0

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:    113


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  0.900
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  2.000


vers. flaeche  =      0.12
natur. flaeche =      0.64
gesamtflaeche  =      0.76




-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4551
 anzahl hydrotope:     113


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)     106.0 mm
 interz.verd.:                       7.5 mm
 bestandsniederschlag:              96.6 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      16.1 mm
 aktuelle verdunstung:              10.3 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              96.6 mm
 overlandflow:                      42.6 mm
 [infiltration:                     54.0 mm]
 kapilarer aufstieg:                 0.0 mm
 verdunstung (bodensp.):             2.9 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -51.2 mm
 fehler:                             0.0 mm



 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:            7.3 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:          15.3 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -8.0 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.641 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.641 qkm


fuellenberechnung in iso
abflusz =         27306.980
niederschlag =    27307.000
flaeche zft  =        1.000
flaeche eing.=        0.641

GEBIET: Abflusswelle Interflow:
fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.641

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV:  fuellenberechnung
ISOV: Abflusz =         10359.960
ISOV: Niederschlag =    10359.965

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1028

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4552

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    2.97

 gesamtmenge an niederschlag (mm):      106.0

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     31


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  0.900
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  7.000


vers. flaeche  =      0.02
natur. flaeche =      0.07
gesamtflaeche  =      0.10




-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4552
 anzahl hydrotope:      31


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)     106.0 mm
 interz.verd.:                       7.4 mm
 bestandsniederschlag:              96.6 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      15.9 mm
 aktuelle verdunstung:              10.2 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              96.6 mm
 overlandflow:                      33.2 mm
 [infiltration:                     63.4 mm]
 kapilarer aufstieg:                 0.0 mm
 verdunstung (bodensp.):             2.8 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -60.6 mm
 fehler:                             0.0 mm



 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:           39.5 mm
 abgabe basisabfluss:                 17.7 mm
        grundw. unterh.l.TG:          22.6 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -1.0 mm
 fehler:                               0.2 mm


 flaechenanteile: 

   grundwasserleiter:                0.074 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.074 qkm


fuellenberechnung in iso
abflusz =          2471.384
niederschlag =     2471.385
flaeche zft  =        1.000
flaeche eing.=        0.074

GEBIET: Abflusswelle Interflow:
fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.074

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV:  fuellenberechnung
ISOV: Abflusz =          1786.630
ISOV: Niederschlag =     1786.631

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1029

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4553

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    2.97

 gesamtmenge an niederschlag (mm):      106.0

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     35


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  0.900
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 = 12.200


vers. flaeche  =      0.02
natur. flaeche =      0.06
gesamtflaeche  =      0.08




-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4553
 anzahl hydrotope:      35


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)     106.0 mm
 interz.verd.:                       7.4 mm
 bestandsniederschlag:              96.6 mm
 differenz interz.speicher:         -1.9 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      15.8 mm
 aktuelle verdunstung:              10.2 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              96.6 mm
 overlandflow:                      25.1 mm
 [infiltration:                     71.6 mm]
 kapilarer aufstieg:                 0.0 mm
 verdunstung (bodensp.):             2.7 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -68.8 mm
 fehler:                             0.0 mm



 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:           79.0 mm
 abgabe basisabfluss:                 16.0 mm
        grundw. unterh.l.TG:          64.0 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -1.2 mm
 fehler:                               0.2 mm


 flaechenanteile: 

   grundwasserleiter:                0.060 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.060 qkm


fuellenberechnung in iso
abflusz =          1513.057
niederschlag =     1513.059
flaeche zft  =        1.000
flaeche eing.=        0.060

GEBIET: Abflusswelle Interflow:
fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.060

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV:  fuellenberechnung
ISOV: Abflusz =          1661.261
ISOV: Niederschlag =     1661.262

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1030

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4558

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    2.97

 gesamtmenge an niederschlag (mm):      106.0

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     90


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  0.900
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 = 10.000


vers. flaeche  =      0.06
natur. flaeche =      0.40
gesamtflaeche  =      0.46




-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4558
 anzahl hydrotope:      90


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)     106.0 mm
 interz.verd.:                       7.5 mm
 bestandsniederschlag:              96.6 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      15.9 mm
 aktuelle verdunstung:              10.6 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              96.6 mm
 overlandflow:                      47.6 mm
 [infiltration:                     49.0 mm]
 kapilarer aufstieg:                 0.0 mm
 verdunstung (bodensp.):             3.1 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -45.9 mm
 fehler:                             0.0 mm



 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:           29.0 mm
 abgabe basisabfluss:                  2.8 mm
        grundw. unterh.l.TG:          27.8 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -1.7 mm
 fehler:                               0.1 mm


 flaechenanteile: 

   grundwasserleiter:                0.400 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.400 qkm


fuellenberechnung in iso
abflusz =         19008.186
niederschlag =    19008.189
flaeche zft  =        1.000
flaeche eing.=        0.400

GEBIET: Abflusswelle Interflow:
fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.400

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV:  fuellenberechnung
ISOV: Abflusz =          5060.804
ISOV: Niederschlag =     5060.808

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1031

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4533

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    2.97

 gesamtmenge an niederschlag (mm):      106.0

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     26


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  0.900
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  0.500


vers. flaeche  =      0.05
natur. flaeche =      0.21
gesamtflaeche  =      0.26


 entnahme gws [qbm/s]:       0.000


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4533
 anzahl hydrotope:      26


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)     106.0 mm
 interz.verd.:                       7.5 mm
 bestandsniederschlag:              96.6 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      16.1 mm
 aktuelle verdunstung:              10.3 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              96.6 mm
 overlandflow:                      24.7 mm
 [infiltration:                     71.9 mm]
 kapilarer aufstieg:                 0.0 mm
 verdunstung (bodensp.):             2.8 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -69.0 mm
 fehler:                             0.0 mm



 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:            0.0 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:           3.5 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.2 mm
     pot.entnahme GWS:                 0.2 mm
 speicherinhaltsaenderung:            -3.6 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.211 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.211 qkm



 Anzahl der Zeitschritte in iso durch Nachlauf zu hoch geworden.
 Sie wird auf 460 begrenzt !  gebiet :  4533

fuellenberechnung in iso
abflusz =          5199.340
niederschlag =     5208.328
flaeche zft  =        1.000
flaeche eing.=        0.211

GEBIET: Abflusswelle Interflow:
fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.211

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV:  fuellenberechnung
ISOV: Abflusz =          3886.513
ISOV: Niederschlag =     3886.515

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1032

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4535

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    2.97

 gesamtmenge an niederschlag (mm):      106.0

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     16


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  0.900
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  2.500


vers. flaeche  =      0.02
natur. flaeche =      0.27
gesamtflaeche  =      0.28




-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4535
 anzahl hydrotope:      16


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)     106.0 mm
 interz.verd.:                       7.8 mm
 bestandsniederschlag:              96.1 mm
 differenz interz.speicher:         -2.2 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      16.2 mm
 aktuelle verdunstung:              10.6 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              96.1 mm
 overlandflow:                      24.8 mm
 [infiltration:                     71.3 mm]
 kapilarer aufstieg:                 0.0 mm
 verdunstung (bodensp.):             2.8 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -68.5 mm
 fehler:                             0.0 mm



 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:            9.4 mm
 abgabe basisabfluss:                  3.9 mm
        grundw. unterh.l.TG:           5.9 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -0.5 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.266 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.266 qkm


fuellenberechnung in iso
abflusz =          6593.648
niederschlag =     6593.643
flaeche zft  =        1.000
flaeche eing.=        0.266

GEBIET: Abflusswelle Interflow:
fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.266

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV:  fuellenberechnung
ISOV: Abflusz =          1497.129
ISOV: Niederschlag =     1497.130

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1033

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4539

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    2.97

 gesamtmenge an niederschlag (mm):      106.0

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     66


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  0.900
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  8.000


vers. flaeche  =      0.32
natur. flaeche =      2.86
gesamtflaeche  =      3.19


 entnahme gws [qbm/s]:       0.001


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4539
 anzahl hydrotope:      66


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)     106.0 mm
 interz.verd.:                       8.9 mm
 bestandsniederschlag:              94.3 mm
 differenz interz.speicher:         -2.9 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      16.4 mm
 aktuelle verdunstung:              11.3 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              94.3 mm
 overlandflow:                      24.7 mm
 [infiltration:                     69.5 mm]
 kapilarer aufstieg:                 0.0 mm
 verdunstung (bodensp.):             2.4 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -67.2 mm
 fehler:                             0.0 mm



 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:            1.1 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:           5.2 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.1 mm
     pot.entnahme GWS:                 0.1 mm
 speicherinhaltsaenderung:            -4.3 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                2.864 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    2.864 qkm


fuellenberechnung in iso
abflusz =         70764.469
niederschlag =    70764.781
flaeche zft  =        1.000
flaeche eing.=        2.864

GEBIET: Abflusswelle Interflow:
fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        2.864

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV:  fuellenberechnung
ISOV: Abflusz =         27350.143
ISOV: Niederschlag =    27350.137

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1034

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4541

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    2.97

 gesamtmenge an niederschlag (mm):      106.0

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     46


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  0.900
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  5.000


vers. flaeche  =      0.09
natur. flaeche =      0.40
gesamtflaeche  =      0.49




-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4541
 anzahl hydrotope:      46


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)     106.0 mm
 interz.verd.:                       8.1 mm
 bestandsniederschlag:              95.5 mm
 differenz interz.speicher:         -2.4 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      16.1 mm
 aktuelle verdunstung:              10.9 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              95.5 mm
 overlandflow:                      32.1 mm
 [infiltration:                     63.4 mm]
 kapilarer aufstieg:                 0.0 mm
 verdunstung (bodensp.):             2.8 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -60.6 mm
 fehler:                             0.0 mm



 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:           26.2 mm
 abgabe basisabfluss:                  3.6 mm
        grundw. unterh.l.TG:          23.0 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -0.5 mm
 fehler:                               0.1 mm


 flaechenanteile: 

   grundwasserleiter:                0.401 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.401 qkm


fuellenberechnung in iso
abflusz =         12870.365
niederschlag =    12870.370
flaeche zft  =        1.000
flaeche eing.=        0.401

GEBIET: Abflusswelle Interflow:
fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.401

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV:  fuellenberechnung
ISOV: Abflusz =          7808.908
ISOV: Niederschlag =     7808.909

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1035

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4547

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    2.97

 gesamtmenge an niederschlag (mm):      106.0

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     38


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  0.900
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  2.750


vers. flaeche  =      0.04
natur. flaeche =      0.11
gesamtflaeche  =      0.15




-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4547
 anzahl hydrotope:      38


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)     106.0 mm
 interz.verd.:                       7.5 mm
 bestandsniederschlag:              96.5 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      16.3 mm
 aktuelle verdunstung:              11.4 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              96.5 mm
 overlandflow:                      56.8 mm
 [infiltration:                     39.7 mm]
 kapilarer aufstieg:                 0.0 mm
 verdunstung (bodensp.):             3.9 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -35.9 mm
 fehler:                             0.0 mm



 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:           13.3 mm
 abgabe basisabfluss:                  8.1 mm
        grundw. unterh.l.TG:          17.7 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:               -12.5 mm
     pot.entnahme GWS:               -12.5 mm
 speicherinhaltsaenderung:             0.0 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.113 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.113 qkm


fuellenberechnung in iso
abflusz =          6398.882
niederschlag =     6398.880
flaeche zft  =        1.000
flaeche eing.=        0.113

GEBIET: Abflusswelle Interflow:
fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.113

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV:  fuellenberechnung
ISOV: Abflusz =          3098.845
ISOV: Niederschlag =     3098.845

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1036

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4544

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    2.97

 gesamtmenge an niederschlag (mm):      106.0

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     49


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  0.900
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  2.000


vers. flaeche  =      0.08
natur. flaeche =      0.38
gesamtflaeche  =      0.46




-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4544
 anzahl hydrotope:      49


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)     106.0 mm
 interz.verd.:                       7.5 mm
 bestandsniederschlag:              96.6 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      16.2 mm
 aktuelle verdunstung:              10.5 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              96.6 mm
 overlandflow:                      30.2 mm
 [infiltration:                     66.3 mm]
 kapilarer aufstieg:                 0.0 mm
 verdunstung (bodensp.):             3.0 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -63.3 mm
 fehler:                             0.0 mm



 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:            1.8 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:           5.0 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                -0.7 mm
     pot.entnahme GWS:                -0.7 mm
 speicherinhaltsaenderung:            -2.5 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.385 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.385 qkm


fuellenberechnung in iso
abflusz =         11626.167
niederschlag =    11626.177
flaeche zft  =        1.000
flaeche eing.=        0.385

GEBIET: Abflusswelle Interflow:
fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.385

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV:  fuellenberechnung
ISOV: Abflusz =          6537.316
ISOV: Niederschlag =     6537.322

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1037

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4546

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    2.97

 gesamtmenge an niederschlag (mm):      106.0

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     67


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  0.900
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  2.250


vers. flaeche  =      0.04
natur. flaeche =      0.22
gesamtflaeche  =      0.26




-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4546
 anzahl hydrotope:      67


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)     106.0 mm
 interz.verd.:                       7.5 mm
 bestandsniederschlag:              96.6 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      16.2 mm
 aktuelle verdunstung:              10.6 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              96.6 mm
 overlandflow:                      46.2 mm
 [infiltration:                     50.3 mm]
 kapilarer aufstieg:                 0.0 mm
 verdunstung (bodensp.):             3.2 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -47.2 mm
 fehler:                             0.0 mm



 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:            8.8 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:          12.9 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -4.1 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.216 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.216 qkm


fuellenberechnung in iso
abflusz =          9973.537
niederschlag =     9973.545
flaeche zft  =        1.000
flaeche eing.=        0.216

GEBIET: Abflusswelle Interflow:
fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.216

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV:  fuellenberechnung
ISOV: Abflusz =          3509.814
ISOV: Niederschlag =     3509.814

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1038

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4548

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    2.97

 gesamtmenge an niederschlag (mm):      106.0

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:    125


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  0.900
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  2.000


vers. flaeche  =      0.09
natur. flaeche =      0.48
gesamtflaeche  =      0.58




-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4548
 anzahl hydrotope:     125


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)     106.0 mm
 interz.verd.:                       7.5 mm
 bestandsniederschlag:              96.6 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      16.2 mm
 aktuelle verdunstung:              10.6 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              96.6 mm
 overlandflow:                      36.2 mm
 [infiltration:                     60.4 mm]
 kapilarer aufstieg:                 0.0 mm
 verdunstung (bodensp.):             3.1 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -57.3 mm
 fehler:                             0.0 mm



 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:           13.7 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:          18.0 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -4.3 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.483 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.483 qkm


fuellenberechnung in iso
abflusz =         17458.908
niederschlag =    17458.908
flaeche zft  =        1.000
flaeche eing.=        0.483

GEBIET: Abflusswelle Interflow:
fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.483

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV:  fuellenberechnung
ISOV: Abflusz =          8039.283
ISOV: Niederschlag =     8039.288

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1039

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4554

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    2.97

 gesamtmenge an niederschlag (mm):      106.0

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     34


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  0.900
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  3.000


vers. flaeche  =      0.18
natur. flaeche =      0.55
gesamtflaeche  =      0.72




-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4554
 anzahl hydrotope:      34


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)     106.0 mm
 interz.verd.:                       7.6 mm
 bestandsniederschlag:              96.3 mm
 differenz interz.speicher:         -2.1 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      15.7 mm
 aktuelle verdunstung:              10.2 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              96.3 mm
 overlandflow:                      24.7 mm
 [infiltration:                     71.6 mm]
 kapilarer aufstieg:                 0.0 mm
 verdunstung (bodensp.):             2.6 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -69.0 mm
 fehler:                             0.0 mm



 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:            8.0 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:          12.4 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -4.4 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.547 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.547 qkm


fuellenberechnung in iso
abflusz =         13509.997
niederschlag =    13509.995
flaeche zft  =        1.000
flaeche eing.=        0.547

GEBIET: Abflusswelle Interflow:

 Anzahl der Zeitschritte in iso durch Nachlauf zu hoch geworden.
 Sie wird auf 460 begrenzt !  gebiet :  4554

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.547

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV:  fuellenberechnung
ISOV: Abflusz =         14886.038
ISOV: Niederschlag =    14886.051

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1040

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4556

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    2.97

 gesamtmenge an niederschlag (mm):      106.0

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:    105


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  0.900
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 = 12.000


vers. flaeche  =      0.25
natur. flaeche =      0.90
gesamtflaeche  =      1.15




-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4556
 anzahl hydrotope:     105


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)     106.0 mm
 interz.verd.:                       7.5 mm
 bestandsniederschlag:              96.6 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      16.0 mm
 aktuelle verdunstung:              10.3 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              96.6 mm
 overlandflow:                      25.2 mm
 [infiltration:                     71.4 mm]
 kapilarer aufstieg:                 0.0 mm
 verdunstung (bodensp.):             2.8 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -68.6 mm
 fehler:                             0.0 mm



 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:           15.2 mm
 abgabe basisabfluss:                  3.6 mm
        grundw. unterh.l.TG:          13.0 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                -0.6 mm
     pot.entnahme GWS:                -0.6 mm
 speicherinhaltsaenderung:            -0.9 mm
 fehler:                               0.2 mm


 flaechenanteile: 

   grundwasserleiter:                0.904 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.904 qkm


fuellenberechnung in iso
abflusz =         22810.803
niederschlag =    22810.838
flaeche zft  =        1.000
flaeche eing.=        0.904

GEBIET: Abflusswelle Interflow:
fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.904

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV:  fuellenberechnung
ISOV: Abflusz =         21223.709
ISOV: Niederschlag =    21223.693

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1041

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4559

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    2.97

 gesamtmenge an niederschlag (mm):      106.0

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:    121


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  0.900
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  4.000


vers. flaeche  =      0.16
natur. flaeche =      0.72
gesamtflaeche  =      0.88




-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4559
 anzahl hydrotope:     121


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)     106.0 mm
 interz.verd.:                       7.4 mm
 bestandsniederschlag:              96.6 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      15.9 mm
 aktuelle verdunstung:              10.3 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              96.6 mm
 overlandflow:                      37.3 mm
 [infiltration:                     59.3 mm]
 kapilarer aufstieg:                 0.0 mm
 verdunstung (bodensp.):             2.8 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -56.5 mm
 fehler:                             0.0 mm



 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:           27.2 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:          34.3 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                -1.6 mm
     pot.entnahme GWS:                -1.6 mm
 speicherinhaltsaenderung:            -5.5 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.718 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.718 qkm


fuellenberechnung in iso
abflusz =         26771.604
niederschlag =    26771.617
flaeche zft  =        1.000
flaeche eing.=        0.718

GEBIET: Abflusswelle Interflow:
fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.718

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV:  fuellenberechnung
ISOV: Abflusz =         13921.619
ISOV: Niederschlag =    13921.611

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1042

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4560

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    2.97

 gesamtmenge an niederschlag (mm):      106.0

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:      4


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  0.900
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  7.500


vers. flaeche  =      0.02
natur. flaeche =      0.03
gesamtflaeche  =      0.05




-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4560
 anzahl hydrotope:       4


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)     106.0 mm
 interz.verd.:                       7.0 mm
 bestandsniederschlag:              97.2 mm
 differenz interz.speicher:         -1.7 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      13.5 mm
 aktuelle verdunstung:               8.9 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              97.2 mm
 overlandflow:                      24.5 mm
 [infiltration:                     72.7 mm]
 kapilarer aufstieg:                 0.0 mm
 verdunstung (bodensp.):             1.9 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -70.8 mm
 fehler:                             0.0 mm



 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:           72.2 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:          80.2 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -8.0 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.034 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.034 qkm


fuellenberechnung in iso
abflusz =           836.338
niederschlag =      836.337
flaeche zft  =        1.000
flaeche eing.=        0.034

GEBIET: Abflusswelle Interflow:
fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.034

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV:  fuellenberechnung
ISOV: Abflusz =          1639.208
ISOV: Niederschlag =     1639.208

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1043

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4561

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    2.97

 gesamtmenge an niederschlag (mm):      106.0

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     28


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  0.900
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  6.300


vers. flaeche  =      0.03
natur. flaeche =      0.05
gesamtflaeche  =      0.08




-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4561
 anzahl hydrotope:      28


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)     106.0 mm
 interz.verd.:                       7.1 mm
 bestandsniederschlag:              97.2 mm
 differenz interz.speicher:         -1.8 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      13.8 mm
 aktuelle verdunstung:               9.5 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              97.2 mm
 overlandflow:                      54.0 mm
 [infiltration:                     43.2 mm]
 kapilarer aufstieg:                 0.0 mm
 verdunstung (bodensp.):             2.4 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -40.8 mm
 fehler:                             0.0 mm



 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:          102.3 mm
 abgabe basisabfluss:                 67.9 mm
        grundw. unterh.l.TG:          34.7 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -0.4 mm
 fehler:                               0.1 mm


 flaechenanteile: 

   grundwasserleiter:                0.054 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.054 qkm


fuellenberechnung in iso
abflusz =          2933.649
niederschlag =     2933.649
flaeche zft  =        1.000
flaeche eing.=        0.054

GEBIET: Abflusswelle Interflow:
fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.054

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV:  fuellenberechnung
ISOV: Abflusz =          2326.700
ISOV: Niederschlag =     2326.701

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1044

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4529

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    2.97

 gesamtmenge an niederschlag (mm):      106.0

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     23


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  3.000


vers. flaeche  =      0.03
natur. flaeche =      0.07
gesamtflaeche  =      0.10




-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4529
 anzahl hydrotope:      23


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)     106.0 mm
 interz.verd.:                       7.2 mm
 bestandsniederschlag:              97.0 mm
 differenz interz.speicher:         -1.8 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      13.8 mm
 aktuelle verdunstung:               9.8 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              97.0 mm
 overlandflow:                      10.5 mm
 [infiltration:                     86.4 mm]
 kapilarer aufstieg:                 0.0 mm
 verdunstung (bodensp.):             2.6 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -83.9 mm
 fehler:                             0.0 mm



 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:           25.3 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:          26.7 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -1.3 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.066 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.066 qkm



 Anzahl der Zeitschritte in iso durch Nachlauf zu hoch geworden.
 Sie wird auf 460 begrenzt !  gebiet :  4529

fuellenberechnung in iso
abflusz =           697.446
niederschlag =      698.651
flaeche zft  =        1.000
flaeche eing.=        0.066

GEBIET: Abflusswelle Interflow:
fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.066

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV:  fuellenberechnung
ISOV: Abflusz =          2833.943
ISOV: Niederschlag =     2833.943

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1045

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4563

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    2.97

 gesamtmenge an niederschlag (mm):      106.0

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     28


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  4.000


vers. flaeche  =      0.01
natur. flaeche =      0.14
gesamtflaeche  =      0.15




-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4563
 anzahl hydrotope:      28


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)     106.0 mm
 interz.verd.:                       7.9 mm
 bestandsniederschlag:              95.9 mm
 differenz interz.speicher:         -2.2 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      15.8 mm
 aktuelle verdunstung:              11.8 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              95.9 mm
 overlandflow:                      12.8 mm
 [infiltration:                     83.2 mm]
 kapilarer aufstieg:                 0.0 mm
 verdunstung (bodensp.):             4.0 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -79.2 mm
 fehler:                             0.0 mm



 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:           48.3 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:          50.1 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -1.8 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.141 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.141 qkm



 Anzahl der Zeitschritte in iso durch Nachlauf zu hoch geworden.
 Sie wird auf 460 begrenzt !  gebiet :  4563

fuellenberechnung in iso
abflusz =          1790.467
niederschlag =     1793.562
flaeche zft  =        1.000
flaeche eing.=        0.141

GEBIET: Abflusswelle Interflow:
fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.141

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV:  fuellenberechnung
ISOV: Abflusz =          1126.536
ISOV: Niederschlag =     1126.537

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1046

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4564

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    2.97

 gesamtmenge an niederschlag (mm):      106.0

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:    108


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  8.500


vers. flaeche  =      0.15
natur. flaeche =      0.77
gesamtflaeche  =      0.92




-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4564
 anzahl hydrotope:     108


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)     106.0 mm
 interz.verd.:                       7.5 mm
 bestandsniederschlag:              96.5 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      16.0 mm
 aktuelle verdunstung:              11.2 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              96.5 mm
 overlandflow:                       8.2 mm
 [infiltration:                     88.4 mm]
 kapilarer aufstieg:                 0.0 mm
 verdunstung (bodensp.):             3.7 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.5 mm
 differenz bodenspeicher:          -84.1 mm
 fehler:                             0.0 mm



 aufteilung perkolation: 

 perkolation bodenspeicher:            0.5 mm

 abgabe grundw.speicher:               0.5 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.5 mm
        grundw. oberh.l.TG:           34.7 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:          35.7 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -0.5 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.773 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.773 qkm



 Anzahl der Zeitschritte in iso durch Nachlauf zu hoch geworden.
 Sie wird auf 460 begrenzt !  gebiet :  4564

fuellenberechnung in iso
abflusz =          6317.458
niederschlag =     6328.375
flaeche zft  =        1.000
flaeche eing.=        0.773

GEBIET: Abflusswelle Interflow:
fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.773

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV:  fuellenberechnung
ISOV: Abflusz =         12573.937
ISOV: Niederschlag =    12573.935

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1047

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4562

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    2.97

 gesamtmenge an niederschlag (mm):      106.0

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:      7


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  0.900
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  3.500


vers. flaeche  =      0.00
natur. flaeche =      0.08
gesamtflaeche  =      0.08




-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4562
 anzahl hydrotope:       7


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)     106.0 mm
 interz.verd.:                       7.4 mm
 bestandsniederschlag:              96.6 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      15.5 mm
 aktuelle verdunstung:              11.4 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              96.6 mm
 overlandflow:                      66.3 mm
 [infiltration:                     30.3 mm]
 kapilarer aufstieg:                 0.0 mm
 verdunstung (bodensp.):             4.0 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -26.3 mm
 fehler:                             0.0 mm



 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:            0.0 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:           2.2 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -2.2 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.081 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.081 qkm


fuellenberechnung in iso
abflusz =          5335.967
niederschlag =     5335.966
flaeche zft  =        1.000
flaeche eing.=        0.081

GEBIET: Abflusswelle Interflow:
fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.081

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV:  fuellenberechnung
ISOV: Abflusz =             7.380
ISOV: Niederschlag =        7.380

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1048

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4565

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    2.97

 gesamtmenge an niederschlag (mm):      106.0

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     14


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  8.000


vers. flaeche  =      0.00
natur. flaeche =      0.17
gesamtflaeche  =      0.17




-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4565
 anzahl hydrotope:      14


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)     106.0 mm
 interz.verd.:                       9.9 mm
 bestandsniederschlag:              92.5 mm
 differenz interz.speicher:         -3.6 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      16.4 mm
 aktuelle verdunstung:              12.6 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              92.5 mm
 overlandflow:                      12.8 mm
 [infiltration:                     79.6 mm]
 kapilarer aufstieg:                 0.0 mm
 verdunstung (bodensp.):             2.7 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -77.0 mm
 fehler:                             0.0 mm



 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:          122.5 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:         125.9 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -3.4 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.169 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.169 qkm



 Anzahl der Zeitschritte in iso durch Nachlauf zu hoch geworden.
 Sie wird auf 460 begrenzt !  gebiet :  4565

fuellenberechnung in iso
abflusz =          2160.698
niederschlag =     2164.433
flaeche zft  =        1.000
flaeche eing.=        0.169

GEBIET: Abflusswelle Interflow:
fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.169

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV:  fuellenberechnung
ISOV: Abflusz =           197.044
ISOV: Niederschlag =      197.044

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1049

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4566

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    2.97

 gesamtmenge an niederschlag (mm):      106.0

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     54


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 = 14.500


vers. flaeche  =      0.03
natur. flaeche =      0.91
gesamtflaeche  =      0.94




-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4566
 anzahl hydrotope:      54


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)     106.0 mm
 interz.verd.:                       8.3 mm
 bestandsniederschlag:              95.1 mm
 differenz interz.speicher:         -2.5 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      16.3 mm
 aktuelle verdunstung:              11.7 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              95.1 mm
 overlandflow:                       9.6 mm
 [infiltration:                     85.5 mm]
 kapilarer aufstieg:                 0.0 mm
 verdunstung (bodensp.):             3.3 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -82.2 mm
 fehler:                             0.0 mm



 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:           46.3 mm
 abgabe basisabfluss:                 23.3 mm
        grundw. unterh.l.TG:          23.2 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -0.1 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.914 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.914 qkm



 Anzahl der Zeitschritte in iso durch Nachlauf zu hoch geworden.
 Sie wird auf 460 begrenzt !  gebiet :  4566

fuellenberechnung in iso
abflusz =          8766.412
niederschlag =     8781.562
flaeche zft  =        1.000
flaeche eing.=        0.914

GEBIET: Abflusswelle Interflow:
fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.914

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV:  fuellenberechnung
ISOV: Abflusz =          2594.992
ISOV: Niederschlag =     2594.998

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1050

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4571

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    2.97

 gesamtmenge an niederschlag (mm):      106.0

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     21


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  1.000


vers. flaeche  =      0.02
natur. flaeche =      0.16
gesamtflaeche  =      0.18




-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4571
 anzahl hydrotope:      21


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)     106.0 mm
 interz.verd.:                       7.5 mm
 bestandsniederschlag:              96.5 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      16.3 mm
 aktuelle verdunstung:              11.5 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              96.5 mm
 overlandflow:                       9.5 mm
 [infiltration:                     87.0 mm]
 kapilarer aufstieg:                 0.0 mm
 verdunstung (bodensp.):             4.0 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -82.9 mm
 fehler:                             0.0 mm



 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:           34.7 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:          34.9 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -0.2 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.160 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.160 qkm


fuellenberechnung in iso
abflusz =          1521.023
niederschlag =     1521.024
flaeche zft  =        1.000
flaeche eing.=        0.160

GEBIET: Abflusswelle Interflow:
fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.160

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV:  fuellenberechnung
ISOV: Abflusz =          1944.402
ISOV: Niederschlag =     1944.402

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1051

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4589

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    2.97

 gesamtmenge an niederschlag (mm):      106.0

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     99


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  1.000


vers. flaeche  =      0.10
natur. flaeche =      0.54
gesamtflaeche  =      0.64




-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4589
 anzahl hydrotope:      99


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)     106.0 mm
 interz.verd.:                       7.5 mm
 bestandsniederschlag:              96.6 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      16.1 mm
 aktuelle verdunstung:              10.9 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              96.6 mm
 overlandflow:                       6.8 mm
 [infiltration:                     89.8 mm]
 kapilarer aufstieg:                 0.0 mm
 verdunstung (bodensp.):             3.4 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        1.4 mm
 differenz bodenspeicher:          -85.0 mm
 fehler:                             0.0 mm



 aufteilung perkolation: 

 perkolation bodenspeicher:            1.4 mm

 abgabe grundw.speicher:               1.4 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  1.4 mm
        grundw. oberh.l.TG:           13.6 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:          16.8 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                -2.6 mm
     pot.entnahme GWS:                -2.6 mm
 speicherinhaltsaenderung:             0.8 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.541 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.541 qkm



 Anzahl der Zeitschritte in iso durch Nachlauf zu hoch geworden.
 Sie wird auf 460 begrenzt !  gebiet :  4589

fuellenberechnung in iso
abflusz =          3667.438
niederschlag =     3673.776
flaeche zft  =        1.000
flaeche eing.=        0.541

GEBIET: Abflusswelle Interflow:
fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.541

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV:  fuellenberechnung
ISOV: Abflusz =          8439.308
ISOV: Niederschlag =     8439.314

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1052

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4572

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    2.97

 gesamtmenge an niederschlag (mm):      106.0

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     35


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  1.000


vers. flaeche  =      0.03
natur. flaeche =      0.27
gesamtflaeche  =      0.30




-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4572
 anzahl hydrotope:      35


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)     106.0 mm
 interz.verd.:                       7.5 mm
 bestandsniederschlag:              96.5 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      16.2 mm
 aktuelle verdunstung:              11.1 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              96.5 mm
 overlandflow:                       7.5 mm
 [infiltration:                     89.0 mm]
 kapilarer aufstieg:                 0.0 mm
 verdunstung (bodensp.):             3.6 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.1 mm
 differenz bodenspeicher:          -85.3 mm
 fehler:                             0.0 mm



 aufteilung perkolation: 

 perkolation bodenspeicher:            0.1 mm

 abgabe grundw.speicher:               0.1 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.1 mm
        grundw. oberh.l.TG:            6.6 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:           6.8 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -0.1 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.275 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.275 qkm



 Anzahl der Zeitschritte in iso durch Nachlauf zu hoch geworden.
 Sie wird auf 460 begrenzt !  gebiet :  4572

fuellenberechnung in iso
abflusz =          2066.556
niederschlag =     2066.556
flaeche zft  =        1.000
flaeche eing.=        0.275

GEBIET: Abflusswelle Interflow:
fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.275

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV:  fuellenberechnung
ISOV: Abflusz =          2350.705
ISOV: Niederschlag =     2350.705

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1053

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4573

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    2.97

 gesamtmenge an niederschlag (mm):      106.0

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     21


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  1.000


vers. flaeche  =      0.01
natur. flaeche =      0.09
gesamtflaeche  =      0.11




-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4573
 anzahl hydrotope:      21


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)     106.0 mm
 interz.verd.:                       7.5 mm
 bestandsniederschlag:              96.6 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      16.2 mm
 aktuelle verdunstung:              12.1 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              96.6 mm
 overlandflow:                      12.6 mm
 [infiltration:                     84.0 mm]
 kapilarer aufstieg:                 0.0 mm
 verdunstung (bodensp.):             4.6 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -79.3 mm
 fehler:                             0.0 mm



 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:           22.5 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:          23.1 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -0.6 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.091 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.091 qkm


fuellenberechnung in iso
abflusz =          1145.171
niederschlag =     1145.171
flaeche zft  =        1.000
flaeche eing.=        0.091

GEBIET: Abflusswelle Interflow:
fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.091

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV:  fuellenberechnung
ISOV: Abflusz =          1226.629
ISOV: Niederschlag =     1226.628

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1054

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4576

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    2.97

 gesamtmenge an niederschlag (mm):      106.0

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     12


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  1.000


vers. flaeche  =      0.00
natur. flaeche =      0.02
gesamtflaeche  =      0.02




-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4576
 anzahl hydrotope:      12


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)     106.0 mm
 interz.verd.:                       7.5 mm
 bestandsniederschlag:              96.6 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      16.0 mm
 aktuelle verdunstung:              12.1 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              96.6 mm
 overlandflow:                      12.7 mm
 [infiltration:                     83.9 mm]
 kapilarer aufstieg:                 0.0 mm
 verdunstung (bodensp.):             4.6 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -79.3 mm
 fehler:                             0.0 mm



 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:           60.6 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:          60.6 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:             0.1 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.017 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.017 qkm


fuellenberechnung in iso
abflusz =           219.216
niederschlag =      219.216
flaeche zft  =        1.000
flaeche eing.=        0.017

GEBIET: Abflusswelle Interflow:
fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.017

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV:  fuellenberechnung
ISOV: Abflusz =            80.836
ISOV: Niederschlag =       80.837

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1055

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4578

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    2.97

 gesamtmenge an niederschlag (mm):      106.0

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     15


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  1.000


vers. flaeche  =      0.00
natur. flaeche =      0.02
gesamtflaeche  =      0.02




-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4578
 anzahl hydrotope:      15


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)     106.0 mm
 interz.verd.:                       7.7 mm
 bestandsniederschlag:              96.3 mm
 differenz interz.speicher:         -2.1 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      16.3 mm
 aktuelle verdunstung:              12.2 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              96.3 mm
 overlandflow:                      12.1 mm
 [infiltration:                     84.2 mm]
 kapilarer aufstieg:                 0.0 mm
 verdunstung (bodensp.):             4.6 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -79.7 mm
 fehler:                             0.0 mm



 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:           86.1 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:          86.4 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -0.3 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.022 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.022 qkm


fuellenberechnung in iso
abflusz =           264.006
niederschlag =      264.006
flaeche zft  =        1.000
flaeche eing.=        0.022

GEBIET: Abflusswelle Interflow:
fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.022

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV:  fuellenberechnung
ISOV: Abflusz =           152.597
ISOV: Niederschlag =      152.597

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1056

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4580

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    2.97

 gesamtmenge an niederschlag (mm):      106.0

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     31


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 = 10.000


vers. flaeche  =      0.01
natur. flaeche =      0.07
gesamtflaeche  =      0.07




-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4580
 anzahl hydrotope:      31


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)     106.0 mm
 interz.verd.:                       7.5 mm
 bestandsniederschlag:              96.6 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      16.0 mm
 aktuelle verdunstung:              11.3 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              96.6 mm
 overlandflow:                       5.9 mm
 [infiltration:                     90.7 mm]
 kapilarer aufstieg:                 0.0 mm
 verdunstung (bodensp.):             3.8 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -86.8 mm
 fehler:                             0.0 mm



 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:          231.7 mm
 abgabe basisabfluss:                 73.7 mm
        grundw. unterh.l.TG:         158.2 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -0.2 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.067 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.067 qkm



 Anzahl der Zeitschritte in iso durch Nachlauf zu hoch geworden.
 Sie wird auf 460 begrenzt !  gebiet :  4580

fuellenberechnung in iso
abflusz =           391.010
niederschlag =      391.686
flaeche zft  =        1.000
flaeche eing.=        0.067

GEBIET: Abflusswelle Interflow:
fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.067

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV:  fuellenberechnung
ISOV: Abflusz =           605.637
ISOV: Niederschlag =      605.638

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1057

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4584

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    2.97

 gesamtmenge an niederschlag (mm):      106.0

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     21


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  5.000


vers. flaeche  =      0.02
natur. flaeche =      0.06
gesamtflaeche  =      0.08




-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4584
 anzahl hydrotope:      21


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)     106.0 mm
 interz.verd.:                       7.5 mm
 bestandsniederschlag:              96.5 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      16.4 mm
 aktuelle verdunstung:              11.1 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              96.5 mm
 overlandflow:                       1.8 mm
 [infiltration:                     94.7 mm]
 kapilarer aufstieg:                 0.0 mm
 verdunstung (bodensp.):             3.5 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.1 mm
 differenz bodenspeicher:          -91.1 mm
 fehler:                             0.0 mm



 aufteilung perkolation: 

 perkolation bodenspeicher:            0.1 mm

 abgabe grundw.speicher:               0.1 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.1 mm
        grundw. oberh.l.TG:           54.8 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:          55.0 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -0.1 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.058 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.058 qkm


fuellenberechnung in iso
abflusz =           102.846
niederschlag =      102.846
flaeche zft  =        1.000
flaeche eing.=        0.058

GEBIET: Abflusswelle Interflow:
fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.058

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV:  fuellenberechnung
ISOV: Abflusz =          1597.476
ISOV: Niederschlag =     1597.475

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1058

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4587

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    2.97

 gesamtmenge an niederschlag (mm):      106.0

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     15


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  5.000


vers. flaeche  =      0.00
natur. flaeche =      0.02
gesamtflaeche  =      0.02




-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4587
 anzahl hydrotope:      15


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)     106.0 mm
 interz.verd.:                       7.5 mm
 bestandsniederschlag:              96.6 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      16.0 mm
 aktuelle verdunstung:              10.6 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              96.6 mm
 overlandflow:                       0.0 mm
 [infiltration:                     96.6 mm]
 kapilarer aufstieg:                 0.0 mm
 verdunstung (bodensp.):             3.2 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -93.4 mm
 fehler:                             0.0 mm



 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:          406.4 mm
 abgabe basisabfluss:                 44.4 mm
        grundw. unterh.l.TG:         362.3 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -0.4 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.018 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.018 qkm


fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.018

GEBIET: Abflusswelle Interflow:
fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.018

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV:  fuellenberechnung
ISOV: Abflusz =           235.808
ISOV: Niederschlag =      235.809

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1059

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4574

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    2.97

 gesamtmenge an niederschlag (mm):      106.0

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     26


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  1.000


vers. flaeche  =      0.02
natur. flaeche =      0.09
gesamtflaeche  =      0.10




-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4574
 anzahl hydrotope:      26


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)     106.0 mm
 interz.verd.:                       7.6 mm
 bestandsniederschlag:              96.4 mm
 differenz interz.speicher:         -2.1 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      16.2 mm
 aktuelle verdunstung:              11.2 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              96.4 mm
 overlandflow:                       3.4 mm
 [infiltration:                     93.0 mm]
 kapilarer aufstieg:                 0.0 mm
 verdunstung (bodensp.):             3.6 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -89.4 mm
 fehler:                             0.0 mm



 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:           10.4 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:          10.8 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -0.4 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.090 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.090 qkm


fuellenberechnung in iso
abflusz =           305.073
niederschlag =      305.072
flaeche zft  =        1.000
flaeche eing.=        0.090

GEBIET: Abflusswelle Interflow:
fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.090

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV:  fuellenberechnung
ISOV: Abflusz =          1297.201
ISOV: Niederschlag =     1297.201

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1060

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4575

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    2.97

 gesamtmenge an niederschlag (mm):      106.0

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     16


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  1.000


vers. flaeche  =      0.01
natur. flaeche =      0.05
gesamtflaeche  =      0.06




-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4575
 anzahl hydrotope:      16


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)     106.0 mm
 interz.verd.:                       7.5 mm
 bestandsniederschlag:              96.6 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      16.0 mm
 aktuelle verdunstung:              10.7 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              96.6 mm
 overlandflow:                       0.3 mm
 [infiltration:                     96.3 mm]
 kapilarer aufstieg:                 0.0 mm
 verdunstung (bodensp.):             3.2 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -93.1 mm
 fehler:                             0.0 mm



 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:           20.6 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:          20.8 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -0.2 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.047 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.047 qkm


fuellenberechnung in iso
abflusz =            13.739
niederschlag =       13.739
flaeche zft  =        1.000
flaeche eing.=        0.047

GEBIET: Abflusswelle Interflow:
fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.047

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV:  fuellenberechnung
ISOV: Abflusz =           915.327
ISOV: Niederschlag =      915.327

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1061

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4579

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    2.97

 gesamtmenge an niederschlag (mm):      106.0

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     20


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  1.000


vers. flaeche  =      0.00
natur. flaeche =      0.01
gesamtflaeche  =      0.02




-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4579
 anzahl hydrotope:      20


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)     106.0 mm
 interz.verd.:                       7.4 mm
 bestandsniederschlag:              96.6 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      15.9 mm
 aktuelle verdunstung:              11.6 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              96.6 mm
 overlandflow:                      10.0 mm
 [infiltration:                     86.6 mm]
 kapilarer aufstieg:                 0.0 mm
 verdunstung (bodensp.):             4.2 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -82.4 mm
 fehler:                             0.0 mm



 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:          214.5 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:         215.1 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -0.6 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.013 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.013 qkm


fuellenberechnung in iso
abflusz =           129.502
niederschlag =      129.502
flaeche zft  =        1.000
flaeche eing.=        0.013

GEBIET: Abflusswelle Interflow:
fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.013

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV:  fuellenberechnung
ISOV: Abflusz =           271.858
ISOV: Niederschlag =      271.858

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1062

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4585

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    2.97

 gesamtmenge an niederschlag (mm):      106.0

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     24


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  5.000


vers. flaeche  =      0.01
natur. flaeche =      0.06
gesamtflaeche  =      0.07




-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4585
 anzahl hydrotope:      24


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)     106.0 mm
 interz.verd.:                       7.5 mm
 bestandsniederschlag:              96.6 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      16.1 mm
 aktuelle verdunstung:              11.0 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              96.6 mm
 overlandflow:                       2.6 mm
 [infiltration:                     93.9 mm]
 kapilarer aufstieg:                 0.0 mm
 verdunstung (bodensp.):             3.5 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.5 mm
 differenz bodenspeicher:          -89.9 mm
 fehler:                             0.0 mm



 aufteilung perkolation: 

 perkolation bodenspeicher:            0.5 mm

 abgabe grundw.speicher:               0.5 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.5 mm
        grundw. oberh.l.TG:           41.2 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:          44.4 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -2.8 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.058 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.058 qkm



 Anzahl der Zeitschritte in iso durch Nachlauf zu hoch geworden.
 Sie wird auf 460 begrenzt !  gebiet :  4585

fuellenberechnung in iso
abflusz =           151.667
niederschlag =      151.723
flaeche zft  =        1.000
flaeche eing.=        0.058

GEBIET: Abflusswelle Interflow:
fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.058

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV:  fuellenberechnung
ISOV: Abflusz =          1142.059
ISOV: Niederschlag =     1142.059

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1063

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4586

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    2.97

 gesamtmenge an niederschlag (mm):      106.0

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     44


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  5.000


vers. flaeche  =      0.01
natur. flaeche =      0.06
gesamtflaeche  =      0.07




-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4586
 anzahl hydrotope:      44


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)     106.0 mm
 interz.verd.:                       7.5 mm
 bestandsniederschlag:              96.6 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      16.0 mm
 aktuelle verdunstung:              11.4 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              96.6 mm
 overlandflow:                       6.7 mm
 [infiltration:                     89.9 mm]
 kapilarer aufstieg:                 0.0 mm
 verdunstung (bodensp.):             3.9 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.5 mm
 differenz bodenspeicher:          -85.4 mm
 fehler:                             0.0 mm



 aufteilung perkolation: 

 perkolation bodenspeicher:            0.5 mm

 abgabe grundw.speicher:               0.5 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.5 mm
        grundw. oberh.l.TG:          133.7 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:         134.2 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:             0.1 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.058 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.058 qkm


fuellenberechnung in iso
abflusz =           386.808
niederschlag =      386.808
flaeche zft  =        1.000
flaeche eing.=        0.058

GEBIET: Abflusswelle Interflow:
fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.058

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV:  fuellenberechnung
ISOV: Abflusz =          1021.186
ISOV: Niederschlag =     1021.187

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         4585

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.

 Keine angeschlossenen Teilgebiete an Strang      4585
 Auswertung des Stranges:         4587

 Abflussverzoegerung mit Kalinin-Miljukov Parametern

 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 dt [h]:   0.08      tmax [d]:     4.86


 Kennwerte Zuflusswelle
 ----------------------

 Scheitel-Zufluss               iqzmax =   1400   qzmax =       0.101 [m**3/s]
 Scheitel-Zufluss im Gerinne    iqzfmx =   1400  qzfmax =       0.101 [m**3/s]
 Scheitel-Zufluss im Vorland    iqzvmx =      0  qzvmax =       0.000 [m**3/s]

 Fuelle-Zufluss                   fuqz =   0.0027 [hm**3]
 Fuelle-zufluss im Gerinne       fuqzf =   0.0027 [hm**3]
 Fuelle-zufluss im Vorland       fuqzv =   0.0000 [hm**3]


 Kennwerte der Systemfunktionen
 -------------------------------

 Anzahl der Zeitschritte  ituh =     18
 Maximum u                imax =      3     umax = 0.269426
 Summe u                   suu = 0.999998   suuh = 1.000000


 tmax [d]:     4.88


 Kennwerte Ausflusswelle
 -----------------------

 Endordinate Ausfluss           qaend =   0.000
 Scheitel-Ausfluss              iqmax =   1404    qmax =       0.100 [m**3/s]

 Fuelle-Ausfluss                  fuq =   0.0027 [hm**3]
 Fuelle-Ausfluss im Gerinne      fuqa =   0.0027 [hm**3]

 Scheitel-Ausfluss im Gerinne  iqamax =   1404   qamax =       0.100 [m**3/s]


 Gesamtzuflusswelle (ohne Basisabfluss)  sqz =        9.006
 Gesamtabflusswelle    "       "         sq  =        9.006


 Keine angeschlossenen Teilgebiete an Strang      4587
 Auswertung des Stranges:         4621

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Fiktiver Strang! Es erfolgt keine Abflussverzoegerung!
 Keine angeschlossenen Teilgebiete an Strang      4621
 Auswertung des Stranges:         1064

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4507

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    2.97

 gesamtmenge an niederschlag (mm):      106.0

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     69


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  0.500


vers. flaeche  =      0.09
natur. flaeche =      0.51
gesamtflaeche  =      0.61




-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4507
 anzahl hydrotope:      69


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)     106.0 mm
 interz.verd.:                       7.5 mm
 bestandsniederschlag:              96.6 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      16.1 mm
 aktuelle verdunstung:              11.1 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              96.6 mm
 overlandflow:                       4.2 mm
 [infiltration:                     92.4 mm]
 kapilarer aufstieg:                 0.0 mm
 verdunstung (bodensp.):             3.7 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        2.1 mm
 differenz bodenspeicher:          -86.6 mm
 fehler:                             0.0 mm



 aufteilung perkolation: 

 perkolation bodenspeicher:            2.1 mm

 abgabe grundw.speicher:               2.1 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  2.1 mm
        grundw. oberh.l.TG:            0.0 mm
 abgabe basisabfluss:                  0.7 mm
        grundw. unterh.l.TG:           2.9 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                -1.2 mm
     pot.entnahme GWS:                -1.2 mm
 speicherinhaltsaenderung:            -0.3 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.513 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.513 qkm



 Anzahl der Zeitschritte in iso durch Nachlauf zu hoch geworden.
 Sie wird auf 460 begrenzt !  gebiet :  4507

fuellenberechnung in iso
abflusz =          2163.171
niederschlag =     2166.910
flaeche zft  =        1.000
flaeche eing.=        0.513

GEBIET: Abflusswelle Interflow:

 Anzahl der Zeitschritte in iso durch Nachlauf zu hoch geworden.
 Sie wird auf 460 begrenzt !  gebiet :  4507

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.513

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV:  fuellenberechnung
ISOV: Abflusz =          8034.371
ISOV: Niederschlag =     8034.367

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1065

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4508

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    2.97

 gesamtmenge an niederschlag (mm):      106.0

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     56


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  1.000


vers. flaeche  =      0.09
natur. flaeche =      0.39
gesamtflaeche  =      0.48


 entnahme gws [qbm/s]:       0.000


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4508
 anzahl hydrotope:      56


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)     106.0 mm
 interz.verd.:                       7.5 mm
 bestandsniederschlag:              96.6 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      16.0 mm
 aktuelle verdunstung:              10.8 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              96.6 mm
 overlandflow:                       3.6 mm
 [infiltration:                     93.0 mm]
 kapilarer aufstieg:                 0.0 mm
 verdunstung (bodensp.):             3.3 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.9 mm
 differenz bodenspeicher:          -88.8 mm
 fehler:                             0.0 mm



 aufteilung perkolation: 

 perkolation bodenspeicher:            0.9 mm

 abgabe grundw.speicher:               0.9 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.9 mm
        grundw. oberh.l.TG:            3.8 mm
 abgabe basisabfluss:                  1.6 mm
        grundw. unterh.l.TG:           3.7 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.2 mm
     pot.entnahme GWS:                 0.2 mm
 speicherinhaltsaenderung:            -0.8 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.390 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.390 qkm



 Anzahl der Zeitschritte in iso durch Nachlauf zu hoch geworden.
 Sie wird auf 460 begrenzt !  gebiet :  4508

fuellenberechnung in iso
abflusz =          1402.268
niederschlag =     1404.691
flaeche zft  =        1.000
flaeche eing.=        0.390

GEBIET: Abflusswelle Interflow:

 Anzahl der Zeitschritte in iso durch Nachlauf zu hoch geworden.
 Sie wird auf 460 begrenzt !  gebiet :  4508

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.390

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV:  fuellenberechnung
ISOV: Abflusz =          7684.554
ISOV: Niederschlag =     7684.559

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1066

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4509

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    2.97

 gesamtmenge an niederschlag (mm):      106.0

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     83


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  1.500


vers. flaeche  =      0.15
natur. flaeche =      0.80
gesamtflaeche  =      0.96


 entnahme gws [qbm/s]:       0.000


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4509
 anzahl hydrotope:      83


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)     106.0 mm
 interz.verd.:                       7.5 mm
 bestandsniederschlag:              96.6 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      16.0 mm
 aktuelle verdunstung:              10.9 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              96.6 mm
 overlandflow:                       6.3 mm
 [infiltration:                     90.3 mm]
 kapilarer aufstieg:                 0.0 mm
 verdunstung (bodensp.):             3.4 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.3 mm
 differenz bodenspeicher:          -86.7 mm
 fehler:                             0.0 mm



 aufteilung perkolation: 

 perkolation bodenspeicher:            0.3 mm

 abgabe grundw.speicher:               0.3 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.3 mm
        grundw. oberh.l.TG:            3.4 mm
 abgabe basisabfluss:                  1.3 mm
        grundw. unterh.l.TG:           3.4 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -1.2 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.801 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.801 qkm



 Anzahl der Zeitschritte in iso durch Nachlauf zu hoch geworden.
 Sie wird auf 460 begrenzt !  gebiet :  4509

fuellenberechnung in iso
abflusz =          5024.089
niederschlag =     5032.775
flaeche zft  =        1.000
flaeche eing.=        0.801

GEBIET: Abflusswelle Interflow:

 Anzahl der Zeitschritte in iso durch Nachlauf zu hoch geworden.
 Sie wird auf 460 begrenzt !  gebiet :  4509

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.801

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV:  fuellenberechnung
ISOV: Abflusz =         13096.955
ISOV: Niederschlag =    13096.954

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         4507

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.

 Keine angeschlossenen Teilgebiete an Strang      4507
 Auswertung des Stranges:         4508

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Abflussverzoegerung mit Kalinin-Miljukov Parametern

 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 dt [h]:   0.08      tmax [d]:     4.89


 Kennwerte Zuflusswelle
 ----------------------

 Scheitel-Zufluss               iqzmax =   1409   qzmax =       0.323 [m**3/s]
 Scheitel-Zufluss im Gerinne    iqzfmx =   1409  qzfmax =       0.323 [m**3/s]
 Scheitel-Zufluss im Vorland    iqzvmx =      0  qzvmax =       0.000 [m**3/s]

 Fuelle-Zufluss                   fuqz =   0.0106 [hm**3]
 Fuelle-zufluss im Gerinne       fuqzf =   0.0106 [hm**3]
 Fuelle-zufluss im Vorland       fuqzv =   0.0000 [hm**3]


 Kennwerte der Systemfunktionen
 -------------------------------

 Anzahl der Zeitschritte  ituh =     32
 Maximum u                imax =      1     umax = 0.248968
 Summe u                   suu = 1.001107   suuh = 1.000000


 tmax [d]:     4.90


 Kennwerte Ausflusswelle
 -----------------------

 Endordinate Ausfluss           qaend =   0.000
 Scheitel-Ausfluss              iqmax =   1410    qmax =       0.323 [m**3/s]

 Fuelle-Ausfluss                  fuq =   0.0106 [hm**3]
 Fuelle-Ausfluss im Gerinne      fuqa =   0.0106 [hm**3]

 Scheitel-Ausfluss im Gerinne  iqamax =   1410   qamax =       0.323 [m**3/s]


 Gesamtzuflusswelle (ohne Basisabfluss)  sqz =       35.227
 Gesamtabflusswelle    "       "         sq  =       35.227


 Keine angeschlossenen Teilgebiete an Strang      4508
 Auswertung des Stranges:         4509

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Abflussverzoegerung mit Kalinin-Miljukov Parametern

 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 dt [h]:   0.08      tmax [d]:     4.89


 Kennwerte Zuflusswelle
 ----------------------

 Scheitel-Zufluss               iqzmax =   1409   qzmax =       0.625 [m**3/s]
 Scheitel-Zufluss im Gerinne    iqzfmx =   1409  qzfmax =       0.625 [m**3/s]
 Scheitel-Zufluss im Vorland    iqzvmx =      0  qzvmax =       0.000 [m**3/s]

 Fuelle-Zufluss                   fuqz =   0.0203 [hm**3]
 Fuelle-zufluss im Gerinne       fuqzf =   0.0203 [hm**3]
 Fuelle-zufluss im Vorland       fuqzv =   0.0000 [hm**3]


 Kennwerte der Systemfunktionen
 -------------------------------

 Anzahl der Zeitschritte  ituh =     18
 Maximum u                imax =      3     umax = 0.269426
 Summe u                   suu = 0.999998   suuh = 1.000000


 tmax [d]:     4.91


 Kennwerte Ausflusswelle
 -----------------------

 Endordinate Ausfluss           qaend =   0.000
 Scheitel-Ausfluss              iqmax =   1413    qmax =       0.623 [m**3/s]

 Fuelle-Ausfluss                  fuq =   0.0203 [hm**3]
 Fuelle-Ausfluss im Gerinne      fuqa =   0.0203 [hm**3]

 Scheitel-Ausfluss im Gerinne  iqamax =   1413   qamax =       0.623 [m**3/s]


 Gesamtzuflusswelle (ohne Basisabfluss)  sqz =       67.623
 Gesamtabflusswelle    "       "         sq  =       67.623


 Keine angeschlossenen Teilgebiete an Strang      4509
 Auswertung des Stranges:         4605

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Fiktiver Strang! Es erfolgt keine Abflussverzoegerung!
 Keine angeschlossenen Teilgebiete an Strang      4605
 Auswertung des Stranges:         4503

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.

 Keine angeschlossenen Teilgebiete an Strang      4503
 Auswertung des Stranges:         4504

 Abflussverzoegerung mit Kalinin-Miljukov Parametern

 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 dt [h]:   0.08      tmax [d]:     4.93


 Kennwerte Zuflusswelle
 ----------------------

 Scheitel-Zufluss               iqzmax =   1419   qzmax =       0.237 [m**3/s]
 Scheitel-Zufluss im Gerinne    iqzfmx =   1419  qzfmax =       0.237 [m**3/s]
 Scheitel-Zufluss im Vorland    iqzvmx =      0  qzvmax =       0.000 [m**3/s]

 Fuelle-Zufluss                   fuqz =   0.0100 [hm**3]
 Fuelle-zufluss im Gerinne       fuqzf =   0.0100 [hm**3]
 Fuelle-zufluss im Vorland       fuqzv =   0.0000 [hm**3]


 Kennwerte der Systemfunktionen
 -------------------------------

 Anzahl der Zeitschritte  ituh =     18
 Maximum u                imax =      3     umax = 0.269426
 Summe u                   suu = 0.999998   suuh = 1.000000


 tmax [d]:     4.94


 Kennwerte Ausflusswelle
 -----------------------

 Endordinate Ausfluss           qaend =   0.000
 Scheitel-Ausfluss              iqmax =   1423    qmax =       0.237 [m**3/s]

 Fuelle-Ausfluss                  fuq =   0.0100 [hm**3]
 Fuelle-Ausfluss im Gerinne      fuqa =   0.0100 [hm**3]

 Scheitel-Ausfluss im Gerinne  iqamax =   1423   qamax =       0.237 [m**3/s]


 Gesamtzuflusswelle (ohne Basisabfluss)  sqz =       33.398
 Gesamtabflusswelle    "       "         sq  =       33.398


 Keine angeschlossenen Teilgebiete an Strang      4504
 Auswertung des Stranges:         4505

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Aufruf der Speicherroutine 


 zufluss-fuelle [hm]        0.034946 speicher 4505
 zusaetzl.zufl im nachl.ast [hm]  0.000000

 speicher   0.036414 abfluss-fuelle [hm]      4505

 speicherinhaltsaenderung [hm]  0.000000
 Keine angeschlossenen Teilgebiete an Strang      4505
 Auswertung des Stranges:         4603

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Fiktiver Strang! Es erfolgt keine Abflussverzoegerung!
 Keine angeschlossenen Teilgebiete an Strang      4603
 Auswertung des Stranges:         1067

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4511

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    2.97

 gesamtmenge an niederschlag (mm):      106.0

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     62


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  2.500


vers. flaeche  =      0.08
natur. flaeche =      0.34
gesamtflaeche  =      0.42




-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4511
 anzahl hydrotope:      62


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)     106.0 mm
 interz.verd.:                       7.5 mm
 bestandsniederschlag:              96.6 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      16.0 mm
 aktuelle verdunstung:              10.9 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              96.6 mm
 overlandflow:                       5.8 mm
 [infiltration:                     90.8 mm]
 kapilarer aufstieg:                 0.0 mm
 verdunstung (bodensp.):             3.4 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.1 mm
 differenz bodenspeicher:          -87.3 mm
 fehler:                             0.0 mm



 aufteilung perkolation: 

 perkolation bodenspeicher:            0.1 mm

 abgabe grundw.speicher:               0.1 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.1 mm
        grundw. oberh.l.TG:            9.7 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:          15.2 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -5.4 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.341 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.341 qkm



 Anzahl der Zeitschritte in iso durch Nachlauf zu hoch geworden.
 Sie wird auf 460 begrenzt !  gebiet :  4511

fuellenberechnung in iso
abflusz =          1960.577
niederschlag =     1963.963
flaeche zft  =        1.000
flaeche eing.=        0.341

GEBIET: Abflusswelle Interflow:
fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.341

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV:  fuellenberechnung
ISOV: Abflusz =          6626.563
ISOV: Niederschlag =     6626.556

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1068

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4567

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    2.97

 gesamtmenge an niederschlag (mm):      106.0

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     67


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  6.000


vers. flaeche  =      0.04
natur. flaeche =      0.26
gesamtflaeche  =      0.30




-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4567
 anzahl hydrotope:      67


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)     106.0 mm
 interz.verd.:                       8.3 mm
 bestandsniederschlag:              95.3 mm
 differenz interz.speicher:         -2.5 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      16.3 mm
 aktuelle verdunstung:              11.5 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              95.3 mm
 overlandflow:                       8.0 mm
 [infiltration:                     87.3 mm]
 kapilarer aufstieg:                 0.0 mm
 verdunstung (bodensp.):             3.3 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.6 mm
 differenz bodenspeicher:          -83.4 mm
 fehler:                             0.0 mm



 aufteilung perkolation: 

 perkolation bodenspeicher:            0.6 mm

 abgabe grundw.speicher:               0.6 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.6 mm
        grundw. oberh.l.TG:           51.1 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:          53.7 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -2.0 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.258 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.258 qkm



 Anzahl der Zeitschritte in iso durch Nachlauf zu hoch geworden.
 Sie wird auf 460 begrenzt !  gebiet :  4567

fuellenberechnung in iso
abflusz =          2053.413
niederschlag =     2056.958
flaeche zft  =        1.000
flaeche eing.=        0.258

GEBIET: Abflusswelle Interflow:
fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.258

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV:  fuellenberechnung
ISOV: Abflusz =          3279.011
ISOV: Niederschlag =     3279.010

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1069

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4588

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    2.97

 gesamtmenge an niederschlag (mm):      106.0

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     26


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  6.000


vers. flaeche  =      0.02
natur. flaeche =      0.12
gesamtflaeche  =      0.13


 entnahme gws [qbm/s]:       0.000


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4588
 anzahl hydrotope:      26


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)     106.0 mm
 interz.verd.:                       7.5 mm
 bestandsniederschlag:              96.6 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      16.1 mm
 aktuelle verdunstung:              10.8 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              96.6 mm
 overlandflow:                       0.3 mm
 [infiltration:                     96.3 mm]
 kapilarer aufstieg:                 0.0 mm
 verdunstung (bodensp.):             3.3 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -93.0 mm
 fehler:                             0.0 mm



 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:          120.1 mm
 abgabe basisabfluss:                 19.5 mm
        grundw. unterh.l.TG:         101.0 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.2 mm
     pot.entnahme GWS:                 0.2 mm
 speicherinhaltsaenderung:            -0.7 mm
 fehler:                               0.1 mm


 flaechenanteile: 

   grundwasserleiter:                0.115 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.115 qkm



 Anzahl der Zeitschritte in iso durch Nachlauf zu hoch geworden.
 Sie wird auf 460 begrenzt !  gebiet :  4588

fuellenberechnung in iso
abflusz =            35.868
niederschlag =       35.930
flaeche zft  =        1.000
flaeche eing.=        0.115

GEBIET: Abflusswelle Interflow:
fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.115

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV:  fuellenberechnung
ISOV: Abflusz =          1640.904
ISOV: Niederschlag =     1640.905

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         4580

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.

 Keine angeschlossenen Teilgebiete an Strang      4580
 Auswertung des Stranges:         4581

 Abflussverzoegerung mit Kalinin-Miljukov Parametern
 Keine angeschlossenen Teilgebiete an Strang      4581
 Auswertung des Stranges:         4626

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Fiktiver Strang! Es erfolgt keine Abflussverzoegerung!
 Keine angeschlossenen Teilgebiete an Strang      4626
 Auswertung des Stranges:         4571

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.

 Keine angeschlossenen Teilgebiete an Strang      4571
 Auswertung des Stranges:         4570

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.

 Keine angeschlossenen Teilgebiete an Strang      4570
 Auswertung des Stranges:         4572

 Abflussverzoegerung mit Kalinin-Miljukov Parametern
 Keine angeschlossenen Teilgebiete an Strang      4572
 Auswertung des Stranges:         4576

 Abflussverzoegerung mit Kalinin-Miljukov Parametern

 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 dt [h]:   0.08      tmax [d]:     4.85


 Kennwerte Zuflusswelle
 ----------------------

 Scheitel-Zufluss               iqzmax =   1396   qzmax =       0.299 [m**3/s]
 Scheitel-Zufluss im Gerinne    iqzfmx =   1396  qzfmax =       0.299 [m**3/s]
 Scheitel-Zufluss im Vorland    iqzvmx =      0  qzvmax =       0.000 [m**3/s]

 Fuelle-Zufluss                   fuqz =   0.0079 [hm**3]
 Fuelle-zufluss im Gerinne       fuqzf =   0.0079 [hm**3]
 Fuelle-zufluss im Vorland       fuqzv =   0.0000 [hm**3]


 Kennwerte der Systemfunktionen
 -------------------------------

 Anzahl der Zeitschritte  ituh =     18
 Maximum u                imax =      3     umax = 0.269426
 Summe u                   suu = 0.999998   suuh = 1.000000


 tmax [d]:     4.86


 Kennwerte Ausflusswelle
 -----------------------

 Endordinate Ausfluss           qaend =   0.000
 Scheitel-Ausfluss              iqmax =   1400    qmax =       0.298 [m**3/s]

 Fuelle-Ausfluss                  fuq =   0.0079 [hm**3]
 Fuelle-Ausfluss im Gerinne      fuqa =   0.0079 [hm**3]

 Scheitel-Ausfluss im Gerinne  iqamax =   1400   qamax =       0.298 [m**3/s]


 Gesamtzuflusswelle (ohne Basisabfluss)  sqz =       26.276
 Gesamtabflusswelle    "       "         sq  =       26.276


 Keine angeschlossenen Teilgebiete an Strang      4576
 Auswertung des Stranges:         4577

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Aufruf der Speicherroutine 


 zufluss-fuelle [hm]        0.012976 speicher 4577
 zusaetzl.zufl im nachl.ast [hm]  0.000000

 speicher   0.013087 abfluss-fuelle [hm]      4577

 speicherinhaltsaenderung [hm]  0.000006
 Keine angeschlossenen Teilgebiete an Strang      4577
 Auswertung des Stranges:         4578

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Abflussverzoegerung mit Kalinin-Miljukov Parametern

 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 dt [h]:   0.08      tmax [d]:     4.88


 Kennwerte Zuflusswelle
 ----------------------

 Scheitel-Zufluss               iqzmax =   1404   qzmax =       0.538 [m**3/s]
 Scheitel-Zufluss im Gerinne    iqzfmx =   1404  qzfmax =       0.538 [m**3/s]
 Scheitel-Zufluss im Vorland    iqzvmx =      0  qzvmax =       0.000 [m**3/s]

 Fuelle-Zufluss                   fuqz =   0.0131 [hm**3]
 Fuelle-zufluss im Gerinne       fuqzf =   0.0131 [hm**3]
 Fuelle-zufluss im Vorland       fuqzv =   0.0000 [hm**3]


 Kennwerte der Systemfunktionen
 -------------------------------

 Anzahl der Zeitschritte  ituh =     18
 Maximum u                imax =      3     umax = 0.269426
 Summe u                   suu = 0.999998   suuh = 1.000000


 tmax [d]:     4.89


 Kennwerte Ausflusswelle
 -----------------------

 Endordinate Ausfluss           qaend =   0.000
 Scheitel-Ausfluss              iqmax =   1408    qmax =       0.535 [m**3/s]

 Fuelle-Ausfluss                  fuq =   0.0131 [hm**3]
 Fuelle-Ausfluss im Gerinne      fuqa =   0.0131 [hm**3]

 Scheitel-Ausfluss im Gerinne  iqamax =   1408   qamax =       0.535 [m**3/s]


 Gesamtzuflusswelle (ohne Basisabfluss)  sqz =       43.627
 Gesamtabflusswelle    "       "         sq  =       43.627


 Keine angeschlossenen Teilgebiete an Strang      4578
 Auswertung des Stranges:         4579

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Fiktiver Strang! Es erfolgt keine Abflussverzoegerung!
 Keine angeschlossenen Teilgebiete an Strang      4579
 Auswertung des Stranges:         4620

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.

 Keine angeschlossenen Teilgebiete an Strang      4620
 Auswertung des Stranges:         4582

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Abflussverzoegerung mit Kalinin-Miljukov Parametern

 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 dt [h]:   0.08      tmax [d]:     4.89


 Kennwerte Zuflusswelle
 ----------------------

 Scheitel-Zufluss               iqzmax =   1407   qzmax =       0.556 [m**3/s]
 Scheitel-Zufluss im Gerinne    iqzfmx =   1407  qzfmax =       0.556 [m**3/s]
 Scheitel-Zufluss im Vorland    iqzvmx =      0  qzvmax =       0.000 [m**3/s]

 Fuelle-Zufluss                   fuqz =   0.0139 [hm**3]
 Fuelle-zufluss im Gerinne       fuqzf =   0.0139 [hm**3]
 Fuelle-zufluss im Vorland       fuqzv =   0.0000 [hm**3]


 Kennwerte der Systemfunktionen
 -------------------------------

 Anzahl der Zeitschritte  ituh =     18
 Maximum u                imax =      3     umax = 0.269426
 Summe u                   suu = 0.999998   suuh = 1.000000


 tmax [d]:     4.90


 Kennwerte Ausflusswelle
 -----------------------

 Endordinate Ausfluss           qaend =   0.000
 Scheitel-Ausfluss              iqmax =   1410    qmax =       0.553 [m**3/s]

 Fuelle-Ausfluss                  fuq =   0.0139 [hm**3]
 Fuelle-Ausfluss im Gerinne      fuqa =   0.0139 [hm**3]

 Scheitel-Ausfluss im Gerinne  iqamax =   1410   qamax =       0.553 [m**3/s]


 Gesamtzuflusswelle (ohne Basisabfluss)  sqz =       46.357
 Gesamtabflusswelle    "       "         sq  =       46.357


 Keine angeschlossenen Teilgebiete an Strang      4582
 Auswertung des Stranges:         4583

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Abflussverzoegerung mit Kalinin-Miljukov Parametern

 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 dt [h]:   0.08      tmax [d]:     4.90


 Kennwerte Zuflusswelle
 ----------------------

 Scheitel-Zufluss               iqzmax =   1410   qzmax =       0.593 [m**3/s]
 Scheitel-Zufluss im Gerinne    iqzfmx =   1410  qzfmax =       0.593 [m**3/s]
 Scheitel-Zufluss im Vorland    iqzvmx =      0  qzvmax =       0.000 [m**3/s]

 Fuelle-Zufluss                   fuqz =   0.0198 [hm**3]
 Fuelle-zufluss im Gerinne       fuqzf =   0.0198 [hm**3]
 Fuelle-zufluss im Vorland       fuqzv =   0.0000 [hm**3]


 Kennwerte der Systemfunktionen
 -------------------------------

 Anzahl der Zeitschritte  ituh =     18
 Maximum u                imax =      3     umax = 0.269426
 Summe u                   suu = 0.999998   suuh = 1.000000


 tmax [d]:     4.91


 Kennwerte Ausflusswelle
 -----------------------

 Endordinate Ausfluss           qaend =   0.000
 Scheitel-Ausfluss              iqmax =   1414    qmax =       0.590 [m**3/s]

 Fuelle-Ausfluss                  fuq =   0.0198 [hm**3]
 Fuelle-Ausfluss im Gerinne      fuqa =   0.0198 [hm**3]

 Scheitel-Ausfluss im Gerinne  iqamax =   1414   qamax =       0.590 [m**3/s]


 Gesamtzuflusswelle (ohne Basisabfluss)  sqz =       66.024
 Gesamtabflusswelle    "       "         sq  =       66.023


 Keine angeschlossenen Teilgebiete an Strang      4583
 Auswertung des Stranges:         4627

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Fiktiver Strang! Es erfolgt keine Abflussverzoegerung!
 Keine angeschlossenen Teilgebiete an Strang      4627
 Auswertung des Stranges:         4567

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.

 Keine angeschlossenen Teilgebiete an Strang      4567
 Auswertung des Stranges:         4568

 Aufruf der Speicherroutine 


 zufluss-fuelle [hm]        0.005119 speicher 4568
 zusaetzl.zufl im nachl.ast [hm]  0.000000

 speicher   0.005329 abfluss-fuelle [hm]      4568

 speicherinhaltsaenderung [hm]  0.000000
 Keine angeschlossenen Teilgebiete an Strang      4568
 Auswertung des Stranges:         4617

 Fiktiver Strang! Es erfolgt keine Abflussverzoegerung!
 Keine angeschlossenen Teilgebiete an Strang      4617
 Auswertung des Stranges:         4527

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.

 Keine angeschlossenen Teilgebiete an Strang      4527
 Auswertung des Stranges:         4528

 Aufruf der Speicherroutine 


 zufluss-fuelle [hm]        0.004591 speicher 4528
 zusaetzl.zufl im nachl.ast [hm]  0.000000

 speicher   0.004767 abfluss-fuelle [hm]      4528

 speicherinhaltsaenderung [hm]  0.000002
 Keine angeschlossenen Teilgebiete an Strang      4528
 Auswertung des Stranges:         4623

 Abflussverzoegerung mit Kalinin-Miljukov Parametern

 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 dt [h]:   0.08      tmax [d]:     4.98


 Kennwerte Zuflusswelle
 ----------------------

 Scheitel-Zufluss               iqzmax =   1435   qzmax =       0.086 [m**3/s]
 Scheitel-Zufluss im Gerinne    iqzfmx =   1435  qzfmax =       0.086 [m**3/s]
 Scheitel-Zufluss im Vorland    iqzvmx =      0  qzvmax =       0.000 [m**3/s]

 Fuelle-Zufluss                   fuqz =   0.0048 [hm**3]
 Fuelle-zufluss im Gerinne       fuqzf =   0.0048 [hm**3]
 Fuelle-zufluss im Vorland       fuqzv =   0.0000 [hm**3]


 Kennwerte der Systemfunktionen
 -------------------------------

 Anzahl der Zeitschritte  ituh =     18
 Maximum u                imax =      3     umax = 0.269426
 Summe u                   suu = 0.999998   suuh = 1.000000


 tmax [d]:     5.00


 Kennwerte Ausflusswelle
 -----------------------

 Endordinate Ausfluss           qaend =   0.000
 Scheitel-Ausfluss              iqmax =   1439    qmax =       0.086 [m**3/s]

 Fuelle-Ausfluss                  fuq =   0.0048 [hm**3]
 Fuelle-Ausfluss im Gerinne      fuqa =   0.0048 [hm**3]

 Scheitel-Ausfluss im Gerinne  iqamax =   1439   qamax =       0.086 [m**3/s]


 Gesamtzuflusswelle (ohne Basisabfluss)  sqz =       15.891
 Gesamtabflusswelle    "       "         sq  =       15.890


 Keine angeschlossenen Teilgebiete an Strang      4623
 Auswertung des Stranges:         4624

 Fiktiver Strang! Es erfolgt keine Abflussverzoegerung!
 Keine angeschlossenen Teilgebiete an Strang      4624
 Auswertung des Stranges:         4610

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.

 Keine angeschlossenen Teilgebiete an Strang      4610
 Auswertung des Stranges:         4531

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Aufruf der Speicherroutine 


 zufluss-fuelle [hm]        0.010874 speicher 4531
 zusaetzl.zufl im nachl.ast [hm]  0.000000

 speicher   0.011223 abfluss-fuelle [hm]      4531

 speicherinhaltsaenderung [hm]  0.000002
 Keine angeschlossenen Teilgebiete an Strang      4531
 Auswertung des Stranges:         4625

 Fiktiver Strang! Es erfolgt keine Abflussverzoegerung!
 Keine angeschlossenen Teilgebiete an Strang      4625
 Auswertung des Stranges:         4520

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.

 Keine angeschlossenen Teilgebiete an Strang      4520
 Auswertung des Stranges:         4521

 Aufruf der Speicherroutine 


 zufluss-fuelle [hm]        0.006360 speicher 4521
 zusaetzl.zufl im nachl.ast [hm]  0.000000

 speicher   0.006487 abfluss-fuelle [hm]      4521

 speicherinhaltsaenderung [hm]  0.000000
 Keine angeschlossenen Teilgebiete an Strang      4521
 Auswertung des Stranges:         4608

 Fiktiver Strang! Es erfolgt keine Abflussverzoegerung!
 Keine angeschlossenen Teilgebiete an Strang      4608
 Auswertung des Stranges:         4514

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.

 Keine angeschlossenen Teilgebiete an Strang      4514
 Auswertung des Stranges:         4515

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Abflussverzoegerung mit Kalinin-Miljukov Parametern

 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 dt [h]:   0.08      tmax [d]:     4.89


 Kennwerte Zuflusswelle
 ----------------------

 Scheitel-Zufluss               iqzmax =   1409   qzmax =       0.539 [m**3/s]
 Scheitel-Zufluss im Gerinne    iqzfmx =   1409  qzfmax =       0.539 [m**3/s]
 Scheitel-Zufluss im Vorland    iqzvmx =      0  qzvmax =       0.000 [m**3/s]

 Fuelle-Zufluss                   fuqz =   0.0152 [hm**3]
 Fuelle-zufluss im Gerinne       fuqzf =   0.0152 [hm**3]
 Fuelle-zufluss im Vorland       fuqzv =   0.0000 [hm**3]


 Kennwerte der Systemfunktionen
 -------------------------------

 Anzahl der Zeitschritte  ituh =     18
 Maximum u                imax =      3     umax = 0.269426
 Summe u                   suu = 0.999998   suuh = 1.000000


 tmax [d]:     4.91


 Kennwerte Ausflusswelle
 -----------------------

 Endordinate Ausfluss           qaend =   0.000
 Scheitel-Ausfluss              iqmax =   1413    qmax =       0.538 [m**3/s]

 Fuelle-Ausfluss                  fuq =   0.0152 [hm**3]
 Fuelle-Ausfluss im Gerinne      fuqa =   0.0152 [hm**3]

 Scheitel-Ausfluss im Gerinne  iqamax =   1413   qamax =       0.538 [m**3/s]


 Gesamtzuflusswelle (ohne Basisabfluss)  sqz =       50.811
 Gesamtabflusswelle    "       "         sq  =       50.811


 Keine angeschlossenen Teilgebiete an Strang      4515
 Auswertung des Stranges:         4516

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Aufruf der Speicherroutine 


 zufluss-fuelle [hm]        0.017460 speicher 4516
 zusaetzl.zufl im nachl.ast [hm]  0.000000

 speicher   0.017857 abfluss-fuelle [hm]      4516

 speicherinhaltsaenderung [hm]  0.000000
 Keine angeschlossenen Teilgebiete an Strang      4516
 Auswertung des Stranges:         4517

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Abflussverzoegerung mit Kalinin-Miljukov Parametern

 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 dt [h]:   0.08      tmax [d]:     4.89


 Kennwerte Zuflusswelle
 ----------------------

 Scheitel-Zufluss               iqzmax =   1409   qzmax =       0.620 [m**3/s]
 Scheitel-Zufluss im Gerinne    iqzfmx =   1409  qzfmax =       0.620 [m**3/s]
 Scheitel-Zufluss im Vorland    iqzvmx =      0  qzvmax =       0.000 [m**3/s]

 Fuelle-Zufluss                   fuqz =   0.0179 [hm**3]
 Fuelle-zufluss im Gerinne       fuqzf =   0.0179 [hm**3]
 Fuelle-zufluss im Vorland       fuqzv =   0.0000 [hm**3]


 Kennwerte der Systemfunktionen
 -------------------------------

 Anzahl der Zeitschritte  ituh =     18
 Maximum u                imax =      3     umax = 0.269426
 Summe u                   suu = 0.999998   suuh = 1.000000


 tmax [d]:     4.91


 Kennwerte Ausflusswelle
 -----------------------

 Endordinate Ausfluss           qaend =   0.000
 Scheitel-Ausfluss              iqmax =   1413    qmax =       0.619 [m**3/s]

 Fuelle-Ausfluss                  fuq =   0.0179 [hm**3]
 Fuelle-Ausfluss im Gerinne      fuqa =   0.0179 [hm**3]

 Scheitel-Ausfluss im Gerinne  iqamax =   1413   qamax =       0.619 [m**3/s]


 Gesamtzuflusswelle (ohne Basisabfluss)  sqz =       59.529
 Gesamtabflusswelle    "       "         sq  =       59.529


 Keine angeschlossenen Teilgebiete an Strang      4517
 Auswertung des Stranges:         4518

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Aufruf der Speicherroutine 


 zufluss-fuelle [hm]        0.017371 speicher 4518
 zusaetzl.zufl im nachl.ast [hm]  0.000000

 speicher   0.017935 abfluss-fuelle [hm]      4518

 speicherinhaltsaenderung [hm]  0.000054
 Keine angeschlossenen Teilgebiete an Strang      4518
 Auswertung des Stranges:         4607

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Fiktiver Strang! Es erfolgt keine Abflussverzoegerung!
 Keine angeschlossenen Teilgebiete an Strang      4607
 Auswertung des Stranges:         4512

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.

 Keine angeschlossenen Teilgebiete an Strang      4512
 Auswertung des Stranges:         4513

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Abflussverzoegerung mit Kalinin-Miljukov Parametern

 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 dt [h]:   0.08      tmax [d]:     4.89


 Kennwerte Zuflusswelle
 ----------------------

 Scheitel-Zufluss               iqzmax =   1409   qzmax =       0.257 [m**3/s]
 Scheitel-Zufluss im Gerinne    iqzfmx =   1409  qzfmax =       0.257 [m**3/s]
 Scheitel-Zufluss im Vorland    iqzvmx =      0  qzvmax =       0.000 [m**3/s]

 Fuelle-Zufluss                   fuqz =   0.0070 [hm**3]
 Fuelle-zufluss im Gerinne       fuqzf =   0.0070 [hm**3]
 Fuelle-zufluss im Vorland       fuqzv =   0.0000 [hm**3]


 Kennwerte der Systemfunktionen
 -------------------------------

 Anzahl der Zeitschritte  ituh =     18
 Maximum u                imax =      3     umax = 0.269426
 Summe u                   suu = 0.999998   suuh = 1.000000


 tmax [d]:     4.91


 Kennwerte Ausflusswelle
 -----------------------

 Endordinate Ausfluss           qaend =   0.000
 Scheitel-Ausfluss              iqmax =   1413    qmax =       0.257 [m**3/s]

 Fuelle-Ausfluss                  fuq =   0.0070 [hm**3]
 Fuelle-Ausfluss im Gerinne      fuqa =   0.0070 [hm**3]

 Scheitel-Ausfluss im Gerinne  iqamax =   1413   qamax =       0.257 [m**3/s]


 Gesamtzuflusswelle (ohne Basisabfluss)  sqz =       23.311
 Gesamtabflusswelle    "       "         sq  =       23.311


 Keine angeschlossenen Teilgebiete an Strang      4513
 Auswertung des Stranges:         4519

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Abflussverzoegerung mit Kalinin-Miljukov Parametern

 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 dt [h]:   0.08      tmax [d]:     4.90


 Kennwerte Zuflusswelle
 ----------------------

 Scheitel-Zufluss               iqzmax =   1412   qzmax =       0.372 [m**3/s]
 Scheitel-Zufluss im Gerinne    iqzfmx =   1412  qzfmax =       0.372 [m**3/s]
 Scheitel-Zufluss im Vorland    iqzvmx =      0  qzvmax =       0.000 [m**3/s]

 Fuelle-Zufluss                   fuqz =   0.0102 [hm**3]
 Fuelle-zufluss im Gerinne       fuqzf =   0.0102 [hm**3]
 Fuelle-zufluss im Vorland       fuqzv =   0.0000 [hm**3]


 Kennwerte der Systemfunktionen
 -------------------------------

 Anzahl der Zeitschritte  ituh =     18
 Maximum u                imax =      3     umax = 0.269426
 Summe u                   suu = 0.999998   suuh = 1.000000


 tmax [d]:     4.91


 Kennwerte Ausflusswelle
 -----------------------

 Endordinate Ausfluss           qaend =   0.000
 Scheitel-Ausfluss              iqmax =   1415    qmax =       0.371 [m**3/s]

 Fuelle-Ausfluss                  fuq =   0.0102 [hm**3]
 Fuelle-Ausfluss im Gerinne      fuqa =   0.0102 [hm**3]

 Scheitel-Ausfluss im Gerinne  iqamax =   1415   qamax =       0.371 [m**3/s]


 Gesamtzuflusswelle (ohne Basisabfluss)  sqz =       33.835
 Gesamtabflusswelle    "       "         sq  =       33.835


 Keine angeschlossenen Teilgebiete an Strang      4519
 Auswertung des Stranges:         4522

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Abflussverzoegerung mit Kalinin-Miljukov Parametern

 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 dt [h]:   0.08      tmax [d]:     4.91


 Kennwerte Zuflusswelle
 ----------------------

 Scheitel-Zufluss               iqzmax =   1413   qzmax =       1.229 [m**3/s]
 Scheitel-Zufluss im Gerinne    iqzfmx =   1413  qzfmax =       1.229 [m**3/s]
 Scheitel-Zufluss im Vorland    iqzvmx =      0  qzvmax =       0.000 [m**3/s]

 Fuelle-Zufluss                   fuqz =   0.0347 [hm**3]
 Fuelle-zufluss im Gerinne       fuqzf =   0.0347 [hm**3]
 Fuelle-zufluss im Vorland       fuqzv =   0.0000 [hm**3]


 Kennwerte der Systemfunktionen
 -------------------------------

 Anzahl der Zeitschritte  ituh =   2880
 Maximum u                imax =      0     umax = 0.000000
 Summe u                   suu = 0.000000   suuh = 0.000000


 tmax [d]:     0.00


 Kennwerte Ausflusswelle
 -----------------------


 Endordinate Ausfluss           qaend =   0.001

 Scheitel-Ausfluss              iqmax =   1416    qmax =       1.227 [m**3/s]


 Fuelle-Ausfluss                  fuq =   0.0347 [hm**3]

 Fuelle-Ausfluss im Gerinne      fuqa =   0.0347 [hm**3]

 Fuelle-Ausfluss im vorland      fuqa =   0.0000 [hm**3]


 Scheitel-Ausfluss im Gerinne  iqamax =   1416   qamax =       1.227 [m**3/s]

 Scheitel-Ausfluss im Vorland  iqamax =      0   qamax =       0.000 [m**3/s]


 Gesamtzuflusswelle (ohne Basisabfluss)  sqz =      115.535
 Gesamtabflusswelle    "       "         sq  =      115.535


 Keine angeschlossenen Teilgebiete an Strang      4522
 Auswertung des Stranges:         4524

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Abflussverzoegerung mit Kalinin-Miljukov Parametern

 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 dt [h]:   0.08      tmax [d]:     4.91


 Kennwerte Zuflusswelle
 ----------------------

 Scheitel-Zufluss               iqzmax =   1413   qzmax =       1.696 [m**3/s]
 Scheitel-Zufluss im Gerinne    iqzfmx =   1413  qzfmax =       1.696 [m**3/s]
 Scheitel-Zufluss im Vorland    iqzvmx =      0  qzvmax =       0.000 [m**3/s]

 Fuelle-Zufluss                   fuqz =   0.0503 [hm**3]
 Fuelle-zufluss im Gerinne       fuqzf =   0.0503 [hm**3]
 Fuelle-zufluss im Vorland       fuqzv =   0.0000 [hm**3]


 Kennwerte der Systemfunktionen
 -------------------------------

 Anzahl der Zeitschritte  ituh =   2880
 Maximum u                imax =      0     umax = 0.000000
 Summe u                   suu = 0.000000   suuh = 0.000000


 tmax [d]:     0.00


 Kennwerte Ausflusswelle
 -----------------------


 Endordinate Ausfluss           qaend =   0.001

 Scheitel-Ausfluss              iqmax =   1416    qmax =       1.692 [m**3/s]


 Fuelle-Ausfluss                  fuq =   0.0503 [hm**3]

 Fuelle-Ausfluss im Gerinne      fuqa =   0.0503 [hm**3]

 Fuelle-Ausfluss im vorland      fuqa =   0.0000 [hm**3]


 Scheitel-Ausfluss im Gerinne  iqamax =   1416   qamax =       1.692 [m**3/s]

 Scheitel-Ausfluss im Vorland  iqamax =      0   qamax =       0.000 [m**3/s]


 Gesamtzuflusswelle (ohne Basisabfluss)  sqz =      167.772
 Gesamtabflusswelle    "       "         sq  =      167.773


 Keine angeschlossenen Teilgebiete an Strang      4524
 Auswertung des Stranges:         4525

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Aufruf der Speicherroutine 


 zufluss-fuelle [hm]        0.058532 speicher 4525
 zusaetzl.zufl im nachl.ast [hm]  0.000000

 speicher   0.060471 abfluss-fuelle [hm]      4525

 speicherinhaltsaenderung [hm]  0.000000
 Keine angeschlossenen Teilgebiete an Strang      4525
 Auswertung des Stranges:         4609

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Fiktiver Strang! Es erfolgt keine Abflussverzoegerung!
 Keine angeschlossenen Teilgebiete an Strang      4609
 Auswertung des Stranges:         4500

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.

 Keine angeschlossenen Teilgebiete an Strang      4500
 Auswertung des Stranges:         4501

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Abflussverzoegerung mit Kalinin-Miljukov Parametern

 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 dt [h]:   0.08      tmax [d]:     4.92


 Kennwerte Zuflusswelle
 ----------------------

 Scheitel-Zufluss               iqzmax =   1417   qzmax =       0.706 [m**3/s]
 Scheitel-Zufluss im Gerinne    iqzfmx =   1383  qzfmax =       0.242 [m**3/s]
 Scheitel-Zufluss im Vorland    iqzvmx =   1417  qzvmax =       0.584 [m**3/s]

 Fuelle-Zufluss                   fuqz =   0.0282 [hm**3]
 Fuelle-zufluss im Gerinne       fuqzf =   0.0152 [hm**3]
 Fuelle-zufluss im Vorland       fuqzv =   0.0130 [hm**3]


 Kennwerte der Systemfunktionen
 -------------------------------

 Anzahl der Zeitschritte  ituh =     34
 Maximum u                imax =      3     umax = 0.173632
 Summe u                   suu = 1.000082   suuh = 1.000000


 tmax [d]:     4.93


 Kennwerte Ausflusswelle
 -----------------------


 Endordinate Ausfluss           qaend =   0.000

 Scheitel-Ausfluss              iqmax =   1420    qmax =       0.704 [m**3/s]


 Fuelle-Ausfluss                  fuq =   0.0280 [hm**3]

 Fuelle-Ausfluss im Gerinne      fuqa =   0.0152 [hm**3]

 Fuelle-Ausfluss im vorland      fuqa =   0.0128 [hm**3]


 Scheitel-Ausfluss im Gerinne  iqamax =   1489   qamax =       0.241 [m**3/s]

 Scheitel-Ausfluss im Vorland  iqamax =   1421   qamax =       0.583 [m**3/s]


 Gesamtzuflusswelle (ohne Basisabfluss)  sqz =       93.868
 Gesamtabflusswelle    "       "         sq  =       93.411


 Keine angeschlossenen Teilgebiete an Strang      4501
 Auswertung des Stranges:         4502

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Aufruf der Speicherroutine 


 zufluss-fuelle [hm]        0.046652 speicher 4502
 zusaetzl.zufl im nachl.ast [hm]  0.000000

 speicher   0.048127 abfluss-fuelle [hm]      4502

 speicherinhaltsaenderung [hm]  0.000000
 Keine angeschlossenen Teilgebiete an Strang      4502
 Auswertung des Stranges:         4506

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Abflussverzoegerung mit Kalinin-Miljukov Parametern

 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 dt [h]:   0.08      tmax [d]:     4.93


 Kennwerte Zuflusswelle
 ----------------------

 Scheitel-Zufluss               iqzmax =   1420   qzmax =       1.281 [m**3/s]
 Scheitel-Zufluss im Gerinne    iqzfmx =   1518  qzfmax =       0.242 [m**3/s]
 Scheitel-Zufluss im Vorland    iqzvmx =   1420  qzvmax =       1.059 [m**3/s]

 Fuelle-Zufluss                   fuqz =   0.0481 [hm**3]
 Fuelle-zufluss im Gerinne       fuqzf =   0.0226 [hm**3]
 Fuelle-zufluss im Vorland       fuqzv =   0.0255 [hm**3]


 Kennwerte der Systemfunktionen
 -------------------------------

 Anzahl der Zeitschritte  ituh =     34
 Maximum u                imax =      3     umax = 0.173632
 Summe u                   suu = 1.000082   suuh = 1.000000


 tmax [d]:     4.94


 Kennwerte Ausflusswelle
 -----------------------


 Endordinate Ausfluss           qaend =   0.000

 Scheitel-Ausfluss              iqmax =   1424    qmax =       1.276 [m**3/s]


 Fuelle-Ausfluss                  fuq =   0.0478 [hm**3]

 Fuelle-Ausfluss im Gerinne      fuqa =   0.0226 [hm**3]

 Fuelle-Ausfluss im vorland      fuqa =   0.0252 [hm**3]


 Scheitel-Ausfluss im Gerinne  iqamax =   1519   qamax =       0.241 [m**3/s]

 Scheitel-Ausfluss im Vorland  iqamax =   1424   qamax =       1.056 [m**3/s]


 Gesamtzuflusswelle (ohne Basisabfluss)  sqz =      160.456
 Gesamtabflusswelle    "       "         sq  =      159.287


 Keine angeschlossenen Teilgebiete an Strang      4506
 Auswertung des Stranges:         4510

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Abflussverzoegerung mit Kalinin-Miljukov Parametern

 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 dt [h]:   0.08      tmax [d]:     4.93


 Kennwerte Zuflusswelle
 ----------------------

 Scheitel-Zufluss               iqzmax =   1421   qzmax =       2.255 [m**3/s]
 Scheitel-Zufluss im Gerinne    iqzfmx =   1421  qzfmax =       2.183 [m**3/s]
 Scheitel-Zufluss im Vorland    iqzvmx =   1421  qzvmax =       0.072 [m**3/s]

 Fuelle-Zufluss                   fuqz =   0.0951 [hm**3]
 Fuelle-zufluss im Gerinne       fuqzf =   0.0945 [hm**3]
 Fuelle-zufluss im Vorland       fuqzv =   0.0006 [hm**3]


 Kennwerte der Systemfunktionen
 -------------------------------

 Anzahl der Zeitschritte  ituh =    119
 Maximum u                imax =      1     umax = 0.368774
 Summe u                   suu = 0.870027   suuh = 1.000000


 tmax [d]:     4.94


 Kennwerte Ausflusswelle
 -----------------------


 Endordinate Ausfluss           qaend =   0.000

 Scheitel-Ausfluss              iqmax =   1426    qmax =       2.153 [m**3/s]


 Fuelle-Ausfluss                  fuq =   0.0948 [hm**3]

 Fuelle-Ausfluss im Gerinne      fuqa =   0.0942 [hm**3]

 Fuelle-Ausfluss im vorland      fuqa =   0.0006 [hm**3]


 Scheitel-Ausfluss im Gerinne  iqamax =   1427   qamax =       2.087 [m**3/s]

 Scheitel-Ausfluss im Vorland  iqamax =   1423   qamax =       0.068 [m**3/s]


 Gesamtzuflusswelle (ohne Basisabfluss)  sqz =      317.011
 Gesamtabflusswelle    "       "         sq  =      315.941


 Keine angeschlossenen Teilgebiete an Strang      4510
 Auswertung des Stranges:         4526

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Abflussverzoegerung mit Kalinin-Miljukov Parametern

 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 dt [h]:   0.08      tmax [d]:     4.92


 Kennwerte Zuflusswelle
 ----------------------

 Scheitel-Zufluss               iqzmax =   1417   qzmax =       3.778 [m**3/s]
 Scheitel-Zufluss im Gerinne    iqzfmx =   1417  qzfmax =       3.778 [m**3/s]
 Scheitel-Zufluss im Vorland    iqzvmx =      0  qzvmax =       0.000 [m**3/s]

 Fuelle-Zufluss                   fuqz =   0.1536 [hm**3]
 Fuelle-zufluss im Gerinne       fuqzf =   0.1536 [hm**3]
 Fuelle-zufluss im Vorland       fuqzv =   0.0000 [hm**3]


 Kennwerte der Systemfunktionen
 -------------------------------

 Anzahl der Zeitschritte  ituh =     27
 Maximum u                imax =      1     umax = 0.557957
 Summe u                   suu = 0.784427   suuh = 1.000000


 tmax [d]:     4.92


 Kennwerte Ausflusswelle
 -----------------------

 Endordinate Ausfluss           qaend =   0.000
 Scheitel-Ausfluss              iqmax =   1418    qmax =       3.774 [m**3/s]

 Fuelle-Ausfluss                  fuq =   0.1536 [hm**3]
 Fuelle-Ausfluss im Gerinne      fuqa =   0.1536 [hm**3]

 Scheitel-Ausfluss im Gerinne  iqamax =   1418   qamax =       3.774 [m**3/s]


 Gesamtzuflusswelle (ohne Basisabfluss)  sqz =      511.979
 Gesamtabflusswelle    "       "         sq  =      511.979


 Keine angeschlossenen Teilgebiete an Strang      4526
 Auswertung des Stranges:         4532

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Abflussverzoegerung mit Kalinin-Miljukov Parametern

 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 dt [h]:   0.08      tmax [d]:     4.94


 Kennwerte Zuflusswelle
 ----------------------

 Scheitel-Zufluss               iqzmax =   1422   qzmax =       5.160 [m**3/s]
 Scheitel-Zufluss im Gerinne    iqzfmx =   1422  qzfmax =       2.587 [m**3/s]
 Scheitel-Zufluss im Vorland    iqzvmx =   1422  qzvmax =       2.573 [m**3/s]

 Fuelle-Zufluss                   fuqz =   0.2255 [hm**3]
 Fuelle-zufluss im Gerinne       fuqzf =   0.1653 [hm**3]
 Fuelle-zufluss im Vorland       fuqzv =   0.0602 [hm**3]


 Kennwerte der Systemfunktionen
 -------------------------------

 Anzahl der Zeitschritte  ituh =     58
 Maximum u                imax =      1     umax = 0.450462
 Summe u                   suu = 0.778253   suuh = 0.999630


 tmax [d]:     4.94


 Kennwerte Ausflusswelle
 -----------------------


 Endordinate Ausfluss           qaend =   0.000

 Scheitel-Ausfluss              iqmax =   1425    qmax =       5.102 [m**3/s]


 Fuelle-Ausfluss                  fuq =   0.2256 [hm**3]

 Fuelle-Ausfluss im Gerinne      fuqa =   0.1653 [hm**3]

 Fuelle-Ausfluss im vorland      fuqa =   0.0603 [hm**3]


 Scheitel-Ausfluss im Gerinne  iqamax =   1426   qamax =       2.546 [m**3/s]

 Scheitel-Ausfluss im Vorland  iqamax =   1423   qamax =       2.559 [m**3/s]


 Gesamtzuflusswelle (ohne Basisabfluss)  sqz =      751.757
 Gesamtabflusswelle    "       "         sq  =      752.090


 Keine angeschlossenen Teilgebiete an Strang      4532
 Auswertung des Stranges:         4563

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Abflussverzoegerung mit Kalinin-Miljukov Parametern

 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 dt [h]:   0.08      tmax [d]:     4.94


 Kennwerte Zuflusswelle
 ----------------------

 Scheitel-Zufluss               iqzmax =   1423   qzmax =       5.610 [m**3/s]
 Scheitel-Zufluss im Gerinne    iqzfmx =   1423  qzfmax =       4.504 [m**3/s]
 Scheitel-Zufluss im Vorland    iqzvmx =   1423  qzvmax =       1.105 [m**3/s]

 Fuelle-Zufluss                   fuqz =   0.2535 [hm**3]
 Fuelle-zufluss im Gerinne       fuqzf =   0.2402 [hm**3]
 Fuelle-zufluss im Vorland       fuqzv =   0.0133 [hm**3]


 Kennwerte der Systemfunktionen
 -------------------------------

 Anzahl der Zeitschritte  ituh =     68
 Maximum u                imax =      1     umax = 0.284769
 Summe u                   suu = 0.990478   suuh = 1.000000


 tmax [d]:     4.95


 Kennwerte Ausflusswelle
 -----------------------


 Endordinate Ausfluss           qaend =   0.001

 Scheitel-Ausfluss              iqmax =   1426    qmax =       5.561 [m**3/s]


 Fuelle-Ausfluss                  fuq =   0.2535 [hm**3]

 Fuelle-Ausfluss im Gerinne      fuqa =   0.2402 [hm**3]

 Fuelle-Ausfluss im vorland      fuqa =   0.0133 [hm**3]


 Scheitel-Ausfluss im Gerinne  iqamax =   1424   qamax =       4.503 [m**3/s]

 Scheitel-Ausfluss im Vorland  iqamax =   1427   qamax =       1.062 [m**3/s]


 Gesamtzuflusswelle (ohne Basisabfluss)  sqz =      844.840
 Gesamtabflusswelle    "       "         sq  =      844.840


 Keine angeschlossenen Teilgebiete an Strang      4563
 Auswertung des Stranges:         4541

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.

 Keine angeschlossenen Teilgebiete an Strang      4541
 Auswertung des Stranges:         4534

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.

 Keine angeschlossenen Teilgebiete an Strang      4534
 Auswertung des Stranges:         4535

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Abflussverzoegerung mit Kalinin-Miljukov Parametern

 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 dt [h]:   0.08      tmax [d]:     4.80


 Kennwerte Zuflusswelle
 ----------------------

 Scheitel-Zufluss               iqzmax =   1383   qzmax =       1.578 [m**3/s]
 Scheitel-Zufluss im Gerinne    iqzfmx =   1383  qzfmax =       1.578 [m**3/s]
 Scheitel-Zufluss im Vorland    iqzvmx =      0  qzvmax =       0.000 [m**3/s]

 Fuelle-Zufluss                   fuqz =   0.0234 [hm**3]
 Fuelle-zufluss im Gerinne       fuqzf =   0.0234 [hm**3]
 Fuelle-zufluss im Vorland       fuqzv =   0.0000 [hm**3]


 Kennwerte der Systemfunktionen
 -------------------------------

 Anzahl der Zeitschritte  ituh =   2880
 Maximum u                imax =      1     umax = 0.000000
 Summe u                   suu = 0.000000   suuh = 0.000000


 tmax [d]:     0.00


 Kennwerte Ausflusswelle
 -----------------------


 Endordinate Ausfluss           qaend =   0.002

 Scheitel-Ausfluss              iqmax =   1386    qmax =       1.471 [m**3/s]


 Fuelle-Ausfluss                  fuq =   0.0234 [hm**3]

 Fuelle-Ausfluss im Gerinne      fuqa =   0.0234 [hm**3]

 Fuelle-Ausfluss im vorland      fuqa =   0.0000 [hm**3]


 Scheitel-Ausfluss im Gerinne  iqamax =   1386   qamax =       1.471 [m**3/s]

 Scheitel-Ausfluss im Vorland  iqamax =      0   qamax =       0.000 [m**3/s]


 Gesamtzuflusswelle (ohne Basisabfluss)  sqz =       78.086
 Gesamtabflusswelle    "       "         sq  =       78.086


 Keine angeschlossenen Teilgebiete an Strang      4535
 Auswertung des Stranges:         4536

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Aufruf der Speicherroutine 


 zufluss-fuelle [hm]        0.032211 speicher 4536
 zusaetzl.zufl im nachl.ast [hm]  0.000000

 speicher   0.032540 abfluss-fuelle [hm]      4536

 speicherinhaltsaenderung [hm]  0.000000
 Keine angeschlossenen Teilgebiete an Strang      4536
 Auswertung des Stranges:         4612

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Fiktiver Strang! Es erfolgt keine Abflussverzoegerung!
 Keine angeschlossenen Teilgebiete an Strang      4612
 Auswertung des Stranges:         4537

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.

 Keine angeschlossenen Teilgebiete an Strang      4537
 Auswertung des Stranges:         4538

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Abflussverzoegerung mit Kalinin-Miljukov Parametern

 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 dt [h]:   0.08      tmax [d]:     4.83


 Kennwerte Zuflusswelle
 ----------------------

 Scheitel-Zufluss               iqzmax =   1390   qzmax =       0.161 [m**3/s]
 Scheitel-Zufluss im Gerinne    iqzfmx =   1390  qzfmax =       0.161 [m**3/s]
 Scheitel-Zufluss im Vorland    iqzvmx =      0  qzvmax =       0.000 [m**3/s]

 Fuelle-Zufluss                   fuqz =   0.0028 [hm**3]
 Fuelle-zufluss im Gerinne       fuqzf =   0.0028 [hm**3]
 Fuelle-zufluss im Vorland       fuqzv =   0.0000 [hm**3]


 Kennwerte der Systemfunktionen
 -------------------------------

 Anzahl der Zeitschritte  ituh =     25
 Maximum u                imax =      1     umax = 0.540740
 Summe u                   suu = 0.727210   suuh = 1.000000


 tmax [d]:     4.83


 Kennwerte Ausflusswelle
 -----------------------

 Endordinate Ausfluss           qaend =   0.000
 Scheitel-Ausfluss              iqmax =   1391    qmax =       0.158 [m**3/s]

 Fuelle-Ausfluss                  fuq =   0.0028 [hm**3]
 Fuelle-Ausfluss im Gerinne      fuqa =   0.0028 [hm**3]

 Scheitel-Ausfluss im Gerinne  iqamax =   1391   qamax =       0.158 [m**3/s]


 Gesamtzuflusswelle (ohne Basisabfluss)  sqz =        9.410
 Gesamtabflusswelle    "       "         sq  =        9.410


 Keine angeschlossenen Teilgebiete an Strang      4538
 Auswertung des Stranges:         4539

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Abflussverzoegerung mit Kalinin-Miljukov Parametern

 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 dt [h]:   0.08      tmax [d]:     4.82


 Kennwerte Zuflusswelle
 ----------------------

 Scheitel-Zufluss               iqzmax =   1387   qzmax =       2.010 [m**3/s]
 Scheitel-Zufluss im Gerinne    iqzfmx =   1387  qzfmax =       1.608 [m**3/s]
 Scheitel-Zufluss im Vorland    iqzvmx =   1387  qzvmax =       0.402 [m**3/s]

 Fuelle-Zufluss                   fuqz =   0.0354 [hm**3]
 Fuelle-zufluss im Gerinne       fuqzf =   0.0324 [hm**3]
 Fuelle-zufluss im Vorland       fuqzv =   0.0029 [hm**3]


 Kennwerte der Systemfunktionen
 -------------------------------

 Anzahl der Zeitschritte  ituh =   2880
 Maximum u                imax =      1     umax = 0.000000
 Summe u                   suu = 0.000000   suuh = 0.000000


 tmax [d]:     4.82


 Kennwerte Ausflusswelle
 -----------------------


 Endordinate Ausfluss           qaend =   0.002

 Scheitel-Ausfluss              iqmax =   1387    qmax =       1.938 [m**3/s]


 Fuelle-Ausfluss                  fuq =   0.0354 [hm**3]

 Fuelle-Ausfluss im Gerinne      fuqa =   0.0324 [hm**3]

 Fuelle-Ausfluss im vorland      fuqa =   0.0029 [hm**3]


 Scheitel-Ausfluss im Gerinne  iqamax =   1387   qamax =       1.551 [m**3/s]

 Scheitel-Ausfluss im Vorland  iqamax =   1388   qamax =       0.387 [m**3/s]


 Gesamtzuflusswelle (ohne Basisabfluss)  sqz =      117.898
 Gesamtabflusswelle    "       "         sq  =      117.899


 Keine angeschlossenen Teilgebiete an Strang      4539
 Auswertung des Stranges:         4540

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Aufruf der Speicherroutine 


 zufluss-fuelle [hm]        0.132985 speicher 4540
 zusaetzl.zufl im nachl.ast [hm]  0.000000

 speicher   0.133443 abfluss-fuelle [hm]      4540

 speicherinhaltsaenderung [hm]  0.000000
 Keine angeschlossenen Teilgebiete an Strang      4540
 Auswertung des Stranges:         4613

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Fiktiver Strang! Es erfolgt keine Abflussverzoegerung!
 Keine angeschlossenen Teilgebiete an Strang      4613
 Auswertung des Stranges:         4546

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Abflussverzoegerung mit Kalinin-Miljukov Parametern

 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 dt [h]:   0.08      tmax [d]:     4.82


 Kennwerte Zuflusswelle
 ----------------------

 Scheitel-Zufluss               iqzmax =   1388   qzmax =       8.543 [m**3/s]
 Scheitel-Zufluss im Gerinne    iqzfmx =   1388  qzfmax =       6.835 [m**3/s]
 Scheitel-Zufluss im Vorland    iqzvmx =   1388  qzvmax =       1.709 [m**3/s]

 Fuelle-Zufluss                   fuqz =   0.1556 [hm**3]
 Fuelle-zufluss im Gerinne       fuqzf =   0.1313 [hm**3]
 Fuelle-zufluss im Vorland       fuqzv =   0.0242 [hm**3]


 Kennwerte der Systemfunktionen
 -------------------------------

 Anzahl der Zeitschritte  ituh =   2880
 Maximum u                imax =      1     umax = 0.000000
 Summe u                   suu = 0.000000   suuh = 0.000000


 tmax [d]:     4.82


 Kennwerte Ausflusswelle
 -----------------------


 Endordinate Ausfluss           qaend =   0.003

 Scheitel-Ausfluss              iqmax =   1389    qmax =       8.428 [m**3/s]


 Fuelle-Ausfluss                  fuq =   0.1556 [hm**3]

 Fuelle-Ausfluss im Gerinne      fuqa =   0.1313 [hm**3]

 Fuelle-Ausfluss im vorland      fuqa =   0.0242 [hm**3]


 Scheitel-Ausfluss im Gerinne  iqamax =   1389   qamax =       6.742 [m**3/s]

 Scheitel-Ausfluss im Vorland  iqamax =   1389   qamax =       1.685 [m**3/s]


 Gesamtzuflusswelle (ohne Basisabfluss)  sqz =      518.551
 Gesamtabflusswelle    "       "         sq  =      518.551


 Keine angeschlossenen Teilgebiete an Strang      4546
 Auswertung des Stranges:         4543

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.

 Keine angeschlossenen Teilgebiete an Strang      4543
 Auswertung des Stranges:         4544

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Abflussverzoegerung mit Kalinin-Miljukov Parametern

 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 dt [h]:   0.08      tmax [d]:     4.82


 Kennwerte Zuflusswelle
 ----------------------

 Scheitel-Zufluss               iqzmax =   1389   qzmax =       3.737 [m**3/s]
 Scheitel-Zufluss im Gerinne    iqzfmx =   1389  qzfmax =       2.990 [m**3/s]
 Scheitel-Zufluss im Vorland    iqzvmx =   1389  qzvmax =       0.747 [m**3/s]

 Fuelle-Zufluss                   fuqz =   0.0536 [hm**3]
 Fuelle-zufluss im Gerinne       fuqzf =   0.0468 [hm**3]
 Fuelle-zufluss im Vorland       fuqzv =   0.0068 [hm**3]


 Kennwerte der Systemfunktionen
 -------------------------------

 Anzahl der Zeitschritte  ituh =   2880
 Maximum u                imax =      1     umax = 0.000000
 Summe u                   suu = 0.000000   suuh = 0.000000


 tmax [d]:     4.83


 Kennwerte Ausflusswelle
 -----------------------


 Endordinate Ausfluss           qaend =   0.005

 Scheitel-Ausfluss              iqmax =   1390    qmax =       3.683 [m**3/s]


 Fuelle-Ausfluss                  fuq =   0.0536 [hm**3]

 Fuelle-Ausfluss im Gerinne      fuqa =   0.0468 [hm**3]

 Fuelle-Ausfluss im vorland      fuqa =   0.0068 [hm**3]


 Scheitel-Ausfluss im Gerinne  iqamax =   1390   qamax =       2.947 [m**3/s]

 Scheitel-Ausfluss im Vorland  iqamax =   1390   qamax =       0.737 [m**3/s]


 Gesamtzuflusswelle (ohne Basisabfluss)  sqz =      178.675
 Gesamtabflusswelle    "       "         sq  =      178.679


 Keine angeschlossenen Teilgebiete an Strang      4544
 Auswertung des Stranges:         4545

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Aufruf der Speicherroutine 


 zufluss-fuelle [hm]        0.071683 speicher 4545
 zusaetzl.zufl im nachl.ast [hm]  0.000000

 speicher   0.049454 abfluss-fuelle [hm]      4545
 abfluss-fuelle [hm]  0.0221 ueberlauf 

 speicherinhaltsaenderung [hm]  0.000000
 Keine angeschlossenen Teilgebiete an Strang      4545
 Auswertung des Stranges:         4547

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Abflussverzoegerung mit Kalinin-Miljukov Parametern

 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 dt [h]:   0.08      tmax [d]:     4.85


 Kennwerte Zuflusswelle
 ----------------------

 Scheitel-Zufluss               iqzmax =   1397   qzmax =       1.035 [m**3/s]
 Scheitel-Zufluss im Gerinne    iqzfmx =   1397  qzfmax =       1.035 [m**3/s]
 Scheitel-Zufluss im Vorland    iqzvmx =      0  qzvmax =       0.000 [m**3/s]

 Fuelle-Zufluss                   fuqz =   0.0495 [hm**3]
 Fuelle-zufluss im Gerinne       fuqzf =   0.0495 [hm**3]
 Fuelle-zufluss im Vorland       fuqzv =   0.0000 [hm**3]


 Kennwerte der Systemfunktionen
 -------------------------------

 Anzahl der Zeitschritte  ituh =   2880
 Maximum u                imax =      1     umax = 0.000000
 Summe u                   suu = 0.000000   suuh = 0.000000


 tmax [d]:     0.00


 Kennwerte Ausflusswelle
 -----------------------


 Endordinate Ausfluss           qaend =   0.006

 Scheitel-Ausfluss              iqmax =   1401    qmax =       1.035 [m**3/s]


 Fuelle-Ausfluss                  fuq =   0.0495 [hm**3]

 Fuelle-Ausfluss im Gerinne      fuqa =   0.0495 [hm**3]

 Fuelle-Ausfluss im vorland      fuqa =   0.0000 [hm**3]


 Scheitel-Ausfluss im Gerinne  iqamax =   1401   qamax =       1.035 [m**3/s]

 Scheitel-Ausfluss im Vorland  iqamax =      0   qamax =       0.000 [m**3/s]


 Gesamtzuflusswelle (ohne Basisabfluss)  sqz =      164.859
 Gesamtabflusswelle    "       "         sq  =      164.865


 Keine angeschlossenen Teilgebiete an Strang      4547
 Auswertung des Stranges:         4548

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Abflussverzoegerung mit Kalinin-Miljukov Parametern

 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 dt [h]:   0.08      tmax [d]:     4.82


 Kennwerte Zuflusswelle
 ----------------------

 Scheitel-Zufluss               iqzmax =   1389   qzmax =      10.563 [m**3/s]
 Scheitel-Zufluss im Gerinne    iqzfmx =   1389  qzfmax =       8.450 [m**3/s]
 Scheitel-Zufluss im Vorland    iqzvmx =   1389  qzvmax =       2.113 [m**3/s]

 Fuelle-Zufluss                   fuqz =   0.2289 [hm**3]
 Fuelle-zufluss im Gerinne       fuqzf =   0.1913 [hm**3]
 Fuelle-zufluss im Vorland       fuqzv =   0.0376 [hm**3]


 Kennwerte der Systemfunktionen
 -------------------------------

 Anzahl der Zeitschritte  ituh =   2880
 Maximum u                imax =      1     umax = 0.000000
 Summe u                   suu = 0.000000   suuh = 0.000000


 tmax [d]:     4.82


 Kennwerte Ausflusswelle
 -----------------------


 Endordinate Ausfluss           qaend =   0.000

 Scheitel-Ausfluss              iqmax =   1389    qmax =      10.416 [m**3/s]


 Fuelle-Ausfluss                  fuq =   0.2289 [hm**3]

 Fuelle-Ausfluss im Gerinne      fuqa =   0.1913 [hm**3]

 Fuelle-Ausfluss im vorland      fuqa =   0.0376 [hm**3]


 Scheitel-Ausfluss im Gerinne  iqamax =   1389   qamax =       8.333 [m**3/s]

 Scheitel-Ausfluss im Vorland  iqamax =   1389   qamax =       2.083 [m**3/s]


 Gesamtzuflusswelle (ohne Basisabfluss)  sqz =      763.078
 Gesamtabflusswelle    "       "         sq  =      763.079


 Keine angeschlossenen Teilgebiete an Strang      4548
 Auswertung des Stranges:         4549

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.

 Keine angeschlossenen Teilgebiete an Strang      4549
 Auswertung des Stranges:         4550

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Aufruf der Speicherroutine 


 zufluss-fuelle [hm]        0.046063 speicher 4550
 zusaetzl.zufl im nachl.ast [hm]  0.000000

 speicher   0.026362 abfluss-fuelle [hm]      4550
 abfluss-fuelle [hm]  0.0195 ueberlauf 

 speicherinhaltsaenderung [hm]  0.000001
 Keine angeschlossenen Teilgebiete an Strang      4550
 Auswertung des Stranges:         4551

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Abflussverzoegerung mit Kalinin-Miljukov Parametern

 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 dt [h]:   0.08      tmax [d]:     4.82


 Kennwerte Zuflusswelle
 ----------------------

 Scheitel-Zufluss               iqzmax =   1389   qzmax =       0.276 [m**3/s]
 Scheitel-Zufluss im Gerinne    iqzfmx =   1389  qzfmax =       0.276 [m**3/s]
 Scheitel-Zufluss im Vorland    iqzvmx =      0  qzvmax =       0.000 [m**3/s]

 Fuelle-Zufluss                   fuqz =   0.0264 [hm**3]
 Fuelle-zufluss im Gerinne       fuqzf =   0.0264 [hm**3]
 Fuelle-zufluss im Vorland       fuqzv =   0.0000 [hm**3]


 Kennwerte der Systemfunktionen
 -------------------------------

 Anzahl der Zeitschritte  ituh =     25
 Maximum u                imax =      1     umax = 0.540740
 Summe u                   suu = 0.727210   suuh = 1.000000


 tmax [d]:     4.91


 Kennwerte Ausflusswelle
 -----------------------

 Endordinate Ausfluss           qaend =   0.000
 Scheitel-Ausfluss              iqmax =   1414    qmax =       0.276 [m**3/s]

 Fuelle-Ausfluss                  fuq =   0.0264 [hm**3]
 Fuelle-Ausfluss im Gerinne      fuqa =   0.0264 [hm**3]

 Scheitel-Ausfluss im Gerinne  iqamax =   1414   qamax =       0.276 [m**3/s]


 Gesamtzuflusswelle (ohne Basisabfluss)  sqz =       87.875
 Gesamtabflusswelle    "       "         sq  =       87.875


 Keine angeschlossenen Teilgebiete an Strang      4551
 Auswertung des Stranges:         4553

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Abflussverzoegerung mit Kalinin-Miljukov Parametern

 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 dt [h]:   0.08      tmax [d]:     4.82


 Kennwerte Zuflusswelle
 ----------------------

 Scheitel-Zufluss               iqzmax =   1389   qzmax =      14.551 [m**3/s]
 Scheitel-Zufluss im Gerinne    iqzfmx =   1389  qzfmax =      14.551 [m**3/s]
 Scheitel-Zufluss im Vorland    iqzvmx =      0  qzvmax =       0.000 [m**3/s]

 Fuelle-Zufluss                   fuqz =   0.3185 [hm**3]
 Fuelle-zufluss im Gerinne       fuqzf =   0.3185 [hm**3]
 Fuelle-zufluss im Vorland       fuqzv =   0.0000 [hm**3]


 Kennwerte der Systemfunktionen
 -------------------------------

 Anzahl der Zeitschritte  ituh =   2880
 Maximum u                imax =      1     umax = 0.000000
 Summe u                   suu = 0.000000   suuh = 0.000000


 tmax [d]:     0.00


 Kennwerte Ausflusswelle
 -----------------------


 Endordinate Ausfluss           qaend =   0.008

 Scheitel-Ausfluss              iqmax =   1392    qmax =      14.265 [m**3/s]


 Fuelle-Ausfluss                  fuq =   0.3185 [hm**3]

 Fuelle-Ausfluss im Gerinne      fuqa =   0.3185 [hm**3]

 Fuelle-Ausfluss im vorland      fuqa =   0.0000 [hm**3]


 Scheitel-Ausfluss im Gerinne  iqamax =   1392   qamax =      14.265 [m**3/s]

 Scheitel-Ausfluss im Vorland  iqamax =      0   qamax =       0.000 [m**3/s]


 Gesamtzuflusswelle (ohne Basisabfluss)  sqz =     1061.514
 Gesamtabflusswelle    "       "         sq  =     1061.520


 Keine angeschlossenen Teilgebiete an Strang      4553
 Auswertung des Stranges:         4559

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Abflussverzoegerung mit Kalinin-Miljukov Parametern

 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 dt [h]:   0.08      tmax [d]:     4.83


 Kennwerte Zuflusswelle
 ----------------------

 Scheitel-Zufluss               iqzmax =   1392   qzmax =      14.607 [m**3/s]
 Scheitel-Zufluss im Gerinne    iqzfmx =   1392  qzfmax =      11.686 [m**3/s]
 Scheitel-Zufluss im Vorland    iqzvmx =   1392  qzvmax =       2.921 [m**3/s]

 Fuelle-Zufluss                   fuqz =   0.3282 [hm**3]
 Fuelle-zufluss im Gerinne       fuqzf =   0.2713 [hm**3]
 Fuelle-zufluss im Vorland       fuqzv =   0.0569 [hm**3]


 Kennwerte der Systemfunktionen
 -------------------------------

 Anzahl der Zeitschritte  ituh =   2880
 Maximum u                imax =      1     umax = 0.000000
 Summe u                   suu = 0.000000   suuh = 0.000000


 tmax [d]:     4.83


 Kennwerte Ausflusswelle
 -----------------------


 Endordinate Ausfluss           qaend =   0.008

 Scheitel-Ausfluss              iqmax =   1392    qmax =      14.453 [m**3/s]


 Fuelle-Ausfluss                  fuq =   0.3282 [hm**3]

 Fuelle-Ausfluss im Gerinne      fuqa =   0.2713 [hm**3]

 Fuelle-Ausfluss im vorland      fuqa =   0.0569 [hm**3]


 Scheitel-Ausfluss im Gerinne  iqamax =   1392   qamax =      11.563 [m**3/s]

 Scheitel-Ausfluss im Vorland  iqamax =   1392   qamax =       2.891 [m**3/s]


 Gesamtzuflusswelle (ohne Basisabfluss)  sqz =     1093.943
 Gesamtabflusswelle    "       "         sq  =     1093.953


 Keine angeschlossenen Teilgebiete an Strang      4559
 Auswertung des Stranges:         4554

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.

 Keine angeschlossenen Teilgebiete an Strang      4554
 Auswertung des Stranges:         4555

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Aufruf der Speicherroutine 


 zufluss-fuelle [hm]        0.028397 speicher 4555
 zusaetzl.zufl im nachl.ast [hm]  0.000000

 speicher   0.025353 abfluss-fuelle [hm]      4555
 abfluss-fuelle [hm]  0.0029 ueberlauf 

 speicherinhaltsaenderung [hm]  0.000053
 Keine angeschlossenen Teilgebiete an Strang      4555
 Auswertung des Stranges:         4556

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Abflussverzoegerung mit Kalinin-Miljukov Parametern

 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 dt [h]:   0.08      tmax [d]:     4.84


 Kennwerte Zuflusswelle
 ----------------------

 Scheitel-Zufluss               iqzmax =   1393   qzmax =       0.733 [m**3/s]
 Scheitel-Zufluss im Gerinne    iqzfmx =   1441  qzfmax =       0.609 [m**3/s]
 Scheitel-Zufluss im Vorland    iqzvmx =   1393  qzvmax =       0.147 [m**3/s]

 Fuelle-Zufluss                   fuqz =   0.0254 [hm**3]
 Fuelle-zufluss im Gerinne       fuqzf =   0.0234 [hm**3]
 Fuelle-zufluss im Vorland       fuqzv =   0.0019 [hm**3]


 Kennwerte der Systemfunktionen
 -------------------------------

 Anzahl der Zeitschritte  ituh =   2880
 Maximum u                imax =      1     umax = 0.000000
 Summe u                   suu = 0.000000   suuh = 0.000000


 tmax [d]:     4.89


 Kennwerte Ausflusswelle
 -----------------------


 Endordinate Ausfluss           qaend =   0.003

 Scheitel-Ausfluss              iqmax =   1408    qmax =       0.733 [m**3/s]


 Fuelle-Ausfluss                  fuq =   0.0254 [hm**3]

 Fuelle-Ausfluss im Gerinne      fuqa =   0.0234 [hm**3]

 Fuelle-Ausfluss im vorland      fuqa =   0.0019 [hm**3]


 Scheitel-Ausfluss im Gerinne  iqamax =   1442   qamax =       0.607 [m**3/s]

 Scheitel-Ausfluss im Vorland  iqamax =   1408   qamax =       0.147 [m**3/s]


 Gesamtzuflusswelle (ohne Basisabfluss)  sqz =       84.511
 Gesamtabflusswelle    "       "         sq  =       84.512


 Keine angeschlossenen Teilgebiete an Strang      4556
 Auswertung des Stranges:         4557

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Aufruf der Speicherroutine 


 zufluss-fuelle [hm]        0.072576 speicher 4557
 zusaetzl.zufl im nachl.ast [hm]  0.000000

 speicher   0.066233 abfluss-fuelle [hm]      4557
 abfluss-fuelle [hm]  0.0064 ueberlauf 

 speicherinhaltsaenderung [hm]  0.000006
 Keine angeschlossenen Teilgebiete an Strang      4557
 Auswertung des Stranges:         4558

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Abflussverzoegerung mit Kalinin-Miljukov Parametern

 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 dt [h]:   0.08      tmax [d]:     4.84


 Kennwerte Zuflusswelle
 ----------------------

 Scheitel-Zufluss               iqzmax =   1393   qzmax =       1.730 [m**3/s]
 Scheitel-Zufluss im Gerinne    iqzfmx =   1393  qzfmax =       1.384 [m**3/s]
 Scheitel-Zufluss im Vorland    iqzvmx =   1393  qzvmax =       0.346 [m**3/s]

 Fuelle-Zufluss                   fuqz =   0.0662 [hm**3]
 Fuelle-zufluss im Gerinne       fuqzf =   0.0575 [hm**3]
 Fuelle-zufluss im Vorland       fuqzv =   0.0087 [hm**3]


 Kennwerte der Systemfunktionen
 -------------------------------

 Anzahl der Zeitschritte  ituh =   2880
 Maximum u                imax =      1     umax = 0.000000
 Summe u                   suu = 0.000000   suuh = 0.000000


 tmax [d]:     4.92


 Kennwerte Ausflusswelle
 -----------------------


 Endordinate Ausfluss           qaend =   0.001

 Scheitel-Ausfluss              iqmax =   1416    qmax =       1.730 [m**3/s]


 Fuelle-Ausfluss                  fuq =   0.0662 [hm**3]

 Fuelle-Ausfluss im Gerinne      fuqa =   0.0575 [hm**3]

 Fuelle-Ausfluss im vorland      fuqa =   0.0087 [hm**3]


 Scheitel-Ausfluss im Gerinne  iqamax =   1416   qamax =       1.384 [m**3/s]

 Scheitel-Ausfluss im Vorland  iqamax =   1416   qamax =       0.346 [m**3/s]


 Gesamtzuflusswelle (ohne Basisabfluss)  sqz =      220.789
 Gesamtabflusswelle    "       "         sq  =      220.789


 Keine angeschlossenen Teilgebiete an Strang      4558
 Auswertung des Stranges:         4561

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Aufruf der Speicherroutine 


 zufluss-fuelle [hm]        0.459569 speicher 4561
 zusaetzl.zufl im nachl.ast [hm]  0.000000

 speicher   0.309279 abfluss-fuelle [hm]      4561
 abfluss-fuelle [hm]  0.1534 ueberlauf 

 speicherinhaltsaenderung [hm]  0.000002
 Keine angeschlossenen Teilgebiete an Strang      4561
 Auswertung des Stranges:         4562

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Abflussverzoegerung mit Kalinin-Miljukov Parametern

 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 dt [h]:   0.08      tmax [d]:     4.82


 Kennwerte Zuflusswelle
 ----------------------

 Scheitel-Zufluss               iqzmax =   1387   qzmax =       4.052 [m**3/s]
 Scheitel-Zufluss im Gerinne    iqzfmx =   1387  qzfmax =       3.242 [m**3/s]
 Scheitel-Zufluss im Vorland    iqzvmx =   1483  qzvmax =       0.810 [m**3/s]

 Fuelle-Zufluss                   fuqz =   0.3093 [hm**3]
 Fuelle-zufluss im Gerinne       fuqzf =   0.2573 [hm**3]
 Fuelle-zufluss im Vorland       fuqzv =   0.0520 [hm**3]


 Kennwerte der Systemfunktionen
 -------------------------------

 Anzahl der Zeitschritte  ituh =    109
 Maximum u                imax =     16     umax = 0.040608
 Summe u                   suu = 0.999995   suuh = 1.000000


 tmax [d]:     5.16


 Kennwerte Ausflusswelle
 -----------------------


 Endordinate Ausfluss           qaend =   0.001

 Scheitel-Ausfluss              iqmax =   1483    qmax =       4.052 [m**3/s]


 Fuelle-Ausfluss                  fuq =   0.3093 [hm**3]

 Fuelle-Ausfluss im Gerinne      fuqa =   0.2573 [hm**3]

 Fuelle-Ausfluss im vorland      fuqa =   0.0520 [hm**3]


 Scheitel-Ausfluss im Gerinne  iqamax =   1410   qamax =       3.242 [m**3/s]

 Scheitel-Ausfluss im Vorland  iqamax =   1486   qamax =       0.810 [m**3/s]


 Gesamtzuflusswelle (ohne Basisabfluss)  sqz =     1030.949
 Gesamtabflusswelle    "       "         sq  =     1030.951


 Keine angeschlossenen Teilgebiete an Strang      4562
 Auswertung des Stranges:         4565

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Abflussverzoegerung mit Kalinin-Miljukov Parametern

 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 dt [h]:   0.08      tmax [d]:     4.95


 Kennwerte Zuflusswelle
 ----------------------

 Scheitel-Zufluss               iqzmax =   1426   qzmax =       9.863 [m**3/s]
 Scheitel-Zufluss im Gerinne    iqzfmx =   1426  qzfmax =       5.088 [m**3/s]
 Scheitel-Zufluss im Vorland    iqzvmx =   1426  qzvmax =       4.775 [m**3/s]

 Fuelle-Zufluss                   fuqz =   0.5800 [hm**3]
 Fuelle-zufluss im Gerinne       fuqzf =   0.3478 [hm**3]
 Fuelle-zufluss im Vorland       fuqzv =   0.2321 [hm**3]


 Kennwerte der Systemfunktionen
 -------------------------------

 Anzahl der Zeitschritte  ituh =     95
 Maximum u                imax =     24     umax = 0.042923
 Summe u                   suu = 0.999996   suuh = 1.000000


 tmax [d]:     5.05


 Kennwerte Ausflusswelle
 -----------------------


 Endordinate Ausfluss           qaend =   0.000

 Scheitel-Ausfluss              iqmax =   1443    qmax =       9.455 [m**3/s]


 Fuelle-Ausfluss                  fuq =   0.5801 [hm**3]

 Fuelle-Ausfluss im Gerinne      fuqa =   0.3476 [hm**3]

 Fuelle-Ausfluss im vorland      fuqa =   0.2325 [hm**3]


 Scheitel-Ausfluss im Gerinne  iqamax =   1428   qamax =       5.075 [m**3/s]

 Scheitel-Ausfluss im Vorland  iqamax =   1454   qamax =       4.677 [m**3/s]


 Gesamtzuflusswelle (ohne Basisabfluss)  sqz =     1933.167
 Gesamtabflusswelle    "       "         sq  =     1933.745


 Keine angeschlossenen Teilgebiete an Strang      4565
 Auswertung des Stranges:         4569

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Abflussverzoegerung mit Kalinin-Miljukov Parametern

 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 dt [h]:   0.08      tmax [d]:     5.00


 Kennwerte Zuflusswelle
 ----------------------

 Scheitel-Zufluss               iqzmax =   1441   qzmax =       9.806 [m**3/s]
 Scheitel-Zufluss im Gerinne    iqzfmx =   1441  qzfmax =       5.036 [m**3/s]
 Scheitel-Zufluss im Vorland    iqzvmx =   1441  qzvmax =       4.769 [m**3/s]

 Fuelle-Zufluss                   fuqz =   0.6014 [hm**3]
 Fuelle-zufluss im Gerinne       fuqzf =   0.3703 [hm**3]
 Fuelle-zufluss im Vorland       fuqzv =   0.2311 [hm**3]


 Kennwerte der Systemfunktionen
 -------------------------------

 Anzahl der Zeitschritte  ituh =    113
 Maximum u                imax =     14     umax = 0.040531
 Summe u                   suu = 0.999992   suuh = 1.000000


 tmax [d]:     5.08


 Kennwerte Ausflusswelle
 -----------------------


 Endordinate Ausfluss           qaend =   0.000

 Scheitel-Ausfluss              iqmax =   1457    qmax =       9.530 [m**3/s]


 Fuelle-Ausfluss                  fuq =   0.6030 [hm**3]

 Fuelle-Ausfluss im Gerinne      fuqa =   0.3697 [hm**3]

 Fuelle-Ausfluss im vorland      fuqa =   0.2334 [hm**3]


 Scheitel-Ausfluss im Gerinne  iqamax =   1450   qamax =       4.951 [m**3/s]

 Scheitel-Ausfluss im Vorland  iqamax =   1463   qamax =       4.645 [m**3/s]


 Gesamtzuflusswelle (ohne Basisabfluss)  sqz =     2004.664
 Gesamtabflusswelle    "       "         sq  =     2010.057


 Keine angeschlossenen Teilgebiete an Strang      4569
 Auswertung des Stranges:         4584

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Fiktiver Strang! Es erfolgt keine Abflussverzoegerung!
 Keine angeschlossenen Teilgebiete an Strang      4584
 Auswertung des Stranges:         4618

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Abflussverzoegerung mit Kalinin-Miljukov Parametern

 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 dt [h]:   0.08      tmax [d]:     5.05


 Kennwerte Zuflusswelle
 ----------------------

 Scheitel-Zufluss               iqzmax =   1454   qzmax =      10.003 [m**3/s]
 Scheitel-Zufluss im Gerinne    iqzfmx =   1454  qzfmax =       5.054 [m**3/s]
 Scheitel-Zufluss im Vorland    iqzvmx =   1454  qzvmax =       4.948 [m**3/s]

 Fuelle-Zufluss                   fuqz =   0.6625 [hm**3]
 Fuelle-zufluss im Gerinne       fuqzf =   0.4320 [hm**3]
 Fuelle-zufluss im Vorland       fuqzv =   0.2305 [hm**3]


 Kennwerte der Systemfunktionen
 -------------------------------

 Anzahl der Zeitschritte  ituh =    126
 Maximum u                imax =     18     umax = 0.034861
 Summe u                   suu = 0.999994   suuh = 1.000000


 tmax [d]:     5.14


 Kennwerte Ausflusswelle
 -----------------------


 Endordinate Ausfluss           qaend =   0.001

 Scheitel-Ausfluss              iqmax =   1470    qmax =       9.613 [m**3/s]


 Fuelle-Ausfluss                  fuq =   0.6625 [hm**3]

 Fuelle-Ausfluss im Gerinne      fuqa =   0.4320 [hm**3]

 Fuelle-Ausfluss im vorland      fuqa =   0.2306 [hm**3]


 Scheitel-Ausfluss im Gerinne  iqamax =   1455   qamax =       5.050 [m**3/s]

 Scheitel-Ausfluss im Vorland  iqamax =   1481   qamax =       4.801 [m**3/s]


 Gesamtzuflusswelle (ohne Basisabfluss)  sqz =     2208.403
 Gesamtabflusswelle    "       "         sq  =     2208.483


 Keine angeschlossenen Teilgebiete an Strang      4618
 Auswertung des Stranges:         4588

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Abflussverzoegerung mit Kalinin-Miljukov Parametern

 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 dt [h]:   0.08      tmax [d]:     5.10


 Kennwerte Zuflusswelle
 ----------------------

 Scheitel-Zufluss               iqzmax =   1470   qzmax =       9.644 [m**3/s]
 Scheitel-Zufluss im Gerinne    iqzfmx =   1470  qzfmax =       4.873 [m**3/s]
 Scheitel-Zufluss im Vorland    iqzvmx =   1470  qzvmax =       4.771 [m**3/s]

 Fuelle-Zufluss                   fuqz =   0.6665 [hm**3]
 Fuelle-zufluss im Gerinne       fuqzf =   0.4345 [hm**3]
 Fuelle-zufluss im Vorland       fuqzv =   0.2320 [hm**3]


 Kennwerte der Systemfunktionen
 -------------------------------

 Anzahl der Zeitschritte  ituh =    126
 Maximum u                imax =     18     umax = 0.034861
 Summe u                   suu = 0.999994   suuh = 1.000000


 tmax [d]:     5.19


 Kennwerte Ausflusswelle
 -----------------------


 Endordinate Ausfluss           qaend =   0.001

 Scheitel-Ausfluss              iqmax =   1484    qmax =       9.326 [m**3/s]


 Fuelle-Ausfluss                  fuq =   0.6665 [hm**3]

 Fuelle-Ausfluss im Gerinne      fuqa =   0.4345 [hm**3]

 Fuelle-Ausfluss im vorland      fuqa =   0.2320 [hm**3]


 Scheitel-Ausfluss im Gerinne  iqamax =   1470   qamax =       4.871 [m**3/s]

 Scheitel-Ausfluss im Vorland  iqamax =   1495   qamax =       4.651 [m**3/s]


 Gesamtzuflusswelle (ohne Basisabfluss)  sqz =     2221.640
 Gesamtabflusswelle    "       "         sq  =     2221.719


 Keine angeschlossenen Teilgebiete an Strang      4588
 Auswertung des Stranges:         1070

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4593

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    2.97

 gesamtmenge an niederschlag (mm):      106.0

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:    126


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  8.000


vers. flaeche  =      0.17
natur. flaeche =      0.86
gesamtflaeche  =      1.02




-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4593
 anzahl hydrotope:     126


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)     106.0 mm
 interz.verd.:                       7.5 mm
 bestandsniederschlag:              96.6 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      16.0 mm
 aktuelle verdunstung:              10.9 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              96.6 mm
 overlandflow:                       8.1 mm
 [infiltration:                     88.4 mm]
 kapilarer aufstieg:                 0.0 mm
 verdunstung (bodensp.):             3.4 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.1 mm
 differenz bodenspeicher:          -84.9 mm
 fehler:                             0.0 mm



 aufteilung perkolation: 

 perkolation bodenspeicher:            0.1 mm

 abgabe grundw.speicher:               0.1 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.1 mm
        grundw. oberh.l.TG:            8.5 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:          10.4 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                -1.2 mm
     pot.entnahme GWS:                -1.2 mm
 speicherinhaltsaenderung:            -0.6 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.855 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.855 qkm



 Anzahl der Zeitschritte in iso durch Nachlauf zu hoch geworden.
 Sie wird auf 460 begrenzt !  gebiet :  4593

fuellenberechnung in iso
abflusz =          6953.754
niederschlag =     6965.775
flaeche zft  =        1.000
flaeche eing.=        0.855

GEBIET: Abflusswelle Interflow:
fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.855

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV:  fuellenberechnung
ISOV: Abflusz =         14275.231
ISOV: Niederschlag =    14275.232

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1071

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4596

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    2.97

 gesamtmenge an niederschlag (mm):      106.0

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     47


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  9.700


vers. flaeche  =      0.05
natur. flaeche =      0.20
gesamtflaeche  =      0.25




-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4596
 anzahl hydrotope:      47


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)     106.0 mm
 interz.verd.:                       7.4 mm
 bestandsniederschlag:              96.6 mm
 differenz interz.speicher:         -1.9 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      15.8 mm
 aktuelle verdunstung:              10.5 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              96.6 mm
 overlandflow:                       0.0 mm
 [infiltration:                     96.6 mm]
 kapilarer aufstieg:                 0.0 mm
 verdunstung (bodensp.):             3.1 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        1.5 mm
 differenz bodenspeicher:          -92.1 mm
 fehler:                             0.0 mm



 aufteilung perkolation: 

 perkolation bodenspeicher:            1.5 mm

 abgabe grundw.speicher:               1.5 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  1.5 mm
        grundw. oberh.l.TG:           72.7 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:          77.9 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -3.8 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.198 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.198 qkm



 Anzahl der Zeitschritte in iso durch Nachlauf zu hoch geworden.
 Sie wird auf 460 begrenzt !  gebiet :  4596

fuellenberechnung in iso
abflusz =             5.051
niederschlag =        5.060
flaeche zft  =        1.000
flaeche eing.=        0.198

GEBIET: Abflusswelle Interflow:
fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.198

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV:  fuellenberechnung
ISOV: Abflusz =          3991.105
ISOV: Niederschlag =     3991.101

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1072

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4591

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    2.97

 gesamtmenge an niederschlag (mm):      106.0

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     85


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  4.000


vers. flaeche  =      0.08
natur. flaeche =      0.38
gesamtflaeche  =      0.46




-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4591
 anzahl hydrotope:      85


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)     106.0 mm
 interz.verd.:                       7.5 mm
 bestandsniederschlag:              96.6 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      16.1 mm
 aktuelle verdunstung:              10.9 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              96.6 mm
 overlandflow:                       5.5 mm
 [infiltration:                     91.1 mm]
 kapilarer aufstieg:                 0.0 mm
 verdunstung (bodensp.):             3.4 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.2 mm
 differenz bodenspeicher:          -87.4 mm
 fehler:                             0.0 mm



 aufteilung perkolation: 

 perkolation bodenspeicher:            0.2 mm

 abgabe grundw.speicher:               0.2 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.2 mm
        grundw. oberh.l.TG:            0.0 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:           1.6 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                -1.5 mm
     pot.entnahme GWS:                -1.5 mm
 speicherinhaltsaenderung:             0.0 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.379 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.379 qkm



 Anzahl der Zeitschritte in iso durch Nachlauf zu hoch geworden.
 Sie wird auf 460 begrenzt !  gebiet :  4591

fuellenberechnung in iso
abflusz =          2081.489
niederschlag =     2085.084
flaeche zft  =        1.000
flaeche eing.=        0.379

GEBIET: Abflusswelle Interflow:
fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.379

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV:  fuellenberechnung
ISOV: Abflusz =          6976.531
ISOV: Niederschlag =     6976.538

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1073

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4594

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    2.97

 gesamtmenge an niederschlag (mm):      106.0

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     61


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  7.500


vers. flaeche  =      0.06
natur. flaeche =      0.31
gesamtflaeche  =      0.37


 entnahme gws [qbm/s]:       0.000


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4594
 anzahl hydrotope:      61


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)     106.0 mm
 interz.verd.:                       7.5 mm
 bestandsniederschlag:              96.6 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      16.1 mm
 aktuelle verdunstung:              10.8 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              96.6 mm
 overlandflow:                       1.8 mm
 [infiltration:                     94.8 mm]
 kapilarer aufstieg:                 0.0 mm
 verdunstung (bodensp.):             3.3 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.3 mm
 differenz bodenspeicher:          -91.2 mm
 fehler:                             0.0 mm



 aufteilung perkolation: 

 perkolation bodenspeicher:            0.3 mm

 abgabe grundw.speicher:               0.3 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.3 mm
        grundw. oberh.l.TG:            4.9 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:           5.7 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.2 mm
     pot.entnahme GWS:                 0.2 mm
 speicherinhaltsaenderung:            -0.7 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.307 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.307 qkm



 Anzahl der Zeitschritte in iso durch Nachlauf zu hoch geworden.
 Sie wird auf 460 begrenzt !  gebiet :  4594

fuellenberechnung in iso
abflusz =           545.012
niederschlag =      545.954
flaeche zft  =        1.000
flaeche eing.=        0.307

GEBIET: Abflusswelle Interflow:
fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.307

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV:  fuellenberechnung
ISOV: Abflusz =          5088.203
ISOV: Niederschlag =     5088.206

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         4589

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.

 Keine angeschlossenen Teilgebiete an Strang      4589
 Auswertung des Stranges:         4590

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Aufruf der Speicherroutine 


 zufluss-fuelle [hm]        0.011678 speicher 4590
 zusaetzl.zufl im nachl.ast [hm]  0.000000

 speicher   0.012109 abfluss-fuelle [hm]      4590

 speicherinhaltsaenderung [hm]  0.000057
 Keine angeschlossenen Teilgebiete an Strang      4590
 Auswertung des Stranges:         4594

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Abflussverzoegerung mit Kalinin-Miljukov Parametern

 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 dt [h]:   0.08      tmax [d]:     4.94


 Kennwerte Zuflusswelle
 ----------------------

 Scheitel-Zufluss               iqzmax =   1423   qzmax =       0.317 [m**3/s]
 Scheitel-Zufluss im Gerinne    iqzfmx =   1423  qzfmax =       0.317 [m**3/s]
 Scheitel-Zufluss im Vorland    iqzvmx =      0  qzvmax =       0.000 [m**3/s]

 Fuelle-Zufluss                   fuqz =   0.0121 [hm**3]
 Fuelle-zufluss im Gerinne       fuqzf =   0.0121 [hm**3]
 Fuelle-zufluss im Vorland       fuqzv =   0.0000 [hm**3]


 Kennwerte der Systemfunktionen
 -------------------------------

 Anzahl der Zeitschritte  ituh =     18
 Maximum u                imax =      3     umax = 0.269426
 Summe u                   suu = 0.999998   suuh = 1.000000


 tmax [d]:     4.95


 Kennwerte Ausflusswelle
 -----------------------

 Endordinate Ausfluss           qaend =   0.000
 Scheitel-Ausfluss              iqmax =   1426    qmax =       0.316 [m**3/s]

 Fuelle-Ausfluss                  fuq =   0.0121 [hm**3]
 Fuelle-Ausfluss im Gerinne      fuqa =   0.0121 [hm**3]

 Scheitel-Ausfluss im Gerinne  iqamax =   1426   qamax =       0.316 [m**3/s]


 Gesamtzuflusswelle (ohne Basisabfluss)  sqz =       40.367
 Gesamtabflusswelle    "       "         sq  =       40.367


 Keine angeschlossenen Teilgebiete an Strang      4594
 Auswertung des Stranges:         4591

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.

 Keine angeschlossenen Teilgebiete an Strang      4591
 Auswertung des Stranges:         4592

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Aufruf der Speicherroutine 


 zufluss-fuelle [hm]        0.008774 speicher 4592
 zusaetzl.zufl im nachl.ast [hm]  0.000000

 speicher   0.009061 abfluss-fuelle [hm]      4592

 speicherinhaltsaenderung [hm]  0.000000
 Keine angeschlossenen Teilgebiete an Strang      4592
 Auswertung des Stranges:         4593

 Abflussverzoegerung mit Kalinin-Miljukov Parametern

 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 dt [h]:   0.08      tmax [d]:     4.92


 Kennwerte Zuflusswelle
 ----------------------

 Scheitel-Zufluss               iqzmax =   1418   qzmax =       0.268 [m**3/s]
 Scheitel-Zufluss im Gerinne    iqzfmx =   1418  qzfmax =       0.268 [m**3/s]
 Scheitel-Zufluss im Vorland    iqzvmx =      0  qzvmax =       0.000 [m**3/s]

 Fuelle-Zufluss                   fuqz =   0.0091 [hm**3]
 Fuelle-zufluss im Gerinne       fuqzf =   0.0091 [hm**3]
 Fuelle-zufluss im Vorland       fuqzv =   0.0000 [hm**3]


 Kennwerte der Systemfunktionen
 -------------------------------

 Anzahl der Zeitschritte  ituh =     18
 Maximum u                imax =      3     umax = 0.269426
 Summe u                   suu = 0.999998   suuh = 1.000000


 tmax [d]:     4.93


 Kennwerte Ausflusswelle
 -----------------------

 Endordinate Ausfluss           qaend =   0.000
 Scheitel-Ausfluss              iqmax =   1421    qmax =       0.267 [m**3/s]

 Fuelle-Ausfluss                  fuq =   0.0091 [hm**3]
 Fuelle-Ausfluss im Gerinne      fuqa =   0.0091 [hm**3]

 Scheitel-Ausfluss im Gerinne  iqamax =   1421   qamax =       0.267 [m**3/s]


 Gesamtzuflusswelle (ohne Basisabfluss)  sqz =       30.202
 Gesamtabflusswelle    "       "         sq  =       30.202


 Keine angeschlossenen Teilgebiete an Strang      4593
 Auswertung des Stranges:         4595

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Aufruf der Speicherroutine 


 zufluss-fuelle [hm]        0.046171 speicher 4595
 zusaetzl.zufl im nachl.ast [hm]  0.000000

 speicher   0.048034 abfluss-fuelle [hm]      4595

 speicherinhaltsaenderung [hm]  0.000004
 Keine angeschlossenen Teilgebiete an Strang      4595
 Auswertung des Stranges:         4596

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Aufruf der Speicherroutine 


 zufluss-fuelle [hm]        0.045447 speicher 4596
 zusaetzl.zufl im nachl.ast [hm]  0.000000

 speicher   0.048040 abfluss-fuelle [hm]      4596

 speicherinhaltsaenderung [hm]  0.000001
 Keine angeschlossenen Teilgebiete an Strang      4596
 Auswertung des Stranges:         4622

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Abflussverzoegerung mit Kalinin-Miljukov Parametern

 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 dt [h]:   0.08      tmax [d]:     4.92


 Kennwerte Zuflusswelle
 ----------------------

 Scheitel-Zufluss               iqzmax =   1418   qzmax =       1.470 [m**3/s]
 Scheitel-Zufluss im Gerinne    iqzfmx =   1418  qzfmax =       1.470 [m**3/s]
 Scheitel-Zufluss im Vorland    iqzvmx =      0  qzvmax =       0.000 [m**3/s]

 Fuelle-Zufluss                   fuqz =   0.0520 [hm**3]
 Fuelle-zufluss im Gerinne       fuqzf =   0.0520 [hm**3]
 Fuelle-zufluss im Vorland       fuqzv =   0.0000 [hm**3]


 Kennwerte der Systemfunktionen
 -------------------------------

 Anzahl der Zeitschritte  ituh =   2880
 Maximum u                imax =     18     umax = 0.000000
 Summe u                   suu = 0.000000   suuh = 0.000000


 tmax [d]:     0.00


 Kennwerte Ausflusswelle
 -----------------------


 Endordinate Ausfluss           qaend =   0.001

 Scheitel-Ausfluss              iqmax =   1422    qmax =       1.467 [m**3/s]


 Fuelle-Ausfluss                  fuq =   0.0520 [hm**3]

 Fuelle-Ausfluss im Gerinne      fuqa =   0.0520 [hm**3]

 Fuelle-Ausfluss im vorland      fuqa =   0.0000 [hm**3]


 Scheitel-Ausfluss im Gerinne  iqamax =   1422   qamax =       1.467 [m**3/s]

 Scheitel-Ausfluss im Vorland  iqamax =      0   qamax =       0.000 [m**3/s]


 Gesamtzuflusswelle (ohne Basisabfluss)  sqz =      173.466
 Gesamtabflusswelle    "       "         sq  =      173.466


 Keine angeschlossenen Teilgebiete an Strang      4622
 Auswertung des Stranges:         1074

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4598

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    2.97

 gesamtmenge an niederschlag (mm):      106.0

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     54


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  6.000


vers. flaeche  =      0.02
natur. flaeche =      0.11
gesamtflaeche  =      0.13


 entnahme gws [qbm/s]:       0.000


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4598
 anzahl hydrotope:      54


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)     106.0 mm
 interz.verd.:                       7.7 mm
 bestandsniederschlag:              96.2 mm
 differenz interz.speicher:         -2.1 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      16.0 mm
 aktuelle verdunstung:              11.1 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              96.2 mm
 overlandflow:                       2.9 mm
 [infiltration:                     93.3 mm]
 kapilarer aufstieg:                 0.0 mm
 verdunstung (bodensp.):             3.4 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.1 mm
 differenz bodenspeicher:          -89.8 mm
 fehler:                             0.0 mm



 aufteilung perkolation: 

 perkolation bodenspeicher:            0.1 mm

 abgabe grundw.speicher:               0.1 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.1 mm
        grundw. oberh.l.TG:          200.6 mm
 abgabe basisabfluss:                 59.4 mm
        grundw. unterh.l.TG:         140.7 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.5 mm
     pot.entnahme GWS:                 0.5 mm
 speicherinhaltsaenderung:             0.1 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.110 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.110 qkm



 Anzahl der Zeitschritte in iso durch Nachlauf zu hoch geworden.
 Sie wird auf 460 begrenzt !  gebiet :  4598

fuellenberechnung in iso
abflusz =           318.315
niederschlag =      318.865
flaeche zft  =        1.000
flaeche eing.=        0.110

GEBIET: Abflusswelle Interflow:
fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.110

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV:  fuellenberechnung
ISOV: Abflusz =          1649.473
ISOV: Niederschlag =     1649.472

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1075

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4597

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    2.97

 gesamtmenge an niederschlag (mm):      106.0

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     84


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  7.000


vers. flaeche  =      0.08
natur. flaeche =      0.27
gesamtflaeche  =      0.35


 entnahme gws [qbm/s]:       0.000


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4597
 anzahl hydrotope:      84


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)     106.0 mm
 interz.verd.:                       7.4 mm
 bestandsniederschlag:              96.7 mm
 differenz interz.speicher:         -1.9 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      15.8 mm
 aktuelle verdunstung:              10.8 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              96.7 mm
 overlandflow:                       2.8 mm
 [infiltration:                     93.8 mm]
 kapilarer aufstieg:                 0.0 mm
 verdunstung (bodensp.):             3.4 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        1.8 mm
 differenz bodenspeicher:          -88.7 mm
 fehler:                             0.0 mm



 aufteilung perkolation: 

 perkolation bodenspeicher:            1.8 mm

 abgabe grundw.speicher:               1.8 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  1.8 mm
        grundw. oberh.l.TG:           64.1 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:          70.4 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.4 mm
     pot.entnahme GWS:                 0.4 mm
 speicherinhaltsaenderung:            -4.9 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.268 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.268 qkm



 Anzahl der Zeitschritte in iso durch Nachlauf zu hoch geworden.
 Sie wird auf 460 begrenzt !  gebiet :  4597

fuellenberechnung in iso
abflusz =           754.660
niederschlag =      755.963
flaeche zft  =        1.000
flaeche eing.=        0.268

GEBIET: Abflusswelle Interflow:
fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.268

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV:  fuellenberechnung
ISOV: Abflusz =          6596.618
ISOV: Niederschlag =     6596.613

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1076

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4599

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    2.97

 gesamtmenge an niederschlag (mm):      106.0

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     27


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 = 20.100


vers. flaeche  =      0.01
natur. flaeche =      0.03
gesamtflaeche  =      0.03


 entnahme gws [qbm/s]:       0.000


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4599
 anzahl hydrotope:      27


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)     106.0 mm
 interz.verd.:                       7.5 mm
 bestandsniederschlag:              96.6 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      16.2 mm
 aktuelle verdunstung:              11.9 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              96.6 mm
 overlandflow:                      15.3 mm
 [infiltration:                     81.2 mm]
 kapilarer aufstieg:                 0.0 mm
 verdunstung (bodensp.):             4.4 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.3 mm
 differenz bodenspeicher:          -76.5 mm
 fehler:                             0.0 mm



 aufteilung perkolation: 

 perkolation bodenspeicher:            0.3 mm

 abgabe grundw.speicher:               0.3 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.3 mm
        grundw. oberh.l.TG:         1321.9 mm
 abgabe basisabfluss:               1022.2 mm
        grundw. unterh.l.TG:         298.6 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 1.4 mm
     pot.entnahme GWS:                 1.4 mm
 speicherinhaltsaenderung:             0.0 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.026 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.026 qkm



 Anzahl der Zeitschritte in iso durch Nachlauf zu hoch geworden.
 Sie wird auf 460 begrenzt !  gebiet :  4599

fuellenberechnung in iso
abflusz =           398.478
niederschlag =      399.166
flaeche zft  =        1.000
flaeche eing.=        0.026

GEBIET: Abflusswelle Interflow:
fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.026

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV:  fuellenberechnung
ISOV: Abflusz =           693.683
ISOV: Niederschlag =      693.684

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         4597

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Abflussverzoegerung mit Kalinin-Miljukov Parametern

 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 dt [h]:   0.08      tmax [d]:     5.15


 Kennwerte Zuflusswelle
 ----------------------

 Scheitel-Zufluss               iqzmax =   1484   qzmax =       9.345 [m**3/s]
 Scheitel-Zufluss im Gerinne    iqzfmx =   1484  qzfmax =       5.240 [m**3/s]
 Scheitel-Zufluss im Vorland    iqzvmx =   1484  qzvmax =       4.106 [m**3/s]

 Fuelle-Zufluss                   fuqz =   0.6703 [hm**3]
 Fuelle-zufluss im Gerinne       fuqzf =   0.4516 [hm**3]
 Fuelle-zufluss im Vorland       fuqzv =   0.2187 [hm**3]


 Kennwerte der Systemfunktionen
 -------------------------------

 Anzahl der Zeitschritte  ituh =      9
 Maximum u                imax =      1     umax = 0.725271
 Summe u                   suu = 1.005751   suuh = 1.000000


 tmax [d]:     5.15


 Kennwerte Ausflusswelle
 -----------------------


 Endordinate Ausfluss           qaend =   0.002

 Scheitel-Ausfluss              iqmax =   1485    qmax =       9.344 [m**3/s]


 Fuelle-Ausfluss                  fuq =   0.6703 [hm**3]

 Fuelle-Ausfluss im Gerinne      fuqa =   0.4516 [hm**3]

 Fuelle-Ausfluss im vorland      fuqa =   0.2187 [hm**3]


 Scheitel-Ausfluss im Gerinne  iqamax =   1485   qamax =       5.238 [m**3/s]

 Scheitel-Ausfluss im Vorland  iqamax =   1484   qamax =       4.106 [m**3/s]


 Gesamtzuflusswelle (ohne Basisabfluss)  sqz =     2234.273
 Gesamtabflusswelle    "       "         sq  =     2234.271


 Keine angeschlossenen Teilgebiete an Strang      4597
 Auswertung des Stranges:         4598

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Abflussverzoegerung mit Kalinin-Miljukov Parametern

 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 dt [h]:   0.08      tmax [d]:     5.14


 Kennwerte Zuflusswelle
 ----------------------

 Scheitel-Zufluss               iqzmax =   1479   qzmax =       9.887 [m**3/s]
 Scheitel-Zufluss im Gerinne    iqzfmx =   1479  qzfmax =       6.856 [m**3/s]
 Scheitel-Zufluss im Vorland    iqzvmx =   1479  qzvmax =       3.031 [m**3/s]

 Fuelle-Zufluss                   fuqz =   0.7382 [hm**3]
 Fuelle-zufluss im Gerinne       fuqzf =   0.5537 [hm**3]
 Fuelle-zufluss im Vorland       fuqzv =   0.1845 [hm**3]


 Kennwerte der Systemfunktionen
 -------------------------------

 Anzahl der Zeitschritte  ituh =     16
 Maximum u                imax =      1     umax = 0.517926
 Summe u                   suu = 0.610857   suuh = 0.999798


 tmax [d]:     5.14


 Kennwerte Ausflusswelle
 -----------------------


 Endordinate Ausfluss           qaend =   0.000

 Scheitel-Ausfluss              iqmax =   1479    qmax =       9.885 [m**3/s]


 Fuelle-Ausfluss                  fuq =   0.7382 [hm**3]

 Fuelle-Ausfluss im Gerinne      fuqa =   0.5537 [hm**3]

 Fuelle-Ausfluss im vorland      fuqa =   0.1845 [hm**3]


 Scheitel-Ausfluss im Gerinne  iqamax =   1479   qamax =       6.854 [m**3/s]

 Scheitel-Ausfluss im Vorland  iqamax =   1479   qamax =       3.030 [m**3/s]


 Gesamtzuflusswelle (ohne Basisabfluss)  sqz =     2460.748
 Gesamtabflusswelle    "       "         sq  =     2460.649


 Keine angeschlossenen Teilgebiete an Strang      4598
 Auswertung des Stranges:         4599

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Fiktiver Strang! Es erfolgt keine Abflussverzoegerung!
 Keine angeschlossenen Teilgebiete an Strang      4599
 Auswertung des Stranges:        10002

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Fiktiver Strang! Es erfolgt keine Abflussverzoegerung!
 Keine angeschlossenen Teilgebiete an Strang     10002


 ------------------------------------------------------------------
           Berechnung wurde ohne Fehler beendet!                   
 ------------------------------------------------------------------
