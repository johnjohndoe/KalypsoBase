



          *****************************************************
          *****************************************************
          ****                                             ****
          ****      HAMBURG UNIVERSITY OF TECHNOLOGY       ****
          ****                                             ****
          **** Department of River and Coastal Engineering ****
          ****                                             ****
          ****                                             ****
          ****            K A L Y P S O - N A              ****
          ****                                             ****
          ****                                             ****
          ****           Rainfall-Runoff-Model             ****
          ****                                             ****
          ****                                             ****
          ****                                             ****
          ****     VERS.  2.0.5      STATUS: 18.04.2006    ****
          ****                                             ****
          ****                                             ****
          ****     Contact:          Dipl.-Ing J. H�bsch   ****
          ****                       j.huebsch@tuhh.de     ****
          *****************************************************
          *****************************************************




 Bearbeitung Fall / Berechnungseinstellungen aus Steuerungsdatei:
 ----------------------------------------------------------------
 2 .. we nat  1996 08 24 00 1996 08 30 23 start\we_nat_start.txt                                                         


 Anzahl der Straenge in der Netzdatei:    182

 Anzahl der Teilgebiete in der Netzdatei:  77



 K U R Z Z E I T S I M U L A T I O N
 Zyklus (iz):                         1
 Anfangsdatum Zyklus (idatsa):   960824
 Enddatum Zyklus (idatse):       960830
 Zeitschritte (idif):              2005


 ************************************************************************************
 *  Neuer Jahreszyklus                                                              *
 *      Jahr:    1996                                                              *
 *      Zyklus:     1                                                              *
 ************************************************************************************
 Auswertung des Stranges:         1000

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4503

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    2.16

 gesamtmenge an niederschlag (mm):       77.1

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     63


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  1.000


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4503
 anzahl hydrotope:      63


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      77.1 mm
 interz.verd.:                       7.2 mm
 bestandsniederschlag:              67.8 mm
 differenz interz.speicher:         -2.1 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      15.5 mm
 aktuelle verdunstung:              10.1 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              67.8 mm
 overlandflow:                       2.3 mm
 [infiltration:                     65.5 mm]
 verdunstung (bodensp.):             3.0 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -62.5 mm
 fehler:                             0.0 mm


 0.00000000E+00  -> zufluss grundwasserleiter in  4503
TG:    4503 -> TG:    4500
Prozent:0.20

TG:    4503 -> TG:    4501
Prozent:0.10

TG:    4503 -> TG:    4506
Prozent:0.20

TG:    4503 -> TG:    4504
Prozent:0.50


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:            0.0 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:           2.0 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                -0.9 mm
     pot.entnahme GWS:                -0.9 mm
 speicherinhaltsaenderung:            -1.1 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.872 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.872 qkm


fuellenberechnung in iso
abflusz =          2035.620
niederschlag =     2035.620
flaeche zft  =        1.000
flaeche eing.=        0.872

GEBIET: Abflusswelle Interflow:

 Anzahl der Zeitschritte in iso durch Nachlauf zu hoch geworden.
 Sie wird auf 460 begrenzt !  gebiet :  4503

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.872

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV:  fuellenberechnung
ISOV: Abflusz =          4650.031
ISOV: Niederschlag =     4650.040

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1001

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4501

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    2.16

 gesamtmenge an niederschlag (mm):       77.1

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     18


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  1.000


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4501
 anzahl hydrotope:      18


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      77.1 mm
 interz.verd.:                       7.1 mm
 bestandsniederschlag:              68.0 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      15.7 mm
 aktuelle verdunstung:              11.8 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              68.0 mm
 overlandflow:                      35.3 mm
 [infiltration:                     32.8 mm]
 verdunstung (bodensp.):             4.8 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -28.0 mm
 fehler:                             0.0 mm


 0.578505874  -> zufluss grundwasserleiter in  4501
TG:    4501 -> TG:    4502
Prozent:0.80

TG:    4501 -> TG:    4506
Prozent:0.20


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:            1.5 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:           2.4 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -0.9 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.115 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.115 qkm


fuellenberechnung in iso
abflusz =          4044.849
niederschlag =     4044.848
flaeche zft  =        1.000
flaeche eing.=        0.115

GEBIET: Abflusswelle Interflow:

 Anzahl der Zeitschritte in iso durch Nachlauf zu hoch geworden.
 Sie wird auf 460 begrenzt !  gebiet :  4501

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.115

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV:  fuellenberechnung
ISOV: Abflusz =           180.380
ISOV: Niederschlag =      180.380

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1002

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4506

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    2.16

 gesamtmenge an niederschlag (mm):       77.1

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     16


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  1.000


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4506
 anzahl hydrotope:      16


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      77.1 mm
 interz.verd.:                       7.0 mm
 bestandsniederschlag:              68.1 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      15.5 mm
 aktuelle verdunstung:              11.7 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              68.1 mm
 overlandflow:                      35.4 mm
 [infiltration:                     32.8 mm]
 verdunstung (bodensp.):             4.7 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -28.1 mm
 fehler:                             0.0 mm


 1.33825564  -> zufluss grundwasserleiter in  4506
TG:    4506 -> TG:    4510
Prozent:1.00


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:            2.1 mm
 abgabe basisabfluss:                  0.1 mm
        grundw. unterh.l.TG:           2.8 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -0.9 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.196 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.196 qkm



 Anzahl der Zeitschritte in iso durch Nachlauf zu hoch geworden.
 Sie wird auf 460 begrenzt !  gebiet :  4506

fuellenberechnung in iso
abflusz =          6925.603
niederschlag =     6925.806
flaeche zft  =        1.000
flaeche eing.=        0.196

GEBIET: Abflusswelle Interflow:

 Anzahl der Zeitschritte in iso durch Nachlauf zu hoch geworden.
 Sie wird auf 460 begrenzt !  gebiet :  4506

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.196

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV:  fuellenberechnung
ISOV: Abflusz =            77.852
ISOV: Niederschlag =       77.852

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1003

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4504

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    2.16

 gesamtmenge an niederschlag (mm):       77.1

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     86


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  1.250


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4504
 anzahl hydrotope:      86


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      77.1 mm
 interz.verd.:                       7.1 mm
 bestandsniederschlag:              68.1 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      16.0 mm
 aktuelle verdunstung:              10.7 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              68.1 mm
 overlandflow:                      16.8 mm
 [infiltration:                     51.3 mm]
 verdunstung (bodensp.):             3.7 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -47.6 mm
 fehler:                             0.0 mm


 2.89252853  -> zufluss grundwasserleiter in  4504
TG:    4504 -> TG:    4510
Prozent:0.20

TG:    4504 -> TG:    4509
Prozent:0.80


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:            1.4 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:           2.6 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -1.2 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.621 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.621 qkm



 Anzahl der Zeitschritte in iso durch Nachlauf zu hoch geworden.
 Sie wird auf 460 begrenzt !  gebiet :  4504

fuellenberechnung in iso
abflusz =         10410.177
niederschlag =    10410.338
flaeche zft  =        1.000
flaeche eing.=        0.621

GEBIET: Abflusswelle Interflow:

 Anzahl der Zeitschritte in iso durch Nachlauf zu hoch geworden.
 Sie wird auf 460 begrenzt !  gebiet :  4504

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.621

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV:  fuellenberechnung
ISOV: Abflusz =          7081.896
ISOV: Niederschlag =     7081.902

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1004

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4510

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    2.16

 gesamtmenge an niederschlag (mm):       77.1

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:    106


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  1.500


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4510
 anzahl hydrotope:     106


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      77.1 mm
 interz.verd.:                       7.1 mm
 bestandsniederschlag:              68.1 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      15.9 mm
 aktuelle verdunstung:              10.6 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              68.1 mm
 overlandflow:                       3.8 mm
 [infiltration:                     64.3 mm]
 verdunstung (bodensp.):             3.6 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -60.7 mm
 fehler:                             0.0 mm


 2.91539073  -> zufluss grundwasserleiter in  4510
TG:    4510 -> TG:    4511
Prozent:0.20

TG:    4510 -> TG:    4526
Prozent:0.80


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:            1.8 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:           5.7 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -3.9 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.478 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.478 qkm



 Anzahl der Zeitschritte in iso durch Nachlauf zu hoch geworden.
 Sie wird auf 460 begrenzt !  gebiet :  4510

fuellenberechnung in iso
abflusz =          1814.505
niederschlag =     1817.639
flaeche zft  =        1.000
flaeche eing.=        0.478

GEBIET: Abflusswelle Interflow:
fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.478

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV:  fuellenberechnung
ISOV: Abflusz =          5267.246
ISOV: Niederschlag =     5267.243

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1005

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4502

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    2.16

 gesamtmenge an niederschlag (mm):       77.1

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     77


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  1.000


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4502
 anzahl hydrotope:      77


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      77.1 mm
 interz.verd.:                       7.0 mm
 bestandsniederschlag:              68.1 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      15.5 mm
 aktuelle verdunstung:              10.2 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              68.1 mm
 overlandflow:                       6.0 mm
 [infiltration:                     62.1 mm]
 verdunstung (bodensp.):             3.2 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -58.9 mm
 fehler:                             0.0 mm


 0.724975348  -> zufluss grundwasserleiter in  4502
TG:    4502 -> TG:    4520
Prozent:0.40

TG:    4502 -> TG:    4523
Prozent:0.60


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:            0.5 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:           1.8 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -1.2 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.413 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.413 qkm


fuellenberechnung in iso
abflusz =          2489.382
niederschlag =     2489.385
flaeche zft  =        1.000
flaeche eing.=        0.413

GEBIET: Abflusswelle Interflow:

 Anzahl der Zeitschritte in iso durch Nachlauf zu hoch geworden.
 Sie wird auf 460 begrenzt !  gebiet :  4502

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.413

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV:  fuellenberechnung
ISOV: Abflusz =          7046.991
ISOV: Niederschlag =     7046.988

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1006

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4500

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    2.16

 gesamtmenge an niederschlag (mm):       77.1

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:    125


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  1.000


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4500
 anzahl hydrotope:     125


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      77.1 mm
 interz.verd.:                       7.1 mm
 bestandsniederschlag:              68.1 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      15.9 mm
 aktuelle verdunstung:              10.4 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              68.1 mm
 overlandflow:                       6.2 mm
 [infiltration:                     61.8 mm]
 verdunstung (bodensp.):             3.3 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -58.5 mm
 fehler:                             0.0 mm


 1.15701175  -> zufluss grundwasserleiter in  4500
TG:    4500 -> TG:    4516
Prozent:0.60

TG:    4500 -> TG:    4520
Prozent:0.40


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:            0.4 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:           2.2 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                -0.9 mm
     pot.entnahme GWS:                -0.9 mm
 speicherinhaltsaenderung:            -1.0 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.933 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.933 qkm


fuellenberechnung in iso
abflusz =          5798.696
niederschlag =     5798.707
flaeche zft  =        1.000
flaeche eing.=        0.933

GEBIET: Abflusswelle Interflow:

 Anzahl der Zeitschritte in iso durch Nachlauf zu hoch geworden.
 Sie wird auf 460 begrenzt !  gebiet :  4500

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.933

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV:  fuellenberechnung
ISOV: Abflusz =         13062.092
ISOV: Niederschlag =    13062.094

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1007

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4512

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    2.16

 gesamtmenge an niederschlag (mm):       77.1

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     33


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  3.800


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4512
 anzahl hydrotope:      33


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      77.1 mm
 interz.verd.:                       7.1 mm
 bestandsniederschlag:              68.1 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      16.1 mm
 aktuelle verdunstung:              10.2 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              68.1 mm
 overlandflow:                       0.0 mm
 [infiltration:                     68.1 mm]
 verdunstung (bodensp.):             3.1 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -65.0 mm
 fehler:                             0.0 mm


 entnahme gws [qbm/s]:       0.001
 0.00000000E+00  -> zufluss grundwasserleiter in  4512
TG:    4512 -> TG:    4513
Prozent:0.10

TG:    4512 -> TG:    4514
Prozent:0.90


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:            0.0 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:           1.9 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 1.0 mm
     pot.entnahme GWS:                 1.0 mm
 speicherinhaltsaenderung:            -2.9 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.408 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.408 qkm



 Anzahl der Zeitschritte in iso durch Nachlauf zu hoch geworden.
 Sie wird auf 460 begrenzt !  gebiet :  4512

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.408

GEBIET: Abflusswelle Interflow:
fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.408

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV:  fuellenberechnung
ISOV: Abflusz =          5083.834
ISOV: Niederschlag =     5083.840

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1008

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4513

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    2.16

 gesamtmenge an niederschlag (mm):       77.1

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     13


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  2.300


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4513
 anzahl hydrotope:      13


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      77.1 mm
 interz.verd.:                       7.0 mm
 bestandsniederschlag:              68.1 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      15.9 mm
 aktuelle verdunstung:              10.1 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              68.1 mm
 overlandflow:                       0.0 mm
 [infiltration:                     68.1 mm]
 verdunstung (bodensp.):             3.1 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -65.1 mm
 fehler:                             0.0 mm


 entnahme gws [qbm/s]:       0.000
 0.258711159  -> zufluss grundwasserleiter in  4513
TG:    4513 -> TG:    4516
Prozent:1.00


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:            0.4 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:           3.4 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.2 mm
     pot.entnahme GWS:                 0.2 mm
 speicherinhaltsaenderung:            -3.2 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.207 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.207 qkm



 Anzahl der Zeitschritte in iso durch Nachlauf zu hoch geworden.
 Sie wird auf 460 begrenzt !  gebiet :  4513

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.207

GEBIET: Abflusswelle Interflow:
fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.207

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV:  fuellenberechnung
ISOV: Abflusz =          2295.347
ISOV: Niederschlag =     2295.347

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1009

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4516

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    2.16

 gesamtmenge an niederschlag (mm):       77.1

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     38


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  8.000


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4516
 anzahl hydrotope:      38


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      77.1 mm
 interz.verd.:                       7.1 mm
 bestandsniederschlag:              68.1 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      16.1 mm
 aktuelle verdunstung:              10.2 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              68.1 mm
 overlandflow:                       0.0 mm
 [infiltration:                     68.1 mm]
 verdunstung (bodensp.):             3.1 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -65.0 mm
 fehler:                             0.0 mm


 6.48652458  -> zufluss grundwasserleiter in  4516
TG:    4516 -> TG:    4519
Prozent:0.65

TG:    4516 -> TG:    4520
Prozent:0.35


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:            4.5 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:          10.3 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -5.7 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.429 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.429 qkm



 Anzahl der Zeitschritte in iso durch Nachlauf zu hoch geworden.
 Sie wird auf 460 begrenzt !  gebiet :  4516

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.429

GEBIET: Abflusswelle Interflow:
fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.429

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV:  fuellenberechnung
ISOV: Abflusz =          4778.970
ISOV: Niederschlag =     4778.970

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1010

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4520

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    2.16

 gesamtmenge an niederschlag (mm):       77.1

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     47


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  5.000


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4520
 anzahl hydrotope:      47


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      77.1 mm
 interz.verd.:                       7.1 mm
 bestandsniederschlag:              68.1 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      16.1 mm
 aktuelle verdunstung:              10.2 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              68.1 mm
 overlandflow:                       0.0 mm
 [infiltration:                     68.0 mm]
 verdunstung (bodensp.):             3.1 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -64.9 mm
 fehler:                             0.0 mm


 8.86861038  -> zufluss grundwasserleiter in  4520
TG:    4520 -> TG:    4522
Prozent:0.10

TG:    4520 -> TG:    4524
Prozent:0.75

TG:    4520 -> TG:    4523
Prozent:0.15


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:            6.6 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:          13.2 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -6.6 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.404 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.404 qkm



 Anzahl der Zeitschritte in iso durch Nachlauf zu hoch geworden.
 Sie wird auf 460 begrenzt !  gebiet :  4520

fuellenberechnung in iso
abflusz =            19.689
niederschlag =       19.723
flaeche zft  =        1.000
flaeche eing.=        0.404

GEBIET: Abflusswelle Interflow:
fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.404

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV:  fuellenberechnung
ISOV: Abflusz =          4685.264
ISOV: Niederschlag =     4685.263

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1011

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4523

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    2.16

 gesamtmenge an niederschlag (mm):       77.1

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     66


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  2.500


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4523
 anzahl hydrotope:      66


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      77.1 mm
 interz.verd.:                       7.1 mm
 bestandsniederschlag:              67.9 mm
 differenz interz.speicher:         -2.1 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      15.5 mm
 aktuelle verdunstung:              10.2 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              67.9 mm
 overlandflow:                       0.8 mm
 [infiltration:                     67.1 mm]
 verdunstung (bodensp.):             3.1 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -64.0 mm
 fehler:                             0.0 mm


 4.11862183  -> zufluss grundwasserleiter in  4523
TG:    4523 -> TG:    4526
Prozent:0.10

TG:    4523 -> TG:    4524
Prozent:0.90


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:            3.0 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:           7.6 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -4.6 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.416 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.416 qkm



 Anzahl der Zeitschritte in iso durch Nachlauf zu hoch geworden.
 Sie wird auf 460 begrenzt !  gebiet :  4523

fuellenberechnung in iso
abflusz =           352.521
niederschlag =      353.131
flaeche zft  =        1.000
flaeche eing.=        0.416

GEBIET: Abflusswelle Interflow:
fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.416

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV:  fuellenberechnung
ISOV: Abflusz =          3725.746
ISOV: Niederschlag =     3725.743

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1012

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4526

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    2.16

 gesamtmenge an niederschlag (mm):       77.1

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     86


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  1.000


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4526
 anzahl hydrotope:      86


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      77.1 mm
 interz.verd.:                       7.2 mm
 bestandsniederschlag:              67.8 mm
 differenz interz.speicher:         -2.1 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      15.8 mm
 aktuelle verdunstung:              10.8 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              67.8 mm
 overlandflow:                       3.9 mm
 [infiltration:                     63.9 mm]
 verdunstung (bodensp.):             3.6 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -60.3 mm
 fehler:                             0.0 mm


 8.32501698  -> zufluss grundwasserleiter in  4526
TG:    4526 -> TG:    4532
Prozent:0.50

TG:    4526 -> TG:    4566
Prozent:0.20

TG:    4526 -> TG:    4567
Prozent:0.30


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:            4.1 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:           9.1 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -5.0 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.608 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.608 qkm



 Anzahl der Zeitschritte in iso durch Nachlauf zu hoch geworden.
 Sie wird auf 460 begrenzt !  gebiet :  4526

fuellenberechnung in iso
abflusz =          2358.979
niederschlag =     2363.055
flaeche zft  =        1.000
flaeche eing.=        0.608

GEBIET: Abflusswelle Interflow:
fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.608

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV:  fuellenberechnung
ISOV: Abflusz =          4621.043
ISOV: Niederschlag =     4621.045

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1013

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4514

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    2.16

 gesamtmenge an niederschlag (mm):       77.1

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     96


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  8.000


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4514
 anzahl hydrotope:      96


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      77.1 mm
 interz.verd.:                       7.1 mm
 bestandsniederschlag:              68.1 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      16.1 mm
 aktuelle verdunstung:              10.2 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              68.1 mm
 overlandflow:                       0.6 mm
 [infiltration:                     67.5 mm]
 verdunstung (bodensp.):             3.2 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -64.4 mm
 fehler:                             0.0 mm


 2.32840085  -> zufluss grundwasserleiter in  4514
TG:    4514 -> TG:    4515
Prozent:0.15

TG:    4514 -> TG:    4518
Prozent:0.20

TG:    4514 -> TG:    4519
Prozent:0.65


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:            1.0 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:           5.3 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -4.3 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.701 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.701 qkm



 Anzahl der Zeitschritte in iso durch Nachlauf zu hoch geworden.
 Sie wird auf 460 begrenzt !  gebiet :  4514

fuellenberechnung in iso
abflusz =           388.876
niederschlag =      389.548
flaeche zft  =        1.000
flaeche eing.=        0.701

GEBIET: Abflusswelle Interflow:
fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.701

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV:  fuellenberechnung
ISOV: Abflusz =         10440.774
ISOV: Niederschlag =    10440.782

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1014

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4515

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    2.16

 gesamtmenge an niederschlag (mm):       77.1

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     23


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  8.000


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4515
 anzahl hydrotope:      23


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      77.1 mm
 interz.verd.:                       6.7 mm
 bestandsniederschlag:              68.7 mm
 differenz interz.speicher:         -1.8 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      13.7 mm
 aktuelle verdunstung:               9.2 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              68.7 mm
 overlandflow:                       1.4 mm
 [infiltration:                     67.3 mm]
 verdunstung (bodensp.):             2.5 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -64.8 mm
 fehler:                             0.0 mm


 1.85955572  -> zufluss grundwasserleiter in  4515
TG:    4515 -> TG:    4519
Prozent:1.00


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:            9.4 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:          11.2 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -1.8 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.060 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.060 qkm



 Anzahl der Zeitschritte in iso durch Nachlauf zu hoch geworden.
 Sie wird auf 460 begrenzt !  gebiet :  4515

fuellenberechnung in iso
abflusz =            83.468
niederschlag =       83.612
flaeche zft  =        1.000
flaeche eing.=        0.060

GEBIET: Abflusswelle Interflow:
fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.060

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV:  fuellenberechnung
ISOV: Abflusz =          1760.931
ISOV: Niederschlag =     1760.930

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1015

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4518

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    2.16

 gesamtmenge an niederschlag (mm):       77.1

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     15


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  2.000


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4518
 anzahl hydrotope:      15


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      77.1 mm
 interz.verd.:                       7.0 mm
 bestandsniederschlag:              68.1 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      15.6 mm
 aktuelle verdunstung:              10.0 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              68.1 mm
 overlandflow:                       0.1 mm
 [infiltration:                     68.1 mm]
 verdunstung (bodensp.):             3.0 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -65.0 mm
 fehler:                             0.0 mm


 2.47940707  -> zufluss grundwasserleiter in  4518
TG:    4518 -> TG:    4519
Prozent:1.00


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:           36.6 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:          43.2 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -6.7 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.020 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.020 qkm



 Anzahl der Zeitschritte in iso durch Nachlauf zu hoch geworden.
 Sie wird auf 460 begrenzt !  gebiet :  4518

fuellenberechnung in iso
abflusz =             1.714
niederschlag =        1.717
flaeche zft  =        1.000
flaeche eing.=        0.020

GEBIET: Abflusswelle Interflow:
fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.020

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV:  fuellenberechnung
ISOV: Abflusz =            69.463
ISOV: Niederschlag =       69.463

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1016

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4519

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    2.16

 gesamtmenge an niederschlag (mm):       77.1

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     73


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  7.000


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4519
 anzahl hydrotope:      73


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      77.1 mm
 interz.verd.:                       7.0 mm
 bestandsniederschlag:              68.2 mm
 differenz interz.speicher:         -1.9 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      15.4 mm
 aktuelle verdunstung:              10.1 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              68.2 mm
 overlandflow:                       2.2 mm
 [infiltration:                     66.0 mm]
 verdunstung (bodensp.):             3.1 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -62.8 mm
 fehler:                             0.0 mm


 22.7653999  -> zufluss grundwasserleiter in  4519
TG:    4519 -> TG:    4522
Prozent:0.60

TG:    4519 -> TG:    4527
Prozent:0.20

TG:    4519 -> TG:    4530
Prozent:0.10

TG:    4519 -> TG:    4529
Prozent:0.10


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:           25.1 mm
 abgabe basisabfluss:                  4.8 mm
        grundw. unterh.l.TG:          21.3 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -1.0 mm
 fehler:                               0.1 mm


 flaechenanteile: 

   grundwasserleiter:                0.272 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.272 qkm



 Anzahl der Zeitschritte in iso durch Nachlauf zu hoch geworden.
 Sie wird auf 460 begrenzt !  gebiet :  4519

fuellenberechnung in iso
abflusz =           609.247
niederschlag =      610.300
flaeche zft  =        1.000
flaeche eing.=        0.272

GEBIET: Abflusswelle Interflow:
fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.272

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV:  fuellenberechnung
ISOV: Abflusz =          3334.816
ISOV: Niederschlag =     3334.817

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1017

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4522

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    2.16

 gesamtmenge an niederschlag (mm):       77.1

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     19


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  5.000


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4522
 anzahl hydrotope:      19


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      77.1 mm
 interz.verd.:                       6.7 mm
 bestandsniederschlag:              68.6 mm
 differenz interz.speicher:         -1.8 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      14.0 mm
 aktuelle verdunstung:               9.5 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              68.6 mm
 overlandflow:                       5.2 mm
 [infiltration:                     63.4 mm]
 verdunstung (bodensp.):             2.8 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -60.6 mm
 fehler:                             0.0 mm


 13.3724928  -> zufluss grundwasserleiter in  4522
TG:    4522 -> TG:    4524
Prozent:0.60

TG:    4522 -> TG:    4532
Prozent:0.40


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:          111.8 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:         114.1 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -2.3 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.036 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.036 qkm



 Anzahl der Zeitschritte in iso durch Nachlauf zu hoch geworden.
 Sie wird auf 460 begrenzt !  gebiet :  4522

fuellenberechnung in iso
abflusz =           185.819
niederschlag =      186.140
flaeche zft  =        1.000
flaeche eing.=        0.036

GEBIET: Abflusswelle Interflow:
fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.036

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV:  fuellenberechnung
ISOV: Abflusz =          1070.314
ISOV: Niederschlag =     1070.314

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1018

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4524

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    2.16

 gesamtmenge an niederschlag (mm):       77.1

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     41


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 = 10.000


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4524
 anzahl hydrotope:      41


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      77.1 mm
 interz.verd.:                       7.1 mm
 bestandsniederschlag:              67.5 mm
 differenz interz.speicher:         -2.5 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      14.8 mm
 aktuelle verdunstung:              10.2 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              67.5 mm
 overlandflow:                       2.3 mm
 [infiltration:                     65.1 mm]
 verdunstung (bodensp.):             3.1 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -62.1 mm
 fehler:                             0.0 mm


 30.9619675  -> zufluss grundwasserleiter in  4524
TG:    4524 -> TG:    4532
Prozent:1.00


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:           39.7 mm
 abgabe basisabfluss:                 10.0 mm
        grundw. unterh.l.TG:          30.6 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -1.0 mm
 fehler:                               0.1 mm


 flaechenanteile: 

   grundwasserleiter:                0.234 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.234 qkm



 Anzahl der Zeitschritte in iso durch Nachlauf zu hoch geworden.
 Sie wird auf 460 begrenzt !  gebiet :  4524

fuellenberechnung in iso
abflusz =           543.590
niederschlag =      544.530
flaeche zft  =        1.000
flaeche eing.=        0.234

GEBIET: Abflusswelle Interflow:
fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.234

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV:  fuellenberechnung
ISOV: Abflusz =           464.461
ISOV: Niederschlag =      464.461

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1019

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4527

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    2.16

 gesamtmenge an niederschlag (mm):       77.1

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     14


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  1.000


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4527
 anzahl hydrotope:      14


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      77.1 mm
 interz.verd.:                       7.1 mm
 bestandsniederschlag:              68.1 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      16.1 mm
 aktuelle verdunstung:              10.7 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              68.1 mm
 overlandflow:                       5.5 mm
 [infiltration:                     62.5 mm]
 verdunstung (bodensp.):             3.7 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -58.9 mm
 fehler:                             0.0 mm


 3.86620855  -> zufluss grundwasserleiter in  4527
TG:    4527 -> TG:    4530
Prozent:0.30

TG:    4527 -> TG:    4529
Prozent:0.70


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:            7.9 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:          10.6 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -2.8 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.148 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.148 qkm



 Anzahl der Zeitschritte in iso durch Nachlauf zu hoch geworden.
 Sie wird auf 460 begrenzt !  gebiet :  4527

fuellenberechnung in iso
abflusz =           812.837
niederschlag =      814.242
flaeche zft  =        1.000
flaeche eing.=        0.148

GEBIET: Abflusswelle Interflow:
fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.148

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV:  fuellenberechnung
ISOV: Abflusz =          2122.061
ISOV: Niederschlag =     2122.060

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1020

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4530

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    2.16

 gesamtmenge an niederschlag (mm):       77.1

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     67


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  2.500


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4530
 anzahl hydrotope:      67


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      77.1 mm
 interz.verd.:                       7.1 mm
 bestandsniederschlag:              68.1 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      16.0 mm
 aktuelle verdunstung:              10.8 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              68.1 mm
 overlandflow:                       5.1 mm
 [infiltration:                     63.0 mm]
 verdunstung (bodensp.):             3.7 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -59.3 mm
 fehler:                             0.0 mm


 3.50278568  -> zufluss grundwasserleiter in  4530
TG:    4530 -> TG:    4532
Prozent:0.70

TG:    4530 -> TG:    4563
Prozent:0.30


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:            3.8 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:           7.0 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -3.1 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.275 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.275 qkm



 Anzahl der Zeitschritte in iso durch Nachlauf zu hoch geworden.
 Sie wird auf 460 begrenzt !  gebiet :  4530

fuellenberechnung in iso
abflusz =          1400.193
niederschlag =     1402.613
flaeche zft  =        1.000
flaeche eing.=        0.275

GEBIET: Abflusswelle Interflow:
fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.275

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV:  fuellenberechnung
ISOV: Abflusz =          3276.645
ISOV: Niederschlag =     3276.643

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1021

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4532

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    2.16

 gesamtmenge an niederschlag (mm):       77.1

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     85


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  8.000


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4532
 anzahl hydrotope:      85


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      77.1 mm
 interz.verd.:                       7.6 mm
 bestandsniederschlag:              66.9 mm
 differenz interz.speicher:         -2.6 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      15.6 mm
 aktuelle verdunstung:              10.8 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              66.9 mm
 overlandflow:                       3.0 mm
 [infiltration:                     64.0 mm]
 verdunstung (bodensp.):             3.2 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -60.8 mm
 fehler:                             0.0 mm


 42.9971008  -> zufluss grundwasserleiter in  4532
TG:    4532 -> TG:    4563
Prozent:0.25

TG:    4532 -> TG:    4565
Prozent:0.25

TG:    4532 -> TG:    4566
Prozent:0.50


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:            8.8 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:          12.2 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -3.4 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                1.464 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    1.464 qkm



 Anzahl der Zeitschritte in iso durch Nachlauf zu hoch geworden.
 Sie wird auf 460 begrenzt !  gebiet :  4532

fuellenberechnung in iso
abflusz =          4312.606
niederschlag =     4320.054
flaeche zft  =        1.000
flaeche eing.=        1.464

GEBIET: Abflusswelle Interflow:
fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        1.464

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV:  fuellenberechnung
ISOV: Abflusz =          1423.426
ISOV: Niederschlag =     1423.427

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1022

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4534

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    2.16

 gesamtmenge an niederschlag (mm):       77.1

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     32


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  0.900
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  2.200


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4534
 anzahl hydrotope:      32


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      77.1 mm
 interz.verd.:                       7.1 mm
 bestandsniederschlag:              68.0 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      16.0 mm
 aktuelle verdunstung:               9.8 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              68.0 mm
 overlandflow:                      10.4 mm
 [infiltration:                     57.7 mm]
 verdunstung (bodensp.):             2.8 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -54.9 mm
 fehler:                             0.0 mm


 0.00000000E+00  -> zufluss grundwasserleiter in  4534
TG:    4534 -> TG:    4535
Prozent:0.50

TG:    4534 -> TG:    4542
Prozent:0.15

TG:    4534 -> TG:    4537
Prozent:0.35


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:            0.0 mm
 abgabe basisabfluss:                  1.3 mm
        grundw. unterh.l.TG:          11.9 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:               -13.2 mm
     pot.entnahme GWS:               -13.2 mm
 speicherinhaltsaenderung:             0.0 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.299 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.299 qkm


fuellenberechnung in iso
abflusz =          3097.753
niederschlag =     3097.752
flaeche zft  =        1.000
flaeche eing.=        0.299

GEBIET: Abflusswelle Interflow:
fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.299

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV:  fuellenberechnung
ISOV: Abflusz =          4772.983
ISOV: Niederschlag =     4772.986

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1023

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4542

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    2.16

 gesamtmenge an niederschlag (mm):       77.1

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     49


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  0.900
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  1.500


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4542
 anzahl hydrotope:      49


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      77.1 mm
 interz.verd.:                       7.1 mm
 bestandsniederschlag:              68.1 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      16.2 mm
 aktuelle verdunstung:               9.9 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              68.1 mm
 overlandflow:                      10.4 mm
 [infiltration:                     57.7 mm]
 verdunstung (bodensp.):             2.8 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -54.9 mm
 fehler:                             0.0 mm


 1.77442789  -> zufluss grundwasserleiter in  4542
TG:    4542 -> TG:    4543
Prozent:0.80

TG:    4542 -> TG:    4544
Prozent:0.20


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:            1.3 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:           3.4 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -2.0 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.395 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.395 qkm


fuellenberechnung in iso
abflusz =          4096.721
niederschlag =     4096.720
flaeche zft  =        1.000
flaeche eing.=        0.395

GEBIET: Abflusswelle Interflow:
fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.395

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV:  fuellenberechnung
ISOV: Abflusz =          4128.207
ISOV: Niederschlag =     4128.206

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1024

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4537

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    2.16

 gesamtmenge an niederschlag (mm):       77.1

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     19


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  0.900
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  2.700


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4537
 anzahl hydrotope:      19


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      77.1 mm
 interz.verd.:                       7.1 mm
 bestandsniederschlag:              68.1 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      16.1 mm
 aktuelle verdunstung:               9.9 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              68.1 mm
 overlandflow:                      10.4 mm
 [infiltration:                     57.7 mm]
 verdunstung (bodensp.):             2.8 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -54.9 mm
 fehler:                             0.0 mm


 4.14023304  -> zufluss grundwasserleiter in  4537
TG:    4537 -> TG:    4539
Prozent:0.90

TG:    4537 -> TG:    4543
Prozent:0.10


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:           19.5 mm
 abgabe basisabfluss:                  4.9 mm
        grundw. unterh.l.TG:          26.7 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:               -11.9 mm
     pot.entnahme GWS:               -11.9 mm
 speicherinhaltsaenderung:            -0.2 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.064 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.064 qkm


fuellenberechnung in iso
abflusz =           659.534
niederschlag =      659.534
flaeche zft  =        1.000
flaeche eing.=        0.064

GEBIET: Abflusswelle Interflow:
fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.064

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV:  fuellenberechnung
ISOV: Abflusz =           682.534
ISOV: Niederschlag =      682.534

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1025

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4543

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    2.16

 gesamtmenge an niederschlag (mm):       77.1

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     80


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  0.900
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  2.000


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4543
 anzahl hydrotope:      80


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      77.1 mm
 interz.verd.:                       7.1 mm
 bestandsniederschlag:              68.1 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      16.1 mm
 aktuelle verdunstung:               9.9 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              68.1 mm
 overlandflow:                      10.4 mm
 [infiltration:                     57.7 mm]
 verdunstung (bodensp.):             2.8 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -54.9 mm
 fehler:                             0.0 mm


 4.10210705  -> zufluss grundwasserleiter in  4543
TG:    4543 -> TG:    4544
Prozent:0.10

TG:    4543 -> TG:    4551
Prozent:0.50

TG:    4543 -> TG:    4549
Prozent:0.40


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:            1.3 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:           4.5 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -3.2 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.918 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.918 qkm


fuellenberechnung in iso
abflusz =          9530.790
niederschlag =     9530.800
flaeche zft  =        1.000
flaeche eing.=        0.918

GEBIET: Abflusswelle Interflow:
fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.918

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV:  fuellenberechnung
ISOV: Abflusz =         11242.499
ISOV: Niederschlag =    11242.504

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1026

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4549

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    2.16

 gesamtmenge an niederschlag (mm):       77.1

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     73


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  0.900
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  1.000


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4549
 anzahl hydrotope:      73


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      77.1 mm
 interz.verd.:                       7.1 mm
 bestandsniederschlag:              68.1 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      16.1 mm
 aktuelle verdunstung:               9.9 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              68.1 mm
 overlandflow:                      12.0 mm
 [infiltration:                     56.0 mm]
 verdunstung (bodensp.):             2.8 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -53.2 mm
 fehler:                             0.0 mm


 5.50954628  -> zufluss grundwasserleiter in  4549
TG:    4549 -> TG:    4551
Prozent:0.40

TG:    4549 -> TG:    4558
Prozent:0.60


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:            1.5 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:           6.1 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -4.6 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                1.076 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    1.076 qkm


fuellenberechnung in iso
abflusz =         12957.008
niederschlag =    12957.014
flaeche zft  =        1.000
flaeche eing.=        1.076

GEBIET: Abflusswelle Interflow:
fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        1.076

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV:  fuellenberechnung
ISOV: Abflusz =         12562.279
ISOV: Niederschlag =    12562.284

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1027

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4551

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    2.16

 gesamtmenge an niederschlag (mm):       77.1

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:    113


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  0.900
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  2.000


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4551
 anzahl hydrotope:     113


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      77.1 mm
 interz.verd.:                       7.1 mm
 bestandsniederschlag:              68.1 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      16.1 mm
 aktuelle verdunstung:               9.9 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              68.1 mm
 overlandflow:                      24.4 mm
 [infiltration:                     43.7 mm]
 verdunstung (bodensp.):             2.9 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -40.8 mm
 fehler:                             0.0 mm


 15.6735706  -> zufluss grundwasserleiter in  4551
TG:    4551 -> TG:    4553
Prozent:0.40

TG:    4551 -> TG:    4558
Prozent:0.30

TG:    4551 -> TG:    4552
Prozent:0.30


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:            7.3 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:          15.3 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -8.0 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.641 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.641 qkm


fuellenberechnung in iso
abflusz =         15660.488
niederschlag =    15660.482
flaeche zft  =        1.000
flaeche eing.=        0.641

GEBIET: Abflusswelle Interflow:
fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.641

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV:  fuellenberechnung
ISOV: Abflusz =          7534.526
ISOV: Niederschlag =     7534.519

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1028

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4552

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    2.16

 gesamtmenge an niederschlag (mm):       77.1

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     31


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  0.900
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  7.000


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4552
 anzahl hydrotope:      31


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      77.1 mm
 interz.verd.:                       7.0 mm
 bestandsniederschlag:              68.1 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      15.9 mm
 aktuelle verdunstung:               9.8 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              68.1 mm
 overlandflow:                      17.0 mm
 [infiltration:                     51.1 mm]
 verdunstung (bodensp.):             2.8 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -48.3 mm
 fehler:                             0.0 mm


 9.80420780  -> zufluss grundwasserleiter in  4552
TG:    4552 -> TG:    4553
Prozent:0.50

TG:    4552 -> TG:    4558
Prozent:0.50


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:           39.5 mm
 abgabe basisabfluss:                 17.7 mm
        grundw. unterh.l.TG:          22.6 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -1.0 mm
 fehler:                               0.2 mm


 flaechenanteile: 

   grundwasserleiter:                0.074 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.074 qkm


fuellenberechnung in iso
abflusz =          1268.502
niederschlag =     1268.503
flaeche zft  =        1.000
flaeche eing.=        0.074

GEBIET: Abflusswelle Interflow:
fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.074

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV:  fuellenberechnung
ISOV: Abflusz =          1299.368
ISOV: Niederschlag =     1299.368

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1029

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4553

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    2.16

 gesamtmenge an niederschlag (mm):       77.1

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     35


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  0.900
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 = 12.200


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4553
 anzahl hydrotope:      35


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      77.1 mm
 interz.verd.:                       7.0 mm
 bestandsniederschlag:              68.1 mm
 differenz interz.speicher:         -1.9 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      15.8 mm
 aktuelle verdunstung:               9.7 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              68.1 mm
 overlandflow:                      10.7 mm
 [infiltration:                     57.5 mm]
 verdunstung (bodensp.):             2.7 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -54.8 mm
 fehler:                             0.0 mm


 15.8769922  -> zufluss grundwasserleiter in  4553
TG:    4553 -> TG:    4558
Prozent:1.00


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:           79.0 mm
 abgabe basisabfluss:                 16.0 mm
        grundw. unterh.l.TG:          64.0 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -1.2 mm
 fehler:                               0.2 mm


 flaechenanteile: 

   grundwasserleiter:                0.060 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.060 qkm


fuellenberechnung in iso
abflusz =           643.014
niederschlag =      643.015
flaeche zft  =        1.000
flaeche eing.=        0.060

GEBIET: Abflusswelle Interflow:
fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.060

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV:  fuellenberechnung
ISOV: Abflusz =          1208.191
ISOV: Niederschlag =     1208.191

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1030

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4558

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    2.16

 gesamtmenge an niederschlag (mm):       77.1

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     90


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  0.900
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 = 10.000


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4558
 anzahl hydrotope:      90


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      77.1 mm
 interz.verd.:                       7.0 mm
 bestandsniederschlag:              68.1 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      15.9 mm
 aktuelle verdunstung:              10.2 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              68.1 mm
 overlandflow:                      28.3 mm
 [infiltration:                     39.8 mm]
 verdunstung (bodensp.):             3.2 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -36.7 mm
 fehler:                             0.0 mm


 38.6543007  -> zufluss grundwasserleiter in  4558
TG:    4558 -> TG:    4561
Prozent:0.50

TG:    4558 -> TG:    4564
Prozent:0.50


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:           29.0 mm
 abgabe basisabfluss:                  2.8 mm
        grundw. unterh.l.TG:          27.8 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -1.7 mm
 fehler:                               0.1 mm


 flaechenanteile: 

   grundwasserleiter:                0.400 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.400 qkm


fuellenberechnung in iso
abflusz =         11296.290
niederschlag =    11296.289
flaeche zft  =        1.000
flaeche eing.=        0.400

GEBIET: Abflusswelle Interflow:
fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.400

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV:  fuellenberechnung
ISOV: Abflusz =          3680.585
ISOV: Niederschlag =     3680.586

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1031

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4533

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    2.16

 gesamtmenge an niederschlag (mm):       77.1

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     26


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  0.900
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  0.500


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4533
 anzahl hydrotope:      26


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      77.1 mm
 interz.verd.:                       7.1 mm
 bestandsniederschlag:              68.1 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      16.1 mm
 aktuelle verdunstung:               9.9 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              68.1 mm
 overlandflow:                      10.4 mm
 [infiltration:                     57.7 mm]
 verdunstung (bodensp.):             2.8 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -54.9 mm
 fehler:                             0.0 mm


 entnahme gws [qbm/s]:       0.000
 0.00000000E+00  -> zufluss grundwasserleiter in  4533
TG:    4533 -> TG:    4535
Prozent:1.00


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:            0.0 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:           3.5 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.2 mm
     pot.entnahme GWS:                 0.2 mm
 speicherinhaltsaenderung:            -3.6 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.211 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.211 qkm



 Anzahl der Zeitschritte in iso durch Nachlauf zu hoch geworden.
 Sie wird auf 460 begrenzt !  gebiet :  4533

fuellenberechnung in iso
abflusz =          2182.149
niederschlag =     2185.919
flaeche zft  =        1.000
flaeche eing.=        0.211

GEBIET: Abflusswelle Interflow:
fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.211

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV:  fuellenberechnung
ISOV: Abflusz =          2826.555
ISOV: Niederschlag =     2826.556

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1032

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4535

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    2.16

 gesamtmenge an niederschlag (mm):       77.1

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     16


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  0.900
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  2.500


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4535
 anzahl hydrotope:      16


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      77.1 mm
 interz.verd.:                       7.3 mm
 bestandsniederschlag:              67.7 mm
 differenz interz.speicher:         -2.2 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      16.2 mm
 aktuelle verdunstung:              10.1 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              67.7 mm
 overlandflow:                      10.4 mm
 [infiltration:                     57.2 mm]
 verdunstung (bodensp.):             2.8 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -54.4 mm
 fehler:                             0.0 mm


 8.35362244  -> zufluss grundwasserleiter in  4535
TG:    4535 -> TG:    4539
Prozent:1.00


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:            9.4 mm
 abgabe basisabfluss:                  3.9 mm
        grundw. unterh.l.TG:           5.9 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -0.5 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.266 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.266 qkm


fuellenberechnung in iso
abflusz =          2774.365
niederschlag =     2774.364
flaeche zft  =        1.000
flaeche eing.=        0.266

GEBIET: Abflusswelle Interflow:
fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.266

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV:  fuellenberechnung
ISOV: Abflusz =          1088.821
ISOV: Niederschlag =     1088.821

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1033

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4539

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    2.16

 gesamtmenge an niederschlag (mm):       77.1

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     66


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  0.900
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  8.000


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4539
 anzahl hydrotope:      66


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      77.1 mm
 interz.verd.:                       8.0 mm
 bestandsniederschlag:              66.2 mm
 differenz interz.speicher:         -2.9 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      16.4 mm
 aktuelle verdunstung:              10.6 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              66.2 mm
 overlandflow:                      10.4 mm
 [infiltration:                     55.8 mm]
 verdunstung (bodensp.):             2.5 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -53.2 mm
 fehler:                             0.0 mm


 entnahme gws [qbm/s]:       0.001
 10.3690586  -> zufluss grundwasserleiter in  4539
TG:    4539 -> TG:    4541
Prozent:0.70

TG:    4539 -> TG:    4547
Prozent:0.10

TG:    4539 -> TG:    4554
Prozent:0.20


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:            1.1 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:           5.2 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.1 mm
     pot.entnahme GWS:                 0.1 mm
 speicherinhaltsaenderung:            -4.3 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                2.864 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    2.864 qkm


fuellenberechnung in iso
abflusz =         29786.523
niederschlag =    29786.590
flaeche zft  =        1.000
flaeche eing.=        2.864

GEBIET: Abflusswelle Interflow:
fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        2.864

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV:  fuellenberechnung
ISOV: Abflusz =         19890.998
ISOV: Niederschlag =    19891.008

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1034

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4541

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    2.16

 gesamtmenge an niederschlag (mm):       77.1

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     46


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  0.900
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  5.000


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4541
 anzahl hydrotope:      46


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      77.1 mm
 interz.verd.:                       7.5 mm
 bestandsniederschlag:              67.2 mm
 differenz interz.speicher:         -2.4 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      16.1 mm
 aktuelle verdunstung:              10.4 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              67.2 mm
 overlandflow:                      16.1 mm
 [infiltration:                     51.1 mm]
 verdunstung (bodensp.):             2.9 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -48.2 mm
 fehler:                             0.0 mm


 34.9887161  -> zufluss grundwasserleiter in  4541
TG:    4541 -> TG:    4548
Prozent:0.20

TG:    4541 -> TG:    4554
Prozent:0.15

TG:    4541 -> TG:    4556
Prozent:0.65


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:           26.2 mm
 abgabe basisabfluss:                  3.6 mm
        grundw. unterh.l.TG:          23.0 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -0.5 mm
 fehler:                               0.1 mm


 flaechenanteile: 

   grundwasserleiter:                0.401 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.401 qkm


fuellenberechnung in iso
abflusz =          6475.013
niederschlag =     6475.005
flaeche zft  =        1.000
flaeche eing.=        0.401

GEBIET: Abflusswelle Interflow:
fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.401

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV:  fuellenberechnung
ISOV: Abflusz =          5679.206
ISOV: Niederschlag =     5679.208

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1035

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4547

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    2.16

 gesamtmenge an niederschlag (mm):       77.1

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     38


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  0.900
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  2.750


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4547
 anzahl hydrotope:      38


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      77.1 mm
 interz.verd.:                       7.1 mm
 bestandsniederschlag:              68.0 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      16.3 mm
 aktuelle verdunstung:              11.1 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              68.0 mm
 overlandflow:                      35.4 mm
 [infiltration:                     32.6 mm]
 verdunstung (bodensp.):             4.0 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -28.6 mm
 fehler:                             0.0 mm


 4.99839163  -> zufluss grundwasserleiter in  4547
TG:    4547 -> TG:    4548
Prozent:1.00


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:           13.3 mm
 abgabe basisabfluss:                  8.1 mm
        grundw. unterh.l.TG:          17.7 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:               -12.5 mm
     pot.entnahme GWS:               -12.5 mm
 speicherinhaltsaenderung:             0.0 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.113 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.113 qkm


fuellenberechnung in iso
abflusz =          3991.828
niederschlag =     3991.825
flaeche zft  =        1.000
flaeche eing.=        0.113

GEBIET: Abflusswelle Interflow:
fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.113

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV:  fuellenberechnung
ISOV: Abflusz =          2253.705
ISOV: Niederschlag =     2253.706

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1036

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4544

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    2.16

 gesamtmenge an niederschlag (mm):       77.1

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     49


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  0.900
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  2.000


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4544
 anzahl hydrotope:      49


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      77.1 mm
 interz.verd.:                       7.1 mm
 bestandsniederschlag:              68.0 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      16.2 mm
 aktuelle verdunstung:              10.1 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              68.0 mm
 overlandflow:                      14.7 mm
 [infiltration:                     53.4 mm]
 verdunstung (bodensp.):             3.0 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -50.4 mm
 fehler:                             0.0 mm


 2.26124454  -> zufluss grundwasserleiter in  4544
TG:    4544 -> TG:    4546
Prozent:1.00


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:            1.8 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:           5.0 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                -0.7 mm
     pot.entnahme GWS:                -0.7 mm
 speicherinhaltsaenderung:            -2.5 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.385 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.385 qkm


fuellenberechnung in iso
abflusz =          5643.653
niederschlag =     5643.657
flaeche zft  =        1.000
flaeche eing.=        0.385

GEBIET: Abflusswelle Interflow:
fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.385

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV:  fuellenberechnung
ISOV: Abflusz =          4754.414
ISOV: Niederschlag =     4754.417

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1037

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4546

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    2.16

 gesamtmenge an niederschlag (mm):       77.1

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     67


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  0.900
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  2.250


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4546
 anzahl hydrotope:      67


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      77.1 mm
 interz.verd.:                       7.1 mm
 bestandsniederschlag:              68.1 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      16.2 mm
 aktuelle verdunstung:              10.3 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              68.1 mm
 overlandflow:                      27.2 mm
 [infiltration:                     40.8 mm]
 verdunstung (bodensp.):             3.2 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -37.6 mm
 fehler:                             0.0 mm


 6.35453510  -> zufluss grundwasserleiter in  4546
TG:    4546 -> TG:    4548
Prozent:1.00


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:            8.8 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:          12.9 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -4.1 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.216 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.216 qkm


fuellenberechnung in iso
abflusz =          5876.473
niederschlag =     5876.479
flaeche zft  =        1.000
flaeche eing.=        0.216

GEBIET: Abflusswelle Interflow:
fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.216

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV:  fuellenberechnung
ISOV: Abflusz =          2552.593
ISOV: Niederschlag =     2552.592

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1038

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4548

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    2.16

 gesamtmenge an niederschlag (mm):       77.1

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:    125


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  0.900
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  2.000


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4548
 anzahl hydrotope:     125


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      77.1 mm
 interz.verd.:                       7.1 mm
 bestandsniederschlag:              68.1 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      16.2 mm
 aktuelle verdunstung:              10.2 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              68.1 mm
 overlandflow:                      19.3 mm
 [infiltration:                     48.7 mm]
 verdunstung (bodensp.):             3.1 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -45.6 mm
 fehler:                             0.0 mm


 22.0669289  -> zufluss grundwasserleiter in  4548
TG:    4548 -> TG:    4556
Prozent:0.50

TG:    4548 -> TG:    4559
Prozent:0.50


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:           13.7 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:          18.0 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -4.3 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.483 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.483 qkm


fuellenberechnung in iso
abflusz =          9332.869
niederschlag =     9332.855
flaeche zft  =        1.000
flaeche eing.=        0.483

GEBIET: Abflusswelle Interflow:
fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.483

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV:  fuellenberechnung
ISOV: Abflusz =          5846.748
ISOV: Niederschlag =     5846.758

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1039

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4554

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    2.16

 gesamtmenge an niederschlag (mm):       77.1

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     34


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  0.900
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  3.000


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4554
 anzahl hydrotope:      34


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      77.1 mm
 interz.verd.:                       7.2 mm
 bestandsniederschlag:              67.9 mm
 differenz interz.speicher:         -2.1 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      15.7 mm
 aktuelle verdunstung:               9.8 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              67.9 mm
 overlandflow:                      10.3 mm
 [infiltration:                     57.5 mm]
 verdunstung (bodensp.):             2.6 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -54.9 mm
 fehler:                             0.0 mm


 14.6182604  -> zufluss grundwasserleiter in  4554
TG:    4554 -> TG:    4556
Prozent:0.50

TG:    4554 -> TG:    4559
Prozent:0.50


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:            8.0 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:          12.4 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -4.4 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.547 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.547 qkm


fuellenberechnung in iso
abflusz =          5664.839
niederschlag =     5664.838
flaeche zft  =        1.000
flaeche eing.=        0.547

GEBIET: Abflusswelle Interflow:

 Anzahl der Zeitschritte in iso durch Nachlauf zu hoch geworden.
 Sie wird auf 460 begrenzt !  gebiet :  4554

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.547

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV:  fuellenberechnung
ISOV: Abflusz =         10826.204
ISOV: Niederschlag =    10826.218

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1040

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4556

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    2.16

 gesamtmenge an niederschlag (mm):       77.1

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:    105


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  0.900
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 = 12.000


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4556
 anzahl hydrotope:     105


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      77.1 mm
 interz.verd.:                       7.1 mm
 bestandsniederschlag:              68.1 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      16.0 mm
 aktuelle verdunstung:               9.8 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              68.1 mm
 overlandflow:                      10.8 mm
 [infiltration:                     57.3 mm]
 verdunstung (bodensp.):             2.8 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -54.5 mm
 fehler:                             0.0 mm


 45.8653488  -> zufluss grundwasserleiter in  4556
TG:    4556 -> TG:    4559
Prozent:1.00


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:           15.2 mm
 abgabe basisabfluss:                  3.6 mm
        grundw. unterh.l.TG:          13.0 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                -0.6 mm
     pot.entnahme GWS:                -0.6 mm
 speicherinhaltsaenderung:            -0.9 mm
 fehler:                               0.2 mm


 flaechenanteile: 

   grundwasserleiter:                0.904 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.904 qkm


fuellenberechnung in iso
abflusz =          9748.034
niederschlag =     9748.049
flaeche zft  =        1.000
flaeche eing.=        0.904

GEBIET: Abflusswelle Interflow:
fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.904

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV:  fuellenberechnung
ISOV: Abflusz =         15435.409
ISOV: Niederschlag =    15435.419

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1041

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4559

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    2.16

 gesamtmenge an niederschlag (mm):       77.1

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:    121


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  0.900
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  4.000


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4559
 anzahl hydrotope:     121


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      77.1 mm
 interz.verd.:                       7.0 mm
 bestandsniederschlag:              68.1 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      15.9 mm
 aktuelle verdunstung:               9.9 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              68.1 mm
 overlandflow:                      20.3 mm
 [infiltration:                     47.8 mm]
 verdunstung (bodensp.):             2.8 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -45.0 mm
 fehler:                             0.0 mm


 65.0036545  -> zufluss grundwasserleiter in  4559
TG:    4559 -> TG:    4560
Prozent:0.10

TG:    4559 -> TG:    4564
Prozent:0.60

TG:    4559 -> TG:    4589
Prozent:0.30


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:           27.2 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:          34.3 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                -1.6 mm
     pot.entnahme GWS:                -1.6 mm
 speicherinhaltsaenderung:            -5.5 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.718 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.718 qkm


fuellenberechnung in iso
abflusz =         14544.260
niederschlag =    14544.263
flaeche zft  =        1.000
flaeche eing.=        0.718

GEBIET: Abflusswelle Interflow:
fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.718

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV:  fuellenberechnung
ISOV: Abflusz =         10124.793
ISOV: Niederschlag =    10124.809

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1042

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4560

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    2.16

 gesamtmenge an niederschlag (mm):       77.1

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:      4


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  0.900
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  7.500


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4560
 anzahl hydrotope:       4


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      77.1 mm
 interz.verd.:                       6.6 mm
 bestandsniederschlag:              68.7 mm
 differenz interz.speicher:         -1.7 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      13.5 mm
 aktuelle verdunstung:               8.5 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              68.7 mm
 overlandflow:                      10.2 mm
 [infiltration:                     58.5 mm]
 verdunstung (bodensp.):             1.9 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -56.6 mm
 fehler:                             0.0 mm


 8.20218277  -> zufluss grundwasserleiter in  4560
TG:    4560 -> TG:    4564
Prozent:1.00


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:           72.2 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:          80.2 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -8.0 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.034 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.034 qkm


fuellenberechnung in iso
abflusz =           348.655
niederschlag =      348.655
flaeche zft  =        1.000
flaeche eing.=        0.034

GEBIET: Abflusswelle Interflow:
fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.034

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV:  fuellenberechnung
ISOV: Abflusz =          1192.152
ISOV: Niederschlag =     1192.151

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1043

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4561

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    2.16

 gesamtmenge an niederschlag (mm):       77.1

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     28


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  0.900
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  6.300


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4561
 anzahl hydrotope:      28


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      77.1 mm
 interz.verd.:                       6.7 mm
 bestandsniederschlag:              68.7 mm
 differenz interz.speicher:         -1.8 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      13.8 mm
 aktuelle verdunstung:               9.1 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              68.7 mm
 overlandflow:                      33.3 mm
 [infiltration:                     35.4 mm]
 verdunstung (bodensp.):             2.5 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -32.9 mm
 fehler:                             0.0 mm


 18.5312786  -> zufluss grundwasserleiter in  4561
TG:    4561 -> TG:    4564
Prozent:0.90

TG:    4561 -> TG:    4565
Prozent:0.10


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:          102.3 mm
 abgabe basisabfluss:                 67.9 mm
        grundw. unterh.l.TG:          34.7 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -0.4 mm
 fehler:                               0.1 mm


 flaechenanteile: 

   grundwasserleiter:                0.054 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.054 qkm


fuellenberechnung in iso
abflusz =          1809.149
niederschlag =     1809.149
flaeche zft  =        1.000
flaeche eing.=        0.054

GEBIET: Abflusswelle Interflow:
fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.054

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV:  fuellenberechnung
ISOV: Abflusz =          1692.145
ISOV: Niederschlag =     1692.146

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1044

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4529

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    2.16

 gesamtmenge an niederschlag (mm):       77.1

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     23


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  3.000


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4529
 anzahl hydrotope:      23


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      77.1 mm
 interz.verd.:                       6.8 mm
 bestandsniederschlag:              68.5 mm
 differenz interz.speicher:         -1.8 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      13.8 mm
 aktuelle verdunstung:               9.4 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              68.5 mm
 overlandflow:                       4.6 mm
 [infiltration:                     63.9 mm]
 verdunstung (bodensp.):             2.6 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -61.3 mm
 fehler:                             0.0 mm


 5.59569025  -> zufluss grundwasserleiter in  4529
TG:    4529 -> TG:    4563
Prozent:1.00


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:           25.3 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:          26.7 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -1.3 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.066 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.066 qkm



 Anzahl der Zeitschritte in iso durch Nachlauf zu hoch geworden.
 Sie wird auf 460 begrenzt !  gebiet :  4529

fuellenberechnung in iso
abflusz =           302.939
niederschlag =      303.462
flaeche zft  =        1.000
flaeche eing.=        0.066

GEBIET: Abflusswelle Interflow:
fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.066

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV:  fuellenberechnung
ISOV: Abflusz =          2061.049
ISOV: Niederschlag =     2061.050

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1045

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4563

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    2.16

 gesamtmenge an niederschlag (mm):       77.1

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     28


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  4.000


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4563
 anzahl hydrotope:      28


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      77.1 mm
 interz.verd.:                       7.3 mm
 bestandsniederschlag:              67.5 mm
 differenz interz.speicher:         -2.2 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      15.8 mm
 aktuelle verdunstung:              11.5 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              67.5 mm
 overlandflow:                       5.6 mm
 [infiltration:                     61.9 mm]
 verdunstung (bodensp.):             4.1 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -57.8 mm
 fehler:                             0.0 mm


 22.6633968  -> zufluss grundwasserleiter in  4563
TG:    4563 -> TG:    4564
Prozent:0.30

TG:    4563 -> TG:    4565
Prozent:0.70


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:           48.4 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:          50.1 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -1.8 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.141 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.141 qkm



 Anzahl der Zeitschritte in iso durch Nachlauf zu hoch geworden.
 Sie wird auf 460 begrenzt !  gebiet :  4563

fuellenberechnung in iso
abflusz =           787.340
niederschlag =      788.701
flaeche zft  =        1.000
flaeche eing.=        0.141

GEBIET: Abflusswelle Interflow:
fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.141

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV:  fuellenberechnung
ISOV: Abflusz =           819.299
ISOV: Niederschlag =      819.299

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1046

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4564

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    2.16

 gesamtmenge an niederschlag (mm):       77.1

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:    108


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  8.500


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4564
 anzahl hydrotope:     108


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      77.1 mm
 interz.verd.:                       7.1 mm
 bestandsniederschlag:              68.0 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      16.0 mm
 aktuelle verdunstung:              10.8 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              68.0 mm
 overlandflow:                       3.6 mm
 [infiltration:                     64.5 mm]
 verdunstung (bodensp.):             3.8 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -60.7 mm
 fehler:                             0.0 mm


 89.5485840  -> zufluss grundwasserleiter in  4564
TG:    4564 -> TG:    4565
Prozent:0.40

TG:    4564 -> TG:    4566
Prozent:0.40

TG:    4564 -> TG:    4571
Prozent:0.20


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:           34.7 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:          35.7 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -1.0 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.773 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.773 qkm



 Anzahl der Zeitschritte in iso durch Nachlauf zu hoch geworden.
 Sie wird auf 460 begrenzt !  gebiet :  4564

fuellenberechnung in iso
abflusz =          2767.621
niederschlag =     2772.400
flaeche zft  =        1.000
flaeche eing.=        0.773

GEBIET: Abflusswelle Interflow:
fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.773

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV:  fuellenberechnung
ISOV: Abflusz =          9144.678
ISOV: Niederschlag =     9144.684

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1047

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4562

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    2.16

 gesamtmenge an niederschlag (mm):       77.1

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:      7


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  0.900
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  3.500


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4562
 anzahl hydrotope:       7


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      77.1 mm
 interz.verd.:                       7.0 mm
 bestandsniederschlag:              68.1 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      15.5 mm
 aktuelle verdunstung:              11.2 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              68.1 mm
 overlandflow:                      42.7 mm
 [infiltration:                     25.4 mm]
 verdunstung (bodensp.):             4.2 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -21.2 mm
 fehler:                             0.0 mm


 0.00000000E+00  -> zufluss grundwasserleiter in  4562
TG:    4562 -> TG:    4565
Prozent:0.10


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:            0.0 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:           2.2 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -2.2 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.081 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.081 qkm


fuellenberechnung in iso
abflusz =          3441.153
niederschlag =     3441.155
flaeche zft  =        1.000
flaeche eing.=        0.081

GEBIET: Abflusswelle Interflow:
fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.081

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV:  fuellenberechnung
ISOV: Abflusz =             5.367
ISOV: Niederschlag =        5.367

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1048

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4565

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    2.16

 gesamtmenge an niederschlag (mm):       77.1

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     14


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  8.000


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4565
 anzahl hydrotope:      14


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      77.1 mm
 interz.verd.:                       8.8 mm
 bestandsniederschlag:              64.7 mm
 differenz interz.speicher:         -3.6 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      16.4 mm
 aktuelle verdunstung:              11.8 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              64.7 mm
 overlandflow:                       5.6 mm
 [infiltration:                     59.1 mm]
 verdunstung (bodensp.):             3.1 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -56.0 mm
 fehler:                             0.0 mm


 68.8416138  -> zufluss grundwasserleiter in  4565
TG:    4565 -> TG:    4566
Prozent:1.00


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:          122.5 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:         125.9 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -3.4 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.169 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.169 qkm



 Anzahl der Zeitschritte in iso durch Nachlauf zu hoch geworden.
 Sie wird auf 460 begrenzt !  gebiet :  4565

fuellenberechnung in iso
abflusz =           949.621
niederschlag =      951.263
flaeche zft  =        1.000
flaeche eing.=        0.169

GEBIET: Abflusswelle Interflow:
fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.169

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV:  fuellenberechnung
ISOV: Abflusz =           143.305
ISOV: Niederschlag =      143.305

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1049

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4566

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    2.16

 gesamtmenge an niederschlag (mm):       77.1

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     54


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 = 14.500


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4566
 anzahl hydrotope:      54


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      77.1 mm
 interz.verd.:                       7.7 mm
 bestandsniederschlag:              66.9 mm
 differenz interz.speicher:         -2.5 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      16.3 mm
 aktuelle verdunstung:              11.1 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              66.9 mm
 overlandflow:                       4.2 mm
 [infiltration:                     62.7 mm]
 verdunstung (bodensp.):             3.5 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -59.2 mm
 fehler:                             0.0 mm


 140.999603  -> zufluss grundwasserleiter in  4566
TG:    4566 -> TG:    4567
Prozent:0.30

TG:    4566 -> TG:    4580
Prozent:0.50

TG:    4566 -> TG:    4587
Prozent:0.20


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:           46.3 mm
 abgabe basisabfluss:                 23.3 mm
        grundw. unterh.l.TG:          23.2 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -0.2 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.914 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.914 qkm



 Anzahl der Zeitschritte in iso durch Nachlauf zu hoch geworden.
 Sie wird auf 460 begrenzt !  gebiet :  4566

fuellenberechnung in iso
abflusz =          3854.007
niederschlag =     3860.667
flaeche zft  =        1.000
flaeche eing.=        0.914

GEBIET: Abflusswelle Interflow:
fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.914

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV:  fuellenberechnung
ISOV: Abflusz =          1887.269
ISOV: Niederschlag =     1887.270

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1050

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4571

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    2.16

 gesamtmenge an niederschlag (mm):       77.1

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     21


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  1.000


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4571
 anzahl hydrotope:      21


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      77.1 mm
 interz.verd.:                       7.1 mm
 bestandsniederschlag:              68.0 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      16.3 mm
 aktuelle verdunstung:              11.2 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              68.0 mm
 overlandflow:                       4.2 mm
 [infiltration:                     63.8 mm]
 verdunstung (bodensp.):             4.1 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -59.8 mm
 fehler:                             0.0 mm


 18.4267292  -> zufluss grundwasserleiter in  4571
TG:    4571 -> TG:    4573
Prozent:0.20

TG:    4571 -> TG:    4580
Prozent:0.80


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:           34.7 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:          34.9 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -0.2 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.160 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.160 qkm


fuellenberechnung in iso
abflusz =           667.074
niederschlag =      667.074
flaeche zft  =        1.000
flaeche eing.=        0.160

GEBIET: Abflusswelle Interflow:
fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.160

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV:  fuellenberechnung
ISOV: Abflusz =          1414.112
ISOV: Niederschlag =     1414.111

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1051

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4589

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    2.16

 gesamtmenge an niederschlag (mm):       77.1

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     99


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  1.000


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4589
 anzahl hydrotope:      99


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      77.1 mm
 interz.verd.:                       7.1 mm
 bestandsniederschlag:              68.1 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      16.1 mm
 aktuelle verdunstung:              10.5 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              68.1 mm
 overlandflow:                       3.0 mm
 [infiltration:                     65.1 mm]
 verdunstung (bodensp.):             3.4 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -61.7 mm
 fehler:                             0.0 mm


 24.6065884  -> zufluss grundwasserleiter in  4589
TG:    4589 -> TG:    4572
Prozent:0.20

TG:    4589 -> TG:    4593
Prozent:0.80


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:           13.6 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:          16.7 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                -2.6 mm
     pot.entnahme GWS:                -2.6 mm
 speicherinhaltsaenderung:            -0.5 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.541 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.541 qkm



 Anzahl der Zeitschritte in iso durch Nachlauf zu hoch geworden.
 Sie wird auf 460 begrenzt !  gebiet :  4589

fuellenberechnung in iso
abflusz =          1610.249
niederschlag =     1613.031
flaeche zft  =        1.000
flaeche eing.=        0.541

GEBIET: Abflusswelle Interflow:
fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.541

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV:  fuellenberechnung
ISOV: Abflusz =          6137.683
ISOV: Niederschlag =     6137.684

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1052

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4572

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    2.16

 gesamtmenge an niederschlag (mm):       77.1

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     35


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  1.000


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4572
 anzahl hydrotope:      35


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      77.1 mm
 interz.verd.:                       7.1 mm
 bestandsniederschlag:              68.0 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      16.2 mm
 aktuelle verdunstung:              10.7 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              68.0 mm
 overlandflow:                       3.3 mm
 [infiltration:                     64.7 mm]
 verdunstung (bodensp.):             3.6 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -61.1 mm
 fehler:                             0.0 mm


 6.03974247  -> zufluss grundwasserleiter in  4572
TG:    4572 -> TG:    4574
Prozent:0.50

TG:    4572 -> TG:    4573
Prozent:0.50


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:            6.6 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:           6.8 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -0.2 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.275 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.275 qkm



 Anzahl der Zeitschritte in iso durch Nachlauf zu hoch geworden.
 Sie wird auf 460 begrenzt !  gebiet :  4572

fuellenberechnung in iso
abflusz =           908.012
niederschlag =      908.011
flaeche zft  =        1.000
flaeche eing.=        0.275

GEBIET: Abflusswelle Interflow:
fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.275

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV:  fuellenberechnung
ISOV: Abflusz =          1709.605
ISOV: Niederschlag =     1709.604

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1053

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4573

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    2.16

 gesamtmenge an niederschlag (mm):       77.1

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     21


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  1.000


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4573
 anzahl hydrotope:      21


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      77.1 mm
 interz.verd.:                       7.1 mm
 bestandsniederschlag:              68.1 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      16.2 mm
 aktuelle verdunstung:              11.8 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              68.1 mm
 overlandflow:                       5.5 mm
 [infiltration:                     62.5 mm]
 verdunstung (bodensp.):             4.8 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -57.8 mm
 fehler:                             0.0 mm


 6.81968641  -> zufluss grundwasserleiter in  4573
TG:    4573 -> TG:    4576
Prozent:0.50

TG:    4573 -> TG:    4578
Prozent:0.50


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:           22.5 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:          23.1 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -0.6 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.091 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.091 qkm


fuellenberechnung in iso
abflusz =           499.979
niederschlag =      499.979
flaeche zft  =        1.000
flaeche eing.=        0.091

GEBIET: Abflusswelle Interflow:
fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.091

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV:  fuellenberechnung
ISOV: Abflusz =           892.094
ISOV: Niederschlag =      892.093

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1054

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4576

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    2.16

 gesamtmenge an niederschlag (mm):       77.1

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     12


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  1.000


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4576
 anzahl hydrotope:      12


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      77.1 mm
 interz.verd.:                       7.1 mm
 bestandsniederschlag:              68.1 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      16.0 mm
 aktuelle verdunstung:              11.8 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              68.1 mm
 overlandflow:                       5.6 mm
 [infiltration:                     62.5 mm]
 verdunstung (bodensp.):             4.7 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -57.7 mm
 fehler:                             0.0 mm


 3.49526715  -> zufluss grundwasserleiter in  4576
TG:    4576 -> TG:    4578
Prozent:0.80

TG:    4576 -> TG:    4579
Prozent:0.20


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:           60.6 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:          60.6 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:             0.1 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.017 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.017 qkm


fuellenberechnung in iso
abflusz =            96.318
niederschlag =       96.318
flaeche zft  =        1.000
flaeche eing.=        0.017

GEBIET: Abflusswelle Interflow:
fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.017

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV:  fuellenberechnung
ISOV: Abflusz =            58.790
ISOV: Niederschlag =       58.790

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1055

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4578

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    2.16

 gesamtmenge an niederschlag (mm):       77.1

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     15


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  1.000


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4578
 anzahl hydrotope:      15


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      77.1 mm
 interz.verd.:                       7.2 mm
 bestandsniederschlag:              67.8 mm
 differenz interz.speicher:         -2.1 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      16.3 mm
 aktuelle verdunstung:              11.9 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              67.8 mm
 overlandflow:                       5.3 mm
 [infiltration:                     62.5 mm]
 verdunstung (bodensp.):             4.7 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -57.8 mm
 fehler:                             0.0 mm


 6.28755856  -> zufluss grundwasserleiter in  4578
TG:    4578 -> TG:    4579
Prozent:0.80

TG:    4578 -> TG:    4580
Prozent:0.20


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:           86.1 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:          86.4 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -0.3 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.022 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.022 qkm


fuellenberechnung in iso
abflusz =           115.425
niederschlag =      115.425
flaeche zft  =        1.000
flaeche eing.=        0.022

GEBIET: Abflusswelle Interflow:
fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.022

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV:  fuellenberechnung
ISOV: Abflusz =           110.980
ISOV: Niederschlag =      110.980

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1056

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4580

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    2.16

 gesamtmenge an niederschlag (mm):       77.1

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     31


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 = 10.000


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4580
 anzahl hydrotope:      31


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      77.1 mm
 interz.verd.:                       7.1 mm
 bestandsniederschlag:              68.1 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      16.0 mm
 aktuelle verdunstung:              10.9 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              68.1 mm
 overlandflow:                       2.6 mm
 [infiltration:                     65.5 mm]
 verdunstung (bodensp.):             3.8 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -61.7 mm
 fehler:                             0.0 mm


 51.3816032  -> zufluss grundwasserleiter in  4580
TG:    4580 -> TG:    4579
Prozent:0.10

TG:    4580 -> TG:    4584
Prozent:0.30

TG:    4580 -> TG:    4586
Prozent:0.60


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:          231.7 mm
 abgabe basisabfluss:                 73.7 mm
        grundw. unterh.l.TG:         158.2 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -0.3 mm
 fehler:                               0.1 mm


 flaechenanteile: 

   grundwasserleiter:                0.067 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.067 qkm



 Anzahl der Zeitschritte in iso durch Nachlauf zu hoch geworden.
 Sie wird auf 460 begrenzt !  gebiet :  4580

fuellenberechnung in iso
abflusz =           170.682
niederschlag =      170.977
flaeche zft  =        1.000
flaeche eing.=        0.067

GEBIET: Abflusswelle Interflow:
fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.067

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV:  fuellenberechnung
ISOV: Abflusz =           440.464
ISOV: Niederschlag =      440.464

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1057

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4584

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    2.16

 gesamtmenge an niederschlag (mm):       77.1

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     21


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  5.000


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4584
 anzahl hydrotope:      21


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      77.1 mm
 interz.verd.:                       7.1 mm
 bestandsniederschlag:              68.0 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      16.4 mm
 aktuelle verdunstung:              10.6 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              68.0 mm
 overlandflow:                       0.8 mm
 [infiltration:                     67.2 mm]
 verdunstung (bodensp.):             3.4 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -63.8 mm
 fehler:                             0.0 mm


 10.5262566  -> zufluss grundwasserleiter in  4584
TG:    4584 -> TG:    4587
Prozent:1.00


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:           54.8 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:          55.0 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -0.2 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.058 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.058 qkm


fuellenberechnung in iso
abflusz =            44.914
niederschlag =       44.914
flaeche zft  =        1.000
flaeche eing.=        0.058

GEBIET: Abflusswelle Interflow:
fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.058

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV:  fuellenberechnung
ISOV: Abflusz =          1161.800
ISOV: Niederschlag =     1161.801

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1058

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4587

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    2.16

 gesamtmenge an niederschlag (mm):       77.1

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     15


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  5.000


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4587
 anzahl hydrotope:      15


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      77.1 mm
 interz.verd.:                       7.1 mm
 bestandsniederschlag:              68.1 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      16.0 mm
 aktuelle verdunstung:              10.1 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              68.1 mm
 overlandflow:                       0.0 mm
 [infiltration:                     68.1 mm]
 verdunstung (bodensp.):             3.1 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -65.0 mm
 fehler:                             0.0 mm


 24.6812401  -> zufluss grundwasserleiter in  4587
TG:    4587 -> TG:    4598
Prozent:1.00


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:          406.3 mm
 abgabe basisabfluss:                 44.4 mm
        grundw. unterh.l.TG:         362.3 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -0.4 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.018 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.018 qkm


fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.018

GEBIET: Abflusswelle Interflow:
fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.018

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV:  fuellenberechnung
ISOV: Abflusz =           171.497
ISOV: Niederschlag =      171.497

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1059

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4574

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    2.16

 gesamtmenge an niederschlag (mm):       77.1

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     26


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  1.000


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4574
 anzahl hydrotope:      26


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      77.1 mm
 interz.verd.:                       7.2 mm
 bestandsniederschlag:              67.9 mm
 differenz interz.speicher:         -2.1 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      16.2 mm
 aktuelle verdunstung:              10.7 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              67.9 mm
 overlandflow:                       1.5 mm
 [infiltration:                     66.4 mm]
 verdunstung (bodensp.):             3.5 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -62.9 mm
 fehler:                             0.0 mm


 3.11029720  -> zufluss grundwasserleiter in  4574
TG:    4574 -> TG:    4575
Prozent:1.00


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:           10.4 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:          10.8 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -0.4 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.090 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.090 qkm


fuellenberechnung in iso
abflusz =           133.448
niederschlag =      133.448
flaeche zft  =        1.000
flaeche eing.=        0.090

GEBIET: Abflusswelle Interflow:
fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.090

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV:  fuellenberechnung
ISOV: Abflusz =           943.418
ISOV: Niederschlag =      943.419

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1060

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4575

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    2.16

 gesamtmenge an niederschlag (mm):       77.1

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     16


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  1.000


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4575
 anzahl hydrotope:      16


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      77.1 mm
 interz.verd.:                       7.1 mm
 bestandsniederschlag:              68.1 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      16.0 mm
 aktuelle verdunstung:              10.2 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              68.1 mm
 overlandflow:                       0.1 mm
 [infiltration:                     68.0 mm]
 verdunstung (bodensp.):             3.1 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -64.8 mm
 fehler:                             0.0 mm


 3.22352719  -> zufluss grundwasserleiter in  4575
TG:    4575 -> TG:    4585
Prozent:1.00


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:           20.6 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:          20.8 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -0.2 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.047 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.047 qkm


fuellenberechnung in iso
abflusz =             5.977
niederschlag =        5.977
flaeche zft  =        1.000
flaeche eing.=        0.047

GEBIET: Abflusswelle Interflow:
fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.047

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV:  fuellenberechnung
ISOV: Abflusz =           665.693
ISOV: Niederschlag =      665.693

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1061

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4579

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    2.16

 gesamtmenge an niederschlag (mm):       77.1

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     20


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  1.000


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4579
 anzahl hydrotope:      20


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      77.1 mm
 interz.verd.:                       7.0 mm
 bestandsniederschlag:              68.1 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      15.9 mm
 aktuelle verdunstung:              11.3 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              68.1 mm
 overlandflow:                       4.4 mm
 [infiltration:                     63.8 mm]
 verdunstung (bodensp.):             4.3 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -59.5 mm
 fehler:                             0.0 mm


 9.25561714  -> zufluss grundwasserleiter in  4579
TG:    4579 -> TG:    4585
Prozent:0.50

TG:    4579 -> TG:    4586
Prozent:0.50


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:          214.5 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:         215.1 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -0.6 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.013 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.013 qkm


fuellenberechnung in iso
abflusz =            56.517
niederschlag =       56.517
flaeche zft  =        1.000
flaeche eing.=        0.013

GEBIET: Abflusswelle Interflow:
fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.013

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV:  fuellenberechnung
ISOV: Abflusz =           197.715
ISOV: Niederschlag =      197.715

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1062

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4585

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    2.16

 gesamtmenge an niederschlag (mm):       77.1

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     24


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  5.000


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4585
 anzahl hydrotope:      24


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      77.1 mm
 interz.verd.:                       7.1 mm
 bestandsniederschlag:              68.1 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      16.1 mm
 aktuelle verdunstung:              10.5 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              68.1 mm
 overlandflow:                       1.2 mm
 [infiltration:                     66.9 mm]
 verdunstung (bodensp.):             3.5 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -63.5 mm
 fehler:                             0.0 mm


 7.89322567  -> zufluss grundwasserleiter in  4585
TG:    4585 -> TG:    4596
Prozent:1.00


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:           41.2 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:          44.4 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -3.2 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.058 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.058 qkm



 Anzahl der Zeitschritte in iso durch Nachlauf zu hoch geworden.
 Sie wird auf 460 begrenzt !  gebiet :  4585

fuellenberechnung in iso
abflusz =            66.206
niederschlag =       66.231
flaeche zft  =        1.000
flaeche eing.=        0.058

GEBIET: Abflusswelle Interflow:
fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.058

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV:  fuellenberechnung
ISOV: Abflusz =           830.590
ISOV: Niederschlag =      830.589

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1063

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4586

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    2.16

 gesamtmenge an niederschlag (mm):       77.1

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     44


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  5.000


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4586
 anzahl hydrotope:      44


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      77.1 mm
 interz.verd.:                       7.1 mm
 bestandsniederschlag:              68.1 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      16.0 mm
 aktuelle verdunstung:              11.0 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              68.1 mm
 overlandflow:                       2.9 mm
 [infiltration:                     65.2 mm]
 verdunstung (bodensp.):             3.9 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -61.2 mm
 fehler:                             0.0 mm


 25.6932526  -> zufluss grundwasserleiter in  4586
TG:    4586 -> TG:    4598
Prozent:0.50

TG:    4586 -> TG:    4596
Prozent:0.50


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:          133.7 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:         134.1 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -0.4 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.058 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.058 qkm


fuellenberechnung in iso
abflusz =           168.810
niederschlag =      168.810
flaeche zft  =        1.000
flaeche eing.=        0.058

GEBIET: Abflusswelle Interflow:
fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.058

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV:  fuellenberechnung
ISOV: Abflusz =           742.681
ISOV: Niederschlag =      742.681

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         4585

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.

 Keine angeschlossenen Teilgebiete an Strang      4585
 Auswertung des Stranges:         4587

 Abflussverzoegerung mit Kalinin-Miljukov Parametern

 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 dt [h]:   0.08      tmax [d]:     4.86


 Kennwerte Zuflusswelle
 ----------------------

 Scheitel-Zufluss               iqzmax =   1400   qzmax =       0.068 [m**3/s]
 Scheitel-Zufluss im Gerinne    iqzfmx =   1400  qzfmax =       0.068 [m**3/s]
 Scheitel-Zufluss im Vorland    iqzvmx =      0  qzvmax =       0.000 [m**3/s]

 Fuelle-Zufluss                   fuqz =   0.0018 [hm**3]
 Fuelle-zufluss im Gerinne       fuqzf =   0.0018 [hm**3]
 Fuelle-zufluss im Vorland       fuqzv =   0.0000 [hm**3]


 Kennwerte der Systemfunktionen
 -------------------------------

 Anzahl der Zeitschritte  ituh =     18
 Maximum u                imax =      3     umax = 0.269426
 Summe u                   suu = 0.999998   suuh = 1.000000


 tmax [d]:     4.88


 Kennwerte Ausflusswelle
 -----------------------

 Endordinate Ausfluss           qaend =   0.000
 Scheitel-Ausfluss              iqmax =   1404    qmax =       0.068 [m**3/s]

 Fuelle-Ausfluss                  fuq =   0.0018 [hm**3]
 Fuelle-Ausfluss im Gerinne      fuqa =   0.0018 [hm**3]

 Scheitel-Ausfluss im Gerinne  iqamax =   1404   qamax =       0.068 [m**3/s]


 Gesamtzuflusswelle (ohne Basisabfluss)  sqz =        6.028
 Gesamtabflusswelle    "       "         sq  =        6.028


 Keine angeschlossenen Teilgebiete an Strang      4587
 Auswertung des Stranges:         4621

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Fiktiver Strang! Es erfolgt keine Abflussverzoegerung!
 Keine angeschlossenen Teilgebiete an Strang      4621
 Auswertung des Stranges:         1064

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4507

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    2.16

 gesamtmenge an niederschlag (mm):       77.1

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     69


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  0.500


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4507
 anzahl hydrotope:      69


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      77.1 mm
 interz.verd.:                       7.1 mm
 bestandsniederschlag:              68.1 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      16.1 mm
 aktuelle verdunstung:              10.7 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              68.1 mm
 overlandflow:                       1.8 mm
 [infiltration:                     66.2 mm]
 verdunstung (bodensp.):             3.6 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        2.0 mm
 differenz bodenspeicher:          -60.5 mm
 fehler:                             0.0 mm


 0.00000000E+00  -> zufluss grundwasserleiter in  4507
TG:    4507 -> TG:    4508
Prozent:1.00


 aufteilung perkolation: 

 perkolation bodenspeicher:            2.0 mm

 abgabe grundw.speicher:               2.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  2.0 mm
        grundw. oberh.l.TG:            0.0 mm
 abgabe basisabfluss:                  0.7 mm
        grundw. unterh.l.TG:           2.9 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                -1.2 mm
     pot.entnahme GWS:                -1.2 mm
 speicherinhaltsaenderung:            -0.3 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.513 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.513 qkm



 Anzahl der Zeitschritte in iso durch Nachlauf zu hoch geworden.
 Sie wird auf 460 begrenzt !  gebiet :  4507

fuellenberechnung in iso
abflusz =           944.958
niederschlag =      946.591
flaeche zft  =        1.000
flaeche eing.=        0.513

GEBIET: Abflusswelle Interflow:

 Anzahl der Zeitschritte in iso durch Nachlauf zu hoch geworden.
 Sie wird auf 460 begrenzt !  gebiet :  4507

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.513

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV:  fuellenberechnung
ISOV: Abflusz =          5843.171
ISOV: Niederschlag =     5843.177

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1065

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4508

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    2.16

 gesamtmenge an niederschlag (mm):       77.1

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     56


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  1.000


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4508
 anzahl hydrotope:      56


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      77.1 mm
 interz.verd.:                       7.1 mm
 bestandsniederschlag:              68.1 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      16.0 mm
 aktuelle verdunstung:              10.3 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              68.1 mm
 overlandflow:                       1.6 mm
 [infiltration:                     66.5 mm]
 verdunstung (bodensp.):             3.2 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.9 mm
 differenz bodenspeicher:          -62.4 mm
 fehler:                             0.0 mm


 entnahme gws [qbm/s]:       0.000
 4.94755888  -> zufluss grundwasserleiter in  4508
TG:    4508 -> TG:    4509
Prozent:1.00


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.9 mm

 abgabe grundw.speicher:               0.9 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.9 mm
        grundw. oberh.l.TG:            3.8 mm
 abgabe basisabfluss:                  1.6 mm
        grundw. unterh.l.TG:           3.7 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.2 mm
     pot.entnahme GWS:                 0.2 mm
 speicherinhaltsaenderung:            -0.9 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.390 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.390 qkm



 Anzahl der Zeitschritte in iso durch Nachlauf zu hoch geworden.
 Sie wird auf 460 begrenzt !  gebiet :  4508

fuellenberechnung in iso
abflusz =           615.991
niederschlag =      617.055
flaeche zft  =        1.000
flaeche eing.=        0.390

GEBIET: Abflusswelle Interflow:

 Anzahl der Zeitschritte in iso durch Nachlauf zu hoch geworden.
 Sie wird auf 460 begrenzt !  gebiet :  4508

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.390

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV:  fuellenberechnung
ISOV: Abflusz =          5588.767
ISOV: Niederschlag =     5588.771

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1066

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4509

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    2.16

 gesamtmenge an niederschlag (mm):       77.1

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     83


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  1.500


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4509
 anzahl hydrotope:      83


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      77.1 mm
 interz.verd.:                       7.1 mm
 bestandsniederschlag:              68.1 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      16.0 mm
 aktuelle verdunstung:              10.4 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              68.1 mm
 overlandflow:                       2.8 mm
 [infiltration:                     65.3 mm]
 verdunstung (bodensp.):             3.4 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.2 mm
 differenz bodenspeicher:          -61.7 mm
 fehler:                             0.0 mm


 entnahme gws [qbm/s]:       0.000
 9.07363701  -> zufluss grundwasserleiter in  4509
TG:    4509 -> TG:    4511
Prozent:1.00


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.2 mm

 abgabe grundw.speicher:               0.2 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.2 mm
        grundw. oberh.l.TG:            3.4 mm
 abgabe basisabfluss:                  1.3 mm
        grundw. unterh.l.TG:           3.4 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -1.2 mm
 fehler:                               0.1 mm


 flaechenanteile: 

   grundwasserleiter:                0.801 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.801 qkm



 Anzahl der Zeitschritte in iso durch Nachlauf zu hoch geworden.
 Sie wird auf 460 begrenzt !  gebiet :  4509

fuellenberechnung in iso
abflusz =          2231.784
niederschlag =     2235.640
flaeche zft  =        1.000
flaeche eing.=        0.801

GEBIET: Abflusswelle Interflow:

 Anzahl der Zeitschritte in iso durch Nachlauf zu hoch geworden.
 Sie wird auf 460 begrenzt !  gebiet :  4509

fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.801

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV:  fuellenberechnung
ISOV: Abflusz =          9525.054
ISOV: Niederschlag =     9525.059

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         4507

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.

 Keine angeschlossenen Teilgebiete an Strang      4507
 Auswertung des Stranges:         4508

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Abflussverzoegerung mit Kalinin-Miljukov Parametern

 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 dt [h]:   0.08      tmax [d]:     4.89


 Kennwerte Zuflusswelle
 ----------------------

 Scheitel-Zufluss               iqzmax =   1409   qzmax =       0.228 [m**3/s]
 Scheitel-Zufluss im Gerinne    iqzfmx =   1409  qzfmax =       0.228 [m**3/s]
 Scheitel-Zufluss im Vorland    iqzvmx =      0  qzvmax =       0.000 [m**3/s]

 Fuelle-Zufluss                   fuqz =   0.0072 [hm**3]
 Fuelle-zufluss im Gerinne       fuqzf =   0.0072 [hm**3]
 Fuelle-zufluss im Vorland       fuqzv =   0.0000 [hm**3]


 Kennwerte der Systemfunktionen
 -------------------------------

 Anzahl der Zeitschritte  ituh =     32
 Maximum u                imax =      1     umax = 0.248968
 Summe u                   suu = 1.001107   suuh = 1.000000


 tmax [d]:     4.90


 Kennwerte Ausflusswelle
 -----------------------

 Endordinate Ausfluss           qaend =   0.000
 Scheitel-Ausfluss              iqmax =   1410    qmax =       0.227 [m**3/s]

 Fuelle-Ausfluss                  fuq =   0.0072 [hm**3]
 Fuelle-Ausfluss im Gerinne      fuqa =   0.0072 [hm**3]

 Scheitel-Ausfluss im Gerinne  iqamax =   1410   qamax =       0.227 [m**3/s]


 Gesamtzuflusswelle (ohne Basisabfluss)  sqz =       23.861
 Gesamtabflusswelle    "       "         sq  =       23.861


 Keine angeschlossenen Teilgebiete an Strang      4508
 Auswertung des Stranges:         4509

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Abflussverzoegerung mit Kalinin-Miljukov Parametern

 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 dt [h]:   0.08      tmax [d]:     4.89


 Kennwerte Zuflusswelle
 ----------------------

 Scheitel-Zufluss               iqzmax =   1409   qzmax =       0.442 [m**3/s]
 Scheitel-Zufluss im Gerinne    iqzfmx =   1409  qzfmax =       0.442 [m**3/s]
 Scheitel-Zufluss im Vorland    iqzvmx =      0  qzvmax =       0.000 [m**3/s]

 Fuelle-Zufluss                   fuqz =   0.0140 [hm**3]
 Fuelle-zufluss im Gerinne       fuqzf =   0.0140 [hm**3]
 Fuelle-zufluss im Vorland       fuqzv =   0.0000 [hm**3]


 Kennwerte der Systemfunktionen
 -------------------------------

 Anzahl der Zeitschritte  ituh =     18
 Maximum u                imax =      3     umax = 0.269426
 Summe u                   suu = 0.999998   suuh = 1.000000


 tmax [d]:     4.91


 Kennwerte Ausflusswelle
 -----------------------

 Endordinate Ausfluss           qaend =   0.000
 Scheitel-Ausfluss              iqmax =   1413    qmax =       0.441 [m**3/s]

 Fuelle-Ausfluss                  fuq =   0.0140 [hm**3]
 Fuelle-Ausfluss im Gerinne      fuqa =   0.0140 [hm**3]

 Scheitel-Ausfluss im Gerinne  iqamax =   1413   qamax =       0.441 [m**3/s]


 Gesamtzuflusswelle (ohne Basisabfluss)  sqz =       46.652
 Gesamtabflusswelle    "       "         sq  =       46.652


 Keine angeschlossenen Teilgebiete an Strang      4509
 Auswertung des Stranges:         4605

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Fiktiver Strang! Es erfolgt keine Abflussverzoegerung!
 Keine angeschlossenen Teilgebiete an Strang      4605
 Auswertung des Stranges:         4503

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.

 Keine angeschlossenen Teilgebiete an Strang      4503
 Auswertung des Stranges:         4504

 Abflussverzoegerung mit Kalinin-Miljukov Parametern

 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 dt [h]:   0.08      tmax [d]:     4.93


 Kennwerte Zuflusswelle
 ----------------------

 Scheitel-Zufluss               iqzmax =   1420   qzmax =       0.162 [m**3/s]
 Scheitel-Zufluss im Gerinne    iqzfmx =   1420  qzfmax =       0.162 [m**3/s]
 Scheitel-Zufluss im Vorland    iqzvmx =      0  qzvmax =       0.000 [m**3/s]

 Fuelle-Zufluss                   fuqz =   0.0067 [hm**3]
 Fuelle-zufluss im Gerinne       fuqzf =   0.0067 [hm**3]
 Fuelle-zufluss im Vorland       fuqzv =   0.0000 [hm**3]


 Kennwerte der Systemfunktionen
 -------------------------------

 Anzahl der Zeitschritte  ituh =     18
 Maximum u                imax =      3     umax = 0.269426
 Summe u                   suu = 0.999998   suuh = 1.000000


 tmax [d]:     4.94


 Kennwerte Ausflusswelle
 -----------------------

 Endordinate Ausfluss           qaend =   0.000
 Scheitel-Ausfluss              iqmax =   1424    qmax =       0.162 [m**3/s]

 Fuelle-Ausfluss                  fuq =   0.0067 [hm**3]
 Fuelle-Ausfluss im Gerinne      fuqa =   0.0067 [hm**3]

 Scheitel-Ausfluss im Gerinne  iqamax =   1424   qamax =       0.162 [m**3/s]


 Gesamtzuflusswelle (ohne Basisabfluss)  sqz =       22.285
 Gesamtabflusswelle    "       "         sq  =       22.285


 Keine angeschlossenen Teilgebiete an Strang      4504
 Auswertung des Stranges:         4505

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Aufruf der Speicherroutine 


 zufluss-fuelle [hm]        0.023443 speicher 4505
 zusaetzl.zufl im nachl.ast [hm]  0.000756

 speicher   0.024199 abfluss-fuelle [hm]      4505

 speicherinhaltsaenderung [hm]  0.000000
 Keine angeschlossenen Teilgebiete an Strang      4505
 Auswertung des Stranges:         4603

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Fiktiver Strang! Es erfolgt keine Abflussverzoegerung!
 Keine angeschlossenen Teilgebiete an Strang      4603
 Auswertung des Stranges:         1067

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4511

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    2.16

 gesamtmenge an niederschlag (mm):       77.1

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     62


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  2.500


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4511
 anzahl hydrotope:      62


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      77.1 mm
 interz.verd.:                       7.1 mm
 bestandsniederschlag:              68.1 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      16.0 mm
 aktuelle verdunstung:              10.4 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              68.1 mm
 overlandflow:                       2.7 mm
 [infiltration:                     65.4 mm]
 verdunstung (bodensp.):             3.4 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -62.0 mm
 fehler:                             0.0 mm


 11.0036583  -> zufluss grundwasserleiter in  4511
TG:    4511 -> TG:    4567
Prozent:1.00


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:            9.7 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:          15.1 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -5.4 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.341 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.341 qkm



 Anzahl der Zeitschritte in iso durch Nachlauf zu hoch geworden.
 Sie wird auf 460 begrenzt !  gebiet :  4511

fuellenberechnung in iso
abflusz =           924.984
niederschlag =      926.582
flaeche zft  =        1.000
flaeche eing.=        0.341

GEBIET: Abflusswelle Interflow:
fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.341

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV:  fuellenberechnung
ISOV: Abflusz =          4819.313
ISOV: Niederschlag =     4819.316

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1068

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4567

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    2.16

 gesamtmenge an niederschlag (mm):       77.1

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     67


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  6.000


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4567
 anzahl hydrotope:      67


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      77.1 mm
 interz.verd.:                       7.6 mm
 bestandsniederschlag:              67.0 mm
 differenz interz.speicher:         -2.5 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      16.3 mm
 aktuelle verdunstung:              11.0 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              67.0 mm
 overlandflow:                       3.7 mm
 [infiltration:                     63.2 mm]
 verdunstung (bodensp.):             3.3 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -59.9 mm
 fehler:                             0.0 mm


 43.8760033  -> zufluss grundwasserleiter in  4567
TG:    4567 -> TG:    4588
Prozent:1.00


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:           51.0 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:          53.7 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -2.6 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.258 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.258 qkm



 Anzahl der Zeitschritte in iso durch Nachlauf zu hoch geworden.
 Sie wird auf 460 begrenzt !  gebiet :  4567

fuellenberechnung in iso
abflusz =           965.201
niederschlag =      966.868
flaeche zft  =        1.000
flaeche eing.=        0.258

GEBIET: Abflusswelle Interflow:
fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.258

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV:  fuellenberechnung
ISOV: Abflusz =          2384.736
ISOV: Niederschlag =     2384.734

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1069

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4588

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    2.16

 gesamtmenge an niederschlag (mm):       77.1

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     26


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  6.000


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4588
 anzahl hydrotope:      26


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      77.1 mm
 interz.verd.:                       7.1 mm
 bestandsniederschlag:              68.1 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      16.1 mm
 aktuelle verdunstung:              10.2 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              68.1 mm
 overlandflow:                       0.2 mm
 [infiltration:                     67.9 mm]
 verdunstung (bodensp.):             3.2 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -64.7 mm
 fehler:                             0.0 mm


 entnahme gws [qbm/s]:       0.000
 46.1225510  -> zufluss grundwasserleiter in  4588
TG:    4588 -> TG:    4598
Prozent:1.00


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:          120.1 mm
 abgabe basisabfluss:                 19.5 mm
        grundw. unterh.l.TG:         101.0 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.2 mm
     pot.entnahme GWS:                 0.2 mm
 speicherinhaltsaenderung:            -0.7 mm
 fehler:                               0.1 mm


 flaechenanteile: 

   grundwasserleiter:                0.115 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.115 qkm



 Anzahl der Zeitschritte in iso durch Nachlauf zu hoch geworden.
 Sie wird auf 460 begrenzt !  gebiet :  4588

fuellenberechnung in iso
abflusz =            18.426
niederschlag =       18.458
flaeche zft  =        1.000
flaeche eing.=        0.115

GEBIET: Abflusswelle Interflow:
fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.115

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV:  fuellenberechnung
ISOV: Abflusz =          1193.384
ISOV: Niederschlag =     1193.386

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         4580

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.

 Keine angeschlossenen Teilgebiete an Strang      4580
 Auswertung des Stranges:         4581

 Abflussverzoegerung mit Kalinin-Miljukov Parametern
 Keine angeschlossenen Teilgebiete an Strang      4581
 Auswertung des Stranges:         4626

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Fiktiver Strang! Es erfolgt keine Abflussverzoegerung!
 Keine angeschlossenen Teilgebiete an Strang      4626
 Auswertung des Stranges:         4571

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.

 Keine angeschlossenen Teilgebiete an Strang      4571
 Auswertung des Stranges:         4570

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.

 Keine angeschlossenen Teilgebiete an Strang      4570
 Auswertung des Stranges:         4572

 Abflussverzoegerung mit Kalinin-Miljukov Parametern
 Keine angeschlossenen Teilgebiete an Strang      4572
 Auswertung des Stranges:         4576

 Abflussverzoegerung mit Kalinin-Miljukov Parametern

 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 dt [h]:   0.08      tmax [d]:     4.85


 Kennwerte Zuflusswelle
 ----------------------

 Scheitel-Zufluss               iqzmax =   1397   qzmax =       0.184 [m**3/s]
 Scheitel-Zufluss im Gerinne    iqzfmx =   1397  qzfmax =       0.184 [m**3/s]
 Scheitel-Zufluss im Vorland    iqzvmx =      0  qzvmax =       0.000 [m**3/s]

 Fuelle-Zufluss                   fuqz =   0.0047 [hm**3]
 Fuelle-zufluss im Gerinne       fuqzf =   0.0047 [hm**3]
 Fuelle-zufluss im Vorland       fuqzv =   0.0000 [hm**3]


 Kennwerte der Systemfunktionen
 -------------------------------

 Anzahl der Zeitschritte  ituh =     18
 Maximum u                imax =      3     umax = 0.269426
 Summe u                   suu = 0.999998   suuh = 1.000000


 tmax [d]:     4.86


 Kennwerte Ausflusswelle
 -----------------------

 Endordinate Ausfluss           qaend =   0.000
 Scheitel-Ausfluss              iqmax =   1401    qmax =       0.183 [m**3/s]

 Fuelle-Ausfluss                  fuq =   0.0047 [hm**3]
 Fuelle-Ausfluss im Gerinne      fuqa =   0.0047 [hm**3]

 Scheitel-Ausfluss im Gerinne  iqamax =   1401   qamax =       0.183 [m**3/s]


 Gesamtzuflusswelle (ohne Basisabfluss)  sqz =       15.663
 Gesamtabflusswelle    "       "         sq  =       15.663


 Keine angeschlossenen Teilgebiete an Strang      4576
 Auswertung des Stranges:         4577

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Aufruf der Speicherroutine 


 zufluss-fuelle [hm]        0.007920 speicher 4577
 zusaetzl.zufl im nachl.ast [hm]  0.000076

 speicher   0.007996 abfluss-fuelle [hm]      4577

 speicherinhaltsaenderung [hm]  0.000006
 Keine angeschlossenen Teilgebiete an Strang      4577
 Auswertung des Stranges:         4578

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Abflussverzoegerung mit Kalinin-Miljukov Parametern

 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 dt [h]:   0.08      tmax [d]:     4.88


 Kennwerte Zuflusswelle
 ----------------------

 Scheitel-Zufluss               iqzmax =   1404   qzmax =       0.342 [m**3/s]
 Scheitel-Zufluss im Gerinne    iqzfmx =   1404  qzfmax =       0.342 [m**3/s]
 Scheitel-Zufluss im Vorland    iqzvmx =      0  qzvmax =       0.000 [m**3/s]

 Fuelle-Zufluss                   fuqz =   0.0080 [hm**3]
 Fuelle-zufluss im Gerinne       fuqzf =   0.0080 [hm**3]
 Fuelle-zufluss im Vorland       fuqzv =   0.0000 [hm**3]


 Kennwerte der Systemfunktionen
 -------------------------------

 Anzahl der Zeitschritte  ituh =     18
 Maximum u                imax =      3     umax = 0.269426
 Summe u                   suu = 0.999998   suuh = 1.000000


 tmax [d]:     4.89


 Kennwerte Ausflusswelle
 -----------------------

 Endordinate Ausfluss           qaend =   0.000
 Scheitel-Ausfluss              iqmax =   1407    qmax =       0.340 [m**3/s]

 Fuelle-Ausfluss                  fuq =   0.0080 [hm**3]
 Fuelle-Ausfluss im Gerinne      fuqa =   0.0080 [hm**3]

 Scheitel-Ausfluss im Gerinne  iqamax =   1407   qamax =       0.340 [m**3/s]


 Gesamtzuflusswelle (ohne Basisabfluss)  sqz =       26.657
 Gesamtabflusswelle    "       "         sq  =       26.657


 Keine angeschlossenen Teilgebiete an Strang      4578
 Auswertung des Stranges:         4579

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Fiktiver Strang! Es erfolgt keine Abflussverzoegerung!
 Keine angeschlossenen Teilgebiete an Strang      4579
 Auswertung des Stranges:         4620

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.

 Keine angeschlossenen Teilgebiete an Strang      4620
 Auswertung des Stranges:         4582

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Abflussverzoegerung mit Kalinin-Miljukov Parametern

 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 dt [h]:   0.08      tmax [d]:     4.89


 Kennwerte Zuflusswelle
 ----------------------

 Scheitel-Zufluss               iqzmax =   1407   qzmax =       0.349 [m**3/s]
 Scheitel-Zufluss im Gerinne    iqzfmx =   1407  qzfmax =       0.349 [m**3/s]
 Scheitel-Zufluss im Vorland    iqzvmx =      0  qzvmax =       0.000 [m**3/s]

 Fuelle-Zufluss                   fuqz =   0.0085 [hm**3]
 Fuelle-zufluss im Gerinne       fuqzf =   0.0085 [hm**3]
 Fuelle-zufluss im Vorland       fuqzv =   0.0000 [hm**3]


 Kennwerte der Systemfunktionen
 -------------------------------

 Anzahl der Zeitschritte  ituh =     18
 Maximum u                imax =      3     umax = 0.269426
 Summe u                   suu = 0.999998   suuh = 1.000000


 tmax [d]:     4.90


 Kennwerte Ausflusswelle
 -----------------------

 Endordinate Ausfluss           qaend =   0.000
 Scheitel-Ausfluss              iqmax =   1410    qmax =       0.348 [m**3/s]

 Fuelle-Ausfluss                  fuq =   0.0085 [hm**3]
 Fuelle-Ausfluss im Gerinne      fuqa =   0.0085 [hm**3]

 Scheitel-Ausfluss im Gerinne  iqamax =   1410   qamax =       0.348 [m**3/s]


 Gesamtzuflusswelle (ohne Basisabfluss)  sqz =       28.262
 Gesamtabflusswelle    "       "         sq  =       28.262


 Keine angeschlossenen Teilgebiete an Strang      4582
 Auswertung des Stranges:         4583

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Abflussverzoegerung mit Kalinin-Miljukov Parametern

 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 dt [h]:   0.08      tmax [d]:     4.89


 Kennwerte Zuflusswelle
 ----------------------

 Scheitel-Zufluss               iqzmax =   1409   qzmax =       0.378 [m**3/s]
 Scheitel-Zufluss im Gerinne    iqzfmx =   1409  qzfmax =       0.378 [m**3/s]
 Scheitel-Zufluss im Vorland    iqzvmx =      0  qzvmax =       0.000 [m**3/s]

 Fuelle-Zufluss                   fuqz =   0.0140 [hm**3]
 Fuelle-zufluss im Gerinne       fuqzf =   0.0140 [hm**3]
 Fuelle-zufluss im Vorland       fuqzv =   0.0000 [hm**3]


 Kennwerte der Systemfunktionen
 -------------------------------

 Anzahl der Zeitschritte  ituh =     18
 Maximum u                imax =      3     umax = 0.269426
 Summe u                   suu = 0.999998   suuh = 1.000000


 tmax [d]:     4.91


 Kennwerte Ausflusswelle
 -----------------------

 Endordinate Ausfluss           qaend =   0.000
 Scheitel-Ausfluss              iqmax =   1413    qmax =       0.376 [m**3/s]

 Fuelle-Ausfluss                  fuq =   0.0140 [hm**3]
 Fuelle-Ausfluss im Gerinne      fuqa =   0.0140 [hm**3]

 Scheitel-Ausfluss im Gerinne  iqamax =   1413   qamax =       0.376 [m**3/s]


 Gesamtzuflusswelle (ohne Basisabfluss)  sqz =       46.639
 Gesamtabflusswelle    "       "         sq  =       46.639


 Keine angeschlossenen Teilgebiete an Strang      4583
 Auswertung des Stranges:         4627

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Fiktiver Strang! Es erfolgt keine Abflussverzoegerung!
 Keine angeschlossenen Teilgebiete an Strang      4627
 Auswertung des Stranges:         4567

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.

 Keine angeschlossenen Teilgebiete an Strang      4567
 Auswertung des Stranges:         4568

 Aufruf der Speicherroutine 


 zufluss-fuelle [hm]        0.003233 speicher 4568
 zusaetzl.zufl im nachl.ast [hm]  0.000117

 speicher   0.003350 abfluss-fuelle [hm]      4568

 speicherinhaltsaenderung [hm]  0.000000
 Keine angeschlossenen Teilgebiete an Strang      4568
 Auswertung des Stranges:         4617

 Fiktiver Strang! Es erfolgt keine Abflussverzoegerung!
 Keine angeschlossenen Teilgebiete an Strang      4617
 Auswertung des Stranges:         4527

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.

 Keine angeschlossenen Teilgebiete an Strang      4527
 Auswertung des Stranges:         4528

 Aufruf der Speicherroutine 


 zufluss-fuelle [hm]        0.002846 speicher 4528
 zusaetzl.zufl im nachl.ast [hm]  0.000089

 speicher   0.002935 abfluss-fuelle [hm]      4528

 speicherinhaltsaenderung [hm]  0.000002
 Keine angeschlossenen Teilgebiete an Strang      4528
 Auswertung des Stranges:         4623

 Abflussverzoegerung mit Kalinin-Miljukov Parametern

 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 dt [h]:   0.08      tmax [d]:     4.96


 Kennwerte Zuflusswelle
 ----------------------

 Scheitel-Zufluss               iqzmax =   1428   qzmax =       0.068 [m**3/s]
 Scheitel-Zufluss im Gerinne    iqzfmx =   1428  qzfmax =       0.068 [m**3/s]
 Scheitel-Zufluss im Vorland    iqzvmx =      0  qzvmax =       0.000 [m**3/s]

 Fuelle-Zufluss                   fuqz =   0.0029 [hm**3]
 Fuelle-zufluss im Gerinne       fuqzf =   0.0029 [hm**3]
 Fuelle-zufluss im Vorland       fuqzv =   0.0000 [hm**3]


 Kennwerte der Systemfunktionen
 -------------------------------

 Anzahl der Zeitschritte  ituh =     18
 Maximum u                imax =      3     umax = 0.269426
 Summe u                   suu = 0.999998   suuh = 1.000000


 tmax [d]:     4.97


 Kennwerte Ausflusswelle
 -----------------------

 Endordinate Ausfluss           qaend =   0.000
 Scheitel-Ausfluss              iqmax =   1432    qmax =       0.068 [m**3/s]

 Fuelle-Ausfluss                  fuq =   0.0029 [hm**3]
 Fuelle-Ausfluss im Gerinne      fuqa =   0.0029 [hm**3]

 Scheitel-Ausfluss im Gerinne  iqamax =   1432   qamax =       0.068 [m**3/s]


 Gesamtzuflusswelle (ohne Basisabfluss)  sqz =        9.783
 Gesamtabflusswelle    "       "         sq  =        9.783


 Keine angeschlossenen Teilgebiete an Strang      4623
 Auswertung des Stranges:         4624

 Fiktiver Strang! Es erfolgt keine Abflussverzoegerung!
 Keine angeschlossenen Teilgebiete an Strang      4624
 Auswertung des Stranges:         4610

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.

 Keine angeschlossenen Teilgebiete an Strang      4610
 Auswertung des Stranges:         4531

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Aufruf der Speicherroutine 


 zufluss-fuelle [hm]        0.006869 speicher 4531
 zusaetzl.zufl im nachl.ast [hm]  0.000174

 speicher   0.007042 abfluss-fuelle [hm]      4531

 speicherinhaltsaenderung [hm]  0.000001
 Keine angeschlossenen Teilgebiete an Strang      4531
 Auswertung des Stranges:         4625

 Fiktiver Strang! Es erfolgt keine Abflussverzoegerung!
 Keine angeschlossenen Teilgebiete an Strang      4625
 Auswertung des Stranges:         4520

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.

 Keine angeschlossenen Teilgebiete an Strang      4520
 Auswertung des Stranges:         4521

 Aufruf der Speicherroutine 


 zufluss-fuelle [hm]        0.004613 speicher 4521
 zusaetzl.zufl im nachl.ast [hm]  0.000092

 speicher   0.004705 abfluss-fuelle [hm]      4521

 speicherinhaltsaenderung [hm]  0.000000
 Keine angeschlossenen Teilgebiete an Strang      4521
 Auswertung des Stranges:         4608

 Fiktiver Strang! Es erfolgt keine Abflussverzoegerung!
 Keine angeschlossenen Teilgebiete an Strang      4608
 Auswertung des Stranges:         4514

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.

 Keine angeschlossenen Teilgebiete an Strang      4514
 Auswertung des Stranges:         4515

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Abflussverzoegerung mit Kalinin-Miljukov Parametern

 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 dt [h]:   0.08      tmax [d]:     4.89


 Kennwerte Zuflusswelle
 ----------------------

 Scheitel-Zufluss               iqzmax =   1409   qzmax =       0.389 [m**3/s]
 Scheitel-Zufluss im Gerinne    iqzfmx =   1409  qzfmax =       0.389 [m**3/s]
 Scheitel-Zufluss im Vorland    iqzvmx =      0  qzvmax =       0.000 [m**3/s]

 Fuelle-Zufluss                   fuqz =   0.0108 [hm**3]
 Fuelle-zufluss im Gerinne       fuqzf =   0.0108 [hm**3]
 Fuelle-zufluss im Vorland       fuqzv =   0.0000 [hm**3]


 Kennwerte der Systemfunktionen
 -------------------------------

 Anzahl der Zeitschritte  ituh =     18
 Maximum u                imax =      3     umax = 0.269426
 Summe u                   suu = 0.999998   suuh = 1.000000


 tmax [d]:     4.91


 Kennwerte Ausflusswelle
 -----------------------

 Endordinate Ausfluss           qaend =   0.000
 Scheitel-Ausfluss              iqmax =   1413    qmax =       0.388 [m**3/s]

 Fuelle-Ausfluss                  fuq =   0.0108 [hm**3]
 Fuelle-Ausfluss im Gerinne      fuqa =   0.0108 [hm**3]

 Scheitel-Ausfluss im Gerinne  iqamax =   1413   qamax =       0.388 [m**3/s]


 Gesamtzuflusswelle (ohne Basisabfluss)  sqz =       36.107
 Gesamtabflusswelle    "       "         sq  =       36.107


 Keine angeschlossenen Teilgebiete an Strang      4515
 Auswertung des Stranges:         4516

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Aufruf der Speicherroutine 


 zufluss-fuelle [hm]        0.012412 speicher 4516
 zusaetzl.zufl im nachl.ast [hm]  0.000266

 speicher   0.012677 abfluss-fuelle [hm]      4516

 speicherinhaltsaenderung [hm]  0.000000
 Keine angeschlossenen Teilgebiete an Strang      4516
 Auswertung des Stranges:         4517

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Abflussverzoegerung mit Kalinin-Miljukov Parametern

 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 dt [h]:   0.08      tmax [d]:     4.89


 Kennwerte Zuflusswelle
 ----------------------

 Scheitel-Zufluss               iqzmax =   1409   qzmax =       0.447 [m**3/s]
 Scheitel-Zufluss im Gerinne    iqzfmx =   1409  qzfmax =       0.447 [m**3/s]
 Scheitel-Zufluss im Vorland    iqzvmx =      0  qzvmax =       0.000 [m**3/s]

 Fuelle-Zufluss                   fuqz =   0.0127 [hm**3]
 Fuelle-zufluss im Gerinne       fuqzf =   0.0127 [hm**3]
 Fuelle-zufluss im Vorland       fuqzv =   0.0000 [hm**3]


 Kennwerte der Systemfunktionen
 -------------------------------

 Anzahl der Zeitschritte  ituh =     18
 Maximum u                imax =      3     umax = 0.269426
 Summe u                   suu = 0.999998   suuh = 1.000000


 tmax [d]:     4.91


 Kennwerte Ausflusswelle
 -----------------------

 Endordinate Ausfluss           qaend =   0.000
 Scheitel-Ausfluss              iqmax =   1413    qmax =       0.446 [m**3/s]

 Fuelle-Ausfluss                  fuq =   0.0127 [hm**3]
 Fuelle-Ausfluss im Gerinne      fuqa =   0.0127 [hm**3]

 Scheitel-Ausfluss im Gerinne  iqamax =   1413   qamax =       0.446 [m**3/s]


 Gesamtzuflusswelle (ohne Basisabfluss)  sqz =       42.265
 Gesamtabflusswelle    "       "         sq  =       42.265


 Keine angeschlossenen Teilgebiete an Strang      4517
 Auswertung des Stranges:         4518

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Aufruf der Speicherroutine 


 zufluss-fuelle [hm]        0.012334 speicher 4518
 zusaetzl.zufl im nachl.ast [hm]  0.000417

 speicher   0.012750 abfluss-fuelle [hm]      4518

 speicherinhaltsaenderung [hm]  0.000054
 Keine angeschlossenen Teilgebiete an Strang      4518
 Auswertung des Stranges:         4607

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Fiktiver Strang! Es erfolgt keine Abflussverzoegerung!
 Keine angeschlossenen Teilgebiete an Strang      4607
 Auswertung des Stranges:         4512

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.

 Keine angeschlossenen Teilgebiete an Strang      4512
 Auswertung des Stranges:         4513

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Abflussverzoegerung mit Kalinin-Miljukov Parametern

 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 dt [h]:   0.08      tmax [d]:     4.89


 Kennwerte Zuflusswelle
 ----------------------

 Scheitel-Zufluss               iqzmax =   1409   qzmax =       0.187 [m**3/s]
 Scheitel-Zufluss im Gerinne    iqzfmx =   1409  qzfmax =       0.187 [m**3/s]
 Scheitel-Zufluss im Vorland    iqzvmx =      0  qzvmax =       0.000 [m**3/s]

 Fuelle-Zufluss                   fuqz =   0.0051 [hm**3]
 Fuelle-zufluss im Gerinne       fuqzf =   0.0051 [hm**3]
 Fuelle-zufluss im Vorland       fuqzv =   0.0000 [hm**3]


 Kennwerte der Systemfunktionen
 -------------------------------

 Anzahl der Zeitschritte  ituh =     18
 Maximum u                imax =      3     umax = 0.269426
 Summe u                   suu = 0.999998   suuh = 1.000000


 tmax [d]:     4.91


 Kennwerte Ausflusswelle
 -----------------------

 Endordinate Ausfluss           qaend =   0.000
 Scheitel-Ausfluss              iqmax =   1413    qmax =       0.187 [m**3/s]

 Fuelle-Ausfluss                  fuq =   0.0051 [hm**3]
 Fuelle-Ausfluss im Gerinne      fuqa =   0.0051 [hm**3]

 Scheitel-Ausfluss im Gerinne  iqamax =   1413   qamax =       0.187 [m**3/s]


 Gesamtzuflusswelle (ohne Basisabfluss)  sqz =       16.958
 Gesamtabflusswelle    "       "         sq  =       16.958


 Keine angeschlossenen Teilgebiete an Strang      4513
 Auswertung des Stranges:         4519

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Abflussverzoegerung mit Kalinin-Miljukov Parametern

 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 dt [h]:   0.08      tmax [d]:     4.90


 Kennwerte Zuflusswelle
 ----------------------

 Scheitel-Zufluss               iqzmax =   1412   qzmax =       0.270 [m**3/s]
 Scheitel-Zufluss im Gerinne    iqzfmx =   1412  qzfmax =       0.270 [m**3/s]
 Scheitel-Zufluss im Vorland    iqzvmx =      0  qzvmax =       0.000 [m**3/s]

 Fuelle-Zufluss                   fuqz =   0.0074 [hm**3]
 Fuelle-zufluss im Gerinne       fuqzf =   0.0074 [hm**3]
 Fuelle-zufluss im Vorland       fuqzv =   0.0000 [hm**3]


 Kennwerte der Systemfunktionen
 -------------------------------

 Anzahl der Zeitschritte  ituh =     18
 Maximum u                imax =      3     umax = 0.269426
 Summe u                   suu = 0.999998   suuh = 1.000000


 tmax [d]:     4.91


 Kennwerte Ausflusswelle
 -----------------------

 Endordinate Ausfluss           qaend =   0.000
 Scheitel-Ausfluss              iqmax =   1415    qmax =       0.270 [m**3/s]

 Fuelle-Ausfluss                  fuq =   0.0074 [hm**3]
 Fuelle-Ausfluss im Gerinne      fuqa =   0.0074 [hm**3]

 Scheitel-Ausfluss im Gerinne  iqamax =   1415   qamax =       0.270 [m**3/s]


 Gesamtzuflusswelle (ohne Basisabfluss)  sqz =       24.613
 Gesamtabflusswelle    "       "         sq  =       24.613


 Keine angeschlossenen Teilgebiete an Strang      4519
 Auswertung des Stranges:         4522

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Abflussverzoegerung mit Kalinin-Miljukov Parametern

 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 dt [h]:   0.08      tmax [d]:     4.91


 Kennwerte Zuflusswelle
 ----------------------

 Scheitel-Zufluss               iqzmax =   1413   qzmax =       0.890 [m**3/s]
 Scheitel-Zufluss im Gerinne    iqzfmx =   1413  qzfmax =       0.890 [m**3/s]
 Scheitel-Zufluss im Vorland    iqzvmx =      0  qzvmax =       0.000 [m**3/s]

 Fuelle-Zufluss                   fuqz =   0.0249 [hm**3]
 Fuelle-zufluss im Gerinne       fuqzf =   0.0249 [hm**3]
 Fuelle-zufluss im Vorland       fuqzv =   0.0000 [hm**3]


 Kennwerte der Systemfunktionen
 -------------------------------

 Anzahl der Zeitschritte  ituh =   2880
 Maximum u                imax =      0     umax = 0.000000
 Summe u                   suu = 0.000000   suuh = 0.000000


 tmax [d]:     0.00


 Kennwerte Ausflusswelle
 -----------------------


 Endordinate Ausfluss           qaend =   0.000

 Scheitel-Ausfluss              iqmax =   1417    qmax =       0.887 [m**3/s]


 Fuelle-Ausfluss                  fuq =   0.0249 [hm**3]

 Fuelle-Ausfluss im Gerinne      fuqa =   0.0249 [hm**3]

 Fuelle-Ausfluss im vorland      fuqa =   0.0000 [hm**3]


 Scheitel-Ausfluss im Gerinne  iqamax =   1417   qamax =       0.887 [m**3/s]

 Scheitel-Ausfluss im Vorland  iqamax =      0   qamax =       0.000 [m**3/s]


 Gesamtzuflusswelle (ohne Basisabfluss)  sqz =       83.055
 Gesamtabflusswelle    "       "         sq  =       83.055


 Keine angeschlossenen Teilgebiete an Strang      4522
 Auswertung des Stranges:         4524

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Abflussverzoegerung mit Kalinin-Miljukov Parametern

 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 dt [h]:   0.08      tmax [d]:     4.91


 Kennwerte Zuflusswelle
 ----------------------

 Scheitel-Zufluss               iqzmax =   1415   qzmax =       1.217 [m**3/s]
 Scheitel-Zufluss im Gerinne    iqzfmx =   1415  qzfmax =       1.217 [m**3/s]
 Scheitel-Zufluss im Vorland    iqzvmx =      0  qzvmax =       0.000 [m**3/s]

 Fuelle-Zufluss                   fuqz =   0.0361 [hm**3]
 Fuelle-zufluss im Gerinne       fuqzf =   0.0361 [hm**3]
 Fuelle-zufluss im Vorland       fuqzv =   0.0000 [hm**3]


 Kennwerte der Systemfunktionen
 -------------------------------

 Anzahl der Zeitschritte  ituh =   2880
 Maximum u                imax =      0     umax = 0.000000
 Summe u                   suu = 0.000000   suuh = 0.000000


 tmax [d]:     0.00


 Kennwerte Ausflusswelle
 -----------------------


 Endordinate Ausfluss           qaend =   0.001

 Scheitel-Ausfluss              iqmax =   1418    qmax =       1.210 [m**3/s]


 Fuelle-Ausfluss                  fuq =   0.0361 [hm**3]

 Fuelle-Ausfluss im Gerinne      fuqa =   0.0361 [hm**3]

 Fuelle-Ausfluss im vorland      fuqa =   0.0000 [hm**3]


 Scheitel-Ausfluss im Gerinne  iqamax =   1418   qamax =       1.210 [m**3/s]

 Scheitel-Ausfluss im Vorland  iqamax =      0   qamax =       0.000 [m**3/s]


 Gesamtzuflusswelle (ohne Basisabfluss)  sqz =      120.420
 Gesamtabflusswelle    "       "         sq  =      120.420


 Keine angeschlossenen Teilgebiete an Strang      4524
 Auswertung des Stranges:         4525

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Aufruf der Speicherroutine 


 zufluss-fuelle [hm]        0.042204 speicher 4525
 zusaetzl.zufl im nachl.ast [hm]  0.001353

 speicher   0.043555 abfluss-fuelle [hm]      4525

 speicherinhaltsaenderung [hm]  0.000000
 Keine angeschlossenen Teilgebiete an Strang      4525
 Auswertung des Stranges:         4609

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Fiktiver Strang! Es erfolgt keine Abflussverzoegerung!
 Keine angeschlossenen Teilgebiete an Strang      4609
 Auswertung des Stranges:         4500

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.

 Keine angeschlossenen Teilgebiete an Strang      4500
 Auswertung des Stranges:         4501

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Abflussverzoegerung mit Kalinin-Miljukov Parametern

 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 dt [h]:   0.08      tmax [d]:     4.93


 Kennwerte Zuflusswelle
 ----------------------

 Scheitel-Zufluss               iqzmax =   1419   qzmax =       0.478 [m**3/s]
 Scheitel-Zufluss im Gerinne    iqzfmx =   1467  qzfmax =       0.242 [m**3/s]
 Scheitel-Zufluss im Vorland    iqzvmx =   1419  qzvmax =       0.336 [m**3/s]

 Fuelle-Zufluss                   fuqz =   0.0189 [hm**3]
 Fuelle-zufluss im Gerinne       fuqzf =   0.0135 [hm**3]
 Fuelle-zufluss im Vorland       fuqzv =   0.0053 [hm**3]


 Kennwerte der Systemfunktionen
 -------------------------------

 Anzahl der Zeitschritte  ituh =     34
 Maximum u                imax =      3     umax = 0.173632
 Summe u                   suu = 1.000082   suuh = 1.000000


 tmax [d]:     4.93


 Kennwerte Ausflusswelle
 -----------------------


 Endordinate Ausfluss           qaend =   0.000

 Scheitel-Ausfluss              iqmax =   1417    qmax =       0.480 [m**3/s]


 Fuelle-Ausfluss                  fuq =   0.0189 [hm**3]

 Fuelle-Ausfluss im Gerinne      fuqa =   0.0135 [hm**3]

 Fuelle-Ausfluss im vorland      fuqa =   0.0053 [hm**3]


 Scheitel-Ausfluss im Gerinne  iqamax =   1468   qamax =       0.241 [m**3/s]

 Scheitel-Ausfluss im Vorland  iqamax =   1419   qamax =       0.336 [m**3/s]


 Gesamtzuflusswelle (ohne Basisabfluss)  sqz =       62.881
 Gesamtabflusswelle    "       "         sq  =       62.869


 Keine angeschlossenen Teilgebiete an Strang      4501
 Auswertung des Stranges:         4502

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Aufruf der Speicherroutine 


 zufluss-fuelle [hm]        0.031769 speicher 4502
 zusaetzl.zufl im nachl.ast [hm]  0.000856

 speicher   0.032625 abfluss-fuelle [hm]      4502

 speicherinhaltsaenderung [hm]  0.000000
 Keine angeschlossenen Teilgebiete an Strang      4502
 Auswertung des Stranges:         4506

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Abflussverzoegerung mit Kalinin-Miljukov Parametern

 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 dt [h]:   0.08      tmax [d]:     4.93


 Kennwerte Zuflusswelle
 ----------------------

 Scheitel-Zufluss               iqzmax =   1419   qzmax =       0.895 [m**3/s]
 Scheitel-Zufluss im Gerinne    iqzfmx =   1497  qzfmax =       0.242 [m**3/s]
 Scheitel-Zufluss im Vorland    iqzvmx =   1419  qzvmax =       0.740 [m**3/s]

 Fuelle-Zufluss                   fuqz =   0.0326 [hm**3]
 Fuelle-zufluss im Gerinne       fuqzf =   0.0172 [hm**3]
 Fuelle-zufluss im Vorland       fuqzv =   0.0155 [hm**3]


 Kennwerte der Systemfunktionen
 -------------------------------

 Anzahl der Zeitschritte  ituh =     34
 Maximum u                imax =      3     umax = 0.173632
 Summe u                   suu = 1.000082   suuh = 1.000000


 tmax [d]:     4.94


 Kennwerte Ausflusswelle
 -----------------------


 Endordinate Ausfluss           qaend =   0.000

 Scheitel-Ausfluss              iqmax =   1423    qmax =       0.891 [m**3/s]


 Fuelle-Ausfluss                  fuq =   0.0324 [hm**3]

 Fuelle-Ausfluss im Gerinne      fuqa =   0.0171 [hm**3]

 Fuelle-Ausfluss im vorland      fuqa =   0.0152 [hm**3]


 Scheitel-Ausfluss im Gerinne  iqamax =   1499   qamax =       0.241 [m**3/s]

 Scheitel-Ausfluss im Vorland  iqamax =   1423   qamax =       0.737 [m**3/s]


 Gesamtzuflusswelle (ohne Basisabfluss)  sqz =      108.790
 Gesamtabflusswelle    "       "         sq  =      107.945


 Keine angeschlossenen Teilgebiete an Strang      4506
 Auswertung des Stranges:         4510

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Abflussverzoegerung mit Kalinin-Miljukov Parametern

 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 dt [h]:   0.08      tmax [d]:     4.93


 Kennwerte Zuflusswelle
 ----------------------

 Scheitel-Zufluss               iqzmax =   1420   qzmax =       1.562 [m**3/s]
 Scheitel-Zufluss im Gerinne    iqzfmx =   1420  qzfmax =       1.562 [m**3/s]
 Scheitel-Zufluss im Vorland    iqzvmx =      0  qzvmax =       0.000 [m**3/s]

 Fuelle-Zufluss                   fuqz =   0.0636 [hm**3]
 Fuelle-zufluss im Gerinne       fuqzf =   0.0636 [hm**3]
 Fuelle-zufluss im Vorland       fuqzv =   0.0000 [hm**3]


 Kennwerte der Systemfunktionen
 -------------------------------

 Anzahl der Zeitschritte  ituh =    357
 Maximum u                imax =      1     umax = 0.272856
 Summe u                   suu = 0.654153   suuh = 1.000000


 tmax [d]:     4.95


 Kennwerte Ausflusswelle
 -----------------------

 Endordinate Ausfluss           qaend =   0.000
 Scheitel-Ausfluss              iqmax =   1425    qmax =       1.502 [m**3/s]

 Fuelle-Ausfluss                  fuq =   0.0636 [hm**3]
 Fuelle-Ausfluss im Gerinne      fuqa =   0.0636 [hm**3]

 Scheitel-Ausfluss im Gerinne  iqamax =   1425   qamax =       1.502 [m**3/s]


 Gesamtzuflusswelle (ohne Basisabfluss)  sqz =      212.029
 Gesamtabflusswelle    "       "         sq  =      212.027


 Keine angeschlossenen Teilgebiete an Strang      4510
 Auswertung des Stranges:         4526

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Abflussverzoegerung mit Kalinin-Miljukov Parametern

 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 dt [h]:   0.08      tmax [d]:     4.92


 Kennwerte Zuflusswelle
 ----------------------

 Scheitel-Zufluss               iqzmax =   1417   qzmax =       2.646 [m**3/s]
 Scheitel-Zufluss im Gerinne    iqzfmx =   1417  qzfmax =       2.646 [m**3/s]
 Scheitel-Zufluss im Vorland    iqzvmx =      0  qzvmax =       0.000 [m**3/s]

 Fuelle-Zufluss                   fuqz =   0.1032 [hm**3]
 Fuelle-zufluss im Gerinne       fuqzf =   0.1032 [hm**3]
 Fuelle-zufluss im Vorland       fuqzv =   0.0000 [hm**3]


 Kennwerte der Systemfunktionen
 -------------------------------

 Anzahl der Zeitschritte  ituh =     27
 Maximum u                imax =      1     umax = 0.557957
 Summe u                   suu = 0.784427   suuh = 1.000000


 tmax [d]:     4.92


 Kennwerte Ausflusswelle
 -----------------------

 Endordinate Ausfluss           qaend =   0.000
 Scheitel-Ausfluss              iqmax =   1418    qmax =       2.643 [m**3/s]

 Fuelle-Ausfluss                  fuq =   0.1032 [hm**3]
 Fuelle-Ausfluss im Gerinne      fuqa =   0.1032 [hm**3]

 Scheitel-Ausfluss im Gerinne  iqamax =   1418   qamax =       2.643 [m**3/s]


 Gesamtzuflusswelle (ohne Basisabfluss)  sqz =      344.071
 Gesamtabflusswelle    "       "         sq  =      344.072


 Keine angeschlossenen Teilgebiete an Strang      4526
 Auswertung des Stranges:         4532

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Abflussverzoegerung mit Kalinin-Miljukov Parametern

 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 dt [h]:   0.08      tmax [d]:     4.94


 Kennwerte Zuflusswelle
 ----------------------

 Scheitel-Zufluss               iqzmax =   1423   qzmax =       3.691 [m**3/s]
 Scheitel-Zufluss im Gerinne    iqzfmx =   1423  qzfmax =       1.851 [m**3/s]
 Scheitel-Zufluss im Vorland    iqzvmx =   1423  qzvmax =       1.841 [m**3/s]

 Fuelle-Zufluss                   fuqz =   0.1538 [hm**3]
 Fuelle-zufluss im Gerinne       fuqzf =   0.1200 [hm**3]
 Fuelle-zufluss im Vorland       fuqzv =   0.0338 [hm**3]


 Kennwerte der Systemfunktionen
 -------------------------------

 Anzahl der Zeitschritte  ituh =     58
 Maximum u                imax =      1     umax = 0.450462
 Summe u                   suu = 0.778253   suuh = 0.999630


 tmax [d]:     4.95


 Kennwerte Ausflusswelle
 -----------------------


 Endordinate Ausfluss           qaend =   0.000

 Scheitel-Ausfluss              iqmax =   1425    qmax =       3.657 [m**3/s]


 Fuelle-Ausfluss                  fuq =   0.1538 [hm**3]

 Fuelle-Ausfluss im Gerinne      fuqa =   0.1199 [hm**3]

 Fuelle-Ausfluss im vorland      fuqa =   0.0339 [hm**3]


 Scheitel-Ausfluss im Gerinne  iqamax =   1426   qamax =       1.829 [m**3/s]

 Scheitel-Ausfluss im Vorland  iqamax =   1425   qamax =       1.829 [m**3/s]


 Gesamtzuflusswelle (ohne Basisabfluss)  sqz =      512.659
 Gesamtabflusswelle    "       "         sq  =      512.729


 Keine angeschlossenen Teilgebiete an Strang      4532
 Auswertung des Stranges:         4563

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Abflussverzoegerung mit Kalinin-Miljukov Parametern

 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 dt [h]:   0.08      tmax [d]:     4.94


 Kennwerte Zuflusswelle
 ----------------------

 Scheitel-Zufluss               iqzmax =   1424   qzmax =       3.983 [m**3/s]
 Scheitel-Zufluss im Gerinne    iqzfmx =   1424  qzfmax =       3.898 [m**3/s]
 Scheitel-Zufluss im Vorland    iqzvmx =   1424  qzvmax =       0.084 [m**3/s]

 Fuelle-Zufluss                   fuqz =   0.1696 [hm**3]
 Fuelle-zufluss im Gerinne       fuqzf =   0.1692 [hm**3]
 Fuelle-zufluss im Vorland       fuqzv =   0.0004 [hm**3]


 Kennwerte der Systemfunktionen
 -------------------------------

 Anzahl der Zeitschritte  ituh =     68
 Maximum u                imax =      1     umax = 0.284769
 Summe u                   suu = 0.990478   suuh = 1.000000


 tmax [d]:     4.95


 Kennwerte Ausflusswelle
 -----------------------


 Endordinate Ausfluss           qaend =   0.001

 Scheitel-Ausfluss              iqmax =   1426    qmax =       3.967 [m**3/s]


 Fuelle-Ausfluss                  fuq =   0.1696 [hm**3]

 Fuelle-Ausfluss im Gerinne      fuqa =   0.1692 [hm**3]

 Fuelle-Ausfluss im vorland      fuqa =   0.0004 [hm**3]


 Scheitel-Ausfluss im Gerinne  iqamax =   1425   qamax =       3.896 [m**3/s]

 Scheitel-Ausfluss im Vorland  iqamax =   1427   qamax =       0.073 [m**3/s]


 Gesamtzuflusswelle (ohne Basisabfluss)  sqz =      565.180
 Gesamtabflusswelle    "       "         sq  =      565.179


 Keine angeschlossenen Teilgebiete an Strang      4563
 Auswertung des Stranges:         4541

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.

 Keine angeschlossenen Teilgebiete an Strang      4541
 Auswertung des Stranges:         4534

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.

 Keine angeschlossenen Teilgebiete an Strang      4534
 Auswertung des Stranges:         4535

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Abflussverzoegerung mit Kalinin-Miljukov Parametern

 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 dt [h]:   0.08      tmax [d]:     4.80


 Kennwerte Zuflusswelle
 ----------------------

 Scheitel-Zufluss               iqzmax =   1383   qzmax =       1.081 [m**3/s]
 Scheitel-Zufluss im Gerinne    iqzfmx =   1383  qzfmax =       1.081 [m**3/s]
 Scheitel-Zufluss im Vorland    iqzvmx =      0  qzvmax =       0.000 [m**3/s]

 Fuelle-Zufluss                   fuqz =   0.0133 [hm**3]
 Fuelle-zufluss im Gerinne       fuqzf =   0.0133 [hm**3]
 Fuelle-zufluss im Vorland       fuqzv =   0.0000 [hm**3]


 Kennwerte der Systemfunktionen
 -------------------------------

 Anzahl der Zeitschritte  ituh =   2880
 Maximum u                imax =      1     umax = 0.000000
 Summe u                   suu = 0.000000   suuh = 0.000000


 tmax [d]:     0.00


 Kennwerte Ausflusswelle
 -----------------------


 Endordinate Ausfluss           qaend =   0.001

 Scheitel-Ausfluss              iqmax =   1386    qmax =       0.991 [m**3/s]


 Fuelle-Ausfluss                  fuq =   0.0133 [hm**3]

 Fuelle-Ausfluss im Gerinne      fuqa =   0.0133 [hm**3]

 Fuelle-Ausfluss im vorland      fuqa =   0.0000 [hm**3]


 Scheitel-Ausfluss im Gerinne  iqamax =   1386   qamax =       0.991 [m**3/s]

 Scheitel-Ausfluss im Vorland  iqamax =      0   qamax =       0.000 [m**3/s]


 Gesamtzuflusswelle (ohne Basisabfluss)  sqz =       44.248
 Gesamtabflusswelle    "       "         sq  =       44.248


 Keine angeschlossenen Teilgebiete an Strang      4535
 Auswertung des Stranges:         4536

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Aufruf der Speicherroutine 


 zufluss-fuelle [hm]        0.018029 speicher 4536
 zusaetzl.zufl im nachl.ast [hm]  0.000148

 speicher   0.018177 abfluss-fuelle [hm]      4536

 speicherinhaltsaenderung [hm]  0.000000
 Keine angeschlossenen Teilgebiete an Strang      4536
 Auswertung des Stranges:         4612

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Fiktiver Strang! Es erfolgt keine Abflussverzoegerung!
 Keine angeschlossenen Teilgebiete an Strang      4612
 Auswertung des Stranges:         4537

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.

 Keine angeschlossenen Teilgebiete an Strang      4537
 Auswertung des Stranges:         4538

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Abflussverzoegerung mit Kalinin-Miljukov Parametern

 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 dt [h]:   0.08      tmax [d]:     4.83


 Kennwerte Zuflusswelle
 ----------------------

 Scheitel-Zufluss               iqzmax =   1390   qzmax =       0.094 [m**3/s]
 Scheitel-Zufluss im Gerinne    iqzfmx =   1390  qzfmax =       0.094 [m**3/s]
 Scheitel-Zufluss im Vorland    iqzvmx =      0  qzvmax =       0.000 [m**3/s]

 Fuelle-Zufluss                   fuqz =   0.0017 [hm**3]
 Fuelle-zufluss im Gerinne       fuqzf =   0.0017 [hm**3]
 Fuelle-zufluss im Vorland       fuqzv =   0.0000 [hm**3]


 Kennwerte der Systemfunktionen
 -------------------------------

 Anzahl der Zeitschritte  ituh =     25
 Maximum u                imax =      1     umax = 0.540740
 Summe u                   suu = 0.727210   suuh = 1.000000


 tmax [d]:     4.83


 Kennwerte Ausflusswelle
 -----------------------

 Endordinate Ausfluss           qaend =   0.000
 Scheitel-Ausfluss              iqmax =   1391    qmax =       0.092 [m**3/s]

 Fuelle-Ausfluss                  fuq =   0.0017 [hm**3]
 Fuelle-Ausfluss im Gerinne      fuqa =   0.0017 [hm**3]

 Scheitel-Ausfluss im Gerinne  iqamax =   1391   qamax =       0.092 [m**3/s]


 Gesamtzuflusswelle (ohne Basisabfluss)  sqz =        5.518
 Gesamtabflusswelle    "       "         sq  =        5.518


 Keine angeschlossenen Teilgebiete an Strang      4538
 Auswertung des Stranges:         4539

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Abflussverzoegerung mit Kalinin-Miljukov Parametern

 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 dt [h]:   0.08      tmax [d]:     4.82


 Kennwerte Zuflusswelle
 ----------------------

 Scheitel-Zufluss               iqzmax =   1388   qzmax =       1.260 [m**3/s]
 Scheitel-Zufluss im Gerinne    iqzfmx =   1388  qzfmax =       1.008 [m**3/s]
 Scheitel-Zufluss im Vorland    iqzvmx =   1388  qzvmax =       0.252 [m**3/s]

 Fuelle-Zufluss                   fuqz =   0.0198 [hm**3]
 Fuelle-zufluss im Gerinne       fuqzf =   0.0189 [hm**3]
 Fuelle-zufluss im Vorland       fuqzv =   0.0009 [hm**3]


 Kennwerte der Systemfunktionen
 -------------------------------

 Anzahl der Zeitschritte  ituh =   2880
 Maximum u                imax =      1     umax = 0.000000
 Summe u                   suu = 0.000000   suuh = 0.000000


 tmax [d]:     4.82


 Kennwerte Ausflusswelle
 -----------------------


 Endordinate Ausfluss           qaend =   0.002

 Scheitel-Ausfluss              iqmax =   1388    qmax =       1.225 [m**3/s]


 Fuelle-Ausfluss                  fuq =   0.0198 [hm**3]

 Fuelle-Ausfluss im Gerinne      fuqa =   0.0189 [hm**3]

 Fuelle-Ausfluss im vorland      fuqa =   0.0009 [hm**3]


 Scheitel-Ausfluss im Gerinne  iqamax =   1388   qamax =       0.981 [m**3/s]

 Scheitel-Ausfluss im Vorland  iqamax =   1389   qamax =       0.244 [m**3/s]


 Gesamtzuflusswelle (ohne Basisabfluss)  sqz =       66.128
 Gesamtabflusswelle    "       "         sq  =       66.129


 Keine angeschlossenen Teilgebiete an Strang      4539
 Auswertung des Stranges:         4540

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Aufruf der Speicherroutine 


 zufluss-fuelle [hm]        0.069265 speicher 4540
 zusaetzl.zufl im nachl.ast [hm]  0.000254

 speicher   0.069484 abfluss-fuelle [hm]      4540

 speicherinhaltsaenderung [hm]  0.000000
 Keine angeschlossenen Teilgebiete an Strang      4540
 Auswertung des Stranges:         4613

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Fiktiver Strang! Es erfolgt keine Abflussverzoegerung!
 Keine angeschlossenen Teilgebiete an Strang      4613
 Auswertung des Stranges:         4546

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Abflussverzoegerung mit Kalinin-Miljukov Parametern

 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 dt [h]:   0.08      tmax [d]:     4.82


 Kennwerte Zuflusswelle
 ----------------------

 Scheitel-Zufluss               iqzmax =   1388   qzmax =       5.173 [m**3/s]
 Scheitel-Zufluss im Gerinne    iqzfmx =   1388  qzfmax =       4.138 [m**3/s]
 Scheitel-Zufluss im Vorland    iqzvmx =   1388  qzvmax =       1.035 [m**3/s]

 Fuelle-Zufluss                   fuqz =   0.0831 [hm**3]
 Fuelle-zufluss im Gerinne       fuqzf =   0.0728 [hm**3]
 Fuelle-zufluss im Vorland       fuqzv =   0.0103 [hm**3]


 Kennwerte der Systemfunktionen
 -------------------------------

 Anzahl der Zeitschritte  ituh =   2880
 Maximum u                imax =      1     umax = 0.000000
 Summe u                   suu = 0.000000   suuh = 0.000000


 tmax [d]:     4.82


 Kennwerte Ausflusswelle
 -----------------------


 Endordinate Ausfluss           qaend =   0.001

 Scheitel-Ausfluss              iqmax =   1389    qmax =       5.100 [m**3/s]


 Fuelle-Ausfluss                  fuq =   0.0831 [hm**3]

 Fuelle-Ausfluss im Gerinne      fuqa =   0.0728 [hm**3]

 Fuelle-Ausfluss im vorland      fuqa =   0.0103 [hm**3]


 Scheitel-Ausfluss im Gerinne  iqamax =   1389   qamax =       4.080 [m**3/s]

 Scheitel-Ausfluss im Vorland  iqamax =   1389   qamax =       1.020 [m**3/s]


 Gesamtzuflusswelle (ohne Basisabfluss)  sqz =      276.940
 Gesamtabflusswelle    "       "         sq  =      276.941


 Keine angeschlossenen Teilgebiete an Strang      4546
 Auswertung des Stranges:         4543

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.

 Keine angeschlossenen Teilgebiete an Strang      4543
 Auswertung des Stranges:         4544

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Abflussverzoegerung mit Kalinin-Miljukov Parametern

 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 dt [h]:   0.08      tmax [d]:     4.82


 Kennwerte Zuflusswelle
 ----------------------

 Scheitel-Zufluss               iqzmax =   1389   qzmax =       2.241 [m**3/s]
 Scheitel-Zufluss im Gerinne    iqzfmx =   1389  qzfmax =       1.793 [m**3/s]
 Scheitel-Zufluss im Vorland    iqzvmx =   1389  qzvmax =       0.448 [m**3/s]

 Fuelle-Zufluss                   fuqz =   0.0290 [hm**3]
 Fuelle-zufluss im Gerinne       fuqzf =   0.0262 [hm**3]
 Fuelle-zufluss im Vorland       fuqzv =   0.0028 [hm**3]


 Kennwerte der Systemfunktionen
 -------------------------------

 Anzahl der Zeitschritte  ituh =   2880
 Maximum u                imax =      1     umax = 0.000000
 Summe u                   suu = 0.000000   suuh = 0.000000


 tmax [d]:     4.82


 Kennwerte Ausflusswelle
 -----------------------


 Endordinate Ausfluss           qaend =   0.006

 Scheitel-Ausfluss              iqmax =   1389    qmax =       2.207 [m**3/s]


 Fuelle-Ausfluss                  fuq =   0.0290 [hm**3]

 Fuelle-Ausfluss im Gerinne      fuqa =   0.0262 [hm**3]

 Fuelle-Ausfluss im vorland      fuqa =   0.0028 [hm**3]


 Scheitel-Ausfluss im Gerinne  iqamax =   1389   qamax =       1.765 [m**3/s]

 Scheitel-Ausfluss im Vorland  iqamax =   1389   qamax =       0.441 [m**3/s]


 Gesamtzuflusswelle (ohne Basisabfluss)  sqz =       96.669
 Gesamtabflusswelle    "       "         sq  =       96.669


 Keine angeschlossenen Teilgebiete an Strang      4544
 Auswertung des Stranges:         4545

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Aufruf der Speicherroutine 


 zufluss-fuelle [hm]        0.039370 speicher 4545
 zusaetzl.zufl im nachl.ast [hm]  0.000029

 speicher   0.032686 abfluss-fuelle [hm]      4545
 abfluss-fuelle [hm]  0.0065 ueberlauf 

 speicherinhaltsaenderung [hm]  0.000000
 Keine angeschlossenen Teilgebiete an Strang      4545
 Auswertung des Stranges:         4547

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Abflussverzoegerung mit Kalinin-Miljukov Parametern

 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 dt [h]:   0.08      tmax [d]:     4.82


 Kennwerte Zuflusswelle
 ----------------------

 Scheitel-Zufluss               iqzmax =   1387   qzmax =       1.035 [m**3/s]
 Scheitel-Zufluss im Gerinne    iqzfmx =   1387  qzfmax =       1.035 [m**3/s]
 Scheitel-Zufluss im Vorland    iqzvmx =      0  qzvmax =       0.000 [m**3/s]

 Fuelle-Zufluss                   fuqz =   0.0327 [hm**3]
 Fuelle-zufluss im Gerinne       fuqzf =   0.0327 [hm**3]
 Fuelle-zufluss im Vorland       fuqzv =   0.0000 [hm**3]


 Kennwerte der Systemfunktionen
 -------------------------------

 Anzahl der Zeitschritte  ituh =   2880
 Maximum u                imax =      1     umax = 0.000000
 Summe u                   suu = 0.000000   suuh = 0.000000


 tmax [d]:     0.00


 Kennwerte Ausflusswelle
 -----------------------


 Endordinate Ausfluss           qaend =   0.007

 Scheitel-Ausfluss              iqmax =   1403    qmax =       1.035 [m**3/s]


 Fuelle-Ausfluss                  fuq =   0.0327 [hm**3]

 Fuelle-Ausfluss im Gerinne      fuqa =   0.0327 [hm**3]

 Fuelle-Ausfluss im vorland      fuqa =   0.0000 [hm**3]


 Scheitel-Ausfluss im Gerinne  iqamax =   1403   qamax =       1.035 [m**3/s]

 Scheitel-Ausfluss im Vorland  iqamax =      0   qamax =       0.000 [m**3/s]


 Gesamtzuflusswelle (ohne Basisabfluss)  sqz =      108.966
 Gesamtabflusswelle    "       "         sq  =      108.970


 Keine angeschlossenen Teilgebiete an Strang      4547
 Auswertung des Stranges:         4548

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Abflussverzoegerung mit Kalinin-Miljukov Parametern

 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 dt [h]:   0.08      tmax [d]:     4.82


 Kennwerte Zuflusswelle
 ----------------------

 Scheitel-Zufluss               iqzmax =   1389   qzmax =       6.744 [m**3/s]
 Scheitel-Zufluss im Gerinne    iqzfmx =   1389  qzfmax =       5.395 [m**3/s]
 Scheitel-Zufluss im Vorland    iqzvmx =   1389  qzvmax =       1.349 [m**3/s]

 Fuelle-Zufluss                   fuqz =   0.1314 [hm**3]
 Fuelle-zufluss im Gerinne       fuqzf =   0.1123 [hm**3]
 Fuelle-zufluss im Vorland       fuqzv =   0.0191 [hm**3]


 Kennwerte der Systemfunktionen
 -------------------------------

 Anzahl der Zeitschritte  ituh =   2880
 Maximum u                imax =      1     umax = 0.000000
 Summe u                   suu = 0.000000   suuh = 0.000000


 tmax [d]:     4.83


 Kennwerte Ausflusswelle
 -----------------------


 Endordinate Ausfluss           qaend =   0.000

 Scheitel-Ausfluss              iqmax =   1390    qmax =       6.650 [m**3/s]


 Fuelle-Ausfluss                  fuq =   0.1314 [hm**3]

 Fuelle-Ausfluss im Gerinne      fuqa =   0.1123 [hm**3]

 Fuelle-Ausfluss im vorland      fuqa =   0.0191 [hm**3]


 Scheitel-Ausfluss im Gerinne  iqamax =   1390   qamax =       5.320 [m**3/s]

 Scheitel-Ausfluss im Vorland  iqamax =   1390   qamax =       1.330 [m**3/s]


 Gesamtzuflusswelle (ohne Basisabfluss)  sqz =      437.886
 Gesamtabflusswelle    "       "         sq  =      437.886


 Keine angeschlossenen Teilgebiete an Strang      4548
 Auswertung des Stranges:         4549

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.

 Keine angeschlossenen Teilgebiete an Strang      4549
 Auswertung des Stranges:         4550

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Aufruf der Speicherroutine 


 zufluss-fuelle [hm]        0.025492 speicher 4550
 zusaetzl.zufl im nachl.ast [hm]  0.000029

 speicher   0.020470 abfluss-fuelle [hm]      4550
 abfluss-fuelle [hm]  0.0049 ueberlauf 

 speicherinhaltsaenderung [hm]  0.000001
 Keine angeschlossenen Teilgebiete an Strang      4550
 Auswertung des Stranges:         4551

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Abflussverzoegerung mit Kalinin-Miljukov Parametern

 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 dt [h]:   0.08      tmax [d]:     4.84


 Kennwerte Zuflusswelle
 ----------------------

 Scheitel-Zufluss               iqzmax =   1394   qzmax =       0.276 [m**3/s]
 Scheitel-Zufluss im Gerinne    iqzfmx =   1394  qzfmax =       0.276 [m**3/s]
 Scheitel-Zufluss im Vorland    iqzvmx =      0  qzvmax =       0.000 [m**3/s]

 Fuelle-Zufluss                   fuqz =   0.0205 [hm**3]
 Fuelle-zufluss im Gerinne       fuqzf =   0.0205 [hm**3]
 Fuelle-zufluss im Vorland       fuqzv =   0.0000 [hm**3]


 Kennwerte der Systemfunktionen
 -------------------------------

 Anzahl der Zeitschritte  ituh =     25
 Maximum u                imax =      1     umax = 0.540740
 Summe u                   suu = 0.727210   suuh = 1.000000


 tmax [d]:     4.92


 Kennwerte Ausflusswelle
 -----------------------

 Endordinate Ausfluss           qaend =   0.000
 Scheitel-Ausfluss              iqmax =   1418    qmax =       0.276 [m**3/s]

 Fuelle-Ausfluss                  fuq =   0.0205 [hm**3]
 Fuelle-Ausfluss im Gerinne      fuqa =   0.0205 [hm**3]

 Scheitel-Ausfluss im Gerinne  iqamax =   1418   qamax =       0.276 [m**3/s]


 Gesamtzuflusswelle (ohne Basisabfluss)  sqz =       68.236
 Gesamtabflusswelle    "       "         sq  =       68.236


 Keine angeschlossenen Teilgebiete an Strang      4551
 Auswertung des Stranges:         4553

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Abflussverzoegerung mit Kalinin-Miljukov Parametern

 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 dt [h]:   0.08      tmax [d]:     4.82


 Kennwerte Zuflusswelle
 ----------------------

 Scheitel-Zufluss               iqzmax =   1389   qzmax =       9.366 [m**3/s]
 Scheitel-Zufluss im Gerinne    iqzfmx =   1389  qzfmax =       9.366 [m**3/s]
 Scheitel-Zufluss im Vorland    iqzvmx =      0  qzvmax =       0.000 [m**3/s]

 Fuelle-Zufluss                   fuqz =   0.1902 [hm**3]
 Fuelle-zufluss im Gerinne       fuqzf =   0.1902 [hm**3]
 Fuelle-zufluss im Vorland       fuqzv =   0.0000 [hm**3]


 Kennwerte der Systemfunktionen
 -------------------------------

 Anzahl der Zeitschritte  ituh =   2880
 Maximum u                imax =      1     umax = 0.000000
 Summe u                   suu = 0.000000   suuh = 0.000000


 tmax [d]:     0.00


 Kennwerte Ausflusswelle
 -----------------------


 Endordinate Ausfluss           qaend =   0.008

 Scheitel-Ausfluss              iqmax =   1392    qmax =       9.180 [m**3/s]


 Fuelle-Ausfluss                  fuq =   0.1902 [hm**3]

 Fuelle-Ausfluss im Gerinne      fuqa =   0.1902 [hm**3]

 Fuelle-Ausfluss im vorland      fuqa =   0.0000 [hm**3]


 Scheitel-Ausfluss im Gerinne  iqamax =   1392   qamax =       9.180 [m**3/s]

 Scheitel-Ausfluss im Vorland  iqamax =      0   qamax =       0.000 [m**3/s]


 Gesamtzuflusswelle (ohne Basisabfluss)  sqz =      634.047
 Gesamtabflusswelle    "       "         sq  =      634.053


 Keine angeschlossenen Teilgebiete an Strang      4553
 Auswertung des Stranges:         4559

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Abflussverzoegerung mit Kalinin-Miljukov Parametern

 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 dt [h]:   0.08      tmax [d]:     4.83


 Kennwerte Zuflusswelle
 ----------------------

 Scheitel-Zufluss               iqzmax =   1392   qzmax =       9.385 [m**3/s]
 Scheitel-Zufluss im Gerinne    iqzfmx =   1392  qzfmax =       7.508 [m**3/s]
 Scheitel-Zufluss im Vorland    iqzvmx =   1392  qzvmax =       1.877 [m**3/s]

 Fuelle-Zufluss                   fuqz =   0.1969 [hm**3]
 Fuelle-zufluss im Gerinne       fuqzf =   0.1657 [hm**3]
 Fuelle-zufluss im Vorland       fuqzv =   0.0313 [hm**3]


 Kennwerte der Systemfunktionen
 -------------------------------

 Anzahl der Zeitschritte  ituh =   2880
 Maximum u                imax =      1     umax = 0.000000
 Summe u                   suu = 0.000000   suuh = 0.000000


 tmax [d]:     4.83


 Kennwerte Ausflusswelle
 -----------------------


 Endordinate Ausfluss           qaend =   0.008

 Scheitel-Ausfluss              iqmax =   1392    qmax =       9.281 [m**3/s]


 Fuelle-Ausfluss                  fuq =   0.1969 [hm**3]

 Fuelle-Ausfluss im Gerinne      fuqa =   0.1657 [hm**3]

 Fuelle-Ausfluss im vorland      fuqa =   0.0313 [hm**3]


 Scheitel-Ausfluss im Gerinne  iqamax =   1392   qamax =       7.425 [m**3/s]

 Scheitel-Ausfluss im Vorland  iqamax =   1392   qamax =       1.856 [m**3/s]


 Gesamtzuflusswelle (ohne Basisabfluss)  sqz =      656.436
 Gesamtabflusswelle    "       "         sq  =      656.443


 Keine angeschlossenen Teilgebiete an Strang      4559
 Auswertung des Stranges:         4554

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.

 Keine angeschlossenen Teilgebiete an Strang      4554
 Auswertung des Stranges:         4555

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Aufruf der Speicherroutine 


 zufluss-fuelle [hm]        0.016492 speicher 4555
 zusaetzl.zufl im nachl.ast [hm]  0.000000

 speicher   0.016492 abfluss-fuelle [hm]      4555
 abfluss-fuelle [hm]  0.0000 ueberlauf 

 speicherinhaltsaenderung [hm]  0.000053
 Keine angeschlossenen Teilgebiete an Strang      4555
 Auswertung des Stranges:         4556

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Abflussverzoegerung mit Kalinin-Miljukov Parametern

 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 dt [h]:   0.08      tmax [d]:     4.86


 Kennwerte Zuflusswelle
 ----------------------

 Scheitel-Zufluss               iqzmax =   1400   qzmax =       0.613 [m**3/s]
 Scheitel-Zufluss im Gerinne    iqzfmx =   1398  qzfmax =       0.610 [m**3/s]
 Scheitel-Zufluss im Vorland    iqzvmx =   1400  qzvmax =       0.003 [m**3/s]

 Fuelle-Zufluss                   fuqz =   0.0165 [hm**3]
 Fuelle-zufluss im Gerinne       fuqzf =   0.0165 [hm**3]
 Fuelle-zufluss im Vorland       fuqzv =   0.0000 [hm**3]


 Kennwerte der Systemfunktionen
 -------------------------------

 Anzahl der Zeitschritte  ituh =   2880
 Maximum u                imax =      1     umax = 0.000000
 Summe u                   suu = 0.000000   suuh = 0.000000


 tmax [d]:     4.86


 Kennwerte Ausflusswelle
 -----------------------


 Endordinate Ausfluss           qaend =   0.001

 Scheitel-Ausfluss              iqmax =   1401    qmax =       0.612 [m**3/s]


 Fuelle-Ausfluss                  fuq =   0.0165 [hm**3]

 Fuelle-Ausfluss im Gerinne      fuqa =   0.0165 [hm**3]

 Fuelle-Ausfluss im vorland      fuqa =   0.0000 [hm**3]


 Scheitel-Ausfluss im Gerinne  iqamax =   1403   qamax =       0.610 [m**3/s]

 Scheitel-Ausfluss im Vorland  iqamax =   1401   qamax =       0.003 [m**3/s]


 Gesamtzuflusswelle (ohne Basisabfluss)  sqz =       54.975
 Gesamtabflusswelle    "       "         sq  =       54.976


 Keine angeschlossenen Teilgebiete an Strang      4556
 Auswertung des Stranges:         4557

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Aufruf der Speicherroutine 


 zufluss-fuelle [hm]        0.044882 speicher 4557
 zusaetzl.zufl im nachl.ast [hm]  0.000022

 speicher   0.044901 abfluss-fuelle [hm]      4557
 abfluss-fuelle [hm]  0.0000 ueberlauf 

 speicherinhaltsaenderung [hm]  0.000006
 Keine angeschlossenen Teilgebiete an Strang      4557
 Auswertung des Stranges:         4558

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Abflussverzoegerung mit Kalinin-Miljukov Parametern

 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 dt [h]:   0.08      tmax [d]:     4.88


 Kennwerte Zuflusswelle
 ----------------------

 Scheitel-Zufluss               iqzmax =   1406   qzmax =       1.604 [m**3/s]
 Scheitel-Zufluss im Gerinne    iqzfmx =   1406  qzfmax =       1.283 [m**3/s]
 Scheitel-Zufluss im Vorland    iqzvmx =   1406  qzvmax =       0.321 [m**3/s]

 Fuelle-Zufluss                   fuqz =   0.0449 [hm**3]
 Fuelle-zufluss im Gerinne       fuqzf =   0.0396 [hm**3]
 Fuelle-zufluss im Vorland       fuqzv =   0.0053 [hm**3]


 Kennwerte der Systemfunktionen
 -------------------------------

 Anzahl der Zeitschritte  ituh =   2880
 Maximum u                imax =      1     umax = 0.000000
 Summe u                   suu = 0.000000   suuh = 0.000000


 tmax [d]:     4.88


 Kennwerte Ausflusswelle
 -----------------------


 Endordinate Ausfluss           qaend =   0.002

 Scheitel-Ausfluss              iqmax =   1406    qmax =       1.602 [m**3/s]


 Fuelle-Ausfluss                  fuq =   0.0449 [hm**3]

 Fuelle-Ausfluss im Gerinne      fuqa =   0.0396 [hm**3]

 Fuelle-Ausfluss im vorland      fuqa =   0.0053 [hm**3]


 Scheitel-Ausfluss im Gerinne  iqamax =   1406   qamax =       1.282 [m**3/s]

 Scheitel-Ausfluss im Vorland  iqamax =   1406   qamax =       0.320 [m**3/s]


 Gesamtzuflusswelle (ohne Basisabfluss)  sqz =      149.684
 Gesamtabflusswelle    "       "         sq  =      149.685


 Keine angeschlossenen Teilgebiete an Strang      4558
 Auswertung des Stranges:         4561

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Aufruf der Speicherroutine 


 zufluss-fuelle [hm]        0.282845 speicher 4561
 zusaetzl.zufl im nachl.ast [hm]  0.001319

 speicher   0.227543 abfluss-fuelle [hm]      4561
 abfluss-fuelle [hm]  0.0560 ueberlauf 

 speicherinhaltsaenderung [hm]  0.000002
 Keine angeschlossenen Teilgebiete an Strang      4561
 Auswertung des Stranges:         4562

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Abflussverzoegerung mit Kalinin-Miljukov Parametern

 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 dt [h]:   0.08      tmax [d]:     4.83


 Kennwerte Zuflusswelle
 ----------------------

 Scheitel-Zufluss               iqzmax =   1390   qzmax =       4.052 [m**3/s]
 Scheitel-Zufluss im Gerinne    iqzfmx =   1390  qzfmax =       3.242 [m**3/s]
 Scheitel-Zufluss im Vorland    iqzvmx =   1445  qzvmax =       0.810 [m**3/s]

 Fuelle-Zufluss                   fuqz =   0.2275 [hm**3]
 Fuelle-zufluss im Gerinne       fuqzf =   0.1911 [hm**3]
 Fuelle-zufluss im Vorland       fuqzv =   0.0365 [hm**3]


 Kennwerte der Systemfunktionen
 -------------------------------

 Anzahl der Zeitschritte  ituh =    109
 Maximum u                imax =     16     umax = 0.040608
 Summe u                   suu = 0.999995   suuh = 1.000000


 tmax [d]:     5.05


 Kennwerte Ausflusswelle
 -----------------------


 Endordinate Ausfluss           qaend =   0.001

 Scheitel-Ausfluss              iqmax =   1445    qmax =       4.050 [m**3/s]


 Fuelle-Ausfluss                  fuq =   0.2276 [hm**3]

 Fuelle-Ausfluss im Gerinne      fuqa =   0.1911 [hm**3]

 Fuelle-Ausfluss im vorland      fuqa =   0.0365 [hm**3]


 Scheitel-Ausfluss im Gerinne  iqamax =   1413   qamax =       3.242 [m**3/s]

 Scheitel-Ausfluss im Vorland  iqamax =   1453   qamax =       0.809 [m**3/s]


 Gesamtzuflusswelle (ohne Basisabfluss)  sqz =      758.498
 Gesamtabflusswelle    "       "         sq  =      758.500


 Keine angeschlossenen Teilgebiete an Strang      4562
 Auswertung des Stranges:         4565

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Abflussverzoegerung mit Kalinin-Miljukov Parametern

 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 dt [h]:   0.08      tmax [d]:     4.95


 Kennwerte Zuflusswelle
 ----------------------

 Scheitel-Zufluss               iqzmax =   1425   qzmax =       8.176 [m**3/s]
 Scheitel-Zufluss im Gerinne    iqzfmx =   1425  qzfmax =       4.218 [m**3/s]
 Scheitel-Zufluss im Vorland    iqzvmx =   1425  qzvmax =       3.958 [m**3/s]

 Fuelle-Zufluss                   fuqz =   0.4094 [hm**3]
 Fuelle-zufluss im Gerinne       fuqzf =   0.2549 [hm**3]
 Fuelle-zufluss im Vorland       fuqzv =   0.1544 [hm**3]


 Kennwerte der Systemfunktionen
 -------------------------------

 Anzahl der Zeitschritte  ituh =     95
 Maximum u                imax =     24     umax = 0.042923
 Summe u                   suu = 0.999996   suuh = 1.000000


 tmax [d]:     5.05


 Kennwerte Ausflusswelle
 -----------------------


 Endordinate Ausfluss           qaend =   0.000

 Scheitel-Ausfluss              iqmax =   1443    qmax =       7.842 [m**3/s]


 Fuelle-Ausfluss                  fuq =   0.4096 [hm**3]

 Fuelle-Ausfluss im Gerinne      fuqa =   0.2547 [hm**3]

 Fuelle-Ausfluss im vorland      fuqa =   0.1548 [hm**3]


 Scheitel-Ausfluss im Gerinne  iqamax =   1428   qamax =       4.208 [m**3/s]

 Scheitel-Ausfluss im Vorland  iqamax =   1453   qamax =       3.881 [m**3/s]


 Gesamtzuflusswelle (ohne Basisabfluss)  sqz =     1364.504
 Gesamtabflusswelle    "       "         sq  =     1365.176


 Keine angeschlossenen Teilgebiete an Strang      4565
 Auswertung des Stranges:         4569

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Abflussverzoegerung mit Kalinin-Miljukov Parametern

 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 dt [h]:   0.08      tmax [d]:     5.00


 Kennwerte Zuflusswelle
 ----------------------

 Scheitel-Zufluss               iqzmax =   1441   qzmax =       8.071 [m**3/s]
 Scheitel-Zufluss im Gerinne    iqzfmx =   1441  qzfmax =       4.145 [m**3/s]
 Scheitel-Zufluss im Vorland    iqzvmx =   1441  qzvmax =       3.925 [m**3/s]

 Fuelle-Zufluss                   fuqz =   0.4226 [hm**3]
 Fuelle-zufluss im Gerinne       fuqzf =   0.2742 [hm**3]
 Fuelle-zufluss im Vorland       fuqzv =   0.1484 [hm**3]


 Kennwerte der Systemfunktionen
 -------------------------------

 Anzahl der Zeitschritte  ituh =    113
 Maximum u                imax =     14     umax = 0.040531
 Summe u                   suu = 0.999992   suuh = 1.000000


 tmax [d]:     5.08


 Kennwerte Ausflusswelle
 -----------------------


 Endordinate Ausfluss           qaend =   0.000

 Scheitel-Ausfluss              iqmax =   1457    qmax =       7.827 [m**3/s]


 Fuelle-Ausfluss                  fuq =   0.4233 [hm**3]

 Fuelle-Ausfluss im Gerinne      fuqa =   0.2736 [hm**3]

 Fuelle-Ausfluss im vorland      fuqa =   0.1498 [hm**3]


 Scheitel-Ausfluss im Gerinne  iqamax =   1450   qamax =       4.071 [m**3/s]

 Scheitel-Ausfluss im Vorland  iqamax =   1463   qamax =       3.816 [m**3/s]


 Gesamtzuflusswelle (ohne Basisabfluss)  sqz =     1408.617
 Gesamtabflusswelle    "       "         sq  =     1411.107


 Keine angeschlossenen Teilgebiete an Strang      4569
 Auswertung des Stranges:         4584

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Fiktiver Strang! Es erfolgt keine Abflussverzoegerung!
 Keine angeschlossenen Teilgebiete an Strang      4584
 Auswertung des Stranges:         4618

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Abflussverzoegerung mit Kalinin-Miljukov Parametern

 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 dt [h]:   0.08      tmax [d]:     5.05


 Kennwerte Zuflusswelle
 ----------------------

 Scheitel-Zufluss               iqzmax =   1455   qzmax =       8.105 [m**3/s]
 Scheitel-Zufluss im Gerinne    iqzfmx =   1455  qzfmax =       4.096 [m**3/s]
 Scheitel-Zufluss im Vorland    iqzvmx =   1455  qzvmax =       4.009 [m**3/s]

 Fuelle-Zufluss                   fuqz =   0.4689 [hm**3]
 Fuelle-zufluss im Gerinne       fuqzf =   0.3220 [hm**3]
 Fuelle-zufluss im Vorland       fuqzv =   0.1469 [hm**3]


 Kennwerte der Systemfunktionen
 -------------------------------

 Anzahl der Zeitschritte  ituh =    126
 Maximum u                imax =     18     umax = 0.034861
 Summe u                   suu = 0.999994   suuh = 1.000000


 tmax [d]:     5.14


 Kennwerte Ausflusswelle
 -----------------------


 Endordinate Ausfluss           qaend =   0.000

 Scheitel-Ausfluss              iqmax =   1470    qmax =       7.771 [m**3/s]


 Fuelle-Ausfluss                  fuq =   0.4690 [hm**3]

 Fuelle-Ausfluss im Gerinne      fuqa =   0.3220 [hm**3]

 Fuelle-Ausfluss im vorland      fuqa =   0.1469 [hm**3]


 Scheitel-Ausfluss im Gerinne  iqamax =   1456   qamax =       4.093 [m**3/s]

 Scheitel-Ausfluss im Vorland  iqamax =   1481   qamax =       3.883 [m**3/s]


 Gesamtzuflusswelle (ohne Basisabfluss)  sqz =     1563.095
 Gesamtabflusswelle    "       "         sq  =     1563.184


 Keine angeschlossenen Teilgebiete an Strang      4618
 Auswertung des Stranges:         4588

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Abflussverzoegerung mit Kalinin-Miljukov Parametern

 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 dt [h]:   0.08      tmax [d]:     5.10


 Kennwerte Zuflusswelle
 ----------------------

 Scheitel-Zufluss               iqzmax =   1470   qzmax =       7.795 [m**3/s]
 Scheitel-Zufluss im Gerinne    iqzfmx =   1470  qzfmax =       3.939 [m**3/s]
 Scheitel-Zufluss im Vorland    iqzvmx =   1470  qzvmax =       3.856 [m**3/s]

 Fuelle-Zufluss                   fuqz =   0.4724 [hm**3]
 Fuelle-zufluss im Gerinne       fuqzf =   0.3238 [hm**3]
 Fuelle-zufluss im Vorland       fuqzv =   0.1486 [hm**3]


 Kennwerte der Systemfunktionen
 -------------------------------

 Anzahl der Zeitschritte  ituh =    126
 Maximum u                imax =     18     umax = 0.034861
 Summe u                   suu = 0.999994   suuh = 1.000000


 tmax [d]:     5.19


 Kennwerte Ausflusswelle
 -----------------------


 Endordinate Ausfluss           qaend =   0.000

 Scheitel-Ausfluss              iqmax =   1483    qmax =       7.496 [m**3/s]


 Fuelle-Ausfluss                  fuq =   0.4725 [hm**3]

 Fuelle-Ausfluss im Gerinne      fuqa =   0.3238 [hm**3]

 Fuelle-Ausfluss im vorland      fuqa =   0.1486 [hm**3]


 Scheitel-Ausfluss im Gerinne  iqamax =   1470   qamax =       3.936 [m**3/s]

 Scheitel-Ausfluss im Vorland  iqamax =   1495   qamax =       3.743 [m**3/s]


 Gesamtzuflusswelle (ohne Basisabfluss)  sqz =     1574.792
 Gesamtabflusswelle    "       "         sq  =     1574.877


 Keine angeschlossenen Teilgebiete an Strang      4588
 Auswertung des Stranges:         1070

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4598

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    2.16

 gesamtmenge an niederschlag (mm):       77.1

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     54


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  6.000


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4598
 anzahl hydrotope:      54


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      77.1 mm
 interz.verd.:                       7.2 mm
 bestandsniederschlag:              67.8 mm
 differenz interz.speicher:         -2.1 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      16.0 mm
 aktuelle verdunstung:              10.6 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              67.8 mm
 overlandflow:                       1.3 mm
 [infiltration:                     66.5 mm]
 verdunstung (bodensp.):             3.4 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -63.1 mm
 fehler:                             0.0 mm


 entnahme gws [qbm/s]:       0.000
 73.6828613  -> zufluss grundwasserleiter in  4598
TG:    4598 -> TG:    4599
Prozent:1.00


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:          200.6 mm
 abgabe basisabfluss:                 59.4 mm
        grundw. unterh.l.TG:         140.7 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.5 mm
     pot.entnahme GWS:                 0.5 mm
 speicherinhaltsaenderung:             0.0 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.110 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.110 qkm



 Anzahl der Zeitschritte in iso durch Nachlauf zu hoch geworden.
 Sie wird auf 460 begrenzt !  gebiet :  4598

fuellenberechnung in iso
abflusz =           140.978
niederschlag =      141.221
flaeche zft  =        1.000
flaeche eing.=        0.110

GEBIET: Abflusswelle Interflow:
fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.110

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV:  fuellenberechnung
ISOV: Abflusz =          1199.614
ISOV: Niederschlag =     1199.616

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1071

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4593

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    2.16

 gesamtmenge an niederschlag (mm):       77.1

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:    126


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  8.000


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4593
 anzahl hydrotope:     126


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      77.1 mm
 interz.verd.:                       7.1 mm
 bestandsniederschlag:              68.1 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      16.0 mm
 aktuelle verdunstung:              10.5 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              68.1 mm
 overlandflow:                       3.6 mm
 [infiltration:                     64.5 mm]
 verdunstung (bodensp.):             3.4 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -61.1 mm
 fehler:                             0.0 mm


 24.1589699  -> zufluss grundwasserleiter in  4593
TG:    4593 -> TG:    4594
Prozent:0.10

TG:    4593 -> TG:    4596
Prozent:0.90


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:            8.5 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:          10.4 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                -1.2 mm
     pot.entnahme GWS:                -1.2 mm
 speicherinhaltsaenderung:            -0.7 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.855 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.855 qkm



 Anzahl der Zeitschritte in iso durch Nachlauf zu hoch geworden.
 Sie wird auf 460 begrenzt !  gebiet :  4593

fuellenberechnung in iso
abflusz =          3055.000
niederschlag =     3060.279
flaeche zft  =        1.000
flaeche eing.=        0.855

GEBIET: Abflusswelle Interflow:
fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.855

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV:  fuellenberechnung
ISOV: Abflusz =         10381.979
ISOV: Niederschlag =    10381.991

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1072

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4591

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    2.16

 gesamtmenge an niederschlag (mm):       77.1

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     85


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  4.000


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4591
 anzahl hydrotope:      85


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      77.1 mm
 interz.verd.:                       7.1 mm
 bestandsniederschlag:              68.1 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      16.1 mm
 aktuelle verdunstung:              10.4 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              68.1 mm
 overlandflow:                       2.4 mm
 [infiltration:                     65.6 mm]
 verdunstung (bodensp.):             3.4 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -62.3 mm
 fehler:                             0.0 mm


 0.00000000E+00  -> zufluss grundwasserleiter in  4591
TG:    4591 -> TG:    4594
Prozent:1.00


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:            0.0 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:           1.6 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                -1.5 mm
     pot.entnahme GWS:                -1.5 mm
 speicherinhaltsaenderung:            -0.2 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.379 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.379 qkm



 Anzahl der Zeitschritte in iso durch Nachlauf zu hoch geworden.
 Sie wird auf 460 begrenzt !  gebiet :  4591

fuellenberechnung in iso
abflusz =           914.376
niederschlag =      915.957
flaeche zft  =        1.000
flaeche eing.=        0.379

GEBIET: Abflusswelle Interflow:
fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.379

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV:  fuellenberechnung
ISOV: Abflusz =          5073.839
ISOV: Niederschlag =     5073.847

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1073

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4594

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    2.16

 gesamtmenge an niederschlag (mm):       77.1

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     61


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  7.500


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4594
 anzahl hydrotope:      61


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      77.1 mm
 interz.verd.:                       7.1 mm
 bestandsniederschlag:              68.1 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      16.1 mm
 aktuelle verdunstung:              10.2 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              68.1 mm
 overlandflow:                       0.8 mm
 [infiltration:                     67.3 mm]
 verdunstung (bodensp.):             3.2 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -64.1 mm
 fehler:                             0.0 mm


 entnahme gws [qbm/s]:       0.000
 5.00651455  -> zufluss grundwasserleiter in  4594
TG:    4594 -> TG:    4597
Prozent:1.00


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:            4.9 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:           5.7 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.2 mm
     pot.entnahme GWS:                 0.2 mm
 speicherinhaltsaenderung:            -1.0 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.307 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.307 qkm



 Anzahl der Zeitschritte in iso durch Nachlauf zu hoch geworden.
 Sie wird auf 460 begrenzt !  gebiet :  4594

fuellenberechnung in iso
abflusz =           239.131
niederschlag =      239.545
flaeche zft  =        1.000
flaeche eing.=        0.307

GEBIET: Abflusswelle Interflow:
fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.307

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV:  fuellenberechnung
ISOV: Abflusz =          3700.512
ISOV: Niederschlag =     3700.513

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1074

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4596

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    2.16

 gesamtmenge an niederschlag (mm):       77.1

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     47


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  9.700


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4596
 anzahl hydrotope:      47


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      77.1 mm
 interz.verd.:                       7.0 mm
 bestandsniederschlag:              68.1 mm
 differenz interz.speicher:         -1.9 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      15.8 mm
 aktuelle verdunstung:              10.0 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              68.1 mm
 overlandflow:                       0.0 mm
 [infiltration:                     68.1 mm]
 verdunstung (bodensp.):             3.0 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -65.1 mm
 fehler:                             0.0 mm


 47.9937019  -> zufluss grundwasserleiter in  4596
TG:    4596 -> TG:    4597
Prozent:1.00


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:           72.7 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:          77.9 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.0 mm
     pot.entnahme GWS:                 0.0 mm
 speicherinhaltsaenderung:            -5.2 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.198 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.198 qkm



 Anzahl der Zeitschritte in iso durch Nachlauf zu hoch geworden.
 Sie wird auf 460 begrenzt !  gebiet :  4596

fuellenberechnung in iso
abflusz =             2.206
niederschlag =        2.210
flaeche zft  =        1.000
flaeche eing.=        0.198

GEBIET: Abflusswelle Interflow:
fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.198

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV:  fuellenberechnung
ISOV: Abflusz =          2902.618
ISOV: Niederschlag =     2902.619

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1075

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4597

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    2.16

 gesamtmenge an niederschlag (mm):       77.1

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     84


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 =  7.000


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4597
 anzahl hydrotope:      84


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      77.1 mm
 interz.verd.:                       7.0 mm
 bestandsniederschlag:              68.2 mm
 differenz interz.speicher:         -1.9 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      15.8 mm
 aktuelle verdunstung:              10.3 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              68.2 mm
 overlandflow:                       1.2 mm
 [infiltration:                     66.9 mm]
 verdunstung (bodensp.):             3.3 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -63.6 mm
 fehler:                             0.0 mm


 entnahme gws [qbm/s]:       0.000
 57.3239822  -> zufluss grundwasserleiter in  4597
TG:    4597 -> TG:    4599
Prozent:1.00


 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:           64.1 mm
 abgabe basisabfluss:                  0.0 mm
        grundw. unterh.l.TG:          70.4 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 0.4 mm
     pot.entnahme GWS:                 0.4 mm
 speicherinhaltsaenderung:            -6.7 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.268 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.268 qkm



 Anzahl der Zeitschritte in iso durch Nachlauf zu hoch geworden.
 Sie wird auf 460 begrenzt !  gebiet :  4597

fuellenberechnung in iso
abflusz =           329.636
niederschlag =      330.206
flaeche zft  =        1.000
flaeche eing.=        0.268

GEBIET: Abflusswelle Interflow:
fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.268

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV:  fuellenberechnung
ISOV: Abflusz =          4797.534
ISOV: Niederschlag =     4797.537

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         1076

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.


 Auswertung von Gebiet:                   4599

 filename der niederschlageswerte: ..\klima.dat\C_4503.N                                       

 korrekturfaktor fuer niederschl.:    2.16

 gesamtmenge an niederschlag (mm):       77.1

Subroutine INP_HYDRO:      Anzahl Hydrotope im TG:     27


 Anfangswerte: aus LZSIM-Datei (*.lzs) oder Endwert letzter Zyklus

Anfangswerte   h01 =  0.000
               w01 =  0.000
               bo1 =  1.000
            bianf1 =  0.000
             aint1 =  0.000
             aigw1 = 20.100


-----------------------------------------

 z u s a m m e n f a s s u n g  
 der bilanz fuer teilgebiet:    4599
 anzahl hydrotope:      27


 speicherbilanz interzeption: 

 niederschlag:(nach schneesp.)      77.1 mm
 interz.verd.:                       7.1 mm
 bestandsniederschlag:              68.0 mm
 differenz interz.speicher:         -2.0 mm
 fehler:                             0.0 mm

 pot. verdunst. (grasref.):         15.0 mm
 pot. verdunst.(akt. vegetat.):      16.2 mm
 aktuelle verdunstung:              11.6 mm


 speicherbilanz bodenspeicher:   

 bestandsniederschlag:              68.0 mm
 overlandflow:                       7.5 mm
 [infiltration:                     60.5 mm]
 verdunstung (bodensp.):             4.5 mm
 lateral. abfluss (interflow):       0.0 mm
 perkolation:                        0.0 mm
 differenz bodenspeicher:          -56.1 mm
 fehler:                             0.0 mm


 entnahme gws [qbm/s]:       0.000
 114.616776  -> zufluss grundwasserleiter in  4599

 aufteilung perkolation: 

 perkolation bodenspeicher:            0.0 mm

 abgabe grundw.speicher:               0.0 mm
        tiefengrundw.leiter:           0.0 mm

        verlust tiefengw.leiter:       0.0 mm

 fehler:                               0.0 mm


 bilanz grundwasserspeicher: 

 zufluss perkolation:                  0.0 mm
        grundw. oberh.l.TG:         1321.7 mm
 abgabe basisabfluss:               1021.7 mm
        grundw. unterh.l.TG:         298.6 mm
        kapilarer aufstieg:            0.0 mm
        entnahme GWS:                 1.4 mm
     pot.entnahme GWS:                 1.4 mm
 speicherinhaltsaenderung:             0.0 mm
 fehler:                               0.0 mm


 flaechenanteile: 

   grundwasserleiter:                0.026 qkm
   tiefengrundwasserleiter:          0.000 qkm
   gesamtflaeche:                    0.026 qkm



 Anzahl der Zeitschritte in iso durch Nachlauf zu hoch geworden.
 Sie wird auf 460 begrenzt !  gebiet :  4599

fuellenberechnung in iso
abflusz =           195.035
niederschlag =      195.372
flaeche zft  =        1.000
flaeche eing.=        0.026

GEBIET: Abflusswelle Interflow:
fuellenberechnung in iso
abflusz =             0.000
niederschlag =        0.000
flaeche zft  =        1.000
flaeche eing.=        0.026

GEBIET: Abfluszwelle versiegelte Flaechen
ISOV:  fuellenberechnung
ISOV: Abflusz =           504.498
ISOV: Niederschlag =      504.498

GEBIET: Abfluszwelle Kluft-Grundwasserleiter
 anzahl der zeitschritte in isov durch nachlauf zu hoch geworden.
 sie wird auf IDIM begrenzt !

ISOV:  fuellenberechnung
ISOV: Abflusz =             0.000
ISOV: Niederschlag =        0.000
 Auswertung des Stranges:         4589

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.

 Keine angeschlossenen Teilgebiete an Strang      4589
 Auswertung des Stranges:         4590

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Aufruf der Speicherroutine 


 zufluss-fuelle [hm]        0.007515 speicher 4590
 zusaetzl.zufl im nachl.ast [hm]  0.000236

 speicher   0.007751 abfluss-fuelle [hm]      4590

 speicherinhaltsaenderung [hm]  0.000057
 Keine angeschlossenen Teilgebiete an Strang      4590
 Auswertung des Stranges:         4594

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Abflussverzoegerung mit Kalinin-Miljukov Parametern

 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 dt [h]:   0.08      tmax [d]:     4.94


 Kennwerte Zuflusswelle
 ----------------------

 Scheitel-Zufluss               iqzmax =   1424   qzmax =       0.215 [m**3/s]
 Scheitel-Zufluss im Gerinne    iqzfmx =   1424  qzfmax =       0.215 [m**3/s]
 Scheitel-Zufluss im Vorland    iqzvmx =      0  qzvmax =       0.000 [m**3/s]

 Fuelle-Zufluss                   fuqz =   0.0078 [hm**3]
 Fuelle-zufluss im Gerinne       fuqzf =   0.0078 [hm**3]
 Fuelle-zufluss im Vorland       fuqzv =   0.0000 [hm**3]


 Kennwerte der Systemfunktionen
 -------------------------------

 Anzahl der Zeitschritte  ituh =     18
 Maximum u                imax =      3     umax = 0.269426
 Summe u                   suu = 0.999998   suuh = 1.000000


 tmax [d]:     4.95


 Kennwerte Ausflusswelle
 -----------------------

 Endordinate Ausfluss           qaend =   0.000
 Scheitel-Ausfluss              iqmax =   1427    qmax =       0.215 [m**3/s]

 Fuelle-Ausfluss                  fuq =   0.0078 [hm**3]
 Fuelle-Ausfluss im Gerinne      fuqa =   0.0078 [hm**3]

 Scheitel-Ausfluss im Gerinne  iqamax =   1427   qamax =       0.215 [m**3/s]


 Gesamtzuflusswelle (ohne Basisabfluss)  sqz =       25.839
 Gesamtabflusswelle    "       "         sq  =       25.839


 Keine angeschlossenen Teilgebiete an Strang      4594
 Auswertung des Stranges:         4591

 Anfangsstrang! 
 F�r den Anfangsknoten des Stranges gilt 9000 < Knotennummer > 10000
 Es erfolgt kein Zufluss und daher auch keine Abflussverzoegerung im Gerinne.

 Keine angeschlossenen Teilgebiete an Strang      4591
 Auswertung des Stranges:         4592

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Aufruf der Speicherroutine 


 zufluss-fuelle [hm]        0.005827 speicher 4592
 zusaetzl.zufl im nachl.ast [hm]  0.000165

 speicher   0.005992 abfluss-fuelle [hm]      4592

 speicherinhaltsaenderung [hm]  0.000000
 Keine angeschlossenen Teilgebiete an Strang      4592
 Auswertung des Stranges:         4593

 Abflussverzoegerung mit Kalinin-Miljukov Parametern

 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 dt [h]:   0.08      tmax [d]:     4.93


 Kennwerte Zuflusswelle
 ----------------------

 Scheitel-Zufluss               iqzmax =   1419   qzmax =       0.184 [m**3/s]
 Scheitel-Zufluss im Gerinne    iqzfmx =   1419  qzfmax =       0.184 [m**3/s]
 Scheitel-Zufluss im Vorland    iqzvmx =      0  qzvmax =       0.000 [m**3/s]

 Fuelle-Zufluss                   fuqz =   0.0060 [hm**3]
 Fuelle-zufluss im Gerinne       fuqzf =   0.0060 [hm**3]
 Fuelle-zufluss im Vorland       fuqzv =   0.0000 [hm**3]


 Kennwerte der Systemfunktionen
 -------------------------------

 Anzahl der Zeitschritte  ituh =     18
 Maximum u                imax =      3     umax = 0.269426
 Summe u                   suu = 0.999998   suuh = 1.000000


 tmax [d]:     4.94


 Kennwerte Ausflusswelle
 -----------------------

 Endordinate Ausfluss           qaend =   0.000
 Scheitel-Ausfluss              iqmax =   1423    qmax =       0.184 [m**3/s]

 Fuelle-Ausfluss                  fuq =   0.0060 [hm**3]
 Fuelle-Ausfluss im Gerinne      fuqa =   0.0060 [hm**3]

 Scheitel-Ausfluss im Gerinne  iqamax =   1423   qamax =       0.184 [m**3/s]


 Gesamtzuflusswelle (ohne Basisabfluss)  sqz =       19.972
 Gesamtabflusswelle    "       "         sq  =       19.972


 Keine angeschlossenen Teilgebiete an Strang      4593
 Auswertung des Stranges:         4595

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Aufruf der Speicherroutine 


 zufluss-fuelle [hm]        0.030053 speicher 4595
 zusaetzl.zufl im nachl.ast [hm]  0.001073

 speicher   0.031124 abfluss-fuelle [hm]      4595

 speicherinhaltsaenderung [hm]  0.000002
 Keine angeschlossenen Teilgebiete an Strang      4595
 Auswertung des Stranges:         4596

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Aufruf der Speicherroutine 


 zufluss-fuelle [hm]        0.029433 speicher 4596
 zusaetzl.zufl im nachl.ast [hm]  0.001699

 speicher   0.031131 abfluss-fuelle [hm]      4596

 speicherinhaltsaenderung [hm]  0.000000
 Keine angeschlossenen Teilgebiete an Strang      4596
 Auswertung des Stranges:         4622

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Abflussverzoegerung mit Kalinin-Miljukov Parametern

 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 dt [h]:   0.08      tmax [d]:     4.92


 Kennwerte Zuflusswelle
 ----------------------

 Scheitel-Zufluss               iqzmax =   1417   qzmax =       1.022 [m**3/s]
 Scheitel-Zufluss im Gerinne    iqzfmx =   1417  qzfmax =       1.022 [m**3/s]
 Scheitel-Zufluss im Vorland    iqzvmx =      0  qzvmax =       0.000 [m**3/s]

 Fuelle-Zufluss                   fuqz =   0.0340 [hm**3]
 Fuelle-zufluss im Gerinne       fuqzf =   0.0340 [hm**3]
 Fuelle-zufluss im Vorland       fuqzv =   0.0000 [hm**3]


 Kennwerte der Systemfunktionen
 -------------------------------

 Anzahl der Zeitschritte  ituh =   2880
 Maximum u                imax =     18     umax = 0.000000
 Summe u                   suu = 0.000000   suuh = 0.000000


 tmax [d]:     0.00


 Kennwerte Ausflusswelle
 -----------------------


 Endordinate Ausfluss           qaend =   0.001

 Scheitel-Ausfluss              iqmax =   1420    qmax =       1.021 [m**3/s]


 Fuelle-Ausfluss                  fuq =   0.0340 [hm**3]

 Fuelle-Ausfluss im Gerinne      fuqa =   0.0340 [hm**3]

 Fuelle-Ausfluss im vorland      fuqa =   0.0000 [hm**3]


 Scheitel-Ausfluss im Gerinne  iqamax =   1420   qamax =       1.021 [m**3/s]

 Scheitel-Ausfluss im Vorland  iqamax =      0   qamax =       0.000 [m**3/s]


 Gesamtzuflusswelle (ohne Basisabfluss)  sqz =      113.464
 Gesamtabflusswelle    "       "         sq  =      113.464


 Keine angeschlossenen Teilgebiete an Strang      4622
 Auswertung des Stranges:         4597

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Abflussverzoegerung mit Kalinin-Miljukov Parametern

 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 dt [h]:   0.08      tmax [d]:     5.15


 Kennwerte Zuflusswelle
 ----------------------

 Scheitel-Zufluss               iqzmax =   1483   qzmax =       7.508 [m**3/s]
 Scheitel-Zufluss im Gerinne    iqzfmx =   1483  qzfmax =       4.210 [m**3/s]
 Scheitel-Zufluss im Vorland    iqzvmx =   1483  qzvmax =       3.299 [m**3/s]

 Fuelle-Zufluss                   fuqz =   0.4753 [hm**3]
 Fuelle-zufluss im Gerinne       fuqzf =   0.3363 [hm**3]
 Fuelle-zufluss im Vorland       fuqzv =   0.1390 [hm**3]


 Kennwerte der Systemfunktionen
 -------------------------------

 Anzahl der Zeitschritte  ituh =      9
 Maximum u                imax =      1     umax = 0.725271
 Summe u                   suu = 1.005751   suuh = 1.000000


 tmax [d]:     5.15


 Kennwerte Ausflusswelle
 -----------------------


 Endordinate Ausfluss           qaend =   0.001

 Scheitel-Ausfluss              iqmax =   1484    qmax =       7.507 [m**3/s]


 Fuelle-Ausfluss                  fuq =   0.4753 [hm**3]

 Fuelle-Ausfluss im Gerinne      fuqa =   0.3363 [hm**3]

 Fuelle-Ausfluss im vorland      fuqa =   0.1390 [hm**3]


 Scheitel-Ausfluss im Gerinne  iqamax =   1484   qamax =       4.209 [m**3/s]

 Scheitel-Ausfluss im Vorland  iqamax =   1484   qamax =       3.299 [m**3/s]


 Gesamtzuflusswelle (ohne Basisabfluss)  sqz =     1584.250
 Gesamtabflusswelle    "       "         sq  =     1584.250


 Keine angeschlossenen Teilgebiete an Strang      4597
 Auswertung des Stranges:         4598

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Abflussverzoegerung mit Kalinin-Miljukov Parametern

 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 gerinne: Anzahl der Zeitschritte in Gerinne durch Nachlauf zu hoch geworden.
 Sie wird auf  2880 begrenzt!


 dt [h]:   0.08      tmax [d]:     5.14


 Kennwerte Zuflusswelle
 ----------------------

 Scheitel-Zufluss               iqzmax =   1479   qzmax =       7.839 [m**3/s]
 Scheitel-Zufluss im Gerinne    iqzfmx =   1479  qzfmax =       5.436 [m**3/s]
 Scheitel-Zufluss im Vorland    iqzvmx =   1479  qzvmax =       2.403 [m**3/s]

 Fuelle-Zufluss                   fuqz =   0.5224 [hm**3]
 Fuelle-zufluss im Gerinne       fuqzf =   0.4006 [hm**3]
 Fuelle-zufluss im Vorland       fuqzv =   0.1218 [hm**3]


 Kennwerte der Systemfunktionen
 -------------------------------

 Anzahl der Zeitschritte  ituh =     16
 Maximum u                imax =      1     umax = 0.517926
 Summe u                   suu = 0.610857   suuh = 0.999798


 tmax [d]:     5.14


 Kennwerte Ausflusswelle
 -----------------------


 Endordinate Ausfluss           qaend =   0.000

 Scheitel-Ausfluss              iqmax =   1480    qmax =       7.837 [m**3/s]


 Fuelle-Ausfluss                  fuq =   0.5223 [hm**3]

 Fuelle-Ausfluss im Gerinne      fuqa =   0.4005 [hm**3]

 Fuelle-Ausfluss im vorland      fuqa =   0.1218 [hm**3]


 Scheitel-Ausfluss im Gerinne  iqamax =   1480   qamax =       5.434 [m**3/s]

 Scheitel-Ausfluss im Vorland  iqamax =   1479   qamax =       2.403 [m**3/s]


 Gesamtzuflusswelle (ohne Basisabfluss)  sqz =     1741.221
 Gesamtabflusswelle    "       "         sq  =     1741.160


 Keine angeschlossenen Teilgebiete an Strang      4598
 Auswertung des Stranges:         4599

 Anfangswert aus LZSIM-Datei (*.lzg)
 Uebernommener Schwellwert des Abflusses:     0.000


 Fiktiver Strang! Es erfolgt keine Abflussverzoegerung!
 Keine angeschlossenen Teilgebiete an Strang      4599
 Auswertung des Stranges:        10002

 Fiktiver Strang! Es erfolgt keine Abflussverzoegerung!
 Keine angeschlossenen Teilgebiete an Strang     10002


 ------------------------------------------------------------------
           Berechnung wurde ohne Fehler beendet!                   
 ------------------------------------------------------------------
