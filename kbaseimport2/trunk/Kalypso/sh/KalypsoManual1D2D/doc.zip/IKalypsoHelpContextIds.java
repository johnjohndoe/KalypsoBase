<?xml version="1.0" encoding="ISO-8859-1"?>


				
				
/**
 * @see KalypsoManual common-eclipse.xsl and KalypsoBuild/publishing/docbook-xsl-1.69.1/eclipse/eclipse-ex.xsl
 *
 */				
public interface IKalypsoHelpContextIds
{
  public static final String PREFIX = "org.kalypso.manual.";
					
				
			
  public static final String Kalypso1D2DAllgemeines =PREFIX + "Kalypso1D2DAllgemeines";
		
			
  public static final String Kalypso1D2DProjektbearbeitung =PREFIX + "Kalypso1D2DProjektbearbeitung";
		
			
  public static final String Kalypso1D2DNeuesProjekt =PREFIX + "Kalypso1D2DNeuesProjekt";
		
			
  public static final String Kalypso1D2DVorhProjekt =PREFIX + "Kalypso1D2DVorhProjekt";
		
			
  public static final String Kalypso1D2DDatenakquisition =PREFIX + "Kalypso1D2DDatenakquisition";
		
			
  public static final String Kalypso1D2DPreprocessing =PREFIX + "Kalypso1D2DPreprocessing";
		
			
  public static final String Kalypso1D2DDatenLaden =PREFIX + "Kalypso1D2DDatenLaden";
		
			
  public static final String Kalypso1D2DImportBackgroundmaps =PREFIX + "Kalypso1D2DImportBackgroundmaps";
		
			
  public static final String Kalypso1D2DImportBackgroundmaps_TIF_JPG =PREFIX + "Kalypso1D2DImportBackgroundmaps_TIF_JPG";
		
			
  public static final String Kalypso1D2DImportBackgroundmaps_SHP =PREFIX + "Kalypso1D2DImportBackgroundmaps_SHP";
		
			
  public static final String Kalypso1D2DImportBackgroundmaps_WebMapService =PREFIX + "Kalypso1D2DImportBackgroundmaps_WebMapService";
		
			
  public static final String Kalypso1D2DImportDHM =PREFIX + "Kalypso1D2DImportDHM";
		
			
  public static final String Kalypso1D2DImportRoughness =PREFIX + "Kalypso1D2DImportRoughness";
		
			
  public static final String Kalypso1D2DImportTimeseries =PREFIX + "Kalypso1D2DImportTimeseries";
		
			
  public static final String Kalypso1D2DImportProf =PREFIX + "Kalypso1D2DImportProf";
		
			
  public static final String Kalypso1D2DNetzaufbau =PREFIX + "Kalypso1D2DNetzaufbau";
		
			
  public static final String Kalypso1D2DNetzaufbau_1DGewaessernetz =PREFIX + "Kalypso1D2DNetzaufbau_1DGewaessernetz";
		
			
  public static final String Kalypso1D2DWSPMimport =PREFIX + "Kalypso1D2DWSPMimport";
		
			
  public static final String Kalypso1D2DNetzaufbau_1DGewassernetz_Profile =PREFIX + "Kalypso1D2DNetzaufbau_1DGewassernetz_Profile";
		
			
  public static final String Kalypso1D2DNetzaufbau_bearbeiten =PREFIX + "Kalypso1D2DNetzaufbau_bearbeiten";
		
			
  public static final String Kalypso1D2DNetzaufbau_Parameter =PREFIX + "Kalypso1D2DNetzaufbau_Parameter";
		
			
  public static final String Kalypso1D2DNetzaufbau_2DNetz =PREFIX + "Kalypso1D2DNetzaufbau_2DNetz";
		
			
  public static final String Kalypso1D2DNetzaufbau_2DNetz_Import =PREFIX + "Kalypso1D2DNetzaufbau_2DNetz_Import";
		
			
  public static final String Kalypso1D2DNetzaufbau_2DNetz_bearbeiten =PREFIX + "Kalypso1D2DNetzaufbau_2DNetz_bearbeiten";
		
			
  public static final String Kalypso1D2DNetzaufbau_2DNetz_Flussschlauchgenerator =PREFIX + "Kalypso1D2DNetzaufbau_2DNetz_Flussschlauchgenerator";
		
			
  public static final String Kalypso1D2DNetzaufbau_2DNetz_Bandgenerator =PREFIX + "Kalypso1D2DNetzaufbau_2DNetz_Bandgenerator";
		
			
  public static final String Kalypso1D2DNetzaufbau_2DNetz_Hoehen =PREFIX + "Kalypso1D2DNetzaufbau_2DNetz_Hoehen";
		
			
  public static final String Kalypso1D2DNetzaufbau_BerechnungseundRB =PREFIX + "Kalypso1D2DNetzaufbau_BerechnungseundRB";
		
			
  public static final String Kalypso1D2DNetzaufbau_BerechnungseundRB_Raenderdefinieren =PREFIX + "Kalypso1D2DNetzaufbau_BerechnungseundRB_Raenderdefinieren";
		
			
  public static final String Kalypso1D2DNetzaufbau_BerechnungseundRB_RB =PREFIX + "Kalypso1D2DNetzaufbau_BerechnungseundRB_RB";
		
			
  public static final String Kalypso1D2DNetzaufbau_BerechnungseundRB_1DEinmuendung =PREFIX + "Kalypso1D2DNetzaufbau_BerechnungseundRB_1DEinmuendung";
		
			
  public static final String Kalypso1D2DNetzaufbau_BerechnungseundRB_1D2DLinienkopplung =PREFIX + "Kalypso1D2DNetzaufbau_BerechnungseundRB_1D2DLinienkopplung";
		
			
  public static final String Kalypso1D2DNetzaufbau_BerechnungseundRB_BerechnungseModellieren =PREFIX + "Kalypso1D2DNetzaufbau_BerechnungseundRB_BerechnungseModellieren";
		
			
  public static final String Kalypso1D2DRauheitsmodellierung =PREFIX + "Kalypso1D2DRauheitsmodellierung";
		
			
  public static final String Kalypso1D2DRauheitsmodellierung_RauheitswerteBearbeiten =PREFIX + "Kalypso1D2DRauheitsmodellierung_RauheitswerteBearbeiten";
		
			
  public static final String Kalypso1D2DRauheitsmodellierung_RauheitszonenBearbeiten =PREFIX + "Kalypso1D2DRauheitsmodellierung_RauheitszonenBearbeiten";
		
			
  public static final String Kalypso1D2DRauheitsmodellierung_RauheitszonenBearbeiten_Polygonneu =PREFIX + "Kalypso1D2DRauheitsmodellierung_RauheitszonenBearbeiten_Polygonneu";
		
			
  public static final String Kalypso1D2DRauheitsmodellierung_RauheitszonenBearbeiten_Polygonloeschen =PREFIX + "Kalypso1D2DRauheitsmodellierung_RauheitszonenBearbeiten_Polygonloeschen";
		
			
  public static final String Kalypso1D2DRauheitsmodellierung_RauheitszonenBearbeiten_Polygonbearbeiten =PREFIX + "Kalypso1D2DRauheitsmodellierung_RauheitszonenBearbeiten_Polygonbearbeiten";
		
			
  public static final String Kalypso1D2DRauheitsmodellierung_RauheitszonenBearbeiten_Rauheitszonebearbeiten =PREFIX + "Kalypso1D2DRauheitsmodellierung_RauheitszonenBearbeiten_Rauheitszonebearbeiten";
		
			
  public static final String Kalypso1D2DDatenexport =PREFIX + "Kalypso1D2DDatenexport";
		
			
  public static final String Kalypso1D2DExportFENetz =PREFIX + "Kalypso1D2DExportFENetz";
		
			
  public static final String Kalypso1D2DProzessing =PREFIX + "Kalypso1D2DProzessing";
		
			
  public static final String Kalypso1D2DBerechnungseinstellungen =PREFIX + "Kalypso1D2DBerechnungseinstellungen";
		
			
  public static final String Kalypso1D2DControlmodel =PREFIX + "Kalypso1D2DControlmodel";
		
			
  public static final String Kalypso1D2DAllgemeine_Einstellungen =PREFIX + "Kalypso1D2DAllgemeine_Einstellungen";
		
			
  public static final String Kalypso1D2DBerechnungssteuerung =PREFIX + "Kalypso1D2DBerechnungssteuerung";
		
			
  public static final String Kalypso1D2DKonvergenz =PREFIX + "Kalypso1D2DKonvergenz";
		
			
  public static final String Kalypso1D2DAnfangswerte =PREFIX + "Kalypso1D2DAnfangswerte";
		
			
  public static final String Kalypso1D2DMarshparameter =PREFIX + "Kalypso1D2DMarshparameter";
		
			
  public static final String Kalypso1D2DTurbulenzmodell =PREFIX + "Kalypso1D2DTurbulenzmodell";
		
			
  public static final String Kalypso1D2DPostprozessing =PREFIX + "Kalypso1D2DPostprozessing";
		
			
  public static final String Kalypso1D2DModellkalibrierung =PREFIX + "Kalypso1D2DModellkalibrierung";
		
}
				
			