<?xml version="1.0" encoding="WINDOWS-1252"?>
<StyledLayerDescriptor xmlns="http://www.opengis.net/sld" xmlns:gml="http://www.opengis.net/gml" xmlns:ogc="http://www.opengis.net/ogc" xmlns:sld="http://www.opengis.net/sld" xmlns:sldExt="http://www.opengis.net/sldExt" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" version="1.0">
    <NamedLayer>
        <Name>deegree style definition</Name>
        <UserStyle>
            <Name>Kalypso style</Name>
            <Title>Kalypso style</Title>
            <FeatureTypeStyle>
                <Rule>
                    <Name>default</Name>
                    <Title>default</Title>
                    <Abstract>default</Abstract>
                    <MinScaleDenominator>0.0</MinScaleDenominator>
                    <MaxScaleDenominator>1.7976931348623157E308</MaxScaleDenominator>
                    <RasterSymbolizer uom="pixel">
<ColorMap>
<ColorMapEntry color="#ffffff" label="" opacity="0.75" quantity="-9999.0"/>
<ColorMapEntry color="#ffff00" label="" opacity="0.75" quantity="1.0"/>
<ColorMapEntry color="#ff8040" label="" opacity="0.75" quantity="2.0"/>
<ColorMapEntry color="#ff0000" label="" opacity="0.75" quantity="3.0"/>
<ColorMapEntry color="#8080ff" label="" opacity="0.75" quantity="4.0"/>
<ColorMapEntry color="#8000ff" label="" opacity="0.75" quantity="5.0"/>
<ColorMapEntry color="#400080" label="" opacity="0.75" quantity="6.0"/>
</ColorMap>
</RasterSymbolizer>
</Rule>
            </FeatureTypeStyle>
        </UserStyle>
    </NamedLayer>
</StyledLayerDescriptor>
