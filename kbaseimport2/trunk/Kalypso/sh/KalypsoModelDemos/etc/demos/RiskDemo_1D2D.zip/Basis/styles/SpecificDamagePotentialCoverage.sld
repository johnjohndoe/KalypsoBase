<?xml version="1.0" encoding="WINDOWS-1252"?>
<StyledLayerDescriptor xmlns="http://www.opengis.net/sld" xmlns:gml="http://www.opengis.net/gml" xmlns:ogc="http://www.opengis.net/ogc" xmlns:sld="http://www.opengis.net/sld" xmlns:sldExt="http://www.opengis.net/sldExt" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" version="1.0">
    <NamedLayer>
        <Name>deegree style definition</Name>
        <UserStyle>
            <Name>Kalypso style</Name>
            <Title>Kalypso style</Title>
            <FeatureTypeStyle>
                <Rule>
                    <Name>default</Name>
                    <Title>default</Title>
                    <Abstract>default</Abstract>
                    <MinScaleDenominator>0.0</MinScaleDenominator>
                    <MaxScaleDenominator>1.7976931348623157E308</MaxScaleDenominator>
                    <RasterSymbolizer uom="pixel">
<ColorMap>
<ColorMapEntry color="#ffffff" label="" opacity="0.75" quantity="0.1"/>
<ColorMapEntry color="#fef6f3" label="" opacity="0.75" quantity="4.901949999999999"/>
<ColorMapEntry color="#fdede8" label="" opacity="0.75" quantity="9.803899999999999"/>
<ColorMapEntry color="#fce4dc" label="" opacity="0.75" quantity="14.705849999999998"/>
<ColorMapEntry color="#fbdcd1" label="" opacity="0.75" quantity="19.607799999999997"/>
<ColorMapEntry color="#fad3c5" label="" opacity="0.75" quantity="24.509749999999997"/>
<ColorMapEntry color="#f9caba" label="" opacity="0.75" quantity="29.411699999999996"/>
<ColorMapEntry color="#f8c1ae" label="" opacity="0.75" quantity="34.313649999999996"/>
<ColorMapEntry color="#f7b9a3" label="" opacity="0.75" quantity="39.215599999999995"/>
<ColorMapEntry color="#f6b097" label="" opacity="0.75" quantity="44.117549999999994"/>
<ColorMapEntry color="#f6a78c" label="" opacity="0.75" quantity="49.019499999999994"/>
<ColorMapEntry color="#f59e80" label="" opacity="0.75" quantity="53.92144999999999"/>
<ColorMapEntry color="#f49675" label="" opacity="0.75" quantity="58.82339999999999"/>
<ColorMapEntry color="#f38d69" label="" opacity="0.75" quantity="63.72534999999999"/>
<ColorMapEntry color="#f2845e" label="" opacity="0.75" quantity="68.62729999999999"/>
<ColorMapEntry color="#f17b52" label="" opacity="0.75" quantity="73.52924999999999"/>
<ColorMapEntry color="#f07347" label="" opacity="0.75" quantity="78.43119999999999"/>
<ColorMapEntry color="#ef6a3b" label="" opacity="0.75" quantity="83.33314999999999"/>
<ColorMapEntry color="#ee6130" label="" opacity="0.75" quantity="88.23509999999999"/>
<ColorMapEntry color="#ed5824" label="" opacity="0.75" quantity="93.13704999999999"/>
<ColorMapEntry color="#ed5019" label="" opacity="0.75" quantity="98.03899999999999"/>
</ColorMap>
</RasterSymbolizer>
</Rule>
            </FeatureTypeStyle>
        </UserStyle>
    </NamedLayer>
</StyledLayerDescriptor>
