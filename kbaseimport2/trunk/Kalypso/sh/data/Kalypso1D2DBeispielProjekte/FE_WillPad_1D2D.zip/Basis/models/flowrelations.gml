<?xml version="1.0" encoding="WINDOWS-1252"?>
<simBase:FlowRelationshipModel xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:gml="http://www.opengis.net/gml" xmlns:xs="http://www.w3.org/2001/XMLSchema-instance" xmlns:simBase="http://www.tu-harburg.de/wb/kalypso/schemata/simulationbase" xmlns:wb1d2d="http://www.tu-harburg.de/wb/kalypso/schemata/1d2d" xmlns:tuhh="org.kalypso.model.wspm.tuhh" xmlns:op1d2d="http://www.tu-harburg.de/wb/kalypso/schemata/operationalmodel" xmlns:swe="http://www.opengis.net/swe" xmlns:ns8="http://www.tu-harburg.de/wb/kalypso/schemata/observation" xmlns:math="org.kalypso.gml.common.math" xmlns:sweExt="org.kalypso.swe.ext" xmlns:om="http://www.opengis.net/om" gml:id="root">
 <simBase:flowRelationshipMember>
  <wb1d2d:TeschkeFlowRelation gml:id="TeschkeFlowRelation11903967140781">
   <gml:description>Gelesen aus: PROF0058.4500.txt</gml:description>
   <gml:name>58.4500</gml:name>
   <simBase:position>
    <gml:Point xmlns:ns1="http://www.w3.org/2001/SMIL20/" xmlns:st="http://www.seegrid.csiro.au/xml/st" xmlns:ns2="http://www.isotc211.org/2005/gmd" xmlns:ns3="http://www.isotc211.org/2005/gco" xmlns:ns4="http://www.isotc211.org/2005/gts" xmlns:ns5="http://www.isotc211.org/2005/gss" xmlns:ns6="http://www.isotc211.org/2005/gsr" xmlns:ns7="http://www.w3.org/2001/SMIL20/Language" srsName="EPSG:31467">
     <gml:coordinates ts="," decimal="." cs=" ">3552955.1161555466 5986891.572496113 2.58</gml:coordinates>
    </gml:Point>
   </simBase:position>
   <wb1d2d:pointsMember>
    <tuhh:WPointsObservation gml:id="WPointsObservation11903967140780">
     <gml:description>�bernommen aus Datei: PROF0058.4500.txt</gml:description>
     <gml:name>0058.4500</gml:name>
     <om:resultDefinition>
      <swe:RecordDefinition gml:id="RecordDefinition11903967140780">
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#Waterlevel"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#Depth"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#Area"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#Runoff"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#Alpha"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#DeltaArea"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#DeltaRunoff"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#DeltaAlpha"/>
      </swe:RecordDefinition>
     </om:resultDefinition>
     <om:result><![CDATA[3.321 0.7410000 4.081000 2.500000 1.000000 0.009216752 0.02751551 0E-7
3.547 0.9670000 6.467000 5.000000 1.000000 -0.0009971829 -0.05818394 0E-7
3.712 1.132000 8.356000 7.500000 1.000000 -0.02397189 -0.02086750 0E-7
3.855 1.275000 10.03600 10.00000 1.000000 -0.01744681 0.03300265 0E-7
3.984 1.404000 11.59100 12.50000 1.000000 -0.003335410 0.04083569 0E-7
4.103 1.523000 13.05500 15.00000 1.000000 0.01828845 -0.01148272 0E-7
4.219 1.639000 14.52700 17.50000 1.000000 0.03088834 -0.01640668 0E-7
4.333 1.753000 16.02400 20.00000 1.000000 0.03153804 0.04178042 0E-7
4.440 1.860000 17.47500 22.50000 1.000000 0.02630693 0.05205027 0E-7
4.539 1.959000 18.88700 25.00000 1.000000 -0.007540380 -0.01048346 0E-7
4.634 2.054000 20.26400 27.50000 1.000000 -0.01914392 -0.04219650 0E-7
4.723 2.143000 21.61000 30.00000 1.000000 -0.04150184 -0.08744198 0E-7
4.808 2.228000 22.93000 32.50000 1.000000 -0.05089465 -0.08586190 0E-7
4.889 2.309000 24.22400 35.00000 1.000000 -0.04762807 -0.03040308 0E-7
4.967 2.387000 25.49600 37.50000 1.000000 -0.01986293 0.1174830 0E-7
5.036 2.456000 26.63600 40.00000 1.000290 0.03624057 0.1373225 -0.0002900000
5.097 2.517000 27.69300 42.50000 1.001130 0.07669258 0.02285147 3.001952E-10
5.155 2.575000 28.76300 45.00000 1.003410 0.08821300 -0.05536271 -9.295917E-10
5.211 2.631000 29.90600 47.50000 1.008250 0.02754030 -0.06015985 9.598298E-10
5.265 2.685000 31.12800 50.00000 1.014460 -0.1126019 0.006008856 -3.304204E-10
]]></om:result>
    </tuhh:WPointsObservation>
   </wb1d2d:pointsMember>
   <wb1d2d:polynomialMember>
    <math:Polynomial1D gml:id="Polynomial1D11903967140783">
     <gml:description>Q1(h)</gml:description>
     <gml:name>Q1(h)</gml:name>
     <math:coefficients>12.7486619475 -43.7417630923 54.4371634025 -21.4533340181 3.41565256692</math:coefficients>
     <math:minRange>0.741</math:minRange>
     <math:maxRange>2.685</math:maxRange>
     <math:domainPhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonRunoff"/>
     <math:rangePhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonWaterlevel"/>
    </math:Polynomial1D>
   </wb1d2d:polynomialMember>
   <wb1d2d:polynomialMember>
    <math:Polynomial1D gml:id="Polynomial1D11903967140784">
     <gml:description>A1(h)</gml:description>
     <gml:name>A1(h)</gml:name>
     <math:coefficients>-0.939917727044 2.32172923024 8.10677227222 -3.23075767507 0.573663266015</math:coefficients>
     <math:minRange>0.741</math:minRange>
     <math:maxRange>2.685</math:maxRange>
     <math:domainPhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonArea"/>
     <math:rangePhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonWaterlevel"/>
    </math:Polynomial1D>
   </wb1d2d:polynomialMember>
   <wb1d2d:polynomialMember>
    <math:Polynomial1D gml:id="Polynomial1D11903967140785">
     <gml:description>al1(h)</gml:description>
     <gml:name>al1(h)</gml:name>
     <math:coefficients>1.0</math:coefficients>
     <math:minRange>0.741</math:minRange>
     <math:maxRange>2.456</math:maxRange>
     <math:domainPhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonAlpha"/>
     <math:rangePhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonWaterlevel"/>
    </math:Polynomial1D>
   </wb1d2d:polynomialMember>
   <wb1d2d:polynomialMember>
    <math:Polynomial1D gml:id="Polynomial1D11903967140781">
     <gml:description>Spl_al</gml:description>
     <gml:name>Spl_al</gml:name>
     <math:coefficients>116.080441711 -138.707219717 55.7181870163 -7.459214582</math:coefficients>
     <math:minRange>2.456</math:minRange>
     <math:maxRange>2.517</math:maxRange>
     <math:domainPhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonAlpha"/>
     <math:rangePhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonWaterlevel"/>
    </math:Polynomial1D>
   </wb1d2d:polynomialMember>
   <wb1d2d:polynomialMember>
    <math:Polynomial1D gml:id="Polynomial1D11903967140787">
     <gml:description>al2(h)</gml:description>
     <gml:name>al2(h)</gml:name>
     <math:coefficients>19.1694497294 -20.237235463 7.47335954414 -0.914157877119</math:coefficients>
     <math:minRange>2.517</math:minRange>
     <math:maxRange>2.685</math:maxRange>
     <math:domainPhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonAlpha"/>
     <math:rangePhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonWaterlevel"/>
    </math:Polynomial1D>
   </wb1d2d:polynomialMember>
   <wb1d2d:station>58.4500</wb1d2d:station>
   <wb1d2d:profileMember xlink:href="terrain.gml#Profile119039671284337"/>
   <wb1d2d:slope>0.00100</wb1d2d:slope>
  </wb1d2d:TeschkeFlowRelation>
 </simBase:flowRelationshipMember>
 <simBase:flowRelationshipMember>
  <wb1d2d:TeschkeFlowRelation gml:id="TeschkeFlowRelation11903967140787">
   <gml:description>Gelesen aus: PROF0058.4900.txt</gml:description>
   <gml:name>58.4900</gml:name>
   <simBase:position>
    <gml:Point xmlns:ns1="http://www.w3.org/2001/SMIL20/" xmlns:st="http://www.seegrid.csiro.au/xml/st" xmlns:ns2="http://www.isotc211.org/2005/gmd" xmlns:ns3="http://www.isotc211.org/2005/gco" xmlns:ns4="http://www.isotc211.org/2005/gts" xmlns:ns5="http://www.isotc211.org/2005/gss" xmlns:ns6="http://www.isotc211.org/2005/gsr" xmlns:ns7="http://www.w3.org/2001/SMIL20/Language" srsName="EPSG:31467">
     <gml:coordinates ts="," decimal="." cs=" ">3552948.742355551 5986913.666396087 2.37</gml:coordinates>
    </gml:Point>
   </simBase:position>
   <wb1d2d:pointsMember>
    <tuhh:WPointsObservation gml:id="WPointsObservation11903967140785">
     <gml:description>�bernommen aus Datei: PROF0058.4900.txt</gml:description>
     <gml:name>0058.4900</gml:name>
     <om:resultDefinition>
      <swe:RecordDefinition gml:id="RecordDefinition11903967140787">
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#Waterlevel"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#Depth"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#Area"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#Runoff"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#Alpha"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#DeltaArea"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#DeltaRunoff"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#DeltaAlpha"/>
      </swe:RecordDefinition>
     </om:resultDefinition>
     <om:result><![CDATA[3.180 0.8100000 3.843000 2.500000 1.000000 -0.004697325 -0.01448762 0E-7
3.415 1.045000 6.069000 5.000000 1.000000 0.02906218 0.02426463 0E-7
3.586 1.216000 7.833000 7.500000 1.000000 -0.01295145 0.04668804 0E-7
3.734 1.364000 9.425000 10.00000 1.000000 -0.03552550 0.02460521 0E-7
3.865 1.495000 10.87900 12.50000 1.000000 -0.02168134 -0.1182327 0E-7
3.995 1.625000 12.38900 15.00000 1.000000 0.01347464 -0.1533484 0E-7
4.133 1.763000 14.11600 17.50000 1.000000 0.04035425 0.1001070 0E-7
4.252 1.882000 15.74900 20.00000 1.000000 0.02802248 0.1087628 0E-7
4.363 1.993000 17.36900 22.50000 1.000000 0.02187316 0.09382728 0E-7
4.466 2.096000 18.98700 25.00000 1.000000 -0.0009196220 0.06273509 0E-7
4.560 2.190000 20.55400 27.50000 1.000000 -0.02245732 -0.009460599 0E-7
4.647 2.277000 22.08000 30.00000 1.000000 -0.03575037 -0.07825550 0E-7
4.728 2.358000 23.56800 32.50000 1.000000 -0.03923901 -0.1225805 0E-7
4.804 2.434000 25.02300 35.00000 1.000000 -0.03045813 -0.1196905 0E-7
4.874 2.504000 26.42400 37.50000 1.000000 -0.01913303 -0.1174351 0E-7
4.943 2.573000 27.83900 40.00000 1.000000 0.02122836 0.05974580 0E-7
5.007 2.637000 29.19900 42.50000 1.000000 0.06982936 0.2532146 0E-7
5.060 2.690000 30.40500 45.00000 1.001190 0.07485170 0.1535222 2.583489E-12
5.108 2.738000 31.58900 47.50000 1.004610 0.02367427 -0.02772956 -5.192957E-12
5.154 2.784000 32.83100 50.00000 1.009040 -0.09955730 -0.1662521 2.611023E-12
]]></om:result>
    </tuhh:WPointsObservation>
   </wb1d2d:pointsMember>
   <wb1d2d:polynomialMember>
    <math:Polynomial1D gml:id="Polynomial1D119039671409311">
     <gml:description>Q1(h)</gml:description>
     <gml:name>Q1(h)</gml:name>
     <math:coefficients>13.2910628131 -44.9307429734 54.2526585184 -21.6333429552 3.46141935046</math:coefficients>
     <math:minRange>0.81</math:minRange>
     <math:maxRange>2.784</math:maxRange>
     <math:domainPhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonRunoff"/>
     <math:rangePhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonWaterlevel"/>
    </math:Polynomial1D>
   </wb1d2d:polynomialMember>
   <wb1d2d:polynomialMember>
    <math:Polynomial1D gml:id="Polynomial1D11903967140936">
     <gml:description>A1(h)</gml:description>
     <gml:name>A1(h)</gml:name>
     <math:coefficients>-3.91367659808 10.1928381647 -1.32382705944 0.614539313999 0.0876998400321</math:coefficients>
     <math:minRange>0.81</math:minRange>
     <math:maxRange>2.784</math:maxRange>
     <math:domainPhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonArea"/>
     <math:rangePhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonWaterlevel"/>
    </math:Polynomial1D>
   </wb1d2d:polynomialMember>
   <wb1d2d:polynomialMember>
    <math:Polynomial1D gml:id="Polynomial1D11903967140935">
     <gml:description>al1(h)</gml:description>
     <gml:name>al1(h)</gml:name>
     <math:coefficients>1.0</math:coefficients>
     <math:minRange>0.81</math:minRange>
     <math:maxRange>2.637</math:maxRange>
     <math:domainPhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonAlpha"/>
     <math:rangePhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonWaterlevel"/>
    </math:Polynomial1D>
   </wb1d2d:polynomialMember>
   <wb1d2d:polynomialMember>
    <math:Polynomial1D gml:id="Polynomial1D119039671409310">
     <gml:description>Spl_al</gml:description>
     <gml:name>Spl_al</gml:name>
     <math:coefficients>-86.2902087324 99.7491935148 -37.9947364372 4.82400486483</math:coefficients>
     <math:minRange>2.637</math:minRange>
     <math:maxRange>2.69</math:maxRange>
     <math:domainPhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonAlpha"/>
     <math:rangePhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonWaterlevel"/>
    </math:Polynomial1D>
   </wb1d2d:polynomialMember>
   <wb1d2d:polynomialMember>
    <math:Polynomial1D gml:id="Polynomial1D11903967140931">
     <gml:description>al2(h)</gml:description>
     <gml:name>al2(h)</gml:name>
     <math:coefficients>2.77262096999 -1.37550533846 0.266535618699</math:coefficients>
     <math:minRange>2.69</math:minRange>
     <math:maxRange>2.784</math:maxRange>
     <math:domainPhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonAlpha"/>
     <math:rangePhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonWaterlevel"/>
    </math:Polynomial1D>
   </wb1d2d:polynomialMember>
   <wb1d2d:station>58.4900</wb1d2d:station>
   <wb1d2d:profileMember xlink:href="terrain.gml#Profile1190396712859225"/>
   <wb1d2d:slope>0.00100</wb1d2d:slope>
  </wb1d2d:TeschkeFlowRelation>
 </simBase:flowRelationshipMember>
 <simBase:flowRelationshipMember>
  <wb1d2d:TeschkeFlowRelation gml:id="TeschkeFlowRelation11903967140930">
   <gml:description>Gelesen aus: PROF0058.5500.txt</gml:description>
   <gml:name>58.5500</gml:name>
   <simBase:position>
    <gml:Point xmlns:ns1="http://www.w3.org/2001/SMIL20/" xmlns:st="http://www.seegrid.csiro.au/xml/st" xmlns:ns2="http://www.isotc211.org/2005/gmd" xmlns:ns3="http://www.isotc211.org/2005/gco" xmlns:ns4="http://www.isotc211.org/2005/gts" xmlns:ns5="http://www.isotc211.org/2005/gss" xmlns:ns6="http://www.isotc211.org/2005/gsr" xmlns:ns7="http://www.w3.org/2001/SMIL20/Language" srsName="EPSG:31467">
     <gml:coordinates ts="," decimal="." cs=" ">3552922.4821555736 5986950.916196042 2.61</gml:coordinates>
    </gml:Point>
   </simBase:position>
   <wb1d2d:pointsMember>
    <tuhh:WPointsObservation gml:id="WPointsObservation119039671409314">
     <gml:description>�bernommen aus Datei: PROF0058.5500.txt</gml:description>
     <gml:name>0058.5500</gml:name>
     <om:resultDefinition>
      <swe:RecordDefinition gml:id="RecordDefinition11903967140938">
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#Waterlevel"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#Depth"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#Area"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#Runoff"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#Alpha"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#DeltaArea"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#DeltaRunoff"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#DeltaAlpha"/>
      </swe:RecordDefinition>
     </om:resultDefinition>
     <om:result><![CDATA[3.256 0.6460000 3.951000 2.500000 1.000000 0.8876066 0.3313898 0E-7
3.499 0.8890000 6.319000 5.000000 1.000000 -2.046111 -0.7445817 0E-7
3.675 1.065000 8.210000 7.500000 1.000000 -0.6585091 -0.2564739 0E-7
3.828 1.218000 9.924000 10.00000 1.000000 0.8353877 0.2878845 0E-7
3.966 1.356000 11.52000 12.50000 1.000000 1.576618 0.5431068 0E-7
4.095 1.485000 13.06300 15.00000 1.000000 1.458241 0.5090786 0E-7
4.219 1.609000 14.60200 17.50000 1.000000 0.6394078 0.2962035 0E-7
4.334 1.724000 16.08700 20.00000 1.000000 -0.4936425 -0.05286188 0E-7
4.439 1.829000 17.50500 22.50000 1.000000 -1.497631 -0.4177167 0E-7
4.530 1.920000 18.84200 25.00000 1.003100 -2.051794 -0.7909589 0.0002577642
4.618 2.008000 20.24000 27.50000 1.007840 -1.958242 -0.8430185 -0.001503353
4.702 2.092000 21.67400 30.00000 1.013530 -0.9295951 -0.4979929 0.003746918
4.777 2.167000 23.15500 32.50000 1.022890 0.9710039 0.09497987 -0.004877881
4.842 2.232000 25.14000 35.00000 1.050020 3.071469 0.8006260 0.003333852
4.893 2.283000 29.53200 37.50000 1.153300 2.788662 1.219824 -0.0009573011
4.927 2.317000 34.48400 40.00000 1.244820 1.080397 0.8890446 -1.244820
4.957 2.347000 38.80200 42.50000 1.299080 -0.006778620 0.4650722 -1.299080
4.982 2.372000 42.58800 45.00000 1.332280 -0.8169815 -0.1809361 -1.332280
5.009 2.399000 46.57800 47.50000 1.356250 -1.284884 -0.5443336 -1.356250
5.032 2.422000 50.12500 50.00000 1.370310 -1.564624 -1.108336 -1.370310
]]></om:result>
    </tuhh:WPointsObservation>
   </wb1d2d:pointsMember>
   <wb1d2d:polynomialMember>
    <math:Polynomial1D gml:id="Polynomial1D119039671409313">
     <gml:description>Q1(h)</gml:description>
     <gml:name>Q1(h)</gml:name>
     <math:coefficients>46.1401070784 -160.579802582 200.42683422 -97.3659602242 17.4158910732</math:coefficients>
     <math:minRange>0.646</math:minRange>
     <math:maxRange>2.422</math:maxRange>
     <math:domainPhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonRunoff"/>
     <math:rangePhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonWaterlevel"/>
    </math:Polynomial1D>
   </wb1d2d:polynomialMember>
   <wb1d2d:polynomialMember>
    <math:Polynomial1D gml:id="Polynomial1D119039671409320">
     <gml:description>A1(h)</gml:description>
     <gml:name>A1(h)</gml:name>
     <math:coefficients>112.57062797 -384.997426583 473.2620633 -237.090776497 42.4505258037</math:coefficients>
     <math:minRange>0.646</math:minRange>
     <math:maxRange>2.422</math:maxRange>
     <math:domainPhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonArea"/>
     <math:rangePhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonWaterlevel"/>
    </math:Polynomial1D>
   </wb1d2d:polynomialMember>
   <wb1d2d:polynomialMember>
    <math:Polynomial1D gml:id="Polynomial1D119039671409315">
     <gml:description>al1(h)</gml:description>
     <gml:name>al1(h)</gml:name>
     <math:coefficients>1.0</math:coefficients>
     <math:minRange>0.646</math:minRange>
     <math:maxRange>1.829</math:maxRange>
     <math:domainPhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonAlpha"/>
     <math:rangePhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonWaterlevel"/>
    </math:Polynomial1D>
   </wb1d2d:polynomialMember>
   <wb1d2d:polynomialMember>
    <math:Polynomial1D gml:id="Polynomial1D119039671409316">
     <gml:description>Spl_al</gml:description>
     <gml:name>Spl_al</gml:name>
     <math:coefficients>373.476725305 -600.592781787 322.708653834 -57.7811358422</math:coefficients>
     <math:minRange>1.829</math:minRange>
     <math:maxRange>1.92</math:maxRange>
     <math:domainPhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonAlpha"/>
     <math:rangePhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonWaterlevel"/>
    </math:Polynomial1D>
   </wb1d2d:polynomialMember>
   <wb1d2d:polynomialMember>
    <math:Polynomial1D gml:id="Polynomial1D119039671409317">
     <gml:description>al2(h)</gml:description>
     <gml:name>al2(h)</gml:name>
     <math:coefficients>1488.18955719 -2890.59186072 2105.12682786 -680.82989648 82.5081628986</math:coefficients>
     <math:minRange>1.92</math:minRange>
     <math:maxRange>2.283</math:maxRange>
     <math:domainPhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonAlpha"/>
     <math:rangePhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonWaterlevel"/>
    </math:Polynomial1D>
   </wb1d2d:polynomialMember>
   <wb1d2d:station>58.5500</wb1d2d:station>
   <wb1d2d:profileMember xlink:href="terrain.gml#Profile1190396712859236"/>
   <wb1d2d:slope>0.00100</wb1d2d:slope>
  </wb1d2d:TeschkeFlowRelation>
 </simBase:flowRelationshipMember>
 <simBase:flowRelationshipMember>
  <wb1d2d:TeschkeFlowRelation gml:id="TeschkeFlowRelation119039671409318">
   <gml:description>Gelesen aus: PROF0058.6000.txt</gml:description>
   <gml:name>58.6000</gml:name>
   <simBase:position>
    <gml:Point xmlns:ns1="http://www.w3.org/2001/SMIL20/" xmlns:st="http://www.seegrid.csiro.au/xml/st" xmlns:ns2="http://www.isotc211.org/2005/gmd" xmlns:ns3="http://www.isotc211.org/2005/gco" xmlns:ns4="http://www.isotc211.org/2005/gts" xmlns:ns5="http://www.isotc211.org/2005/gss" xmlns:ns6="http://www.isotc211.org/2005/gsr" xmlns:ns7="http://www.w3.org/2001/SMIL20/Language" srsName="EPSG:31467">
     <gml:coordinates ts="," decimal="." cs=" ">3552898.109255594 5986988.048495999 2.76</gml:coordinates>
    </gml:Point>
   </simBase:position>
   <wb1d2d:pointsMember>
    <tuhh:WPointsObservation gml:id="WPointsObservation119039671409319">
     <gml:description>�bernommen aus Datei: PROF0058.6000.txt</gml:description>
     <gml:name>0058.6000</gml:name>
     <om:resultDefinition>
      <swe:RecordDefinition gml:id="RecordDefinition11903967140936">
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#Waterlevel"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#Depth"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#Area"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#Runoff"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#Alpha"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#DeltaArea"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#DeltaRunoff"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#DeltaAlpha"/>
      </swe:RecordDefinition>
     </om:resultDefinition>
     <om:result><![CDATA[3.270 0.5100000 4.270000 2.500000 1.000000 -0.01472452 0.007996279 0E-7
3.488 0.7280000 6.684000 5.000000 1.000000 0.03504661 -0.03552571 0E-7
3.654 0.8940000 8.701000 7.500000 1.000000 0.003268167 0.03353061 0E-7
3.791 1.031000 10.40300 10.00000 1.000000 -0.01107941 0.01489764 0E-7
3.915 1.155000 11.96900 12.50000 1.000000 -0.02018105 -0.003298769 0E-7
4.031 1.271000 13.43800 15.00000 1.000000 -0.01113003 -0.004244691 0E-7
4.140 1.380000 14.84400 17.50000 1.000000 -0.009943529 -0.01393069 0E-7
4.242 1.482000 16.17000 20.00000 1.000000 -0.001857647 -0.06545767 0E-7
4.344 1.584000 17.51000 22.50000 1.000000 0.01156963 -0.004435106 0E-7
4.442 1.682000 18.82200 25.00000 1.000000 0.02189207 0.06459111 0E-7
4.535 1.775000 20.09900 27.50000 1.000000 0.02409904 0.1062352 0E-7
4.619 1.859000 21.29400 30.00000 1.000960 0.009234267 -0.004572146 -0.0009600000
4.702 1.942000 22.50200 32.50000 1.001970 -0.005090442 -0.04865160 -0.000004522947
4.783 2.023000 23.70200 35.00000 1.003160 -0.008963700 -0.05159906 -0.000001878817
4.860 2.100000 24.89000 37.50000 1.004370 -0.02654054 -0.07636389 0.00005304417
4.936 2.176000 26.07700 40.00000 1.005700 -0.02151777 -0.02595623 -0.00005776960
5.010 2.250000 27.26000 42.50000 1.007090 -0.003757364 0.07057262 -0.0001197068
5.079 2.319000 28.39200 45.00000 1.008430 0.02414549 0.1025975 0.0003060979
5.141 2.381000 29.47700 47.50000 1.011490 0.01835093 -0.02226345 -0.0002349565
5.203 2.443000 30.62600 50.00000 1.015200 -0.01282020 -0.04412194 0.00005969254
]]></om:result>
    </tuhh:WPointsObservation>
   </wb1d2d:pointsMember>
   <wb1d2d:polynomialMember>
    <math:Polynomial1D gml:id="Polynomial1D11903967140937">
     <gml:description>Q1(h)</gml:description>
     <gml:name>Q1(h)</gml:name>
     <math:coefficients>2.81652908112 -11.6761830096 26.0845929473 -9.39713173538 1.60020122528</math:coefficients>
     <math:minRange>0.51</math:minRange>
     <math:maxRange>2.443</math:maxRange>
     <math:domainPhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonRunoff"/>
     <math:rangePhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonWaterlevel"/>
    </math:Polynomial1D>
   </wb1d2d:polynomialMember>
   <wb1d2d:polynomialMember>
    <math:Polynomial1D gml:id="Polynomial1D119039671409327">
     <gml:description>A1(h)</gml:description>
     <gml:name>A1(h)</gml:name>
     <math:coefficients>-0.348287276699 6.66200273857 5.90094589037 -2.76202259721 0.554165233943</math:coefficients>
     <math:minRange>0.51</math:minRange>
     <math:maxRange>2.443</math:maxRange>
     <math:domainPhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonArea"/>
     <math:rangePhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonWaterlevel"/>
    </math:Polynomial1D>
   </wb1d2d:polynomialMember>
   <wb1d2d:polynomialMember>
    <math:Polynomial1D gml:id="Polynomial1D119039671409328">
     <gml:description>al1(h)</gml:description>
     <gml:name>al1(h)</gml:name>
     <math:coefficients>1.0</math:coefficients>
     <math:minRange>0.51</math:minRange>
     <math:maxRange>1.859</math:maxRange>
     <math:domainPhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonAlpha"/>
     <math:rangePhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonWaterlevel"/>
    </math:Polynomial1D>
   </wb1d2d:polynomialMember>
   <wb1d2d:polynomialMember>
    <math:Polynomial1D gml:id="Polynomial1D119039671409312">
     <gml:description>Spl_al</gml:description>
     <gml:name>Spl_al</gml:name>
     <math:coefficients>36.5143186597 -55.9877614985 29.4048149437 -5.14478946295</math:coefficients>
     <math:minRange>1.859</math:minRange>
     <math:maxRange>1.942</math:maxRange>
     <math:domainPhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonAlpha"/>
     <math:rangePhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonWaterlevel"/>
    </math:Polynomial1D>
   </wb1d2d:polynomialMember>
   <wb1d2d:polynomialMember>
    <math:Polynomial1D gml:id="Polynomial1D11903967140932">
     <gml:description>al2(h)</gml:description>
     <gml:name>al2(h)</gml:name>
     <math:coefficients>8.70629429207 -14.7706156756 10.5941406407 -3.37187502122 0.402260170255</math:coefficients>
     <math:minRange>1.942</math:minRange>
     <math:maxRange>2.443</math:maxRange>
     <math:domainPhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonAlpha"/>
     <math:rangePhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonWaterlevel"/>
    </math:Polynomial1D>
   </wb1d2d:polynomialMember>
   <wb1d2d:station>58.6000</wb1d2d:station>
   <wb1d2d:profileMember xlink:href="terrain.gml#Profile11903967128753"/>
   <wb1d2d:slope>0.00100</wb1d2d:slope>
  </wb1d2d:TeschkeFlowRelation>
 </simBase:flowRelationshipMember>
 <simBase:flowRelationshipMember>
  <wb1d2d:TeschkeFlowRelation gml:id="TeschkeFlowRelation119039671409329">
   <gml:description>Gelesen aus: PROF0058.6500.txt</gml:description>
   <gml:name>58.6500</gml:name>
   <simBase:position>
    <gml:Point xmlns:ns1="http://www.w3.org/2001/SMIL20/" xmlns:st="http://www.seegrid.csiro.au/xml/st" xmlns:ns2="http://www.isotc211.org/2005/gmd" xmlns:ns3="http://www.isotc211.org/2005/gco" xmlns:ns4="http://www.isotc211.org/2005/gts" xmlns:ns5="http://www.isotc211.org/2005/gss" xmlns:ns6="http://www.isotc211.org/2005/gsr" xmlns:ns7="http://www.w3.org/2001/SMIL20/Language" srsName="EPSG:31467">
     <gml:coordinates ts="," decimal="." cs=" ">3552873.290355615 5987024.335495955 2.54</gml:coordinates>
    </gml:Point>
   </simBase:position>
   <wb1d2d:pointsMember>
    <tuhh:WPointsObservation gml:id="WPointsObservation11903967140931">
     <gml:description>�bernommen aus Datei: PROF0058.6500.txt</gml:description>
     <gml:name>0058.6500</gml:name>
     <om:resultDefinition>
      <swe:RecordDefinition gml:id="RecordDefinition119039671409331">
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#Waterlevel"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#Depth"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#Area"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#Runoff"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#Alpha"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#DeltaArea"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#DeltaRunoff"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#DeltaAlpha"/>
      </swe:RecordDefinition>
     </om:resultDefinition>
     <om:result><![CDATA[3.098 0.5580000 4.039000 2.500000 1.000000 -0.0007219283 0.2101282 0E-7
3.317 0.7770000 6.232000 5.000000 1.000000 0.0002120053 -0.3181487 0E-7
3.494 0.9540000 8.132000 7.500000 1.000000 -0.001066211 -0.2035198 0E-7
3.641 1.101000 9.765000 10.00000 1.000000 0.0008866689 -0.06642568 0E-7
3.779 1.239000 11.33100 12.50000 1.000000 0.005041142 0.1672838 0E-7
3.902 1.362000 12.75200 15.00000 1.000000 0.007269415 0.2443508 0E-7
4.020 1.480000 14.14900 17.50000 1.000000 -0.004511983 0.2989223 0E-7
4.131 1.591000 15.46900 20.00000 1.000000 -0.002405226 0.2524597 0E-7
4.235 1.695000 16.73500 22.50000 1.000000 -0.01001647 0.08584072 0E-7
4.336 1.796000 17.98500 25.00000 1.000000 -0.01568924 -0.1169609 0E-7
4.431 1.891000 19.17100 27.50000 1.000000 -0.006629444 -0.4227059 0E-7
4.529 1.989000 20.41400 30.00000 1.000000 0.01401020 -0.6135371 0E-7
4.649 2.109000 22.00300 32.50000 1.000000 0.02530470 -0.1965657 0E-7
4.759 2.219000 23.54100 35.00000 1.000000 0.01779244 0.1000905 0E-7
4.860 2.320000 25.03700 37.50000 1.000000 -0.007350708 0.3104727 0E-7
4.955 2.415000 26.49800 40.00000 1.000000 -0.01654351 0.5226438 0E-7
5.029 2.489000 27.68600 42.50000 1.000000 -0.02056381 0.2708139 0E-7
5.094 2.554000 28.75700 45.00000 1.000810 -0.008335515 -0.1381908 -0.0008100000
5.160 2.620000 29.87100 47.50000 1.001700 0.02331746 -0.3869518 -1.001700
4.048 1.508000 14.47700 50.00000 1.000000 -14.47700 -50.00000 -1.000000
]]></om:result>
    </tuhh:WPointsObservation>
   </wb1d2d:pointsMember>
   <wb1d2d:polynomialMember>
    <math:Polynomial1D gml:id="Polynomial1D119039671410935">
     <gml:description>Q1(h)</gml:description>
     <gml:name>Q1(h)</gml:name>
     <math:coefficients>8.89885836012 -31.7872123268 46.3415960002 -18.1079694646 2.73888740613</math:coefficients>
     <math:minRange>0.558</math:minRange>
     <math:maxRange>2.62</math:maxRange>
     <math:domainPhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonRunoff"/>
     <math:rangePhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonWaterlevel"/>
    </math:Polynomial1D>
   </wb1d2d:polynomialMember>
   <wb1d2d:polynomialMember>
    <math:Polynomial1D gml:id="Polynomial1D119039671410928">
     <gml:description>A1(h)</gml:description>
     <gml:name>A1(h)</gml:name>
     <math:coefficients>-0.0993632936239 4.61964674417 6.43028801276 -2.83953969824 0.526708256051</math:coefficients>
     <math:minRange>0.558</math:minRange>
     <math:maxRange>2.62</math:maxRange>
     <math:domainPhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonArea"/>
     <math:rangePhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonWaterlevel"/>
    </math:Polynomial1D>
   </wb1d2d:polynomialMember>
   <wb1d2d:polynomialMember>
    <math:Polynomial1D gml:id="Polynomial1D11903967141090">
     <gml:description>al1(h)</gml:description>
     <gml:name>al1(h)</gml:name>
     <math:coefficients>1.0</math:coefficients>
     <math:minRange>0.558</math:minRange>
     <math:maxRange>2.554</math:maxRange>
     <math:domainPhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonAlpha"/>
     <math:rangePhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonWaterlevel"/>
    </math:Polynomial1D>
   </wb1d2d:polynomialMember>
   <wb1d2d:polynomialMember>
    <math:Polynomial1D gml:id="Polynomial1D119039671410913">
     <gml:description>Spl_al</gml:description>
     <gml:name>Spl_al</gml:name>
     <math:coefficients>0.0</math:coefficients>
     <math:minRange>2.554</math:minRange>
     <math:maxRange>2.554</math:maxRange>
     <math:domainPhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonAlpha"/>
     <math:rangePhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonWaterlevel"/>
    </math:Polynomial1D>
   </wb1d2d:polynomialMember>
   <wb1d2d:polynomialMember>
    <math:Polynomial1D gml:id="Polynomial1D119039671410939">
     <gml:description>al2(h)</gml:description>
     <gml:name>al2(h)</gml:name>
     <math:coefficients>0.0</math:coefficients>
     <math:minRange>2.554</math:minRange>
     <math:maxRange>2.554</math:maxRange>
     <math:domainPhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonAlpha"/>
     <math:rangePhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonWaterlevel"/>
    </math:Polynomial1D>
   </wb1d2d:polynomialMember>
   <wb1d2d:station>58.6500</wb1d2d:station>
   <wb1d2d:profileMember xlink:href="terrain.gml#Profile1190396712890169"/>
   <wb1d2d:slope>0.00100</wb1d2d:slope>
  </wb1d2d:TeschkeFlowRelation>
 </simBase:flowRelationshipMember>
 <simBase:flowRelationshipMember>
  <wb1d2d:TeschkeFlowRelation gml:id="TeschkeFlowRelation119039671410912">
   <gml:description>Gelesen aus: PROF0058.7000.txt</gml:description>
   <gml:name>58.7000</gml:name>
   <simBase:position>
    <gml:Point xmlns:ns1="http://www.w3.org/2001/SMIL20/" xmlns:st="http://www.seegrid.csiro.au/xml/st" xmlns:ns2="http://www.isotc211.org/2005/gmd" xmlns:ns3="http://www.isotc211.org/2005/gco" xmlns:ns4="http://www.isotc211.org/2005/gts" xmlns:ns5="http://www.isotc211.org/2005/gss" xmlns:ns6="http://www.isotc211.org/2005/gsr" xmlns:ns7="http://www.w3.org/2001/SMIL20/Language" srsName="EPSG:31467">
     <gml:coordinates ts="," decimal="." cs=" ">3552857.550255628 5987079.98749589 2.68</gml:coordinates>
    </gml:Point>
   </simBase:position>
   <wb1d2d:pointsMember>
    <tuhh:WPointsObservation gml:id="WPointsObservation119039671410938">
     <gml:description>�bernommen aus Datei: PROF0058.7000.txt</gml:description>
     <gml:name>0058.7000</gml:name>
     <om:resultDefinition>
      <swe:RecordDefinition gml:id="RecordDefinition119039671410935">
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#Waterlevel"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#Depth"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#Area"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#Runoff"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#Alpha"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#DeltaArea"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#DeltaRunoff"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#DeltaAlpha"/>
      </swe:RecordDefinition>
     </om:resultDefinition>
     <om:result><![CDATA[3.210 0.5300000 4.099000 2.500000 1.000000 1.342625 0.001184872 0E-7
3.427 0.7470000 6.383000 5.000000 1.000000 -1.764799 -0.003122590 0E-7
3.592 0.9120000 8.242000 7.500000 1.000000 -1.466701 -0.01835140 0E-7
3.736 1.056000 9.891000 10.00000 1.000000 -0.4214607 -0.002801935 0E-7
3.867 1.187000 11.41600 12.50000 1.000000 0.5853114 0.02720430 0E-7
3.988 1.308000 12.85100 15.00000 1.000000 1.251150 0.04260783 0E-7
4.101 1.421000 14.21800 17.50000 1.000000 1.491879 0.02875965 0E-7
4.209 1.529000 15.53000 20.00000 1.000000 1.347308 0.01592859 0E-7
4.311 1.631000 16.79600 22.50000 1.000000 0.8710234 -0.04434410 0E-7
4.410 1.730000 18.02400 25.00000 1.000000 0.1862293 -0.09842789 0E-7
4.508 1.828000 19.26400 27.50000 1.000000 -0.6232977 -0.1061350 0E-7
4.605 1.925000 20.52600 30.00000 1.000000 -1.415660 -0.07267485 0E-7
4.703 2.023000 21.81600 32.50000 1.000000 -1.994411 0.05244770 0E-7
4.803 2.123000 23.19400 35.00000 1.000000 -2.155149 0.2986241 0E-7
4.888 2.208000 24.42200 37.50000 1.000930 -1.737358 0.1871583 -0.0009300000
4.968 2.288000 25.68200 40.00000 1.003760 -0.7369107 -0.01793170 1.667011E-10
5.044 2.364000 26.98600 42.50000 1.007710 0.9268041 -0.2940040 -4.377954E-10
5.133 2.453000 28.62800 45.00000 1.013230 4.027738 -0.1326575 4.013434E-10
5.221 2.541000 30.39500 47.50000 1.018960 8.596187 0.06311913 -1.302485E-10
5.301 2.621000 54.76800 50.00000 1.354760 -8.310508 0.07341642 -1.354760
]]></om:result>
    </tuhh:WPointsObservation>
   </wb1d2d:pointsMember>
   <wb1d2d:polynomialMember>
    <math:Polynomial1D gml:id="Polynomial1D11903967141095">
     <gml:description>Q1(h)</gml:description>
     <gml:name>Q1(h)</gml:name>
     <math:coefficients>1.36439946757 -6.10454260889 17.9608697564 -4.84044235333 0.603451281163</math:coefficients>
     <math:minRange>0.53</math:minRange>
     <math:maxRange>2.621</math:maxRange>
     <math:domainPhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonRunoff"/>
     <math:rangePhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonWaterlevel"/>
    </math:Polynomial1D>
   </wb1d2d:polynomialMember>
   <wb1d2d:polynomialMember>
    <math:Polynomial1D gml:id="Polynomial1D11903967141094">
     <gml:description>A1(h)</gml:description>
     <gml:name>A1(h)</gml:name>
     <math:coefficients>50.213518808 -176.528611037 228.061825201 -113.00710261 19.6421703906</math:coefficients>
     <math:minRange>0.53</math:minRange>
     <math:maxRange>2.621</math:maxRange>
     <math:domainPhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonArea"/>
     <math:rangePhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonWaterlevel"/>
    </math:Polynomial1D>
   </wb1d2d:polynomialMember>
   <wb1d2d:polynomialMember>
    <math:Polynomial1D gml:id="Polynomial1D119039671410911">
     <gml:description>al1(h)</gml:description>
     <gml:name>al1(h)</gml:name>
     <math:coefficients>1.0</math:coefficients>
     <math:minRange>0.53</math:minRange>
     <math:maxRange>2.208</math:maxRange>
     <math:domainPhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonAlpha"/>
     <math:rangePhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonWaterlevel"/>
    </math:Polynomial1D>
   </wb1d2d:polynomialMember>
   <wb1d2d:polynomialMember>
    <math:Polynomial1D gml:id="Polynomial1D119039671410942">
     <gml:description>Spl_al</gml:description>
     <gml:name>Spl_al</gml:name>
     <math:coefficients>88.9317883795 -116.828241318 51.7137427881 -7.62622952895</math:coefficients>
     <math:minRange>2.208</math:minRange>
     <math:maxRange>2.288</math:maxRange>
     <math:domainPhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonAlpha"/>
     <math:rangePhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonWaterlevel"/>
    </math:Polynomial1D>
   </wb1d2d:polynomialMember>
   <wb1d2d:polynomialMember>
    <math:Polynomial1D gml:id="Polynomial1D119039671410922">
     <gml:description>al2(h)</gml:description>
     <gml:name>al2(h)</gml:name>
     <math:coefficients>3.49222023568 -3.11921046861 1.28076380426 -0.1716906341</math:coefficients>
     <math:minRange>2.288</math:minRange>
     <math:maxRange>2.541</math:maxRange>
     <math:domainPhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonAlpha"/>
     <math:rangePhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonWaterlevel"/>
    </math:Polynomial1D>
   </wb1d2d:polynomialMember>
   <wb1d2d:station>58.7000</wb1d2d:station>
   <wb1d2d:profileMember xlink:href="terrain.gml#Profile1190396712890189"/>
   <wb1d2d:slope>0.00100</wb1d2d:slope>
  </wb1d2d:TeschkeFlowRelation>
 </simBase:flowRelationshipMember>
 <simBase:flowRelationshipMember>
  <wb1d2d:TeschkeFlowRelation gml:id="TeschkeFlowRelation119039671410939">
   <gml:description>Gelesen aus: PROF0058.7500.txt</gml:description>
   <gml:name>58.7500</gml:name>
   <simBase:position>
    <gml:Point xmlns:ns1="http://www.w3.org/2001/SMIL20/" xmlns:st="http://www.seegrid.csiro.au/xml/st" xmlns:ns2="http://www.isotc211.org/2005/gmd" xmlns:ns3="http://www.isotc211.org/2005/gco" xmlns:ns4="http://www.isotc211.org/2005/gts" xmlns:ns5="http://www.isotc211.org/2005/gss" xmlns:ns6="http://www.isotc211.org/2005/gsr" xmlns:ns7="http://www.w3.org/2001/SMIL20/Language" srsName="EPSG:31467">
     <gml:coordinates ts="," decimal="." cs=" ">3552856.334655629 5987128.860095832 2.68</gml:coordinates>
    </gml:Point>
   </simBase:position>
   <wb1d2d:pointsMember>
    <tuhh:WPointsObservation gml:id="WPointsObservation119039671410936">
     <gml:description>�bernommen aus Datei: PROF0058.7500.txt</gml:description>
     <gml:name>0058.7500</gml:name>
     <om:resultDefinition>
      <swe:RecordDefinition gml:id="RecordDefinition11903967141092">
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#Waterlevel"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#Depth"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#Area"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#Runoff"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#Alpha"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#DeltaArea"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#DeltaRunoff"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#DeltaAlpha"/>
      </swe:RecordDefinition>
     </om:resultDefinition>
     <om:result><![CDATA[3.291 0.6110000 4.397000 2.500000 1.000000 0.3300954 0.1350639 0E-7
3.484 0.8040000 6.753000 5.000000 1.000000 -0.4266976 -0.1717825 0E-7
3.637 0.9570000 8.671000 7.500000 1.000000 -0.3578294 -0.1733326 0E-7
3.775 1.095000 10.44200 10.00000 1.000000 -0.09692109 0.01200550 0E-7
3.892 1.212000 11.95800 12.50000 1.000000 0.1469055 0.03509295 0E-7
4.004 1.324000 13.44100 15.00000 1.000000 0.3050660 0.1153759 0E-7
4.109 1.429000 14.85200 17.50000 1.000000 0.3578426 0.1510657 0E-7
4.209 1.529000 16.20300 20.00000 1.000000 0.3221133 0.1516354 0E-7
4.304 1.624000 17.50500 22.50000 1.000000 0.2043481 0.09304822 0E-7
4.395 1.715000 18.76800 25.00000 1.000000 0.03428778 -0.01400664 0E-7
4.486 1.806000 20.04700 27.50000 1.000000 -0.1631505 -0.06964569 0E-7
4.575 1.895000 21.31800 30.00000 1.000000 -0.3488254 -0.1274278 0E-7
4.660 1.980000 22.56300 32.50000 1.000000 -0.4874579 -0.2426166 0E-7
4.744 2.064000 23.81800 35.00000 1.000000 -0.5317958 -0.3283689 0E-7
4.837 2.157000 25.25200 37.50000 1.000000 -0.4197453 -0.07692928 0E-7
4.926 2.246000 26.65500 40.00000 1.000000 -0.06080888 0.1486100 0E-7
5.009 2.329000 28.03500 42.50000 1.000000 0.5305506 0.2881058 0E-7
5.089 2.409000 29.39800 45.00000 1.000000 1.444159 0.4380309 0E-7
5.165 2.485000 30.73300 47.50000 1.000000 2.686803 0.5680349 0E-7
5.193 2.513000 37.95500 50.00000 1.150300 -3.468938 -0.9319594 -1.150300
]]></om:result>
    </tuhh:WPointsObservation>
   </wb1d2d:pointsMember>
   <wb1d2d:polynomialMember>
    <math:Polynomial1D gml:id="Polynomial1D11903967141253">
     <gml:description>Q1(h)</gml:description>
     <gml:name>Q1(h)</gml:name>
     <math:coefficients>7.37253911233 -28.1539049065 41.7731219396 -15.0677064326 2.20069573416</math:coefficients>
     <math:minRange>0.611</math:minRange>
     <math:maxRange>2.513</math:maxRange>
     <math:domainPhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonRunoff"/>
     <math:rangePhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonWaterlevel"/>
    </math:Polynomial1D>
   </wb1d2d:polynomialMember>
   <wb1d2d:polynomialMember>
    <math:Polynomial1D gml:id="Polynomial1D119039671412533">
     <gml:description>A1(h)</gml:description>
     <gml:name>A1(h)</gml:name>
     <math:coefficients>17.275541959 -57.1090338466 81.4803544837 -39.6005585439 6.88604803244</math:coefficients>
     <math:minRange>0.611</math:minRange>
     <math:maxRange>2.513</math:maxRange>
     <math:domainPhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonArea"/>
     <math:rangePhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonWaterlevel"/>
    </math:Polynomial1D>
   </wb1d2d:polynomialMember>
   <wb1d2d:polynomialMember>
    <math:Polynomial1D gml:id="Polynomial1D119039671412537">
     <gml:description>al1(h)</gml:description>
     <gml:name>al1(h)</gml:name>
     <math:coefficients>1.0</math:coefficients>
     <math:minRange>0.611</math:minRange>
     <math:maxRange>2.485</math:maxRange>
     <math:domainPhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonAlpha"/>
     <math:rangePhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonWaterlevel"/>
    </math:Polynomial1D>
   </wb1d2d:polynomialMember>
   <wb1d2d:polynomialMember>
    <math:Polynomial1D gml:id="Polynomial1D11903967141252">
     <gml:description>Spl_al</gml:description>
     <gml:name>Spl_al</gml:name>
     <math:coefficients>0.0</math:coefficients>
     <math:minRange>2.485</math:minRange>
     <math:maxRange>2.485</math:maxRange>
     <math:domainPhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonAlpha"/>
     <math:rangePhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonWaterlevel"/>
    </math:Polynomial1D>
   </wb1d2d:polynomialMember>
   <wb1d2d:polynomialMember>
    <math:Polynomial1D gml:id="Polynomial1D119039671412526">
     <gml:description>al2(h)</gml:description>
     <gml:name>al2(h)</gml:name>
     <math:coefficients>0.0</math:coefficients>
     <math:minRange>2.485</math:minRange>
     <math:maxRange>2.485</math:maxRange>
     <math:domainPhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonAlpha"/>
     <math:rangePhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonWaterlevel"/>
    </math:Polynomial1D>
   </wb1d2d:polynomialMember>
   <wb1d2d:station>58.7500</wb1d2d:station>
   <wb1d2d:profileMember xlink:href="terrain.gml#Profile1190396712906189"/>
   <wb1d2d:slope>0.00100</wb1d2d:slope>
  </wb1d2d:TeschkeFlowRelation>
 </simBase:flowRelationshipMember>
 <simBase:flowRelationshipMember>
  <wb1d2d:TeschkeFlowRelation gml:id="TeschkeFlowRelation119039671412515">
   <gml:description>Gelesen aus: PROF0058.8000.txt</gml:description>
   <gml:name>58.8000</gml:name>
   <simBase:position>
    <gml:Point xmlns:ns1="http://www.w3.org/2001/SMIL20/" xmlns:st="http://www.seegrid.csiro.au/xml/st" xmlns:ns2="http://www.isotc211.org/2005/gmd" xmlns:ns3="http://www.isotc211.org/2005/gco" xmlns:ns4="http://www.isotc211.org/2005/gts" xmlns:ns5="http://www.isotc211.org/2005/gss" xmlns:ns6="http://www.isotc211.org/2005/gsr" xmlns:ns7="http://www.w3.org/2001/SMIL20/Language" srsName="EPSG:31467">
     <gml:coordinates ts="," decimal="." cs=" ">3552861.070555625 5987182.570595766 2.11</gml:coordinates>
    </gml:Point>
   </simBase:position>
   <wb1d2d:pointsMember>
    <tuhh:WPointsObservation gml:id="WPointsObservation119039671412534">
     <gml:description>�bernommen aus Datei: PROF0058.8000.txt</gml:description>
     <gml:name>0058.8000</gml:name>
     <om:resultDefinition>
      <swe:RecordDefinition gml:id="RecordDefinition11903967141253">
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#Waterlevel"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#Depth"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#Area"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#Runoff"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#Alpha"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#DeltaArea"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#DeltaRunoff"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#DeltaAlpha"/>
      </swe:RecordDefinition>
     </om:resultDefinition>
     <om:result><![CDATA[2.984 0.8740000 3.895000 2.500000 1.000000 -0.01343724 0.07277690 0E-7
3.226 1.116000 6.321000 5.000000 1.000000 0.02381321 -0.1573371 0E-7
3.402 1.292000 8.318000 7.500000 1.000000 0.02122478 -0.02814634 0E-7
3.541 1.431000 10.01000 10.00000 1.000000 -0.01041953 -0.001286337 0E-7
3.668 1.558000 11.58200 12.50000 1.000000 -0.01579721 0.08836404 0E-7
3.781 1.671000 13.01100 15.00000 1.000000 -0.01902018 0.08017817 0E-7
3.888 1.778000 14.38200 17.50000 1.000000 -0.01644589 0.07794803 0E-7
3.989 1.879000 15.68700 20.00000 1.000000 -0.005677847 0.04293284 0E-7
4.087 1.977000 16.96700 22.50000 1.000000 0.008669851 0.02349837 0E-7
4.179 2.069000 18.19900 25.00000 1.000000 0.008567358 -0.07460002 0E-7
4.272 2.162000 19.45900 27.50000 1.000000 0.01234065 -0.07804893 0E-7
4.359 2.249000 20.66000 30.00000 1.000000 0.01298411 -0.1810638 0E-7
4.451 2.341000 21.94800 32.50000 1.000000 0.01970276 -0.08031188 0E-7
4.541 2.431000 23.24700 35.00000 1.000000 0.01559265 0.03308588 0E-7
4.626 2.516000 24.52300 37.50000 1.000000 -0.006971860 0.06925460 0E-7
4.708 2.598000 25.77800 40.00000 1.000000 -0.01980916 0.08472949 0E-7
4.787 2.677000 27.01300 42.50000 1.000000 -0.02253448 0.07911329 0E-7
4.863 2.753000 28.23100 45.00000 1.000000 -0.01722148 0.05198771 0E-7
4.936 2.826000 29.43100 47.50000 1.000000 -0.002485917 0.002591649 0E-7
5.005 2.895000 30.59000 50.00000 1.000000 0.02692543 -0.1056666 0E-7
]]></om:result>
    </tuhh:WPointsObservation>
   </wb1d2d:pointsMember>
   <wb1d2d:polynomialMember>
    <math:Polynomial1D gml:id="Polynomial1D119039671412532">
     <gml:description>Q1(h)</gml:description>
     <gml:name>Q1(h)</gml:name>
     <math:coefficients>16.6661231926 -45.063086791 42.4966211021 -11.9539830351 1.38893371013</math:coefficients>
     <math:minRange>0.874</math:minRange>
     <math:maxRange>2.895</math:maxRange>
     <math:domainPhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonRunoff"/>
     <math:rangePhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonWaterlevel"/>
    </math:Polynomial1D>
   </wb1d2d:polynomialMember>
   <wb1d2d:polynomialMember>
    <math:Polynomial1D gml:id="Polynomial1D119039671412515">
     <gml:description>A1(h)</gml:description>
     <gml:name>A1(h)</gml:name>
     <math:coefficients>0.508153098215 -3.97554303129 12.0890020507 -4.0563049365 0.551213980886</math:coefficients>
     <math:minRange>0.874</math:minRange>
     <math:maxRange>2.895</math:maxRange>
     <math:domainPhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonArea"/>
     <math:rangePhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonWaterlevel"/>
    </math:Polynomial1D>
   </wb1d2d:polynomialMember>
   <wb1d2d:polynomialMember>
    <math:Polynomial1D gml:id="Polynomial1D119039671412539">
     <gml:description>al1(h)</gml:description>
     <gml:name>al1(h)</gml:name>
     <math:coefficients>1.0</math:coefficients>
     <math:minRange>0.874</math:minRange>
     <math:maxRange>2.895</math:maxRange>
     <math:domainPhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonAlpha"/>
     <math:rangePhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonWaterlevel"/>
    </math:Polynomial1D>
   </wb1d2d:polynomialMember>
   <wb1d2d:polynomialMember>
    <math:Polynomial1D gml:id="Polynomial1D119039671412560">
     <gml:description>Spl_al</gml:description>
     <gml:name>Spl_al</gml:name>
     <math:coefficients>0.0</math:coefficients>
     <math:minRange>2.895</math:minRange>
     <math:maxRange>2.895</math:maxRange>
     <math:domainPhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonAlpha"/>
     <math:rangePhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonWaterlevel"/>
    </math:Polynomial1D>
   </wb1d2d:polynomialMember>
   <wb1d2d:polynomialMember>
    <math:Polynomial1D gml:id="Polynomial1D119039671412556">
     <gml:description>al2(h)</gml:description>
     <gml:name>al2(h)</gml:name>
     <math:coefficients>0.0</math:coefficients>
     <math:minRange>2.895</math:minRange>
     <math:maxRange>2.895</math:maxRange>
     <math:domainPhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonAlpha"/>
     <math:rangePhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonWaterlevel"/>
    </math:Polynomial1D>
   </wb1d2d:polynomialMember>
   <wb1d2d:station>58.8000</wb1d2d:station>
   <wb1d2d:profileMember xlink:href="terrain.gml#Profile1190396712921120"/>
   <wb1d2d:slope>0.00100</wb1d2d:slope>
  </wb1d2d:TeschkeFlowRelation>
 </simBase:flowRelationshipMember>
 <simBase:flowRelationshipMember>
  <wb1d2d:TeschkeFlowRelation gml:id="TeschkeFlowRelation119039671412530">
   <gml:description>Gelesen aus: PROF0058.8500.txt</gml:description>
   <gml:name>58.8500</gml:name>
   <simBase:position>
    <gml:Point xmlns:ns1="http://www.w3.org/2001/SMIL20/" xmlns:st="http://www.seegrid.csiro.au/xml/st" xmlns:ns2="http://www.isotc211.org/2005/gmd" xmlns:ns3="http://www.isotc211.org/2005/gco" xmlns:ns4="http://www.isotc211.org/2005/gts" xmlns:ns5="http://www.isotc211.org/2005/gss" xmlns:ns6="http://www.isotc211.org/2005/gsr" xmlns:ns7="http://www.w3.org/2001/SMIL20/Language" srsName="EPSG:31467">
     <gml:coordinates ts="," decimal="." cs=" ">3552876.7785556116 5987232.864695706 2.75</gml:coordinates>
    </gml:Point>
   </simBase:position>
   <wb1d2d:pointsMember>
    <tuhh:WPointsObservation gml:id="WPointsObservation11903967141250">
     <gml:description>�bernommen aus Datei: PROF0058.8500.txt</gml:description>
     <gml:name>0058.8500</gml:name>
     <om:resultDefinition>
      <swe:RecordDefinition gml:id="RecordDefinition119039671412515">
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#Waterlevel"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#Depth"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#Area"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#Runoff"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#Alpha"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#DeltaArea"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#DeltaRunoff"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#DeltaAlpha"/>
      </swe:RecordDefinition>
     </om:resultDefinition>
     <om:result><![CDATA[3.409 0.6590000 3.978000 2.500000 1.000000 0.005034097 -0.0001984495 0E-7
3.634 0.8840000 6.275000 5.000000 1.000000 0.003812398 -0.008796101 0E-7
3.803 1.053000 8.080000 7.500000 1.000000 -0.01282857 0.007880553 0E-7
3.951 1.201000 9.696000 10.00000 1.000000 -0.01783409 0.01932364 0E-7
4.087 1.337000 11.20800 12.50000 1.000000 -0.009246221 0.009876543 0E-7
4.216 1.466000 12.67600 15.00000 1.000000 0.005699316 -0.001430273 0E-7
4.336 1.586000 14.07900 17.50000 1.000000 0.02356550 -0.08882573 0E-7
4.460 1.710000 15.58300 20.00000 1.000000 0.03712317 0.005293388 0E-7
4.577 1.827000 17.08100 22.50000 1.000000 0.02512750 0.06227404 0E-7
4.685 1.935000 18.53600 25.00000 1.000000 -0.003603895 0.03969229 0E-7
4.787 2.037000 19.95400 27.50000 1.000000 -0.01899856 0.009889764 0E-7
4.882 2.132000 21.34100 30.00000 1.000000 -0.04431003 -0.04707832 0E-7
4.973 2.223000 22.69900 32.50000 1.000000 -0.04155231 -0.04886849 0E-7
5.059 2.309000 24.03000 35.00000 1.000000 -0.02999185 -0.01687766 0E-7
5.140 2.390000 25.32000 37.50000 1.000000 0.00006645584 0.04748370 0E-7
5.214 2.464000 26.55200 40.00000 1.000500 0.02560188 0.06674056 -0.0005000000
5.281 2.531000 27.69900 42.50000 1.001760 0.06320789 0.01313511 -2.155698E-10
5.343 2.593000 28.84700 45.00000 1.004760 0.05326972 -0.06622949 6.610881E-10
5.403 2.653000 30.04000 47.50000 1.008980 0.002500596 -0.06495371 -6.722523E-10
5.462 2.712000 31.27400 50.00000 1.014010 -0.06664298 0.06166864 2.267233E-10
]]></om:result>
    </tuhh:WPointsObservation>
   </wb1d2d:pointsMember>
   <wb1d2d:polynomialMember>
    <math:Polynomial1D gml:id="Polynomial1D119039671412559">
     <gml:description>Q1(h)</gml:description>
     <gml:name>Q1(h)</gml:name>
     <math:coefficients>6.31944065265 -25.1644544318 38.5921234806 -15.6794484306 2.60461430295</math:coefficients>
     <math:minRange>0.659</math:minRange>
     <math:maxRange>2.712</math:maxRange>
     <math:domainPhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonRunoff"/>
     <math:rangePhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonWaterlevel"/>
    </math:Polynomial1D>
   </wb1d2d:polynomialMember>
   <wb1d2d:polynomialMember>
    <math:Polynomial1D gml:id="Polynomial1D119039671412540">
     <gml:description>A1(h)</gml:description>
     <gml:name>A1(h)</gml:name>
     <math:coefficients>-1.96271624654 7.75665479817 2.52520634173 -1.10818276777 0.289596142853</math:coefficients>
     <math:minRange>0.659</math:minRange>
     <math:maxRange>2.712</math:maxRange>
     <math:domainPhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonArea"/>
     <math:rangePhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonWaterlevel"/>
    </math:Polynomial1D>
   </wb1d2d:polynomialMember>
   <wb1d2d:polynomialMember>
    <math:Polynomial1D gml:id="Polynomial1D119039671412550">
     <gml:description>al1(h)</gml:description>
     <gml:name>al1(h)</gml:name>
     <math:coefficients>1.0</math:coefficients>
     <math:minRange>0.659</math:minRange>
     <math:maxRange>2.464</math:maxRange>
     <math:domainPhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonAlpha"/>
     <math:rangePhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonWaterlevel"/>
    </math:Polynomial1D>
   </wb1d2d:polynomialMember>
   <wb1d2d:polynomialMember>
    <math:Polynomial1D gml:id="Polynomial1D11903967141254">
     <gml:description>Spl_al</gml:description>
     <gml:name>Spl_al</gml:name>
     <math:coefficients>63.5617266712 -74.558321609 29.6045900044 -3.91641246135</math:coefficients>
     <math:minRange>2.464</math:minRange>
     <math:maxRange>2.531</math:maxRange>
     <math:domainPhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonAlpha"/>
     <math:rangePhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonWaterlevel"/>
    </math:Polynomial1D>
   </wb1d2d:polynomialMember>
   <wb1d2d:polynomialMember>
    <math:Polynomial1D gml:id="Polynomial1D119039671412511">
     <gml:description>al2(h)</gml:description>
     <gml:name>al2(h)</gml:name>
     <math:coefficients>7.30258574929 -6.94277439148 2.52161568577 -0.301109527955</math:coefficients>
     <math:minRange>2.531</math:minRange>
     <math:maxRange>2.712</math:maxRange>
     <math:domainPhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonAlpha"/>
     <math:rangePhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonWaterlevel"/>
    </math:Polynomial1D>
   </wb1d2d:polynomialMember>
   <wb1d2d:station>58.8500</wb1d2d:station>
   <wb1d2d:profileMember xlink:href="terrain.gml#Profile1190396712921252"/>
   <wb1d2d:slope>0.00100</wb1d2d:slope>
  </wb1d2d:TeschkeFlowRelation>
 </simBase:flowRelationshipMember>
 <simBase:flowRelationshipMember>
  <wb1d2d:TeschkeFlowRelation gml:id="TeschkeFlowRelation119039671412550">
   <gml:description>Gelesen aus: PROF0058.9000.txt</gml:description>
   <gml:name>58.9000</gml:name>
   <simBase:position>
    <gml:Point xmlns:ns1="http://www.w3.org/2001/SMIL20/" xmlns:st="http://www.seegrid.csiro.au/xml/st" xmlns:ns2="http://www.isotc211.org/2005/gmd" xmlns:ns3="http://www.isotc211.org/2005/gco" xmlns:ns4="http://www.isotc211.org/2005/gts" xmlns:ns5="http://www.isotc211.org/2005/gss" xmlns:ns6="http://www.isotc211.org/2005/gsr" xmlns:ns7="http://www.w3.org/2001/SMIL20/Language" srsName="EPSG:31467">
     <gml:coordinates ts="," decimal="." cs=" ">3552880.6368556083 5987277.405495655 2.72</gml:coordinates>
    </gml:Point>
   </simBase:position>
   <wb1d2d:pointsMember>
    <tuhh:WPointsObservation gml:id="WPointsObservation119039671412516">
     <gml:description>�bernommen aus Datei: PROF0058.9000.txt</gml:description>
     <gml:name>0058.9000</gml:name>
     <om:resultDefinition>
      <swe:RecordDefinition gml:id="RecordDefinition119039671412514">
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#Waterlevel"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#Depth"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#Area"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#Runoff"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#Alpha"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#DeltaArea"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#DeltaRunoff"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#DeltaAlpha"/>
      </swe:RecordDefinition>
     </om:resultDefinition>
     <om:result><![CDATA[3.292 0.5720000 4.127000 2.500000 1.000000 0.003888867 0.02411525 0E-7
3.503 0.7830000 6.432000 5.000000 1.000000 -0.006607205 -0.01931903 0E-7
3.666 0.9460000 8.305000 7.500000 1.000000 -0.002954190 -0.03294293 0E-7
3.805 1.085000 9.965000 10.00000 1.000000 -0.003375395 -0.05680935 0E-7
3.935 1.215000 11.54900 12.50000 1.000000 0.008083471 0.02522525 0E-7
4.052 1.332000 13.01900 15.00000 1.000000 0.007079079 0.04959102 0E-7
4.161 1.441000 14.42000 17.50000 1.000000 0.001900569 0.05899262 0E-7
4.264 1.544000 15.76600 20.00000 1.000000 -0.0007783805 0.06063418 0E-7
4.359 1.639000 17.02400 22.50000 1.000000 0.001983683 -0.02611362 0E-7
4.455 1.735000 18.32700 25.00000 1.000000 -0.004386191 0.01082464 0E-7
4.544 1.824000 19.55400 27.50000 1.000000 -0.007345814 -0.05239148 0E-7
4.632 1.912000 20.78700 30.00000 1.000000 -0.007314100 -0.06516951 0E-7
4.720 2.000000 22.03400 32.50000 1.000000 0.003653731 -0.002230886 0E-7
4.802 2.082000 23.23100 35.00000 1.000000 0.003677179 -0.04676655 0E-7
4.884 2.164000 24.46100 37.50000 1.000000 -0.002782042 -0.02669764 0E-7
4.963 2.243000 25.66300 40.00000 1.000000 0.001702806 -0.03751668 0E-7
5.044 2.324000 26.93000 42.50000 1.000000 0.002915491 0.07783419 0E-7
5.121 2.401000 28.16700 45.00000 1.000000 0.003744417 0.1243682 0E-7
5.194 2.474000 29.37100 47.50000 1.000000 0.005117282 0.09420728 0E-7
5.259 2.539000 30.48600 50.00000 1.001030 -0.008203256 -0.1598350 -1.001030
]]></om:result>
    </tuhh:WPointsObservation>
   </wb1d2d:pointsMember>
   <wb1d2d:polynomialMember>
    <math:Polynomial1D gml:id="Polynomial1D119039671412542">
     <gml:description>Q1(h)</gml:description>
     <gml:name>Q1(h)</gml:name>
     <math:coefficients>1.37609456845 -6.48281547991 16.9029916155 -3.86757870473 0.463498042571</math:coefficients>
     <math:minRange>0.572</math:minRange>
     <math:maxRange>2.539</math:maxRange>
     <math:domainPhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonRunoff"/>
     <math:rangePhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonWaterlevel"/>
    </math:Polynomial1D>
   </wb1d2d:polynomialMember>
   <wb1d2d:polynomialMember>
    <math:Polynomial1D gml:id="Polynomial1D119039671412512">
     <gml:description>A1(h)</gml:description>
     <gml:name>A1(h)</gml:name>
     <math:coefficients>-0.950585307683 6.91573634808 4.22192012477 -1.52627168631 0.279953708349</math:coefficients>
     <math:minRange>0.572</math:minRange>
     <math:maxRange>2.539</math:maxRange>
     <math:domainPhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonArea"/>
     <math:rangePhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonWaterlevel"/>
    </math:Polynomial1D>
   </wb1d2d:polynomialMember>
   <wb1d2d:polynomialMember>
    <math:Polynomial1D gml:id="Polynomial1D119039671412544">
     <gml:description>al1(h)</gml:description>
     <gml:name>al1(h)</gml:name>
     <math:coefficients>1.0</math:coefficients>
     <math:minRange>0.572</math:minRange>
     <math:maxRange>2.474</math:maxRange>
     <math:domainPhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonAlpha"/>
     <math:rangePhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonWaterlevel"/>
    </math:Polynomial1D>
   </wb1d2d:polynomialMember>
   <wb1d2d:polynomialMember>
    <math:Polynomial1D gml:id="Polynomial1D119039671412549">
     <gml:description>Spl_al</gml:description>
     <gml:name>Spl_al</gml:name>
     <math:coefficients>0.0</math:coefficients>
     <math:minRange>2.474</math:minRange>
     <math:maxRange>2.474</math:maxRange>
     <math:domainPhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonAlpha"/>
     <math:rangePhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonWaterlevel"/>
    </math:Polynomial1D>
   </wb1d2d:polynomialMember>
   <wb1d2d:polynomialMember>
    <math:Polynomial1D gml:id="Polynomial1D119039671412541">
     <gml:description>al2(h)</gml:description>
     <gml:name>al2(h)</gml:name>
     <math:coefficients>0.0</math:coefficients>
     <math:minRange>2.474</math:minRange>
     <math:maxRange>2.474</math:maxRange>
     <math:domainPhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonAlpha"/>
     <math:rangePhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonWaterlevel"/>
    </math:Polynomial1D>
   </wb1d2d:polynomialMember>
   <wb1d2d:station>58.9000</wb1d2d:station>
   <wb1d2d:profileMember xlink:href="terrain.gml#Profile1190396712937204"/>
   <wb1d2d:slope>0.00100</wb1d2d:slope>
  </wb1d2d:TeschkeFlowRelation>
 </simBase:flowRelationshipMember>
 <simBase:flowRelationshipMember>
  <wb1d2d:TeschkeFlowRelation gml:id="TeschkeFlowRelation119039671412521">
   <gml:description>Gelesen aus: PROF0058.9500.txt</gml:description>
   <gml:name>58.9500</gml:name>
   <simBase:position>
    <gml:Point xmlns:ns1="http://www.w3.org/2001/SMIL20/" xmlns:st="http://www.seegrid.csiro.au/xml/st" xmlns:ns2="http://www.isotc211.org/2005/gmd" xmlns:ns3="http://www.isotc211.org/2005/gco" xmlns:ns4="http://www.isotc211.org/2005/gts" xmlns:ns5="http://www.isotc211.org/2005/gss" xmlns:ns6="http://www.isotc211.org/2005/gsr" xmlns:ns7="http://www.w3.org/2001/SMIL20/Language" srsName="EPSG:31467">
     <gml:coordinates ts="," decimal="." cs=" ">3552869.178555618 5987324.5826956015 2.55</gml:coordinates>
    </gml:Point>
   </simBase:position>
   <wb1d2d:pointsMember>
    <tuhh:WPointsObservation gml:id="WPointsObservation119039671412581">
     <gml:description>�bernommen aus Datei: PROF0058.9500.txt</gml:description>
     <gml:name>0058.9500</gml:name>
     <om:resultDefinition>
      <swe:RecordDefinition gml:id="RecordDefinition119039671412521">
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#Waterlevel"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#Depth"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#Area"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#Runoff"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#Alpha"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#DeltaArea"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#DeltaRunoff"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#DeltaAlpha"/>
      </swe:RecordDefinition>
     </om:resultDefinition>
     <om:result><![CDATA[3.210 0.6600000 3.905000 2.500000 1.000000 -0.005478683 0.01033569 0E-7
3.440 0.8900000 6.121000 5.000000 1.000000 0.005784774 -0.03446745 0E-7
3.621 1.071000 7.989000 7.500000 1.000000 0.01068122 0.005227819 0E-7
3.775 1.225000 9.674000 10.00000 1.000000 0.002791786 0.02570014 0E-7
3.912 1.362000 11.23900 12.50000 1.000000 -0.004101215 0.01567420 0E-7
4.039 1.489000 12.75100 15.00000 1.000000 -0.01410957 0.01591758 0E-7
4.158 1.608000 14.20600 17.50000 1.000000 -0.009212827 0.01766844 0E-7
4.269 1.719000 15.61100 20.00000 1.000000 -0.004398939 -0.01383608 0E-7
4.373 1.823000 16.97200 22.50000 1.000000 -0.0001951638 -0.08337821 0E-7
4.472 1.922000 18.31200 25.00000 1.000000 0.001328570 -0.1624993 0E-7
4.583 2.033000 19.86000 27.50000 1.000000 0.008924466 0.1803051 0E-7
4.672 2.122000 21.13800 30.00000 1.000000 0.01975828 0.06231164 0E-7
4.761 2.211000 22.46900 32.50000 1.000000 0.01669739 0.04086312 0E-7
4.846 2.296000 23.79700 35.00000 1.000000 -0.004586149 0.003631004 0E-7
4.928 2.378000 25.10100 37.50000 1.000000 -0.01049676 -0.02617290 0E-7
5.007 2.457000 26.38400 40.00000 1.000000 -0.006288384 -0.05275379 0E-7
5.083 2.533000 27.66200 42.50000 1.000000 -0.01036756 -0.08059590 0E-7
5.160 2.610000 28.98900 45.00000 1.000000 -0.009349092 0.02324689 0E-7
5.233 2.683000 30.28000 47.50000 1.000000 -0.004965188 0.09040939 0E-7
5.298 2.748000 31.44200 50.00000 1.000000 0.01758305 -0.03758733 0E-7
]]></om:result>
    </tuhh:WPointsObservation>
   </wb1d2d:pointsMember>
   <wb1d2d:polynomialMember>
    <math:Polynomial1D gml:id="Polynomial1D119039671414023">
     <gml:description>Q1(h)</gml:description>
     <gml:name>Q1(h)</gml:name>
     <math:coefficients>2.15856597924 -9.21893592036 17.7124534298 -4.93289385479 0.732078449245</math:coefficients>
     <math:minRange>0.66</math:minRange>
     <math:maxRange>2.748</math:maxRange>
     <math:domainPhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonRunoff"/>
     <math:rangePhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonWaterlevel"/>
    </math:Polynomial1D>
   </wb1d2d:polynomialMember>
   <wb1d2d:polynomialMember>
    <math:Polynomial1D gml:id="Polynomial1D11903967141404">
     <gml:description>A1(h)</gml:description>
     <gml:name>A1(h)</gml:name>
     <math:coefficients>-1.47048639831 6.85676841496 2.14725264818 -0.383270512972 0.102167678136</math:coefficients>
     <math:minRange>0.66</math:minRange>
     <math:maxRange>2.748</math:maxRange>
     <math:domainPhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonArea"/>
     <math:rangePhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonWaterlevel"/>
    </math:Polynomial1D>
   </wb1d2d:polynomialMember>
   <wb1d2d:polynomialMember>
    <math:Polynomial1D gml:id="Polynomial1D119039671414043">
     <gml:description>al1(h)</gml:description>
     <gml:name>al1(h)</gml:name>
     <math:coefficients>1.0</math:coefficients>
     <math:minRange>0.66</math:minRange>
     <math:maxRange>2.748</math:maxRange>
     <math:domainPhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonAlpha"/>
     <math:rangePhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonWaterlevel"/>
    </math:Polynomial1D>
   </wb1d2d:polynomialMember>
   <wb1d2d:polynomialMember>
    <math:Polynomial1D gml:id="Polynomial1D119039671414049">
     <gml:description>Spl_al</gml:description>
     <gml:name>Spl_al</gml:name>
     <math:coefficients>0.0</math:coefficients>
     <math:minRange>2.748</math:minRange>
     <math:maxRange>2.748</math:maxRange>
     <math:domainPhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonAlpha"/>
     <math:rangePhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonWaterlevel"/>
    </math:Polynomial1D>
   </wb1d2d:polynomialMember>
   <wb1d2d:polynomialMember>
    <math:Polynomial1D gml:id="Polynomial1D119039671414010">
     <gml:description>al2(h)</gml:description>
     <gml:name>al2(h)</gml:name>
     <math:coefficients>0.0</math:coefficients>
     <math:minRange>2.748</math:minRange>
     <math:maxRange>2.748</math:maxRange>
     <math:domainPhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonAlpha"/>
     <math:rangePhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonWaterlevel"/>
    </math:Polynomial1D>
   </wb1d2d:polynomialMember>
   <wb1d2d:station>58.9500</wb1d2d:station>
   <wb1d2d:profileMember xlink:href="terrain.gml#Profile1190396712953121"/>
   <wb1d2d:slope>0.00100</wb1d2d:slope>
  </wb1d2d:TeschkeFlowRelation>
 </simBase:flowRelationshipMember>
 <simBase:flowRelationshipMember>
  <wb1d2d:TeschkeFlowRelation gml:id="TeschkeFlowRelation11903967141400">
   <gml:description>Gelesen aus: PROF0059.0000.txt</gml:description>
   <gml:name>59.0000</gml:name>
   <simBase:position>
    <gml:Point xmlns:ns1="http://www.w3.org/2001/SMIL20/" xmlns:st="http://www.seegrid.csiro.au/xml/st" xmlns:ns2="http://www.isotc211.org/2005/gmd" xmlns:ns3="http://www.isotc211.org/2005/gco" xmlns:ns4="http://www.isotc211.org/2005/gts" xmlns:ns5="http://www.isotc211.org/2005/gss" xmlns:ns6="http://www.isotc211.org/2005/gsr" xmlns:ns7="http://www.w3.org/2001/SMIL20/Language" srsName="EPSG:31467">
     <gml:coordinates ts="," decimal="." cs=" ">3552853.1586556314 5987371.402095542 2.85</gml:coordinates>
    </gml:Point>
   </simBase:position>
   <wb1d2d:pointsMember>
    <tuhh:WPointsObservation gml:id="WPointsObservation119039671414068">
     <gml:description>�bernommen aus Datei: PROF0059.0000.txt</gml:description>
     <gml:name>0059.0000</gml:name>
     <om:resultDefinition>
      <swe:RecordDefinition gml:id="RecordDefinition11903967141405">
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#Waterlevel"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#Depth"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#Area"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#Runoff"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#Alpha"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#DeltaArea"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#DeltaRunoff"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#DeltaAlpha"/>
      </swe:RecordDefinition>
     </om:resultDefinition>
     <om:result><![CDATA[3.398 0.5480000 4.384000 2.500000 1.000000 -0.02487910 -0.02187167 0E-7
3.589 0.7390000 6.721000 5.000000 1.000000 0.04048130 -0.002834999 0E-7
3.738 0.8880000 8.591000 7.500000 1.000000 0.02667655 0.03614250 0E-7
3.868 1.018000 10.25000 10.00000 1.000000 -0.005929923 0.05351589 0E-7
3.987 1.137000 11.77400 12.50000 1.000000 -0.02310397 0.04784450 0E-7
4.097 1.247000 13.19900 15.00000 1.000000 -0.03117657 -0.01649070 0E-7
4.203 1.353000 14.59000 17.50000 1.000000 -0.02813212 -0.06857216 0E-7
4.308 1.458000 15.98800 20.00000 1.000000 -0.01179505 -0.05399806 0E-7
4.401 1.551000 17.24800 22.50000 1.000000 0.01280419 -0.2522478 0E-7
4.512 1.662000 18.80400 25.00000 1.000000 0.03388565 0.09429306 0E-7
4.604 1.754000 20.15700 27.50000 1.000000 0.02744533 0.04733453 0E-7
4.697 1.847000 21.56100 30.00000 1.000000 0.02362423 0.1295462 0E-7
4.785 1.935000 22.93700 32.50000 1.000000 0.01059219 0.1860145 0E-7
4.864 2.014000 24.21000 35.00000 1.000000 -0.005954263 0.09222306 0E-7
4.938 2.088000 25.43300 37.50000 1.000000 -0.02289241 -0.04208518 0E-7
5.010 2.160000 26.63600 40.00000 1.000000 -0.02471789 -0.1204309 0E-7
5.080 2.230000 27.82000 42.50000 1.000000 -0.01421778 -0.1363642 0E-7
5.147 2.297000 28.98700 45.00000 1.000000 -0.01291939 -0.1230052 0E-7
5.213 2.363000 30.13800 47.50000 1.000000 0.01107397 -0.001183743 0E-7
5.276 2.426000 31.27400 50.00000 1.000000 0.01913507 0.1521703 0E-7
]]></om:result>
    </tuhh:WPointsObservation>
   </wb1d2d:pointsMember>
   <wb1d2d:polynomialMember>
    <math:Polynomial1D gml:id="Polynomial1D11903967141401">
     <gml:description>Q1(h)</gml:description>
     <gml:name>Q1(h)</gml:name>
     <math:coefficients>3.09644554081 -16.3623171793 35.1150602822 -14.7947580656 2.63645917401</math:coefficients>
     <math:minRange>0.548</math:minRange>
     <math:maxRange>2.426</math:maxRange>
     <math:domainPhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonRunoff"/>
     <math:rangePhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonWaterlevel"/>
    </math:Polynomial1D>
   </wb1d2d:polynomialMember>
   <wb1d2d:polynomialMember>
    <math:Polynomial1D gml:id="Polynomial1D11903967141405">
     <gml:description>A1(h)</gml:description>
     <gml:name>A1(h)</gml:name>
     <math:coefficients>-3.15643012782 15.1607496299 -3.52643158356 1.71511320311 -0.175073877123</math:coefficients>
     <math:minRange>0.548</math:minRange>
     <math:maxRange>2.426</math:maxRange>
     <math:domainPhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonArea"/>
     <math:rangePhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonWaterlevel"/>
    </math:Polynomial1D>
   </wb1d2d:polynomialMember>
   <wb1d2d:polynomialMember>
    <math:Polynomial1D gml:id="Polynomial1D119039671414069">
     <gml:description>al1(h)</gml:description>
     <gml:name>al1(h)</gml:name>
     <math:coefficients>1.0</math:coefficients>
     <math:minRange>0.548</math:minRange>
     <math:maxRange>2.426</math:maxRange>
     <math:domainPhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonAlpha"/>
     <math:rangePhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonWaterlevel"/>
    </math:Polynomial1D>
   </wb1d2d:polynomialMember>
   <wb1d2d:polynomialMember>
    <math:Polynomial1D gml:id="Polynomial1D119039671414024">
     <gml:description>Spl_al</gml:description>
     <gml:name>Spl_al</gml:name>
     <math:coefficients>0.0</math:coefficients>
     <math:minRange>2.426</math:minRange>
     <math:maxRange>2.426</math:maxRange>
     <math:domainPhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonAlpha"/>
     <math:rangePhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonWaterlevel"/>
    </math:Polynomial1D>
   </wb1d2d:polynomialMember>
   <wb1d2d:polynomialMember>
    <math:Polynomial1D gml:id="Polynomial1D119039671414015">
     <gml:description>al2(h)</gml:description>
     <gml:name>al2(h)</gml:name>
     <math:coefficients>0.0</math:coefficients>
     <math:minRange>2.426</math:minRange>
     <math:maxRange>2.426</math:maxRange>
     <math:domainPhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonAlpha"/>
     <math:rangePhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonWaterlevel"/>
    </math:Polynomial1D>
   </wb1d2d:polynomialMember>
   <wb1d2d:station>59.0000</wb1d2d:station>
   <wb1d2d:profileMember xlink:href="terrain.gml#Profile119039671295392"/>
   <wb1d2d:slope>0.00100</wb1d2d:slope>
  </wb1d2d:TeschkeFlowRelation>
 </simBase:flowRelationshipMember>
 <simBase:flowRelationshipMember>
  <wb1d2d:TeschkeFlowRelation gml:id="TeschkeFlowRelation119039671414026">
   <gml:description>Gelesen aus: PROF0059.0500.txt</gml:description>
   <gml:name>59.0500</gml:name>
   <simBase:position>
    <gml:Point xmlns:ns1="http://www.w3.org/2001/SMIL20/" xmlns:st="http://www.seegrid.csiro.au/xml/st" xmlns:ns2="http://www.isotc211.org/2005/gmd" xmlns:ns3="http://www.isotc211.org/2005/gco" xmlns:ns4="http://www.isotc211.org/2005/gts" xmlns:ns5="http://www.isotc211.org/2005/gss" xmlns:ns6="http://www.isotc211.org/2005/gsr" xmlns:ns7="http://www.w3.org/2001/SMIL20/Language" srsName="EPSG:31467">
     <gml:coordinates ts="," decimal="." cs=" ">3552846.8787556365 5987422.554695483 2.68</gml:coordinates>
    </gml:Point>
   </simBase:position>
   <wb1d2d:pointsMember>
    <tuhh:WPointsObservation gml:id="WPointsObservation119039671414087">
     <gml:description>�bernommen aus Datei: PROF0059.0500.txt</gml:description>
     <gml:name>0059.0500</gml:name>
     <om:resultDefinition>
      <swe:RecordDefinition gml:id="RecordDefinition119039671414036">
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#Waterlevel"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#Depth"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#Area"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#Runoff"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#Alpha"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#DeltaArea"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#DeltaRunoff"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#DeltaAlpha"/>
      </swe:RecordDefinition>
     </om:resultDefinition>
     <om:result><![CDATA[3.437 0.7570000 4.089000 2.500000 1.000000 -0.006771743 0.04084349 0E-7
3.667 0.9870000 6.486000 5.000000 1.000000 0.02551872 -0.02551730 0E-7
3.828 1.148000 8.334000 7.500000 1.000000 -0.01059937 -0.07868144 0E-7
3.968 1.288000 9.980000 10.00000 1.000000 -0.01773990 -0.07984059 0E-7
4.100 1.420000 11.56100 12.50000 1.000000 -0.004109386 0.02537651 0E-7
4.221 1.541000 13.05900 15.00000 1.000000 0.0004037536 0.08746421 0E-7
4.334 1.654000 14.49000 17.50000 1.000000 0.008254706 0.1093375 0E-7
4.440 1.760000 15.87400 20.00000 1.000000 0.006863985 0.07870207 0E-7
4.543 1.863000 17.24800 22.50000 1.000000 0.009202147 0.07202430 0E-7
4.640 1.960000 18.58300 25.00000 1.000000 0.002792902 0.007690240 0E-7
4.732 2.052000 19.88500 27.50000 1.000000 -0.006982531 -0.09704480 0E-7
4.821 2.141000 21.15800 30.00000 1.000000 0.003098032 -0.1917019 0E-7
4.911 2.231000 22.50200 32.50000 1.000000 -0.006738558 -0.1588420 0E-7
4.999 2.319000 23.84800 35.00000 1.000000 -0.008576203 -0.06975153 0E-7
5.083 2.403000 25.17000 37.50000 1.000000 -0.006901668 0.02151291 0E-7
5.163 2.483000 26.46900 40.00000 1.000000 -0.004490475 0.1145470 0E-7
5.240 2.560000 27.74800 42.50000 1.000000 0.01041796 0.2419819 0E-7
5.306 2.626000 28.89400 45.00000 1.000320 0.008630452 0.1099262 -0.0003200000
5.369 2.689000 30.01200 47.50000 1.001540 0.01556265 -0.01862664 0E-7
5.428 2.748000 31.13000 50.00000 1.003350 -0.01783548 -0.1894002 0E-7
]]></om:result>
    </tuhh:WPointsObservation>
   </wb1d2d:pointsMember>
   <wb1d2d:polynomialMember>
    <math:Polynomial1D gml:id="Polynomial1D119039671414078">
     <gml:description>Q1(h)</gml:description>
     <gml:name>Q1(h)</gml:name>
     <math:coefficients>10.4234419986 -34.401074664 41.183397832 -14.0674751689 2.01395816457</math:coefficients>
     <math:minRange>0.757</math:minRange>
     <math:maxRange>2.748</math:maxRange>
     <math:domainPhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonRunoff"/>
     <math:rangePhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonWaterlevel"/>
    </math:Polynomial1D>
   </wb1d2d:polynomialMember>
   <wb1d2d:polynomialMember>
    <math:Polynomial1D gml:id="Polynomial1D119039671414085">
     <gml:description>A1(h)</gml:description>
     <gml:name>A1(h)</gml:name>
     <math:coefficients>-1.80717848836 4.688882665 5.29182593218 -1.83838584815 0.319549414745</math:coefficients>
     <math:minRange>0.757</math:minRange>
     <math:maxRange>2.748</math:maxRange>
     <math:domainPhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonArea"/>
     <math:rangePhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonWaterlevel"/>
    </math:Polynomial1D>
   </wb1d2d:polynomialMember>
   <wb1d2d:polynomialMember>
    <math:Polynomial1D gml:id="Polynomial1D119039671414048">
     <gml:description>al1(h)</gml:description>
     <gml:name>al1(h)</gml:name>
     <math:coefficients>1.0</math:coefficients>
     <math:minRange>0.757</math:minRange>
     <math:maxRange>2.626</math:maxRange>
     <math:domainPhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonAlpha"/>
     <math:rangePhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonWaterlevel"/>
    </math:Polynomial1D>
   </wb1d2d:polynomialMember>
   <wb1d2d:polynomialMember>
    <math:Polynomial1D gml:id="Polynomial1D119039671414041">
     <gml:description>Spl_al</gml:description>
     <gml:name>Spl_al</gml:name>
     <math:coefficients>88.7563574327 -98.4768035858 36.8236174975 -4.58828994369</math:coefficients>
     <math:minRange>2.626</math:minRange>
     <math:maxRange>2.689</math:maxRange>
     <math:domainPhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonAlpha"/>
     <math:rangePhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonWaterlevel"/>
    </math:Polynomial1D>
   </wb1d2d:polynomialMember>
   <wb1d2d:polynomialMember>
    <math:Polynomial1D gml:id="Polynomial1D119039671414077">
     <gml:description>al2(h)</gml:description>
     <gml:name>al2(h)</gml:name>
     <math:coefficients>0.919046949153 0.0306779661017</math:coefficients>
     <math:minRange>2.689</math:minRange>
     <math:maxRange>2.748</math:maxRange>
     <math:domainPhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonAlpha"/>
     <math:rangePhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonWaterlevel"/>
    </math:Polynomial1D>
   </wb1d2d:polynomialMember>
   <wb1d2d:station>59.0500</wb1d2d:station>
   <wb1d2d:profileMember xlink:href="terrain.gml#Profile1190396712953224"/>
   <wb1d2d:slope>0.00100</wb1d2d:slope>
  </wb1d2d:TeschkeFlowRelation>
 </simBase:flowRelationshipMember>
 <simBase:flowRelationshipMember>
  <wb1d2d:TeschkeFlowRelation gml:id="TeschkeFlowRelation119039671414076">
   <gml:description>Gelesen aus: PROF0059.1000.txt</gml:description>
   <gml:name>59.1000</gml:name>
   <simBase:position>
    <gml:Point xmlns:ns1="http://www.w3.org/2001/SMIL20/" xmlns:st="http://www.seegrid.csiro.au/xml/st" xmlns:ns2="http://www.isotc211.org/2005/gmd" xmlns:ns3="http://www.isotc211.org/2005/gco" xmlns:ns4="http://www.isotc211.org/2005/gts" xmlns:ns5="http://www.isotc211.org/2005/gss" xmlns:ns6="http://www.isotc211.org/2005/gsr" xmlns:ns7="http://www.w3.org/2001/SMIL20/Language" srsName="EPSG:31467">
     <gml:coordinates ts="," decimal="." cs=" ">3552839.477155643 5987474.348595423 2.46</gml:coordinates>
    </gml:Point>
   </simBase:position>
   <wb1d2d:pointsMember>
    <tuhh:WPointsObservation gml:id="WPointsObservation1190396714140106">
     <gml:description>�bernommen aus Datei: PROF0059.1000.txt</gml:description>
     <gml:name>0059.1000</gml:name>
     <om:resultDefinition>
      <swe:RecordDefinition gml:id="RecordDefinition119039671414060">
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#Waterlevel"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#Depth"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#Area"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#Runoff"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#Alpha"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#DeltaArea"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#DeltaRunoff"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#DeltaAlpha"/>
      </swe:RecordDefinition>
     </om:resultDefinition>
     <om:result><![CDATA[3.215 0.7550000 3.597000 2.500000 1.000000 -0.005866099 0.08439855 0E-7
3.484 1.024000 5.738000 5.000000 1.000000 0.01049612 -0.1401790 0E-7
3.687 1.227000 7.509000 7.500000 1.000000 0.005428424 -0.09107532 0E-7
3.861 1.401000 9.120000 10.00000 1.000000 -0.003470632 0.01128162 0E-7
4.016 1.556000 10.61700 12.50000 1.000000 -0.003567057 0.07938409 0E-7
4.157 1.697000 12.04400 15.00000 1.000000 -0.008154232 0.08001669 0E-7
4.292 1.832000 13.45700 17.50000 1.000000 0.00005284653 0.09851310 0E-7
4.421 1.961000 14.87400 20.00000 1.000000 0.001420781 0.1073949 0E-7
4.540 2.080000 16.25100 22.50000 1.000000 -0.008574575 0.007446976 0E-7
4.658 2.198000 17.66100 25.00000 1.000000 -0.0006906080 -0.02883401 0E-7
4.772 2.312000 19.09600 27.50000 1.000000 0.0003065945 -0.06224495 0E-7
4.873 2.413000 20.42400 30.00000 1.000000 0.005211263 -0.2970399 0E-7
4.984 2.524000 21.95500 32.50000 1.000000 0.01228912 -0.2078850 0E-7
5.097 2.637000 23.59800 35.00000 1.000000 0.02262275 0.05296932 0E-7
5.198 2.738000 25.17800 37.50000 1.000000 0.003312248 0.1457906 0E-7
5.291 2.831000 26.71100 40.00000 1.000000 -0.01643146 0.1546348 0E-7
5.378 2.918000 28.20300 42.50000 1.000000 -0.02076463 0.1222531 0E-7
5.460 3.000000 29.66100 45.00000 1.000000 -0.007675849 0.06879038 0E-7
5.536 3.076000 31.08900 47.50000 1.000000 -0.008099648 -0.04669415 0E-7
5.609 3.149000 32.49200 50.00000 1.000000 0.02215463 -0.1389217 0E-7
]]></om:result>
    </tuhh:WPointsObservation>
   </wb1d2d:pointsMember>
   <wb1d2d:polynomialMember>
    <math:Polynomial1D gml:id="Polynomial1D119039671414094">
     <gml:description>Q1(h)</gml:description>
     <gml:name>Q1(h)</gml:name>
     <math:coefficients>7.71436080437 -22.9530068913 27.011224454 -8.22331551344 1.0511351732</math:coefficients>
     <math:minRange>0.755</math:minRange>
     <math:maxRange>3.149</math:maxRange>
     <math:domainPhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonRunoff"/>
     <math:rangePhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonWaterlevel"/>
    </math:Polynomial1D>
   </wb1d2d:polynomialMember>
   <wb1d2d:polynomialMember>
    <math:Polynomial1D gml:id="Polynomial1D1190396714140104">
     <gml:description>A1(h)</gml:description>
     <gml:name>A1(h)</gml:name>
     <math:coefficients>-0.924374483972 3.91976326968 3.4452006318 -1.11429785584 0.220958583297</math:coefficients>
     <math:minRange>0.755</math:minRange>
     <math:maxRange>3.149</math:maxRange>
     <math:domainPhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonArea"/>
     <math:rangePhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonWaterlevel"/>
    </math:Polynomial1D>
   </wb1d2d:polynomialMember>
   <wb1d2d:polynomialMember>
    <math:Polynomial1D gml:id="Polynomial1D119039671415625">
     <gml:description>al1(h)</gml:description>
     <gml:name>al1(h)</gml:name>
     <math:coefficients>1.0</math:coefficients>
     <math:minRange>0.755</math:minRange>
     <math:maxRange>3.149</math:maxRange>
     <math:domainPhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonAlpha"/>
     <math:rangePhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonWaterlevel"/>
    </math:Polynomial1D>
   </wb1d2d:polynomialMember>
   <wb1d2d:polynomialMember>
    <math:Polynomial1D gml:id="Polynomial1D119039671415631">
     <gml:description>Spl_al</gml:description>
     <gml:name>Spl_al</gml:name>
     <math:coefficients>0.0</math:coefficients>
     <math:minRange>3.149</math:minRange>
     <math:maxRange>3.149</math:maxRange>
     <math:domainPhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonAlpha"/>
     <math:rangePhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonWaterlevel"/>
    </math:Polynomial1D>
   </wb1d2d:polynomialMember>
   <wb1d2d:polynomialMember>
    <math:Polynomial1D gml:id="Polynomial1D119039671415687">
     <gml:description>al2(h)</gml:description>
     <gml:name>al2(h)</gml:name>
     <math:coefficients>0.0</math:coefficients>
     <math:minRange>3.149</math:minRange>
     <math:maxRange>3.149</math:maxRange>
     <math:domainPhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonAlpha"/>
     <math:rangePhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonWaterlevel"/>
    </math:Polynomial1D>
   </wb1d2d:polynomialMember>
   <wb1d2d:station>59.1000</wb1d2d:station>
   <wb1d2d:profileMember xlink:href="terrain.gml#Profile1190396712968133"/>
   <wb1d2d:slope>0.00100</wb1d2d:slope>
  </wb1d2d:TeschkeFlowRelation>
 </simBase:flowRelationshipMember>
 <simBase:flowRelationshipMember>
  <wb1d2d:TeschkeFlowRelation gml:id="TeschkeFlowRelation119039671415696">
   <gml:description>Gelesen aus: PROF0059.1500.txt</gml:description>
   <gml:name>59.1500</gml:name>
   <simBase:position>
    <gml:Point xmlns:ns1="http://www.w3.org/2001/SMIL20/" xmlns:st="http://www.seegrid.csiro.au/xml/st" xmlns:ns2="http://www.isotc211.org/2005/gmd" xmlns:ns3="http://www.isotc211.org/2005/gco" xmlns:ns4="http://www.isotc211.org/2005/gts" xmlns:ns5="http://www.isotc211.org/2005/gss" xmlns:ns6="http://www.isotc211.org/2005/gsr" xmlns:ns7="http://www.w3.org/2001/SMIL20/Language" srsName="EPSG:31467">
     <gml:coordinates ts="," decimal="." cs=" ">3552849.686655634 5987524.123195363 2.78</gml:coordinates>
    </gml:Point>
   </simBase:position>
   <wb1d2d:pointsMember>
    <tuhh:WPointsObservation gml:id="WPointsObservation119039671415655">
     <gml:description>�bernommen aus Datei: PROF0059.1500.txt</gml:description>
     <gml:name>0059.1500</gml:name>
     <om:resultDefinition>
      <swe:RecordDefinition gml:id="RecordDefinition119039671415697">
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#Waterlevel"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#Depth"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#Area"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#Runoff"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#Alpha"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#DeltaArea"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#DeltaRunoff"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#DeltaAlpha"/>
      </swe:RecordDefinition>
     </om:resultDefinition>
     <om:result><![CDATA[3.519 0.7390000 4.323000 2.500000 1.000000 -0.006710859 0.07091733 0E-7
3.731 0.9510000 6.546000 5.000000 1.000000 0.008448004 -0.09229422 0E-7
3.903 1.123000 8.390000 7.500000 1.000000 0.003735053 -0.08879238 0E-7
4.054 1.274000 10.03600 10.00000 1.000000 -0.001349315 -0.04868122 0E-7
4.195 1.415000 11.58900 12.50000 1.000000 0.009128908 0.04873569 0E-7
4.328 1.548000 13.10300 15.00000 1.000000 0.006806295 0.1573851 0E-7
4.450 1.670000 14.55000 17.50000 1.000000 -0.01330618 0.1606292 0E-7
4.565 1.785000 15.94300 20.00000 1.000000 -0.01785295 0.1022046 0E-7
4.673 1.893000 17.29000 22.50000 1.000000 -0.01498452 -0.04007400 0E-7
4.780 2.000000 18.67600 25.00000 1.000000 -0.01215423 -0.1454642 0E-7
4.884 2.104000 20.07000 27.50000 1.000000 0.0004350789 -0.2614662 0E-7
4.990 2.210000 21.54000 30.00000 1.000000 0.02986672 -0.2703912 0E-7
5.108 2.328000 23.29700 32.50000 1.000000 0.03110093 0.08441640 0E-7
5.214 2.434000 24.98100 35.00000 1.000000 0.01709786 0.2342890 0E-7
5.311 2.531000 26.60900 37.50000 1.000000 0.001479022 0.2426721 0E-7
5.400 2.620000 28.19000 40.00000 1.000000 -0.02201747 0.1263070 0E-7
5.484 2.704000 29.73300 42.50000 1.000000 -0.02019900 -0.04053013 0E-7
5.562 2.782000 31.24200 45.00000 1.000000 -0.02439343 -0.2910590 0E-7
5.653 2.873000 33.06200 47.50000 1.000000 0.003554568 -0.05143870 0E-7
5.737 2.957000 34.84500 50.00000 1.000000 0.02131551 0.1026348 0E-7
]]></om:result>
    </tuhh:WPointsObservation>
   </wb1d2d:pointsMember>
   <wb1d2d:polynomialMember>
    <math:Polynomial1D gml:id="Polynomial1D119039671415667">
     <gml:description>Q1(h)</gml:description>
     <gml:name>Q1(h)</gml:name>
     <math:coefficients>5.23944891661 -19.741830917 27.6222990824 -8.67129489342 1.12374447257</math:coefficients>
     <math:minRange>0.739</math:minRange>
     <math:maxRange>2.957</math:maxRange>
     <math:domainPhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonRunoff"/>
     <math:rangePhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonWaterlevel"/>
    </math:Polynomial1D>
   </wb1d2d:polynomialMember>
   <wb1d2d:polynomialMember>
    <math:Polynomial1D gml:id="Polynomial1D119039671415695">
     <gml:description>A1(h)</gml:description>
     <gml:name>A1(h)</gml:name>
     <math:coefficients>-3.3023697469 10.016116182 0.644656190241 -0.484536364784 0.201978081669</math:coefficients>
     <math:minRange>0.739</math:minRange>
     <math:maxRange>2.957</math:maxRange>
     <math:domainPhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonArea"/>
     <math:rangePhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonWaterlevel"/>
    </math:Polynomial1D>
   </wb1d2d:polynomialMember>
   <wb1d2d:polynomialMember>
    <math:Polynomial1D gml:id="Polynomial1D11903967141562">
     <gml:description>al1(h)</gml:description>
     <gml:name>al1(h)</gml:name>
     <math:coefficients>1.0</math:coefficients>
     <math:minRange>0.739</math:minRange>
     <math:maxRange>2.957</math:maxRange>
     <math:domainPhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonAlpha"/>
     <math:rangePhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonWaterlevel"/>
    </math:Polynomial1D>
   </wb1d2d:polynomialMember>
   <wb1d2d:polynomialMember>
    <math:Polynomial1D gml:id="Polynomial1D119039671415648">
     <gml:description>Spl_al</gml:description>
     <gml:name>Spl_al</gml:name>
     <math:coefficients>0.0</math:coefficients>
     <math:minRange>2.957</math:minRange>
     <math:maxRange>2.957</math:maxRange>
     <math:domainPhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonAlpha"/>
     <math:rangePhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonWaterlevel"/>
    </math:Polynomial1D>
   </wb1d2d:polynomialMember>
   <wb1d2d:polynomialMember>
    <math:Polynomial1D gml:id="Polynomial1D119039671415678">
     <gml:description>al2(h)</gml:description>
     <gml:name>al2(h)</gml:name>
     <math:coefficients>0.0</math:coefficients>
     <math:minRange>2.957</math:minRange>
     <math:maxRange>2.957</math:maxRange>
     <math:domainPhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonAlpha"/>
     <math:rangePhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonWaterlevel"/>
    </math:Polynomial1D>
   </wb1d2d:polynomialMember>
   <wb1d2d:station>59.1500</wb1d2d:station>
   <wb1d2d:profileMember xlink:href="terrain.gml#Profile1190396712984107"/>
   <wb1d2d:slope>0.00100</wb1d2d:slope>
  </wb1d2d:TeschkeFlowRelation>
 </simBase:flowRelationshipMember>
 <simBase:flowRelationshipMember>
  <wb1d2d:TeschkeFlowRelation gml:id="TeschkeFlowRelation119039671415683">
   <gml:description>Gelesen aus: PROF0059.2000.txt</gml:description>
   <gml:name>59.2000</gml:name>
   <simBase:position>
    <gml:Point xmlns:ns1="http://www.w3.org/2001/SMIL20/" xmlns:st="http://www.seegrid.csiro.au/xml/st" xmlns:ns2="http://www.isotc211.org/2005/gmd" xmlns:ns3="http://www.isotc211.org/2005/gco" xmlns:ns4="http://www.isotc211.org/2005/gts" xmlns:ns5="http://www.isotc211.org/2005/gss" xmlns:ns6="http://www.isotc211.org/2005/gsr" xmlns:ns7="http://www.w3.org/2001/SMIL20/Language" srsName="EPSG:31467">
     <gml:coordinates ts="," decimal="." cs=" ">3552889.8487556004 5987558.466895324 2.52</gml:coordinates>
    </gml:Point>
   </simBase:position>
   <wb1d2d:pointsMember>
    <tuhh:WPointsObservation gml:id="WPointsObservation1190396714156103">
     <gml:description>�bernommen aus Datei: PROF0059.2000.txt</gml:description>
     <gml:name>0059.2000</gml:name>
     <om:resultDefinition>
      <swe:RecordDefinition gml:id="RecordDefinition119039671415695">
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#Waterlevel"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#Depth"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#Area"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#Runoff"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#Alpha"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#DeltaArea"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#DeltaRunoff"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#DeltaAlpha"/>
      </swe:RecordDefinition>
     </om:resultDefinition>
     <om:result><![CDATA[3.321 0.8010000 3.673000 2.500000 1.000000 0.4243797 0.09778635 0E-7
3.578 1.058000 5.723000 5.000000 1.000000 -0.7176251 -0.1279985 0E-7
3.786 1.266000 7.484000 7.500000 1.000000 -0.4329453 -0.06371299 0E-7
3.964 1.444000 9.043000 10.00000 1.000000 0.09611742 -0.1096957 0E-7
4.140 1.620000 10.64600 12.50000 1.000000 0.5555710 -0.06163890 0E-7
4.330 1.810000 12.54900 15.00000 1.000000 0.7049310 0.2891556 0E-7
4.492 1.972000 14.37400 17.50000 1.000000 0.4707407 0.3386576 0E-7
4.632 2.112000 16.10500 20.00000 1.000000 0.06401150 0.1980543 0E-7
4.757 2.237000 17.76900 22.50000 1.000000 -0.3618670 -0.00001068555 0E-7
4.868 2.348000 19.32800 25.00000 1.000000 -0.6809527 -0.2343267 0E-7
4.970 2.450000 20.83400 27.50000 1.000000 -0.8393355 -0.4078032 0E-7
5.066 2.546000 22.30400 30.00000 1.000000 -0.7709866 -0.4477493 0E-7
5.156 2.636000 23.74200 32.50000 1.000000 -0.4460174 -0.3511040 0E-7
5.241 2.721000 25.14800 35.00000 1.000000 0.1759396 -0.09244382 0E-7
5.322 2.802000 26.52900 37.50000 1.000000 1.128911 0.3581850 0E-7
5.400 2.880000 27.89300 40.00000 1.000000 2.452953 1.038939 0E-7
5.442 2.922000 31.92700 42.50000 1.071350 0.07053353 0.4047354 1.630089E-8
5.488 2.968000 34.36600 45.00000 1.092220 -0.3779799 0.08173695 -5.237924E-8
5.531 3.011000 36.72200 47.50000 1.108100 -0.6878668 -0.2488190 5.663172E-8
5.570 3.050000 38.88500 50.00000 1.119030 -0.8285119 -0.6619480 -2.055337E-8
]]></om:result>
    </tuhh:WPointsObservation>
   </wb1d2d:pointsMember>
   <wb1d2d:polynomialMember>
    <math:Polynomial1D gml:id="Polynomial1D11903967141564">
     <gml:description>Q1(h)</gml:description>
     <gml:name>Q1(h)</gml:name>
     <math:coefficients>12.7817527032 -40.9637193346 49.1374071551 -19.7713699077 3.0664581784</math:coefficients>
     <math:minRange>0.801</math:minRange>
     <math:maxRange>3.05</math:maxRange>
     <math:domainPhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonRunoff"/>
     <math:rangePhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonWaterlevel"/>
    </math:Polynomial1D>
   </wb1d2d:polynomialMember>
   <wb1d2d:polynomialMember>
    <math:Polynomial1D gml:id="Polynomial1D1190396714156114">
     <gml:description>A1(h)</gml:description>
     <gml:name>A1(h)</gml:name>
     <math:coefficients>35.9471849499 -96.9397332106 99.2437596961 -39.3207410972 5.66458108844</math:coefficients>
     <math:minRange>0.801</math:minRange>
     <math:maxRange>3.05</math:maxRange>
     <math:domainPhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonArea"/>
     <math:rangePhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonWaterlevel"/>
    </math:Polynomial1D>
   </wb1d2d:polynomialMember>
   <wb1d2d:polynomialMember>
    <math:Polynomial1D gml:id="Polynomial1D119039671415637">
     <gml:description>al1(h)</gml:description>
     <gml:name>al1(h)</gml:name>
     <math:coefficients>1.0</math:coefficients>
     <math:minRange>0.801</math:minRange>
     <math:maxRange>2.88</math:maxRange>
     <math:domainPhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonAlpha"/>
     <math:rangePhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonWaterlevel"/>
    </math:Polynomial1D>
   </wb1d2d:polynomialMember>
   <wb1d2d:polynomialMember>
    <math:Polynomial1D gml:id="Polynomial1D119039671415686">
     <gml:description>Spl_al</gml:description>
     <gml:name>Spl_al</gml:name>
     <math:coefficients>40245.4353999 -41605.6165446 14336.78688 -1646.66425074</math:coefficients>
     <math:minRange>2.88</math:minRange>
     <math:maxRange>2.922</math:maxRange>
     <math:domainPhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonAlpha"/>
     <math:rangePhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonWaterlevel"/>
    </math:Polynomial1D>
   </wb1d2d:polynomialMember>
   <wb1d2d:polynomialMember>
    <math:Polynomial1D gml:id="Polynomial1D119039671415641">
     <gml:description>al2(h)</gml:description>
     <gml:name>al2(h)</gml:name>
     <math:coefficients>19.6318398019 -22.3877464843 8.63334857799 -1.07645690845</math:coefficients>
     <math:minRange>2.922</math:minRange>
     <math:maxRange>3.05</math:maxRange>
     <math:domainPhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonAlpha"/>
     <math:rangePhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonWaterlevel"/>
    </math:Polynomial1D>
   </wb1d2d:polynomialMember>
   <wb1d2d:station>59.2000</wb1d2d:station>
   <wb1d2d:profileMember xlink:href="terrain.gml#Profile119039671298412"/>
   <wb1d2d:slope>0.00100</wb1d2d:slope>
  </wb1d2d:TeschkeFlowRelation>
 </simBase:flowRelationshipMember>
 <simBase:flowRelationshipMember>
  <wb1d2d:TeschkeFlowRelation gml:id="TeschkeFlowRelation119039671415684">
   <gml:description>Gelesen aus: PROF0059.2600.txt</gml:description>
   <gml:name>59.2600</gml:name>
   <simBase:position>
    <gml:Point xmlns:ns1="http://www.w3.org/2001/SMIL20/" xmlns:st="http://www.seegrid.csiro.au/xml/st" xmlns:ns2="http://www.isotc211.org/2005/gmd" xmlns:ns3="http://www.isotc211.org/2005/gco" xmlns:ns4="http://www.isotc211.org/2005/gts" xmlns:ns5="http://www.isotc211.org/2005/gss" xmlns:ns6="http://www.isotc211.org/2005/gsr" xmlns:ns7="http://www.w3.org/2001/SMIL20/Language" srsName="EPSG:31467">
     <gml:coordinates ts="," decimal="." cs=" ">3552936.579355561 5987592.611995282 2.31</gml:coordinates>
    </gml:Point>
   </simBase:position>
   <wb1d2d:pointsMember>
    <tuhh:WPointsObservation gml:id="WPointsObservation119039671415610">
     <gml:description>�bernommen aus Datei: PROF0059.2600.txt</gml:description>
     <gml:name>0059.2600</gml:name>
     <om:resultDefinition>
      <swe:RecordDefinition gml:id="RecordDefinition119039671415640">
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#Waterlevel"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#Depth"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#Area"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#Runoff"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#Alpha"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#DeltaArea"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#DeltaRunoff"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#DeltaAlpha"/>
      </swe:RecordDefinition>
     </om:resultDefinition>
     <om:result><![CDATA[3.120 0.8100000 3.472000 2.500000 1.000000 -0.01522396 -0.009675356 0E-7
3.442 1.132000 5.751000 5.000000 1.000000 0.04085475 0.003011783 0E-7
3.671 1.361000 7.667000 7.500000 1.000000 0.007977885 0.03389378 0E-7
3.862 1.552000 9.423000 10.00000 1.000000 -0.02369467 0.03664814 0E-7
4.029 1.719000 11.06300 12.50000 1.000000 -0.03301252 -0.007924174 0E-7
4.179 1.869000 12.62300 15.00000 1.000000 -0.02393975 -0.09429020 0E-7
4.323 2.013000 14.19900 17.50000 1.000000 0.005100384 -0.08620439 0E-7
4.461 2.151000 15.81300 20.00000 1.000000 0.02540219 0.005066097 0E-7
4.588 2.278000 17.40900 22.50000 1.000000 0.02128685 0.06755860 0E-7
4.705 2.395000 18.95200 25.00000 1.000000 0.02330755 0.09544832 0E-7
4.812 2.502000 20.44700 27.50000 1.000000 0.01038239 0.06321688 0E-7
4.912 2.602000 21.90600 30.00000 1.000000 -0.001132539 0.01882146 0E-7
5.006 2.696000 23.33300 32.50000 1.000000 -0.01026499 -0.02779906 0E-7
5.095 2.785000 24.73100 35.00000 1.000000 -0.01270958 -0.06260200 0E-7
5.180 2.870000 26.12200 37.50000 1.000000 -0.02088044 -0.06698190 0E-7
5.261 2.951000 27.48800 40.00000 1.000000 -0.02209501 -0.04919110 0E-7
5.338 3.028000 28.81800 42.50000 1.000000 -0.01075313 -0.01902915 0E-7
5.412 3.102000 30.11800 45.00000 1.000000 0.01995790 0.04781245 0E-7
5.483 3.173000 31.40800 47.50000 1.000000 0.04621370 0.1442581 0E-7
5.542 3.232000 32.60500 50.00000 1.002340 -0.02677699 -0.09203825 -1.002340
]]></om:result>
    </tuhh:WPointsObservation>
   </wb1d2d:pointsMember>
   <wb1d2d:polynomialMember>
    <math:Polynomial1D gml:id="Polynomial1D119039671417157">
     <gml:description>Q1(h)</gml:description>
     <gml:name>Q1(h)</gml:name>
     <math:coefficients>4.66880414326 -13.367996085 16.6434897748 -4.85433020183 0.719204105727</math:coefficients>
     <math:minRange>0.81</math:minRange>
     <math:maxRange>3.232</math:maxRange>
     <math:domainPhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonRunoff"/>
     <math:rangePhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonWaterlevel"/>
    </math:Polynomial1D>
   </wb1d2d:polynomialMember>
   <wb1d2d:polynomialMember>
    <math:Polynomial1D gml:id="Polynomial1D119039671417147">
     <gml:description>A1(h)</gml:description>
     <gml:name>A1(h)</gml:name>
     <math:coefficients>-0.981063515817 4.29350214092 1.42591926108 0.0142348291989 0.0394739114296</math:coefficients>
     <math:minRange>0.81</math:minRange>
     <math:maxRange>3.232</math:maxRange>
     <math:domainPhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonArea"/>
     <math:rangePhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonWaterlevel"/>
    </math:Polynomial1D>
   </wb1d2d:polynomialMember>
   <wb1d2d:polynomialMember>
    <math:Polynomial1D gml:id="Polynomial1D119039671417154">
     <gml:description>al1(h)</gml:description>
     <gml:name>al1(h)</gml:name>
     <math:coefficients>1.0</math:coefficients>
     <math:minRange>0.81</math:minRange>
     <math:maxRange>3.173</math:maxRange>
     <math:domainPhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonAlpha"/>
     <math:rangePhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonWaterlevel"/>
    </math:Polynomial1D>
   </wb1d2d:polynomialMember>
   <wb1d2d:polynomialMember>
    <math:Polynomial1D gml:id="Polynomial1D119039671417192">
     <gml:description>Spl_al</gml:description>
     <gml:name>Spl_al</gml:name>
     <math:coefficients>0.0</math:coefficients>
     <math:minRange>3.173</math:minRange>
     <math:maxRange>3.173</math:maxRange>
     <math:domainPhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonAlpha"/>
     <math:rangePhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonWaterlevel"/>
    </math:Polynomial1D>
   </wb1d2d:polynomialMember>
   <wb1d2d:polynomialMember>
    <math:Polynomial1D gml:id="Polynomial1D119039671417128">
     <gml:description>al2(h)</gml:description>
     <gml:name>al2(h)</gml:name>
     <math:coefficients>0.0</math:coefficients>
     <math:minRange>3.173</math:minRange>
     <math:maxRange>3.173</math:maxRange>
     <math:domainPhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonAlpha"/>
     <math:rangePhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonWaterlevel"/>
    </math:Polynomial1D>
   </wb1d2d:polynomialMember>
   <wb1d2d:station>59.2600</wb1d2d:station>
   <wb1d2d:profileMember xlink:href="terrain.gml#Profile119039671300020"/>
   <wb1d2d:slope>0.00100</wb1d2d:slope>
  </wb1d2d:TeschkeFlowRelation>
 </simBase:flowRelationshipMember>
 <simBase:flowRelationshipMember>
  <wb1d2d:TeschkeFlowRelation gml:id="TeschkeFlowRelation119039671417115">
   <gml:description>Gelesen aus: PROF0059.3000.txt</gml:description>
   <gml:name>59.3000</gml:name>
   <simBase:position>
    <gml:Point xmlns:ns1="http://www.w3.org/2001/SMIL20/" xmlns:st="http://www.seegrid.csiro.au/xml/st" xmlns:ns2="http://www.isotc211.org/2005/gmd" xmlns:ns3="http://www.isotc211.org/2005/gco" xmlns:ns4="http://www.isotc211.org/2005/gts" xmlns:ns5="http://www.isotc211.org/2005/gss" xmlns:ns6="http://www.isotc211.org/2005/gsr" xmlns:ns7="http://www.w3.org/2001/SMIL20/Language" srsName="EPSG:31467">
     <gml:coordinates ts="," decimal="." cs=" ">3552969.4561555334 5987619.335495255 3.01</gml:coordinates>
    </gml:Point>
   </simBase:position>
   <wb1d2d:pointsMember>
    <tuhh:WPointsObservation gml:id="WPointsObservation11903967141712">
     <gml:description>�bernommen aus Datei: PROF0059.3000.txt</gml:description>
     <gml:name>0059.3000</gml:name>
     <om:resultDefinition>
      <swe:RecordDefinition gml:id="RecordDefinition119039671417158">
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#Waterlevel"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#Depth"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#Area"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#Runoff"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#Alpha"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#DeltaArea"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#DeltaRunoff"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#DeltaAlpha"/>
      </swe:RecordDefinition>
     </om:resultDefinition>
     <om:result><![CDATA[3.629 0.6190000 3.974000 2.500000 1.000000 0.01994060 0.08063831 0E-7
3.856 0.8460000 6.264000 5.000000 1.000000 -0.02592980 -0.1087277 0E-7
4.028 1.018000 8.119000 7.500000 1.000000 -0.02368599 -0.08848115 0E-7
4.176 1.166000 9.792000 10.00000 1.000000 -0.01476177 -0.03810899 0E-7
4.311 1.301000 11.35800 12.50000 1.000000 0.01160185 0.02273169 0E-7
4.437 1.427000 12.87000 15.00000 1.000000 0.03313991 0.07537290 0E-7
4.558 1.548000 14.38600 17.50000 1.000000 0.03404564 0.1546368 0E-7
4.671 1.661000 15.84900 20.00000 1.000000 0.03054504 0.1706309 0E-7
4.776 1.766000 17.26800 22.50000 1.000000 0.01001502 0.1046369 0E-7
4.874 1.864000 18.64800 25.00000 1.000000 -0.02218749 -0.03124155 0E-7
4.968 1.958000 19.99400 27.50000 1.000000 -0.03056501 -0.1673394 0E-7
5.057 2.047000 21.31100 30.00000 1.000000 -0.03428098 -0.3276850 0E-7
5.152 2.142000 22.76900 32.50000 1.000000 -0.03241071 -0.2017584 0E-7
5.242 2.232000 24.21400 35.00000 1.000000 -0.03076889 -0.06941261 0E-7
5.327 2.317000 25.62900 37.50000 1.000000 -0.01450915 0.06867016 0E-7
5.407 2.397000 27.01700 40.00000 1.000000 0.009756114 0.2081662 0E-7
5.481 2.471000 28.32900 42.50000 1.000000 0.06700371 0.3044888 0E-7
5.545 2.535000 29.54100 45.00000 1.001800 0.09298498 0.1850821 4.450440E-12
5.603 2.593000 30.75500 47.50000 1.005300 0.04782036 -0.03746444 -9.138468E-12
5.657 2.647000 32.06200 50.00000 1.012280 -0.1277534 -0.3048353 4.687362E-12
]]></om:result>
    </tuhh:WPointsObservation>
   </wb1d2d:pointsMember>
   <wb1d2d:polynomialMember>
    <math:Polynomial1D gml:id="Polynomial1D11903967141714">
     <gml:description>Q1(h)</gml:description>
     <gml:name>Q1(h)</gml:name>
     <math:coefficients>6.6178620405 -24.3269641164 36.5414617683 -13.9550917401 2.24590132498</math:coefficients>
     <math:minRange>0.619</math:minRange>
     <math:maxRange>2.647</math:maxRange>
     <math:domainPhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonRunoff"/>
     <math:rangePhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonWaterlevel"/>
    </math:Polynomial1D>
   </wb1d2d:polynomialMember>
   <wb1d2d:polynomialMember>
    <math:Polynomial1D gml:id="Polynomial1D1190396714171116">
     <gml:description>A1(h)</gml:description>
     <gml:name>A1(h)</gml:name>
     <math:coefficients>-0.0631180407254 2.95457275859 7.49461684269 -3.0747921815 0.584434175745</math:coefficients>
     <math:minRange>0.619</math:minRange>
     <math:maxRange>2.647</math:maxRange>
     <math:domainPhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonArea"/>
     <math:rangePhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonWaterlevel"/>
    </math:Polynomial1D>
   </wb1d2d:polynomialMember>
   <wb1d2d:polynomialMember>
    <math:Polynomial1D gml:id="Polynomial1D11903967141715">
     <gml:description>al1(h)</gml:description>
     <gml:name>al1(h)</gml:name>
     <math:coefficients>1.0</math:coefficients>
     <math:minRange>0.619</math:minRange>
     <math:maxRange>2.471</math:maxRange>
     <math:domainPhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonAlpha"/>
     <math:rangePhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonWaterlevel"/>
    </math:Polynomial1D>
   </wb1d2d:polynomialMember>
   <wb1d2d:polynomialMember>
    <math:Polynomial1D gml:id="Polynomial1D119039671417144">
     <gml:description>Spl_al</gml:description>
     <gml:name>Spl_al</gml:name>
     <math:coefficients>123.069512341 -145.896889755 58.1105685763 -7.7131356761</math:coefficients>
     <math:minRange>2.471</math:minRange>
     <math:maxRange>2.535</math:maxRange>
     <math:domainPhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonAlpha"/>
     <math:rangePhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonWaterlevel"/>
    </math:Polynomial1D>
   </wb1d2d:polynomialMember>
   <wb1d2d:polynomialMember>
    <math:Polynomial1D gml:id="Polynomial1D119039671417178">
     <gml:description>al2(h)</gml:description>
     <gml:name>al2(h)</gml:name>
     <math:coefficients>4.89339850365 -3.09495167384 0.61530743003</math:coefficients>
     <math:minRange>2.535</math:minRange>
     <math:maxRange>2.647</math:maxRange>
     <math:domainPhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonAlpha"/>
     <math:rangePhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonWaterlevel"/>
    </math:Polynomial1D>
   </wb1d2d:polynomialMember>
   <wb1d2d:station>59.3000</wb1d2d:station>
   <wb1d2d:profileMember xlink:href="terrain.gml#Profile119039671300017"/>
   <wb1d2d:slope>0.00100</wb1d2d:slope>
  </wb1d2d:TeschkeFlowRelation>
 </simBase:flowRelationshipMember>
 <simBase:flowRelationshipMember>
  <wb1d2d:TeschkeFlowRelation gml:id="TeschkeFlowRelation119039671417182">
   <gml:description>Gelesen aus: PROF0059.3700.txt</gml:description>
   <gml:name>59.3700</gml:name>
   <simBase:position>
    <gml:Point xmlns:ns1="http://www.w3.org/2001/SMIL20/" xmlns:st="http://www.seegrid.csiro.au/xml/st" xmlns:ns2="http://www.isotc211.org/2005/gmd" xmlns:ns3="http://www.isotc211.org/2005/gco" xmlns:ns4="http://www.isotc211.org/2005/gts" xmlns:ns5="http://www.isotc211.org/2005/gss" xmlns:ns6="http://www.isotc211.org/2005/gsr" xmlns:ns7="http://www.w3.org/2001/SMIL20/Language" srsName="EPSG:31467">
     <gml:coordinates ts="," decimal="." cs=" ">3552986.6851555193 5987678.013695183 2.77</gml:coordinates>
    </gml:Point>
   </simBase:position>
   <wb1d2d:pointsMember>
    <tuhh:WPointsObservation gml:id="WPointsObservation1190396714171123">
     <gml:description>�bernommen aus Datei: PROF0059.3700.txt</gml:description>
     <gml:name>0059.3700</gml:name>
     <om:resultDefinition>
      <swe:RecordDefinition gml:id="RecordDefinition11903967141713">
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#Waterlevel"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#Depth"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#Area"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#Runoff"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#Alpha"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#DeltaArea"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#DeltaRunoff"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#DeltaAlpha"/>
      </swe:RecordDefinition>
     </om:resultDefinition>
     <om:result><![CDATA[3.451 0.6810000 3.941000 2.500000 1.000000 0.4159587 0.6660116 0E-7
3.679 0.9090000 6.109000 5.000000 1.000000 -0.6964052 -0.9931671 0E-7
3.860 1.090000 7.943000 7.500000 1.000000 -0.4194443 -0.7265882 0E-7
4.019 1.249000 9.620000 10.00000 1.000000 0.07546014 -0.04347711 0E-7
4.160 1.390000 11.17500 12.50000 1.000000 0.4239807 0.4844604 0E-7
4.294 1.524000 12.69900 15.00000 1.000000 0.5681740 0.8297860 0E-7
4.420 1.650000 14.21400 17.50000 1.000000 0.4656439 0.8710289 0E-7
4.539 1.769000 15.70200 20.00000 1.000000 0.2002829 0.6158862 0E-7
4.652 1.882000 17.17300 22.50000 1.000000 -0.1433438 0.1202024 0E-7
4.757 1.987000 18.61100 25.00000 1.000000 -0.4751482 -0.5856125 0E-7
4.880 2.110000 20.38000 27.50000 1.000000 -0.7263546 -0.9736207 0E-7
4.999 2.229000 22.26500 30.00000 1.000000 -0.7152271 -1.279371 0E-7
5.100 2.330000 23.97900 32.50000 1.000000 -0.3056976 -1.661970 0E-7
5.311 2.541000 28.15100 35.00000 1.000000 2.314506 1.678078 0E-7
5.386 2.616000 33.77700 37.50000 1.070020 0.1531594 1.947574 0.0001335846
5.424 2.654000 36.06900 40.00000 1.082580 -0.1202455 1.033996 -0.0004119703
5.464 2.694000 38.62000 42.50000 1.093060 -0.3354173 0.3538513 0.0003532677
5.503 2.733000 41.16500 45.00000 1.100870 -0.3790536 -0.2103854 0.0001378280
5.540 2.770000 43.61600 47.50000 1.106550 -0.2380211 -0.7140462 -0.0003653352
5.571 2.801000 45.78700 50.00000 1.111450 -0.06280787 -1.412637 0.0001526251
]]></om:result>
    </tuhh:WPointsObservation>
   </wb1d2d:pointsMember>
   <wb1d2d:polynomialMember>
    <math:Polynomial1D gml:id="Polynomial1D1190396714171125">
     <gml:description>Q1(h)</gml:description>
     <gml:name>Q1(h)</gml:name>
     <math:coefficients>43.1196034023 -134.462594336 148.99405429 -61.634364722 9.22120970471</math:coefficients>
     <math:minRange>0.681</math:minRange>
     <math:maxRange>2.801</math:maxRange>
     <math:domainPhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonRunoff"/>
     <math:rangePhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonWaterlevel"/>
    </math:Polynomial1D>
   </wb1d2d:polynomialMember>
   <wb1d2d:polynomialMember>
    <math:Polynomial1D gml:id="Polynomial1D1190396714171145">
     <gml:description>A1(h)</gml:description>
     <gml:name>A1(h)</gml:name>
     <math:coefficients>33.1600815992 -103.298053336 123.788646398 -56.5893242332 9.32987321928</math:coefficients>
     <math:minRange>0.681</math:minRange>
     <math:maxRange>2.801</math:maxRange>
     <math:domainPhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonArea"/>
     <math:rangePhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonWaterlevel"/>
    </math:Polynomial1D>
   </wb1d2d:polynomialMember>
   <wb1d2d:polynomialMember>
    <math:Polynomial1D gml:id="Polynomial1D119039671417118">
     <gml:description>al1(h)</gml:description>
     <gml:name>al1(h)</gml:name>
     <math:coefficients>1.0</math:coefficients>
     <math:minRange>0.681</math:minRange>
     <math:maxRange>2.541</math:maxRange>
     <math:domainPhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonAlpha"/>
     <math:rangePhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonWaterlevel"/>
    </math:Polynomial1D>
   </wb1d2d:polynomialMember>
   <wb1d2d:polynomialMember>
    <math:Polynomial1D gml:id="Polynomial1D1190396714171103">
     <gml:description>Spl_al</gml:description>
     <gml:name>Spl_al</gml:name>
     <math:coefficients>4806.35265 -5588.37952478 2165.83207301 -279.729842119</math:coefficients>
     <math:minRange>2.541</math:minRange>
     <math:maxRange>2.616</math:maxRange>
     <math:domainPhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonAlpha"/>
     <math:rangePhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonWaterlevel"/>
    </math:Polynomial1D>
   </wb1d2d:polynomialMember>
   <wb1d2d:polynomialMember>
    <math:Polynomial1D gml:id="Polynomial1D119039671417141">
     <gml:description>al2(h)</gml:description>
     <gml:name>al2(h)</gml:name>
     <math:coefficients>2994.00113352 -4443.38687514 2472.359853 -611.075817756 56.6109921318</math:coefficients>
     <math:minRange>2.616</math:minRange>
     <math:maxRange>2.801</math:maxRange>
     <math:domainPhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonAlpha"/>
     <math:rangePhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonWaterlevel"/>
    </math:Polynomial1D>
   </wb1d2d:polynomialMember>
   <wb1d2d:station>59.3700</wb1d2d:station>
   <wb1d2d:profileMember xlink:href="terrain.gml#Profile1190396713015278"/>
   <wb1d2d:slope>0.00100</wb1d2d:slope>
  </wb1d2d:TeschkeFlowRelation>
 </simBase:flowRelationshipMember>
 <simBase:flowRelationshipMember>
  <wb1d2d:TeschkeFlowRelation gml:id="TeschkeFlowRelation119039671417122">
   <gml:description>Gelesen aus: PROF0059.4000.txt</gml:description>
   <gml:name>59.4000</gml:name>
   <simBase:position>
    <gml:Point xmlns:ns1="http://www.w3.org/2001/SMIL20/" xmlns:st="http://www.seegrid.csiro.au/xml/st" xmlns:ns2="http://www.isotc211.org/2005/gmd" xmlns:ns3="http://www.isotc211.org/2005/gco" xmlns:ns4="http://www.isotc211.org/2005/gts" xmlns:ns5="http://www.isotc211.org/2005/gss" xmlns:ns6="http://www.isotc211.org/2005/gsr" xmlns:ns7="http://www.w3.org/2001/SMIL20/Language" srsName="EPSG:31467">
     <gml:coordinates ts="," decimal="." cs=" ">3552983.6591555215 5987726.637695124 2.68</gml:coordinates>
    </gml:Point>
   </simBase:position>
   <wb1d2d:pointsMember>
    <tuhh:WPointsObservation gml:id="WPointsObservation1190396714171146">
     <gml:description>�bernommen aus Datei: PROF0059.4000.txt</gml:description>
     <gml:name>0059.4000</gml:name>
     <om:resultDefinition>
      <swe:RecordDefinition gml:id="RecordDefinition119039671417133">
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#Waterlevel"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#Depth"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#Area"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#Runoff"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#Alpha"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#DeltaArea"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#DeltaRunoff"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#DeltaAlpha"/>
      </swe:RecordDefinition>
     </om:resultDefinition>
     <om:result><![CDATA[3.570 0.8900000 3.652000 2.500000 1.000000 1.675599 0.05224405 0E-7
3.848 1.168000 5.843000 5.000000 1.000000 -3.273873 -0.09827166 0E-7
4.061 1.381000 7.684000 7.500000 1.000000 -1.521410 -0.03996804 0E-7
4.244 1.564000 9.364000 10.00000 1.000000 0.8354769 -0.02919508 0E-7
4.421 1.741000 11.10800 12.50000 1.000000 2.398331 0.1036344 0E-7
4.580 1.900000 12.82100 15.00000 1.000000 2.598371 0.1440467 0E-7
4.721 2.041000 14.46000 17.50000 1.000000 1.762335 0.07639341 0E-7
4.848 2.168000 16.03700 20.00000 1.000000 0.3790368 -0.03406777 0E-7
4.965 2.285000 17.56300 22.50000 1.000000 -1.112849 -0.1080157 0E-7
5.073 2.393000 19.04600 25.00000 1.000000 -2.343458 -0.1202333 0E-7
5.173 2.493000 20.49100 27.50000 1.000000 -3.013989 -0.05033729 0E-7
5.261 2.581000 21.86600 30.00000 1.002630 -2.969601 -0.03221630 9.753617E-8
5.340 2.660000 23.42100 32.50000 1.013820 -2.406025 -0.03107101 -0.000006669919
5.412 2.732000 25.16200 35.00000 1.029020 -1.308495 -0.02430687 0.00003041524
5.478 2.798000 27.03000 37.50000 1.045490 0.3628379 -0.01229970 -0.00004591713
5.540 2.860000 28.98700 40.00000 1.061830 2.701086 0.05439628 0.000009265483
5.598 2.918000 31.00600 42.50000 1.077340 5.685397 0.1545251 0.00004283195
5.652 2.972000 33.06700 45.00000 1.091720 9.254361 0.2632601 -0.00004213798
5.703 3.023000 35.15700 47.50000 1.104860 13.44296 0.4064392 0.00001211483
5.729 3.049000 75.33800 50.00000 1.274840 -23.14609 -0.6749565 -1.274840
]]></om:result>
    </tuhh:WPointsObservation>
   </wb1d2d:pointsMember>
   <wb1d2d:polynomialMember>
    <math:Polynomial1D gml:id="Polynomial1D119039671417169">
     <gml:description>Q1(h)</gml:description>
     <gml:name>Q1(h)</gml:name>
     <math:coefficients>15.1891397757 -44.6746213789 48.5100733952 -18.5581678586 2.83958808808</math:coefficients>
     <math:minRange>0.89</math:minRange>
     <math:maxRange>3.049</math:maxRange>
     <math:domainPhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonRunoff"/>
     <math:rangePhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonWaterlevel"/>
    </math:Polynomial1D>
   </wb1d2d:polynomialMember>
   <wb1d2d:polynomialMember>
    <math:Polynomial1D gml:id="Polynomial1D1190396714171139">
     <gml:description>A1(h)</gml:description>
     <gml:name>A1(h)</gml:name>
     <math:coefficients>218.000056199 -557.601775452 508.641265882 -192.536130082 26.1871098413</math:coefficients>
     <math:minRange>0.89</math:minRange>
     <math:maxRange>3.049</math:maxRange>
     <math:domainPhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonArea"/>
     <math:rangePhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonWaterlevel"/>
    </math:Polynomial1D>
   </wb1d2d:polynomialMember>
   <wb1d2d:polynomialMember>
    <math:Polynomial1D gml:id="Polynomial1D119039671417176">
     <gml:description>al1(h)</gml:description>
     <gml:name>al1(h)</gml:name>
     <math:coefficients>1.0</math:coefficients>
     <math:minRange>0.89</math:minRange>
     <math:maxRange>2.493</math:maxRange>
     <math:domainPhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonAlpha"/>
     <math:rangePhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonWaterlevel"/>
    </math:Polynomial1D>
   </wb1d2d:polynomialMember>
   <wb1d2d:polynomialMember>
    <math:Polynomial1D gml:id="Polynomial1D1190396714171108">
     <gml:description>Spl_al</gml:description>
     <gml:name>Spl_al</gml:name>
     <math:coefficients>-63.9125118678 78.0437920471 -31.2771164867 4.17824063041</math:coefficients>
     <math:minRange>2.493</math:minRange>
     <math:maxRange>2.581</math:maxRange>
     <math:domainPhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonAlpha"/>
     <math:rangePhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonWaterlevel"/>
    </math:Polynomial1D>
   </wb1d2d:polynomialMember>
   <wb1d2d:polynomialMember>
    <math:Polynomial1D gml:id="Polynomial1D11903967141713">
     <gml:description>al2(h)</gml:description>
     <gml:name>al2(h)</gml:name>
     <math:coefficients>59.5848197095 -79.0932601438 39.7808568733 -8.84943398008 0.737048501306</math:coefficients>
     <math:minRange>2.581</math:minRange>
     <math:maxRange>3.023</math:maxRange>
     <math:domainPhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonAlpha"/>
     <math:rangePhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonWaterlevel"/>
    </math:Polynomial1D>
   </wb1d2d:polynomialMember>
   <wb1d2d:station>59.4000</wb1d2d:station>
   <wb1d2d:profileMember xlink:href="terrain.gml#Profile1190396713015220"/>
   <wb1d2d:slope>0.00100</wb1d2d:slope>
  </wb1d2d:TeschkeFlowRelation>
 </simBase:flowRelationshipMember>
 <simBase:flowRelationshipMember>
  <wb1d2d:TeschkeFlowRelation gml:id="TeschkeFlowRelation119039671417199">
   <gml:description>Gelesen aus: PROF0059.4500.txt</gml:description>
   <gml:name>59.4500</gml:name>
   <simBase:position>
    <gml:Point xmlns:ns1="http://www.w3.org/2001/SMIL20/" xmlns:st="http://www.seegrid.csiro.au/xml/st" xmlns:ns2="http://www.isotc211.org/2005/gmd" xmlns:ns3="http://www.isotc211.org/2005/gco" xmlns:ns4="http://www.isotc211.org/2005/gts" xmlns:ns5="http://www.isotc211.org/2005/gss" xmlns:ns6="http://www.isotc211.org/2005/gsr" xmlns:ns7="http://www.w3.org/2001/SMIL20/Language" srsName="EPSG:31467">
     <gml:coordinates ts="," decimal="." cs=" ">3552986.9675555187 5987774.24439507 2.8</gml:coordinates>
    </gml:Point>
   </simBase:position>
   <wb1d2d:pointsMember>
    <tuhh:WPointsObservation gml:id="WPointsObservation119039671417161">
     <gml:description>�bernommen aus Datei: PROF0059.4500.txt</gml:description>
     <gml:name>0059.4500</gml:name>
     <om:resultDefinition>
      <swe:RecordDefinition gml:id="RecordDefinition119039671417128">
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#Waterlevel"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#Depth"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#Area"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#Runoff"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#Alpha"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#DeltaArea"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#DeltaRunoff"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#DeltaAlpha"/>
      </swe:RecordDefinition>
     </om:resultDefinition>
     <om:result><![CDATA[3.488 0.6880000 3.719000 2.500000 1.000000 1.423220 0.6818563 0E-7
3.737 0.9370000 5.816000 5.000000 1.000000 -2.600136 -1.315096 0E-7
3.938 1.138000 7.647000 7.500000 1.000000 -1.344873 -0.5990342 0E-7
4.107 1.307000 9.289000 10.00000 1.000000 0.4590424 0.3382625 0E-7
4.255 1.455000 10.78300 12.50000 1.000000 1.637799 0.8816130 0E-7
4.391 1.591000 12.19700 15.00000 1.000000 1.992783 0.9820888 0E-7
4.517 1.717000 13.54900 17.50000 1.000000 1.589533 0.6527841 0E-7
4.634 1.834000 14.82600 20.00000 1.000000 0.6685380 -0.01968655 0E-7
4.766 1.966000 16.31700 22.50000 1.000000 -0.7804574 -0.5736027 0E-7
4.902 2.102000 17.96400 25.00000 1.000000 -2.310365 -0.9878511 0E-7
5.024 2.224000 19.55300 27.50000 1.000000 -3.151243 -1.283330 0E-7
5.135 2.335000 21.09000 30.00000 1.000000 -2.901340 -1.236322 0E-7
5.269 2.469000 23.07300 32.50000 1.000000 -0.4319036 0.4416898 0E-7
5.393 2.593000 25.12100 35.00000 1.000960 4.904465 3.366131 -0.0009600000
4.317 1.517000 11.42200 37.50000 1.000000 1.899324 -22.90202 0.003540000
5.473 2.673000 26.62200 40.00000 1.003540 10.37888 2.918619 0E-7
5.477 2.677000 26.69000 42.50000 1.003680 10.71273 0.6714987 0E-7
5.490 2.690000 45.13700 45.00000 1.256760 -6.390887 -0.9888716 -1.256760
5.518 2.718000 48.71400 47.50000 1.266190 -6.874318 -1.585249 -1.266190
5.542 2.742000 51.70000 50.00000 1.269170 -6.981461 -2.345500 -1.269170
]]></om:result>
    </tuhh:WPointsObservation>
   </wb1d2d:pointsMember>
   <wb1d2d:polynomialMember>
    <math:Polynomial1D gml:id="Polynomial1D119039671418788">
     <gml:description>Q1(h)</gml:description>
     <gml:name>Q1(h)</gml:name>
     <math:coefficients>57.2072208823 -178.301140302 196.771354121 -84.1604416182 13.0014149276</math:coefficients>
     <math:minRange>0.688</math:minRange>
     <math:maxRange>2.742</math:maxRange>
     <math:domainPhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonRunoff"/>
     <math:rangePhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonWaterlevel"/>
    </math:Polynomial1D>
   </wb1d2d:polynomialMember>
   <wb1d2d:polynomialMember>
    <math:Polynomial1D gml:id="Polynomial1D1190396714187158">
     <gml:description>A1(h)</gml:description>
     <gml:name>A1(h)</gml:name>
     <math:coefficients>113.785358653 -349.455455247 382.330161029 -169.388622405 26.6530591936</math:coefficients>
     <math:minRange>0.688</math:minRange>
     <math:maxRange>2.742</math:maxRange>
     <math:domainPhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonArea"/>
     <math:rangePhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonWaterlevel"/>
    </math:Polynomial1D>
   </wb1d2d:polynomialMember>
   <wb1d2d:polynomialMember>
    <math:Polynomial1D gml:id="Polynomial1D119039671418771">
     <gml:description>al1(h)</gml:description>
     <gml:name>al1(h)</gml:name>
     <math:coefficients>1.0</math:coefficients>
     <math:minRange>0.688</math:minRange>
     <math:maxRange>2.593</math:maxRange>
     <math:domainPhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonAlpha"/>
     <math:rangePhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonWaterlevel"/>
    </math:Polynomial1D>
   </wb1d2d:polynomialMember>
   <wb1d2d:polynomialMember>
    <math:Polynomial1D gml:id="Polynomial1D1190396714187101">
     <gml:description>Spl_al</gml:description>
     <gml:name>Spl_al</gml:name>
     <math:coefficients>154.956328832 -174.953153828 66.2494531248 -8.35937499997</math:coefficients>
     <math:minRange>2.593</math:minRange>
     <math:maxRange>2.673</math:maxRange>
     <math:domainPhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonAlpha"/>
     <math:rangePhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonWaterlevel"/>
    </math:Polynomial1D>
   </wb1d2d:polynomialMember>
   <wb1d2d:polynomialMember>
    <math:Polynomial1D gml:id="Polynomial1D1190396714187159">
     <gml:description>al2(h)</gml:description>
     <gml:name>al2(h)</gml:name>
     <math:coefficients>0.909985 0.0349999999999</math:coefficients>
     <math:minRange>2.673</math:minRange>
     <math:maxRange>2.677</math:maxRange>
     <math:domainPhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonAlpha"/>
     <math:rangePhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonWaterlevel"/>
    </math:Polynomial1D>
   </wb1d2d:polynomialMember>
   <wb1d2d:station>59.4500</wb1d2d:station>
   <wb1d2d:profileMember xlink:href="terrain.gml#Profile1190396713031162"/>
   <wb1d2d:slope>0.00100</wb1d2d:slope>
  </wb1d2d:TeschkeFlowRelation>
 </simBase:flowRelationshipMember>
 <simBase:flowRelationshipMember>
  <wb1d2d:TeschkeFlowRelation gml:id="TeschkeFlowRelation119039671418727">
   <gml:description>Gelesen aus: PROF0059.5000.txt</gml:description>
   <gml:name>59.5000</gml:name>
   <simBase:position>
    <gml:Point xmlns:ns1="http://www.w3.org/2001/SMIL20/" xmlns:st="http://www.seegrid.csiro.au/xml/st" xmlns:ns2="http://www.isotc211.org/2005/gmd" xmlns:ns3="http://www.isotc211.org/2005/gco" xmlns:ns4="http://www.isotc211.org/2005/gts" xmlns:ns5="http://www.isotc211.org/2005/gss" xmlns:ns6="http://www.isotc211.org/2005/gsr" xmlns:ns7="http://www.w3.org/2001/SMIL20/Language" srsName="EPSG:31467">
     <gml:coordinates ts="," decimal="." cs=" ">3553012.031355498 5987820.794095011 2.85</gml:coordinates>
    </gml:Point>
   </simBase:position>
   <wb1d2d:pointsMember>
    <tuhh:WPointsObservation gml:id="WPointsObservation119039671418797">
     <gml:description>�bernommen aus Datei: PROF0059.5000.txt</gml:description>
     <gml:name>0059.5000</gml:name>
     <om:resultDefinition>
      <swe:RecordDefinition gml:id="RecordDefinition1190396714187118">
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#Waterlevel"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#Depth"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#Area"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#Runoff"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#Alpha"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#DeltaArea"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#DeltaRunoff"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#DeltaAlpha"/>
      </swe:RecordDefinition>
     </om:resultDefinition>
     <om:result><![CDATA[3.398 0.5480000 3.818000 2.500000 1.000000 0.01363136 0.1281020 0E-7
3.637 0.7870000 5.938000 5.000000 1.000000 -0.02382272 -0.2902535 0E-7
3.829 0.9790000 7.786000 7.500000 1.000000 -0.007627477 -0.07862169 0E-7
3.989 1.139000 9.420000 10.00000 1.000000 0.005361961 0.1198928 0E-7
4.131 1.281000 10.93900 12.50000 1.000000 0.005063401 0.2262169 0E-7
4.260 1.410000 12.36400 15.00000 1.000000 0.001614175 0.2080868 0E-7
4.380 1.530000 13.72300 17.50000 1.000000 0.001017083 0.08923593 0E-7
4.492 1.642000 15.01800 20.00000 1.000000 0.008147931 -0.1309115 0E-7
4.598 1.748000 16.27100 22.50000 1.000000 0.02261841 -0.4154034 0E-7
4.721 1.871000 17.78300 25.00000 1.000000 0.03240480 -0.2521556 0E-7
4.853 2.003000 19.51900 27.50000 1.000000 0.004365936 0.2620495 0E-7
4.951 2.101000 20.89000 30.00000 1.000000 -0.03729730 0.1456045 0E-7
5.043 2.193000 22.21000 32.50000 1.000000 -0.05241196 0.03317442 0E-7
5.130 2.280000 23.50700 35.00000 1.000000 -0.05648360 -0.04165169 0E-7
5.213 2.363000 24.78300 37.50000 1.000000 -0.03773894 -0.04326593 0E-7
5.293 2.443000 26.03200 40.00000 1.000000 0.02539151 0.06814844 0E-7
5.364 2.514000 27.18400 42.50000 1.000540 0.09697379 0.08055526 -0.0005400000
5.426 2.576000 28.31700 45.00000 1.003770 0.08259880 -0.05476097 -7.813750E-13
5.487 2.637000 29.52500 47.50000 1.008710 0.02494881 -0.05426082 1.550760E-12
5.545 2.695000 30.80200 50.00000 1.014830 -0.1087560 0.0002186107 -7.698286E-13
]]></om:result>
    </tuhh:WPointsObservation>
   </wb1d2d:pointsMember>
   <wb1d2d:polynomialMember>
    <math:Polynomial1D gml:id="Polynomial1D119039671418778">
     <gml:description>Q1(h)</gml:description>
     <gml:name>Q1(h)</gml:name>
     <math:coefficients>8.17041943039 -29.5344302547 44.7997008075 -18.7813259208 3.10259505397</math:coefficients>
     <math:minRange>0.548</math:minRange>
     <math:maxRange>2.695</math:maxRange>
     <math:domainPhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonRunoff"/>
     <math:rangePhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonWaterlevel"/>
    </math:Polynomial1D>
   </wb1d2d:polynomialMember>
   <wb1d2d:polynomialMember>
    <math:Polynomial1D gml:id="Polynomial1D1190396714187107">
     <gml:description>A1(h)</gml:description>
     <gml:name>A1(h)</gml:name>
     <math:coefficients>0.800061639322 2.30563979286 7.42566947342 -3.12850736432 0.587349791374</math:coefficients>
     <math:minRange>0.548</math:minRange>
     <math:maxRange>2.695</math:maxRange>
     <math:domainPhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonArea"/>
     <math:rangePhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonWaterlevel"/>
    </math:Polynomial1D>
   </wb1d2d:polynomialMember>
   <wb1d2d:polynomialMember>
    <math:Polynomial1D gml:id="Polynomial1D119039671418798">
     <gml:description>al1(h)</gml:description>
     <gml:name>al1(h)</gml:name>
     <math:coefficients>1.0</math:coefficients>
     <math:minRange>0.548</math:minRange>
     <math:maxRange>2.514</math:maxRange>
     <math:domainPhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonAlpha"/>
     <math:rangePhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonWaterlevel"/>
    </math:Polynomial1D>
   </wb1d2d:polynomialMember>
   <wb1d2d:polynomialMember>
    <math:Polynomial1D gml:id="Polynomial1D11903967141878">
     <gml:description>Spl_al</gml:description>
     <gml:name>Spl_al</gml:name>
     <math:coefficients>232.543785796 -271.682238517 106.228815985 -13.8411450244</math:coefficients>
     <math:minRange>2.514</math:minRange>
     <math:maxRange>2.576</math:maxRange>
     <math:domainPhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonAlpha"/>
     <math:rangePhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonWaterlevel"/>
    </math:Polynomial1D>
   </wb1d2d:polynomialMember>
   <wb1d2d:polynomialMember>
    <math:Polynomial1D gml:id="Polynomial1D119039671418724">
     <gml:description>al2(h)</gml:description>
     <gml:name>al2(h)</gml:name>
     <math:coefficients>2.19561691726 -0.993754527176 0.206164997846</math:coefficients>
     <math:minRange>2.576</math:minRange>
     <math:maxRange>2.695</math:maxRange>
     <math:domainPhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonAlpha"/>
     <math:rangePhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonWaterlevel"/>
    </math:Polynomial1D>
   </wb1d2d:polynomialMember>
   <wb1d2d:station>59.5000</wb1d2d:station>
   <wb1d2d:profileMember xlink:href="terrain.gml#Profile1190396713031223"/>
   <wb1d2d:slope>0.00100</wb1d2d:slope>
  </wb1d2d:TeschkeFlowRelation>
 </simBase:flowRelationshipMember>
 <simBase:flowRelationshipMember>
  <wb1d2d:TeschkeFlowRelation gml:id="TeschkeFlowRelation119039671418798">
   <gml:description>Gelesen aus: PROF0059.5500.txt</gml:description>
   <gml:name>59.5500</gml:name>
   <simBase:position>
    <gml:Point xmlns:ns1="http://www.w3.org/2001/SMIL20/" xmlns:st="http://www.seegrid.csiro.au/xml/st" xmlns:ns2="http://www.isotc211.org/2005/gmd" xmlns:ns3="http://www.isotc211.org/2005/gco" xmlns:ns4="http://www.isotc211.org/2005/gts" xmlns:ns5="http://www.isotc211.org/2005/gss" xmlns:ns6="http://www.isotc211.org/2005/gsr" xmlns:ns7="http://www.w3.org/2001/SMIL20/Language" srsName="EPSG:31467">
     <gml:coordinates ts="," decimal="." cs=" ">3553038.035255476 5987864.967794962 2.67</gml:coordinates>
    </gml:Point>
   </simBase:position>
   <wb1d2d:pointsMember>
    <tuhh:WPointsObservation gml:id="WPointsObservation119039671418717">
     <gml:description>�bernommen aus Datei: PROF0059.5500.txt</gml:description>
     <gml:name>0059.5500</gml:name>
     <om:resultDefinition>
      <swe:RecordDefinition gml:id="RecordDefinition1190396714187136">
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#Waterlevel"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#Depth"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#Area"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#Runoff"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#Alpha"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#DeltaArea"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#DeltaRunoff"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#DeltaAlpha"/>
      </swe:RecordDefinition>
     </om:resultDefinition>
     <om:result><![CDATA[3.419 0.7490000 3.926000 2.500000 1.000000 0.1711982 0.1656108 0E-7
3.653 0.9830000 6.118000 5.000000 1.000000 -0.2907696 -0.2889854 0E-7
3.840 1.170000 7.991000 7.500000 1.000000 -0.1702070 -0.1676819 0E-7
4.001 1.331000 9.692000 10.00000 1.000000 0.02952533 0.03751600 0E-7
4.145 1.475000 11.28000 12.50000 1.000000 0.1739860 0.1904341 0E-7
4.276 1.606000 12.78500 15.00000 1.000000 0.2237985 0.2406952 0E-7
4.398 1.728000 14.22500 17.50000 1.000000 0.1997620 0.2122724 0E-7
4.511 1.841000 15.61300 20.00000 1.000000 0.1017800 0.08397020 0E-7
4.618 1.948000 16.95700 22.50000 1.000000 -0.02163572 -0.08549563 0E-7
4.720 2.050000 18.26100 25.00000 1.000000 -0.1370195 -0.2674009 0E-7
4.824 2.154000 19.65000 27.50000 1.000000 -0.2537689 -0.2785374 0E-7
4.925 2.255000 21.03300 30.00000 1.000000 -0.3005655 -0.2050527 0E-7
5.019 2.349000 22.38700 32.50000 1.000000 -0.2777969 -0.1339905 0E-7
5.109 2.439000 23.71500 35.00000 1.000000 -0.1230436 0.02474327 0E-7
5.195 2.525000 25.02600 37.50000 1.000000 0.1767611 0.2833047 0E-7
5.267 2.597000 26.27300 40.00000 1.003660 0.4574812 0.2858605 -0.000002732752
5.331 2.661000 27.82700 42.50000 1.017600 0.4234437 0.1800112 0.00001209568
5.391 2.721000 29.65700 45.00000 1.036990 0.1770975 0.08741878 -0.00002048566
5.445 2.775000 31.57300 47.50000 1.054430 -0.1661734 -0.09682971 0.00001531380
5.496 2.826000 33.42800 50.00000 1.067730 -0.3938533 -0.2678630 -0.000004191069
]]></om:result>
    </tuhh:WPointsObservation>
   </wb1d2d:pointsMember>
   <wb1d2d:polynomialMember>
    <math:Polynomial1D gml:id="Polynomial1D1190396714187160">
     <gml:description>Q1(h)</gml:description>
     <gml:name>Q1(h)</gml:name>
     <math:coefficients>15.717749984 -48.9815167542 56.3013509518 -21.3140084458 3.19593217195</math:coefficients>
     <math:minRange>0.749</math:minRange>
     <math:maxRange>2.826</math:maxRange>
     <math:domainPhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonRunoff"/>
     <math:rangePhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonWaterlevel"/>
    </math:Polynomial1D>
   </wb1d2d:polynomialMember>
   <wb1d2d:polynomialMember>
    <math:Polynomial1D gml:id="Polynomial1D119039671418751">
     <gml:description>A1(h)</gml:description>
     <gml:name>A1(h)</gml:name>
     <math:coefficients>14.8316526735 -42.8692307906 52.8223808418 -22.2289441764 3.43657248406</math:coefficients>
     <math:minRange>0.749</math:minRange>
     <math:maxRange>2.826</math:maxRange>
     <math:domainPhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonArea"/>
     <math:rangePhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonWaterlevel"/>
    </math:Polynomial1D>
   </wb1d2d:polynomialMember>
   <wb1d2d:polynomialMember>
    <math:Polynomial1D gml:id="Polynomial1D119039671418734">
     <gml:description>al1(h)</gml:description>
     <gml:name>al1(h)</gml:name>
     <math:coefficients>1.0</math:coefficients>
     <math:minRange>0.749</math:minRange>
     <math:maxRange>2.525</math:maxRange>
     <math:domainPhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonAlpha"/>
     <math:rangePhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonWaterlevel"/>
    </math:Polynomial1D>
   </wb1d2d:polynomialMember>
   <wb1d2d:polynomialMember>
    <math:Polynomial1D gml:id="Polynomial1D119039671418742">
     <gml:description>Spl_al</gml:description>
     <gml:name>Spl_al</gml:name>
     <math:coefficients>-55.7758912061 68.5650882667 -27.5935335169 3.70067018233</math:coefficients>
     <math:minRange>2.525</math:minRange>
     <math:maxRange>2.597</math:maxRange>
     <math:domainPhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonAlpha"/>
     <math:rangePhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonWaterlevel"/>
    </math:Polynomial1D>
   </wb1d2d:polynomialMember>
   <wb1d2d:polynomialMember>
    <math:Polynomial1D gml:id="Polynomial1D1190396714187176">
     <gml:description>al2(h)</gml:description>
     <gml:name>al2(h)</gml:name>
     <math:coefficients>319.133883826 -438.221529726 224.971108982 -50.9981859439 4.30625567744</math:coefficients>
     <math:minRange>2.597</math:minRange>
     <math:maxRange>2.826</math:maxRange>
     <math:domainPhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonAlpha"/>
     <math:rangePhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonWaterlevel"/>
    </math:Polynomial1D>
   </wb1d2d:polynomialMember>
   <wb1d2d:station>59.5500</wb1d2d:station>
   <wb1d2d:profileMember xlink:href="terrain.gml#Profile119039671304654"/>
   <wb1d2d:slope>0.00100</wb1d2d:slope>
  </wb1d2d:TeschkeFlowRelation>
 </simBase:flowRelationshipMember>
 <simBase:flowRelationshipMember>
  <op1d2d:BoundaryCondition gml:id="BoundaryCondition119039699728153">
   <gml:description>Manuell erzeugt am: 21.09.2007 19:49</gml:description>
   <gml:name>Wasserstand - Zeitreihe</gml:name>
   <simBase:position>
    <gml:Point xmlns:ns1="http://www.w3.org/2001/SMIL20/" xmlns:st="http://www.seegrid.csiro.au/xml/st" xmlns:ns2="http://www.isotc211.org/2005/gmd" xmlns:ns3="http://www.isotc211.org/2005/gco" xmlns:ns4="http://www.isotc211.org/2005/gts" xmlns:ns5="http://www.isotc211.org/2005/gss" xmlns:ns6="http://www.isotc211.org/2005/gsr" xmlns:ns7="http://www.w3.org/2001/SMIL20/Language" srsName="EPSG:31467">
     <gml:coordinates ts="," decimal="." cs=" ">3552947.7515222193 5986889.447896114</gml:coordinates>
    </gml:Point>
   </simBase:position>
   <op1d2d:direction/>
   <op1d2d:observation>
    <ns8:ObservationWithSource gml:id="ObservationWithSource1190396997281105">
     <gml:name>Wasserstand - Zeitreihe</gml:name>
     <om:observedProperty xlink:href="urn:ogc:gml:dict:kalypso:model:1d2d:timeserie:phenomenons#TimeserieBorderCondition1D"/>
     <om:resultDefinition>
      <sweExt:SortedRecordDefinition gml:id="SortedRecordDefinition1190396997406102">
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:1d2d:timeserie:components#Time"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:1d2d:timeserie:components#Waterlevel"/>
       <sweExt:sortedComponent xlink:href="urn:ogc:gml:dict:kalypso:model:1d2d:timeserie:components#Time"/>
      </sweExt:SortedRecordDefinition>
     </om:resultDefinition>
     <om:result><![CDATA[2007-09-21T00%3A00%3A00.000%2B02%3A00 20.0
2007-09-21T01%3A00%3A00.000%2B02%3A00 20.0
2007-09-21T02%3A00%3A00.000%2B02%3A00 20.0
2007-09-21T03%3A00%3A00.000%2B02%3A00 20.0
2007-09-21T04%3A00%3A00.000%2B02%3A00 20.0
2007-09-21T05%3A00%3A00.000%2B02%3A00 20.0
2007-09-21T06%3A00%3A00.000%2B02%3A00 20.0
2007-09-21T07%3A00%3A00.000%2B02%3A00 20.0
2007-09-21T08%3A00%3A00.000%2B02%3A00 20.0
2007-09-21T09%3A00%3A00.000%2B02%3A00 20.0
2007-09-21T10%3A00%3A00.000%2B02%3A00 20.0
2007-09-21T11%3A00%3A00.000%2B02%3A00 20.0
2007-09-21T12%3A00%3A00.000%2B02%3A00 20.0
2007-09-21T13%3A00%3A00.000%2B02%3A00 20.0
2007-09-21T14%3A00%3A00.000%2B02%3A00 20.0
2007-09-21T15%3A00%3A00.000%2B02%3A00 20.0
2007-09-21T16%3A00%3A00.000%2B02%3A00 20.0
2007-09-21T17%3A00%3A00.000%2B02%3A00 20.0
2007-09-21T18%3A00%3A00.000%2B02%3A00 20.0
2007-09-21T19%3A00%3A00.000%2B02%3A00 20.0
2007-09-21T20%3A00%3A00.000%2B02%3A00 20.0
2007-09-21T21%3A00%3A00.000%2B02%3A00 20.0
2007-09-21T22%3A00%3A00.000%2B02%3A00 20.0
2007-09-21T23%3A00%3A00.000%2B02%3A00 20.0
2007-09-22T00%3A00%3A00.000%2B02%3A00 20.0
]]></om:result>
     <ns8:dataSourceURI/>
    </ns8:ObservationWithSource>
   </op1d2d:observation>
   <op1d2d:bcType>LINE1D2D</op1d2d:bcType>
   <op1d2d:parentModelElement>ContinuityLine1D119039693395316574</op1d2d:parentModelElement>
   <op1d2d:stationaryCondition>4.5</op1d2d:stationaryCondition>
  </op1d2d:BoundaryCondition>
 </simBase:flowRelationshipMember>
 <simBase:flowRelationshipMember>
  <op1d2d:BoundaryCondition gml:id="BoundaryCondition119039701292142">
   <gml:description>Manuell erzeugt am: 21.09.2007 19:50</gml:description>
   <gml:name>Abfluss - Zeitreihe</gml:name>
   <simBase:position>
    <gml:Point xmlns:ns1="http://www.w3.org/2001/SMIL20/" xmlns:st="http://www.seegrid.csiro.au/xml/st" xmlns:ns2="http://www.isotc211.org/2005/gmd" xmlns:ns3="http://www.isotc211.org/2005/gco" xmlns:ns4="http://www.isotc211.org/2005/gts" xmlns:ns5="http://www.isotc211.org/2005/gss" xmlns:ns6="http://www.isotc211.org/2005/gsr" xmlns:ns7="http://www.w3.org/2001/SMIL20/Language" srsName="EPSG:31467">
     <gml:coordinates ts="," decimal="." cs=" ">3553038.035255476 5987864.967794962</gml:coordinates>
    </gml:Point>
   </simBase:position>
   <op1d2d:direction>240</op1d2d:direction>
   <op1d2d:observation>
    <ns8:ObservationWithSource gml:id="ObservationWithSource1190397012921164">
     <gml:name>Abfluss - Zeitreihe</gml:name>
     <om:observedProperty xlink:href="urn:ogc:gml:dict:kalypso:model:1d2d:timeserie:phenomenons#TimeserieBorderCondition1D"/>
     <om:resultDefinition>
      <sweExt:SortedRecordDefinition gml:id="SortedRecordDefinition119039701293796">
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:1d2d:timeserie:components#Time"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:1d2d:timeserie:components#Discharge"/>
       <sweExt:sortedComponent xlink:href="urn:ogc:gml:dict:kalypso:model:1d2d:timeserie:components#Time"/>
      </sweExt:SortedRecordDefinition>
     </om:resultDefinition>
     <om:result><![CDATA[2007-09-21T05%3A00%3A00.000%2B02%3A00 20.0
2007-09-21T06%3A00%3A00.000%2B02%3A00 20.0
2007-09-21T07%3A00%3A00.000%2B02%3A00 20.0
2007-09-21T08%3A00%3A00.000%2B02%3A00 20.0
2007-09-21T09%3A00%3A00.000%2B02%3A00 20.0
2007-09-21T10%3A00%3A00.000%2B02%3A00 20.0
2007-09-21T11%3A00%3A00.000%2B02%3A00 20.0
2007-09-21T12%3A00%3A00.000%2B02%3A00 20.0
2007-09-21T13%3A00%3A00.000%2B02%3A00 20.0
2007-09-21T14%3A00%3A00.000%2B02%3A00 20.0
2007-09-21T15%3A00%3A00.000%2B02%3A00 20.0
2007-09-21T16%3A00%3A00.000%2B02%3A00 20.0
2007-09-21T17%3A00%3A00.000%2B02%3A00 20.0
2007-09-21T18%3A00%3A00.000%2B02%3A00 20.0
2007-09-21T19%3A00%3A00.000%2B02%3A00 20.0
2007-09-21T20%3A00%3A00.000%2B02%3A00 20.0
2007-09-21T21%3A00%3A00.000%2B02%3A00 20.0
2007-09-21T22%3A00%3A00.000%2B02%3A00 20.0
2007-09-21T23%3A00%3A00.000%2B02%3A00 20.0
2007-09-22T00%3A00%3A00.000%2B02%3A00 20.0
2007-09-23T00%3A00%3A00.000%2B02%3A00 20.0
2007-09-23T12%3A00%3A00.000%2B02%3A00 20.0
2007-09-24T00%3A00%3A00.000%2B02%3A00 20.0
2007-09-24T12%3A00%3A00.000%2B02%3A00 20.0
2007-09-25T00%3A00%3A00.000%2B02%3A00 20.000
]]></om:result>
     <ns8:dataSourceURI/>
    </ns8:ObservationWithSource>
   </op1d2d:observation>
   <op1d2d:bcType>LINE1D2D</op1d2d:bcType>
   <op1d2d:parentModelElement>ContinuityLine1D119039694375010676</op1d2d:parentModelElement>
   <op1d2d:parentCalculationUnit>CalculationUnit1D11903971116258141</op1d2d:parentCalculationUnit>
   <op1d2d:stationaryCondition>20.0</op1d2d:stationaryCondition>
  </op1d2d:BoundaryCondition>
 </simBase:flowRelationshipMember>
 <simBase:flowRelationshipMember>
  <op1d2d:BoundaryCondition gml:id="BoundaryCondition119056310079643">
   <gml:description>Manuell erzeugt am: 23.09.2007 17:58</gml:description>
   <gml:name>Abfluss - Zeitreihe</gml:name>
   <simBase:position>
    <gml:Point xmlns:ns1="http://www.w3.org/2001/SMIL20/" xmlns:st="http://www.seegrid.csiro.au/xml/st" xmlns:ns2="http://www.isotc211.org/2005/gmd" xmlns:ns3="http://www.isotc211.org/2005/gco" xmlns:ns4="http://www.isotc211.org/2005/gts" xmlns:ns5="http://www.isotc211.org/2005/gss" xmlns:ns6="http://www.isotc211.org/2005/gsr" xmlns:ns7="http://www.w3.org/2001/SMIL20/Language" srsName="EPSG:31467">
     <gml:coordinates ts="," decimal="." cs=" ">3553518.7470066003 5989132.715850924</gml:coordinates>
    </gml:Point>
   </simBase:position>
   <op1d2d:direction>265</op1d2d:direction>
   <op1d2d:observation>
    <ns8:ObservationWithSource gml:id="ObservationWithSource1190563100796368">
     <gml:name>Abfluss - Zeitreihe</gml:name>
     <om:observedProperty xlink:href="urn:ogc:gml:dict:kalypso:model:1d2d:timeserie:phenomenons#TimeserieBorderCondition1D"/>
     <om:resultDefinition>
      <sweExt:SortedRecordDefinition gml:id="SortedRecordDefinition1190563100796291">
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:1d2d:timeserie:components#Time"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:1d2d:timeserie:components#Discharge"/>
       <sweExt:sortedComponent xlink:href="urn:ogc:gml:dict:kalypso:model:1d2d:timeserie:components#Time"/>
      </sweExt:SortedRecordDefinition>
     </om:resultDefinition>
     <om:result><![CDATA[2007-09-23T00%3A00%3A00.000%2B02%3A00 1.000
2007-09-23T12%3A00%3A00.000%2B02%3A00 1.000
2007-09-24T00%3A00%3A00.000%2B02%3A00 2.000
2007-09-24T12%3A00%3A00.000%2B02%3A00 3.000
2007-09-25T00%3A00%3A00.000%2B02%3A00 4.000
2007-09-25T12%3A00%3A00.000%2B02%3A00 5.000
2007-09-26T00%3A00%3A00.000%2B02%3A00 7.000
2007-09-26T12%3A00%3A00.000%2B02%3A00 9.000
2007-09-27T00%3A00%3A00.000%2B02%3A00 10.000
2007-09-27T12%3A00%3A00.000%2B02%3A00 10
2007-09-28T00%3A00%3A00.000%2B02%3A00 10
2007-09-28T12%3A00%3A00.000%2B02%3A00 10
2007-09-29T00%3A00%3A00.000%2B02%3A00 10
2007-09-29T12%3A00%3A00.000%2B02%3A00 10
2007-09-30T00%3A00%3A00.000%2B02%3A00 10
2007-09-30T12%3A00%3A00.000%2B02%3A00 10
2007-10-01T00%3A00%3A00.000%2B02%3A00 10
2007-10-01T12%3A00%3A00.000%2B02%3A00 10
2007-10-02T00%3A00%3A00.000%2B02%3A00 10
2007-10-02T12%3A00%3A00.000%2B02%3A00 10
2007-10-03T00%3A00%3A00.000%2B02%3A00 10
2007-10-03T12%3A00%3A00.000%2B02%3A00 10
]]></om:result>
     <ns8:dataSourceURI/>
    </ns8:ObservationWithSource>
   </op1d2d:observation>
   <op1d2d:bcType>LINE1D2D</op1d2d:bcType>
   <op1d2d:parentModelElement>ContinuityLine2D119037980860915961</op1d2d:parentModelElement>
   <op1d2d:parentCalculationUnit>CalculationUnit2D119039712104619205</op1d2d:parentCalculationUnit>
   <op1d2d:stationaryCondition>10.0</op1d2d:stationaryCondition>
  </op1d2d:BoundaryCondition>
 </simBase:flowRelationshipMember>
 <simBase:flowRelationshipMember>
  <op1d2d:BoundaryCondition gml:id="BoundaryCondition1190563220625430">
   <gml:description>Manuell erzeugt am: 23.09.2007 18:00</gml:description>
   <gml:name>Abfluss - Zeitreihe</gml:name>
   <simBase:position>
    <gml:Point xmlns:ns1="http://www.w3.org/2001/SMIL20/" xmlns:st="http://www.seegrid.csiro.au/xml/st" xmlns:ns2="http://www.isotc211.org/2005/gmd" xmlns:ns3="http://www.isotc211.org/2005/gco" xmlns:ns4="http://www.isotc211.org/2005/gts" xmlns:ns5="http://www.isotc211.org/2005/gss" xmlns:ns6="http://www.isotc211.org/2005/gsr" xmlns:ns7="http://www.w3.org/2001/SMIL20/Language" srsName="EPSG:31467">
     <gml:coordinates ts="," decimal="." cs=" ">3553934.637694051 5989007.580223504</gml:coordinates>
    </gml:Point>
   </simBase:position>
   <op1d2d:direction>175</op1d2d:direction>
   <op1d2d:observation>
    <ns8:ObservationWithSource gml:id="ObservationWithSource119056322062555">
     <gml:name>Abfluss - Zeitreihe</gml:name>
     <om:observedProperty xlink:href="urn:ogc:gml:dict:kalypso:model:1d2d:timeserie:phenomenons#TimeserieBorderCondition1D"/>
     <om:resultDefinition>
      <sweExt:SortedRecordDefinition gml:id="SortedRecordDefinition1190563220625342">
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:1d2d:timeserie:components#Time"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:1d2d:timeserie:components#Discharge"/>
       <sweExt:sortedComponent xlink:href="urn:ogc:gml:dict:kalypso:model:1d2d:timeserie:components#Time"/>
      </sweExt:SortedRecordDefinition>
     </om:resultDefinition>
     <om:result><![CDATA[2007-09-23T00%3A00%3A00.000%2B02%3A00 1.000
2007-09-23T12%3A00%3A00.000%2B02%3A00 2
2007-09-24T00%3A00%3A00.000%2B02%3A00 3
2007-09-24T12%3A00%3A00.000%2B02%3A00 4
2007-09-25T00%3A00%3A00.000%2B02%3A00 5
2007-09-25T12%3A00%3A00.000%2B02%3A00 7
2007-09-26T00%3A00%3A00.000%2B02%3A00 9
2007-09-26T12%3A00%3A00.000%2B02%3A00 10
2007-09-27T00%3A00%3A00.000%2B02%3A00 10
2007-09-27T12%3A00%3A00.000%2B02%3A00 10
2007-09-28T00%3A00%3A00.000%2B02%3A00 10
2007-09-28T12%3A00%3A00.000%2B02%3A00 10
2007-09-29T00%3A00%3A00.000%2B02%3A00 10
2007-09-29T12%3A00%3A00.000%2B02%3A00 10
2007-09-30T00%3A00%3A00.000%2B02%3A00 10
2007-09-30T12%3A00%3A00.000%2B02%3A00 10
2007-10-01T00%3A00%3A00.000%2B02%3A00 10
2007-10-01T12%3A00%3A00.000%2B02%3A00 10
2007-10-02T00%3A00%3A00.000%2B02%3A00 10
2007-10-02T12%3A00%3A00.000%2B02%3A00 10
2007-10-03T00%3A00%3A00.000%2B02%3A00 10
2007-10-03T12%3A00%3A00.000%2B02%3A00 10
]]></om:result>
     <ns8:dataSourceURI/>
    </ns8:ObservationWithSource>
   </op1d2d:observation>
   <op1d2d:bcType>LINE1D2D</op1d2d:bcType>
   <op1d2d:parentModelElement>ContinuityLine2D119037981192112754</op1d2d:parentModelElement>
   <op1d2d:parentCalculationUnit>CalculationUnit2D119039712104619205</op1d2d:parentCalculationUnit>
   <op1d2d:stationaryCondition>10.0</op1d2d:stationaryCondition>
  </op1d2d:BoundaryCondition>
 </simBase:flowRelationshipMember>
 <simBase:flowRelationshipMember>
  <op1d2d:BoundaryCondition gml:id="BoundaryCondition1190563319125261">
   <gml:description>Manuell erzeugt am: 23.09.2007 18:01</gml:description>
   <gml:name>Wasserstand - Zeitreihe</gml:name>
   <simBase:position>
    <gml:Point xmlns:ns1="http://www.w3.org/2001/SMIL20/" xmlns:st="http://www.seegrid.csiro.au/xml/st" xmlns:ns2="http://www.isotc211.org/2005/gmd" xmlns:ns3="http://www.isotc211.org/2005/gco" xmlns:ns4="http://www.isotc211.org/2005/gts" xmlns:ns5="http://www.isotc211.org/2005/gss" xmlns:ns6="http://www.isotc211.org/2005/gsr" xmlns:ns7="http://www.w3.org/2001/SMIL20/Language" srsName="EPSG:31467">
     <gml:coordinates ts="," decimal="." cs=" ">3553024.6263368544 5987873.016405155</gml:coordinates>
    </gml:Point>
   </simBase:position>
   <op1d2d:direction/>
   <op1d2d:observation>
    <ns8:ObservationWithSource gml:id="ObservationWithSource1190563319125298">
     <gml:name>Wasserstand - Zeitreihe</gml:name>
     <om:observedProperty xlink:href="urn:ogc:gml:dict:kalypso:model:1d2d:timeserie:phenomenons#TimeserieBorderCondition1D"/>
     <om:resultDefinition>
      <sweExt:SortedRecordDefinition gml:id="SortedRecordDefinition119056331914061">
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:1d2d:timeserie:components#Time"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:1d2d:timeserie:components#Waterlevel"/>
       <sweExt:sortedComponent xlink:href="urn:ogc:gml:dict:kalypso:model:1d2d:timeserie:components#Time"/>
      </sweExt:SortedRecordDefinition>
     </om:resultDefinition>
     <om:result><![CDATA[2007-09-23T00%3A00%3A00.000%2B02%3A00 8
2007-09-23T12%3A00%3A00.000%2B02%3A00 7.8
2007-09-24T00%3A00%3A00.000%2B02%3A00 7.6
2007-09-24T12%3A00%3A00.000%2B02%3A00 7.4
2007-09-25T00%3A00%3A00.000%2B02%3A00 7.2
2007-09-25T12%3A00%3A00.000%2B02%3A00 7.0
2007-09-26T00%3A00%3A00.000%2B02%3A00 6.8
2007-09-26T12%3A00%3A00.000%2B02%3A00 6.6
2007-09-27T00%3A00%3A00.000%2B02%3A00 6.4
2007-09-27T12%3A00%3A00.000%2B02%3A00 6.2
2007-09-28T00%3A00%3A00.000%2B02%3A00 6.1
2007-09-28T12%3A00%3A00.000%2B02%3A00 6
2007-09-29T00%3A00%3A00.000%2B02%3A00 5.9
2007-09-29T12%3A00%3A00.000%2B02%3A00 5.8
2007-09-30T00%3A00%3A00.000%2B02%3A00 5.7
2007-09-30T12%3A00%3A00.000%2B02%3A00 5.6
2007-10-01T00%3A00%3A00.000%2B02%3A00 5.5
2007-10-01T12%3A00%3A00.000%2B02%3A00 5.4
2007-10-02T00%3A00%3A00.000%2B02%3A00 5.3
2007-10-02T12%3A00%3A00.000%2B02%3A00 5.2
2007-10-03T00%3A00%3A00.000%2B02%3A00 5.1
2007-10-03T12%3A00%3A00.000%2B02%3A00 5.05
]]></om:result>
     <ns8:dataSourceURI/>
    </ns8:ObservationWithSource>
   </op1d2d:observation>
   <op1d2d:bcType>LINE1D2D</op1d2d:bcType>
   <op1d2d:parentModelElement>ContinuityLine2D119039695454615041</op1d2d:parentModelElement>
   <op1d2d:parentCalculationUnit>CalculationUnit2D119039712104619205</op1d2d:parentCalculationUnit>
   <op1d2d:stationaryCondition>8.4</op1d2d:stationaryCondition>
  </op1d2d:BoundaryCondition>
 </simBase:flowRelationshipMember>
 <simBase:flowRelationshipMember>
  <op1d2d:BoundaryCondition gml:id="BoundaryCondition1190565600828319">
   <gml:description>Manuell erzeugt am: 23.09.2007 18:40</gml:description>
   <gml:name>Wasserstand - Zeitreihe</gml:name>
   <simBase:position>
    <gml:Point xmlns:ns1="http://www.w3.org/2001/SMIL20/" xmlns:st="http://www.seegrid.csiro.au/xml/st" xmlns:ns2="http://www.isotc211.org/2005/gmd" xmlns:ns3="http://www.isotc211.org/2005/gco" xmlns:ns4="http://www.isotc211.org/2005/gts" xmlns:ns5="http://www.isotc211.org/2005/gss" xmlns:ns6="http://www.isotc211.org/2005/gsr" xmlns:ns7="http://www.w3.org/2001/SMIL20/Language" srsName="EPSG:31467">
     <gml:coordinates ts="," decimal="." cs=" ">3553060.039166822 5987851.926068426</gml:coordinates>
    </gml:Point>
   </simBase:position>
   <op1d2d:direction/>
   <op1d2d:observation>
    <ns8:ObservationWithSource gml:id="ObservationWithSource1190565600828278">
     <gml:name>Wasserstand - Zeitreihe</gml:name>
     <om:observedProperty xlink:href="urn:ogc:gml:dict:kalypso:model:1d2d:timeserie:phenomenons#TimeserieBorderCondition1D"/>
     <om:resultDefinition>
      <sweExt:SortedRecordDefinition gml:id="SortedRecordDefinition1190565600828222">
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:1d2d:timeserie:components#Time"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:1d2d:timeserie:components#Waterlevel"/>
       <sweExt:sortedComponent xlink:href="urn:ogc:gml:dict:kalypso:model:1d2d:timeserie:components#Time"/>
      </sweExt:SortedRecordDefinition>
     </om:resultDefinition>
     <om:result><![CDATA[2007-09-23T00%3A00%3A00.000%2B02%3A00 5.05
2007-09-23T12%3A00%3A00.000%2B02%3A00 4.8
2007-09-24T00%3A00%3A00.000%2B02%3A00 4.5
2007-09-24T12%3A00%3A00.000%2B02%3A00 4.2
2007-09-25T00%3A00%3A00.000%2B02%3A00 4.0
2007-09-25T12%3A00%3A00.000%2B02%3A00 3.5
]]></om:result>
     <ns8:dataSourceURI/>
    </ns8:ObservationWithSource>
   </op1d2d:observation>
   <op1d2d:bcType>LINE1D2D</op1d2d:bcType>
   <op1d2d:parentModelElement>ContinuityLine2D119039695454615041</op1d2d:parentModelElement>
   <op1d2d:parentCalculationUnit>CalculationUnit1D2D11905586440935834</op1d2d:parentCalculationUnit>
   <op1d2d:stationaryCondition>5.05</op1d2d:stationaryCondition>
  </op1d2d:BoundaryCondition>
 </simBase:flowRelationshipMember>
 <simBase:flowRelationshipMember>
  <op1d2d:BoundaryCondition gml:id="BoundaryCondition119056563285999">
   <gml:description>Manuell erzeugt am: 23.09.2007 18:40</gml:description>
   <gml:name>Abfluss - Zeitreihe</gml:name>
   <simBase:position>
    <gml:Point xmlns:ns1="http://www.w3.org/2001/SMIL20/" xmlns:st="http://www.seegrid.csiro.au/xml/st" xmlns:ns2="http://www.isotc211.org/2005/gmd" xmlns:ns3="http://www.isotc211.org/2005/gco" xmlns:ns4="http://www.isotc211.org/2005/gts" xmlns:ns5="http://www.isotc211.org/2005/gss" xmlns:ns6="http://www.isotc211.org/2005/gsr" xmlns:ns7="http://www.w3.org/2001/SMIL20/Language" srsName="EPSG:31467">
     <gml:coordinates ts="," decimal="." cs=" ">3553927.841160971 5988968.031866124</gml:coordinates>
    </gml:Point>
   </simBase:position>
   <op1d2d:direction>175</op1d2d:direction>
   <op1d2d:observation>
    <ns8:ObservationWithSource gml:id="ObservationWithSource1190565632859505">
     <gml:name>Abfluss - Zeitreihe</gml:name>
     <om:observedProperty xlink:href="urn:ogc:gml:dict:kalypso:model:1d2d:timeserie:phenomenons#TimeserieBorderCondition1D"/>
     <om:resultDefinition>
      <sweExt:SortedRecordDefinition gml:id="SortedRecordDefinition1190565632859121">
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:1d2d:timeserie:components#Time"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:1d2d:timeserie:components#Discharge"/>
       <sweExt:sortedComponent xlink:href="urn:ogc:gml:dict:kalypso:model:1d2d:timeserie:components#Time"/>
      </sweExt:SortedRecordDefinition>
     </om:resultDefinition>
     <om:result><![CDATA[2007-09-23T00%3A00%3A00.000%2B02%3A00 10
2007-09-23T12%3A00%3A00.000%2B02%3A00 10
2007-09-24T00%3A00%3A00.000%2B02%3A00 10
2007-09-24T12%3A00%3A00.000%2B02%3A00 10
2007-09-25T00%3A00%3A00.000%2B02%3A00 10
]]></om:result>
     <ns8:dataSourceURI/>
    </ns8:ObservationWithSource>
   </op1d2d:observation>
   <op1d2d:bcType>LINE1D2D</op1d2d:bcType>
   <op1d2d:parentModelElement>ContinuityLine2D119037981192112754</op1d2d:parentModelElement>
   <op1d2d:parentCalculationUnit>CalculationUnit1D2D11905586440935834</op1d2d:parentCalculationUnit>
   <op1d2d:parentCalculationUnit>CalculationUnit1D2D119056704167114995</op1d2d:parentCalculationUnit>
   <op1d2d:stationaryCondition>10.0</op1d2d:stationaryCondition>
  </op1d2d:BoundaryCondition>
 </simBase:flowRelationshipMember>
 <simBase:flowRelationshipMember>
  <op1d2d:BoundaryCondition gml:id="BoundaryCondition1190565660218167">
   <gml:description>Manuell erzeugt am: 23.09.2007 18:41</gml:description>
   <gml:name>Abfluss - Zeitreihe</gml:name>
   <simBase:position>
    <gml:Point xmlns:ns1="http://www.w3.org/2001/SMIL20/" xmlns:st="http://www.seegrid.csiro.au/xml/st" xmlns:ns2="http://www.isotc211.org/2005/gmd" xmlns:ns3="http://www.isotc211.org/2005/gco" xmlns:ns4="http://www.isotc211.org/2005/gts" xmlns:ns5="http://www.isotc211.org/2005/gss" xmlns:ns6="http://www.isotc211.org/2005/gsr" xmlns:ns7="http://www.w3.org/2001/SMIL20/Language" srsName="EPSG:31467">
     <gml:coordinates ts="," decimal="." cs=" ">3553523.057259898 5989131.748300801</gml:coordinates>
    </gml:Point>
   </simBase:position>
   <op1d2d:direction>265</op1d2d:direction>
   <op1d2d:observation>
    <ns8:ObservationWithSource gml:id="ObservationWithSource1190565660218340">
     <gml:name>Abfluss - Zeitreihe</gml:name>
     <om:observedProperty xlink:href="urn:ogc:gml:dict:kalypso:model:1d2d:timeserie:phenomenons#TimeserieBorderCondition1D"/>
     <om:resultDefinition>
      <sweExt:SortedRecordDefinition gml:id="SortedRecordDefinition1190565660234285">
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:1d2d:timeserie:components#Time"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:1d2d:timeserie:components#Discharge"/>
       <sweExt:sortedComponent xlink:href="urn:ogc:gml:dict:kalypso:model:1d2d:timeserie:components#Time"/>
      </sweExt:SortedRecordDefinition>
     </om:resultDefinition>
     <om:result><![CDATA[2007-09-23T00%3A00%3A00.000%2B02%3A00 10
2007-09-23T12%3A00%3A00.000%2B02%3A00 10
2007-09-24T00%3A00%3A00.000%2B02%3A00 10
2007-09-24T12%3A00%3A00.000%2B02%3A00 10
2007-09-25T00%3A00%3A00.000%2B02%3A00 10
]]></om:result>
     <ns8:dataSourceURI/>
    </ns8:ObservationWithSource>
   </op1d2d:observation>
   <op1d2d:bcType>LINE1D2D</op1d2d:bcType>
   <op1d2d:parentModelElement>ContinuityLine2D119037980860915961</op1d2d:parentModelElement>
   <op1d2d:parentCalculationUnit>CalculationUnit1D2D11905586440935834</op1d2d:parentCalculationUnit>
   <op1d2d:parentCalculationUnit>CalculationUnit1D2D119056704167114995</op1d2d:parentCalculationUnit>
   <op1d2d:stationaryCondition>10.0</op1d2d:stationaryCondition>
  </op1d2d:BoundaryCondition>
 </simBase:flowRelationshipMember>
 <simBase:flowRelationshipMember>
  <op1d2d:BoundaryCondition gml:id="BoundaryCondition1190567019859273">
   <gml:description>Manuell erzeugt am: 23.09.2007 19:03</gml:description>
   <gml:name>Wasserstand - Zeitreihe</gml:name>
   <simBase:position>
    <gml:Point xmlns:ns1="http://www.w3.org/2001/SMIL20/" xmlns:st="http://www.seegrid.csiro.au/xml/st" xmlns:ns2="http://www.isotc211.org/2005/gmd" xmlns:ns3="http://www.isotc211.org/2005/gco" xmlns:ns4="http://www.isotc211.org/2005/gts" xmlns:ns5="http://www.isotc211.org/2005/gss" xmlns:ns6="http://www.isotc211.org/2005/gsr" xmlns:ns7="http://www.w3.org/2001/SMIL20/Language" srsName="EPSG:31467">
     <gml:coordinates ts="," decimal="." cs=" ">3552962.480788874 5986893.697096109</gml:coordinates>
    </gml:Point>
   </simBase:position>
   <op1d2d:direction/>
   <op1d2d:observation>
    <ns8:ObservationWithSource gml:id="ObservationWithSource1190567019859526">
     <gml:name>Wasserstand - Zeitreihe</gml:name>
     <om:observedProperty xlink:href="urn:ogc:gml:dict:kalypso:model:1d2d:timeserie:phenomenons#TimeserieBorderCondition1D"/>
     <om:resultDefinition>
      <sweExt:SortedRecordDefinition gml:id="SortedRecordDefinition1190567019859462">
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:1d2d:timeserie:components#Time"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:1d2d:timeserie:components#Waterlevel"/>
       <sweExt:sortedComponent xlink:href="urn:ogc:gml:dict:kalypso:model:1d2d:timeserie:components#Time"/>
      </sweExt:SortedRecordDefinition>
     </om:resultDefinition>
     <om:result><![CDATA[2007-09-23T00%3A00%3A00.000%2B02%3A00 4.5
2007-09-23T12%3A00%3A00.000%2B02%3A00 4.5
2007-09-24T00%3A00%3A00.000%2B02%3A00 4.5
2007-09-24T12%3A00%3A00.000%2B02%3A00 4.5
2007-09-25T00%3A00%3A00.000%2B02%3A00 4.5
]]></om:result>
     <ns8:dataSourceURI/>
    </ns8:ObservationWithSource>
   </op1d2d:observation>
   <op1d2d:bcType>LINE1D2D</op1d2d:bcType>
   <op1d2d:parentModelElement>ContinuityLine1D119039693395316574</op1d2d:parentModelElement>
   <op1d2d:parentCalculationUnit>CalculationUnit1D11903971116258141</op1d2d:parentCalculationUnit>
   <op1d2d:parentCalculationUnit>CalculationUnit1D2D119056704167114995</op1d2d:parentCalculationUnit>
   <op1d2d:stationaryCondition>4.5</op1d2d:stationaryCondition>
  </op1d2d:BoundaryCondition>
 </simBase:flowRelationshipMember>
</simBase:FlowRelationshipModel>
