<?xml version="1.0" encoding="WINDOWS-1252"?>
<resultMeta1d2d:ScenarioResultMeta xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:gml="http://www.opengis.net/gml" xmlns:xs="http://www.w3.org/2001/XMLSchema-instance" xmlns:resultMeta1d2d="http://www.tu-harburg.de/wb/kalypso/schemata/1d2dResultMeta" xmlns:commonShp="org.kalypso.gml.common" gml:id="root">
 <gml:name>Ergebnisse</gml:name>
 <resultMeta:path xmlns:resultMeta="http://www.tu-harburg.de/wb/kalypso/schemata/simulationbase/result/meta">results</resultMeta:path>
 <resultMeta:childMember xmlns:resultMeta="http://www.tu-harburg.de/wb/kalypso/schemata/simulationbase/result/meta">
  <resultMeta1d2d:CalculationUnitResultMeta gml:id="CalculationUnitResultMeta1192633013781101">
   <gml:name>Abschnitt_7/8</gml:name>
   <resultMeta:path>CalculationUnit2D119039712104619205</resultMeta:path>
   <resultMeta:childMember>
    <resultMeta1d2d:StepResultMeta gml:id="StepResultMeta119263301381226">
     <gml:description>instation�rer Rechenlauf zum Zeitpunkt: 03.10.2007 14:00:00</gml:description>
     <gml:name>Zeitschritt 21 (03.10.2007 14:00:00)</gml:name>
     <resultMeta:path>timestep-0021</resultMeta:path>
     <resultMeta:childMember>
      <resultMeta1d2d:DocumentResultMeta gml:id="DocumentResultMeta1192633013812184">
       <gml:description>ASCII Ergebnisdatei(en) des RMA10 Rechenkerns</gml:description>
       <gml:name>RMA-Rohdaten</gml:name>
       <resultMeta:path>original.2d.zip</resultMeta:path>
       <resultMeta1d2d:type>coreDataZip</resultMeta1d2d:type>
      </resultMeta1d2d:DocumentResultMeta>
     </resultMeta:childMember>
     <resultMeta:childMember>
      <resultMeta1d2d:DocumentResultMeta gml:id="DocumentResultMeta1192633013812166">
       <gml:description>TIN der Flie�tiefen</gml:description>
       <gml:name>Flie�tiefen</gml:name>
       <resultMeta:path>Tin/tin_DEPTH.gml</resultMeta:path>
       <resultMeta1d2d:type>tinDepth</resultMeta1d2d:type>
       <resultMeta1d2d:minValue>0.000</resultMeta1d2d:minValue>
       <resultMeta1d2d:maxValue>2.445</resultMeta1d2d:maxValue>
      </resultMeta1d2d:DocumentResultMeta>
     </resultMeta:childMember>
     <resultMeta:childMember>
      <resultMeta1d2d:DocumentResultMeta gml:id="DocumentResultMeta119263301381277">
       <gml:description>TIN der Wasserspiegellagen</gml:description>
       <gml:name>Wasserspiegellagen</gml:name>
       <resultMeta:path>Tin/tin_WATERLEVEL.gml</resultMeta:path>
       <resultMeta1d2d:type>tinWsp</resultMeta1d2d:type>
       <resultMeta1d2d:minValue>0.000</resultMeta1d2d:minValue>
       <resultMeta1d2d:maxValue>6.192</resultMeta1d2d:maxValue>
      </resultMeta1d2d:DocumentResultMeta>
     </resultMeta:childMember>
     <resultMeta:childMember>
      <resultMeta1d2d:DocumentResultMeta gml:id="DocumentResultMeta119263301381242">
       <gml:description>TIN der tiefengemittelten Flie�geschwindigkeiten</gml:description>
       <gml:name>Geschwindigkeiten</gml:name>
       <resultMeta:path>Tin/tin_VELOCITY.gml</resultMeta:path>
       <resultMeta1d2d:type>tinVelo</resultMeta1d2d:type>
       <resultMeta1d2d:minValue>0.000</resultMeta1d2d:minValue>
       <resultMeta1d2d:maxValue>1.309</resultMeta1d2d:maxValue>
      </resultMeta1d2d:DocumentResultMeta>
     </resultMeta:childMember>
     <resultMeta:childMember>
      <resultMeta1d2d:DocumentResultMeta gml:id="DocumentResultMeta119263301381246">
       <gml:description>Ergebnisse an den Knoten</gml:description>
       <gml:name>Vektoren</gml:name>
       <resultMeta:path>results.gml</resultMeta:path>
       <resultMeta1d2d:type>nodes</resultMeta1d2d:type>
       <resultMeta1d2d:minValue>0.000</resultMeta1d2d:minValue>
       <resultMeta1d2d:maxValue>1.309</resultMeta1d2d:maxValue>
      </resultMeta1d2d:DocumentResultMeta>
     </resultMeta:childMember>
     <resultMeta1d2d:stepTime>2007-10-03T14:00:00.000+02:00</resultMeta1d2d:stepTime>
     <resultMeta1d2d:stepNumber>21</resultMeta1d2d:stepNumber>
     <resultMeta1d2d:isRestart/>
     <resultMeta1d2d:type>unsteady</resultMeta1d2d:type>
    </resultMeta1d2d:StepResultMeta>
   </resultMeta:childMember>
   <resultMeta1d2d:simulationStartTime>2007-10-17T16:26:29.218+02:00</resultMeta1d2d:simulationStartTime>
   <resultMeta1d2d:simulationEndTime>2007-10-17T16:53:05.828+02:00</resultMeta1d2d:simulationEndTime>
   <resultMeta1d2d:calcUnitID>CalculationUnit2D119039712104619205</resultMeta1d2d:calcUnitID>
  </resultMeta1d2d:CalculationUnitResultMeta>
 </resultMeta:childMember>
</resultMeta1d2d:ScenarioResultMeta>
