<?xml version="1.0" encoding="UTF-8"?>
<resultMeta1d2d:CalculationUnitResultMeta xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:gml="http://www.opengis.net/gml" xmlns:xs="http://www.w3.org/2001/XMLSchema-instance" xmlns:resultMeta1d2d="http://www.tu-harburg.de/wb/kalypso/schemata/1d2dResultMeta" xmlns:commonShp="org.kalypso.gml.common" gml:id="root">
 <gml:description></gml:description>
 <gml:name>Abschnitt_7/8</gml:name>
 <resultMeta:path xmlns:resultMeta="http://www.tu-harburg.de/wb/kalypso/schemata/simulationbase/result/meta">CalculationUnit2D119039712104619205</resultMeta:path>
 <resultMeta:childMember xmlns:resultMeta="http://www.tu-harburg.de/wb/kalypso/schemata/simulationbase/result/meta">
  <resultMeta1d2d:StepResultMeta gml:id="StepResultMeta11926312457181">
   <gml:description>stationärer Rechenlauf</gml:description>
   <gml:name>stationär</gml:name>
   <resultMeta:path>steady</resultMeta:path>
   <resultMeta:childMember>
    <resultMeta1d2d:DocumentResultMeta gml:id="DocumentResultMeta11926312480311">
     <gml:description>ASCII Ergebnisdatei(en) des RMA10 Rechenkerns</gml:description>
     <gml:name>RMA-Rohdaten</gml:name>
     <resultMeta:path>original.2d.zip</resultMeta:path>
     <resultMeta1d2d:type>coreDataZip</resultMeta1d2d:type>
    </resultMeta1d2d:DocumentResultMeta>
   </resultMeta:childMember>
   <resultMeta:childMember>
    <resultMeta1d2d:DocumentResultMeta gml:id="DocumentResultMeta11926312803281">
     <gml:description>TIN der Fließtiefen</gml:description>
     <gml:name>Fließtiefen</gml:name>
     <resultMeta:path>Tin/tin_DEPTH.gml</resultMeta:path>
     <resultMeta1d2d:type>tinDepth</resultMeta1d2d:type>
     <resultMeta1d2d:minValue>0.000</resultMeta1d2d:minValue>
     <resultMeta1d2d:maxValue>5.739</resultMeta1d2d:maxValue>
    </resultMeta1d2d:DocumentResultMeta>
   </resultMeta:childMember>
   <resultMeta:childMember>
    <resultMeta1d2d:DocumentResultMeta gml:id="DocumentResultMeta11926312803282">
     <gml:description>TIN der Wasserspiegellagen</gml:description>
     <gml:name>Wasserspiegellagen</gml:name>
     <resultMeta:path>Tin/tin_WATERLEVEL.gml</resultMeta:path>
     <resultMeta1d2d:type>tinWsp</resultMeta1d2d:type>
     <resultMeta1d2d:minValue>0.000</resultMeta1d2d:minValue>
     <resultMeta1d2d:maxValue>8.469</resultMeta1d2d:maxValue>
    </resultMeta1d2d:DocumentResultMeta>
   </resultMeta:childMember>
   <resultMeta:childMember>
    <resultMeta1d2d:DocumentResultMeta gml:id="DocumentResultMeta11926312803284">
     <gml:description>TIN der tiefengemittelten Fließgeschwindigkeiten</gml:description>
     <gml:name>Geschwindigkeiten</gml:name>
     <resultMeta:path>Tin/tin_VELOCITY.gml</resultMeta:path>
     <resultMeta1d2d:type>tinVelo</resultMeta1d2d:type>
     <resultMeta1d2d:minValue>0.000</resultMeta1d2d:minValue>
     <resultMeta1d2d:maxValue>0.246</resultMeta1d2d:maxValue>
    </resultMeta1d2d:DocumentResultMeta>
   </resultMeta:childMember>
   <resultMeta:childMember>
    <resultMeta1d2d:DocumentResultMeta gml:id="DocumentResultMeta11926312803285">
     <gml:description>Ergebnisse an den Knoten</gml:description>
     <gml:name>Vektoren</gml:name>
     <resultMeta:path>results.gml</resultMeta:path>
     <resultMeta1d2d:type>nodes</resultMeta1d2d:type>
     <resultMeta1d2d:minValue>0.000</resultMeta1d2d:minValue>
     <resultMeta1d2d:maxValue>0.246</resultMeta1d2d:maxValue>
    </resultMeta1d2d:DocumentResultMeta>
   </resultMeta:childMember>
   <resultMeta1d2d:stepTime>2007-09-23T02:00:00.000+02:00</resultMeta1d2d:stepTime>
   <resultMeta1d2d:stepNumber>-1</resultMeta1d2d:stepNumber>
   <resultMeta1d2d:isRestart/>
   <resultMeta1d2d:type>steady</resultMeta1d2d:type>
  </resultMeta1d2d:StepResultMeta>
 </resultMeta:childMember>
 <resultMeta:childMember xmlns:resultMeta="http://www.tu-harburg.de/wb/kalypso/schemata/simulationbase/result/meta">
  <resultMeta1d2d:DocumentResultMeta gml:id="DocumentResultMeta11926312803283">
   <gml:description>TIN der Modellhöhen</gml:description>
   <gml:name>Modellhöhen</gml:name>
   <resultMeta:path>model/Tin/tin_TERRAIN.gml</resultMeta:path>
   <resultMeta1d2d:type>tinTerrain</resultMeta1d2d:type>
   <resultMeta1d2d:minValue>0.000</resultMeta1d2d:minValue>
   <resultMeta1d2d:maxValue>8.396</resultMeta1d2d:maxValue>
  </resultMeta1d2d:DocumentResultMeta>
 </resultMeta:childMember>
 <resultMeta:childMember xmlns:resultMeta="http://www.tu-harburg.de/wb/kalypso/schemata/simulationbase/result/meta">
  <resultMeta1d2d:StepResultMeta gml:id="StepResultMeta11926313239061">
   <gml:description>instationärer Rechenlauf zum Zeitpunkt: 23.09.2007 14:00:00</gml:description>
   <gml:name>Zeitschritt 1 (23.09.2007 14:00:00)</gml:name>
   <resultMeta:path>timestep-0001</resultMeta:path>
   <resultMeta:childMember>
    <resultMeta1d2d:DocumentResultMeta gml:id="DocumentResultMeta11926313288591">
     <gml:description>ASCII Ergebnisdatei(en) des RMA10 Rechenkerns</gml:description>
     <gml:name>RMA-Rohdaten</gml:name>
     <resultMeta:path>original.2d.zip</resultMeta:path>
     <resultMeta1d2d:type>coreDataZip</resultMeta1d2d:type>
    </resultMeta1d2d:DocumentResultMeta>
   </resultMeta:childMember>
   <resultMeta:childMember>
    <resultMeta1d2d:DocumentResultMeta gml:id="DocumentResultMeta11926313580782">
     <gml:description>TIN der Fließtiefen</gml:description>
     <gml:name>Fließtiefen</gml:name>
     <resultMeta:path>Tin/tin_DEPTH.gml</resultMeta:path>
     <resultMeta1d2d:type>tinDepth</resultMeta1d2d:type>
     <resultMeta1d2d:minValue>0.000</resultMeta1d2d:minValue>
     <resultMeta1d2d:maxValue>5.181</resultMeta1d2d:maxValue>
    </resultMeta1d2d:DocumentResultMeta>
   </resultMeta:childMember>
   <resultMeta:childMember>
    <resultMeta1d2d:DocumentResultMeta gml:id="DocumentResultMeta11926313580781">
     <gml:description>TIN der Wasserspiegellagen</gml:description>
     <gml:name>Wasserspiegellagen</gml:name>
     <resultMeta:path>Tin/tin_WATERLEVEL.gml</resultMeta:path>
     <resultMeta1d2d:type>tinWsp</resultMeta1d2d:type>
     <resultMeta1d2d:minValue>0.000</resultMeta1d2d:minValue>
     <resultMeta1d2d:maxValue>7.850</resultMeta1d2d:maxValue>
    </resultMeta1d2d:DocumentResultMeta>
   </resultMeta:childMember>
   <resultMeta:childMember>
    <resultMeta1d2d:DocumentResultMeta gml:id="DocumentResultMeta119263135807810">
     <gml:description>TIN der tiefengemittelten Fließgeschwindigkeiten</gml:description>
     <gml:name>Geschwindigkeiten</gml:name>
     <resultMeta:path>Tin/tin_VELOCITY.gml</resultMeta:path>
     <resultMeta1d2d:type>tinVelo</resultMeta1d2d:type>
     <resultMeta1d2d:minValue>0.000</resultMeta1d2d:minValue>
     <resultMeta1d2d:maxValue>0.429</resultMeta1d2d:maxValue>
    </resultMeta1d2d:DocumentResultMeta>
   </resultMeta:childMember>
   <resultMeta:childMember>
    <resultMeta1d2d:DocumentResultMeta gml:id="DocumentResultMeta11926313580788">
     <gml:description>Ergebnisse an den Knoten</gml:description>
     <gml:name>Vektoren</gml:name>
     <resultMeta:path>results.gml</resultMeta:path>
     <resultMeta1d2d:type>nodes</resultMeta1d2d:type>
     <resultMeta1d2d:minValue>0.000</resultMeta1d2d:minValue>
     <resultMeta1d2d:maxValue>0.429</resultMeta1d2d:maxValue>
    </resultMeta1d2d:DocumentResultMeta>
   </resultMeta:childMember>
   <resultMeta1d2d:stepTime>2007-09-23T14:00:00.000+02:00</resultMeta1d2d:stepTime>
   <resultMeta1d2d:stepNumber>1</resultMeta1d2d:stepNumber>
   <resultMeta1d2d:isRestart/>
   <resultMeta1d2d:type>unsteady</resultMeta1d2d:type>
  </resultMeta1d2d:StepResultMeta>
 </resultMeta:childMember>
 <resultMeta:childMember xmlns:resultMeta="http://www.tu-harburg.de/wb/kalypso/schemata/simulationbase/result/meta">
  <resultMeta1d2d:StepResultMeta gml:id="StepResultMeta11926314114214">
   <gml:description>instationärer Rechenlauf zum Zeitpunkt: 24.09.2007 02:00:00</gml:description>
   <gml:name>Zeitschritt 2 (24.09.2007 02:00:00)</gml:name>
   <resultMeta:path>timestep-0002</resultMeta:path>
   <resultMeta:childMember>
    <resultMeta1d2d:DocumentResultMeta gml:id="DocumentResultMeta11926314228285">
     <gml:description>ASCII Ergebnisdatei(en) des RMA10 Rechenkerns</gml:description>
     <gml:name>RMA-Rohdaten</gml:name>
     <resultMeta:path>original.2d.zip</resultMeta:path>
     <resultMeta1d2d:type>coreDataZip</resultMeta1d2d:type>
    </resultMeta1d2d:DocumentResultMeta>
   </resultMeta:childMember>
   <resultMeta:childMember>
    <resultMeta1d2d:DocumentResultMeta gml:id="DocumentResultMeta11926314521257">
     <gml:description>TIN der Fließtiefen</gml:description>
     <gml:name>Fließtiefen</gml:name>
     <resultMeta:path>Tin/tin_DEPTH.gml</resultMeta:path>
     <resultMeta1d2d:type>tinDepth</resultMeta1d2d:type>
     <resultMeta1d2d:minValue>0.000</resultMeta1d2d:minValue>
     <resultMeta1d2d:maxValue>4.979</resultMeta1d2d:maxValue>
    </resultMeta1d2d:DocumentResultMeta>
   </resultMeta:childMember>
   <resultMeta:childMember>
    <resultMeta1d2d:DocumentResultMeta gml:id="DocumentResultMeta119263145212515">
     <gml:description>TIN der Wasserspiegellagen</gml:description>
     <gml:name>Wasserspiegellagen</gml:name>
     <resultMeta:path>Tin/tin_WATERLEVEL.gml</resultMeta:path>
     <resultMeta1d2d:type>tinWsp</resultMeta1d2d:type>
     <resultMeta1d2d:minValue>0.000</resultMeta1d2d:minValue>
     <resultMeta1d2d:maxValue>7.654</resultMeta1d2d:maxValue>
    </resultMeta1d2d:DocumentResultMeta>
   </resultMeta:childMember>
   <resultMeta:childMember>
    <resultMeta1d2d:DocumentResultMeta gml:id="DocumentResultMeta11926314521252">
     <gml:description>TIN der tiefengemittelten Fließgeschwindigkeiten</gml:description>
     <gml:name>Geschwindigkeiten</gml:name>
     <resultMeta:path>Tin/tin_VELOCITY.gml</resultMeta:path>
     <resultMeta1d2d:type>tinVelo</resultMeta1d2d:type>
     <resultMeta1d2d:minValue>0.000</resultMeta1d2d:minValue>
     <resultMeta1d2d:maxValue>0.484</resultMeta1d2d:maxValue>
    </resultMeta1d2d:DocumentResultMeta>
   </resultMeta:childMember>
   <resultMeta:childMember>
    <resultMeta1d2d:DocumentResultMeta gml:id="DocumentResultMeta11926314521255">
     <gml:description>Ergebnisse an den Knoten</gml:description>
     <gml:name>Vektoren</gml:name>
     <resultMeta:path>results.gml</resultMeta:path>
     <resultMeta1d2d:type>nodes</resultMeta1d2d:type>
     <resultMeta1d2d:minValue>0.000</resultMeta1d2d:minValue>
     <resultMeta1d2d:maxValue>0.484</resultMeta1d2d:maxValue>
    </resultMeta1d2d:DocumentResultMeta>
   </resultMeta:childMember>
   <resultMeta1d2d:stepTime>2007-09-24T02:00:00.000+02:00</resultMeta1d2d:stepTime>
   <resultMeta1d2d:stepNumber>2</resultMeta1d2d:stepNumber>
   <resultMeta1d2d:isRestart/>
   <resultMeta1d2d:type>unsteady</resultMeta1d2d:type>
  </resultMeta1d2d:StepResultMeta>
 </resultMeta:childMember>
 <resultMeta:childMember xmlns:resultMeta="http://www.tu-harburg.de/wb/kalypso/schemata/simulationbase/result/meta">
  <resultMeta1d2d:StepResultMeta gml:id="StepResultMeta11926314924376">
   <gml:description>instationärer Rechenlauf zum Zeitpunkt: 24.09.2007 14:00:00</gml:description>
   <gml:name>Zeitschritt 3 (24.09.2007 14:00:00)</gml:name>
   <resultMeta:path>timestep-0003</resultMeta:path>
   <resultMeta:childMember>
    <resultMeta1d2d:DocumentResultMeta gml:id="DocumentResultMeta119263150437510">
     <gml:description>ASCII Ergebnisdatei(en) des RMA10 Rechenkerns</gml:description>
     <gml:name>RMA-Rohdaten</gml:name>
     <resultMeta:path>original.2d.zip</resultMeta:path>
     <resultMeta1d2d:type>coreDataZip</resultMeta1d2d:type>
    </resultMeta1d2d:DocumentResultMeta>
   </resultMeta:childMember>
   <resultMeta:childMember>
    <resultMeta1d2d:DocumentResultMeta gml:id="DocumentResultMeta11926315327181">
     <gml:description>TIN der Fließtiefen</gml:description>
     <gml:name>Fließtiefen</gml:name>
     <resultMeta:path>Tin/tin_DEPTH.gml</resultMeta:path>
     <resultMeta1d2d:type>tinDepth</resultMeta1d2d:type>
     <resultMeta1d2d:minValue>0.000</resultMeta1d2d:minValue>
     <resultMeta1d2d:maxValue>4.776</resultMeta1d2d:maxValue>
    </resultMeta1d2d:DocumentResultMeta>
   </resultMeta:childMember>
   <resultMeta:childMember>
    <resultMeta1d2d:DocumentResultMeta gml:id="DocumentResultMeta119263153271813">
     <gml:description>TIN der Wasserspiegellagen</gml:description>
     <gml:name>Wasserspiegellagen</gml:name>
     <resultMeta:path>Tin/tin_WATERLEVEL.gml</resultMeta:path>
     <resultMeta1d2d:type>tinWsp</resultMeta1d2d:type>
     <resultMeta1d2d:minValue>0.000</resultMeta1d2d:minValue>
     <resultMeta1d2d:maxValue>7.461</resultMeta1d2d:maxValue>
    </resultMeta1d2d:DocumentResultMeta>
   </resultMeta:childMember>
   <resultMeta:childMember>
    <resultMeta1d2d:DocumentResultMeta gml:id="DocumentResultMeta11926315327188">
     <gml:description>TIN der tiefengemittelten Fließgeschwindigkeiten</gml:description>
     <gml:name>Geschwindigkeiten</gml:name>
     <resultMeta:path>Tin/tin_VELOCITY.gml</resultMeta:path>
     <resultMeta1d2d:type>tinVelo</resultMeta1d2d:type>
     <resultMeta1d2d:minValue>0.000</resultMeta1d2d:minValue>
     <resultMeta1d2d:maxValue>0.372</resultMeta1d2d:maxValue>
    </resultMeta1d2d:DocumentResultMeta>
   </resultMeta:childMember>
   <resultMeta:childMember>
    <resultMeta1d2d:DocumentResultMeta gml:id="DocumentResultMeta119263153271815">
     <gml:description>Ergebnisse an den Knoten</gml:description>
     <gml:name>Vektoren</gml:name>
     <resultMeta:path>results.gml</resultMeta:path>
     <resultMeta1d2d:type>nodes</resultMeta1d2d:type>
     <resultMeta1d2d:minValue>0.000</resultMeta1d2d:minValue>
     <resultMeta1d2d:maxValue>0.372</resultMeta1d2d:maxValue>
    </resultMeta1d2d:DocumentResultMeta>
   </resultMeta:childMember>
   <resultMeta1d2d:stepTime>2007-09-24T14:00:00.000+02:00</resultMeta1d2d:stepTime>
   <resultMeta1d2d:stepNumber>3</resultMeta1d2d:stepNumber>
   <resultMeta1d2d:isRestart/>
   <resultMeta1d2d:type>unsteady</resultMeta1d2d:type>
  </resultMeta1d2d:StepResultMeta>
 </resultMeta:childMember>
 <resultMeta:childMember xmlns:resultMeta="http://www.tu-harburg.de/wb/kalypso/schemata/simulationbase/result/meta">
  <resultMeta1d2d:StepResultMeta gml:id="StepResultMeta11926315992347">
   <gml:description>instationärer Rechenlauf zum Zeitpunkt: 25.09.2007 02:00:00</gml:description>
   <gml:name>Zeitschritt 4 (25.09.2007 02:00:00)</gml:name>
   <resultMeta:path>timestep-0004</resultMeta:path>
   <resultMeta:childMember>
    <resultMeta1d2d:DocumentResultMeta gml:id="DocumentResultMeta119263162168718">
     <gml:description>ASCII Ergebnisdatei(en) des RMA10 Rechenkerns</gml:description>
     <gml:name>RMA-Rohdaten</gml:name>
     <resultMeta:path>original.2d.zip</resultMeta:path>
     <resultMeta1d2d:type>coreDataZip</resultMeta1d2d:type>
    </resultMeta1d2d:DocumentResultMeta>
   </resultMeta:childMember>
   <resultMeta:childMember>
    <resultMeta1d2d:DocumentResultMeta gml:id="DocumentResultMeta11926316501566">
     <gml:description>TIN der Fließtiefen</gml:description>
     <gml:name>Fließtiefen</gml:name>
     <resultMeta:path>Tin/tin_DEPTH.gml</resultMeta:path>
     <resultMeta1d2d:type>tinDepth</resultMeta1d2d:type>
     <resultMeta1d2d:minValue>0.000</resultMeta1d2d:minValue>
     <resultMeta1d2d:maxValue>4.575</resultMeta1d2d:maxValue>
    </resultMeta1d2d:DocumentResultMeta>
   </resultMeta:childMember>
   <resultMeta:childMember>
    <resultMeta1d2d:DocumentResultMeta gml:id="DocumentResultMeta11926316501564">
     <gml:description>TIN der Wasserspiegellagen</gml:description>
     <gml:name>Wasserspiegellagen</gml:name>
     <resultMeta:path>Tin/tin_WATERLEVEL.gml</resultMeta:path>
     <resultMeta1d2d:type>tinWsp</resultMeta1d2d:type>
     <resultMeta1d2d:minValue>0.000</resultMeta1d2d:minValue>
     <resultMeta1d2d:maxValue>7.266</resultMeta1d2d:maxValue>
    </resultMeta1d2d:DocumentResultMeta>
   </resultMeta:childMember>
   <resultMeta:childMember>
    <resultMeta1d2d:DocumentResultMeta gml:id="DocumentResultMeta119263165015621">
     <gml:description>TIN der tiefengemittelten Fließgeschwindigkeiten</gml:description>
     <gml:name>Geschwindigkeiten</gml:name>
     <resultMeta:path>Tin/tin_VELOCITY.gml</resultMeta:path>
     <resultMeta1d2d:type>tinVelo</resultMeta1d2d:type>
     <resultMeta1d2d:minValue>0.000</resultMeta1d2d:minValue>
     <resultMeta1d2d:maxValue>0.415</resultMeta1d2d:maxValue>
    </resultMeta1d2d:DocumentResultMeta>
   </resultMeta:childMember>
   <resultMeta:childMember>
    <resultMeta1d2d:DocumentResultMeta gml:id="DocumentResultMeta119263165015628">
     <gml:description>Ergebnisse an den Knoten</gml:description>
     <gml:name>Vektoren</gml:name>
     <resultMeta:path>results.gml</resultMeta:path>
     <resultMeta1d2d:type>nodes</resultMeta1d2d:type>
     <resultMeta1d2d:minValue>0.000</resultMeta1d2d:minValue>
     <resultMeta1d2d:maxValue>0.415</resultMeta1d2d:maxValue>
    </resultMeta1d2d:DocumentResultMeta>
   </resultMeta:childMember>
   <resultMeta1d2d:stepTime>2007-09-25T02:00:00.000+02:00</resultMeta1d2d:stepTime>
   <resultMeta1d2d:stepNumber>4</resultMeta1d2d:stepNumber>
   <resultMeta1d2d:isRestart/>
   <resultMeta1d2d:type>unsteady</resultMeta1d2d:type>
  </resultMeta1d2d:StepResultMeta>
 </resultMeta:childMember>
 <resultMeta:childMember xmlns:resultMeta="http://www.tu-harburg.de/wb/kalypso/schemata/simulationbase/result/meta">
  <resultMeta1d2d:StepResultMeta gml:id="StepResultMeta119263167793711">
   <gml:description>instationärer Rechenlauf zum Zeitpunkt: 25.09.2007 14:00:00</gml:description>
   <gml:name>Zeitschritt 5 (25.09.2007 14:00:00)</gml:name>
   <resultMeta:path>timestep-0005</resultMeta:path>
   <resultMeta:childMember>
    <resultMeta1d2d:DocumentResultMeta gml:id="DocumentResultMeta119263169596830">
     <gml:description>ASCII Ergebnisdatei(en) des RMA10 Rechenkerns</gml:description>
     <gml:name>RMA-Rohdaten</gml:name>
     <resultMeta:path>original.2d.zip</resultMeta:path>
     <resultMeta1d2d:type>coreDataZip</resultMeta1d2d:type>
    </resultMeta1d2d:DocumentResultMeta>
   </resultMeta:childMember>
   <resultMeta:childMember>
    <resultMeta1d2d:DocumentResultMeta gml:id="DocumentResultMeta11926317249686">
     <gml:description>TIN der Fließtiefen</gml:description>
     <gml:name>Fließtiefen</gml:name>
     <resultMeta:path>Tin/tin_DEPTH.gml</resultMeta:path>
     <resultMeta1d2d:type>tinDepth</resultMeta1d2d:type>
     <resultMeta1d2d:minValue>0.000</resultMeta1d2d:minValue>
     <resultMeta1d2d:maxValue>4.373</resultMeta1d2d:maxValue>
    </resultMeta1d2d:DocumentResultMeta>
   </resultMeta:childMember>
   <resultMeta:childMember>
    <resultMeta1d2d:DocumentResultMeta gml:id="DocumentResultMeta119263172496819">
     <gml:description>TIN der Wasserspiegellagen</gml:description>
     <gml:name>Wasserspiegellagen</gml:name>
     <resultMeta:path>Tin/tin_WATERLEVEL.gml</resultMeta:path>
     <resultMeta1d2d:type>tinWsp</resultMeta1d2d:type>
     <resultMeta1d2d:minValue>0.000</resultMeta1d2d:minValue>
     <resultMeta1d2d:maxValue>7.076</resultMeta1d2d:maxValue>
    </resultMeta1d2d:DocumentResultMeta>
   </resultMeta:childMember>
   <resultMeta:childMember>
    <resultMeta1d2d:DocumentResultMeta gml:id="DocumentResultMeta119263172498426">
     <gml:description>TIN der tiefengemittelten Fließgeschwindigkeiten</gml:description>
     <gml:name>Geschwindigkeiten</gml:name>
     <resultMeta:path>Tin/tin_VELOCITY.gml</resultMeta:path>
     <resultMeta1d2d:type>tinVelo</resultMeta1d2d:type>
     <resultMeta1d2d:minValue>0.000</resultMeta1d2d:minValue>
     <resultMeta1d2d:maxValue>0.809</resultMeta1d2d:maxValue>
    </resultMeta1d2d:DocumentResultMeta>
   </resultMeta:childMember>
   <resultMeta:childMember>
    <resultMeta1d2d:DocumentResultMeta gml:id="DocumentResultMeta119263172498410">
     <gml:description>Ergebnisse an den Knoten</gml:description>
     <gml:name>Vektoren</gml:name>
     <resultMeta:path>results.gml</resultMeta:path>
     <resultMeta1d2d:type>nodes</resultMeta1d2d:type>
     <resultMeta1d2d:minValue>0.000</resultMeta1d2d:minValue>
     <resultMeta1d2d:maxValue>0.809</resultMeta1d2d:maxValue>
    </resultMeta1d2d:DocumentResultMeta>
   </resultMeta:childMember>
   <resultMeta1d2d:stepTime>2007-09-25T14:00:00.000+02:00</resultMeta1d2d:stepTime>
   <resultMeta1d2d:stepNumber>5</resultMeta1d2d:stepNumber>
   <resultMeta1d2d:isRestart/>
   <resultMeta1d2d:type>unsteady</resultMeta1d2d:type>
  </resultMeta1d2d:StepResultMeta>
 </resultMeta:childMember>
 <resultMeta:childMember xmlns:resultMeta="http://www.tu-harburg.de/wb/kalypso/schemata/simulationbase/result/meta">
  <resultMeta1d2d:StepResultMeta gml:id="StepResultMeta119263174798428">
   <gml:description>instationärer Rechenlauf zum Zeitpunkt: 26.09.2007 02:00:00</gml:description>
   <gml:name>Zeitschritt 6 (26.09.2007 02:00:00)</gml:name>
   <resultMeta:path>timestep-0006</resultMeta:path>
   <resultMeta:childMember>
    <resultMeta1d2d:DocumentResultMeta gml:id="DocumentResultMeta11926317675461">
     <gml:description>ASCII Ergebnisdatei(en) des RMA10 Rechenkerns</gml:description>
     <gml:name>RMA-Rohdaten</gml:name>
     <resultMeta:path>original.2d.zip</resultMeta:path>
     <resultMeta1d2d:type>coreDataZip</resultMeta1d2d:type>
    </resultMeta1d2d:DocumentResultMeta>
   </resultMeta:childMember>
   <resultMeta:childMember>
    <resultMeta1d2d:DocumentResultMeta gml:id="DocumentResultMeta119263179759336">
     <gml:description>TIN der Fließtiefen</gml:description>
     <gml:name>Fließtiefen</gml:name>
     <resultMeta:path>Tin/tin_DEPTH.gml</resultMeta:path>
     <resultMeta1d2d:type>tinDepth</resultMeta1d2d:type>
     <resultMeta1d2d:minValue>0.000</resultMeta1d2d:minValue>
     <resultMeta1d2d:maxValue>4.174</resultMeta1d2d:maxValue>
    </resultMeta1d2d:DocumentResultMeta>
   </resultMeta:childMember>
   <resultMeta:childMember>
    <resultMeta1d2d:DocumentResultMeta gml:id="DocumentResultMeta119263179759338">
     <gml:description>TIN der Wasserspiegellagen</gml:description>
     <gml:name>Wasserspiegellagen</gml:name>
     <resultMeta:path>Tin/tin_WATERLEVEL.gml</resultMeta:path>
     <resultMeta1d2d:type>tinWsp</resultMeta1d2d:type>
     <resultMeta1d2d:minValue>0.000</resultMeta1d2d:minValue>
     <resultMeta1d2d:maxValue>6.895</resultMeta1d2d:maxValue>
    </resultMeta1d2d:DocumentResultMeta>
   </resultMeta:childMember>
   <resultMeta:childMember>
    <resultMeta1d2d:DocumentResultMeta gml:id="DocumentResultMeta119263179759313">
     <gml:description>TIN der tiefengemittelten Fließgeschwindigkeiten</gml:description>
     <gml:name>Geschwindigkeiten</gml:name>
     <resultMeta:path>Tin/tin_VELOCITY.gml</resultMeta:path>
     <resultMeta1d2d:type>tinVelo</resultMeta1d2d:type>
     <resultMeta1d2d:minValue>0.000</resultMeta1d2d:minValue>
     <resultMeta1d2d:maxValue>1.472</resultMeta1d2d:maxValue>
    </resultMeta1d2d:DocumentResultMeta>
   </resultMeta:childMember>
   <resultMeta:childMember>
    <resultMeta1d2d:DocumentResultMeta gml:id="DocumentResultMeta119263179759337">
     <gml:description>Ergebnisse an den Knoten</gml:description>
     <gml:name>Vektoren</gml:name>
     <resultMeta:path>results.gml</resultMeta:path>
     <resultMeta1d2d:type>nodes</resultMeta1d2d:type>
     <resultMeta1d2d:minValue>0.000</resultMeta1d2d:minValue>
     <resultMeta1d2d:maxValue>1.472</resultMeta1d2d:maxValue>
    </resultMeta1d2d:DocumentResultMeta>
   </resultMeta:childMember>
   <resultMeta1d2d:stepTime>2007-09-26T02:00:00.000+02:00</resultMeta1d2d:stepTime>
   <resultMeta1d2d:stepNumber>6</resultMeta1d2d:stepNumber>
   <resultMeta1d2d:isRestart/>
   <resultMeta1d2d:type>unsteady</resultMeta1d2d:type>
  </resultMeta1d2d:StepResultMeta>
 </resultMeta:childMember>
 <resultMeta:childMember xmlns:resultMeta="http://www.tu-harburg.de/wb/kalypso/schemata/simulationbase/result/meta">
  <resultMeta1d2d:StepResultMeta gml:id="StepResultMeta119263181551531">
   <gml:description>instationärer Rechenlauf zum Zeitpunkt: 26.09.2007 14:00:00</gml:description>
   <gml:name>Zeitschritt 7 (26.09.2007 14:00:00)</gml:name>
   <resultMeta:path>timestep-0007</resultMeta:path>
   <resultMeta:childMember>
    <resultMeta1d2d:DocumentResultMeta gml:id="DocumentResultMeta119263183732828">
     <gml:description>ASCII Ergebnisdatei(en) des RMA10 Rechenkerns</gml:description>
     <gml:name>RMA-Rohdaten</gml:name>
     <resultMeta:path>original.2d.zip</resultMeta:path>
     <resultMeta1d2d:type>coreDataZip</resultMeta1d2d:type>
    </resultMeta1d2d:DocumentResultMeta>
   </resultMeta:childMember>
   <resultMeta:childMember>
    <resultMeta1d2d:DocumentResultMeta gml:id="DocumentResultMeta119263186670328">
     <gml:description>TIN der Fließtiefen</gml:description>
     <gml:name>Fließtiefen</gml:name>
     <resultMeta:path>Tin/tin_DEPTH.gml</resultMeta:path>
     <resultMeta1d2d:type>tinDepth</resultMeta1d2d:type>
     <resultMeta1d2d:minValue>0.000</resultMeta1d2d:minValue>
     <resultMeta1d2d:maxValue>3.973</resultMeta1d2d:maxValue>
    </resultMeta1d2d:DocumentResultMeta>
   </resultMeta:childMember>
   <resultMeta:childMember>
    <resultMeta1d2d:DocumentResultMeta gml:id="DocumentResultMeta119263186670318">
     <gml:description>TIN der Wasserspiegellagen</gml:description>
     <gml:name>Wasserspiegellagen</gml:name>
     <resultMeta:path>Tin/tin_WATERLEVEL.gml</resultMeta:path>
     <resultMeta1d2d:type>tinWsp</resultMeta1d2d:type>
     <resultMeta1d2d:minValue>0.000</resultMeta1d2d:minValue>
     <resultMeta1d2d:maxValue>6.719</resultMeta1d2d:maxValue>
    </resultMeta1d2d:DocumentResultMeta>
   </resultMeta:childMember>
   <resultMeta:childMember>
    <resultMeta1d2d:DocumentResultMeta gml:id="DocumentResultMeta11926318667037">
     <gml:description>TIN der tiefengemittelten Fließgeschwindigkeiten</gml:description>
     <gml:name>Geschwindigkeiten</gml:name>
     <resultMeta:path>Tin/tin_VELOCITY.gml</resultMeta:path>
     <resultMeta1d2d:type>tinVelo</resultMeta1d2d:type>
     <resultMeta1d2d:minValue>0.000</resultMeta1d2d:minValue>
     <resultMeta1d2d:maxValue>2.176</resultMeta1d2d:maxValue>
    </resultMeta1d2d:DocumentResultMeta>
   </resultMeta:childMember>
   <resultMeta:childMember>
    <resultMeta1d2d:DocumentResultMeta gml:id="DocumentResultMeta119263186670312">
     <gml:description>Ergebnisse an den Knoten</gml:description>
     <gml:name>Vektoren</gml:name>
     <resultMeta:path>results.gml</resultMeta:path>
     <resultMeta1d2d:type>nodes</resultMeta1d2d:type>
     <resultMeta1d2d:minValue>0.000</resultMeta1d2d:minValue>
     <resultMeta1d2d:maxValue>2.176</resultMeta1d2d:maxValue>
    </resultMeta1d2d:DocumentResultMeta>
   </resultMeta:childMember>
   <resultMeta1d2d:stepTime>2007-09-26T14:00:00.000+02:00</resultMeta1d2d:stepTime>
   <resultMeta1d2d:stepNumber>7</resultMeta1d2d:stepNumber>
   <resultMeta1d2d:isRestart/>
   <resultMeta1d2d:type>unsteady</resultMeta1d2d:type>
  </resultMeta1d2d:StepResultMeta>
 </resultMeta:childMember>
 <resultMeta:childMember xmlns:resultMeta="http://www.tu-harburg.de/wb/kalypso/schemata/simulationbase/result/meta">
  <resultMeta1d2d:StepResultMeta gml:id="StepResultMeta119263187382833">
   <gml:description>instationärer Rechenlauf zum Zeitpunkt: 27.09.2007 02:00:00</gml:description>
   <gml:name>Zeitschritt 8 (27.09.2007 02:00:00)</gml:name>
   <resultMeta:path>timestep-0008</resultMeta:path>
   <resultMeta:childMember>
    <resultMeta1d2d:DocumentResultMeta gml:id="DocumentResultMeta119263189853123">
     <gml:description>ASCII Ergebnisdatei(en) des RMA10 Rechenkerns</gml:description>
     <gml:name>RMA-Rohdaten</gml:name>
     <resultMeta:path>original.2d.zip</resultMeta:path>
     <resultMeta1d2d:type>coreDataZip</resultMeta1d2d:type>
    </resultMeta1d2d:DocumentResultMeta>
   </resultMeta:childMember>
   <resultMeta:childMember>
    <resultMeta1d2d:DocumentResultMeta gml:id="DocumentResultMeta119263192809338">
     <gml:description>TIN der Fließtiefen</gml:description>
     <gml:name>Fließtiefen</gml:name>
     <resultMeta:path>Tin/tin_DEPTH.gml</resultMeta:path>
     <resultMeta1d2d:type>tinDepth</resultMeta1d2d:type>
     <resultMeta1d2d:minValue>0.000</resultMeta1d2d:minValue>
     <resultMeta1d2d:maxValue>3.767</resultMeta1d2d:maxValue>
    </resultMeta1d2d:DocumentResultMeta>
   </resultMeta:childMember>
   <resultMeta:childMember>
    <resultMeta1d2d:DocumentResultMeta gml:id="DocumentResultMeta119263192809324">
     <gml:description>TIN der Wasserspiegellagen</gml:description>
     <gml:name>Wasserspiegellagen</gml:name>
     <resultMeta:path>Tin/tin_WATERLEVEL.gml</resultMeta:path>
     <resultMeta1d2d:type>tinWsp</resultMeta1d2d:type>
     <resultMeta1d2d:minValue>0.000</resultMeta1d2d:minValue>
     <resultMeta1d2d:maxValue>6.540</resultMeta1d2d:maxValue>
    </resultMeta1d2d:DocumentResultMeta>
   </resultMeta:childMember>
   <resultMeta:childMember>
    <resultMeta1d2d:DocumentResultMeta gml:id="DocumentResultMeta119263192809351">
     <gml:description>TIN der tiefengemittelten Fließgeschwindigkeiten</gml:description>
     <gml:name>Geschwindigkeiten</gml:name>
     <resultMeta:path>Tin/tin_VELOCITY.gml</resultMeta:path>
     <resultMeta1d2d:type>tinVelo</resultMeta1d2d:type>
     <resultMeta1d2d:minValue>0.000</resultMeta1d2d:minValue>
     <resultMeta1d2d:maxValue>0.514</resultMeta1d2d:maxValue>
    </resultMeta1d2d:DocumentResultMeta>
   </resultMeta:childMember>
   <resultMeta:childMember>
    <resultMeta1d2d:DocumentResultMeta gml:id="DocumentResultMeta119263192809347">
     <gml:description>Ergebnisse an den Knoten</gml:description>
     <gml:name>Vektoren</gml:name>
     <resultMeta:path>results.gml</resultMeta:path>
     <resultMeta1d2d:type>nodes</resultMeta1d2d:type>
     <resultMeta1d2d:minValue>0.000</resultMeta1d2d:minValue>
     <resultMeta1d2d:maxValue>0.514</resultMeta1d2d:maxValue>
    </resultMeta1d2d:DocumentResultMeta>
   </resultMeta:childMember>
   <resultMeta1d2d:stepTime>2007-09-27T02:00:00.000+02:00</resultMeta1d2d:stepTime>
   <resultMeta1d2d:stepNumber>8</resultMeta1d2d:stepNumber>
   <resultMeta1d2d:isRestart/>
   <resultMeta1d2d:type>unsteady</resultMeta1d2d:type>
  </resultMeta1d2d:StepResultMeta>
 </resultMeta:childMember>
 <resultMeta:childMember xmlns:resultMeta="http://www.tu-harburg.de/wb/kalypso/schemata/simulationbase/result/meta">
  <resultMeta1d2d:StepResultMeta gml:id="StepResultMeta11926319350783">
   <gml:description>instationärer Rechenlauf zum Zeitpunkt: 27.09.2007 14:00:00</gml:description>
   <gml:name>Zeitschritt 9 (27.09.2007 14:00:00)</gml:name>
   <resultMeta:path>timestep-0009</resultMeta:path>
   <resultMeta:childMember>
    <resultMeta1d2d:DocumentResultMeta gml:id="DocumentResultMeta119263196334323">
     <gml:description>ASCII Ergebnisdatei(en) des RMA10 Rechenkerns</gml:description>
     <gml:name>RMA-Rohdaten</gml:name>
     <resultMeta:path>original.2d.zip</resultMeta:path>
     <resultMeta1d2d:type>coreDataZip</resultMeta1d2d:type>
    </resultMeta1d2d:DocumentResultMeta>
   </resultMeta:childMember>
   <resultMeta:childMember>
    <resultMeta1d2d:DocumentResultMeta gml:id="DocumentResultMeta119263199743748">
     <gml:description>TIN der Fließtiefen</gml:description>
     <gml:name>Fließtiefen</gml:name>
     <resultMeta:path>Tin/tin_DEPTH.gml</resultMeta:path>
     <resultMeta1d2d:type>tinDepth</resultMeta1d2d:type>
     <resultMeta1d2d:minValue>0.000</resultMeta1d2d:minValue>
     <resultMeta1d2d:maxValue>3.566</resultMeta1d2d:maxValue>
    </resultMeta1d2d:DocumentResultMeta>
   </resultMeta:childMember>
   <resultMeta:childMember>
    <resultMeta1d2d:DocumentResultMeta gml:id="DocumentResultMeta119263199743720">
     <gml:description>TIN der Wasserspiegellagen</gml:description>
     <gml:name>Wasserspiegellagen</gml:name>
     <resultMeta:path>Tin/tin_WATERLEVEL.gml</resultMeta:path>
     <resultMeta1d2d:type>tinWsp</resultMeta1d2d:type>
     <resultMeta1d2d:minValue>0.000</resultMeta1d2d:minValue>
     <resultMeta1d2d:maxValue>6.496</resultMeta1d2d:maxValue>
    </resultMeta1d2d:DocumentResultMeta>
   </resultMeta:childMember>
   <resultMeta:childMember>
    <resultMeta1d2d:DocumentResultMeta gml:id="DocumentResultMeta119263199743736">
     <gml:description>TIN der tiefengemittelten Fließgeschwindigkeiten</gml:description>
     <gml:name>Geschwindigkeiten</gml:name>
     <resultMeta:path>Tin/tin_VELOCITY.gml</resultMeta:path>
     <resultMeta1d2d:type>tinVelo</resultMeta1d2d:type>
     <resultMeta1d2d:minValue>0.000</resultMeta1d2d:minValue>
     <resultMeta1d2d:maxValue>0.753</resultMeta1d2d:maxValue>
    </resultMeta1d2d:DocumentResultMeta>
   </resultMeta:childMember>
   <resultMeta:childMember>
    <resultMeta1d2d:DocumentResultMeta gml:id="DocumentResultMeta119263199743715">
     <gml:description>Ergebnisse an den Knoten</gml:description>
     <gml:name>Vektoren</gml:name>
     <resultMeta:path>results.gml</resultMeta:path>
     <resultMeta1d2d:type>nodes</resultMeta1d2d:type>
     <resultMeta1d2d:minValue>0.000</resultMeta1d2d:minValue>
     <resultMeta1d2d:maxValue>0.753</resultMeta1d2d:maxValue>
    </resultMeta1d2d:DocumentResultMeta>
   </resultMeta:childMember>
   <resultMeta1d2d:stepTime>2007-09-27T14:00:00.000+02:00</resultMeta1d2d:stepTime>
   <resultMeta1d2d:stepNumber>9</resultMeta1d2d:stepNumber>
   <resultMeta1d2d:isRestart/>
   <resultMeta1d2d:type>unsteady</resultMeta1d2d:type>
  </resultMeta1d2d:StepResultMeta>
 </resultMeta:childMember>
 <resultMeta:childMember xmlns:resultMeta="http://www.tu-harburg.de/wb/kalypso/schemata/simulationbase/result/meta">
  <resultMeta1d2d:StepResultMeta gml:id="StepResultMeta119263197125044">
   <gml:description>instationärer Rechenlauf zum Zeitpunkt: 28.09.2007 02:00:00</gml:description>
   <gml:name>Zeitschritt 10 (28.09.2007 02:00:00)</gml:name>
   <resultMeta:path>timestep-0010</resultMeta:path>
   <resultMeta:childMember>
    <resultMeta1d2d:DocumentResultMeta gml:id="DocumentResultMeta119263202840627">
     <gml:description>ASCII Ergebnisdatei(en) des RMA10 Rechenkerns</gml:description>
     <gml:name>RMA-Rohdaten</gml:name>
     <resultMeta:path>original.2d.zip</resultMeta:path>
     <resultMeta1d2d:type>coreDataZip</resultMeta1d2d:type>
    </resultMeta1d2d:DocumentResultMeta>
   </resultMeta:childMember>
   <resultMeta:childMember>
    <resultMeta1d2d:DocumentResultMeta gml:id="DocumentResultMeta119263206000031">
     <gml:description>TIN der Fließtiefen</gml:description>
     <gml:name>Fließtiefen</gml:name>
     <resultMeta:path>Tin/tin_DEPTH.gml</resultMeta:path>
     <resultMeta1d2d:type>tinDepth</resultMeta1d2d:type>
     <resultMeta1d2d:minValue>0.000</resultMeta1d2d:minValue>
     <resultMeta1d2d:maxValue>3.465</resultMeta1d2d:maxValue>
    </resultMeta1d2d:DocumentResultMeta>
   </resultMeta:childMember>
   <resultMeta:childMember>
    <resultMeta1d2d:DocumentResultMeta gml:id="DocumentResultMeta11926320600008">
     <gml:description>TIN der Wasserspiegellagen</gml:description>
     <gml:name>Wasserspiegellagen</gml:name>
     <resultMeta:path>Tin/tin_WATERLEVEL.gml</resultMeta:path>
     <resultMeta1d2d:type>tinWsp</resultMeta1d2d:type>
     <resultMeta1d2d:minValue>0.000</resultMeta1d2d:minValue>
     <resultMeta1d2d:maxValue>6.482</resultMeta1d2d:maxValue>
    </resultMeta1d2d:DocumentResultMeta>
   </resultMeta:childMember>
   <resultMeta:childMember>
    <resultMeta1d2d:DocumentResultMeta gml:id="DocumentResultMeta119263206000043">
     <gml:description>TIN der tiefengemittelten Fließgeschwindigkeiten</gml:description>
     <gml:name>Geschwindigkeiten</gml:name>
     <resultMeta:path>Tin/tin_VELOCITY.gml</resultMeta:path>
     <resultMeta1d2d:type>tinVelo</resultMeta1d2d:type>
     <resultMeta1d2d:minValue>0.000</resultMeta1d2d:minValue>
     <resultMeta1d2d:maxValue>0.744</resultMeta1d2d:maxValue>
    </resultMeta1d2d:DocumentResultMeta>
   </resultMeta:childMember>
   <resultMeta:childMember>
    <resultMeta1d2d:DocumentResultMeta gml:id="DocumentResultMeta119263206000053">
     <gml:description>Ergebnisse an den Knoten</gml:description>
     <gml:name>Vektoren</gml:name>
     <resultMeta:path>results.gml</resultMeta:path>
     <resultMeta1d2d:type>nodes</resultMeta1d2d:type>
     <resultMeta1d2d:minValue>0.000</resultMeta1d2d:minValue>
     <resultMeta1d2d:maxValue>0.744</resultMeta1d2d:maxValue>
    </resultMeta1d2d:DocumentResultMeta>
   </resultMeta:childMember>
   <resultMeta1d2d:stepTime>2007-09-28T02:00:00.000+02:00</resultMeta1d2d:stepTime>
   <resultMeta1d2d:stepNumber>10</resultMeta1d2d:stepNumber>
   <resultMeta1d2d:isRestart/>
   <resultMeta1d2d:type>unsteady</resultMeta1d2d:type>
  </resultMeta1d2d:StepResultMeta>
 </resultMeta:childMember>
 <resultMeta:childMember xmlns:resultMeta="http://www.tu-harburg.de/wb/kalypso/schemata/simulationbase/result/meta">
  <resultMeta1d2d:StepResultMeta gml:id="StepResultMeta119263201143751">
   <gml:description>instationärer Rechenlauf zum Zeitpunkt: 28.09.2007 14:00:00</gml:description>
   <gml:name>Zeitschritt 11 (28.09.2007 14:00:00)</gml:name>
   <resultMeta:path>timestep-0011</resultMeta:path>
   <resultMeta:childMember>
    <resultMeta1d2d:DocumentResultMeta gml:id="DocumentResultMeta119263209665661">
     <gml:description>ASCII Ergebnisdatei(en) des RMA10 Rechenkerns</gml:description>
     <gml:name>RMA-Rohdaten</gml:name>
     <resultMeta:path>original.2d.zip</resultMeta:path>
     <resultMeta1d2d:type>coreDataZip</resultMeta1d2d:type>
    </resultMeta1d2d:DocumentResultMeta>
   </resultMeta:childMember>
   <resultMeta:childMember>
    <resultMeta1d2d:DocumentResultMeta gml:id="DocumentResultMeta11926321335316">
     <gml:description>TIN der Fließtiefen</gml:description>
     <gml:name>Fließtiefen</gml:name>
     <resultMeta:path>Tin/tin_DEPTH.gml</resultMeta:path>
     <resultMeta1d2d:type>tinDepth</resultMeta1d2d:type>
     <resultMeta1d2d:minValue>0.000</resultMeta1d2d:minValue>
     <resultMeta1d2d:maxValue>3.366</resultMeta1d2d:maxValue>
    </resultMeta1d2d:DocumentResultMeta>
   </resultMeta:childMember>
   <resultMeta:childMember>
    <resultMeta1d2d:DocumentResultMeta gml:id="DocumentResultMeta119263213353151">
     <gml:description>TIN der Wasserspiegellagen</gml:description>
     <gml:name>Wasserspiegellagen</gml:name>
     <resultMeta:path>Tin/tin_WATERLEVEL.gml</resultMeta:path>
     <resultMeta1d2d:type>tinWsp</resultMeta1d2d:type>
     <resultMeta1d2d:minValue>0.000</resultMeta1d2d:minValue>
     <resultMeta1d2d:maxValue>6.421</resultMeta1d2d:maxValue>
    </resultMeta1d2d:DocumentResultMeta>
   </resultMeta:childMember>
   <resultMeta:childMember>
    <resultMeta1d2d:DocumentResultMeta gml:id="DocumentResultMeta119263213353145">
     <gml:description>TIN der tiefengemittelten Fließgeschwindigkeiten</gml:description>
     <gml:name>Geschwindigkeiten</gml:name>
     <resultMeta:path>Tin/tin_VELOCITY.gml</resultMeta:path>
     <resultMeta1d2d:type>tinVelo</resultMeta1d2d:type>
     <resultMeta1d2d:minValue>0.000</resultMeta1d2d:minValue>
     <resultMeta1d2d:maxValue>0.827</resultMeta1d2d:maxValue>
    </resultMeta1d2d:DocumentResultMeta>
   </resultMeta:childMember>
   <resultMeta:childMember>
    <resultMeta1d2d:DocumentResultMeta gml:id="DocumentResultMeta119263213353114">
     <gml:description>Ergebnisse an den Knoten</gml:description>
     <gml:name>Vektoren</gml:name>
     <resultMeta:path>results.gml</resultMeta:path>
     <resultMeta1d2d:type>nodes</resultMeta1d2d:type>
     <resultMeta1d2d:minValue>0.000</resultMeta1d2d:minValue>
     <resultMeta1d2d:maxValue>0.827</resultMeta1d2d:maxValue>
    </resultMeta1d2d:DocumentResultMeta>
   </resultMeta:childMember>
   <resultMeta1d2d:stepTime>2007-09-28T14:00:00.000+02:00</resultMeta1d2d:stepTime>
   <resultMeta1d2d:stepNumber>11</resultMeta1d2d:stepNumber>
   <resultMeta1d2d:isRestart/>
   <resultMeta1d2d:type>unsteady</resultMeta1d2d:type>
  </resultMeta1d2d:StepResultMeta>
 </resultMeta:childMember>
 <resultMeta:childMember xmlns:resultMeta="http://www.tu-harburg.de/wb/kalypso/schemata/simulationbase/result/meta">
  <resultMeta1d2d:StepResultMeta gml:id="StepResultMeta119263203735923">
   <gml:description>instationärer Rechenlauf zum Zeitpunkt: 29.09.2007 02:00:00</gml:description>
   <gml:name>Zeitschritt 12 (29.09.2007 02:00:00)</gml:name>
   <resultMeta:path>timestep-0012</resultMeta:path>
   <resultMeta:childMember>
    <resultMeta1d2d:DocumentResultMeta gml:id="DocumentResultMeta119263218967175">
     <gml:description>ASCII Ergebnisdatei(en) des RMA10 Rechenkerns</gml:description>
     <gml:name>RMA-Rohdaten</gml:name>
     <resultMeta:path>original.2d.zip</resultMeta:path>
     <resultMeta1d2d:type>coreDataZip</resultMeta1d2d:type>
    </resultMeta1d2d:DocumentResultMeta>
   </resultMeta:childMember>
   <resultMeta:childMember>
    <resultMeta1d2d:DocumentResultMeta gml:id="DocumentResultMeta119263221253130">
     <gml:description>TIN der Fließtiefen</gml:description>
     <gml:name>Fließtiefen</gml:name>
     <resultMeta:path>Tin/tin_DEPTH.gml</resultMeta:path>
     <resultMeta1d2d:type>tinDepth</resultMeta1d2d:type>
     <resultMeta1d2d:minValue>0.000</resultMeta1d2d:minValue>
     <resultMeta1d2d:maxValue>3.265</resultMeta1d2d:maxValue>
    </resultMeta1d2d:DocumentResultMeta>
   </resultMeta:childMember>
   <resultMeta:childMember>
    <resultMeta1d2d:DocumentResultMeta gml:id="DocumentResultMeta119263221253120">
     <gml:description>TIN der Wasserspiegellagen</gml:description>
     <gml:name>Wasserspiegellagen</gml:name>
     <resultMeta:path>Tin/tin_WATERLEVEL.gml</resultMeta:path>
     <resultMeta1d2d:type>tinWsp</resultMeta1d2d:type>
     <resultMeta1d2d:minValue>0.000</resultMeta1d2d:minValue>
     <resultMeta1d2d:maxValue>6.441</resultMeta1d2d:maxValue>
    </resultMeta1d2d:DocumentResultMeta>
   </resultMeta:childMember>
   <resultMeta:childMember>
    <resultMeta1d2d:DocumentResultMeta gml:id="DocumentResultMeta119263221253167">
     <gml:description>TIN der tiefengemittelten Fließgeschwindigkeiten</gml:description>
     <gml:name>Geschwindigkeiten</gml:name>
     <resultMeta:path>Tin/tin_VELOCITY.gml</resultMeta:path>
     <resultMeta1d2d:type>tinVelo</resultMeta1d2d:type>
     <resultMeta1d2d:minValue>0.000</resultMeta1d2d:minValue>
     <resultMeta1d2d:maxValue>0.824</resultMeta1d2d:maxValue>
    </resultMeta1d2d:DocumentResultMeta>
   </resultMeta:childMember>
   <resultMeta:childMember>
    <resultMeta1d2d:DocumentResultMeta gml:id="DocumentResultMeta119263221253182">
     <gml:description>Ergebnisse an den Knoten</gml:description>
     <gml:name>Vektoren</gml:name>
     <resultMeta:path>results.gml</resultMeta:path>
     <resultMeta1d2d:type>nodes</resultMeta1d2d:type>
     <resultMeta1d2d:minValue>0.000</resultMeta1d2d:minValue>
     <resultMeta1d2d:maxValue>0.824</resultMeta1d2d:maxValue>
    </resultMeta1d2d:DocumentResultMeta>
   </resultMeta:childMember>
   <resultMeta1d2d:stepTime>2007-09-29T02:00:00.000+02:00</resultMeta1d2d:stepTime>
   <resultMeta1d2d:stepNumber>12</resultMeta1d2d:stepNumber>
   <resultMeta1d2d:isRestart/>
   <resultMeta1d2d:type>unsteady</resultMeta1d2d:type>
  </resultMeta1d2d:StepResultMeta>
 </resultMeta:childMember>
 <resultMeta:childMember xmlns:resultMeta="http://www.tu-harburg.de/wb/kalypso/schemata/simulationbase/result/meta">
  <resultMeta1d2d:StepResultMeta gml:id="StepResultMeta119263206675052">
   <gml:description>instationärer Rechenlauf zum Zeitpunkt: 29.09.2007 14:00:00</gml:description>
   <gml:name>Zeitschritt 13 (29.09.2007 14:00:00)</gml:name>
   <resultMeta:path>timestep-0013</resultMeta:path>
   <resultMeta:childMember>
    <resultMeta1d2d:DocumentResultMeta gml:id="DocumentResultMeta119263225007819">
     <gml:description>ASCII Ergebnisdatei(en) des RMA10 Rechenkerns</gml:description>
     <gml:name>RMA-Rohdaten</gml:name>
     <resultMeta:path>original.2d.zip</resultMeta:path>
     <resultMeta1d2d:type>coreDataZip</resultMeta1d2d:type>
    </resultMeta1d2d:DocumentResultMeta>
   </resultMeta:childMember>
   <resultMeta:childMember>
    <resultMeta1d2d:DocumentResultMeta gml:id="DocumentResultMeta11926322831404">
     <gml:description>TIN der Fließtiefen</gml:description>
     <gml:name>Fließtiefen</gml:name>
     <resultMeta:path>Tin/tin_DEPTH.gml</resultMeta:path>
     <resultMeta1d2d:type>tinDepth</resultMeta1d2d:type>
     <resultMeta1d2d:minValue>0.000</resultMeta1d2d:minValue>
     <resultMeta1d2d:maxValue>3.166</resultMeta1d2d:maxValue>
    </resultMeta1d2d:DocumentResultMeta>
   </resultMeta:childMember>
   <resultMeta:childMember>
    <resultMeta1d2d:DocumentResultMeta gml:id="DocumentResultMeta119263228314063">
     <gml:description>TIN der Wasserspiegellagen</gml:description>
     <gml:name>Wasserspiegellagen</gml:name>
     <resultMeta:path>Tin/tin_WATERLEVEL.gml</resultMeta:path>
     <resultMeta1d2d:type>tinWsp</resultMeta1d2d:type>
     <resultMeta1d2d:minValue>0.000</resultMeta1d2d:minValue>
     <resultMeta1d2d:maxValue>6.388</resultMeta1d2d:maxValue>
    </resultMeta1d2d:DocumentResultMeta>
   </resultMeta:childMember>
   <resultMeta:childMember>
    <resultMeta1d2d:DocumentResultMeta gml:id="DocumentResultMeta119263228314018">
     <gml:description>TIN der tiefengemittelten Fließgeschwindigkeiten</gml:description>
     <gml:name>Geschwindigkeiten</gml:name>
     <resultMeta:path>Tin/tin_VELOCITY.gml</resultMeta:path>
     <resultMeta1d2d:type>tinVelo</resultMeta1d2d:type>
     <resultMeta1d2d:minValue>0.000</resultMeta1d2d:minValue>
     <resultMeta1d2d:maxValue>0.891</resultMeta1d2d:maxValue>
    </resultMeta1d2d:DocumentResultMeta>
   </resultMeta:childMember>
   <resultMeta:childMember>
    <resultMeta1d2d:DocumentResultMeta gml:id="DocumentResultMeta119263228314031">
     <gml:description>Ergebnisse an den Knoten</gml:description>
     <gml:name>Vektoren</gml:name>
     <resultMeta:path>results.gml</resultMeta:path>
     <resultMeta1d2d:type>nodes</resultMeta1d2d:type>
     <resultMeta1d2d:minValue>0.000</resultMeta1d2d:minValue>
     <resultMeta1d2d:maxValue>0.891</resultMeta1d2d:maxValue>
    </resultMeta1d2d:DocumentResultMeta>
   </resultMeta:childMember>
   <resultMeta1d2d:stepTime>2007-09-29T14:00:00.000+02:00</resultMeta1d2d:stepTime>
   <resultMeta1d2d:stepNumber>13</resultMeta1d2d:stepNumber>
   <resultMeta1d2d:isRestart/>
   <resultMeta1d2d:type>unsteady</resultMeta1d2d:type>
  </resultMeta1d2d:StepResultMeta>
 </resultMeta:childMember>
 <resultMeta:childMember xmlns:resultMeta="http://www.tu-harburg.de/wb/kalypso/schemata/simulationbase/result/meta">
  <resultMeta1d2d:StepResultMeta gml:id="StepResultMeta119263208650069">
   <gml:description>instationärer Rechenlauf zum Zeitpunkt: 30.09.2007 02:00:00</gml:description>
   <gml:name>Zeitschritt 14 (30.09.2007 02:00:00)</gml:name>
   <resultMeta:path>timestep-0014</resultMeta:path>
   <resultMeta:childMember>
    <resultMeta1d2d:DocumentResultMeta gml:id="DocumentResultMeta119263232264091">
     <gml:description>ASCII Ergebnisdatei(en) des RMA10 Rechenkerns</gml:description>
     <gml:name>RMA-Rohdaten</gml:name>
     <resultMeta:path>original.2d.zip</resultMeta:path>
     <resultMeta1d2d:type>coreDataZip</resultMeta1d2d:type>
    </resultMeta1d2d:DocumentResultMeta>
   </resultMeta:childMember>
   <resultMeta:childMember>
    <resultMeta1d2d:DocumentResultMeta gml:id="DocumentResultMeta119263234648441">
     <gml:description>TIN der Fließtiefen</gml:description>
     <gml:name>Fließtiefen</gml:name>
     <resultMeta:path>Tin/tin_DEPTH.gml</resultMeta:path>
     <resultMeta1d2d:type>tinDepth</resultMeta1d2d:type>
     <resultMeta1d2d:minValue>0.000</resultMeta1d2d:minValue>
     <resultMeta1d2d:maxValue>3.068</resultMeta1d2d:maxValue>
    </resultMeta1d2d:DocumentResultMeta>
   </resultMeta:childMember>
   <resultMeta:childMember>
    <resultMeta1d2d:DocumentResultMeta gml:id="DocumentResultMeta119263234648434">
     <gml:description>TIN der Wasserspiegellagen</gml:description>
     <gml:name>Wasserspiegellagen</gml:name>
     <resultMeta:path>Tin/tin_WATERLEVEL.gml</resultMeta:path>
     <resultMeta1d2d:type>tinWsp</resultMeta1d2d:type>
     <resultMeta1d2d:minValue>0.000</resultMeta1d2d:minValue>
     <resultMeta1d2d:maxValue>6.351</resultMeta1d2d:maxValue>
    </resultMeta1d2d:DocumentResultMeta>
   </resultMeta:childMember>
   <resultMeta:childMember>
    <resultMeta1d2d:DocumentResultMeta gml:id="DocumentResultMeta119263234648446">
     <gml:description>TIN der tiefengemittelten Fließgeschwindigkeiten</gml:description>
     <gml:name>Geschwindigkeiten</gml:name>
     <resultMeta:path>Tin/tin_VELOCITY.gml</resultMeta:path>
     <resultMeta1d2d:type>tinVelo</resultMeta1d2d:type>
     <resultMeta1d2d:minValue>0.000</resultMeta1d2d:minValue>
     <resultMeta1d2d:maxValue>0.916</resultMeta1d2d:maxValue>
    </resultMeta1d2d:DocumentResultMeta>
   </resultMeta:childMember>
   <resultMeta:childMember>
    <resultMeta1d2d:DocumentResultMeta gml:id="DocumentResultMeta119263234648427">
     <gml:description>Ergebnisse an den Knoten</gml:description>
     <gml:name>Vektoren</gml:name>
     <resultMeta:path>results.gml</resultMeta:path>
     <resultMeta1d2d:type>nodes</resultMeta1d2d:type>
     <resultMeta1d2d:minValue>0.000</resultMeta1d2d:minValue>
     <resultMeta1d2d:maxValue>0.916</resultMeta1d2d:maxValue>
    </resultMeta1d2d:DocumentResultMeta>
   </resultMeta:childMember>
   <resultMeta1d2d:stepTime>2007-09-30T02:00:00.000+02:00</resultMeta1d2d:stepTime>
   <resultMeta1d2d:stepNumber>14</resultMeta1d2d:stepNumber>
   <resultMeta1d2d:isRestart/>
   <resultMeta1d2d:type>unsteady</resultMeta1d2d:type>
  </resultMeta1d2d:StepResultMeta>
 </resultMeta:childMember>
 <resultMeta:childMember xmlns:resultMeta="http://www.tu-harburg.de/wb/kalypso/schemata/simulationbase/result/meta">
  <resultMeta1d2d:StepResultMeta gml:id="StepResultMeta119263211068773">
   <gml:description>instationärer Rechenlauf zum Zeitpunkt: 30.09.2007 14:00:00</gml:description>
   <gml:name>Zeitschritt 15 (30.09.2007 14:00:00)</gml:name>
   <resultMeta:path>timestep-0015</resultMeta:path>
   <resultMeta:childMember>
    <resultMeta1d2d:DocumentResultMeta gml:id="DocumentResultMeta119263238237514">
     <gml:description>ASCII Ergebnisdatei(en) des RMA10 Rechenkerns</gml:description>
     <gml:name>RMA-Rohdaten</gml:name>
     <resultMeta:path>original.2d.zip</resultMeta:path>
     <resultMeta1d2d:type>coreDataZip</resultMeta1d2d:type>
    </resultMeta1d2d:DocumentResultMeta>
   </resultMeta:childMember>
   <resultMeta:childMember>
    <resultMeta1d2d:DocumentResultMeta gml:id="DocumentResultMeta119263240237587">
     <gml:description>TIN der Fließtiefen</gml:description>
     <gml:name>Fließtiefen</gml:name>
     <resultMeta:path>Tin/tin_DEPTH.gml</resultMeta:path>
     <resultMeta1d2d:type>tinDepth</resultMeta1d2d:type>
     <resultMeta1d2d:minValue>0.000</resultMeta1d2d:minValue>
     <resultMeta1d2d:maxValue>2.973</resultMeta1d2d:maxValue>
    </resultMeta1d2d:DocumentResultMeta>
   </resultMeta:childMember>
   <resultMeta:childMember>
    <resultMeta1d2d:DocumentResultMeta gml:id="DocumentResultMeta119263240237520">
     <gml:description>TIN der Wasserspiegellagen</gml:description>
     <gml:name>Wasserspiegellagen</gml:name>
     <resultMeta:path>Tin/tin_WATERLEVEL.gml</resultMeta:path>
     <resultMeta1d2d:type>tinWsp</resultMeta1d2d:type>
     <resultMeta1d2d:minValue>0.000</resultMeta1d2d:minValue>
     <resultMeta1d2d:maxValue>6.303</resultMeta1d2d:maxValue>
    </resultMeta1d2d:DocumentResultMeta>
   </resultMeta:childMember>
   <resultMeta:childMember>
    <resultMeta1d2d:DocumentResultMeta gml:id="DocumentResultMeta11926324023751">
     <gml:description>TIN der tiefengemittelten Fließgeschwindigkeiten</gml:description>
     <gml:name>Geschwindigkeiten</gml:name>
     <resultMeta:path>Tin/tin_VELOCITY.gml</resultMeta:path>
     <resultMeta1d2d:type>tinVelo</resultMeta1d2d:type>
     <resultMeta1d2d:minValue>0.000</resultMeta1d2d:minValue>
     <resultMeta1d2d:maxValue>0.947</resultMeta1d2d:maxValue>
    </resultMeta1d2d:DocumentResultMeta>
   </resultMeta:childMember>
   <resultMeta:childMember>
    <resultMeta1d2d:DocumentResultMeta gml:id="DocumentResultMeta119263240237598">
     <gml:description>Ergebnisse an den Knoten</gml:description>
     <gml:name>Vektoren</gml:name>
     <resultMeta:path>results.gml</resultMeta:path>
     <resultMeta1d2d:type>nodes</resultMeta1d2d:type>
     <resultMeta1d2d:minValue>0.000</resultMeta1d2d:minValue>
     <resultMeta1d2d:maxValue>0.947</resultMeta1d2d:maxValue>
    </resultMeta1d2d:DocumentResultMeta>
   </resultMeta:childMember>
   <resultMeta1d2d:stepTime>2007-09-30T14:00:00.000+02:00</resultMeta1d2d:stepTime>
   <resultMeta1d2d:stepNumber>15</resultMeta1d2d:stepNumber>
   <resultMeta1d2d:isRestart/>
   <resultMeta1d2d:type>unsteady</resultMeta1d2d:type>
  </resultMeta1d2d:StepResultMeta>
 </resultMeta:childMember>
 <resultMeta:childMember xmlns:resultMeta="http://www.tu-harburg.de/wb/kalypso/schemata/simulationbase/result/meta">
  <resultMeta1d2d:StepResultMeta gml:id="StepResultMeta119263212834364">
   <gml:description>instationärer Rechenlauf zum Zeitpunkt: 01.10.2007 02:00:00</gml:description>
   <gml:name>Zeitschritt 16 (01.10.2007 02:00:00)</gml:name>
   <resultMeta:path>timestep-0016</resultMeta:path>
   <resultMeta:childMember>
    <resultMeta1d2d:DocumentResultMeta gml:id="DocumentResultMeta119263243909345">
     <gml:description>ASCII Ergebnisdatei(en) des RMA10 Rechenkerns</gml:description>
     <gml:name>RMA-Rohdaten</gml:name>
     <resultMeta:path>original.2d.zip</resultMeta:path>
     <resultMeta1d2d:type>coreDataZip</resultMeta1d2d:type>
    </resultMeta1d2d:DocumentResultMeta>
   </resultMeta:childMember>
   <resultMeta:childMember>
    <resultMeta1d2d:DocumentResultMeta gml:id="DocumentResultMeta119263246360972">
     <gml:description>TIN der Fließtiefen</gml:description>
     <gml:name>Fließtiefen</gml:name>
     <resultMeta:path>Tin/tin_DEPTH.gml</resultMeta:path>
     <resultMeta1d2d:type>tinDepth</resultMeta1d2d:type>
     <resultMeta1d2d:minValue>0.000</resultMeta1d2d:minValue>
     <resultMeta1d2d:maxValue>2.885</resultMeta1d2d:maxValue>
    </resultMeta1d2d:DocumentResultMeta>
   </resultMeta:childMember>
   <resultMeta:childMember>
    <resultMeta1d2d:DocumentResultMeta gml:id="DocumentResultMeta119263246360912">
     <gml:description>TIN der Wasserspiegellagen</gml:description>
     <gml:name>Wasserspiegellagen</gml:name>
     <resultMeta:path>Tin/tin_WATERLEVEL.gml</resultMeta:path>
     <resultMeta1d2d:type>tinWsp</resultMeta1d2d:type>
     <resultMeta1d2d:minValue>0.000</resultMeta1d2d:minValue>
     <resultMeta1d2d:maxValue>6.272</resultMeta1d2d:maxValue>
    </resultMeta1d2d:DocumentResultMeta>
   </resultMeta:childMember>
   <resultMeta:childMember>
    <resultMeta1d2d:DocumentResultMeta gml:id="DocumentResultMeta119263246360943">
     <gml:description>TIN der tiefengemittelten Fließgeschwindigkeiten</gml:description>
     <gml:name>Geschwindigkeiten</gml:name>
     <resultMeta:path>Tin/tin_VELOCITY.gml</resultMeta:path>
     <resultMeta1d2d:type>tinVelo</resultMeta1d2d:type>
     <resultMeta1d2d:minValue>0.000</resultMeta1d2d:minValue>
     <resultMeta1d2d:maxValue>0.969</resultMeta1d2d:maxValue>
    </resultMeta1d2d:DocumentResultMeta>
   </resultMeta:childMember>
   <resultMeta:childMember>
    <resultMeta1d2d:DocumentResultMeta gml:id="DocumentResultMeta119263246360996">
     <gml:description>Ergebnisse an den Knoten</gml:description>
     <gml:name>Vektoren</gml:name>
     <resultMeta:path>results.gml</resultMeta:path>
     <resultMeta1d2d:type>nodes</resultMeta1d2d:type>
     <resultMeta1d2d:minValue>0.000</resultMeta1d2d:minValue>
     <resultMeta1d2d:maxValue>0.969</resultMeta1d2d:maxValue>
    </resultMeta1d2d:DocumentResultMeta>
   </resultMeta:childMember>
   <resultMeta1d2d:stepTime>2007-10-01T02:00:00.000+02:00</resultMeta1d2d:stepTime>
   <resultMeta1d2d:stepNumber>16</resultMeta1d2d:stepNumber>
   <resultMeta1d2d:isRestart/>
   <resultMeta1d2d:type>unsteady</resultMeta1d2d:type>
  </resultMeta1d2d:StepResultMeta>
 </resultMeta:childMember>
 <resultMeta:childMember xmlns:resultMeta="http://www.tu-harburg.de/wb/kalypso/schemata/simulationbase/result/meta">
  <resultMeta1d2d:StepResultMeta gml:id="StepResultMeta119263214707865">
   <gml:description>instationärer Rechenlauf zum Zeitpunkt: 01.10.2007 14:00:00</gml:description>
   <gml:name>Zeitschritt 17 (01.10.2007 14:00:00)</gml:name>
   <resultMeta:path>timestep-0017</resultMeta:path>
   <resultMeta:childMember>
    <resultMeta1d2d:DocumentResultMeta gml:id="DocumentResultMeta119263251295364">
     <gml:description>ASCII Ergebnisdatei(en) des RMA10 Rechenkerns</gml:description>
     <gml:name>RMA-Rohdaten</gml:name>
     <resultMeta:path>original.2d.zip</resultMeta:path>
     <resultMeta1d2d:type>coreDataZip</resultMeta1d2d:type>
    </resultMeta1d2d:DocumentResultMeta>
   </resultMeta:childMember>
   <resultMeta:childMember>
    <resultMeta1d2d:DocumentResultMeta gml:id="DocumentResultMeta1192632542015105">
     <gml:description>TIN der Fließtiefen</gml:description>
     <gml:name>Fließtiefen</gml:name>
     <resultMeta:path>Tin/tin_DEPTH.gml</resultMeta:path>
     <resultMeta1d2d:type>tinDepth</resultMeta1d2d:type>
     <resultMeta1d2d:minValue>0.000</resultMeta1d2d:minValue>
     <resultMeta1d2d:maxValue>2.791</resultMeta1d2d:maxValue>
    </resultMeta1d2d:DocumentResultMeta>
   </resultMeta:childMember>
   <resultMeta:childMember>
    <resultMeta1d2d:DocumentResultMeta gml:id="DocumentResultMeta11926325420157">
     <gml:description>TIN der Wasserspiegellagen</gml:description>
     <gml:name>Wasserspiegellagen</gml:name>
     <resultMeta:path>Tin/tin_WATERLEVEL.gml</resultMeta:path>
     <resultMeta1d2d:type>tinWsp</resultMeta1d2d:type>
     <resultMeta1d2d:minValue>0.000</resultMeta1d2d:minValue>
     <resultMeta1d2d:maxValue>6.192</resultMeta1d2d:maxValue>
    </resultMeta1d2d:DocumentResultMeta>
   </resultMeta:childMember>
   <resultMeta:childMember>
    <resultMeta1d2d:DocumentResultMeta gml:id="DocumentResultMeta119263254201587">
     <gml:description>TIN der tiefengemittelten Fließgeschwindigkeiten</gml:description>
     <gml:name>Geschwindigkeiten</gml:name>
     <resultMeta:path>Tin/tin_VELOCITY.gml</resultMeta:path>
     <resultMeta1d2d:type>tinVelo</resultMeta1d2d:type>
     <resultMeta1d2d:minValue>0.000</resultMeta1d2d:minValue>
     <resultMeta1d2d:maxValue>1.037</resultMeta1d2d:maxValue>
    </resultMeta1d2d:DocumentResultMeta>
   </resultMeta:childMember>
   <resultMeta:childMember>
    <resultMeta1d2d:DocumentResultMeta gml:id="DocumentResultMeta119263254201546">
     <gml:description>Ergebnisse an den Knoten</gml:description>
     <gml:name>Vektoren</gml:name>
     <resultMeta:path>results.gml</resultMeta:path>
     <resultMeta1d2d:type>nodes</resultMeta1d2d:type>
     <resultMeta1d2d:minValue>0.000</resultMeta1d2d:minValue>
     <resultMeta1d2d:maxValue>1.037</resultMeta1d2d:maxValue>
    </resultMeta1d2d:DocumentResultMeta>
   </resultMeta:childMember>
   <resultMeta1d2d:stepTime>2007-10-01T14:00:00.000+02:00</resultMeta1d2d:stepTime>
   <resultMeta1d2d:stepNumber>17</resultMeta1d2d:stepNumber>
   <resultMeta1d2d:isRestart/>
   <resultMeta1d2d:type>unsteady</resultMeta1d2d:type>
  </resultMeta1d2d:StepResultMeta>
 </resultMeta:childMember>
 <resultMeta:childMember xmlns:resultMeta="http://www.tu-harburg.de/wb/kalypso/schemata/simulationbase/result/meta">
  <resultMeta1d2d:StepResultMeta gml:id="StepResultMeta119263215671823">
   <gml:description>instationärer Rechenlauf zum Zeitpunkt: 02.10.2007 02:00:00</gml:description>
   <gml:name>Zeitschritt 18 (02.10.2007 02:00:00)</gml:name>
   <resultMeta:path>timestep-0018</resultMeta:path>
   <resultMeta:childMember>
    <resultMeta1d2d:DocumentResultMeta gml:id="DocumentResultMeta119263257762529">
     <gml:description>ASCII Ergebnisdatei(en) des RMA10 Rechenkerns</gml:description>
     <gml:name>RMA-Rohdaten</gml:name>
     <resultMeta:path>original.2d.zip</resultMeta:path>
     <resultMeta1d2d:type>coreDataZip</resultMeta1d2d:type>
    </resultMeta1d2d:DocumentResultMeta>
   </resultMeta:childMember>
   <resultMeta:childMember>
    <resultMeta1d2d:DocumentResultMeta gml:id="DocumentResultMeta1192632601734109">
     <gml:description>TIN der Fließtiefen</gml:description>
     <gml:name>Fließtiefen</gml:name>
     <resultMeta:path>Tin/tin_DEPTH.gml</resultMeta:path>
     <resultMeta1d2d:type>tinDepth</resultMeta1d2d:type>
     <resultMeta1d2d:minValue>0.000</resultMeta1d2d:minValue>
     <resultMeta1d2d:maxValue>2.710</resultMeta1d2d:maxValue>
    </resultMeta1d2d:DocumentResultMeta>
   </resultMeta:childMember>
   <resultMeta:childMember>
    <resultMeta1d2d:DocumentResultMeta gml:id="DocumentResultMeta119263260173436">
     <gml:description>TIN der Wasserspiegellagen</gml:description>
     <gml:name>Wasserspiegellagen</gml:name>
     <resultMeta:path>Tin/tin_WATERLEVEL.gml</resultMeta:path>
     <resultMeta1d2d:type>tinWsp</resultMeta1d2d:type>
     <resultMeta1d2d:minValue>0.000</resultMeta1d2d:minValue>
     <resultMeta1d2d:maxValue>6.192</resultMeta1d2d:maxValue>
    </resultMeta1d2d:DocumentResultMeta>
   </resultMeta:childMember>
   <resultMeta:childMember>
    <resultMeta1d2d:DocumentResultMeta gml:id="DocumentResultMeta11926326017344">
     <gml:description>TIN der tiefengemittelten Fließgeschwindigkeiten</gml:description>
     <gml:name>Geschwindigkeiten</gml:name>
     <resultMeta:path>Tin/tin_VELOCITY.gml</resultMeta:path>
     <resultMeta1d2d:type>tinVelo</resultMeta1d2d:type>
     <resultMeta1d2d:minValue>0.000</resultMeta1d2d:minValue>
     <resultMeta1d2d:maxValue>1.142</resultMeta1d2d:maxValue>
    </resultMeta1d2d:DocumentResultMeta>
   </resultMeta:childMember>
   <resultMeta:childMember>
    <resultMeta1d2d:DocumentResultMeta gml:id="DocumentResultMeta119263260173497">
     <gml:description>Ergebnisse an den Knoten</gml:description>
     <gml:name>Vektoren</gml:name>
     <resultMeta:path>results.gml</resultMeta:path>
     <resultMeta1d2d:type>nodes</resultMeta1d2d:type>
     <resultMeta1d2d:minValue>0.000</resultMeta1d2d:minValue>
     <resultMeta1d2d:maxValue>1.142</resultMeta1d2d:maxValue>
    </resultMeta1d2d:DocumentResultMeta>
   </resultMeta:childMember>
   <resultMeta1d2d:stepTime>2007-10-02T02:00:00.000+02:00</resultMeta1d2d:stepTime>
   <resultMeta1d2d:stepNumber>18</resultMeta1d2d:stepNumber>
   <resultMeta1d2d:isRestart/>
   <resultMeta1d2d:type>unsteady</resultMeta1d2d:type>
  </resultMeta1d2d:StepResultMeta>
 </resultMeta:childMember>
 <resultMeta:childMember xmlns:resultMeta="http://www.tu-harburg.de/wb/kalypso/schemata/simulationbase/result/meta">
  <resultMeta1d2d:StepResultMeta gml:id="StepResultMeta119263216995324">
   <gml:description>instationärer Rechenlauf zum Zeitpunkt: 02.10.2007 14:00:00</gml:description>
   <gml:name>Zeitschritt 19 (02.10.2007 14:00:00)</gml:name>
   <resultMeta:path>timestep-0019</resultMeta:path>
   <resultMeta:childMember>
    <resultMeta1d2d:DocumentResultMeta gml:id="DocumentResultMeta119263263737514">
     <gml:description>ASCII Ergebnisdatei(en) des RMA10 Rechenkerns</gml:description>
     <gml:name>RMA-Rohdaten</gml:name>
     <resultMeta:path>original.2d.zip</resultMeta:path>
     <resultMeta1d2d:type>coreDataZip</resultMeta1d2d:type>
    </resultMeta1d2d:DocumentResultMeta>
   </resultMeta:childMember>
   <resultMeta:childMember>
    <resultMeta1d2d:DocumentResultMeta gml:id="DocumentResultMeta119263266159339">
     <gml:description>TIN der Fließtiefen</gml:description>
     <gml:name>Fließtiefen</gml:name>
     <resultMeta:path>Tin/tin_DEPTH.gml</resultMeta:path>
     <resultMeta1d2d:type>tinDepth</resultMeta1d2d:type>
     <resultMeta1d2d:minValue>0.000</resultMeta1d2d:minValue>
     <resultMeta1d2d:maxValue>2.587</resultMeta1d2d:maxValue>
    </resultMeta1d2d:DocumentResultMeta>
   </resultMeta:childMember>
   <resultMeta:childMember>
    <resultMeta1d2d:DocumentResultMeta gml:id="DocumentResultMeta119263266159373">
     <gml:description>TIN der Wasserspiegellagen</gml:description>
     <gml:name>Wasserspiegellagen</gml:name>
     <resultMeta:path>Tin/tin_WATERLEVEL.gml</resultMeta:path>
     <resultMeta1d2d:type>tinWsp</resultMeta1d2d:type>
     <resultMeta1d2d:minValue>0.000</resultMeta1d2d:minValue>
     <resultMeta1d2d:maxValue>6.192</resultMeta1d2d:maxValue>
    </resultMeta1d2d:DocumentResultMeta>
   </resultMeta:childMember>
   <resultMeta:childMember>
    <resultMeta1d2d:DocumentResultMeta gml:id="DocumentResultMeta119263266159335">
     <gml:description>TIN der tiefengemittelten Fließgeschwindigkeiten</gml:description>
     <gml:name>Geschwindigkeiten</gml:name>
     <resultMeta:path>Tin/tin_VELOCITY.gml</resultMeta:path>
     <resultMeta1d2d:type>tinVelo</resultMeta1d2d:type>
     <resultMeta1d2d:minValue>0.000</resultMeta1d2d:minValue>
     <resultMeta1d2d:maxValue>1.243</resultMeta1d2d:maxValue>
    </resultMeta1d2d:DocumentResultMeta>
   </resultMeta:childMember>
   <resultMeta:childMember>
    <resultMeta1d2d:DocumentResultMeta gml:id="DocumentResultMeta119263266159381">
     <gml:description>Ergebnisse an den Knoten</gml:description>
     <gml:name>Vektoren</gml:name>
     <resultMeta:path>results.gml</resultMeta:path>
     <resultMeta1d2d:type>nodes</resultMeta1d2d:type>
     <resultMeta1d2d:minValue>0.000</resultMeta1d2d:minValue>
     <resultMeta1d2d:maxValue>1.243</resultMeta1d2d:maxValue>
    </resultMeta1d2d:DocumentResultMeta>
   </resultMeta:childMember>
   <resultMeta1d2d:stepTime>2007-10-02T14:00:00.000+02:00</resultMeta1d2d:stepTime>
   <resultMeta1d2d:stepNumber>19</resultMeta1d2d:stepNumber>
   <resultMeta1d2d:isRestart/>
   <resultMeta1d2d:type>unsteady</resultMeta1d2d:type>
  </resultMeta1d2d:StepResultMeta>
 </resultMeta:childMember>
 <resultMeta:childMember xmlns:resultMeta="http://www.tu-harburg.de/wb/kalypso/schemata/simulationbase/result/meta">
  <resultMeta1d2d:StepResultMeta gml:id="StepResultMeta119263218006232">
   <gml:description>instationärer Rechenlauf zum Zeitpunkt: 03.10.2007 02:00:00</gml:description>
   <gml:name>Zeitschritt 20 (03.10.2007 02:00:00)</gml:name>
   <resultMeta:path>timestep-0020</resultMeta:path>
   <resultMeta:childMember>
    <resultMeta1d2d:DocumentResultMeta gml:id="DocumentResultMeta119263269718752">
     <gml:description>ASCII Ergebnisdatei(en) des RMA10 Rechenkerns</gml:description>
     <gml:name>RMA-Rohdaten</gml:name>
     <resultMeta:path>original.2d.zip</resultMeta:path>
     <resultMeta1d2d:type>coreDataZip</resultMeta1d2d:type>
    </resultMeta1d2d:DocumentResultMeta>
   </resultMeta:childMember>
   <resultMeta:childMember>
    <resultMeta1d2d:DocumentResultMeta gml:id="DocumentResultMeta119263272120387">
     <gml:description>TIN der Fließtiefen</gml:description>
     <gml:name>Fließtiefen</gml:name>
     <resultMeta:path>Tin/tin_DEPTH.gml</resultMeta:path>
     <resultMeta1d2d:type>tinDepth</resultMeta1d2d:type>
     <resultMeta1d2d:minValue>0.000</resultMeta1d2d:minValue>
     <resultMeta1d2d:maxValue>2.492</resultMeta1d2d:maxValue>
    </resultMeta1d2d:DocumentResultMeta>
   </resultMeta:childMember>
   <resultMeta:childMember>
    <resultMeta1d2d:DocumentResultMeta gml:id="DocumentResultMeta119263272120343">
     <gml:description>TIN der Wasserspiegellagen</gml:description>
     <gml:name>Wasserspiegellagen</gml:name>
     <resultMeta:path>Tin/tin_WATERLEVEL.gml</resultMeta:path>
     <resultMeta1d2d:type>tinWsp</resultMeta1d2d:type>
     <resultMeta1d2d:minValue>0.000</resultMeta1d2d:minValue>
     <resultMeta1d2d:maxValue>6.192</resultMeta1d2d:maxValue>
    </resultMeta1d2d:DocumentResultMeta>
   </resultMeta:childMember>
   <resultMeta:childMember>
    <resultMeta1d2d:DocumentResultMeta gml:id="DocumentResultMeta119263272120344">
     <gml:description>TIN der tiefengemittelten Fließgeschwindigkeiten</gml:description>
     <gml:name>Geschwindigkeiten</gml:name>
     <resultMeta:path>Tin/tin_VELOCITY.gml</resultMeta:path>
     <resultMeta1d2d:type>tinVelo</resultMeta1d2d:type>
     <resultMeta1d2d:minValue>0.000</resultMeta1d2d:minValue>
     <resultMeta1d2d:maxValue>1.289</resultMeta1d2d:maxValue>
    </resultMeta1d2d:DocumentResultMeta>
   </resultMeta:childMember>
   <resultMeta:childMember>
    <resultMeta1d2d:DocumentResultMeta gml:id="DocumentResultMeta119263272120372">
     <gml:description>Ergebnisse an den Knoten</gml:description>
     <gml:name>Vektoren</gml:name>
     <resultMeta:path>results.gml</resultMeta:path>
     <resultMeta1d2d:type>nodes</resultMeta1d2d:type>
     <resultMeta1d2d:minValue>0.000</resultMeta1d2d:minValue>
     <resultMeta1d2d:maxValue>1.289</resultMeta1d2d:maxValue>
    </resultMeta1d2d:DocumentResultMeta>
   </resultMeta:childMember>
   <resultMeta1d2d:stepTime>2007-10-03T02:00:00.000+02:00</resultMeta1d2d:stepTime>
   <resultMeta1d2d:stepNumber>20</resultMeta1d2d:stepNumber>
   <resultMeta1d2d:isRestart/>
   <resultMeta1d2d:type>unsteady</resultMeta1d2d:type>
  </resultMeta1d2d:StepResultMeta>
 </resultMeta:childMember>
 <resultMeta:childMember xmlns:resultMeta="http://www.tu-harburg.de/wb/kalypso/schemata/simulationbase/result/meta">
  <resultMeta1d2d:StepResultMeta gml:id="StepResultMeta119263218979633">
   <gml:description>instationärer Rechenlauf zum Zeitpunkt: 03.10.2007 14:00:00</gml:description>
   <gml:name>Zeitschritt 21 (03.10.2007 14:00:00)</gml:name>
   <resultMeta:path>timestep-0021</resultMeta:path>
   <resultMeta:childMember>
    <resultMeta1d2d:DocumentResultMeta gml:id="DocumentResultMeta1192632760531105">
     <gml:description>ASCII Ergebnisdatei(en) des RMA10 Rechenkerns</gml:description>
     <gml:name>RMA-Rohdaten</gml:name>
     <resultMeta:path>original.2d.zip</resultMeta:path>
     <resultMeta1d2d:type>coreDataZip</resultMeta1d2d:type>
    </resultMeta1d2d:DocumentResultMeta>
   </resultMeta:childMember>
   <resultMeta:childMember>
    <resultMeta1d2d:DocumentResultMeta gml:id="DocumentResultMeta119263278567123">
     <gml:description>TIN der Fließtiefen</gml:description>
     <gml:name>Fließtiefen</gml:name>
     <resultMeta:path>Tin/tin_DEPTH.gml</resultMeta:path>
     <resultMeta1d2d:type>tinDepth</resultMeta1d2d:type>
     <resultMeta1d2d:minValue>0.000</resultMeta1d2d:minValue>
     <resultMeta1d2d:maxValue>2.445</resultMeta1d2d:maxValue>
    </resultMeta1d2d:DocumentResultMeta>
   </resultMeta:childMember>
   <resultMeta:childMember>
    <resultMeta1d2d:DocumentResultMeta gml:id="DocumentResultMeta1192632785671107">
     <gml:description>TIN der Wasserspiegellagen</gml:description>
     <gml:name>Wasserspiegellagen</gml:name>
     <resultMeta:path>Tin/tin_WATERLEVEL.gml</resultMeta:path>
     <resultMeta1d2d:type>tinWsp</resultMeta1d2d:type>
     <resultMeta1d2d:minValue>0.000</resultMeta1d2d:minValue>
     <resultMeta1d2d:maxValue>6.192</resultMeta1d2d:maxValue>
    </resultMeta1d2d:DocumentResultMeta>
   </resultMeta:childMember>
   <resultMeta:childMember>
    <resultMeta1d2d:DocumentResultMeta gml:id="DocumentResultMeta119263278567146">
     <gml:description>TIN der tiefengemittelten Fließgeschwindigkeiten</gml:description>
     <gml:name>Geschwindigkeiten</gml:name>
     <resultMeta:path>Tin/tin_VELOCITY.gml</resultMeta:path>
     <resultMeta1d2d:type>tinVelo</resultMeta1d2d:type>
     <resultMeta1d2d:minValue>0.000</resultMeta1d2d:minValue>
     <resultMeta1d2d:maxValue>1.309</resultMeta1d2d:maxValue>
    </resultMeta1d2d:DocumentResultMeta>
   </resultMeta:childMember>
   <resultMeta:childMember>
    <resultMeta1d2d:DocumentResultMeta gml:id="DocumentResultMeta1192632785671119">
     <gml:description>Ergebnisse an den Knoten</gml:description>
     <gml:name>Vektoren</gml:name>
     <resultMeta:path>results.gml</resultMeta:path>
     <resultMeta1d2d:type>nodes</resultMeta1d2d:type>
     <resultMeta1d2d:minValue>0.000</resultMeta1d2d:minValue>
     <resultMeta1d2d:maxValue>1.309</resultMeta1d2d:maxValue>
    </resultMeta1d2d:DocumentResultMeta>
   </resultMeta:childMember>
   <resultMeta1d2d:stepTime>2007-10-03T14:00:00.000+02:00</resultMeta1d2d:stepTime>
   <resultMeta1d2d:stepNumber>21</resultMeta1d2d:stepNumber>
   <resultMeta1d2d:isRestart/>
   <resultMeta1d2d:type>unsteady</resultMeta1d2d:type>
  </resultMeta1d2d:StepResultMeta>
 </resultMeta:childMember>
 <resultMeta1d2d:simulationStartTime>2007-10-17T16:26:29.218+02:00</resultMeta1d2d:simulationStartTime>
 <resultMeta1d2d:simulationEndTime>2007-10-17T16:53:05.828+02:00</resultMeta1d2d:simulationEndTime>
 <resultMeta1d2d:calcUnitID>CalculationUnit2D119039712104619205</resultMeta1d2d:calcUnitID>
</resultMeta1d2d:CalculationUnitResultMeta>
