<?xml version="1.0" encoding="WINDOWS-1252"?>
<om:Observation xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:gml="http://www.opengis.net/gml" xmlns:xs="http://www.w3.org/2001/XMLSchema-instance" xmlns:om="http://www.opengis.net/om" xmlns:st="http://www.seegrid.csiro.au/xml/st" xmlns:sweExt="org.kalypso.swe.ext" xs:schemaLocation="http://www.opengis.net/om http://dev.bjoernsen.de/ogc/schema/om/1.0.30/om.xsd     http://www.opengis.net/gml http://dev.bjoernsen.de/ogc/schema/gml/3.1.1/base/gml.xsd     http://www.w3.org/1999/xlink http://dev.bjoernsen.de/ogc/schema/gml/3.1.1/xlink/xlinks.xsd     http://www.opengis.net/swe http://dev.bjoernsen.de/ogc/schema/sweCommon/1.0.30/swe.xsd     http://www.seegrid.csiro.au/xml/st http://dev.bjoernsen.de/ogc/schema/sweCommon/1.0.30/simpleTypeDerivation.xsd" gml:id="LengthSectionResult">
 <gml:name>L�ngsschnitt</gml:name>
 <om:procedure>
  <om:ObservationProcedure gml:id="proc_wspm_ls">
   <gml:description>WSPM TUHH L�ngsschnitt Ergebnis</gml:description>
   <gml:name>WSPM-TUHH-LS</gml:name>
   <om:method/>
  </om:ObservationProcedure>
 </om:procedure>
 <om:resultDefinition>
  <sweExt:SortedRecordDefinition gml:id="SortedRecordDefinition11905618106404">
   <swe:component xmlns:swe="http://www.opengis.net/swe" xlink:href="urn:ogc:gml:dict:kalypso:model:wspm:components#LengthSectionStation"/>
   <swe:component xmlns:swe="http://www.opengis.net/swe" xlink:href="urn:ogc:gml:dict:kalypso:model:wspm:components#LengthSectionRunOff"/>
   <swe:component xmlns:swe="http://www.opengis.net/swe" xlink:href="urn:ogc:gml:dict:kalypso:model:wspm:components#LengthSectionGround"/>
   <swe:component xmlns:swe="http://www.opengis.net/swe" xlink:href="urn:ogc:gml:dict:kalypso:model:wspm:components#LengthSectionWaterlevel"/>
   <sweExt:sortedComponent xlink:href="urn:ogc:gml:dict:kalypso:model:wspm:components#LengthSectionStation"/>
  </sweExt:SortedRecordDefinition>
 </om:resultDefinition>
 <om:result><![CDATA[59400 null 2.7385 6.2075
59500 null 2.6874 6.2098
59600 null 2.8409 6.2151
59700 null 2.8846 6.2160
59800 null 3.0478 6.2189
59900 null 3.2695 6.2249
60000 null 3.3373 6.2298
60100 null 3.6042 6.2335
60200 null 3.3585 6.2400
60300 null 3.2819 6.2474
60400 null 3.4169 6.2587
60500 null 3.5135 6.2672
60600 null 3.5147 6.2726
60700 null 3.4826 6.2803
60800 null 3.5889 6.2852
60900 null 3.4952 6.2916
61000 null 4.1786 6.3066
61100 null 4.2258 6.3208
61200 null 4.2291 6.3293
61300 null 4.4586 6.3471
61400 null 4.5688 6.3776
]]></om:result>
</om:Observation>
