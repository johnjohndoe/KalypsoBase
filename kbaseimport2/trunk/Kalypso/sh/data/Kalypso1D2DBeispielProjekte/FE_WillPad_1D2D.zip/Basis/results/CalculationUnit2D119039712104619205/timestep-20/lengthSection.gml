<?xml version="1.0" encoding="WINDOWS-1252"?>
<om:Observation xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:gml="http://www.opengis.net/gml" xmlns:xs="http://www.w3.org/2001/XMLSchema-instance" xmlns:om="http://www.opengis.net/om" xmlns:st="http://www.seegrid.csiro.au/xml/st" xmlns:sweExt="org.kalypso.swe.ext" xs:schemaLocation="http://www.opengis.net/om http://dev.bjoernsen.de/ogc/schema/om/1.0.30/om.xsd     http://www.opengis.net/gml http://dev.bjoernsen.de/ogc/schema/gml/3.1.1/base/gml.xsd     http://www.w3.org/1999/xlink http://dev.bjoernsen.de/ogc/schema/gml/3.1.1/xlink/xlinks.xsd     http://www.opengis.net/swe http://dev.bjoernsen.de/ogc/schema/sweCommon/1.0.30/swe.xsd     http://www.seegrid.csiro.au/xml/st http://dev.bjoernsen.de/ogc/schema/sweCommon/1.0.30/simpleTypeDerivation.xsd" gml:id="LengthSectionResult">
 <gml:name>L�ngsschnitt</gml:name>
 <om:procedure>
  <om:ObservationProcedure gml:id="proc_wspm_ls">
   <gml:description>WSPM TUHH L�ngsschnitt Ergebnis</gml:description>
   <gml:name>WSPM-TUHH-LS</gml:name>
   <om:method/>
  </om:ObservationProcedure>
 </om:procedure>
 <om:resultDefinition>
  <sweExt:SortedRecordDefinition gml:id="SortedRecordDefinition11905650834687">
   <swe:component xmlns:swe="http://www.opengis.net/swe" xlink:href="urn:ogc:gml:dict:kalypso:model:wspm:components#LengthSectionStation"/>
   <swe:component xmlns:swe="http://www.opengis.net/swe" xlink:href="urn:ogc:gml:dict:kalypso:model:wspm:components#LengthSectionRunOff"/>
   <swe:component xmlns:swe="http://www.opengis.net/swe" xlink:href="urn:ogc:gml:dict:kalypso:model:wspm:components#LengthSectionGround"/>
   <swe:component xmlns:swe="http://www.opengis.net/swe" xlink:href="urn:ogc:gml:dict:kalypso:model:wspm:components#LengthSectionWaterlevel"/>
   <sweExt:sortedComponent xlink:href="urn:ogc:gml:dict:kalypso:model:wspm:components#LengthSectionStation"/>
  </sweExt:SortedRecordDefinition>
 </om:resultDefinition>
 <om:result><![CDATA[59400 null 2.7388 5.0689
59500 null 2.6874 5.1081
59600 null 2.8409 5.1373
59700 null 2.8846 5.1601
59800 null 3.0478 5.1896
59900 null 3.2701 5.2196
60000 null 3.3373 5.2539
60100 null 3.6042 5.2918
60200 null 3.3585 5.3369
60300 null 3.2819 5.3778
60400 null 3.4169 5.4278
60500 null 3.5135 5.4601
60600 null 3.5147 5.4919
60700 null 3.4826 5.5175
60800 null 3.5889 5.5469
60900 null 3.4952 5.5680
61000 null 4.1785 5.6473
61100 null 4.2259 5.7944
61200 null 4.2291 5.8175
61300 null 4.4586 5.8513
61400 null 4.5696 5.8871
]]></om:result>
</om:Observation>
