<?xml version="1.0" encoding="WINDOWS-1252"?>
<c1d2d:ControlModelGroup xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:gml="http://www.opengis.net/gml" xmlns:xs="http://www.w3.org/2001/XMLSchema-instance" xmlns:c1d2d="http://www.tu-harburg.de/wb/kalypso/schemata/1d2dControl" xmlns:swe="http://www.opengis.net/swe" xmlns:sweExt="org.kalypso.swe.ext" gml:id="root">
 <c1d2d:controlModelCollection>
  <c1d2d:ControlModelCollection gml:id="ControlModelCollection11914815875931">
   <c1d2d:activeModelID xlink:href="#ControlModel11914828330152"/>
   <c1d2d:controlModelMember>
    <c1d2d:ControlModel gml:id="ControlModel119157763131214">
     <gml:name>Steuerparameter f�r  WillBuenz_1D2D</gml:name>
     <wb1d2d:calculationUnit xmlns:wb1d2d="http://www.tu-harburg.de/wb/kalypso/schemata/1d2d" xlink:href="discretisation.gml#CalculationUnit1D2D11915776313123651"/>
     <c1d2d:Version>NEW</c1d2d:Version>
     <c1d2d:VEGETA>false</c1d2d:VEGETA>
     <c1d2d:IDNOPT>-1</c1d2d:IDNOPT>
     <c1d2d:startsim/>
     <c1d2d:IEDSW>10</c1d2d:IEDSW>
     <c1d2d:TBFACT>0.2</c1d2d:TBFACT>
     <c1d2d:TBMIN>2.0</c1d2d:TBMIN>
     <c1d2d:_p_bottom/>
     <c1d2d:OMEGA>52.0</c1d2d:OMEGA>
     <c1d2d:ELEV/>
     <c1d2d:UNOM>0.5</c1d2d:UNOM>
     <c1d2d:UDIR/>
     <c1d2d:HMIN/>
     <c1d2d:DSET>0.1</c1d2d:DSET>
     <c1d2d:DSETD>0.12</c1d2d:DSETD>
     <c1d2d:_steady>true</c1d2d:_steady>
     <c1d2d:_unsteady>false</c1d2d:_unsteady>
     <c1d2d:NITI>25</c1d2d:NITI>
     <c1d2d:NITN>1</c1d2d:NITN>
     <c1d2d:CONV_1>0.0010</c1d2d:CONV_1>
     <c1d2d:CONV_2>0.0010</c1d2d:CONV_2>
     <c1d2d:CONV_3>1.0E-4</c1d2d:CONV_3>
     <c1d2d:IDRPT>1</c1d2d:IDRPT>
     <c1d2d:DRFACT>0.05</c1d2d:DRFACT>
     <c1d2d:AC1>1.5</c1d2d:AC1>
     <c1d2d:AC2>0.67</c1d2d:AC2>
     <c1d2d:AC3>0.04</c1d2d:AC3>
     <c1d2d:_restart>true</c1d2d:_restart>
     <c1d2d:restartInfoMember>
      <c1d2d:RestartInfo gml:id="RestartInfo11915777124065">
       <c1d2d:calculationUnitID>CalculationUnit1D119148158759313274</c1d2d:calculationUnitID>
       <c1d2d:stepResultMetaID>StepResultMeta119148618279679</c1d2d:stepResultMetaID>
       <c1d2d:filePath>results/CalculationUnit1D119148158759313274/steady/results.gml</c1d2d:filePath>
      </c1d2d:RestartInfo>
     </c1d2d:restartInfoMember>
     <c1d2d:restartInfoMember>
      <c1d2d:RestartInfo gml:id="RestartInfo119157771240616">
       <c1d2d:calculationUnitID>CalculationUnit2D11914828330154813</c1d2d:calculationUnitID>
       <c1d2d:stepResultMetaID>StepResultMeta1191487318328202</c1d2d:stepResultMetaID>
       <c1d2d:filePath>results/CalculationUnit2D11914828330154813/timestep-0021/results.gml</c1d2d:filePath>
      </c1d2d:RestartInfo>
     </c1d2d:restartInfoMember>
     <c1d2d:IACCYC>1</c1d2d:IACCYC>
     <c1d2d:FNAM3/>
     <c1d2d:_steadyBC>0.3</c1d2d:_steadyBC>
     <c1d2d:timestepsMember>
      <c1d2d:TimestepsObservation gml:id="TimestepsObservation11915776313122">
       <gml:name>Zeitschrittdefinition</gml:name>
       <om:resultDefinition xmlns:om="http://www.opengis.net/om">
        <sweExt:SortedRecordDefinition gml:id="SortedRecordDefinition11915776313126">
         <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:1d2d:timeserie:components#OrdinalNumber"/>
         <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:1d2d:timeserie:components#Time"/>
         <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:1d2d:timeserie:components#UnderRelaxationFactor"/>
         <sweExt:sortedComponent xlink:href="urn:ogc:gml:dict:kalypso:model:1d2d:timeserie:components#OrdinalNumber"/>
        </sweExt:SortedRecordDefinition>
       </om:resultDefinition>
       <om:result xmlns:om="http://www.opengis.net/om"/>
      </c1d2d:TimestepsObservation>
     </c1d2d:timestepsMember>
    </c1d2d:ControlModel>
   </c1d2d:controlModelMember>
   <c1d2d:controlModelMember>
    <c1d2d:ControlModel gml:id="ControlModel11914828330152">
     <gml:name>Steuerparameter f�r  WillBuenz_OW</gml:name>
     <wb1d2d:calculationUnit xmlns:wb1d2d="http://www.tu-harburg.de/wb/kalypso/schemata/1d2d" xlink:href="discretisation.gml#CalculationUnit2D11914828330154813"/>
     <c1d2d:Version>NEW</c1d2d:Version>
     <c1d2d:VEGETA>false</c1d2d:VEGETA>
     <c1d2d:IDNOPT>-1</c1d2d:IDNOPT>
     <c1d2d:startsim/>
     <c1d2d:IEDSW>10</c1d2d:IEDSW>
     <c1d2d:TBFACT>0.2</c1d2d:TBFACT>
     <c1d2d:TBMIN>2.0</c1d2d:TBMIN>
     <c1d2d:_p_bottom/>
     <c1d2d:OMEGA>52.0</c1d2d:OMEGA>
     <c1d2d:ELEV>8.4</c1d2d:ELEV>
     <c1d2d:UNOM>0.5</c1d2d:UNOM>
     <c1d2d:UDIR>235.0</c1d2d:UDIR>
     <c1d2d:HMIN>0.0</c1d2d:HMIN>
     <c1d2d:DSET>0.1</c1d2d:DSET>
     <c1d2d:DSETD>0.12</c1d2d:DSETD>
     <c1d2d:_steady>true</c1d2d:_steady>
     <c1d2d:_unsteady>true</c1d2d:_unsteady>
     <c1d2d:NITI>25</c1d2d:NITI>
     <c1d2d:NITN>25</c1d2d:NITN>
     <c1d2d:CONV_1>0.01</c1d2d:CONV_1>
     <c1d2d:CONV_2>0.01</c1d2d:CONV_2>
     <c1d2d:CONV_3>0.0010</c1d2d:CONV_3>
     <c1d2d:IDRPT>1</c1d2d:IDRPT>
     <c1d2d:DRFACT>0.05</c1d2d:DRFACT>
     <c1d2d:AC1>1.5</c1d2d:AC1>
     <c1d2d:AC2>0.67</c1d2d:AC2>
     <c1d2d:AC3>0.04</c1d2d:AC3>
     <c1d2d:_restart>false</c1d2d:_restart>
     <c1d2d:IACCYC>1</c1d2d:IACCYC>
     <c1d2d:FNAM3/>
     <c1d2d:_steadyBC>0.5</c1d2d:_steadyBC>
     <c1d2d:timestepsMember>
      <c1d2d:TimestepsObservation gml:id="TimestepsObservation11914828330154">
       <gml:name>Zeitschrittdefinition</gml:name>
       <om:resultDefinition xmlns:om="http://www.opengis.net/om">
        <sweExt:SortedRecordDefinition gml:id="SortedRecordDefinition11914863481714">
         <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:1d2d:timeserie:components#OrdinalNumber"/>
         <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:1d2d:timeserie:components#Time"/>
         <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:1d2d:timeserie:components#UnderRelaxationFactor"/>
         <sweExt:sortedComponent xlink:href="urn:ogc:gml:dict:kalypso:model:1d2d:timeserie:components#OrdinalNumber"/>
        </sweExt:SortedRecordDefinition>
       </om:resultDefinition>
       <om:result xmlns:om="http://www.opengis.net/om"><![CDATA[1 2007-09-23T00%3A00%3A00.000%2B02%3A00 0.500
2 2007-09-23T12%3A00%3A00.000%2B02%3A00 0.500
3 2007-09-24T00%3A00%3A00.000%2B02%3A00 0.500
4 2007-09-24T12%3A00%3A00.000%2B02%3A00 0.500
5 2007-09-25T00%3A00%3A00.000%2B02%3A00 0.500
6 2007-09-25T12%3A00%3A00.000%2B02%3A00 0.500
7 2007-09-26T00%3A00%3A00.000%2B02%3A00 0.500
8 2007-09-26T12%3A00%3A00.000%2B02%3A00 0.500
9 2007-09-27T00%3A00%3A00.000%2B02%3A00 0.500
10 2007-09-27T12%3A00%3A00.000%2B02%3A00 0.600
11 2007-09-28T00%3A00%3A00.000%2B02%3A00 0.700
12 2007-09-28T12%3A00%3A00.000%2B02%3A00 0.800
13 2007-09-29T00%3A00%3A00.000%2B02%3A00 0.900
14 2007-09-29T12%3A00%3A00.000%2B02%3A00 1
15 2007-09-30T00%3A00%3A00.000%2B02%3A00 1
16 2007-09-30T12%3A00%3A00.000%2B02%3A00 1
17 2007-10-01T00%3A00%3A00.000%2B02%3A00 1
18 2007-10-01T12%3A00%3A00.000%2B02%3A00 1
19 2007-10-02T00%3A00%3A00.000%2B02%3A00 1
20 2007-10-02T12%3A00%3A00.000%2B02%3A00 1
21 2007-10-03T00%3A00%3A00.000%2B02%3A00 1
22 2007-10-03T12%3A00%3A00.000%2B02%3A00 1
]]></om:result>
      </c1d2d:TimestepsObservation>
     </c1d2d:timestepsMember>
    </c1d2d:ControlModel>
   </c1d2d:controlModelMember>
   <c1d2d:controlModelMember>
    <c1d2d:ControlModel gml:id="ControlModel11914815875932">
     <gml:name>Steuerparameter f�r  WillBuenz_UW</gml:name>
     <wb1d2d:calculationUnit xmlns:wb1d2d="http://www.tu-harburg.de/wb/kalypso/schemata/1d2d" xlink:href="discretisation.gml#CalculationUnit1D119148158759313274"/>
     <c1d2d:Version>NEW</c1d2d:Version>
     <c1d2d:VEGETA>false</c1d2d:VEGETA>
     <c1d2d:IDNOPT>-1</c1d2d:IDNOPT>
     <c1d2d:startsim/>
     <c1d2d:IEDSW>10</c1d2d:IEDSW>
     <c1d2d:TBFACT>0.2</c1d2d:TBFACT>
     <c1d2d:TBMIN>2.0</c1d2d:TBMIN>
     <c1d2d:_p_bottom/>
     <c1d2d:OMEGA>52.0</c1d2d:OMEGA>
     <c1d2d:ELEV>12.0</c1d2d:ELEV>
     <c1d2d:UNOM>0.5</c1d2d:UNOM>
     <c1d2d:UDIR>235.0</c1d2d:UDIR>
     <c1d2d:HMIN>0.15</c1d2d:HMIN>
     <c1d2d:DSET>0.1</c1d2d:DSET>
     <c1d2d:DSETD>0.12</c1d2d:DSETD>
     <c1d2d:_steady>true</c1d2d:_steady>
     <c1d2d:_unsteady>false</c1d2d:_unsteady>
     <c1d2d:NITI>25</c1d2d:NITI>
     <c1d2d:NITN>1</c1d2d:NITN>
     <c1d2d:CONV_1>0.01</c1d2d:CONV_1>
     <c1d2d:CONV_2>0.01</c1d2d:CONV_2>
     <c1d2d:CONV_3>0.0010</c1d2d:CONV_3>
     <c1d2d:IDRPT>1</c1d2d:IDRPT>
     <c1d2d:DRFACT>0.05</c1d2d:DRFACT>
     <c1d2d:AC1>1.5</c1d2d:AC1>
     <c1d2d:AC2>0.67</c1d2d:AC2>
     <c1d2d:AC3>0.04</c1d2d:AC3>
     <c1d2d:_restart>false</c1d2d:_restart>
     <c1d2d:IACCYC>1</c1d2d:IACCYC>
     <c1d2d:FNAM3/>
     <c1d2d:_steadyBC>0.5</c1d2d:_steadyBC>
     <c1d2d:timestepsMember>
      <c1d2d:TimestepsObservation gml:id="TimestepsObservation11914815875930">
       <gml:name>Zeitschrittdefinition</gml:name>
       <om:resultDefinition xmlns:om="http://www.opengis.net/om">
        <sweExt:SortedRecordDefinition gml:id="SortedRecordDefinition11914815876091">
         <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:1d2d:timeserie:components#OrdinalNumber"/>
         <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:1d2d:timeserie:components#Time"/>
         <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:1d2d:timeserie:components#UnderRelaxationFactor"/>
         <sweExt:sortedComponent xlink:href="urn:ogc:gml:dict:kalypso:model:1d2d:timeserie:components#OrdinalNumber"/>
        </sweExt:SortedRecordDefinition>
       </om:resultDefinition>
       <om:result xmlns:om="http://www.opengis.net/om"/>
      </c1d2d:TimestepsObservation>
     </c1d2d:timestepsMember>
    </c1d2d:ControlModel>
   </c1d2d:controlModelMember>
  </c1d2d:ControlModelCollection>
 </c1d2d:controlModelCollection>
</c1d2d:ControlModelGroup>
