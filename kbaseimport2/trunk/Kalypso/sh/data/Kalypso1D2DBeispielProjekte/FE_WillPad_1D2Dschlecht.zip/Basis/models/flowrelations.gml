<?xml version="1.0" encoding="WINDOWS-1252"?>
<simBase:FlowRelationshipModel xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:gml="http://www.opengis.net/gml" xmlns:xs="http://www.w3.org/2001/XMLSchema-instance" xmlns:simBase="http://www.tu-harburg.de/wb/kalypso/schemata/simulationbase" xmlns:wb1d2d="http://www.tu-harburg.de/wb/kalypso/schemata/1d2d" xmlns:op1d2d="http://www.tu-harburg.de/wb/kalypso/schemata/operationalmodel" xmlns:tuhh="org.kalypso.model.wspm.tuhh" xmlns:swe="http://www.opengis.net/swe" xmlns:ns8="http://www.tu-harburg.de/wb/kalypso/schemata/observation" xmlns:math="org.kalypso.gml.common.math" xmlns:om="http://www.opengis.net/om" xmlns:sweExt="org.kalypso.swe.ext" gml:id="root">
 <simBase:flowRelationshipMember>
  <wb1d2d:TeschkeFlowRelation gml:id="TeschkeFlowRelation11913552127341">
   <gml:description>Gelesen aus: PROF0058.4500.txt</gml:description>
   <gml:name>58.4500</gml:name>
   <simBase:position>
    <gml:Point xmlns:ns1="http://www.w3.org/2001/SMIL20/" xmlns:st="http://www.seegrid.csiro.au/xml/st" xmlns:ns2="http://www.isotc211.org/2005/gmd" xmlns:ns3="http://www.isotc211.org/2005/gco" xmlns:ns4="http://www.isotc211.org/2005/gts" xmlns:ns5="http://www.isotc211.org/2005/gss" xmlns:ns6="http://www.isotc211.org/2005/gsr" xmlns:ns7="http://www.w3.org/2001/SMIL20/Language" srsName="EPSG:31467">
     <gml:coordinates ts="," decimal="." cs=" ">3552976.267011057 5986892.157092223 2.58</gml:coordinates>
    </gml:Point>
   </simBase:position>
   <wb1d2d:pointsMember>
    <tuhh:WPointsObservation gml:id="WPointsObservation11913552127341">
     <gml:description>�bernommen aus Datei: PROF0058.4500.txt</gml:description>
     <gml:name>0058.4500</gml:name>
     <om:resultDefinition>
      <swe:RecordDefinition gml:id="RecordDefinition11913552127341">
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#Waterlevel"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#Depth"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#Area"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#Runoff"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#Alpha"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#DeltaArea"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#DeltaRunoff"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#DeltaAlpha"/>
      </swe:RecordDefinition>
     </om:resultDefinition>
     <om:result><![CDATA[3.114 0.5340000 2.230000 1.000000 1.000000 -0.01572836 0.1388323 0E-7
3.194 0.6140000 2.903000 1.500000 1.000000 -0.003343259 -0.02571593 0E-7
3.261 0.6810000 3.513000 2.000000 1.000000 0.003251442 -0.09283167 0E-7
3.321 0.7410000 4.081000 2.500000 1.000000 0.01602896 -0.09870568 0E-7
3.374 0.7940000 4.619000 3.000000 1.000000 0.01083388 -0.08560344 0E-7
3.424 0.8440000 5.132000 3.500000 1.000000 0.01558150 -0.04078906 0E-7
3.468 0.8880000 5.602000 4.000000 1.000000 0.01206540 -0.01604329 0E-7
3.508 0.9280000 6.042000 4.500000 1.000000 0.004116223 -0.004616754 0E-7
3.547 0.9670000 6.467000 5.000000 1.000000 0.007024200 0.02363636 0E-7
3.583 1.003000 6.879000 5.500000 1.000000 -0.004636582 0.03572588 0E-7
3.617 1.037000 7.262000 6.000000 1.000000 -0.005194886 0.03977320 0E-7
3.650 1.070000 7.636000 6.500000 1.000000 -0.004259657 0.04699238 0E-7
3.681 1.101000 8.000000 7.000000 1.000000 -0.01291519 0.03884784 0E-7
3.712 1.132000 8.356000 7.500000 1.000000 -0.01072448 0.04491831 0E-7
3.742 1.162000 8.705000 8.000000 1.000000 -0.01053159 0.04760949 0E-7
3.771 1.191000 9.046000 8.500000 1.000000 -0.01171007 0.04514405 0E-7
3.800 1.220000 9.382000 9.000000 1.000000 -0.005758828 0.05363010 0E-7
3.827 1.247000 9.712000 9.500000 1.000000 -0.01554858 0.03652816 0E-7
3.855 1.275000 10.03600 10.00000 1.000000 -0.005661613 0.04662713 0E-7
3.881 1.301000 10.35600 10.50000 1.000000 -0.01400671 0.02850818 0E-7
3.908 1.328000 10.67100 11.00000 1.000000 -0.003745159 0.03704151 0E-7
3.934 1.354000 10.98200 11.50000 1.000000 0.00001445723 0.03433797 0E-7
3.959 1.379000 11.28800 12.00000 1.000000 -0.001906509 0.01935574 0E-7
3.984 1.404000 11.59100 12.50000 1.000000 0.0005760494 0.01093197 0E-7
4.008 1.428000 11.89000 13.00000 1.000000 -0.003826368 -0.01111073 0E-7
4.032 1.452000 12.18600 13.50000 1.000000 -0.003900250 -0.02733917 0E-7
4.056 1.476000 12.47900 14.00000 1.000000 0.0003833761 -0.03784340 0E-7
4.080 1.500000 12.76900 14.50000 1.000000 0.009061228 -0.04269861 0E-7
4.103 1.523000 13.05500 15.00000 1.000000 0.01064354 -0.06294002 0E-7
4.125 1.545000 13.33900 15.50000 1.000000 0.003000778 -0.09927519 0E-7
4.148 1.568000 13.62000 16.00000 1.000000 0.01230666 -0.1095799 0E-7
4.171 1.591000 13.91300 16.50000 1.000000 0.01108813 -0.1148351 0E-7
4.195 1.615000 14.22100 17.00000 1.000000 0.009199486 -0.09319976 0E-7
4.219 1.639000 14.52700 17.50000 1.000000 0.01107007 -0.06605918 0E-7
4.243 1.663000 14.83000 18.00000 1.000000 0.01778922 -0.03338784 0E-7
4.266 1.686000 15.13100 18.50000 1.000000 0.01542779 -0.01768404 0E-7
4.289 1.709000 15.43100 19.00000 1.000000 0.01594530 0.003184556 0E-7
4.311 1.731000 15.72800 19.50000 1.000000 0.008245908 0.006295505 0E-7
4.333 1.753000 16.02400 20.00000 1.000000 0.003447761 0.01425144 0E-7
4.355 1.775000 16.31700 20.50000 1.000000 0.003648251 0.02712680 0E-7
4.377 1.797000 16.60900 21.00000 1.000000 0.006950241 0.04500650 0E-7
4.398 1.818000 16.89900 21.50000 1.000000 0.0008892702 0.04410204 0E-7
4.419 1.839000 17.18800 22.00000 1.000000 -0.002059364 0.04793603 0E-7
4.440 1.860000 17.47500 22.50000 1.000000 -0.0007922516 0.05660902 0E-7
4.460 1.880000 17.76000 23.00000 1.000000 -0.009093433 0.04565822 0E-7
4.480 1.900000 18.04400 23.50000 1.000000 -0.01418990 0.03929729 0E-7
4.500 1.920000 18.32600 24.00000 1.000000 -0.01498085 0.03763511 0E-7
4.520 1.940000 18.60700 24.50000 1.000000 -0.01236171 0.04078771 0E-7
4.539 1.959000 18.88700 25.00000 1.000000 -0.02059261 0.02335447 0E-7
4.559 1.979000 19.16500 25.50000 1.000000 -0.009958958 0.03625669 0E-7
4.578 1.998000 19.44100 26.00000 1.000000 -0.009220639 0.02832693 0E-7
4.596 2.016000 19.71700 26.50000 1.000000 -0.02067365 -0.001061462 0E-7
4.615 2.035000 19.99100 27.00000 1.000000 -0.01282327 0.0005053079 0E-7
4.634 2.054000 20.26400 27.50000 1.000000 -0.001189846 0.007144767 0E-7
4.652 2.072000 20.53600 28.00000 1.000000 -0.0008692121 -0.008074302 0E-7
4.670 2.090000 20.80600 28.50000 1.000000 0.004146041 -0.01848985 0E-7
4.688 2.108000 21.07500 29.00000 1.000000 0.01295542 -0.02397271 0E-7
4.705 2.125000 21.34300 29.50000 1.000000 0.009988377 -0.05227890 0E-7
4.723 2.143000 21.61000 30.00000 1.000000 0.02652483 -0.04778295 0E-7
]]></om:result>
    </tuhh:WPointsObservation>
   </wb1d2d:pointsMember>
   <wb1d2d:polynomialMember>
    <math:Polynomial1D gml:id="Polynomial1D11913552127503">
     <gml:description>Q1(h)</gml:description>
     <gml:name>Q1(h)</gml:name>
     <math:coefficients>5.8357194923 -23.2655534917 32.8765021968 -11.8176850625 1.86320380774</math:coefficients>
     <math:minRange>0.534</math:minRange>
     <math:maxRange>2.143</math:maxRange>
     <math:domainPhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonRunoff"/>
     <math:rangePhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonWaterlevel"/>
    </math:Polynomial1D>
   </wb1d2d:polynomialMember>
   <wb1d2d:polynomialMember>
    <math:Polynomial1D gml:id="Polynomial1D11913552127504">
     <gml:description>A1(h)</gml:description>
     <gml:name>A1(h)</gml:name>
     <math:coefficients>-0.167160885846 -0.469385354706 11.7585714995 -5.25400608715 0.972797000806</math:coefficients>
     <math:minRange>0.534</math:minRange>
     <math:maxRange>2.143</math:maxRange>
     <math:domainPhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonArea"/>
     <math:rangePhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonWaterlevel"/>
    </math:Polynomial1D>
   </wb1d2d:polynomialMember>
   <wb1d2d:polynomialMember>
    <math:Polynomial1D gml:id="Polynomial1D11913552127502">
     <gml:description>al1(h)</gml:description>
     <gml:name>al1(h)</gml:name>
     <math:coefficients>1.0</math:coefficients>
     <math:minRange>0.534</math:minRange>
     <math:maxRange>2.143</math:maxRange>
     <math:domainPhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonAlpha"/>
     <math:rangePhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonWaterlevel"/>
    </math:Polynomial1D>
   </wb1d2d:polynomialMember>
   <wb1d2d:polynomialMember>
    <math:Polynomial1D gml:id="Polynomial1D11913552127500">
     <gml:description>Spl_al</gml:description>
     <gml:name>Spl_al</gml:name>
     <math:coefficients>0.0</math:coefficients>
     <math:minRange>2.143</math:minRange>
     <math:maxRange>2.143</math:maxRange>
     <math:domainPhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonAlpha"/>
     <math:rangePhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonWaterlevel"/>
    </math:Polynomial1D>
   </wb1d2d:polynomialMember>
   <wb1d2d:polynomialMember>
    <math:Polynomial1D gml:id="Polynomial1D11913552127507">
     <gml:description>al2(h)</gml:description>
     <gml:name>al2(h)</gml:name>
     <math:coefficients>0.0</math:coefficients>
     <math:minRange>2.143</math:minRange>
     <math:maxRange>2.143</math:maxRange>
     <math:domainPhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonAlpha"/>
     <math:rangePhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonWaterlevel"/>
    </math:Polynomial1D>
   </wb1d2d:polynomialMember>
   <wb1d2d:station>58.4500</wb1d2d:station>
   <wb1d2d:profileMember xlink:href="terrain.gml#Profile11913552121710"/>
   <wb1d2d:slope>0.00100</wb1d2d:slope>
  </wb1d2d:TeschkeFlowRelation>
 </simBase:flowRelationshipMember>
 <simBase:flowRelationshipMember>
  <wb1d2d:TeschkeFlowRelation gml:id="TeschkeFlowRelation11913552127505">
   <gml:description>Gelesen aus: PROF0058.4900.txt</gml:description>
   <gml:name>58.4900</gml:name>
   <simBase:position>
    <gml:Point xmlns:ns1="http://www.w3.org/2001/SMIL20/" xmlns:st="http://www.seegrid.csiro.au/xml/st" xmlns:ns2="http://www.isotc211.org/2005/gmd" xmlns:ns3="http://www.isotc211.org/2005/gco" xmlns:ns4="http://www.isotc211.org/2005/gts" xmlns:ns5="http://www.isotc211.org/2005/gss" xmlns:ns6="http://www.isotc211.org/2005/gsr" xmlns:ns7="http://www.w3.org/2001/SMIL20/Language" srsName="EPSG:31467">
     <gml:coordinates ts="," decimal="." cs=" ">3552963.458011079 5986930.429892132 2.37</gml:coordinates>
    </gml:Point>
   </simBase:position>
   <wb1d2d:pointsMember>
    <tuhh:WPointsObservation gml:id="WPointsObservation11913552127504">
     <gml:description>�bernommen aus Datei: PROF0058.4900.txt</gml:description>
     <gml:name>0058.4900</gml:name>
     <om:resultDefinition>
      <swe:RecordDefinition gml:id="RecordDefinition11913552127509">
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#Waterlevel"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#Depth"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#Area"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#Runoff"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#Alpha"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#DeltaArea"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#DeltaRunoff"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#DeltaAlpha"/>
      </swe:RecordDefinition>
     </om:resultDefinition>
     <om:result><![CDATA[2.944 0.5740000 2.034000 1.000000 1.000000 -0.03611910 0.2424202 0E-7
3.033 0.6630000 2.663000 1.500000 1.000000 -0.005832890 -0.08775731 0E-7
3.112 0.7420000 3.276000 2.000000 1.000000 0.01739851 -0.1789974 0E-7
3.180 0.8100000 3.843000 2.500000 1.000000 0.03115071 -0.1611963 0E-7
3.236 0.8660000 4.341000 3.000000 1.000000 0.03166968 -0.1349233 0E-7
3.287 0.9170000 4.815000 3.500000 1.000000 0.02598479 -0.08673758 0E-7
3.335 0.9650000 5.271000 4.000000 1.000000 0.02214097 -0.01757089 0E-7
3.379 1.009000 5.700000 4.500000 1.000000 0.01659895 0.04460848 0E-7
3.415 1.045000 6.069000 5.000000 1.000000 0.00006471788 0.03047080 0E-7
3.454 1.084000 6.467000 5.500000 1.000000 -0.01031090 0.08062178 0E-7
3.490 1.120000 6.827000 6.000000 1.000000 -0.007378662 0.1084397 0E-7
3.523 1.153000 7.173000 6.500000 1.000000 -0.01650907 0.1076311 0E-7
3.554 1.184000 7.493000 7.000000 1.000000 -0.01649675 0.08884453 0E-7
3.586 1.216000 7.833000 7.500000 1.000000 -0.02260083 0.09707017 0E-7
3.619 1.249000 8.179000 8.000000 1.000000 -0.02051386 0.1324523 0E-7
3.649 1.279000 8.499000 8.500000 1.000000 -0.02076500 0.1283524 0E-7
3.678 1.308000 8.813000 9.000000 1.000000 -0.02266455 0.1154601 0E-7
3.706 1.336000 9.122000 9.500000 1.000000 -0.02748635 0.09253707 0E-7
3.734 1.364000 9.425000 10.00000 1.000000 -0.02347119 0.07588475 0E-7
3.761 1.391000 9.724000 10.50000 1.000000 -0.02367625 0.04761113 0E-7
3.786 1.416000 10.00400 11.00000 1.000000 -0.02455107 -0.01087655 0E-7
3.814 1.444000 10.31000 11.50000 1.000000 -0.01503658 -0.01117706 0E-7
3.839 1.469000 10.59300 12.00000 1.000000 -0.01365993 -0.06049620 0E-7
3.865 1.495000 10.87900 12.50000 1.000000 -0.001143326 -0.08735307 0E-7
3.887 1.517000 11.13500 13.00000 1.000000 -0.002271970 -0.1835060 0E-7
3.914 1.544000 11.43900 13.50000 1.000000 0.009493011 -0.1835074 0E-7
3.938 1.568000 11.72300 14.00000 1.000000 0.009028706 -0.2350000 0E-7
3.964 1.594000 12.02300 14.50000 1.000000 0.01935843 -0.2447386 0E-7
3.995 1.625000 12.38900 15.00000 1.000000 0.02787668 -0.1540989 0E-7
4.025 1.655000 12.74900 15.50000 1.000000 0.03523219 -0.07597033 0E-7
4.053 1.683000 13.09600 16.00000 1.000000 0.03570460 -0.03031088 0E-7
4.080 1.710000 13.43900 16.50000 1.000000 0.03220724 0.001701267 0E-7
4.107 1.737000 13.77900 17.00000 1.000000 0.03629809 0.03976940 0E-7
4.133 1.763000 14.11600 17.50000 1.000000 0.03520488 0.06397319 0E-7
4.158 1.788000 14.45000 18.00000 1.000000 0.02862396 0.07397171 0E-7
4.182 1.812000 14.78100 18.50000 1.000000 0.01623188 0.06940380 0E-7
4.206 1.836000 15.10100 19.00000 1.000000 0.01923533 0.07090483 0E-7
4.229 1.859000 15.41700 19.50000 1.000000 0.01709279 0.05755551 0E-7
4.252 1.882000 15.74900 20.00000 1.000000 0.003359514 0.05048710 0E-7
4.275 1.905000 16.07900 20.50000 1.000000 -0.003771581 0.05008339 0E-7
4.297 1.927000 16.39800 21.00000 1.000000 -0.009449766 0.03457093 0E-7
4.319 1.949000 16.71500 21.50000 1.000000 -0.008553413 0.02590856 0E-7
4.341 1.971000 17.03800 22.00000 1.000000 -0.008895687 0.02449569 0E-7
4.363 1.993000 17.36900 22.50000 1.000000 -0.01228388 0.03075244 0E-7
4.384 2.014000 17.69700 23.00000 1.000000 -0.02275974 0.02155692 0E-7
4.405 2.035000 18.02300 23.50000 1.000000 -0.02636308 0.02015215 0E-7
4.426 2.056000 18.34600 24.00000 1.000000 -0.02191134 0.02695634 0E-7
4.446 2.076000 18.66700 24.50000 1.000000 -0.02618138 0.01765708 0E-7
4.466 2.096000 18.98700 25.00000 1.000000 -0.02453031 0.01658897 0E-7
4.485 2.115000 19.30400 25.50000 1.000000 -0.03124882 -0.001433135 0E-7
4.504 2.134000 19.61900 26.00000 1.000000 -0.03122351 -0.01130261 0E-7
4.523 2.153000 19.93300 26.50000 1.000000 -0.02530198 -0.01264908 0E-7
4.542 2.172000 20.24400 27.00000 1.000000 -0.01132858 -0.005090682 0E-7
4.560 2.190000 20.55400 27.50000 1.000000 -0.008655030 -0.01567531 0E-7
4.578 2.208000 20.86300 28.00000 1.000000 -0.0001669723 -0.01757072 0E-7
4.596 2.226000 21.16900 28.50000 1.000000 0.01627605 -0.01042361 0E-7
4.613 2.243000 21.47500 29.00000 1.000000 0.01948417 -0.02282175 0E-7
4.630 2.260000 21.77800 29.50000 1.000000 0.03036230 -0.02651778 0E-7
4.647 2.277000 22.08000 30.00000 1.000000 0.04703519 -0.02119127 0E-7
]]></om:result>
    </tuhh:WPointsObservation>
   </wb1d2d:pointsMember>
   <wb1d2d:polynomialMember>
    <math:Polynomial1D gml:id="Polynomial1D11913552127509">
     <gml:description>Q1(h)</gml:description>
     <gml:name>Q1(h)</gml:name>
     <math:coefficients>11.7842689756 -42.6703061833 53.92914418 -22.2995170589 3.68308853395</math:coefficients>
     <math:minRange>0.574</math:minRange>
     <math:maxRange>2.277</math:maxRange>
     <math:domainPhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonRunoff"/>
     <math:rangePhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonWaterlevel"/>
    </math:Polynomial1D>
   </wb1d2d:polynomialMember>
   <wb1d2d:polynomialMember>
    <math:Polynomial1D gml:id="Polynomial1D119135521276510">
     <gml:description>A1(h)</gml:description>
     <gml:name>A1(h)</gml:name>
     <math:coefficients>0.0841254360261 -1.66697719312 11.3333277169 -5.16464503959 1.04348159836</math:coefficients>
     <math:minRange>0.574</math:minRange>
     <math:maxRange>2.277</math:maxRange>
     <math:domainPhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonArea"/>
     <math:rangePhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonWaterlevel"/>
    </math:Polynomial1D>
   </wb1d2d:polynomialMember>
   <wb1d2d:polynomialMember>
    <math:Polynomial1D gml:id="Polynomial1D11913552127652">
     <gml:description>al1(h)</gml:description>
     <gml:name>al1(h)</gml:name>
     <math:coefficients>1.0</math:coefficients>
     <math:minRange>0.574</math:minRange>
     <math:maxRange>2.277</math:maxRange>
     <math:domainPhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonAlpha"/>
     <math:rangePhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonWaterlevel"/>
    </math:Polynomial1D>
   </wb1d2d:polynomialMember>
   <wb1d2d:polynomialMember>
    <math:Polynomial1D gml:id="Polynomial1D119135521276512">
     <gml:description>Spl_al</gml:description>
     <gml:name>Spl_al</gml:name>
     <math:coefficients>0.0</math:coefficients>
     <math:minRange>2.277</math:minRange>
     <math:maxRange>2.277</math:maxRange>
     <math:domainPhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonAlpha"/>
     <math:rangePhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonWaterlevel"/>
    </math:Polynomial1D>
   </wb1d2d:polynomialMember>
   <wb1d2d:polynomialMember>
    <math:Polynomial1D gml:id="Polynomial1D119135521276511">
     <gml:description>al2(h)</gml:description>
     <gml:name>al2(h)</gml:name>
     <math:coefficients>0.0</math:coefficients>
     <math:minRange>2.277</math:minRange>
     <math:maxRange>2.277</math:maxRange>
     <math:domainPhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonAlpha"/>
     <math:rangePhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonWaterlevel"/>
    </math:Polynomial1D>
   </wb1d2d:polynomialMember>
   <wb1d2d:station>58.4900</wb1d2d:station>
   <wb1d2d:profileMember xlink:href="terrain.gml#Profile11913552121717"/>
   <wb1d2d:slope>0.00100</wb1d2d:slope>
  </wb1d2d:TeschkeFlowRelation>
 </simBase:flowRelationshipMember>
 <simBase:flowRelationshipMember>
  <wb1d2d:TeschkeFlowRelation gml:id="TeschkeFlowRelation11913552127659">
   <gml:description>Gelesen aus: PROF0058.5500.txt</gml:description>
   <gml:name>58.5500</gml:name>
   <simBase:position>
    <gml:Point xmlns:ns1="http://www.w3.org/2001/SMIL20/" xmlns:st="http://www.seegrid.csiro.au/xml/st" xmlns:ns2="http://www.isotc211.org/2005/gmd" xmlns:ns3="http://www.isotc211.org/2005/gco" xmlns:ns4="http://www.isotc211.org/2005/gts" xmlns:ns5="http://www.isotc211.org/2005/gss" xmlns:ns6="http://www.isotc211.org/2005/gsr" xmlns:ns7="http://www.w3.org/2001/SMIL20/Language" srsName="EPSG:31467">
     <gml:coordinates ts="," decimal="." cs=" ">3552926.392411141 5986951.996892079 2.61</gml:coordinates>
    </gml:Point>
   </simBase:position>
   <wb1d2d:pointsMember>
    <tuhh:WPointsObservation gml:id="WPointsObservation11913552127657">
     <gml:description>�bernommen aus Datei: PROF0058.5500.txt</gml:description>
     <gml:name>0058.5500</gml:name>
     <om:resultDefinition>
      <swe:RecordDefinition gml:id="RecordDefinition11913552127653">
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#Waterlevel"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#Depth"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#Area"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#Runoff"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#Alpha"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#DeltaArea"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#DeltaRunoff"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#DeltaAlpha"/>
      </swe:RecordDefinition>
     </om:resultDefinition>
     <om:result><![CDATA[3.043 0.4330000 2.179000 1.000000 1.000000 0.03225608 0.1341124 0E-7
3.125 0.5150000 2.825000 1.500000 1.000000 -0.008385569 -0.02530730 0E-7
3.194 0.5840000 3.408000 2.000000 1.000000 -0.02504821 -0.09341463 0E-7
3.256 0.6460000 3.951000 2.500000 1.000000 -0.02167538 -0.1048541 0E-7
3.312 0.7020000 4.464000 3.000000 1.000000 -0.01510416 -0.09010014 0E-7
3.364 0.7540000 4.953000 3.500000 1.000000 -0.002561785 -0.05547964 0E-7
3.412 0.8020000 5.423000 4.000000 1.000000 0.004546074 -0.01771358 0E-7
3.457 0.8470000 5.878000 4.500000 1.000000 0.007598346 0.02200288 0E-7
3.499 0.8890000 6.319000 5.000000 1.000000 0.002375602 0.05455555 0E-7
3.538 0.9280000 6.728000 5.500000 1.000000 0.004356709 0.07236000 0E-7
3.573 0.9630000 7.106000 6.000000 1.000000 -0.0001630468 0.05505245 0E-7
3.608 0.9980000 7.479000 6.500000 1.000000 0.004298448 0.05389448 0E-7
3.642 1.032000 7.849000 7.000000 1.000000 0.004458204 0.05323944 0E-7
3.675 1.065000 8.210000 7.500000 1.000000 0.005755729 0.05122895 0E-7
3.707 1.097000 8.564000 8.000000 1.000000 0.005726722 0.04621493 0E-7
3.739 1.129000 8.912000 8.500000 1.000000 0.01416193 0.05273083 0E-7
3.769 1.159000 9.255000 9.000000 1.000000 0.007462074 0.03779149 0E-7
3.799 1.189000 9.592000 9.500000 1.000000 0.008775569 0.03252266 0E-7
3.828 1.218000 9.924000 10.00000 1.000000 0.005698786 0.01981650 0E-7
3.857 1.247000 10.25100 10.50000 1.000000 0.009477125 0.01592082 0E-7
3.885 1.275000 10.57400 11.00000 1.000000 0.007633953 0.003235834 0E-7
3.912 1.302000 10.89300 11.50000 1.000000 0.00002492359 -0.01911612 0E-7
3.940 1.330000 11.20800 12.00000 1.000000 0.009782312 -0.01571899 0E-7
3.966 1.356000 11.52000 12.50000 1.000000 0.001092004 -0.04086923 0E-7
3.992 1.382000 11.82800 13.00000 1.000000 -0.001822342 -0.05879480 0E-7
4.018 1.408000 12.13300 13.50000 1.000000 0.0001454121 -0.06937960 0E-7
4.043 1.433000 12.43500 14.00000 1.000000 -0.004804239 -0.09173126 0E-7
4.069 1.459000 12.74800 14.50000 1.000000 -0.006772628 -0.08747136 0E-7
4.095 1.485000 13.06300 15.00000 1.000000 -0.008447080 -0.07536121 0E-7
4.121 1.511000 13.37500 15.50000 1.000000 -0.004655612 -0.05517284 0E-7
4.146 1.536000 13.68500 16.00000 1.000000 -0.008509058 -0.04713529 0E-7
4.171 1.561000 13.99300 16.50000 1.000000 -0.007726188 -0.03113983 0E-7
4.195 1.585000 14.29800 17.00000 1.000000 -0.01363224 -0.02804091 0E-7
4.219 1.609000 14.60200 17.50000 1.000000 -0.01574173 -0.01708766 0E-7
4.242 1.632000 14.90300 18.00000 1.000000 -0.02462257 -0.01978931 0E-7
4.266 1.656000 15.20200 18.50000 1.000000 -0.01567040 0.007393122 0E-7
4.289 1.679000 15.49900 19.00000 1.000000 -0.01434560 0.02082542 0E-7
4.311 1.701000 15.79400 19.50000 1.000000 -0.02086504 0.01974365 0E-7
4.334 1.724000 16.08700 20.00000 1.000000 -0.008795431 0.04981421 0E-7
4.356 1.746000 16.37800 20.50000 1.000000 -0.004459690 0.06525174 0E-7
4.377 1.767000 16.66800 21.00000 1.000000 -0.009136462 0.06522443 0E-7
4.399 1.789000 16.95600 21.50000 1.000000 0.005554217 0.09766188 0E-7
4.419 1.809000 17.23400 22.00000 1.000000 0.006268954 0.08966355 0E-7
4.439 1.829000 17.50500 22.50000 1.000000 0.01753550 0.08952749 0E-7
4.457 1.847000 17.75700 23.00000 1.000560 0.02276022 0.04635466 -0.0005600000
4.475 1.865000 18.02500 23.50000 1.001040 0.01514171 0.009980741 -0.000005882877
4.494 1.884000 18.29500 24.00000 1.001640 0.02356667 0.006976449 0.00001047813
4.512 1.902000 18.56700 24.50000 1.002320 0.01887632 -0.01474249 0.000007998538
4.530 1.920000 18.84200 25.00000 1.003100 0.01477798 -0.02898805 -0.000009551665
4.548 1.938000 19.11800 25.50000 1.003950 0.01342185 -0.03552635 -0.00001813449
4.566 1.956000 19.39600 26.00000 1.004850 0.01396191 -0.03411700 -0.000003646216
4.584 1.974000 19.67500 26.50000 1.005800 0.01755599 -0.02451314 0.00002808266
4.601 1.991000 19.95700 27.00000 1.006810 0.006318459 -0.03546809 0.000001815983
4.618 2.008000 20.24000 27.50000 1.007840 -0.002019548 -0.03866906 0.000005581226
4.635 2.025000 20.52400 28.00000 1.008950 -0.007315699 -0.03389215 -0.00002537178
4.652 2.042000 20.80900 28.50000 1.010050 -0.009424627 -0.02090828 -0.000005740888
4.669 2.059000 21.09700 29.00000 1.011180 -0.01019792 0.0005167734 0.00001982837
4.685 2.075000 21.38400 29.50000 1.012320 -0.02277074 -0.0008049306 -0.000003861835
4.702 2.092000 21.67400 30.00000 1.013530 -0.01669277 0.03769396 -0.000001595154
]]></om:result>
    </tuhh:WPointsObservation>
   </wb1d2d:pointsMember>
   <wb1d2d:polynomialMember>
    <math:Polynomial1D gml:id="Polynomial1D11913552127651">
     <gml:description>Q1(h)</gml:description>
     <gml:name>Q1(h)</gml:name>
     <math:coefficients>3.62502393851 -16.4363658032 29.8204664076 -13.0015565204 2.57530358554</math:coefficients>
     <math:minRange>0.433</math:minRange>
     <math:maxRange>2.092</math:maxRange>
     <math:domainPhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonRunoff"/>
     <math:rangePhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonWaterlevel"/>
    </math:Polynomial1D>
   </wb1d2d:polynomialMember>
   <wb1d2d:polynomialMember>
    <math:Polynomial1D gml:id="Polynomial1D119135521276514">
     <gml:description>A1(h)</gml:description>
     <gml:name>A1(h)</gml:name>
     <math:coefficients>0.880846019122 -1.8568173918 14.2574944628 -7.29196572203 1.51542310734</math:coefficients>
     <math:minRange>0.433</math:minRange>
     <math:maxRange>2.092</math:maxRange>
     <math:domainPhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonArea"/>
     <math:rangePhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonWaterlevel"/>
    </math:Polynomial1D>
   </wb1d2d:polynomialMember>
   <wb1d2d:polynomialMember>
    <math:Polynomial1D gml:id="Polynomial1D11913552127659">
     <gml:description>al1(h)</gml:description>
     <gml:name>al1(h)</gml:name>
     <math:coefficients>1.0</math:coefficients>
     <math:minRange>0.433</math:minRange>
     <math:maxRange>1.847</math:maxRange>
     <math:domainPhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonAlpha"/>
     <math:rangePhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonWaterlevel"/>
    </math:Polynomial1D>
   </wb1d2d:polynomialMember>
   <wb1d2d:polynomialMember>
    <math:Polynomial1D gml:id="Polynomial1D119135521276523">
     <gml:description>Spl_al</gml:description>
     <gml:name>Spl_al</gml:name>
     <math:coefficients>1685.99659823 -2722.22193829 1465.93329776 -263.13034327</math:coefficients>
     <math:minRange>1.847</math:minRange>
     <math:maxRange>1.865</math:maxRange>
     <math:domainPhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonAlpha"/>
     <math:rangePhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonWaterlevel"/>
    </math:Polynomial1D>
   </wb1d2d:polynomialMember>
   <wb1d2d:polynomialMember>
    <math:Polynomial1D gml:id="Polynomial1D119135521276520">
     <gml:description>al2(h)</gml:description>
     <gml:name>al2(h)</gml:name>
     <math:coefficients>2.92063829144 -3.0361552599 1.67514044517 -0.369892477553 0.0261002151308</math:coefficients>
     <math:minRange>1.865</math:minRange>
     <math:maxRange>2.092</math:maxRange>
     <math:domainPhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonAlpha"/>
     <math:rangePhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonWaterlevel"/>
    </math:Polynomial1D>
   </wb1d2d:polynomialMember>
   <wb1d2d:station>58.5500</wb1d2d:station>
   <wb1d2d:profileMember xlink:href="terrain.gml#Profile11913552121870"/>
   <wb1d2d:slope>0.00100</wb1d2d:slope>
  </wb1d2d:TeschkeFlowRelation>
 </simBase:flowRelationshipMember>
 <simBase:flowRelationshipMember>
  <wb1d2d:TeschkeFlowRelation gml:id="TeschkeFlowRelation119135521276523">
   <gml:description>Gelesen aus: PROF0058.6000.txt</gml:description>
   <gml:name>58.6000</gml:name>
   <simBase:position>
    <gml:Point xmlns:ns1="http://www.w3.org/2001/SMIL20/" xmlns:st="http://www.seegrid.csiro.au/xml/st" xmlns:ns2="http://www.isotc211.org/2005/gmd" xmlns:ns3="http://www.isotc211.org/2005/gco" xmlns:ns4="http://www.isotc211.org/2005/gts" xmlns:ns5="http://www.isotc211.org/2005/gss" xmlns:ns6="http://www.isotc211.org/2005/gsr" xmlns:ns7="http://www.w3.org/2001/SMIL20/Language" srsName="EPSG:31467">
     <gml:coordinates ts="," decimal="." cs=" ">3552898.837911187 5986989.242391991 2.76</gml:coordinates>
    </gml:Point>
   </simBase:position>
   <wb1d2d:pointsMember>
    <tuhh:WPointsObservation gml:id="WPointsObservation119135521276512">
     <gml:description>�bernommen aus Datei: PROF0058.6000.txt</gml:description>
     <gml:name>0058.6000</gml:name>
     <om:resultDefinition>
      <swe:RecordDefinition gml:id="RecordDefinition119135521276522">
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#Waterlevel"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#Depth"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#Area"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#Runoff"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#Alpha"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#DeltaArea"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#DeltaRunoff"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#DeltaAlpha"/>
      </swe:RecordDefinition>
     </om:resultDefinition>
     <om:result><![CDATA[3.086 0.3260000 2.420000 1.000000 1.000000 0.02174693 0.07911492 0E-7
3.164 0.4040000 3.181000 1.500000 1.000000 -0.008297384 0.05188661 0E-7
3.216 0.4560000 3.703000 2.000000 1.000000 -0.01223126 -0.05125374 0E-7
3.270 0.5100000 4.270000 2.500000 1.000000 -0.01845666 -0.07296854 0E-7
3.320 0.5600000 4.803000 3.000000 1.000000 -0.01385715 -0.07225003 0E-7
3.364 0.6040000 5.286000 3.500000 1.000000 -0.01080718 -0.08724482 0E-7
3.408 0.6480000 5.769000 4.000000 1.000000 0.003040858 -0.06210272 0E-7
3.449 0.6890000 6.234000 4.500000 1.000000 0.009683736 -0.03779313 0E-7
3.488 0.7280000 6.684000 5.000000 1.000000 0.01524259 -0.008718850 0E-7
3.525 0.7650000 7.120000 5.500000 1.000000 0.01701543 0.01976362 0E-7
3.562 0.8020000 7.564000 6.000000 1.000000 0.01563904 0.07334728 0E-7
3.595 0.8350000 7.969000 6.500000 1.000000 0.009076297 0.08768256 0E-7
3.625 0.8650000 8.339000 7.000000 1.000000 0.003988207 0.07167984 0E-7
3.654 0.8940000 8.701000 7.500000 1.000000 -0.003055109 0.05405461 0E-7
3.683 0.9230000 9.055000 8.000000 1.000000 -0.0001287392 0.05036769 0E-7
3.711 0.9510000 9.401000 8.500000 1.000000 0.0001872648 0.04249501 0E-7
3.738 0.9780000 9.741000 9.000000 1.000000 -0.004428205 0.02881061 0E-7
3.765 1.005000 10.07500 9.500000 1.000000 -0.001756682 0.02642719 0E-7
3.791 1.031000 10.40300 10.00000 1.000000 -0.004440910 0.01606865 0E-7
3.817 1.057000 10.72500 10.50000 1.000000 -0.0001213808 0.01575325 0E-7
3.842 1.082000 11.04300 11.00000 1.000000 -0.003477878 0.005496583 0E-7
3.867 1.107000 11.35600 11.50000 1.000000 -0.001037089 0.004151274 0E-7
3.891 1.131000 11.66500 12.00000 1.000000 -0.006510755 -0.008921989 0E-7
3.915 1.155000 11.96900 12.50000 1.000000 -0.006333057 -0.01410183 0E-7
3.939 1.179000 12.26900 13.00000 1.000000 -0.001533256 -0.01154037 0E-7
3.962 1.202000 12.56600 13.50000 1.000000 -0.005869797 -0.02279296 0E-7
3.985 1.225000 12.86000 14.00000 1.000000 -0.006667439 -0.02720204 0E-7
4.008 1.248000 13.15000 14.50000 1.000000 -0.002932271 -0.02489422 0E-7
4.031 1.271000 13.43800 15.00000 1.000000 0.003336032 -0.01599377 0E-7
4.053 1.293000 13.72300 15.50000 1.000000 0.0003150835 -0.02316293 0E-7
4.075 1.315000 14.00400 16.00000 1.000000 0.001799438 -0.02451644 0E-7
4.097 1.337000 14.28800 16.50000 1.000000 0.0008058573 -0.02015696 0E-7
4.119 1.359000 14.57100 17.00000 1.000000 0.001356476 -0.01018516 0E-7
4.140 1.380000 14.84400 17.50000 1.000000 -0.0004487019 -0.01824914 0E-7
4.161 1.401000 15.11300 18.00000 1.000000 0.002295481 -0.02137352 0E-7
4.181 1.421000 15.37700 18.50000 1.000000 -0.002359698 -0.04364178 0E-7
4.201 1.441000 15.63800 19.00000 1.000000 -0.003454522 -0.06157441 0E-7
4.221 1.461000 15.89800 19.50000 1.000000 -0.002953105 -0.07523996 0E-7
4.242 1.482000 16.17000 20.00000 1.000000 -0.0007415813 -0.06006981 0E-7
4.263 1.503000 16.44200 20.50000 1.000000 0.002221084 -0.04034542 0E-7
4.284 1.524000 16.71300 21.00000 1.000000 0.006989492 -0.01614129 0E-7
4.304 1.544000 16.98100 21.50000 1.000000 0.002429162 -0.01280114 0E-7
4.324 1.564000 17.24600 22.00000 1.000000 0.001707978 -0.005525406 0E-7
4.344 1.584000 17.51000 22.50000 1.000000 0.002884387 0.005625688 0E-7
4.364 1.604000 17.77400 23.00000 1.000000 0.005020501 0.02059329 0E-7
4.385 1.625000 18.06000 23.50000 1.000000 -0.0004316679 0.06535388 0E-7
4.404 1.644000 18.31900 24.00000 1.000000 -0.004561358 0.06174935 0E-7
4.423 1.663000 18.57500 24.50000 1.000000 -0.004636906 0.06143718 0E-7
4.442 1.682000 18.82200 25.00000 1.000000 0.005407445 0.06437153 0E-7
4.461 1.701000 19.08000 25.50000 1.000000 0.005640438 0.07050765 0E-7
4.479 1.719000 19.33600 26.00000 1.000000 -0.004556360 0.05291889 0E-7
4.498 1.738000 19.59000 26.50000 1.000000 0.002199919 0.06516578 0E-7
4.516 1.756000 19.84400 27.00000 1.000000 -0.003469730 0.05329065 0E-7
4.535 1.775000 20.09900 27.50000 1.000000 0.005103920 0.07149095 0E-7
4.550 1.790000 20.30900 28.00000 1.000340 0.004291895 -0.01728348 -0.0003400000
4.568 1.808000 20.56400 28.50000 1.000480 0.001667281 -0.02137233 -0.0004800000
4.585 1.825000 20.80800 29.00000 1.000630 -0.002561968 -0.05059426 -0.0006300000
4.602 1.842000 21.05100 29.50000 1.000790 -0.004348746 -0.07749429 -0.0007900000
4.619 1.859000 21.29400 30.00000 1.000960 -0.004625681 -0.1020978 -0.0009600000
]]></om:result>
    </tuhh:WPointsObservation>
   </wb1d2d:pointsMember>
   <wb1d2d:polynomialMember>
    <math:Polynomial1D gml:id="Polynomial1D119135521276528">
     <gml:description>Q1(h)</gml:description>
     <gml:name>Q1(h)</gml:name>
     <math:coefficients>0.876321984508 -4.18682067694 15.8369611045 -3.44553056414 0.352502607593</math:coefficients>
     <math:minRange>0.326</math:minRange>
     <math:maxRange>1.859</math:maxRange>
     <math:domainPhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonRunoff"/>
     <math:rangePhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonWaterlevel"/>
    </math:Polynomial1D>
   </wb1d2d:polynomialMember>
   <wb1d2d:polynomialMember>
    <math:Polynomial1D gml:id="Polynomial1D119135521276517">
     <gml:description>A1(h)</gml:description>
     <gml:name>A1(h)</gml:name>
     <math:coefficients>0.20150253701 4.32532421173 9.24887312179 -4.72013064868 0.955235605865</math:coefficients>
     <math:minRange>0.326</math:minRange>
     <math:maxRange>1.859</math:maxRange>
     <math:domainPhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonArea"/>
     <math:rangePhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonWaterlevel"/>
    </math:Polynomial1D>
   </wb1d2d:polynomialMember>
   <wb1d2d:polynomialMember>
    <math:Polynomial1D gml:id="Polynomial1D119135521276521">
     <gml:description>al1(h)</gml:description>
     <gml:name>al1(h)</gml:name>
     <math:coefficients>1.0</math:coefficients>
     <math:minRange>0.326</math:minRange>
     <math:maxRange>1.859</math:maxRange>
     <math:domainPhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonAlpha"/>
     <math:rangePhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonWaterlevel"/>
    </math:Polynomial1D>
   </wb1d2d:polynomialMember>
   <wb1d2d:polynomialMember>
    <math:Polynomial1D gml:id="Polynomial1D119135521276531">
     <gml:description>Spl_al</gml:description>
     <gml:name>Spl_al</gml:name>
     <math:coefficients>0.0</math:coefficients>
     <math:minRange>1.859</math:minRange>
     <math:maxRange>1.859</math:maxRange>
     <math:domainPhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonAlpha"/>
     <math:rangePhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonWaterlevel"/>
    </math:Polynomial1D>
   </wb1d2d:polynomialMember>
   <wb1d2d:polynomialMember>
    <math:Polynomial1D gml:id="Polynomial1D119135521276527">
     <gml:description>al2(h)</gml:description>
     <gml:name>al2(h)</gml:name>
     <math:coefficients>0.0</math:coefficients>
     <math:minRange>1.859</math:minRange>
     <math:maxRange>1.859</math:maxRange>
     <math:domainPhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonAlpha"/>
     <math:rangePhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonWaterlevel"/>
    </math:Polynomial1D>
   </wb1d2d:polynomialMember>
   <wb1d2d:station>58.6000</wb1d2d:station>
   <wb1d2d:profileMember xlink:href="terrain.gml#Profile11913552122031"/>
   <wb1d2d:slope>0.00100</wb1d2d:slope>
  </wb1d2d:TeschkeFlowRelation>
 </simBase:flowRelationshipMember>
 <simBase:flowRelationshipMember>
  <wb1d2d:TeschkeFlowRelation gml:id="TeschkeFlowRelation119135521276529">
   <gml:description>Gelesen aus: PROF0058.6500.txt</gml:description>
   <gml:name>58.6500</gml:name>
   <simBase:position>
    <gml:Point xmlns:ns1="http://www.w3.org/2001/SMIL20/" xmlns:st="http://www.seegrid.csiro.au/xml/st" xmlns:ns2="http://www.isotc211.org/2005/gmd" xmlns:ns3="http://www.isotc211.org/2005/gco" xmlns:ns4="http://www.isotc211.org/2005/gts" xmlns:ns5="http://www.isotc211.org/2005/gss" xmlns:ns6="http://www.isotc211.org/2005/gsr" xmlns:ns7="http://www.w3.org/2001/SMIL20/Language" srsName="EPSG:31467">
     <gml:coordinates ts="," decimal="." cs=" ">3552881.1650112164 5987029.225391896 2.54</gml:coordinates>
    </gml:Point>
   </simBase:position>
   <wb1d2d:pointsMember>
    <tuhh:WPointsObservation gml:id="WPointsObservation119135521276514">
     <gml:description>�bernommen aus Datei: PROF0058.6500.txt</gml:description>
     <gml:name>0058.6500</gml:name>
     <om:resultDefinition>
      <swe:RecordDefinition gml:id="RecordDefinition11913552127654">
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#Waterlevel"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#Depth"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#Area"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#Runoff"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#Alpha"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#DeltaArea"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#DeltaRunoff"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#DeltaAlpha"/>
      </swe:RecordDefinition>
     </om:resultDefinition>
     <om:result><![CDATA[2.911 0.3710000 2.310000 1.000000 1.000000 0.004679479 0.01420584 0E-7
2.982 0.4420000 2.949000 1.500000 1.000000 -0.002178559 0.003629451 0E-7
3.043 0.5030000 3.516000 2.000000 1.000000 -0.005451329 -0.005092169 0E-7
3.098 0.5580000 4.039000 2.500000 1.000000 -0.005213698 -0.007454008 0E-7
3.145 0.6050000 4.490000 3.000000 1.000000 0.001308485 -0.04202292 0E-7
3.195 0.6550000 4.990000 3.500000 1.000000 -0.002206182 -0.007090322 0E-7
3.239 0.6990000 5.434000 4.000000 1.000000 -0.001538329 -0.003083765 0E-7
3.281 0.7410000 5.859000 4.500000 1.000000 0.004248245 0.006505574 0E-7
3.317 0.7770000 6.232000 5.000000 1.000000 0.005121678 -0.03494057 0E-7
3.359 0.8190000 6.673000 5.500000 1.000000 0.005388426 0.02498808 0E-7
3.396 0.8560000 7.062000 6.000000 1.000000 0.009400806 0.04014484 0E-7
3.431 0.8910000 7.441000 6.500000 1.000000 0.005650840 0.04600611 0E-7
3.463 0.9230000 7.789000 7.000000 1.000000 0.003548436 0.02404558 0E-7
3.494 0.9540000 8.132000 7.500000 1.000000 -0.001923171 0.001090646 0E-7
3.527 0.9870000 8.494000 8.000000 1.000000 -0.002100526 0.02377210 0E-7
3.557 1.017000 8.830000 8.500000 1.000000 -0.007016257 0.01204249 0E-7
3.587 1.047000 9.159000 9.000000 1.000000 -0.002967020 0.01261439 0E-7
3.614 1.074000 9.466000 9.500000 1.000000 -0.008607475 -0.02649616 0E-7
3.641 1.101000 9.765000 10.00000 1.000000 -0.004772830 -0.05590819 0E-7
3.672 1.132000 10.11700 10.50000 1.000000 -0.007318244 -0.003804886 0E-7
3.700 1.160000 10.42600 11.00000 1.000000 0.0008768756 0.005560195 0E-7
3.727 1.187000 10.73200 11.50000 1.000000 0.002100262 0.006210423 0E-7
3.753 1.213000 11.03300 12.00000 1.000000 -0.001831234 -0.003004188 0E-7
3.779 1.239000 11.33100 12.50000 1.000000 -0.001592284 -0.003815360 0E-7
3.804 1.264000 11.62300 13.00000 1.000000 -0.005745012 -0.01600241 0E-7
3.829 1.289000 11.90400 13.50000 1.000000 0.002139106 -0.02061659 0E-7
3.853 1.313000 12.18500 14.00000 1.000000 -0.0005733569 -0.03801045 0E-7
3.877 1.337000 12.46300 14.50000 1.000000 0.0006397348 -0.04859754 0E-7
3.902 1.362000 12.75200 15.00000 1.000000 0.003458997 -0.03164473 0E-7
3.928 1.388000 13.05400 15.50000 1.000000 0.005993176 0.01362316 0E-7
3.951 1.411000 13.33100 16.00000 1.000000 -0.0007316688 0.002382889 0E-7
3.975 1.435000 13.60600 16.50000 1.000000 0.007171175 0.01872403 0E-7
3.998 1.458000 13.87900 17.00000 1.000000 0.006125215 0.01954313 0E-7
4.020 1.480000 14.14900 17.50000 1.000000 -0.002975887 0.004007787 0E-7
4.043 1.503000 14.41700 18.00000 1.000000 0.002588649 0.01609109 0E-7
4.065 1.525000 14.68300 18.50000 1.000000 -0.0009650762 0.01119916 0E-7
4.087 1.547000 14.94700 19.00000 1.000000 -0.001754243 0.01141580 0E-7
4.109 1.569000 15.20900 19.50000 1.000000 0.0002287061 0.01667906 0E-7
4.131 1.591000 15.46900 20.00000 1.000000 0.004993005 0.02692728 0E-7
4.152 1.612000 15.72500 20.50000 1.000000 0.002461452 0.01857622 0E-7
4.173 1.633000 15.98000 21.00000 1.000000 0.001662679 0.01465814 0E-7
4.194 1.654000 16.23300 21.50000 1.000000 0.003608994 0.01512012 0E-7
4.214 1.674000 16.48500 22.00000 1.000000 -0.004879759 -0.004225489 0E-7
4.235 1.695000 16.73500 22.50000 1.000000 0.001562012 0.004636341 0E-7
4.255 1.715000 16.98400 23.00000 1.000000 -0.002473936 -0.006804462 0E-7
4.275 1.735000 17.23300 23.50000 1.000000 -0.005778389 -0.01445791 0E-7
4.296 1.756000 17.48800 24.00000 1.000000 -0.001992719 0.006533150 0E-7
4.316 1.776000 17.74000 24.50000 1.000000 -0.006744757 0.006504071 0E-7
4.336 1.796000 17.98500 25.00000 1.000000 -0.003711381 0.01012642 0E-7
4.356 1.816000 18.22700 25.50000 1.000000 0.003127407 0.01735603 0E-7
4.374 1.834000 18.45200 26.00000 1.000000 0.002788396 -0.02308950 0E-7
4.393 1.853000 18.69300 26.50000 1.000000 -0.0003252088 -0.03490831 0E-7
4.414 1.874000 18.95200 27.00000 1.000000 0.004514822 0.008315317 0E-7
4.431 1.891000 19.17100 27.50000 1.000000 -0.0001795558 -0.04915473 0E-7
4.451 1.911000 19.42900 28.00000 1.000000 -0.005206757 -0.02538831 0E-7
4.470 1.930000 19.66500 28.50000 1.000000 -0.000009905916 -0.02470028 0E-7
4.489 1.949000 19.91100 29.00000 1.000000 -0.003938584 -0.02101949 0E-7
4.510 1.970000 20.17400 29.50000 1.000000 0.001661076 0.03911806 0E-7
4.529 1.989000 20.41400 30.00000 1.000000 0.005655199 0.04897977 0E-7
]]></om:result>
    </tuhh:WPointsObservation>
   </wb1d2d:pointsMember>
   <wb1d2d:polynomialMember>
    <math:Polynomial1D gml:id="Polynomial1D119135521278120">
     <gml:description>Q1(h)</gml:description>
     <gml:name>Q1(h)</gml:name>
     <math:coefficients>-0.00210325259028 -0.949101429736 10.4066429543 -1.27060959135 0.0490057695136</math:coefficients>
     <math:minRange>0.371</math:minRange>
     <math:maxRange>1.989</math:maxRange>
     <math:domainPhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonRunoff"/>
     <math:rangePhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonWaterlevel"/>
    </math:Polynomial1D>
   </wb1d2d:polynomialMember>
   <wb1d2d:polynomialMember>
    <math:Polynomial1D gml:id="Polynomial1D11913552127817">
     <gml:description>A1(h)</gml:description>
     <gml:name>A1(h)</gml:name>
     <math:coefficients>-0.45951169096 6.03942002341 4.47161213748 -1.71474186768 0.298344210042</math:coefficients>
     <math:minRange>0.371</math:minRange>
     <math:maxRange>1.989</math:maxRange>
     <math:domainPhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonArea"/>
     <math:rangePhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonWaterlevel"/>
    </math:Polynomial1D>
   </wb1d2d:polynomialMember>
   <wb1d2d:polynomialMember>
    <math:Polynomial1D gml:id="Polynomial1D119135521278121">
     <gml:description>al1(h)</gml:description>
     <gml:name>al1(h)</gml:name>
     <math:coefficients>1.0</math:coefficients>
     <math:minRange>0.371</math:minRange>
     <math:maxRange>1.989</math:maxRange>
     <math:domainPhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonAlpha"/>
     <math:rangePhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonWaterlevel"/>
    </math:Polynomial1D>
   </wb1d2d:polynomialMember>
   <wb1d2d:polynomialMember>
    <math:Polynomial1D gml:id="Polynomial1D119135521278136">
     <gml:description>Spl_al</gml:description>
     <gml:name>Spl_al</gml:name>
     <math:coefficients>0.0</math:coefficients>
     <math:minRange>1.989</math:minRange>
     <math:maxRange>1.989</math:maxRange>
     <math:domainPhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonAlpha"/>
     <math:rangePhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonWaterlevel"/>
    </math:Polynomial1D>
   </wb1d2d:polynomialMember>
   <wb1d2d:polynomialMember>
    <math:Polynomial1D gml:id="Polynomial1D11913552127813">
     <gml:description>al2(h)</gml:description>
     <gml:name>al2(h)</gml:name>
     <math:coefficients>0.0</math:coefficients>
     <math:minRange>1.989</math:minRange>
     <math:maxRange>1.989</math:maxRange>
     <math:domainPhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonAlpha"/>
     <math:rangePhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonWaterlevel"/>
    </math:Polynomial1D>
   </wb1d2d:polynomialMember>
   <wb1d2d:station>58.6500</wb1d2d:station>
   <wb1d2d:profileMember xlink:href="terrain.gml#Profile119135521221811"/>
   <wb1d2d:slope>0.00100</wb1d2d:slope>
  </wb1d2d:TeschkeFlowRelation>
 </simBase:flowRelationshipMember>
 <simBase:flowRelationshipMember>
  <wb1d2d:TeschkeFlowRelation gml:id="TeschkeFlowRelation11913552127816">
   <gml:description>Gelesen aus: PROF0058.7000.txt</gml:description>
   <gml:name>58.7000</gml:name>
   <simBase:position>
    <gml:Point xmlns:ns1="http://www.w3.org/2001/SMIL20/" xmlns:st="http://www.seegrid.csiro.au/xml/st" xmlns:ns2="http://www.isotc211.org/2005/gmd" xmlns:ns3="http://www.isotc211.org/2005/gco" xmlns:ns4="http://www.isotc211.org/2005/gts" xmlns:ns5="http://www.isotc211.org/2005/gss" xmlns:ns6="http://www.isotc211.org/2005/gsr" xmlns:ns7="http://www.w3.org/2001/SMIL20/Language" srsName="EPSG:31467">
     <gml:coordinates ts="," decimal="." cs=" ">3552862.529711248 5987080.641091775 2.68</gml:coordinates>
    </gml:Point>
   </simBase:position>
   <wb1d2d:pointsMember>
    <tuhh:WPointsObservation gml:id="WPointsObservation119135521278129">
     <gml:description>�bernommen aus Datei: PROF0058.7000.txt</gml:description>
     <gml:name>0058.7000</gml:name>
     <om:resultDefinition>
      <swe:RecordDefinition gml:id="RecordDefinition119135521278117">
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#Waterlevel"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#Depth"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#Area"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#Runoff"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#Alpha"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#DeltaArea"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#DeltaRunoff"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#DeltaAlpha"/>
      </swe:RecordDefinition>
     </om:resultDefinition>
     <om:result><![CDATA[3.021 0.3410000 2.302000 1.000000 1.000000 -0.01062573 -0.005443331 0E-7
3.094 0.4140000 2.966000 1.500000 1.000000 -0.0003555906 -0.007000911 0E-7
3.156 0.4760000 3.556000 2.000000 1.000000 0.007552873 -0.002610753 0E-7
3.210 0.5300000 4.099000 2.500000 1.000000 0.002150561 -0.004070518 0E-7
3.259 0.5790000 4.598000 3.000000 1.000000 0.003193249 -0.005002955 0E-7
3.305 0.6250000 5.071000 3.500000 1.000000 0.009220754 0.003103052 0E-7
3.348 0.6680000 5.524000 4.000000 1.000000 0.01166678 0.01205447 0E-7
3.388 0.7080000 5.961000 4.500000 1.000000 0.004413867 0.01440579 0E-7
3.427 0.7470000 6.383000 5.000000 1.000000 0.006588635 0.03051283 0E-7
3.463 0.7830000 6.790000 5.500000 1.000000 -0.004695519 0.02954849 0E-7
3.497 0.8170000 7.167000 6.000000 1.000000 -0.004571471 0.02044066 0E-7
3.530 0.8500000 7.534000 6.500000 1.000000 -0.002620454 0.01475827 0E-7
3.561 0.8810000 7.892000 7.000000 1.000000 -0.01159668 -0.005136559 0E-7
3.592 0.9120000 8.242000 7.500000 1.000000 -0.01037829 -0.01004698 0E-7
3.622 0.9420000 8.584000 8.000000 1.000000 -0.01053966 -0.01691295 0E-7
3.652 0.9720000 8.920000 8.500000 1.000000 -0.002909111 -0.01024201 0E-7
3.680 1.000000 9.249000 9.000000 1.000000 -0.009672078 -0.02535530 0E-7
3.708 1.028000 9.573000 9.500000 1.000000 -0.01006015 -0.02909789 0E-7
3.736 1.056000 9.891000 10.00000 1.000000 -0.003151890 -0.02167688 0E-7
3.763 1.083000 10.20500 10.50000 1.000000 -0.002686532 -0.02200134 0E-7
3.790 1.110000 10.51400 11.00000 1.000000 0.003860446 -0.01232996 0E-7
3.816 1.136000 10.81800 11.50000 1.000000 0.004694967 -0.01226703 0E-7
3.841 1.161000 11.11900 12.00000 1.000000 -0.002331241 -0.02302503 0E-7
3.867 1.187000 11.41600 12.50000 1.000000 0.007266012 -0.005633897 0E-7
3.891 1.211000 11.70900 13.00000 1.000000 -0.001963994 -0.02042854 0E-7
3.916 1.236000 11.99900 13.50000 1.000000 0.004381474 -0.007389414 0E-7
3.940 1.260000 12.28600 14.00000 1.000000 0.002579182 -0.007706099 0E-7
3.964 1.284000 12.57000 14.50000 1.000000 0.004457298 -0.001148026 0E-7
3.988 1.308000 12.85100 15.00000 1.000000 0.01000872 0.01214074 0E-7
4.011 1.331000 13.12900 15.50000 1.000000 0.007249336 0.01022389 0E-7
4.034 1.354000 13.40500 16.00000 1.000000 0.007106001 0.01422607 0E-7
4.057 1.377000 13.67900 16.50000 1.000000 0.009582651 0.02401719 0E-7
4.079 1.399000 13.94900 17.00000 1.000000 0.004625377 0.01693945 0E-7
4.101 1.421000 14.21800 17.50000 1.000000 0.001251171 0.01492255 0E-7
4.123 1.443000 14.48400 18.00000 1.000000 0.001472017 0.01784990 0E-7
4.145 1.465000 14.74900 18.50000 1.000000 0.003302683 0.02560403 0E-7
4.166 1.486000 15.01100 19.00000 1.000000 -0.003410352 0.01467235 0E-7
4.188 1.508000 15.27100 19.50000 1.000000 0.004665465 0.03151800 0E-7
4.209 1.529000 15.53000 20.00000 1.000000 0.002180400 0.02904637 0E-7
4.230 1.550000 15.78600 20.50000 1.000000 0.003327886 0.03054641 0E-7
4.250 1.570000 16.04100 21.00000 1.000000 -0.006159114 0.01176102 0E-7
4.271 1.591000 16.29400 21.50000 1.000000 -0.0007034335 0.02070914 0E-7
4.291 1.611000 16.54600 22.00000 1.000000 -0.005893629 0.008822805 0E-7
4.311 1.631000 16.79600 22.50000 1.000000 -0.008410838 0.0001596972 0E-7
4.331 1.651000 17.04400 23.00000 1.000000 -0.008226004 -0.005374235 0E-7
4.351 1.671000 17.29100 23.50000 1.000000 -0.006308168 -0.007873656 0E-7
4.371 1.691000 17.53700 24.00000 1.000000 -0.002624472 -0.007433839 0E-7
4.390 1.710000 17.78100 24.50000 1.000000 -0.008683945 -0.02938087 0E-7
4.410 1.730000 18.02400 25.00000 1.000000 -0.0004051145 -0.02348590 0E-7
4.429 1.749000 18.26500 25.50000 1.000000 -0.001881421 -0.04042534 0E-7
4.448 1.768000 18.50500 26.00000 1.000000 -0.001534509 -0.05505273 0E-7
4.467 1.787000 18.75100 26.50000 1.000000 -0.006328259 -0.06745233 0E-7
4.488 1.808000 19.00800 27.00000 1.000000 0.004313311 -0.02603575 0E-7
4.508 1.828000 19.26400 27.50000 1.000000 0.004277350 -0.008072317 0E-7
4.528 1.848000 19.51800 28.00000 1.000000 0.007331214 0.01206118 0E-7
4.547 1.867000 19.77200 28.50000 1.000000 -0.001412936 0.008106308 0E-7
4.567 1.887000 20.02400 29.00000 1.000000 0.005910712 0.03218124 0E-7
4.586 1.906000 20.27600 29.50000 1.000000 0.001417596 0.03178725 0E-7
4.605 1.925000 20.52600 30.00000 1.000000 0.00009259614 0.03299421 0E-7
]]></om:result>
    </tuhh:WPointsObservation>
   </wb1d2d:pointsMember>
   <wb1d2d:polynomialMember>
    <math:Polynomial1D gml:id="Polynomial1D119135521278128">
     <gml:description>Q1(h)</gml:description>
     <gml:name>Q1(h)</gml:name>
     <math:coefficients>0.108740076104 -1.03431891234 10.9852573021 -0.925595780608 -0.159437983145</math:coefficients>
     <math:minRange>0.341</math:minRange>
     <math:maxRange>1.925</math:maxRange>
     <math:domainPhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonRunoff"/>
     <math:rangePhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonWaterlevel"/>
    </math:Polynomial1D>
   </wb1d2d:polynomialMember>
   <wb1d2d:polynomialMember>
    <math:Polynomial1D gml:id="Polynomial1D119135521278143">
     <gml:description>A1(h)</gml:description>
     <gml:name>A1(h)</gml:name>
     <math:coefficients>-0.298521572235 5.92800177162 5.719030712 -2.6041753056 0.49499231619</math:coefficients>
     <math:minRange>0.341</math:minRange>
     <math:maxRange>1.925</math:maxRange>
     <math:domainPhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonArea"/>
     <math:rangePhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonWaterlevel"/>
    </math:Polynomial1D>
   </wb1d2d:polynomialMember>
   <wb1d2d:polynomialMember>
    <math:Polynomial1D gml:id="Polynomial1D119135521278138">
     <gml:description>al1(h)</gml:description>
     <gml:name>al1(h)</gml:name>
     <math:coefficients>1.0</math:coefficients>
     <math:minRange>0.341</math:minRange>
     <math:maxRange>1.925</math:maxRange>
     <math:domainPhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonAlpha"/>
     <math:rangePhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonWaterlevel"/>
    </math:Polynomial1D>
   </wb1d2d:polynomialMember>
   <wb1d2d:polynomialMember>
    <math:Polynomial1D gml:id="Polynomial1D119135521278132">
     <gml:description>Spl_al</gml:description>
     <gml:name>Spl_al</gml:name>
     <math:coefficients>0.0</math:coefficients>
     <math:minRange>1.925</math:minRange>
     <math:maxRange>1.925</math:maxRange>
     <math:domainPhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonAlpha"/>
     <math:rangePhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonWaterlevel"/>
    </math:Polynomial1D>
   </wb1d2d:polynomialMember>
   <wb1d2d:polynomialMember>
    <math:Polynomial1D gml:id="Polynomial1D119135521278117">
     <gml:description>al2(h)</gml:description>
     <gml:name>al2(h)</gml:name>
     <math:coefficients>0.0</math:coefficients>
     <math:minRange>1.925</math:minRange>
     <math:maxRange>1.925</math:maxRange>
     <math:domainPhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonAlpha"/>
     <math:rangePhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonWaterlevel"/>
    </math:Polynomial1D>
   </wb1d2d:polynomialMember>
   <wb1d2d:station>58.7000</wb1d2d:station>
   <wb1d2d:profileMember xlink:href="terrain.gml#Profile11913552122342"/>
   <wb1d2d:slope>0.00100</wb1d2d:slope>
  </wb1d2d:TeschkeFlowRelation>
 </simBase:flowRelationshipMember>
 <simBase:flowRelationshipMember>
  <wb1d2d:TeschkeFlowRelation gml:id="TeschkeFlowRelation119135521278141">
   <gml:description>Gelesen aus: PROF0058.7500.txt</gml:description>
   <gml:name>58.7500</gml:name>
   <simBase:position>
    <gml:Point xmlns:ns1="http://www.w3.org/2001/SMIL20/" xmlns:st="http://www.seegrid.csiro.au/xml/st" xmlns:ns2="http://www.isotc211.org/2005/gmd" xmlns:ns3="http://www.isotc211.org/2005/gco" xmlns:ns4="http://www.isotc211.org/2005/gts" xmlns:ns5="http://www.isotc211.org/2005/gss" xmlns:ns6="http://www.isotc211.org/2005/gsr" xmlns:ns7="http://www.w3.org/2001/SMIL20/Language" srsName="EPSG:31467">
     <gml:coordinates ts="," decimal="." cs=" ">3552854.240111261 5987128.993991661 2.68</gml:coordinates>
    </gml:Point>
   </simBase:position>
   <wb1d2d:pointsMember>
    <tuhh:WPointsObservation gml:id="WPointsObservation119135521278143">
     <gml:description>�bernommen aus Datei: PROF0058.7500.txt</gml:description>
     <gml:name>0058.7500</gml:name>
     <om:resultDefinition>
      <swe:RecordDefinition gml:id="RecordDefinition119135521278119">
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#Waterlevel"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#Depth"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#Area"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#Runoff"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#Alpha"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#DeltaArea"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#DeltaRunoff"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#DeltaAlpha"/>
      </swe:RecordDefinition>
     </om:resultDefinition>
     <om:result><![CDATA[3.124 0.4440000 2.512000 1.000000 1.000000 -0.01509816 -0.02313637 0E-7
3.187 0.5070000 3.207000 1.500000 1.000000 -0.001904051 -0.01081148 0E-7
3.242 0.5620000 3.827000 2.000000 1.000000 0.01035780 0.004314328 0E-7
3.291 0.6110000 4.397000 2.500000 1.000000 0.01363736 0.01573934 0E-7
3.336 0.6560000 4.931000 3.000000 1.000000 0.01372380 0.02835430 0E-7
3.378 0.6980000 5.439000 3.500000 1.000000 0.01026756 0.04334961 0E-7
3.415 0.7350000 5.896000 4.000000 1.000000 0.002251351 0.02586170 0E-7
3.450 0.7700000 6.333000 4.500000 1.000000 -0.006406800 0.006796225 0E-7
3.484 0.8040000 6.753000 5.000000 1.000000 -0.007133989 -0.003512847 0E-7
3.517 0.8370000 7.159000 5.500000 1.000000 -0.003382132 -0.007319391 0E-7
3.548 0.8680000 7.552000 6.000000 1.000000 -0.009083781 -0.02270589 0E-7
3.579 0.8990000 7.934000 6.500000 1.000000 -0.001604275 -0.02043725 0E-7
3.608 0.9280000 8.307000 7.000000 1.000000 -0.008378223 -0.03482220 0E-7
3.637 0.9570000 8.671000 7.500000 1.000000 -0.004428381 -0.03420806 0E-7
3.665 0.9850000 9.027000 8.000000 1.000000 -0.003605332 -0.03683831 0E-7
3.692 1.012000 9.375000 8.500000 1.000000 -0.006135724 -0.04438853 0E-7
3.719 1.039000 9.726000 9.000000 1.000000 -0.01035579 -0.03952577 0E-7
3.748 1.068000 10.08700 9.500000 1.000000 0.002515186 0.01633286 0E-7
3.775 1.095000 10.44200 10.00000 1.000000 -0.003137917 0.04630000 0E-7
3.802 1.122000 10.79200 10.50000 1.000000 -0.002615844 0.08805171 0E-7
3.829 1.149000 11.13700 11.00000 1.000000 0.004047406 0.1413736 0E-7
3.844 1.164000 11.33900 11.50000 1.000000 -0.002101935 -0.04630648 0E-7
3.868 1.188000 11.65100 12.00000 1.000000 -0.00003779587 -0.03940312 0E-7
3.892 1.212000 11.95800 12.50000 1.000000 0.007878550 -0.02378834 0E-7
3.915 1.235000 12.26100 13.00000 1.000000 0.007461713 -0.02163311 0E-7
3.937 1.257000 12.56100 13.50000 1.000000 -0.002396613 -0.03409793 0E-7
3.960 1.280000 12.85700 14.00000 1.000000 0.005674673 -0.01700409 0E-7
3.982 1.302000 13.15100 14.50000 1.000000 0.003231772 -0.01545307 0E-7
4.004 1.324000 13.44100 15.00000 1.000000 0.005478942 -0.007252696 0E-7
4.025 1.345000 13.72800 15.50000 1.000000 -0.001912624 -0.01607453 0E-7
4.047 1.367000 14.01200 16.00000 1.000000 0.007690063 0.004727241 0E-7
4.068 1.388000 14.29500 16.50000 1.000000 0.005601155 0.007680041 0E-7
4.089 1.409000 14.57500 17.00000 1.000000 0.007158041 0.01619537 0E-7
4.109 1.429000 14.85200 17.50000 1.000000 -0.001084185 0.005552198 0E-7
4.130 1.450000 15.12600 18.00000 1.000000 0.007760314 0.02456374 0E-7
4.150 1.470000 15.39800 18.50000 1.000000 0.005764965 0.02368400 0E-7
4.170 1.490000 15.66900 19.00000 1.000000 0.005395458 0.02739514 0E-7
4.189 1.509000 15.93700 19.50000 1.000000 -0.004913573 0.01006866 0E-7
4.209 1.529000 16.20300 20.00000 1.000000 0.0009775890 0.02240100 0E-7
4.228 1.548000 16.46700 20.50000 1.000000 -0.004105479 0.01305372 0E-7
4.247 1.567000 16.72900 21.00000 1.000000 -0.006568575 0.007438720 0E-7
4.266 1.586000 16.99000 21.50000 1.000000 -0.007395200 0.005452814 0E-7
4.285 1.605000 17.24800 22.00000 1.000000 -0.004567656 0.006991604 0E-7
4.304 1.624000 17.50500 22.50000 1.000000 -0.00006704581 0.01194949 0E-7
4.322 1.642000 17.76100 23.00000 1.000000 -0.007690566 -0.006612235 0E-7
4.341 1.661000 18.01500 23.50000 1.000000 0.001179514 0.004696282 0E-7
4.359 1.679000 18.26800 24.00000 1.000000 -0.002107377 -0.008044064 0E-7
4.377 1.697000 18.52100 24.50000 1.000000 -0.004713876 -0.01809518 0E-7
4.395 1.715000 18.76800 25.00000 1.000000 -0.0006189518 -0.02555185 0E-7
4.412 1.732000 19.01300 25.50000 1.000000 -0.007809877 -0.05807605 0E-7
4.431 1.751000 19.27000 26.00000 1.000000 0.001764132 -0.03306578 0E-7
4.449 1.769000 19.53000 26.50000 1.000000 -0.004900812 -0.03331745 0E-7
4.468 1.788000 19.78900 27.00000 1.000000 0.004371644 -0.003414482 0E-7
4.486 1.806000 20.04700 27.50000 1.000000 0.001369396 0.0007595550 0E-7
4.504 1.824000 20.30300 28.00000 1.000000 0.001216579 0.006933387 0E-7
4.522 1.842000 20.55800 28.50000 1.000000 0.002941046 0.01500539 0E-7
4.540 1.860000 20.81300 29.00000 1.000000 0.005571612 0.02487297 0E-7
4.557 1.877000 21.06600 29.50000 1.000000 -0.003251814 0.007969965 0E-7
4.575 1.895000 21.31800 30.00000 1.000000 0.004226740 0.02103160 0E-7
]]></om:result>
    </tuhh:WPointsObservation>
   </wb1d2d:pointsMember>
   <wb1d2d:polynomialMember>
    <math:Polynomial1D gml:id="Polynomial1D119135521279614">
     <gml:description>Q1(h)</gml:description>
     <gml:name>Q1(h)</gml:name>
     <math:coefficients>-0.192769103409 -2.28707096984 11.2079475885 -0.107715808973 -0.385190937639</math:coefficients>
     <math:minRange>0.444</math:minRange>
     <math:maxRange>1.895</math:maxRange>
     <math:domainPhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonRunoff"/>
     <math:rangePhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonWaterlevel"/>
    </math:Polynomial1D>
   </wb1d2d:polynomialMember>
   <wb1d2d:polynomialMember>
    <math:Polynomial1D gml:id="Polynomial1D119135521279622">
     <gml:description>A1(h)</gml:description>
     <gml:name>A1(h)</gml:name>
     <math:coefficients>-1.83054174249 8.07204477785 4.57851700895 -1.98837225242 0.383509575579</math:coefficients>
     <math:minRange>0.444</math:minRange>
     <math:maxRange>1.895</math:maxRange>
     <math:domainPhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonArea"/>
     <math:rangePhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonWaterlevel"/>
    </math:Polynomial1D>
   </wb1d2d:polynomialMember>
   <wb1d2d:polynomialMember>
    <math:Polynomial1D gml:id="Polynomial1D11913552127961">
     <gml:description>al1(h)</gml:description>
     <gml:name>al1(h)</gml:name>
     <math:coefficients>1.0</math:coefficients>
     <math:minRange>0.444</math:minRange>
     <math:maxRange>1.895</math:maxRange>
     <math:domainPhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonAlpha"/>
     <math:rangePhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonWaterlevel"/>
    </math:Polynomial1D>
   </wb1d2d:polynomialMember>
   <wb1d2d:polynomialMember>
    <math:Polynomial1D gml:id="Polynomial1D119135521279623">
     <gml:description>Spl_al</gml:description>
     <gml:name>Spl_al</gml:name>
     <math:coefficients>0.0</math:coefficients>
     <math:minRange>1.895</math:minRange>
     <math:maxRange>1.895</math:maxRange>
     <math:domainPhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonAlpha"/>
     <math:rangePhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonWaterlevel"/>
    </math:Polynomial1D>
   </wb1d2d:polynomialMember>
   <wb1d2d:polynomialMember>
    <math:Polynomial1D gml:id="Polynomial1D119135521279611">
     <gml:description>al2(h)</gml:description>
     <gml:name>al2(h)</gml:name>
     <math:coefficients>0.0</math:coefficients>
     <math:minRange>1.895</math:minRange>
     <math:maxRange>1.895</math:maxRange>
     <math:domainPhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonAlpha"/>
     <math:rangePhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonWaterlevel"/>
    </math:Polynomial1D>
   </wb1d2d:polynomialMember>
   <wb1d2d:station>58.7500</wb1d2d:station>
   <wb1d2d:profileMember xlink:href="terrain.gml#Profile119135521223412"/>
   <wb1d2d:slope>0.00100</wb1d2d:slope>
  </wb1d2d:TeschkeFlowRelation>
 </simBase:flowRelationshipMember>
 <simBase:flowRelationshipMember>
  <wb1d2d:TeschkeFlowRelation gml:id="TeschkeFlowRelation119135521279628">
   <gml:description>Gelesen aus: PROF0058.8000.txt</gml:description>
   <gml:name>58.8000</gml:name>
   <simBase:position>
    <gml:Point xmlns:ns1="http://www.w3.org/2001/SMIL20/" xmlns:st="http://www.seegrid.csiro.au/xml/st" xmlns:ns2="http://www.isotc211.org/2005/gmd" xmlns:ns3="http://www.isotc211.org/2005/gco" xmlns:ns4="http://www.isotc211.org/2005/gts" xmlns:ns5="http://www.isotc211.org/2005/gss" xmlns:ns6="http://www.isotc211.org/2005/gsr" xmlns:ns7="http://www.w3.org/2001/SMIL20/Language" srsName="EPSG:31467">
     <gml:coordinates ts="," decimal="." cs=" ">3552869.046111237 5987179.697791541 2.11</gml:coordinates>
    </gml:Point>
   </simBase:position>
   <wb1d2d:pointsMember>
    <tuhh:WPointsObservation gml:id="WPointsObservation119135521279645">
     <gml:description>�bernommen aus Datei: PROF0058.8000.txt</gml:description>
     <gml:name>0058.8000</gml:name>
     <om:resultDefinition>
      <swe:RecordDefinition gml:id="RecordDefinition119135521279631">
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#Waterlevel"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#Depth"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#Area"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#Runoff"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#Alpha"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#DeltaArea"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#DeltaRunoff"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#DeltaAlpha"/>
      </swe:RecordDefinition>
     </om:resultDefinition>
     <om:result><![CDATA[2.737 0.6270000 2.004000 1.000000 1.000000 0.01382853 0.04735424 0E-7
2.836 0.7260000 2.686000 1.500000 1.000000 -0.01045226 -0.01618597 0E-7
2.916 0.8060000 3.312000 2.000000 1.000000 -0.01049032 -0.03440488 0E-7
2.984 0.8740000 3.895000 2.500000 1.000000 -0.003913058 -0.03067425 0E-7
3.044 0.9340000 4.448000 3.000000 1.000000 0.001910067 -0.01261642 0E-7
3.097 0.9870000 4.976000 3.500000 1.000000 -0.005689267 0.003215332 0E-7
3.143 1.033000 5.447000 4.000000 1.000000 -0.006744644 -0.004449352 0E-7
3.185 1.075000 5.888000 4.500000 1.000000 -0.005238680 -0.01855713 0E-7
3.226 1.116000 6.321000 5.000000 1.000000 0.004978383 -0.01071620 0E-7
3.264 1.154000 6.738000 5.500000 1.000000 0.007817417 -0.01050857 0E-7
3.300 1.190000 7.146000 6.000000 1.000000 0.004902107 -0.01051622 0E-7
3.332 1.222000 7.508000 6.500000 1.000000 0.008484497 -0.04485646 0E-7
3.369 1.259000 7.934000 7.000000 1.000000 0.01111419 0.01829484 0E-7
3.402 1.292000 8.318000 7.500000 1.000000 0.01432391 0.04275968 0E-7
3.433 1.323000 8.693000 8.000000 1.000000 0.006937529 0.05431518 0E-7
3.464 1.354000 9.063000 8.500000 1.000000 0.008000737 0.08396035 0E-7
3.492 1.382000 9.410000 9.000000 1.000000 -0.001109102 0.07771700 0E-7
3.518 1.408000 9.724000 9.500000 1.000000 0.0008001547 0.04910484 0E-7
3.541 1.431000 10.01000 10.00000 1.000000 -0.004128952 -0.02367134 0E-7
3.570 1.460000 10.37100 10.50000 1.000000 -0.008724152 0.02849931 0E-7
3.595 1.485000 10.68000 11.00000 1.000000 -0.008798644 0.01641397 0E-7
3.620 1.510000 10.98500 11.50000 1.000000 -0.003423088 0.01517222 0E-7
3.644 1.534000 11.28600 12.00000 1.000000 -0.005183446 0.004012994 0E-7
3.668 1.558000 11.58200 12.50000 1.000000 -0.0007657975 0.002509446 0E-7
3.689 1.579000 11.84800 13.00000 1.000000 -0.002986789 -0.05352612 0E-7
3.712 1.602000 12.13700 13.50000 1.000000 -0.002157760 -0.05910331 0E-7
3.737 1.627000 12.45500 14.00000 1.000000 -0.004079114 -0.01218821 0E-7
3.759 1.649000 12.73800 14.50000 1.000000 -0.008068690 -0.02289667 0E-7
3.781 1.671000 13.01100 15.00000 1.000000 -0.001284484 -0.02628179 0E-7
3.803 1.693000 13.29700 15.50000 1.000000 -0.006752442 -0.02251456 0E-7
3.825 1.715000 13.57200 16.00000 1.000000 -0.0004935723 -0.01177233 0E-7
3.846 1.736000 13.84400 16.50000 1.000000 -0.003355990 -0.01790773 0E-7
3.867 1.757000 14.11400 17.00000 1.000000 -0.003580608 -0.01802034 0E-7
3.888 1.778000 14.38200 17.50000 1.000000 -0.001173109 -0.01228064 0E-7
3.909 1.799000 14.64700 18.00000 1.000000 0.004864928 -0.0008643807 0E-7
3.928 1.818000 14.90000 18.50000 1.000000 -0.002364842 -0.03341401 0E-7
3.947 1.837000 15.14000 19.00000 1.000000 0.003928309 -0.06160279 0E-7
3.966 1.856000 15.39500 19.50000 1.000000 -0.004248115 -0.08557206 0E-7
3.989 1.879000 15.68700 20.00000 1.000000 0.003262886 -0.003886587 0E-7
4.009 1.899000 15.94400 20.50000 1.000000 0.007369555 0.006575086 0E-7
4.028 1.918000 16.19700 21.00000 1.000000 0.003009707 -0.004651672 0E-7
4.047 1.937000 16.45200 21.50000 1.000000 -0.002756910 -0.01230124 0E-7
4.067 1.957000 16.71000 22.00000 1.000000 0.002259090 0.009651004 0E-7
4.087 1.977000 16.96700 22.50000 1.000000 0.008985676 0.03519876 0E-7
4.106 1.996000 17.22300 23.00000 1.000000 0.004213472 0.03762175 0E-7
4.124 2.014000 17.46800 23.50000 1.000000 -0.002135239 0.01627732 0E-7
4.144 2.034000 17.72900 24.00000 1.000000 0.002804999 0.05098677 0E-7
4.162 2.052000 17.96400 24.50000 1.000000 0.007879564 0.03464257 0E-7
4.179 2.069000 18.19900 25.00000 1.000000 0.0002808896 -0.006612843 0E-7
4.200 2.090000 18.47800 25.50000 1.000000 0.003124112 0.06249762 0E-7
4.218 2.108000 18.72500 26.00000 1.000000 -0.001430841 0.05226081 0E-7
4.236 2.126000 18.97100 26.50000 1.000000 -0.004145333 0.04365574 0E-7
4.254 2.144000 19.21600 27.00000 1.000000 -0.004977397 0.03651638 0E-7
4.272 2.162000 19.45900 27.50000 1.000000 -0.002882850 0.03067381 0E-7
4.289 2.179000 19.68600 28.00000 1.000000 0.002487938 -0.001585957 0E-7
4.305 2.195000 19.90500 28.50000 1.000000 0.003019261 -0.06057477 0E-7
4.325 2.215000 20.18300 29.00000 1.000000 0.0006196732 -0.008433532 0E-7
4.342 2.232000 20.42200 29.50000 1.000000 -0.003033328 -0.03851860 0E-7
4.359 2.249000 20.66000 30.00000 1.000000 -0.004638757 -0.06822009 0E-7
]]></om:result>
    </tuhh:WPointsObservation>
   </wb1d2d:pointsMember>
   <wb1d2d:polynomialMember>
    <math:Polynomial1D gml:id="Polynomial1D119135521281214">
     <gml:description>Q1(h)</gml:description>
     <gml:name>Q1(h)</gml:name>
     <math:coefficients>1.50759150207 -3.66975989157 2.09298591266 4.83917317934 -1.13185192144</math:coefficients>
     <math:minRange>0.627</math:minRange>
     <math:maxRange>2.249</math:maxRange>
     <math:domainPhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonRunoff"/>
     <math:rangePhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonWaterlevel"/>
    </math:Polynomial1D>
   </wb1d2d:polynomialMember>
   <wb1d2d:polynomialMember>
    <math:Polynomial1D gml:id="Polynomial1D119135521281238">
     <gml:description>A1(h)</gml:description>
     <gml:name>A1(h)</gml:name>
     <math:coefficients>2.4482531042 -9.31560507812 17.3284265058 -6.23787381451 0.87827708227</math:coefficients>
     <math:minRange>0.627</math:minRange>
     <math:maxRange>2.249</math:maxRange>
     <math:domainPhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonArea"/>
     <math:rangePhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonWaterlevel"/>
    </math:Polynomial1D>
   </wb1d2d:polynomialMember>
   <wb1d2d:polynomialMember>
    <math:Polynomial1D gml:id="Polynomial1D119135521281236">
     <gml:description>al1(h)</gml:description>
     <gml:name>al1(h)</gml:name>
     <math:coefficients>1.0</math:coefficients>
     <math:minRange>0.627</math:minRange>
     <math:maxRange>2.249</math:maxRange>
     <math:domainPhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonAlpha"/>
     <math:rangePhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonWaterlevel"/>
    </math:Polynomial1D>
   </wb1d2d:polynomialMember>
   <wb1d2d:polynomialMember>
    <math:Polynomial1D gml:id="Polynomial1D119135521281248">
     <gml:description>Spl_al</gml:description>
     <gml:name>Spl_al</gml:name>
     <math:coefficients>0.0</math:coefficients>
     <math:minRange>2.249</math:minRange>
     <math:maxRange>2.249</math:maxRange>
     <math:domainPhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonAlpha"/>
     <math:rangePhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonWaterlevel"/>
    </math:Polynomial1D>
   </wb1d2d:polynomialMember>
   <wb1d2d:polynomialMember>
    <math:Polynomial1D gml:id="Polynomial1D119135521281219">
     <gml:description>al2(h)</gml:description>
     <gml:name>al2(h)</gml:name>
     <math:coefficients>0.0</math:coefficients>
     <math:minRange>2.249</math:minRange>
     <math:maxRange>2.249</math:maxRange>
     <math:domainPhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonAlpha"/>
     <math:rangePhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonWaterlevel"/>
    </math:Polynomial1D>
   </wb1d2d:polynomialMember>
   <wb1d2d:station>58.8000</wb1d2d:station>
   <wb1d2d:profileMember xlink:href="terrain.gml#Profile119135521225011"/>
   <wb1d2d:slope>0.00100</wb1d2d:slope>
  </wb1d2d:TeschkeFlowRelation>
 </simBase:flowRelationshipMember>
 <simBase:flowRelationshipMember>
  <wb1d2d:TeschkeFlowRelation gml:id="TeschkeFlowRelation119135521281226">
   <gml:description>Gelesen aus: PROF0058.8500.txt</gml:description>
   <gml:name>58.8500</gml:name>
   <simBase:position>
    <gml:Point xmlns:ns1="http://www.w3.org/2001/SMIL20/" xmlns:st="http://www.seegrid.csiro.au/xml/st" xmlns:ns2="http://www.isotc211.org/2005/gmd" xmlns:ns3="http://www.isotc211.org/2005/gco" xmlns:ns4="http://www.isotc211.org/2005/gts" xmlns:ns5="http://www.isotc211.org/2005/gss" xmlns:ns6="http://www.isotc211.org/2005/gsr" xmlns:ns7="http://www.w3.org/2001/SMIL20/Language" srsName="EPSG:31467">
     <gml:coordinates ts="," decimal="." cs=" ">3552883.2264112127 5987231.575591416 2.75</gml:coordinates>
    </gml:Point>
   </simBase:position>
   <wb1d2d:pointsMember>
    <tuhh:WPointsObservation gml:id="WPointsObservation11913552128128">
     <gml:description>�bernommen aus Datei: PROF0058.8500.txt</gml:description>
     <gml:name>0058.8500</gml:name>
     <om:resultDefinition>
      <swe:RecordDefinition gml:id="RecordDefinition119135521281250">
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#Waterlevel"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#Depth"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#Area"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#Runoff"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#Alpha"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#DeltaArea"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#DeltaRunoff"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#DeltaAlpha"/>
      </swe:RecordDefinition>
     </om:resultDefinition>
     <om:result><![CDATA[3.183 0.4330000 2.109000 1.000000 1.000000 -0.04539193 0.1310731 0E-7
3.272 0.5220000 2.785000 1.500000 1.000000 0.002594829 -0.05400562 0E-7
3.345 0.5950000 3.402000 2.000000 1.000000 0.02648064 -0.1042927 0E-7
3.409 0.6590000 3.978000 2.500000 1.000000 0.04175210 -0.08463676 0E-7
3.466 0.7160000 4.524000 3.000000 1.000000 0.04215533 -0.03351537 0E-7
3.516 0.7660000 5.039000 3.500000 1.000000 0.01976966 0.01184882 0E-7
3.558 0.8080000 5.471000 4.000000 1.000000 0.01001647 0.01081216 0E-7
3.597 0.8470000 5.881000 4.500000 1.000000 -0.001746959 0.004929136 0E-7
3.634 0.8840000 6.275000 5.000000 1.000000 -0.01301017 -0.0008515551 0E-7
3.670 0.9200000 6.656000 5.500000 1.000000 -0.01746109 0.002139609 0E-7
3.705 0.9550000 7.026000 6.000000 1.000000 -0.01780639 0.01066783 0E-7
3.739 0.9890000 7.386000 6.500000 1.000000 -0.01564713 0.02186155 0E-7
3.771 1.021000 7.737000 7.000000 1.000000 -0.02326116 0.01746991 0E-7
3.803 1.053000 8.080000 7.500000 1.000000 -0.02061122 0.02624662 0E-7
3.834 1.084000 8.415000 8.000000 1.000000 -0.01875502 0.03092281 0E-7
3.864 1.114000 8.744000 8.500000 1.000000 -0.02000090 0.02972543 0E-7
3.894 1.144000 9.067000 9.000000 1.000000 -0.01360389 0.03818298 0E-7
3.923 1.173000 9.384000 9.500000 1.000000 -0.01069260 0.03836960 0E-7
3.951 1.201000 9.696000 10.00000 1.000000 -0.01246415 0.02898266 0E-7
3.979 1.229000 10.00400 10.50000 1.000000 -0.008938633 0.02676564 0E-7
4.007 1.257000 10.30700 11.00000 1.000000 0.0008714036 0.03138581 0E-7
4.034 1.284000 10.60600 11.50000 1.000000 0.004728250 0.02417778 0E-7
4.060 1.310000 10.90500 12.00000 1.000000 -0.001486884 0.004237720 0E-7
4.087 1.337000 11.20800 12.50000 1.000000 0.0007748963 0.008286492 0E-7
4.114 1.364000 11.50700 13.00000 1.000000 0.008315657 0.01778112 0E-7
4.140 1.390000 11.80400 13.50000 1.000000 0.007761527 0.01340493 0E-7
4.166 1.416000 12.09700 14.00000 1.000000 0.01250167 0.01381550 0E-7
4.191 1.441000 12.38800 14.50000 1.000000 0.009075851 -0.0005926582 0E-7
4.216 1.466000 12.67600 15.00000 1.000000 0.009983116 -0.01072208 0E-7
4.241 1.491000 12.96100 15.50000 1.000000 0.01530476 -0.01661346 0E-7
4.265 1.515000 13.24400 16.00000 1.000000 0.01242833 -0.03830090 0E-7
4.289 1.539000 13.52400 16.50000 1.000000 0.01402747 -0.05610123 0E-7
4.312 1.562000 13.80300 17.00000 1.000000 0.006367179 -0.09032966 0E-7
4.336 1.586000 14.07900 17.50000 1.000000 0.01514300 -0.1004509 0E-7
4.359 1.609000 14.35300 18.00000 1.000000 0.01572602 -0.1272411 0E-7
4.385 1.635000 14.66200 18.50000 1.000000 0.01923064 -0.08781992 0E-7
4.410 1.660000 14.97100 19.00000 1.000000 0.01297006 -0.06455482 0E-7
4.435 1.685000 15.27800 19.50000 1.000000 0.01107615 -0.03666869 0E-7
4.460 1.710000 15.58300 20.00000 1.000000 0.01371304 -0.004022097 0E-7
4.484 1.734000 15.88600 20.50000 1.000000 0.008586489 0.01194555 0E-7
4.508 1.758000 16.18800 21.00000 1.000000 0.007114043 0.03260707 0E-7
4.531 1.781000 16.48700 21.50000 1.000000 -0.001232795 0.03614239 0E-7
4.554 1.804000 16.78500 22.00000 1.000000 -0.005829801 0.04432150 0E-7
4.577 1.827000 17.08100 22.50000 1.000000 -0.005513812 0.05732981 0E-7
4.599 1.849000 17.37500 23.00000 1.000000 -0.01319872 0.05273662 0E-7
4.621 1.871000 17.66800 23.50000 1.000000 -0.01690847 0.05293257 0E-7
4.643 1.893000 17.95900 24.00000 1.000000 -0.01548288 0.05811773 0E-7
4.664 1.914000 18.24800 24.50000 1.000000 -0.02227224 0.04518913 0E-7
4.685 1.935000 18.53600 25.00000 1.000000 -0.02490464 0.03719515 0E-7
4.706 1.956000 18.82300 25.50000 1.000000 -0.02322630 0.03434124 0E-7
4.727 1.977000 19.10700 26.00000 1.000000 -0.01507873 0.03684309 0E-7
4.747 1.997000 19.39100 26.50000 1.000000 -0.01746830 0.02060214 0E-7
4.767 2.017000 19.67300 27.00000 1.000000 -0.01441824 0.009627649 0E-7
4.787 2.037000 19.95400 27.50000 1.000000 -0.006779699 0.004131833 0E-7
4.806 2.056000 20.23400 28.00000 1.000000 -0.009110233 -0.02081371 0E-7
4.826 2.076000 20.51300 28.50000 1.000000 0.007968546 -0.01498386 0E-7
4.845 2.095000 20.79000 29.00000 1.000000 0.01599225 -0.02874934 0E-7
4.864 2.114000 21.06600 29.50000 1.000000 0.02881174 -0.03675083 0E-7
4.882 2.132000 21.34100 30.00000 1.000000 0.03106186 -0.06513336 0E-7
]]></om:result>
    </tuhh:WPointsObservation>
   </wb1d2d:pointsMember>
   <wb1d2d:polynomialMember>
    <math:Polynomial1D gml:id="Polynomial1D119135521282817">
     <gml:description>Q1(h)</gml:description>
     <gml:name>Q1(h)</gml:name>
     <math:coefficients>4.57309587987 -19.9847796986 33.0930295985 -13.1835579921 2.19290151222</math:coefficients>
     <math:minRange>0.433</math:minRange>
     <math:maxRange>2.132</math:maxRange>
     <math:domainPhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonRunoff"/>
     <math:rangePhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonWaterlevel"/>
    </math:Polynomial1D>
   </wb1d2d:polynomialMember>
   <wb1d2d:polynomialMember>
    <math:Polynomial1D gml:id="Polynomial1D119135521282836">
     <gml:description>A1(h)</gml:description>
     <gml:name>A1(h)</gml:name>
     <math:coefficients>-0.0975468810891 1.47167063521 10.1029143625 -4.9976521853 1.00873949872</math:coefficients>
     <math:minRange>0.433</math:minRange>
     <math:maxRange>2.132</math:maxRange>
     <math:domainPhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonArea"/>
     <math:rangePhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonWaterlevel"/>
    </math:Polynomial1D>
   </wb1d2d:polynomialMember>
   <wb1d2d:polynomialMember>
    <math:Polynomial1D gml:id="Polynomial1D119135521282827">
     <gml:description>al1(h)</gml:description>
     <gml:name>al1(h)</gml:name>
     <math:coefficients>1.0</math:coefficients>
     <math:minRange>0.433</math:minRange>
     <math:maxRange>2.132</math:maxRange>
     <math:domainPhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonAlpha"/>
     <math:rangePhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonWaterlevel"/>
    </math:Polynomial1D>
   </wb1d2d:polynomialMember>
   <wb1d2d:polynomialMember>
    <math:Polynomial1D gml:id="Polynomial1D119135521282839">
     <gml:description>Spl_al</gml:description>
     <gml:name>Spl_al</gml:name>
     <math:coefficients>0.0</math:coefficients>
     <math:minRange>2.132</math:minRange>
     <math:maxRange>2.132</math:maxRange>
     <math:domainPhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonAlpha"/>
     <math:rangePhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonWaterlevel"/>
    </math:Polynomial1D>
   </wb1d2d:polynomialMember>
   <wb1d2d:polynomialMember>
    <math:Polynomial1D gml:id="Polynomial1D119135521282816">
     <gml:description>al2(h)</gml:description>
     <gml:name>al2(h)</gml:name>
     <math:coefficients>0.0</math:coefficients>
     <math:minRange>2.132</math:minRange>
     <math:maxRange>2.132</math:maxRange>
     <math:domainPhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonAlpha"/>
     <math:rangePhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonWaterlevel"/>
    </math:Polynomial1D>
   </wb1d2d:polynomialMember>
   <wb1d2d:station>58.8500</wb1d2d:station>
   <wb1d2d:profileMember xlink:href="terrain.gml#Profile119135521226510"/>
   <wb1d2d:slope>0.00100</wb1d2d:slope>
  </wb1d2d:TeschkeFlowRelation>
 </simBase:flowRelationshipMember>
 <simBase:flowRelationshipMember>
  <wb1d2d:TeschkeFlowRelation gml:id="TeschkeFlowRelation119135521282838">
   <gml:description>Gelesen aus: PROF0058.9000.txt</gml:description>
   <gml:name>58.9000</gml:name>
   <simBase:position>
    <gml:Point xmlns:ns1="http://www.w3.org/2001/SMIL20/" xmlns:st="http://www.seegrid.csiro.au/xml/st" xmlns:ns2="http://www.isotc211.org/2005/gmd" xmlns:ns3="http://www.isotc211.org/2005/gco" xmlns:ns4="http://www.isotc211.org/2005/gts" xmlns:ns5="http://www.isotc211.org/2005/gss" xmlns:ns6="http://www.isotc211.org/2005/gsr" xmlns:ns7="http://www.w3.org/2001/SMIL20/Language" srsName="EPSG:31467">
     <gml:coordinates ts="," decimal="." cs=" ">3552887.045811206 5987277.753291312 2.72</gml:coordinates>
    </gml:Point>
   </simBase:position>
   <wb1d2d:pointsMember>
    <tuhh:WPointsObservation gml:id="WPointsObservation119135521282830">
     <gml:description>�bernommen aus Datei: PROF0058.9000.txt</gml:description>
     <gml:name>0058.9000</gml:name>
     <om:resultDefinition>
      <swe:RecordDefinition gml:id="RecordDefinition119135521282867">
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#Waterlevel"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#Depth"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#Area"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#Runoff"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#Alpha"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#DeltaArea"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#DeltaRunoff"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#DeltaAlpha"/>
      </swe:RecordDefinition>
     </om:resultDefinition>
     <om:result><![CDATA[3.102 0.3820000 2.292000 1.000000 1.000000 -0.01440121 0.004155868 0E-7
3.176 0.4560000 2.984000 1.500000 1.000000 -0.004458430 -0.004698650 0E-7
3.233 0.5130000 3.534000 2.000000 1.000000 0.008461490 -0.04427278 0E-7
3.292 0.5720000 4.127000 2.500000 1.000000 0.01668365 0.004271235 0E-7
3.341 0.6210000 4.643000 3.000000 1.000000 0.01320727 0.01338567 0E-7
3.387 0.6670000 5.135000 3.500000 1.000000 0.01243551 0.03400428 0E-7
3.427 0.7070000 5.575000 4.000000 1.000000 0.007000396 0.01929484 0E-7
3.466 0.7460000 6.013000 4.500000 1.000000 -0.001071891 0.02082770 0E-7
3.503 0.7830000 6.432000 5.000000 1.000000 -0.006833297 0.02188589 0E-7
3.538 0.8180000 6.826000 5.500000 1.000000 -0.005390757 0.01794715 0E-7
3.569 0.8490000 7.182000 6.000000 1.000000 -0.007638657 -0.02513912 0E-7
3.602 0.8820000 7.564000 6.500000 1.000000 -0.009618500 -0.02100496 0E-7
3.635 0.9150000 7.949000 7.000000 1.000000 -0.01120609 0.001068203 0E-7
3.666 0.9460000 8.305000 7.500000 1.000000 -0.004076823 0.007529417 0E-7
3.695 0.9750000 8.654000 8.000000 1.000000 -0.01089049 -0.004878136 0E-7
3.724 1.004000 8.996000 8.500000 1.000000 -0.008392549 -0.004162331 0E-7
3.752 1.032000 9.332000 9.000000 1.000000 -0.009656549 -0.008455522 0E-7
3.779 1.059000 9.652000 9.500000 1.000000 -0.004968623 -0.01921771 0E-7
3.805 1.085000 9.965000 10.00000 1.000000 -0.003588251 -0.03781970 0E-7
3.831 1.111000 10.27400 10.50000 1.000000 0.003433167 -0.04646825 0E-7
3.857 1.137000 10.59300 11.00000 1.000000 0.002056365 -0.04528829 0E-7
3.884 1.164000 10.92500 11.50000 1.000000 0.001554094 -0.01455684 0E-7
3.910 1.190000 11.24500 12.00000 1.000000 0.002340006 0.006296179 0E-7
3.935 1.215000 11.54900 12.50000 1.000000 0.008212878 0.01606305 0E-7
3.959 1.239000 11.84900 13.00000 1.000000 0.006987600 0.01360678 0E-7
3.983 1.263000 12.14600 13.50000 1.000000 0.01001945 0.01907542 0E-7
4.006 1.286000 12.44000 14.00000 1.000000 0.004720667 0.01085406 0E-7
4.029 1.309000 12.73100 14.50000 1.000000 0.003561970 0.009787878 0E-7
4.052 1.332000 13.01900 15.00000 1.000000 0.006540566 0.01582225 0E-7
4.074 1.354000 13.30400 15.50000 1.000000 0.0009321090 0.006452291 0E-7
4.097 1.377000 13.58700 16.00000 1.000000 0.01113851 0.02623508 0E-7
4.118 1.398000 13.86700 16.50000 1.000000 -0.0001510839 0.006899361 0E-7
4.140 1.420000 14.14400 17.00000 1.000000 0.005386099 0.01664273 0E-7
4.161 1.441000 14.42000 17.50000 1.000000 0.00007344134 0.009095739 0E-7
4.182 1.462000 14.69300 18.00000 1.000000 -0.001259151 0.007265960 0E-7
4.203 1.483000 14.96400 18.50000 1.000000 0.0004005310 0.01113054 0E-7
4.224 1.504000 15.23300 19.00000 1.000000 0.005066653 0.02066919 0E-7
4.244 1.524000 15.50000 19.50000 1.000000 -0.0003485279 0.01120304 0E-7
4.264 1.544000 15.76600 20.00000 1.000000 -0.003820660 0.006854153 0E-7
4.284 1.564000 16.02900 20.50000 1.000000 -0.003332565 0.007611450 0E-7
4.304 1.584000 16.29100 21.00000 1.000000 -0.0008654533 0.01346596 0E-7
4.324 1.604000 16.55100 21.50000 1.000000 0.004601069 0.02441082 0E-7
4.341 1.621000 16.77800 22.00000 1.000000 0.004049791 -0.03728739 0E-7
4.359 1.639000 17.02400 22.50000 1.000000 -0.001360594 -0.06920019 0E-7
4.380 1.660000 17.31200 23.00000 1.000000 -0.007582348 -0.01789549 0E-7
4.400 1.680000 17.57500 23.50000 1.000000 -0.001103705 0.01236707 0E-7
4.418 1.698000 17.82700 24.00000 1.000000 -0.009616425 -0.006047709 0E-7
4.437 1.717000 18.07800 24.50000 1.000000 -0.002594274 0.006766295 0E-7
4.455 1.735000 18.32700 25.00000 1.000000 -0.006173724 -0.003165878 0E-7
4.473 1.753000 18.57500 25.50000 1.000000 -0.007776907 -0.008961987 0E-7
4.491 1.771000 18.82200 26.00000 1.000000 -0.007378990 -0.01061402 0E-7
4.509 1.789000 19.06700 26.50000 1.000000 -0.003954087 -0.008112591 0E-7
4.527 1.807000 19.31100 27.00000 1.000000 0.001524743 -0.001446931 0E-7
4.544 1.824000 19.55400 27.50000 1.000000 -0.004863417 -0.01909480 0E-7
4.562 1.842000 19.79600 28.00000 1.000000 0.004745811 -0.004296010 0E-7
4.579 1.859000 20.03500 28.50000 1.000000 0.004422417 -0.01423733 0E-7
4.596 1.876000 20.28100 29.00000 1.000000 -0.001858509 -0.02041523 0E-7
4.615 1.895000 20.53500 29.50000 1.000000 0.01332971 0.03597532 0E-7
4.632 1.912000 20.78700 30.00000 1.000000 0.003346579 0.03781694 0E-7
]]></om:result>
    </tuhh:WPointsObservation>
   </wb1d2d:pointsMember>
   <wb1d2d:polynomialMember>
    <math:Polynomial1D gml:id="Polynomial1D11913552128286">
     <gml:description>Q1(h)</gml:description>
     <gml:name>Q1(h)</gml:name>
     <math:coefficients>0.638855129639 -4.34776347425 15.1756851472 -3.5879133297 0.547137501982</math:coefficients>
     <math:minRange>0.382</math:minRange>
     <math:maxRange>1.912</math:maxRange>
     <math:domainPhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonRunoff"/>
     <math:rangePhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonWaterlevel"/>
    </math:Polynomial1D>
   </wb1d2d:polynomialMember>
   <wb1d2d:polynomialMember>
    <math:Polynomial1D gml:id="Polynomial1D119135521282812">
     <gml:description>A1(h)</gml:description>
     <gml:name>A1(h)</gml:name>
     <math:coefficients>-0.680199676975 5.95888383853 5.45391024604 -2.21135917408 0.418720895582</math:coefficients>
     <math:minRange>0.382</math:minRange>
     <math:maxRange>1.912</math:maxRange>
     <math:domainPhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonArea"/>
     <math:rangePhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonWaterlevel"/>
    </math:Polynomial1D>
   </wb1d2d:polynomialMember>
   <wb1d2d:polynomialMember>
    <math:Polynomial1D gml:id="Polynomial1D119135521282819">
     <gml:description>al1(h)</gml:description>
     <gml:name>al1(h)</gml:name>
     <math:coefficients>1.0</math:coefficients>
     <math:minRange>0.382</math:minRange>
     <math:maxRange>1.912</math:maxRange>
     <math:domainPhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonAlpha"/>
     <math:rangePhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonWaterlevel"/>
    </math:Polynomial1D>
   </wb1d2d:polynomialMember>
   <wb1d2d:polynomialMember>
    <math:Polynomial1D gml:id="Polynomial1D119135521282824">
     <gml:description>Spl_al</gml:description>
     <gml:name>Spl_al</gml:name>
     <math:coefficients>0.0</math:coefficients>
     <math:minRange>1.912</math:minRange>
     <math:maxRange>1.912</math:maxRange>
     <math:domainPhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonAlpha"/>
     <math:rangePhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonWaterlevel"/>
    </math:Polynomial1D>
   </wb1d2d:polynomialMember>
   <wb1d2d:polynomialMember>
    <math:Polynomial1D gml:id="Polynomial1D119135521282815">
     <gml:description>al2(h)</gml:description>
     <gml:name>al2(h)</gml:name>
     <math:coefficients>0.0</math:coefficients>
     <math:minRange>1.912</math:minRange>
     <math:maxRange>1.912</math:maxRange>
     <math:domainPhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonAlpha"/>
     <math:rangePhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonWaterlevel"/>
    </math:Polynomial1D>
   </wb1d2d:polynomialMember>
   <wb1d2d:station>58.9000</wb1d2d:station>
   <wb1d2d:profileMember xlink:href="terrain.gml#Profile119135521226515"/>
   <wb1d2d:slope>0.00100</wb1d2d:slope>
  </wb1d2d:TeschkeFlowRelation>
 </simBase:flowRelationshipMember>
 <simBase:flowRelationshipMember>
  <wb1d2d:TeschkeFlowRelation gml:id="TeschkeFlowRelation119135521282857">
   <gml:description>Gelesen aus: PROF0058.9500.txt</gml:description>
   <gml:name>58.9500</gml:name>
   <simBase:position>
    <gml:Point xmlns:ns1="http://www.w3.org/2001/SMIL20/" xmlns:st="http://www.seegrid.csiro.au/xml/st" xmlns:ns2="http://www.isotc211.org/2005/gmd" xmlns:ns3="http://www.isotc211.org/2005/gco" xmlns:ns4="http://www.isotc211.org/2005/gts" xmlns:ns5="http://www.isotc211.org/2005/gss" xmlns:ns6="http://www.isotc211.org/2005/gsr" xmlns:ns7="http://www.w3.org/2001/SMIL20/Language" srsName="EPSG:31467">
     <gml:coordinates ts="," decimal="." cs=" ">3552874.213911228 5987327.093991194 2.55</gml:coordinates>
    </gml:Point>
   </simBase:position>
   <wb1d2d:pointsMember>
    <tuhh:WPointsObservation gml:id="WPointsObservation119135521282873">
     <gml:description>�bernommen aus Datei: PROF0058.9500.txt</gml:description>
     <gml:name>0058.9500</gml:name>
     <om:resultDefinition>
      <swe:RecordDefinition gml:id="RecordDefinition119135521282854">
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#Waterlevel"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#Depth"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#Area"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#Runoff"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#Alpha"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#DeltaArea"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#DeltaRunoff"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#DeltaAlpha"/>
      </swe:RecordDefinition>
     </om:resultDefinition>
     <om:result><![CDATA[3.002 0.4520000 2.160000 1.000000 1.000000 -0.01381740 -0.03131722 0E-7
3.083 0.5330000 2.805000 1.500000 1.000000 0.003420293 -0.002896670 0E-7
3.148 0.5980000 3.351000 2.000000 1.000000 0.01451369 -0.008660304 0E-7
3.210 0.6600000 3.905000 2.500000 1.000000 0.01177738 0.02157455 0E-7
3.266 0.7160000 4.428000 3.000000 1.000000 0.002423274 0.05011017 0E-7
3.312 0.7620000 4.863000 3.500000 1.000000 -0.00004254951 0.01957027 0E-7
3.359 0.8090000 5.313000 4.000000 1.000000 0.001345162 0.03212372 0E-7
3.401 0.8510000 5.732000 4.500000 1.000000 -0.006514543 0.01822505 0E-7
3.440 0.8900000 6.121000 5.000000 1.000000 -0.007401043 -0.006744169 0E-7
3.478 0.9280000 6.499000 5.500000 1.000000 -0.001546807 -0.02208066 0E-7
3.517 0.9670000 6.906000 6.000000 1.000000 -0.008913999 -0.002396817 0E-7
3.553 1.003000 7.278000 6.500000 1.000000 -0.007049394 -0.002798306 0E-7
3.588 1.038000 7.639000 7.000000 1.000000 -0.00009963343 0.001093172 0E-7
3.621 1.071000 7.989000 7.500000 1.000000 0.0007795767 -0.007533222 0E-7
3.653 1.103000 8.334000 8.000000 1.000000 -0.0003726224 -0.01609553 0E-7
3.684 1.134000 8.673000 8.500000 1.000000 -0.002940187 -0.02610554 0E-7
3.715 1.165000 9.008000 9.000000 1.000000 0.001726043 -0.02256470 0E-7
3.745 1.195000 9.338000 9.500000 1.000000 0.003479868 -0.02250393 0E-7
3.775 1.225000 9.674000 10.00000 1.000000 0.002200445 -0.01003446 0E-7
3.803 1.253000 9.998000 10.50000 1.000000 -0.006736595 -0.02066941 0E-7
3.831 1.281000 10.30700 11.00000 1.000000 0.001877734 -0.02076088 0E-7
3.858 1.308000 10.61700 11.50000 1.000000 0.0005560257 -0.02885149 0E-7
3.884 1.334000 10.91800 12.00000 1.000000 -0.0009690637 -0.04614070 0E-7
3.912 1.362000 11.23900 12.50000 1.000000 0.002986847 -0.01654399 0E-7
3.938 1.388000 11.54300 13.00000 1.000000 0.003003524 -0.01585528 0E-7
3.964 1.414000 11.84900 13.50000 1.000000 0.003213135 -0.006714478 0E-7
3.989 1.439000 12.15200 14.00000 1.000000 -0.003278921 -0.009315567 0E-7
4.015 1.465000 12.45300 14.50000 1.000000 0.006258824 0.01599264 0E-7
4.039 1.489000 12.75100 15.00000 1.000000 -0.003115518 0.008015857 0E-7
4.064 1.514000 13.04600 15.50000 1.000000 0.004567715 0.02767594 0E-7
4.088 1.538000 13.34000 16.00000 1.000000 0.003110190 0.03326895 0E-7
4.112 1.562000 13.63100 16.50000 1.000000 0.006597377 0.04531162 0E-7
4.135 1.585000 13.92000 17.00000 1.000000 0.001657862 0.04194672 0E-7
4.158 1.608000 14.20600 17.50000 1.000000 0.001542757 0.04425950 0E-7
4.181 1.631000 14.49100 18.00000 1.000000 0.004273712 0.05212464 0E-7
4.203 1.653000 14.77400 18.50000 1.000000 -0.001756282 0.04298554 0E-7
4.225 1.675000 15.05500 19.00000 1.000000 -0.004053529 0.03869329 0E-7
4.247 1.697000 15.33400 19.50000 1.000000 -0.002594249 0.03912960 0E-7
4.269 1.719000 15.61100 20.00000 1.000000 0.002646914 0.04417339 0E-7
4.290 1.740000 15.88600 20.50000 1.000000 -0.001254111 0.03044497 0E-7
4.311 1.761000 16.16000 21.00000 1.000000 -0.002482274 0.02069170 0E-7
4.332 1.782000 16.43200 21.50000 1.000000 -0.00001150640 0.01480115 0E-7
4.352 1.802000 16.70300 22.00000 1.000000 -0.008006239 -0.01113223 0E-7
4.373 1.823000 16.97200 22.50000 1.000000 0.0008615816 -0.009814201 0E-7
4.393 1.843000 17.24000 23.00000 1.000000 -0.0008447062 -0.02909675 0E-7
4.413 1.863000 17.50500 23.50000 1.000000 0.002093658 -0.04529414 0E-7
4.432 1.882000 17.76900 24.00000 1.000000 -0.005816017 -0.08292141 0E-7
4.452 1.902000 18.03000 24.50000 1.000000 0.004411024 -0.09341206 0E-7
4.472 1.922000 18.31200 25.00000 1.000000 -0.004631498 -0.1011385 0E-7
4.493 1.943000 18.59800 25.50000 1.000000 -0.002129603 -0.08139955 0E-7
4.514 1.964000 18.88300 26.00000 1.000000 0.003351911 -0.05886979 0E-7
4.534 1.984000 19.16600 26.50000 1.000000 -0.001123166 -0.05875120 0E-7
4.554 2.004000 19.44800 27.00000 1.000000 -0.002733031 -0.05634214 0E-7
4.583 2.033000 19.86000 27.50000 1.000000 -0.004781259 0.1759730 0E-7
4.601 2.051000 20.10900 28.00000 1.000000 0.002731064 0.1326440 0E-7
4.618 2.068000 20.35600 28.50000 1.000000 -0.0005286574 0.06534383 0E-7
4.636 2.086000 20.61100 29.00000 1.000000 0.004142128 0.02489030 0E-7
4.654 2.104000 20.87400 29.50000 1.000000 0.002479951 -0.01422158 0E-7
4.672 2.122000 21.13800 30.00000 1.000000 0.001514736 -0.05208664 0E-7
]]></om:result>
    </tuhh:WPointsObservation>
   </wb1d2d:pointsMember>
   <wb1d2d:polynomialMember>
    <math:Polynomial1D gml:id="Polynomial1D119135521284322">
     <gml:description>Q1(h)</gml:description>
     <gml:name>Q1(h)</gml:name>
     <math:coefficients>-0.295301234526 -0.130028779755 5.9147040287 1.46349447111 -0.498025907911</math:coefficients>
     <math:minRange>0.452</math:minRange>
     <math:maxRange>2.122</math:maxRange>
     <math:domainPhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonRunoff"/>
     <math:rangePhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonWaterlevel"/>
    </math:Polynomial1D>
   </wb1d2d:polynomialMember>
   <wb1d2d:polynomialMember>
    <math:Polynomial1D gml:id="Polynomial1D119135521284346">
     <gml:description>A1(h)</gml:description>
     <gml:name>A1(h)</gml:name>
     <math:coefficients>-0.746552965724 4.60080210644 4.59745927559 -1.49220406133 0.280111385776</math:coefficients>
     <math:minRange>0.452</math:minRange>
     <math:maxRange>2.122</math:maxRange>
     <math:domainPhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonArea"/>
     <math:rangePhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonWaterlevel"/>
    </math:Polynomial1D>
   </wb1d2d:polynomialMember>
   <wb1d2d:polynomialMember>
    <math:Polynomial1D gml:id="Polynomial1D119135521284348">
     <gml:description>al1(h)</gml:description>
     <gml:name>al1(h)</gml:name>
     <math:coefficients>1.0</math:coefficients>
     <math:minRange>0.452</math:minRange>
     <math:maxRange>2.122</math:maxRange>
     <math:domainPhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonAlpha"/>
     <math:rangePhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonWaterlevel"/>
    </math:Polynomial1D>
   </wb1d2d:polynomialMember>
   <wb1d2d:polynomialMember>
    <math:Polynomial1D gml:id="Polynomial1D119135521284318">
     <gml:description>Spl_al</gml:description>
     <gml:name>Spl_al</gml:name>
     <math:coefficients>0.0</math:coefficients>
     <math:minRange>2.122</math:minRange>
     <math:maxRange>2.122</math:maxRange>
     <math:domainPhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonAlpha"/>
     <math:rangePhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonWaterlevel"/>
    </math:Polynomial1D>
   </wb1d2d:polynomialMember>
   <wb1d2d:polynomialMember>
    <math:Polynomial1D gml:id="Polynomial1D119135521284330">
     <gml:description>al2(h)</gml:description>
     <gml:name>al2(h)</gml:name>
     <math:coefficients>0.0</math:coefficients>
     <math:minRange>2.122</math:minRange>
     <math:maxRange>2.122</math:maxRange>
     <math:domainPhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonAlpha"/>
     <math:rangePhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonWaterlevel"/>
    </math:Polynomial1D>
   </wb1d2d:polynomialMember>
   <wb1d2d:station>58.9500</wb1d2d:station>
   <wb1d2d:profileMember xlink:href="terrain.gml#Profile119135521228123"/>
   <wb1d2d:slope>0.00100</wb1d2d:slope>
  </wb1d2d:TeschkeFlowRelation>
 </simBase:flowRelationshipMember>
 <simBase:flowRelationshipMember>
  <wb1d2d:TeschkeFlowRelation gml:id="TeschkeFlowRelation119135521284316">
   <gml:description>Gelesen aus: PROF0059.0000.txt</gml:description>
   <gml:name>59.0000</gml:name>
   <simBase:position>
    <gml:Point xmlns:ns1="http://www.w3.org/2001/SMIL20/" xmlns:st="http://www.seegrid.csiro.au/xml/st" xmlns:ns2="http://www.isotc211.org/2005/gmd" xmlns:ns3="http://www.isotc211.org/2005/gco" xmlns:ns4="http://www.isotc211.org/2005/gts" xmlns:ns5="http://www.isotc211.org/2005/gss" xmlns:ns6="http://www.isotc211.org/2005/gsr" xmlns:ns7="http://www.w3.org/2001/SMIL20/Language" srsName="EPSG:31467">
     <gml:coordinates ts="," decimal="." cs=" ">3552857.828711255 5987372.493791085 2.85</gml:coordinates>
    </gml:Point>
   </simBase:position>
   <wb1d2d:pointsMember>
    <tuhh:WPointsObservation gml:id="WPointsObservation119135521284324">
     <gml:description>�bernommen aus Datei: PROF0059.0000.txt</gml:description>
     <gml:name>0059.0000</gml:name>
     <om:resultDefinition>
      <swe:RecordDefinition gml:id="RecordDefinition119135521284372">
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#Waterlevel"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#Depth"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#Area"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#Runoff"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#Alpha"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#DeltaArea"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#DeltaRunoff"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#DeltaAlpha"/>
      </swe:RecordDefinition>
     </om:resultDefinition>
     <om:result><![CDATA[3.229 0.3790000 2.472000 1.000000 1.000000 -0.01185528 0.05978578 0E-7
3.297 0.4470000 3.213000 1.500000 1.000000 0.003714613 0.01499011 0E-7
3.351 0.5010000 3.830000 2.000000 1.000000 0.006860460 -0.01864915 0E-7
3.398 0.5480000 4.384000 2.500000 1.000000 0.004457553 -0.04236837 0E-7
3.442 0.5920000 4.902000 3.000000 1.000000 0.01145371 -0.04074363 0E-7
3.482 0.6320000 5.392000 3.500000 1.000000 0.004989654 -0.04058746 0E-7
3.520 0.6700000 5.859000 4.000000 1.000000 0.002158739 -0.02860875 0E-7
3.556 0.7060000 6.308000 4.500000 1.000000 -0.003329255 -0.01218296 0E-7
3.589 0.7390000 6.721000 5.000000 1.000000 -0.006953702 -0.01328932 0E-7
3.621 0.7710000 7.118000 5.500000 1.000000 -0.004719143 -0.007329116 0E-7
3.652 0.8020000 7.502000 6.000000 1.000000 -0.00008781322 0.002686059 0E-7
3.681 0.8310000 7.874000 6.500000 1.000000 -0.007055006 -0.003302981 0E-7
3.710 0.8600000 8.237000 7.000000 1.000000 -0.003758430 0.006318057 0E-7
3.738 0.8880000 8.591000 7.500000 1.000000 -0.003024024 0.01253044 0E-7
3.765 0.9150000 8.936000 8.000000 1.000000 -0.005067248 0.01327119 0E-7
3.792 0.9420000 9.274000 8.500000 1.000000 0.0006807345 0.02585738 0E-7
3.818 0.9680000 9.606000 9.000000 1.000000 0.0003807470 0.03017706 0E-7
3.843 0.9930000 9.931000 9.500000 1.000000 -0.005091116 0.02459843 0E-7
3.868 1.018000 10.25000 10.00000 1.000000 -0.004022306 0.02794386 0E-7
3.893 1.043000 10.56400 10.50000 1.000000 0.002564409 0.03984122 0E-7
3.917 1.067000 10.87300 11.00000 1.000000 0.001803272 0.03897297 0E-7
3.941 1.091000 11.17800 11.50000 1.000000 0.005505901 0.04534316 0E-7
3.964 1.114000 11.47700 12.00000 1.000000 0.002787276 0.03712850 0E-7
3.987 1.137000 11.77400 12.50000 1.000000 0.002514253 0.03502860 0E-7
4.009 1.159000 12.06600 13.00000 1.000000 -0.005223753 0.01677302 0E-7
4.032 1.182000 12.35400 13.50000 1.000000 0.004442430 0.02592416 0E-7
4.054 1.204000 12.63900 14.00000 1.000000 0.004660976 0.01799576 0E-7
4.075 1.225000 12.92100 14.50000 1.000000 -0.004599318 -0.007871057 0E-7
4.097 1.247000 13.19900 15.00000 1.000000 0.003678541 -0.006704866 0E-7
4.118 1.268000 13.47400 15.50000 1.000000 0.002514049 -0.02423347 0E-7
4.139 1.289000 13.75200 16.00000 1.000000 -0.001044419 -0.03792935 0E-7
4.161 1.311000 14.03400 16.50000 1.000000 0.005174064 -0.02452019 0E-7
4.182 1.332000 14.31400 17.00000 1.000000 0.001028897 -0.03082953 0E-7
4.203 1.353000 14.59000 17.50000 1.000000 0.001668727 -0.03374563 0E-7
4.224 1.374000 14.86500 18.00000 1.000000 0.004162702 -0.03340168 0E-7
4.244 1.394000 15.13800 18.50000 1.000000 -0.003695297 -0.05396968 0E-7
4.265 1.415000 15.40800 19.00000 1.000000 0.005685139 -0.04762404 0E-7
4.286 1.436000 15.69800 19.50000 1.000000 -0.003846084 -0.03837980 0E-7
4.308 1.458000 15.98800 20.00000 1.000000 0.001243251 -0.001898489 0E-7
4.329 1.479000 16.27500 20.50000 1.000000 -0.002774588 0.01293851 0E-7
4.350 1.500000 16.56100 21.00000 1.000000 -0.004415249 0.03035079 0E-7
4.371 1.521000 16.84400 21.50000 1.000000 -0.001573535 0.05024329 0E-7
4.381 1.531000 16.98300 22.00000 1.000000 -0.003905601 -0.2013433 0E-7
4.401 1.551000 17.24800 22.50000 1.000000 0.005563093 -0.2029273 0E-7
4.422 1.572000 17.54800 23.00000 1.000000 -0.004525530 -0.1773738 0E-7
4.452 1.602000 17.95800 23.50000 1.000000 0.002930064 0.07720786 0E-7
4.472 1.622000 18.23400 24.00000 1.000000 0.007553246 0.08265073 0E-7
4.491 1.641000 18.50700 24.50000 1.000000 0.002987802 0.06453238 0E-7
4.512 1.662000 18.80400 25.00000 1.000000 0.004894386 0.09902516 0E-7
4.532 1.682000 19.10400 25.50000 1.000000 -0.008141301 0.1098608 0E-7
4.553 1.703000 19.40400 26.00000 1.000000 -0.004278770 0.1480769 0E-7
4.573 1.723000 19.70100 26.50000 1.000000 -0.009317800 0.1623767 0E-7
4.594 1.744000 19.99800 27.00000 1.000000 0.003091423 0.2041545 0E-7
4.604 1.754000 20.15700 27.50000 1.000000 -0.007497864 -0.03723054 0E-7
4.623 1.773000 20.44000 28.00000 1.000000 -0.006526713 -0.04476419 0E-7
4.642 1.792000 20.72200 28.50000 1.000000 -0.001839070 -0.05087375 0E-7
4.661 1.811000 21.00300 29.00000 1.000000 0.006696194 -0.05557336 0E-7
4.679 1.829000 21.28200 29.50000 1.000000 0.004741433 -0.08505039 0E-7
4.697 1.847000 21.56100 30.00000 1.000000 0.005580476 -0.1132773 0E-7
]]></om:result>
    </tuhh:WPointsObservation>
   </wb1d2d:pointsMember>
   <wb1d2d:polynomialMember>
    <math:Polynomial1D gml:id="Polynomial1D119135521284333">
     <gml:description>Q1(h)</gml:description>
     <gml:name>Q1(h)</gml:name>
     <math:coefficients>1.82333276466 -10.7027061414 26.0387104251 -8.66122832963 1.1665430909</math:coefficients>
     <math:minRange>0.379</math:minRange>
     <math:maxRange>1.847</math:maxRange>
     <math:domainPhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonRunoff"/>
     <math:rangePhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonWaterlevel"/>
    </math:Polynomial1D>
   </wb1d2d:polynomialMember>
   <wb1d2d:polynomialMember>
    <math:Polynomial1D gml:id="Polynomial1D11913552128431">
     <gml:description>A1(h)</gml:description>
     <gml:name>A1(h)</gml:name>
     <math:coefficients>-0.986287768357 6.73162061735 7.84724203953 -4.68042435298 1.10332428563</math:coefficients>
     <math:minRange>0.379</math:minRange>
     <math:maxRange>1.847</math:maxRange>
     <math:domainPhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonArea"/>
     <math:rangePhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonWaterlevel"/>
    </math:Polynomial1D>
   </wb1d2d:polynomialMember>
   <wb1d2d:polynomialMember>
    <math:Polynomial1D gml:id="Polynomial1D119135521284386">
     <gml:description>al1(h)</gml:description>
     <gml:name>al1(h)</gml:name>
     <math:coefficients>1.0</math:coefficients>
     <math:minRange>0.379</math:minRange>
     <math:maxRange>1.847</math:maxRange>
     <math:domainPhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonAlpha"/>
     <math:rangePhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonWaterlevel"/>
    </math:Polynomial1D>
   </wb1d2d:polynomialMember>
   <wb1d2d:polynomialMember>
    <math:Polynomial1D gml:id="Polynomial1D119135521284378">
     <gml:description>Spl_al</gml:description>
     <gml:name>Spl_al</gml:name>
     <math:coefficients>0.0</math:coefficients>
     <math:minRange>1.847</math:minRange>
     <math:maxRange>1.847</math:maxRange>
     <math:domainPhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonAlpha"/>
     <math:rangePhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonWaterlevel"/>
    </math:Polynomial1D>
   </wb1d2d:polynomialMember>
   <wb1d2d:polynomialMember>
    <math:Polynomial1D gml:id="Polynomial1D119135521284367">
     <gml:description>al2(h)</gml:description>
     <gml:name>al2(h)</gml:name>
     <math:coefficients>0.0</math:coefficients>
     <math:minRange>1.847</math:minRange>
     <math:maxRange>1.847</math:maxRange>
     <math:domainPhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonAlpha"/>
     <math:rangePhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonWaterlevel"/>
    </math:Polynomial1D>
   </wb1d2d:polynomialMember>
   <wb1d2d:station>59.0000</wb1d2d:station>
   <wb1d2d:profileMember xlink:href="terrain.gml#Profile11913552122962"/>
   <wb1d2d:slope>0.00100</wb1d2d:slope>
  </wb1d2d:TeschkeFlowRelation>
 </simBase:flowRelationshipMember>
 <simBase:flowRelationshipMember>
  <wb1d2d:TeschkeFlowRelation gml:id="TeschkeFlowRelation119135521284380">
   <gml:description>Gelesen aus: PROF0059.0500.txt</gml:description>
   <gml:name>59.0500</gml:name>
   <simBase:position>
    <gml:Point xmlns:ns1="http://www.w3.org/2001/SMIL20/" xmlns:st="http://www.seegrid.csiro.au/xml/st" xmlns:ns2="http://www.isotc211.org/2005/gmd" xmlns:ns3="http://www.isotc211.org/2005/gco" xmlns:ns4="http://www.isotc211.org/2005/gts" xmlns:ns5="http://www.isotc211.org/2005/gss" xmlns:ns6="http://www.isotc211.org/2005/gsr" xmlns:ns7="http://www.w3.org/2001/SMIL20/Language" srsName="EPSG:31467">
     <gml:coordinates ts="," decimal="." cs=" ">3552856.640911256 5987422.856890968 2.68</gml:coordinates>
    </gml:Point>
   </simBase:position>
   <wb1d2d:pointsMember>
    <tuhh:WPointsObservation gml:id="WPointsObservation119135521284348">
     <gml:description>�bernommen aus Datei: PROF0059.0500.txt</gml:description>
     <gml:name>0059.0500</gml:name>
     <om:resultDefinition>
      <swe:RecordDefinition gml:id="RecordDefinition119135521284384">
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#Waterlevel"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#Depth"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#Area"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#Runoff"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#Alpha"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#DeltaArea"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#DeltaRunoff"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#DeltaAlpha"/>
      </swe:RecordDefinition>
     </om:resultDefinition>
     <om:result><![CDATA[3.216 0.5360000 2.167000 1.000000 1.000000 -0.01293694 0.09368364 0E-7
3.300 0.6200000 2.848000 1.500000 1.000000 -0.006546202 -0.03788498 0E-7
3.369 0.6890000 3.459000 2.000000 1.000000 -0.003177324 -0.09169365 0E-7
3.437 0.7570000 4.089000 2.500000 1.000000 0.01037701 -0.03525020 0E-7
3.485 0.8050000 4.558000 3.000000 1.000000 0.01576507 -0.07735990 0E-7
3.536 0.8560000 5.066000 3.500000 1.000000 0.02804928 -0.03538723 0E-7
3.582 0.9020000 5.555000 4.000000 1.000000 0.02127701 -0.0001121724 0E-7
3.626 0.9460000 6.027000 4.500000 1.000000 0.02091334 0.05100191 0E-7
3.667 0.9870000 6.486000 5.000000 1.000000 0.009681795 0.09734127 0E-7
3.701 1.021000 6.881000 5.500000 1.000000 -0.008447468 0.07338716 0E-7
3.734 1.054000 7.259000 6.000000 1.000000 -0.01622117 0.05460294 0E-7
3.766 1.086000 7.626000 6.500000 1.000000 -0.02033262 0.03865293 0E-7
3.797 1.117000 7.984000 7.000000 1.000000 -0.02338759 0.02339486 0E-7
3.828 1.148000 8.334000 7.500000 1.000000 -0.01531781 0.02321625 0E-7
3.857 1.177000 8.676000 8.000000 1.000000 -0.01969420 0.004038048 0E-7
3.886 1.206000 9.011000 8.500000 1.000000 -0.01465230 -0.002695990 0E-7
3.914 1.234000 9.340000 9.000000 1.000000 -0.01316298 -0.01494348 0E-7
3.941 1.261000 9.663000 9.500000 1.000000 -0.01555298 -0.03418152 0E-7
3.968 1.288000 9.980000 10.00000 1.000000 -0.01013622 -0.04342018 0E-7
3.995 1.315000 10.30000 10.50000 1.000000 -0.005982326 -0.04288151 0E-7
4.022 1.342000 10.62100 11.00000 1.000000 -0.001149591 -0.03277239 0E-7
4.048 1.368000 10.93800 11.50000 1.000000 -0.002841908 -0.03269008 0E-7
4.074 1.394000 11.25100 12.00000 1.000000 0.0009470460 -0.02406909 0E-7
4.100 1.420000 11.56100 12.50000 1.000000 0.009195098 -0.007054484 0E-7
4.125 1.445000 11.86700 13.00000 1.000000 0.01056721 -0.002132511 0E-7
4.149 1.469000 12.16900 13.50000 1.000000 0.004900337 -0.01031994 0E-7
4.174 1.494000 12.46900 14.00000 1.000000 0.01489441 0.009275589 0E-7
4.198 1.518000 12.76500 14.50000 1.000000 0.01776259 0.01500923 0E-7
4.221 1.541000 13.05900 15.00000 1.000000 0.01136705 0.005972276 0E-7
4.244 1.564000 13.35000 15.50000 1.000000 0.009158887 0.003053042 0E-7
4.267 1.587000 13.63900 16.00000 1.000000 0.01016736 0.006210449 0E-7
4.290 1.610000 13.92500 16.50000 1.000000 0.01542770 0.01541137 0E-7
4.312 1.632000 14.20800 17.00000 1.000000 0.01223393 0.008104920 0E-7
4.334 1.654000 14.49000 17.50000 1.000000 0.01126442 0.006289587 0E-7
4.355 1.675000 14.76900 18.00000 1.000000 0.001705257 -0.01305604 0E-7
4.377 1.697000 15.04600 18.50000 1.000000 0.008266653 -0.004157315 0E-7
4.398 1.718000 15.32100 19.00000 1.000000 0.005220954 -0.01327373 0E-7
4.419 1.739000 15.59400 19.50000 1.000000 0.005481250 -0.01738290 0E-7
4.440 1.760000 15.87400 20.00000 1.000000 0.0001046572 -0.01646975 0E-7
4.461 1.781000 16.15200 20.50000 1.000000 -0.001847549 -0.01051367 0E-7
4.482 1.802000 16.42800 21.00000 1.000000 -0.0003099352 0.0005114464 0E-7
4.502 1.822000 16.70300 21.50000 1.000000 -0.009539680 -0.008056343 0E-7
4.523 1.843000 16.97600 22.00000 1.000000 -0.001889002 0.01296178 0E-7
4.543 1.863000 17.24800 22.50000 1.000000 -0.005016586 0.01398324 0E-7
4.563 1.883000 17.51800 23.00000 1.000000 -0.004525032 0.01974300 0E-7
4.582 1.902000 17.78600 23.50000 1.000000 -0.01399092 0.004645354 0E-7
4.602 1.922000 18.05300 24.00000 1.000000 -0.007125933 0.01978089 0E-7
4.621 1.941000 18.31900 24.50000 1.000000 -0.01124430 0.01368508 0E-7
4.640 1.960000 18.58300 25.00000 1.000000 -0.01162330 0.01205025 0E-7
4.659 1.979000 18.84600 25.50000 1.000000 -0.009188100 0.01493085 0E-7
4.678 1.998000 19.10800 26.00000 1.000000 -0.003861046 0.02238503 0E-7
4.696 2.016000 19.36800 26.50000 1.000000 -0.008785865 0.007405961 0E-7
4.714 2.034000 19.62700 27.00000 1.000000 -0.01086988 -0.003357129 0E-7
4.732 2.052000 19.88500 27.50000 1.000000 -0.01004015 -0.009845592 0E-7
4.750 2.070000 20.14200 28.00000 1.000000 -0.006221500 -0.01199779 0E-7
4.768 2.088000 20.39800 28.50000 1.000000 0.0006634985 -0.009749115 0E-7
4.786 2.106000 20.65200 29.00000 1.000000 0.01169451 -0.003031955 0E-7
4.803 2.123000 20.90500 29.50000 1.000000 0.01104587 -0.02029917 0E-7
4.821 2.141000 21.15800 30.00000 1.000000 0.02748620 -0.004688540 0E-7
]]></om:result>
    </tuhh:WPointsObservation>
   </wb1d2d:pointsMember>
   <wb1d2d:polynomialMember>
    <math:Polynomial1D gml:id="Polynomial1D119135521284336">
     <gml:description>Q1(h)</gml:description>
     <gml:name>Q1(h)</gml:name>
     <math:coefficients>4.57429374994 -18.0759370256 25.5128821464 -7.91885119921 1.18455819464</math:coefficients>
     <math:minRange>0.536</math:minRange>
     <math:maxRange>2.141</math:maxRange>
     <math:domainPhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonRunoff"/>
     <math:rangePhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonWaterlevel"/>
    </math:Polynomial1D>
   </wb1d2d:polynomialMember>
   <wb1d2d:polynomialMember>
    <math:Polynomial1D gml:id="Polynomial1D119135521284380">
     <gml:description>A1(h)</gml:description>
     <gml:name>A1(h)</gml:name>
     <math:coefficients>0.131680926611 -1.40240950471 12.1500315215 -5.13086356111 0.890769527498</math:coefficients>
     <math:minRange>0.536</math:minRange>
     <math:maxRange>2.141</math:maxRange>
     <math:domainPhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonArea"/>
     <math:rangePhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonWaterlevel"/>
    </math:Polynomial1D>
   </wb1d2d:polynomialMember>
   <wb1d2d:polynomialMember>
    <math:Polynomial1D gml:id="Polynomial1D119135521284320">
     <gml:description>al1(h)</gml:description>
     <gml:name>al1(h)</gml:name>
     <math:coefficients>1.0</math:coefficients>
     <math:minRange>0.536</math:minRange>
     <math:maxRange>2.141</math:maxRange>
     <math:domainPhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonAlpha"/>
     <math:rangePhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonWaterlevel"/>
    </math:Polynomial1D>
   </wb1d2d:polynomialMember>
   <wb1d2d:polynomialMember>
    <math:Polynomial1D gml:id="Polynomial1D1191355212843103">
     <gml:description>Spl_al</gml:description>
     <gml:name>Spl_al</gml:name>
     <math:coefficients>0.0</math:coefficients>
     <math:minRange>2.141</math:minRange>
     <math:maxRange>2.141</math:maxRange>
     <math:domainPhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonAlpha"/>
     <math:rangePhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonWaterlevel"/>
    </math:Polynomial1D>
   </wb1d2d:polynomialMember>
   <wb1d2d:polynomialMember>
    <math:Polynomial1D gml:id="Polynomial1D119135521284381">
     <gml:description>al2(h)</gml:description>
     <gml:name>al2(h)</gml:name>
     <math:coefficients>0.0</math:coefficients>
     <math:minRange>2.141</math:minRange>
     <math:maxRange>2.141</math:maxRange>
     <math:domainPhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonAlpha"/>
     <math:rangePhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonWaterlevel"/>
    </math:Polynomial1D>
   </wb1d2d:polynomialMember>
   <wb1d2d:station>59.0500</wb1d2d:station>
   <wb1d2d:profileMember xlink:href="terrain.gml#Profile119135521229623"/>
   <wb1d2d:slope>0.00100</wb1d2d:slope>
  </wb1d2d:TeschkeFlowRelation>
 </simBase:flowRelationshipMember>
 <simBase:flowRelationshipMember>
  <wb1d2d:TeschkeFlowRelation gml:id="TeschkeFlowRelation119135521284325">
   <gml:description>Gelesen aus: PROF0059.1000.txt</gml:description>
   <gml:name>59.1000</gml:name>
   <simBase:position>
    <gml:Point xmlns:ns1="http://www.w3.org/2001/SMIL20/" xmlns:st="http://www.seegrid.csiro.au/xml/st" xmlns:ns2="http://www.isotc211.org/2005/gmd" xmlns:ns3="http://www.isotc211.org/2005/gco" xmlns:ns4="http://www.isotc211.org/2005/gts" xmlns:ns5="http://www.isotc211.org/2005/gss" xmlns:ns6="http://www.isotc211.org/2005/gsr" xmlns:ns7="http://www.w3.org/2001/SMIL20/Language" srsName="EPSG:31467">
     <gml:coordinates ts="," decimal="." cs=" ">3552848.80151127 5987473.3208908485 2.46</gml:coordinates>
    </gml:Point>
   </simBase:position>
   <wb1d2d:pointsMember>
    <tuhh:WPointsObservation gml:id="WPointsObservation119135521284361">
     <gml:description>�bernommen aus Datei: PROF0059.1000.txt</gml:description>
     <gml:name>0059.1000</gml:name>
     <om:resultDefinition>
      <swe:RecordDefinition gml:id="RecordDefinition119135521284319">
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#Waterlevel"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#Depth"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#Area"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#Runoff"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#Alpha"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#DeltaArea"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#DeltaRunoff"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#DeltaAlpha"/>
      </swe:RecordDefinition>
     </om:resultDefinition>
     <om:result><![CDATA[2.964 0.5040000 1.921000 1.000000 1.000000 -0.006863489 0.04860896 0E-7
3.065 0.6050000 2.556000 1.500000 1.000000 -0.003460199 0.001237822 0E-7
3.141 0.6810000 3.067000 2.000000 1.000000 0.003480759 -0.05057622 0E-7
3.215 0.7550000 3.597000 2.500000 1.000000 0.005627759 -0.02992310 0E-7
3.279 0.8190000 4.072000 3.000000 1.000000 0.01108677 -0.01550478 0E-7
3.333 0.8730000 4.495000 3.500000 1.000000 0.006937846 -0.03701193 0E-7
3.391 0.9310000 4.960000 4.000000 1.000000 0.004591170 0.02061990 0E-7
3.437 0.9770000 5.337000 4.500000 1.000000 0.003365267 -0.005972675 0E-7
3.484 1.024000 5.738000 5.000000 1.000000 -0.006058824 0.005317170 0E-7
3.528 1.068000 6.108000 5.500000 1.000000 -0.002817077 0.008550726 0E-7
3.570 1.110000 6.471000 6.000000 1.000000 -0.003792338 0.01049515 0E-7
3.610 1.150000 6.824000 6.500000 1.000000 -0.006984038 0.007650371 0E-7
3.648 1.188000 7.155000 7.000000 1.000000 -0.001275892 -0.003186515 0E-7
3.687 1.227000 7.509000 7.500000 1.000000 -0.005385578 0.01554956 0E-7
3.724 1.264000 7.841000 8.000000 1.000000 -0.001489399 0.02298050 0E-7
3.759 1.299000 8.168000 8.500000 1.000000 -0.007280938 0.01640338 0E-7
3.793 1.333000 8.479000 9.000000 1.000000 -0.003069759 0.007975503 0E-7
3.826 1.366000 8.783000 9.500000 1.000000 0.001834338 -0.003584382 0E-7
3.861 1.401000 9.120000 10.00000 1.000000 -0.004373479 0.02642517 0E-7
3.894 1.434000 9.428000 10.50000 1.000000 0.002490886 0.03722934 0E-7
3.925 1.465000 9.733000 11.00000 1.000000 -0.004097701 0.02670366 0E-7
3.956 1.496000 10.03300 11.50000 1.000000 -0.003130318 0.02535378 0E-7
3.986 1.526000 10.32800 12.00000 1.000000 -0.004422548 0.01652063 0E-7
4.016 1.556000 10.61700 12.50000 1.000000 0.002716303 0.01602280 0E-7
4.045 1.585000 10.90500 13.00000 1.000000 0.003322015 0.006685556 0E-7
4.073 1.613000 11.19000 13.50000 1.000000 -0.0008124282 -0.01238408 0E-7
4.101 1.641000 11.47500 14.00000 1.000000 -0.002738823 -0.02448373 0E-7
4.130 1.670000 11.76500 14.50000 1.000000 0.002815093 -0.01190252 0E-7
4.157 1.697000 12.04400 15.00000 1.000000 0.001198155 -0.02811448 0E-7
4.183 1.723000 12.31400 15.50000 1.000000 0.0003674006 -0.05633624 0E-7
4.211 1.751000 12.60500 16.00000 1.000000 0.001553931 -0.04185479 0E-7
4.237 1.777000 12.87900 16.50000 1.000000 0.001068899 -0.05822895 0E-7
4.265 1.805000 13.16800 17.00000 1.000000 0.009053881 -0.03111938 0E-7
4.292 1.832000 13.45700 17.50000 1.000000 0.008884499 -0.01672502 0E-7
4.318 1.858000 13.74300 18.00000 1.000000 0.003358108 -0.01576473 0E-7
4.345 1.885000 14.02900 18.50000 1.000000 0.01112062 0.01024633 0E-7
4.370 1.910000 14.31200 19.00000 1.000000 0.002462166 0.002505039 0E-7
4.396 1.936000 14.59400 19.50000 1.000000 0.008235383 0.01972933 0E-7
4.421 1.961000 14.87400 20.00000 1.000000 0.007374940 0.02209728 0E-7
4.445 1.985000 15.15300 20.50000 1.000000 -0.001337691 0.008986206 0E-7
4.470 2.010000 15.42900 21.00000 1.000000 0.006694498 0.02094145 0E-7
4.493 2.033000 15.70500 21.50000 1.000000 -0.005691425 -0.003775823 0E-7
4.517 2.057000 15.97900 22.00000 1.000000 -0.002190166 -0.003473517 0E-7
4.540 2.080000 16.25100 22.50000 1.000000 -0.005857942 -0.01986215 0E-7
4.563 2.103000 16.51800 23.00000 1.000000 -0.002113205 -0.03220078 0E-7
4.587 2.127000 16.80500 23.50000 1.000000 -0.003947592 -0.01903464 0E-7
4.611 2.151000 17.09200 24.00000 1.000000 -0.002993448 -0.001489438 0E-7
4.634 2.174000 17.37700 24.50000 1.000000 -0.009340417 -0.001411336 0E-7
4.658 2.198000 17.66100 25.00000 1.000000 0.0003287553 0.02467416 0E-7
4.680 2.220000 17.94400 25.50000 1.000000 -0.01079420 0.01073785 0E-7
4.703 2.243000 18.22500 26.00000 1.000000 -0.004735904 0.02279459 0E-7
4.725 2.265000 18.50600 26.50000 1.000000 -0.008379633 0.01631345 0E-7
4.753 2.293000 18.86400 27.00000 1.000000 -0.009326961 0.1496924 0E-7
4.772 2.312000 19.09600 27.50000 1.000000 0.003621450 0.08284191 0E-7
4.790 2.330000 19.33600 28.00000 1.000000 -0.002280920 -0.004302524 0E-7
4.811 2.351000 19.61000 28.50000 1.000000 -0.0005945533 -0.01955802 0E-7
4.832 2.372000 19.88200 29.00000 1.000000 0.005933074 -0.03149470 0E-7
4.852 2.392000 20.15400 29.50000 1.000000 0.001908614 -0.06358378 0E-7
4.873 2.413000 20.42400 30.00000 1.000000 0.01620431 -0.06902978 0E-7
]]></om:result>
    </tuhh:WPointsObservation>
   </wb1d2d:pointsMember>
   <wb1d2d:polynomialMember>
    <math:Polynomial1D gml:id="Polynomial1D119135521285924">
     <gml:description>Q1(h)</gml:description>
     <gml:name>Q1(h)</gml:name>
     <math:coefficients>1.6039841487 -6.35485892927 11.4913327183 -2.24381818594 0.244157763875</math:coefficients>
     <math:minRange>0.504</math:minRange>
     <math:maxRange>2.413</math:maxRange>
     <math:domainPhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonRunoff"/>
     <math:rangePhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonWaterlevel"/>
    </math:Polynomial1D>
   </wb1d2d:polynomialMember>
   <wb1d2d:polynomialMember>
    <math:Polynomial1D gml:id="Polynomial1D119135521285993">
     <gml:description>A1(h)</gml:description>
     <gml:name>A1(h)</gml:name>
     <math:coefficients>-0.128204369533 1.65834122078 5.69358237928 -2.05521394532 0.362542295176</math:coefficients>
     <math:minRange>0.504</math:minRange>
     <math:maxRange>2.413</math:maxRange>
     <math:domainPhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonArea"/>
     <math:rangePhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonWaterlevel"/>
    </math:Polynomial1D>
   </wb1d2d:polynomialMember>
   <wb1d2d:polynomialMember>
    <math:Polynomial1D gml:id="Polynomial1D119135521285977">
     <gml:description>al1(h)</gml:description>
     <gml:name>al1(h)</gml:name>
     <math:coefficients>1.0</math:coefficients>
     <math:minRange>0.504</math:minRange>
     <math:maxRange>2.413</math:maxRange>
     <math:domainPhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonAlpha"/>
     <math:rangePhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonWaterlevel"/>
    </math:Polynomial1D>
   </wb1d2d:polynomialMember>
   <wb1d2d:polynomialMember>
    <math:Polynomial1D gml:id="Polynomial1D1191355212859103">
     <gml:description>Spl_al</gml:description>
     <gml:name>Spl_al</gml:name>
     <math:coefficients>0.0</math:coefficients>
     <math:minRange>2.413</math:minRange>
     <math:maxRange>2.413</math:maxRange>
     <math:domainPhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonAlpha"/>
     <math:rangePhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonWaterlevel"/>
    </math:Polynomial1D>
   </wb1d2d:polynomialMember>
   <wb1d2d:polynomialMember>
    <math:Polynomial1D gml:id="Polynomial1D119135521285922">
     <gml:description>al2(h)</gml:description>
     <gml:name>al2(h)</gml:name>
     <math:coefficients>0.0</math:coefficients>
     <math:minRange>2.413</math:minRange>
     <math:maxRange>2.413</math:maxRange>
     <math:domainPhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonAlpha"/>
     <math:rangePhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonWaterlevel"/>
    </math:Polynomial1D>
   </wb1d2d:polynomialMember>
   <wb1d2d:station>59.1000</wb1d2d:station>
   <wb1d2d:profileMember xlink:href="terrain.gml#Profile119135521231228"/>
   <wb1d2d:slope>0.00100</wb1d2d:slope>
  </wb1d2d:TeschkeFlowRelation>
 </simBase:flowRelationshipMember>
 <simBase:flowRelationshipMember>
  <wb1d2d:TeschkeFlowRelation gml:id="TeschkeFlowRelation119135521285969">
   <gml:description>Gelesen aus: PROF0059.1500.txt</gml:description>
   <gml:name>59.1500</gml:name>
   <simBase:position>
    <gml:Point xmlns:ns1="http://www.w3.org/2001/SMIL20/" xmlns:st="http://www.seegrid.csiro.au/xml/st" xmlns:ns2="http://www.isotc211.org/2005/gmd" xmlns:ns3="http://www.isotc211.org/2005/gco" xmlns:ns4="http://www.isotc211.org/2005/gts" xmlns:ns5="http://www.isotc211.org/2005/gss" xmlns:ns6="http://www.isotc211.org/2005/gsr" xmlns:ns7="http://www.w3.org/2001/SMIL20/Language" srsName="EPSG:31467">
     <gml:coordinates ts="," decimal="." cs=" ">3552854.9996112594 5987519.926690736 2.78</gml:coordinates>
    </gml:Point>
   </simBase:position>
   <wb1d2d:pointsMember>
    <tuhh:WPointsObservation gml:id="WPointsObservation119135521285998">
     <gml:description>�bernommen aus Datei: PROF0059.1500.txt</gml:description>
     <gml:name>0059.1500</gml:name>
     <om:resultDefinition>
      <swe:RecordDefinition gml:id="RecordDefinition119135521285923">
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#Waterlevel"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#Depth"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#Area"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#Runoff"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#Alpha"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#DeltaArea"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#DeltaRunoff"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#DeltaAlpha"/>
      </swe:RecordDefinition>
     </om:resultDefinition>
     <om:result><![CDATA[3.321 0.5410000 2.377000 1.000000 1.000000 -0.03329207 -0.09232767 0E-7
3.406 0.6260000 3.174000 1.500000 1.000000 0.01844440 0.02412536 0E-7
3.467 0.6870000 3.787000 2.000000 1.000000 0.02235976 0.04745857 0E-7
3.519 0.7390000 4.323000 2.500000 1.000000 0.01702634 0.04423700 0E-7
3.566 0.7860000 4.819000 3.000000 1.000000 0.004244746 0.03168806 0E-7
3.611 0.8310000 5.282000 3.500000 1.000000 0.006955079 0.03131090 0E-7
3.653 0.8730000 5.721000 4.000000 1.000000 0.005232345 0.02565876 0E-7
3.692 0.9120000 6.141000 4.500000 1.000000 -0.006512455 0.008134974 0E-7
3.731 0.9510000 6.546000 5.000000 1.000000 -0.001155359 0.01247783 0E-7
3.767 0.9870000 6.936000 5.500000 1.000000 -0.01050970 -0.003139302 0E-7
3.803 1.023000 7.314000 6.000000 1.000000 -0.006082686 -0.001190526 0E-7
3.837 1.057000 7.682000 6.500000 1.000000 -0.01125539 -0.01143523 0E-7
3.871 1.091000 8.040000 7.000000 1.000000 -0.004809914 -0.006837058 0E-7
3.903 1.123000 8.390000 7.500000 1.000000 -0.01029996 -0.01870214 0E-7
3.935 1.155000 8.732000 8.000000 1.000000 -0.006303026 -0.01806017 0E-7
3.966 1.186000 9.067000 8.500000 1.000000 -0.004666387 -0.02141364 0E-7
3.996 1.216000 9.396000 9.000000 1.000000 -0.006491429 -0.03011706 0E-7
4.025 1.245000 9.719000 9.500000 1.000000 -0.01187726 -0.04543345 0E-7
4.054 1.274000 10.03600 10.00000 1.000000 -0.009899308 -0.05134912 0E-7
4.083 1.303000 10.34800 10.50000 1.000000 -0.001512002 -0.04805172 0E-7
4.111 1.331000 10.65600 11.00000 1.000000 0.001211686 -0.05353643 0E-7
4.139 1.359000 10.97100 11.50000 1.000000 -0.001655108 -0.05075603 0E-7
4.167 1.387000 11.28200 12.00000 1.000000 0.0009405437 -0.03985959 0E-7
4.195 1.415000 11.58900 12.50000 1.000000 0.009055471 -0.02098971 0E-7
4.222 1.442000 11.89700 13.00000 1.000000 0.006411943 -0.01322691 0E-7
4.249 1.469000 12.20300 13.50000 1.000000 0.007295438 0.001707079 0E-7
4.276 1.496000 12.50600 14.00000 1.000000 0.01276721 0.02370155 0E-7
4.302 1.522000 12.80600 14.50000 1.000000 0.01137552 0.03293782 0E-7
4.328 1.548000 13.10300 15.00000 1.000000 0.01457721 0.04853483 0E-7
4.353 1.573000 13.39700 15.50000 1.000000 0.01079445 0.05022133 0E-7
4.378 1.598000 13.68900 16.00000 1.000000 0.01060263 0.05764034 0E-7
4.402 1.622000 13.97900 16.50000 1.000000 0.002292317 0.05009401 0E-7
4.426 1.646000 14.26600 17.00000 1.000000 -0.001438548 0.04771429 0E-7
4.450 1.670000 14.55000 17.50000 1.000000 -0.0005312921 0.05044946 0E-7
4.474 1.694000 14.83300 18.00000 1.000000 0.003074861 0.05825132 0E-7
4.497 1.717000 15.11300 18.50000 1.000000 -0.0006085533 0.04960777 0E-7
4.520 1.740000 15.39200 19.00000 1.000000 -0.001616804 0.04554007 0E-7
4.543 1.763000 15.66800 19.50000 1.000000 0.002109041 0.04601482 0E-7
4.565 1.785000 15.94300 20.00000 1.000000 -0.003648502 0.02895223 0E-7
4.587 1.807000 16.21600 20.50000 1.000000 -0.005709286 0.01599374 0E-7
4.609 1.829000 16.48700 21.00000 1.000000 -0.004017177 0.007117720 0E-7
4.630 1.850000 16.75600 21.50000 1.000000 -0.01103206 -0.02029140 0E-7
4.652 1.872000 17.02400 22.00000 1.000000 -0.002746107 -0.02124108 0E-7
4.673 1.893000 17.29000 22.50000 1.000000 -0.003221485 -0.04111248 0E-7
4.694 1.914000 17.55400 23.00000 1.000000 0.0001132082 -0.05731953 0E-7
4.714 1.934000 17.82200 23.50000 1.000000 -0.01154906 -0.09316521 0E-7
4.737 1.957000 18.10800 24.00000 1.000000 -0.0006059595 -0.05529516 0E-7
4.759 1.979000 18.39300 24.50000 1.000000 0.0006501862 -0.03671886 0E-7
4.780 2.000000 18.67600 25.00000 1.000000 -0.007013933 -0.03798409 0E-7
4.802 2.022000 18.95800 25.50000 1.000000 0.001690752 -0.01159218 0E-7
4.823 2.043000 19.23800 26.00000 1.000000 0.001400452 -0.005394657 0E-7
4.844 2.064000 19.51600 26.50000 1.000000 0.005341109 0.004452935 0E-7
4.864 2.084000 19.79400 27.00000 1.000000 -0.002011353 -0.006578647 0E-7
4.884 2.104000 20.07000 27.50000 1.000000 -0.005226001 -0.01428653 0E-7
4.904 2.124000 20.34400 28.00000 1.000000 -0.004245541 -0.01866181 0E-7
4.924 2.144000 20.61800 28.50000 1.000000 -0.001011663 -0.01969388 0E-7
4.944 2.164000 20.89000 29.00000 1.000000 0.006534955 -0.01737046 0E-7
4.964 2.184000 21.17700 29.50000 1.000000 0.001454652 -0.01167756 0E-7
4.990 2.210000 21.54000 30.00000 1.000000 0.008599031 0.1507865 0E-7
]]></om:result>
    </tuhh:WPointsObservation>
   </wb1d2d:pointsMember>
   <wb1d2d:polynomialMember>
    <math:Polynomial1D gml:id="Polynomial1D119135521285981">
     <gml:description>Q1(h)</gml:description>
     <gml:name>Q1(h)</gml:name>
     <math:coefficients>0.685989115806 -6.5144572988 14.5624095897 -3.49755691695 0.439734898229</math:coefficients>
     <math:minRange>0.541</math:minRange>
     <math:maxRange>2.21</math:maxRange>
     <math:domainPhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonRunoff"/>
     <math:rangePhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonWaterlevel"/>
    </math:Polynomial1D>
   </wb1d2d:polynomialMember>
   <wb1d2d:polynomialMember>
    <math:Polynomial1D gml:id="Polynomial1D119135521285912">
     <gml:description>A1(h)</gml:description>
     <gml:name>A1(h)</gml:name>
     <math:coefficients>-2.63749741517 8.2943084381 2.16222167287 -1.0199217535 0.264272121421</math:coefficients>
     <math:minRange>0.541</math:minRange>
     <math:maxRange>2.21</math:maxRange>
     <math:domainPhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonArea"/>
     <math:rangePhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonWaterlevel"/>
    </math:Polynomial1D>
   </wb1d2d:polynomialMember>
   <wb1d2d:polynomialMember>
    <math:Polynomial1D gml:id="Polynomial1D119135521285931">
     <gml:description>al1(h)</gml:description>
     <gml:name>al1(h)</gml:name>
     <math:coefficients>1.0</math:coefficients>
     <math:minRange>0.541</math:minRange>
     <math:maxRange>2.21</math:maxRange>
     <math:domainPhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonAlpha"/>
     <math:rangePhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonWaterlevel"/>
    </math:Polynomial1D>
   </wb1d2d:polynomialMember>
   <wb1d2d:polynomialMember>
    <math:Polynomial1D gml:id="Polynomial1D119135521285973">
     <gml:description>Spl_al</gml:description>
     <gml:name>Spl_al</gml:name>
     <math:coefficients>0.0</math:coefficients>
     <math:minRange>2.21</math:minRange>
     <math:maxRange>2.21</math:maxRange>
     <math:domainPhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonAlpha"/>
     <math:rangePhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonWaterlevel"/>
    </math:Polynomial1D>
   </wb1d2d:polynomialMember>
   <wb1d2d:polynomialMember>
    <math:Polynomial1D gml:id="Polynomial1D119135521285975">
     <gml:description>al2(h)</gml:description>
     <gml:name>al2(h)</gml:name>
     <math:coefficients>0.0</math:coefficients>
     <math:minRange>2.21</math:minRange>
     <math:maxRange>2.21</math:maxRange>
     <math:domainPhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonAlpha"/>
     <math:rangePhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonWaterlevel"/>
    </math:Polynomial1D>
   </wb1d2d:polynomialMember>
   <wb1d2d:station>59.1500</wb1d2d:station>
   <wb1d2d:profileMember xlink:href="terrain.gml#Profile119135521231230"/>
   <wb1d2d:slope>0.00100</wb1d2d:slope>
  </wb1d2d:TeschkeFlowRelation>
 </simBase:flowRelationshipMember>
 <simBase:flowRelationshipMember>
  <wb1d2d:TeschkeFlowRelation gml:id="TeschkeFlowRelation119135521285963">
   <gml:description>Gelesen aus: PROF0059.2000.txt</gml:description>
   <gml:name>59.2000</gml:name>
   <simBase:position>
    <gml:Point xmlns:ns1="http://www.w3.org/2001/SMIL20/" xmlns:st="http://www.seegrid.csiro.au/xml/st" xmlns:ns2="http://www.isotc211.org/2005/gmd" xmlns:ns3="http://www.isotc211.org/2005/gco" xmlns:ns4="http://www.isotc211.org/2005/gts" xmlns:ns5="http://www.isotc211.org/2005/gss" xmlns:ns6="http://www.isotc211.org/2005/gsr" xmlns:ns7="http://www.w3.org/2001/SMIL20/Language" srsName="EPSG:31467">
     <gml:coordinates ts="," decimal="." cs=" ">3552894.141711193 5987552.0154906595 2.52</gml:coordinates>
    </gml:Point>
   </simBase:position>
   <wb1d2d:pointsMember>
    <tuhh:WPointsObservation gml:id="WPointsObservation119135521285985">
     <gml:description>�bernommen aus Datei: PROF0059.2000.txt</gml:description>
     <gml:name>0059.2000</gml:name>
     <om:resultDefinition>
      <swe:RecordDefinition gml:id="RecordDefinition119135521285927">
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#Waterlevel"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#Depth"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#Area"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#Runoff"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#Alpha"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#DeltaArea"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#DeltaRunoff"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#DeltaAlpha"/>
      </swe:RecordDefinition>
     </om:resultDefinition>
     <om:result><![CDATA[3.075 0.5550000 1.961000 1.000000 1.000000 -0.08873181 0.05387687 0E-7
3.175 0.6550000 2.602000 1.500000 1.000000 0.01831946 -0.04824133 0E-7
3.255 0.7350000 3.178000 2.000000 1.000000 0.04521928 -0.05354860 0E-7
3.321 0.8010000 3.673000 2.500000 1.000000 0.05167396 -0.04699891 0E-7
3.379 0.8590000 4.126000 3.000000 1.000000 0.04309562 -0.03933994 0E-7
3.434 0.9140000 4.557000 3.500000 1.000000 0.03734606 -0.01146573 0E-7
3.482 0.9620000 4.943000 4.000000 1.000000 0.02594175 -0.01872618 0E-7
3.535 1.015000 5.366000 4.500000 1.000000 0.02078626 0.05535204 0E-7
3.578 1.058000 5.723000 5.000000 1.000000 0.006403218 0.04123226 0E-7
3.624 1.104000 6.109000 5.500000 1.000000 -0.009140171 0.07829772 0E-7
3.666 1.146000 6.457000 6.000000 1.000000 -0.01503820 0.08228289 0E-7
3.707 1.187000 6.803000 6.500000 1.000000 -0.02324308 0.08520955 0E-7
3.748 1.228000 7.151000 7.000000 1.000000 -0.02937682 0.09761339 0E-7
3.786 1.266000 7.484000 7.500000 1.000000 -0.04164244 0.07998986 0E-7
3.823 1.303000 7.798000 8.000000 1.000000 -0.03953247 0.05581624 0E-7
3.858 1.338000 8.107000 8.500000 1.000000 -0.04584423 0.01096047 0E-7
3.896 1.376000 8.434000 9.000000 1.000000 -0.03995134 0.01018674 0E-7
3.932 1.412000 8.758000 9.500000 1.000000 -0.04426909 -0.01233461 0E-7
3.964 1.444000 9.043000 10.00000 1.000000 -0.04140898 -0.08439607 0E-7
4.001 1.481000 9.366000 10.50000 1.000000 -0.02702119 -0.08558403 0E-7
4.034 1.514000 9.665000 11.00000 1.000000 -0.02080246 -0.1370849 0E-7
4.067 1.547000 9.964000 11.50000 1.000000 -0.01034129 -0.1851127 0E-7
4.104 1.584000 10.30700 12.00000 1.000000 -0.001102766 -0.1740477 0E-7
4.140 1.620000 10.64600 12.50000 1.000000 0.008196078 -0.1721351 0E-7
4.178 1.658000 11.00100 13.00000 1.000000 0.02708540 -0.1369099 0E-7
4.218 1.698000 11.39700 13.50000 1.000000 0.03189032 -0.06684589 0E-7
4.257 1.737000 11.78700 14.00000 1.000000 0.04014540 -0.003647304 0E-7
4.294 1.774000 12.17100 14.50000 1.000000 0.04109356 0.03826777 0E-7
4.330 1.810000 12.54900 15.00000 1.000000 0.04456269 0.07352953 0E-7
4.365 1.845000 12.92200 15.50000 1.000000 0.04923803 0.1023985 0E-7
4.398 1.878000 13.29100 16.00000 1.000000 0.04269970 0.1095848 0E-7
4.430 1.910000 13.65500 16.50000 1.000000 0.03628369 0.1101797 0E-7
4.466 1.946000 14.06400 17.00000 1.000000 0.03699775 0.1847951 0E-7
4.492 1.972000 14.37400 17.50000 1.000000 0.02794914 0.1080667 0E-7
4.521 2.001000 14.72600 18.00000 1.000000 0.01676758 0.08911237 0E-7
4.550 2.030000 15.07500 18.50000 1.000000 0.01415465 0.08035606 0E-7
4.578 2.058000 15.42200 19.00000 1.000000 0.007025091 0.06513096 0E-7
4.606 2.086000 15.76500 19.50000 1.000000 0.009369396 0.06100409 0E-7
4.632 2.112000 16.10500 20.00000 1.000000 -0.004928878 0.03212970 0E-7
4.658 2.138000 16.44300 20.50000 1.000000 -0.01227103 0.01425305 0E-7
4.684 2.164000 16.77800 21.00000 1.000000 -0.01154141 0.008106670 0E-7
4.709 2.189000 17.11100 21.50000 1.000000 -0.01683273 -0.005263176 0E-7
4.733 2.213000 17.44100 22.00000 1.000000 -0.02762174 -0.02658105 0E-7
4.757 2.237000 17.76900 22.50000 1.000000 -0.03179911 -0.03596525 0E-7
4.781 2.261000 18.09500 23.00000 1.000000 -0.02927017 -0.03275187 0E-7
4.803 2.283000 18.40500 23.50000 1.000000 -0.03390268 -0.05982170 0E-7
4.825 2.305000 18.71500 24.00000 1.000000 -0.03442603 -0.07518761 0E-7
4.847 2.327000 19.02200 24.50000 1.000000 -0.02776533 -0.07829161 0E-7
4.868 2.348000 19.32800 25.00000 1.000000 -0.03038947 -0.09201710 0E-7
4.889 2.369000 19.63200 25.50000 1.000000 -0.02706626 -0.09353731 0E-7
4.910 2.390000 19.93500 26.00000 1.000000 -0.01872898 -0.08232899 0E-7
4.930 2.410000 20.23600 26.50000 1.000000 -0.01942384 -0.08314028 0E-7
4.950 2.430000 20.53600 27.00000 1.000000 -0.01535829 -0.07144768 0E-7
4.970 2.450000 20.83400 27.50000 1.000000 -0.005473358 -0.04676798 0E-7
4.990 2.470000 21.13100 28.00000 1.000000 0.009290352 -0.008607812 0E-7
5.009 2.489000 21.42600 28.50000 1.000000 0.01411307 0.01558912 0E-7
5.028 2.508000 21.72000 29.00000 1.000000 0.02354202 0.05284673 0E-7
5.047 2.527000 22.01300 29.50000 1.000000 0.03762919 0.1036135 0E-7
5.066 2.546000 22.30400 30.00000 1.000000 0.05742692 0.1683461 0E-7
]]></om:result>
    </tuhh:WPointsObservation>
   </wb1d2d:pointsMember>
   <wb1d2d:polynomialMember>
    <math:Polynomial1D gml:id="Polynomial1D119135521287564">
     <gml:description>Q1(h)</gml:description>
     <gml:name>Q1(h)</gml:name>
     <math:coefficients>6.0742163931 -24.5647504099 35.7680930016 -15.5321502888 2.64452964278</math:coefficients>
     <math:minRange>0.555</math:minRange>
     <math:maxRange>2.546</math:maxRange>
     <math:domainPhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonRunoff"/>
     <math:rangePhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonWaterlevel"/>
    </math:Polynomial1D>
   </wb1d2d:polynomialMember>
   <wb1d2d:polynomialMember>
    <math:Polynomial1D gml:id="Polynomial1D1191355212875121">
     <gml:description>A1(h)</gml:description>
     <gml:name>A1(h)</gml:name>
     <math:coefficients>-2.264566873 7.53422654411 -0.261911716774 0.148767712879 0.111533896291</math:coefficients>
     <math:minRange>0.555</math:minRange>
     <math:maxRange>2.546</math:maxRange>
     <math:domainPhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonArea"/>
     <math:rangePhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonWaterlevel"/>
    </math:Polynomial1D>
   </wb1d2d:polynomialMember>
   <wb1d2d:polynomialMember>
    <math:Polynomial1D gml:id="Polynomial1D119135521287531">
     <gml:description>al1(h)</gml:description>
     <gml:name>al1(h)</gml:name>
     <math:coefficients>1.0</math:coefficients>
     <math:minRange>0.555</math:minRange>
     <math:maxRange>2.546</math:maxRange>
     <math:domainPhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonAlpha"/>
     <math:rangePhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonWaterlevel"/>
    </math:Polynomial1D>
   </wb1d2d:polynomialMember>
   <wb1d2d:polynomialMember>
    <math:Polynomial1D gml:id="Polynomial1D1191355212875109">
     <gml:description>Spl_al</gml:description>
     <gml:name>Spl_al</gml:name>
     <math:coefficients>0.0</math:coefficients>
     <math:minRange>2.546</math:minRange>
     <math:maxRange>2.546</math:maxRange>
     <math:domainPhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonAlpha"/>
     <math:rangePhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonWaterlevel"/>
    </math:Polynomial1D>
   </wb1d2d:polynomialMember>
   <wb1d2d:polynomialMember>
    <math:Polynomial1D gml:id="Polynomial1D119135521287536">
     <gml:description>al2(h)</gml:description>
     <gml:name>al2(h)</gml:name>
     <math:coefficients>0.0</math:coefficients>
     <math:minRange>2.546</math:minRange>
     <math:maxRange>2.546</math:maxRange>
     <math:domainPhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonAlpha"/>
     <math:rangePhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonWaterlevel"/>
    </math:Polynomial1D>
   </wb1d2d:polynomialMember>
   <wb1d2d:station>59.2000</wb1d2d:station>
   <wb1d2d:profileMember xlink:href="terrain.gml#Profile119135521232820"/>
   <wb1d2d:slope>0.00100</wb1d2d:slope>
  </wb1d2d:TeschkeFlowRelation>
 </simBase:flowRelationshipMember>
 <simBase:flowRelationshipMember>
  <wb1d2d:TeschkeFlowRelation gml:id="TeschkeFlowRelation119135521287513">
   <gml:description>Gelesen aus: PROF0059.2600.txt</gml:description>
   <gml:name>59.2600</gml:name>
   <simBase:position>
    <gml:Point xmlns:ns1="http://www.w3.org/2001/SMIL20/" xmlns:st="http://www.seegrid.csiro.au/xml/st" xmlns:ns2="http://www.isotc211.org/2005/gmd" xmlns:ns3="http://www.isotc211.org/2005/gco" xmlns:ns4="http://www.isotc211.org/2005/gts" xmlns:ns5="http://www.isotc211.org/2005/gss" xmlns:ns6="http://www.isotc211.org/2005/gsr" xmlns:ns7="http://www.w3.org/2001/SMIL20/Language" srsName="EPSG:31467">
     <gml:coordinates ts="," decimal="." cs=" ">3552936.6085111224 5987593.060590565 2.31</gml:coordinates>
    </gml:Point>
   </simBase:position>
   <wb1d2d:pointsMember>
    <tuhh:WPointsObservation gml:id="WPointsObservation119135521287579">
     <gml:description>�bernommen aus Datei: PROF0059.2600.txt</gml:description>
     <gml:name>0059.2600</gml:name>
     <om:resultDefinition>
      <swe:RecordDefinition gml:id="RecordDefinition1191355212875122">
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#Waterlevel"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#Depth"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#Area"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#Runoff"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#Alpha"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#DeltaArea"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#DeltaRunoff"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#DeltaAlpha"/>
      </swe:RecordDefinition>
     </om:resultDefinition>
     <om:result><![CDATA[2.825 0.5150000 1.839000 1.000000 1.000000 0.01894818 0.1379393 0E-7
2.939 0.6290000 2.426000 1.500000 1.000000 -0.01426585 -0.01359297 0E-7
3.029 0.7190000 2.932000 2.000000 1.000000 -0.02204838 -0.1087429 0E-7
3.120 0.8100000 3.472000 2.500000 1.000000 -0.008757584 -0.09062814 0E-7
3.194 0.8840000 3.948000 3.000000 1.000000 -0.001064597 -0.09311219 0E-7
3.263 0.9530000 4.419000 3.500000 1.000000 0.004282465 -0.07063738 0E-7
3.329 1.019000 4.891000 4.000000 1.000000 0.009408082 -0.02018247 0E-7
3.388 1.078000 5.330000 4.500000 1.000000 0.01377447 0.01231580 0E-7
3.442 1.132000 5.751000 5.000000 1.000000 0.01187410 0.03206691 0E-7
3.490 1.180000 6.139000 5.500000 1.000000 0.006687176 0.01934815 0E-7
3.541 1.231000 6.555000 6.000000 1.000000 0.007692171 0.06253304 0E-7
3.586 1.276000 6.935000 6.500000 1.000000 0.004191909 0.06313576 0E-7
3.629 1.319000 7.308000 7.000000 1.000000 -0.001710914 0.05982218 0E-7
3.671 1.361000 7.667000 7.500000 1.000000 0.004649776 0.06198336 0E-7
3.710 1.400000 8.016000 8.000000 1.000000 0.0008551334 0.04313928 0E-7
3.749 1.439000 8.372000 8.500000 1.000000 -0.004268968 0.03844309 0E-7
3.789 1.479000 8.739000 9.000000 1.000000 -0.005538593 0.06099858 0E-7
3.826 1.516000 9.083000 9.500000 1.000000 -0.005969203 0.05737340 0E-7
3.862 1.552000 9.423000 10.00000 1.000000 -0.006821743 0.05225463 0E-7
3.897 1.587000 9.759000 10.50000 1.000000 -0.008479695 0.04460592 0E-7
3.932 1.622000 10.09000 11.00000 1.000000 -0.0005594129 0.04797595 0E-7
3.965 1.655000 10.41800 11.50000 1.000000 -0.004777392 0.03265120 0E-7
3.997 1.687000 10.74200 12.00000 1.000000 -0.01084641 0.01196298 0E-7
4.029 1.719000 11.06300 12.50000 1.000000 -0.009968126 0.0004560090 0E-7
4.061 1.751000 11.38100 13.00000 1.000000 -0.002087042 -0.001858710 0E-7
4.091 1.781000 11.69600 13.50000 1.000000 -0.007881616 -0.02691189 0E-7
4.120 1.810000 11.99700 14.00000 1.000000 -0.006530255 -0.06007607 0E-7
4.148 1.838000 12.28800 14.50000 1.000000 -0.002328191 -0.1021085 0E-7
4.179 1.869000 12.62300 15.00000 1.000000 -0.006671368 -0.08674843 0E-7
4.208 1.898000 12.92700 15.50000 1.000000 0.002365953 -0.09667293 0E-7
4.236 1.926000 13.22800 16.00000 1.000000 0.007087435 -0.1161438 0E-7
4.264 1.954000 13.54300 16.50000 1.000000 0.001300442 -0.1283396 0E-7
4.294 1.984000 13.87200 17.00000 1.000000 0.007563323 -0.09755511 0E-7
4.323 2.013000 14.19900 17.50000 1.000000 0.008641794 -0.07639117 0E-7
4.351 2.041000 14.52300 18.00000 1.000000 0.005222741 -0.06559661 0E-7
4.379 2.069000 14.84500 18.50000 1.000000 0.007646317 -0.04725835 0E-7
4.406 2.096000 15.16400 19.00000 1.000000 0.005214040 -0.04021277 0E-7
4.434 2.124000 15.48700 19.50000 1.000000 0.01447488 -0.006817562 0E-7
4.461 2.151000 15.81300 20.00000 1.000000 0.01279509 0.01491231 0E-7
4.487 2.177000 16.13600 20.50000 1.000000 0.005841246 0.02425362 0E-7
4.513 2.203000 16.45800 21.00000 1.000000 0.003649181 0.04048218 0E-7
4.539 2.229000 16.77700 21.50000 1.000000 0.008315813 0.06368456 0E-7
4.564 2.254000 17.09400 22.00000 1.000000 0.006266195 0.07342503 0E-7
4.588 2.278000 17.40900 22.50000 1.000000 -0.002851846 0.06899940 0E-7
4.612 2.302000 17.72200 23.00000 1.000000 -0.006426709 0.07074935 0E-7
4.636 2.326000 18.03300 23.50000 1.000000 -0.004371319 0.07875603 0E-7
4.659 2.349000 18.34200 24.00000 1.000000 -0.009870434 0.07154484 0E-7
4.682 2.372000 18.64800 24.50000 1.000000 -0.008872000 0.07023409 0E-7
4.705 2.395000 18.95200 25.00000 1.000000 -0.002292649 0.07490329 0E-7
4.727 2.417000 19.25400 25.50000 1.000000 -0.003787105 0.06330169 0E-7
4.748 2.438000 19.55500 26.00000 1.000000 -0.01474109 0.03474223 0E-7
4.770 2.460000 19.85400 26.50000 1.000000 -0.006455554 0.03419746 0E-7
4.791 2.481000 20.15100 27.00000 1.000000 -0.006792874 0.01633333 0E-7
4.812 2.502000 20.44700 27.50000 1.000000 -0.002790741 0.003798372 0E-7
4.832 2.522000 20.74200 28.00000 1.000000 -0.008902966 -0.02692882 0E-7
4.853 2.543000 21.03500 28.50000 1.000000 0.004830763 -0.02885013 0E-7
4.873 2.563000 21.32700 29.00000 1.000000 0.008266081 -0.04933362 0E-7
4.892 2.582000 21.61700 29.50000 1.000000 0.001980832 -0.08907197 0E-7
4.912 2.602000 21.90600 30.00000 1.000000 0.01490504 -0.09955114 0E-7
]]></om:result>
    </tuhh:WPointsObservation>
   </wb1d2d:pointsMember>
   <wb1d2d:polynomialMember>
    <math:Polynomial1D gml:id="Polynomial1D119135521287515">
     <gml:description>Q1(h)</gml:description>
     <gml:name>Q1(h)</gml:name>
     <math:coefficients>2.29264601236 -7.28382016469 11.0348060776 -2.62008636089 0.392841148855</math:coefficients>
     <math:minRange>0.515</math:minRange>
     <math:maxRange>2.602</math:maxRange>
     <math:domainPhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonRunoff"/>
     <math:rangePhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonWaterlevel"/>
    </math:Polynomial1D>
   </wb1d2d:polynomialMember>
   <wb1d2d:polynomialMember>
    <math:Polynomial1D gml:id="Polynomial1D11913552128755">
     <gml:description>A1(h)</gml:description>
     <gml:name>A1(h)</gml:name>
     <math:coefficients>0.743815039837 -0.55145134641 6.18619355077 -1.94447207971 0.326885674121</math:coefficients>
     <math:minRange>0.515</math:minRange>
     <math:maxRange>2.602</math:maxRange>
     <math:domainPhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonArea"/>
     <math:rangePhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonWaterlevel"/>
    </math:Polynomial1D>
   </wb1d2d:polynomialMember>
   <wb1d2d:polynomialMember>
    <math:Polynomial1D gml:id="Polynomial1D1191355212875119">
     <gml:description>al1(h)</gml:description>
     <gml:name>al1(h)</gml:name>
     <math:coefficients>1.0</math:coefficients>
     <math:minRange>0.515</math:minRange>
     <math:maxRange>2.602</math:maxRange>
     <math:domainPhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonAlpha"/>
     <math:rangePhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonWaterlevel"/>
    </math:Polynomial1D>
   </wb1d2d:polynomialMember>
   <wb1d2d:polynomialMember>
    <math:Polynomial1D gml:id="Polynomial1D1191355212875129">
     <gml:description>Spl_al</gml:description>
     <gml:name>Spl_al</gml:name>
     <math:coefficients>0.0</math:coefficients>
     <math:minRange>2.602</math:minRange>
     <math:maxRange>2.602</math:maxRange>
     <math:domainPhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonAlpha"/>
     <math:rangePhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonWaterlevel"/>
    </math:Polynomial1D>
   </wb1d2d:polynomialMember>
   <wb1d2d:polynomialMember>
    <math:Polynomial1D gml:id="Polynomial1D119135521287514">
     <gml:description>al2(h)</gml:description>
     <gml:name>al2(h)</gml:name>
     <math:coefficients>0.0</math:coefficients>
     <math:minRange>2.602</math:minRange>
     <math:maxRange>2.602</math:maxRange>
     <math:domainPhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonAlpha"/>
     <math:rangePhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonWaterlevel"/>
    </math:Polynomial1D>
   </wb1d2d:polynomialMember>
   <wb1d2d:station>59.2600</wb1d2d:station>
   <wb1d2d:profileMember xlink:href="terrain.gml#Profile119135521234316"/>
   <wb1d2d:slope>0.00100</wb1d2d:slope>
  </wb1d2d:TeschkeFlowRelation>
 </simBase:flowRelationshipMember>
 <simBase:flowRelationshipMember>
  <wb1d2d:TeschkeFlowRelation gml:id="TeschkeFlowRelation119135521287569">
   <gml:description>Gelesen aus: PROF0059.3000.txt</gml:description>
   <gml:name>59.3000</gml:name>
   <simBase:position>
    <gml:Point xmlns:ns1="http://www.w3.org/2001/SMIL20/" xmlns:st="http://www.seegrid.csiro.au/xml/st" xmlns:ns2="http://www.isotc211.org/2005/gmd" xmlns:ns3="http://www.isotc211.org/2005/gco" xmlns:ns4="http://www.isotc211.org/2005/gts" xmlns:ns5="http://www.isotc211.org/2005/gss" xmlns:ns6="http://www.isotc211.org/2005/gsr" xmlns:ns7="http://www.w3.org/2001/SMIL20/Language" srsName="EPSG:31467">
     <gml:coordinates ts="," decimal="." cs=" ">3552968.0972110694 5987620.076190501 3.01</gml:coordinates>
    </gml:Point>
   </simBase:position>
   <wb1d2d:pointsMember>
    <tuhh:WPointsObservation gml:id="WPointsObservation119135521287518">
     <gml:description>�bernommen aus Datei: PROF0059.3000.txt</gml:description>
     <gml:name>0059.3000</gml:name>
     <om:resultDefinition>
      <swe:RecordDefinition gml:id="RecordDefinition119135521287581">
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#Waterlevel"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#Depth"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#Area"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#Runoff"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#Alpha"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#DeltaArea"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#DeltaRunoff"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#DeltaAlpha"/>
      </swe:RecordDefinition>
     </om:resultDefinition>
     <om:result><![CDATA[3.423 0.4130000 2.192000 1.000000 1.000000 -0.02381729 0.07256618 0E-7
3.502 0.4920000 2.842000 1.500000 1.000000 -0.003581252 -0.02629131 0E-7
3.569 0.5590000 3.429000 2.000000 1.000000 0.008299832 -0.05970673 0E-7
3.629 0.6190000 3.974000 2.500000 1.000000 0.02104773 -0.05227077 0E-7
3.683 0.6730000 4.488000 3.000000 1.000000 0.02487202 -0.02898222 0E-7
3.731 0.7210000 4.966000 3.500000 1.000000 0.01882065 -0.01468481 0E-7
3.776 0.7660000 5.424000 4.000000 1.000000 0.01257393 0.006740714 0E-7
3.818 0.8080000 5.861000 4.500000 1.000000 0.004848019 0.02565202 0E-7
3.856 0.8460000 6.264000 5.000000 1.000000 -0.003743984 0.02051059 0E-7
3.893 0.8830000 6.655000 5.500000 1.000000 -0.005482290 0.02434297 0E-7
3.928 0.9180000 7.034000 6.000000 1.000000 -0.01170890 0.01999742 0E-7
3.962 0.9520000 7.404000 6.500000 1.000000 -0.01550706 0.01846702 0E-7
3.995 0.9850000 7.765000 7.000000 1.000000 -0.01735915 0.01763589 0E-7
4.028 1.018000 8.119000 7.500000 1.000000 -0.008657494 0.03136761 0E-7
4.059 1.049000 8.465000 8.000000 1.000000 -0.01078199 0.02677050 0E-7
4.089 1.079000 8.805000 8.500000 1.000000 -0.01514945 0.01763144 0E-7
4.119 1.109000 9.140000 9.000000 1.000000 -0.01176103 0.01942227 0E-7
4.148 1.138000 9.468000 9.500000 1.000000 -0.01006666 0.01460829 0E-7
4.176 1.166000 9.792000 10.00000 1.000000 -0.01335157 0.001943422 0E-7
4.204 1.194000 10.11100 10.50000 1.000000 -0.009302095 -0.001840987 0E-7
4.232 1.222000 10.42600 11.00000 1.000000 0.001076768 0.003100195 0E-7
4.258 1.248000 10.73600 11.50000 1.000000 -0.004697532 -0.02032684 0E-7
4.285 1.275000 11.04800 12.00000 1.000000 0.001366742 -0.01767045 0E-7
4.311 1.301000 11.35800 12.50000 1.000000 -0.0002757791 -0.02623245 0E-7
4.337 1.327000 11.66600 13.00000 1.000000 0.002136639 -0.02758326 0E-7
4.363 1.353000 11.97000 13.50000 1.000000 0.01063039 -0.02175131 0E-7
4.388 1.378000 12.27200 14.00000 1.000000 0.01109794 -0.02861013 0E-7
4.412 1.402000 12.57000 14.50000 1.000000 0.005336604 -0.04894885 0E-7
4.437 1.427000 12.87000 15.00000 1.000000 0.01173710 -0.04277354 0E-7
4.462 1.452000 13.17800 15.50000 1.000000 0.01220654 -0.02989876 0E-7
4.487 1.477000 13.48300 16.00000 1.000000 0.01779368 -0.01027020 0E-7
4.511 1.501000 13.78700 16.50000 1.000000 0.01399958 -0.005007846 0E-7
4.535 1.525000 14.08700 17.00000 1.000000 0.01625871 0.006619175 0E-7
4.558 1.548000 14.38600 17.50000 1.000000 0.008902408 0.002983290 0E-7
4.581 1.571000 14.68300 18.00000 1.000000 0.005536651 0.005364830 0E-7
4.604 1.594000 14.97700 18.50000 1.000000 0.007218263 0.01386533 0E-7
4.627 1.617000 15.27000 19.00000 1.000000 0.01200768 0.02859770 0E-7
4.649 1.639000 15.56100 19.50000 1.000000 0.007881082 0.02689619 0E-7
4.671 1.661000 15.84900 20.00000 1.000000 0.008800706 0.03112850 0E-7
4.692 1.682000 16.13700 20.50000 1.000000 -0.001446479 0.01809398 0E-7
4.713 1.703000 16.42200 21.00000 1.000000 -0.006715975 0.01070202 0E-7
4.734 1.724000 16.70600 21.50000 1.000000 -0.008948630 0.009079879 0E-7
4.755 1.745000 16.98800 22.00000 1.000000 -0.007082786 0.01336273 0E-7
4.776 1.766000 17.26800 22.50000 1.000000 -0.001054271 0.02369362 0E-7
4.796 1.786000 17.54700 23.00000 1.000000 -0.005574535 0.01548396 0E-7
4.816 1.806000 17.82400 23.50000 1.000000 -0.006013012 0.01303397 0E-7
4.835 1.825000 18.10000 24.00000 1.000000 -0.01729506 -0.008827964 0E-7
4.855 1.845000 18.37500 24.50000 1.000000 -0.01149447 0.0003721734 0E-7
4.874 1.864000 18.64800 25.00000 1.000000 -0.01563237 -0.01014577 0E-7
4.893 1.883000 18.92000 25.50000 1.000000 -0.01666347 -0.01492728 0E-7
4.912 1.902000 19.19000 26.00000 1.000000 -0.01352795 -0.01382773 0E-7
4.931 1.921000 19.45900 26.50000 1.000000 -0.007164271 -0.006697178 0E-7
4.949 1.939000 19.72700 27.00000 1.000000 -0.01218084 -0.02055388 0E-7
4.968 1.958000 19.99400 27.50000 1.000000 0.0007047383 -0.001228503 0E-7
4.986 1.976000 20.26000 28.00000 1.000000 0.002090001 -0.003239554 0E-7
5.004 1.994000 20.52400 28.50000 1.000000 0.007704445 0.0007315542 0E-7
5.021 2.011000 20.78800 29.00000 1.000000 0.0004405612 -0.01766829 0E-7
5.039 2.029000 21.05000 29.50000 1.000000 0.01256041 -0.001633759 0E-7
5.057 2.047000 21.31100 30.00000 1.000000 0.02808783 0.02083495 0E-7
]]></om:result>
    </tuhh:WPointsObservation>
   </wb1d2d:pointsMember>
   <wb1d2d:polynomialMember>
    <math:Polynomial1D gml:id="Polynomial1D1191355212875133">
     <gml:description>Q1(h)</gml:description>
     <gml:name>Q1(h)</gml:name>
     <math:coefficients>2.35948496749 -11.5438229859 23.899635018 -9.15680224481 1.6908822424</math:coefficients>
     <math:minRange>0.413</math:minRange>
     <math:maxRange>2.047</math:maxRange>
     <math:domainPhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonRunoff"/>
     <math:rangePhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonWaterlevel"/>
    </math:Polynomial1D>
   </wb1d2d:polynomialMember>
   <wb1d2d:polynomialMember>
    <math:Polynomial1D gml:id="Polynomial1D119135521287555">
     <gml:description>A1(h)</gml:description>
     <gml:name>A1(h)</gml:name>
     <math:coefficients>-0.499902275214 4.33682288032 6.11384334723 -2.57650744428 0.537814011564</math:coefficients>
     <math:minRange>0.413</math:minRange>
     <math:maxRange>2.047</math:maxRange>
     <math:domainPhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonArea"/>
     <math:rangePhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonWaterlevel"/>
    </math:Polynomial1D>
   </wb1d2d:polynomialMember>
   <wb1d2d:polynomialMember>
    <math:Polynomial1D gml:id="Polynomial1D119135521287565">
     <gml:description>al1(h)</gml:description>
     <gml:name>al1(h)</gml:name>
     <math:coefficients>1.0</math:coefficients>
     <math:minRange>0.413</math:minRange>
     <math:maxRange>2.047</math:maxRange>
     <math:domainPhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonAlpha"/>
     <math:rangePhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonWaterlevel"/>
    </math:Polynomial1D>
   </wb1d2d:polynomialMember>
   <wb1d2d:polynomialMember>
    <math:Polynomial1D gml:id="Polynomial1D1191355212875142">
     <gml:description>Spl_al</gml:description>
     <gml:name>Spl_al</gml:name>
     <math:coefficients>0.0</math:coefficients>
     <math:minRange>2.047</math:minRange>
     <math:maxRange>2.047</math:maxRange>
     <math:domainPhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonAlpha"/>
     <math:rangePhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonWaterlevel"/>
    </math:Polynomial1D>
   </wb1d2d:polynomialMember>
   <wb1d2d:polynomialMember>
    <math:Polynomial1D gml:id="Polynomial1D119135521287553">
     <gml:description>al2(h)</gml:description>
     <gml:name>al2(h)</gml:name>
     <math:coefficients>0.0</math:coefficients>
     <math:minRange>2.047</math:minRange>
     <math:maxRange>2.047</math:maxRange>
     <math:domainPhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonAlpha"/>
     <math:rangePhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonWaterlevel"/>
    </math:Polynomial1D>
   </wb1d2d:polynomialMember>
   <wb1d2d:station>59.3000</wb1d2d:station>
   <wb1d2d:profileMember xlink:href="terrain.gml#Profile11913552123435"/>
   <wb1d2d:slope>0.00100</wb1d2d:slope>
  </wb1d2d:TeschkeFlowRelation>
 </simBase:flowRelationshipMember>
 <simBase:flowRelationshipMember>
  <wb1d2d:TeschkeFlowRelation gml:id="TeschkeFlowRelation1191355212875112">
   <gml:description>Gelesen aus: PROF0059.3700.txt</gml:description>
   <gml:name>59.3700</gml:name>
   <simBase:position>
    <gml:Point xmlns:ns1="http://www.w3.org/2001/SMIL20/" xmlns:st="http://www.seegrid.csiro.au/xml/st" xmlns:ns2="http://www.isotc211.org/2005/gmd" xmlns:ns3="http://www.isotc211.org/2005/gco" xmlns:ns4="http://www.isotc211.org/2005/gts" xmlns:ns5="http://www.isotc211.org/2005/gss" xmlns:ns6="http://www.isotc211.org/2005/gsr" xmlns:ns7="http://www.w3.org/2001/SMIL20/Language" srsName="EPSG:31467">
     <gml:coordinates ts="," decimal="." cs=" ">3552948.9493111013 5987681.407790358 2.77</gml:coordinates>
    </gml:Point>
   </simBase:position>
   <wb1d2d:pointsMember>
    <tuhh:WPointsObservation gml:id="WPointsObservation1191355212875136">
     <gml:description>�bernommen aus Datei: PROF0059.3700.txt</gml:description>
     <gml:name>0059.3700</gml:name>
     <om:resultDefinition>
      <swe:RecordDefinition gml:id="RecordDefinition119135521287533">
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#Waterlevel"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#Depth"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#Area"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#Runoff"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#Alpha"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#DeltaArea"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#DeltaRunoff"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#DeltaAlpha"/>
      </swe:RecordDefinition>
     </om:resultDefinition>
     <om:result><![CDATA[3.239 0.4690000 2.142000 1.000000 1.000000 -0.01432967 -0.1225797 0E-7
3.325 0.5550000 2.828000 1.500000 1.000000 0.01220916 0.003182986 0E-7
3.395 0.6250000 3.434000 2.000000 1.000000 0.01252373 0.07439209 0E-7
3.451 0.6810000 3.941000 2.500000 1.000000 0.005957768 0.07383709 0E-7
3.502 0.7320000 4.416000 3.000000 1.000000 -0.002325802 0.06287018 0E-7
3.548 0.7780000 4.841000 3.500000 1.000000 0.002014928 0.03267650 0E-7
3.595 0.8250000 5.295000 4.000000 1.000000 -0.005577432 0.04139513 0E-7
3.636 0.8660000 5.687000 4.500000 1.000000 -0.002096445 0.009195444 0E-7
3.679 0.9090000 6.109000 5.000000 1.000000 -0.003529215 0.02410015 0E-7
3.718 0.9480000 6.495000 5.500000 1.000000 -0.003148839 0.01272725 0E-7
3.753 0.9830000 6.849000 6.000000 1.000000 -0.006526272 -0.03121329 0E-7
3.792 1.022000 7.240000 6.500000 1.000000 -0.002630140 -0.003495704 0E-7
3.827 1.057000 7.599000 7.000000 1.000000 -0.003540214 -0.01243094 0E-7
3.860 1.090000 7.943000 7.500000 1.000000 -0.006757715 -0.03437945 0E-7
3.892 1.122000 8.271000 8.000000 1.000000 -0.001404454 -0.05697734 0E-7
3.927 1.157000 8.635000 8.500000 1.000000 0.002452740 -0.01937937 0E-7
3.958 1.188000 8.969000 9.000000 1.000000 -0.002893016 -0.02991716 0E-7
3.987 1.217000 9.273000 9.500000 1.000000 0.002981896 -0.06088002 0E-7
4.019 1.249000 9.620000 10.00000 1.000000 0.0006552496 -0.03101045 0E-7
4.048 1.278000 9.939000 10.50000 1.000000 -0.003469421 -0.03985857 0E-7
4.077 1.307000 10.24800 11.00000 1.000000 0.004834516 -0.03849803 0E-7
4.103 1.333000 10.53500 11.50000 1.000000 0.004415040 -0.08050551 0E-7
4.133 1.363000 10.87200 12.00000 1.000000 0.0006046131 -0.04230533 0E-7
4.160 1.390000 11.17500 12.50000 1.000000 -0.0001635979 -0.04922232 0E-7
4.187 1.417000 11.47600 13.00000 1.000000 0.003362464 -0.04812667 0E-7
4.214 1.444000 11.78300 13.50000 1.000000 0.003244582 -0.03925700 0E-7
4.241 1.471000 12.09200 14.00000 1.000000 0.003550822 -0.02286626 0E-7
4.268 1.498000 12.39600 14.50000 1.000000 0.01135554 0.0007782296 0E-7
4.294 1.524000 12.69900 15.00000 1.000000 0.01104853 0.01162144 0E-7
4.319 1.549000 13.00100 15.50000 1.000000 0.002426954 0.008668200 0E-7
4.345 1.575000 13.30800 16.00000 1.000000 0.003041269 0.03141486 0E-7
4.372 1.602000 13.63000 16.50000 1.000000 0.003279051 0.08024054 0E-7
4.397 1.627000 13.92900 17.00000 1.000000 0.005273878 0.09354988 0E-7
4.420 1.650000 14.21400 17.50000 1.000000 -0.0005027788 0.06991179 0E-7
4.445 1.675000 14.52500 18.00000 1.000000 -0.005403937 0.09190225 0E-7
4.470 1.700000 14.83000 18.50000 1.000000 -0.001507347 0.1179828 0E-7
4.493 1.723000 15.12200 19.00000 1.000000 -0.006764317 0.1053237 0E-7
4.516 1.746000 15.41300 19.50000 1.000000 -0.008484888 0.09561628 0E-7
4.539 1.769000 15.70200 20.00000 1.000000 -0.005583242 0.08860430 0E-7
4.561 1.791000 15.98800 20.50000 1.000000 -0.009837137 0.06243712 0E-7
4.584 1.814000 16.28300 21.00000 1.000000 -0.007544243 0.05992907 0E-7
4.606 1.836000 16.56200 21.50000 1.000000 0.0005307468 0.03756691 0E-7
4.628 1.858000 16.85700 22.00000 1.000000 -0.004658788 0.01668732 0E-7
4.652 1.882000 17.17300 22.50000 1.000000 -0.001277150 0.04075337 0E-7
4.674 1.904000 17.46700 23.00000 1.000000 0.0005446632 0.02213729 0E-7
4.695 1.925000 17.75800 23.50000 1.000000 -0.005263807 -0.01773174 0E-7
4.716 1.946000 18.04900 24.00000 1.000000 -0.008235250 -0.05723098 0E-7
4.737 1.967000 18.33700 24.50000 1.000000 -0.005282335 -0.09660567 0E-7
4.757 1.987000 18.61100 25.00000 1.000000 0.0006164553 -0.1580282 0E-7
4.778 2.008000 18.91000 25.50000 1.000000 -0.001460733 -0.1978865 0E-7
4.797 2.027000 19.17800 26.00000 1.000000 0.001934689 -0.2821035 0E-7
4.826 2.056000 19.58600 26.50000 1.000000 0.01337529 -0.1489288 0E-7
4.853 2.083000 19.98700 27.00000 1.000000 0.008745558 -0.06154259 0E-7
4.880 2.110000 20.38000 27.50000 1.000000 0.01798530 0.02319131 0E-7
4.905 2.135000 20.76700 28.00000 1.000000 0.008856829 0.06171931 0E-7
4.930 2.160000 21.14800 28.50000 1.000000 0.01113359 0.09696070 0E-7
4.953 2.183000 21.52500 29.00000 1.000000 -0.008317637 0.08604770 0E-7
4.977 2.207000 21.89700 29.50000 1.000000 -0.002016449 0.09254717 0E-7
4.999 2.229000 22.26500 30.00000 1.000000 -0.01842357 0.05299270 0E-7
]]></om:result>
    </tuhh:WPointsObservation>
   </wb1d2d:pointsMember>
   <wb1d2d:polynomialMember>
    <math:Polynomial1D gml:id="Polynomial1D1191355212875124">
     <gml:description>Q1(h)</gml:description>
     <gml:name>Q1(h)</gml:name>
     <math:coefficients>-1.45714693325 3.85300851136 0.632246524883 4.29273282781 -1.12455233475</math:coefficients>
     <math:minRange>0.469</math:minRange>
     <math:maxRange>2.229</math:maxRange>
     <math:domainPhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonRunoff"/>
     <math:rangePhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonWaterlevel"/>
    </math:Polynomial1D>
   </wb1d2d:polynomialMember>
   <wb1d2d:polynomialMember>
    <math:Polynomial1D gml:id="Polynomial1D119135521287519">
     <gml:description>A1(h)</gml:description>
     <gml:name>A1(h)</gml:name>
     <math:coefficients>-0.897538540613 4.44715011097 5.21482579919 -2.24311022694 0.492741944011</math:coefficients>
     <math:minRange>0.469</math:minRange>
     <math:maxRange>2.229</math:maxRange>
     <math:domainPhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonArea"/>
     <math:rangePhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonWaterlevel"/>
    </math:Polynomial1D>
   </wb1d2d:polynomialMember>
   <wb1d2d:polynomialMember>
    <math:Polynomial1D gml:id="Polynomial1D1191355212875137">
     <gml:description>al1(h)</gml:description>
     <gml:name>al1(h)</gml:name>
     <math:coefficients>1.0</math:coefficients>
     <math:minRange>0.469</math:minRange>
     <math:maxRange>2.229</math:maxRange>
     <math:domainPhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonAlpha"/>
     <math:rangePhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonWaterlevel"/>
    </math:Polynomial1D>
   </wb1d2d:polynomialMember>
   <wb1d2d:polynomialMember>
    <math:Polynomial1D gml:id="Polynomial1D1191355212875145">
     <gml:description>Spl_al</gml:description>
     <gml:name>Spl_al</gml:name>
     <math:coefficients>0.0</math:coefficients>
     <math:minRange>2.229</math:minRange>
     <math:maxRange>2.229</math:maxRange>
     <math:domainPhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonAlpha"/>
     <math:rangePhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonWaterlevel"/>
    </math:Polynomial1D>
   </wb1d2d:polynomialMember>
   <wb1d2d:polynomialMember>
    <math:Polynomial1D gml:id="Polynomial1D119135521287574">
     <gml:description>al2(h)</gml:description>
     <gml:name>al2(h)</gml:name>
     <math:coefficients>0.0</math:coefficients>
     <math:minRange>2.229</math:minRange>
     <math:maxRange>2.229</math:maxRange>
     <math:domainPhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonAlpha"/>
     <math:rangePhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonWaterlevel"/>
    </math:Polynomial1D>
   </wb1d2d:polynomialMember>
   <wb1d2d:station>59.3700</wb1d2d:station>
   <wb1d2d:profileMember xlink:href="terrain.gml#Profile119135521235910"/>
   <wb1d2d:slope>0.00100</wb1d2d:slope>
  </wb1d2d:TeschkeFlowRelation>
 </simBase:flowRelationshipMember>
 <simBase:flowRelationshipMember>
  <wb1d2d:TeschkeFlowRelation gml:id="TeschkeFlowRelation1191355212875116">
   <gml:description>Gelesen aus: PROF0059.4000.txt</gml:description>
   <gml:name>59.4000</gml:name>
   <simBase:position>
    <gml:Point xmlns:ns1="http://www.w3.org/2001/SMIL20/" xmlns:st="http://www.seegrid.csiro.au/xml/st" xmlns:ns2="http://www.isotc211.org/2005/gmd" xmlns:ns3="http://www.isotc211.org/2005/gco" xmlns:ns4="http://www.isotc211.org/2005/gts" xmlns:ns5="http://www.isotc211.org/2005/gss" xmlns:ns6="http://www.isotc211.org/2005/gsr" xmlns:ns7="http://www.w3.org/2001/SMIL20/Language" srsName="EPSG:31467">
     <gml:coordinates ts="," decimal="." cs=" ">3552985.1853110404 5987726.633390247 2.68</gml:coordinates>
    </gml:Point>
   </simBase:position>
   <wb1d2d:pointsMember>
    <tuhh:WPointsObservation gml:id="WPointsObservation119135521289037">
     <gml:description>�bernommen aus Datei: PROF0059.4000.txt</gml:description>
     <gml:name>0059.4000</gml:name>
     <om:resultDefinition>
      <swe:RecordDefinition gml:id="RecordDefinition119135521289074">
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#Waterlevel"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#Depth"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#Area"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#Runoff"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#Alpha"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#DeltaArea"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#DeltaRunoff"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#DeltaAlpha"/>
      </swe:RecordDefinition>
     </om:resultDefinition>
     <om:result><![CDATA[3.291 0.6110000 1.895000 1.000000 1.000000 -0.05144657 0.03513108 0E-7
3.402 0.7220000 2.530000 1.500000 1.000000 0.01302748 -0.05258936 0E-7
3.492 0.8120000 3.109000 2.000000 1.000000 0.03740467 -0.05342533 0E-7
3.570 0.8900000 3.652000 2.500000 1.000000 0.04245939 -0.01684087 0E-7
3.639 0.9590000 4.166000 3.000000 1.000000 0.03216069 0.02933740 0E-7
3.697 1.017000 4.615000 3.500000 1.000000 0.02001063 0.03537181 0E-7
3.750 1.070000 5.039000 4.000000 1.000000 0.005812348 0.03214461 0E-7
3.800 1.120000 5.447000 4.500000 1.000000 -0.006355921 0.02870945 0E-7
3.848 1.168000 5.843000 5.000000 1.000000 -0.01395365 0.02925903 0E-7
3.894 1.214000 6.228000 5.500000 1.000000 -0.01900545 0.02960461 0E-7
3.938 1.258000 6.604000 6.000000 1.000000 -0.02447319 0.02614283 0E-7
3.981 1.301000 6.971000 6.500000 1.000000 -0.02261041 0.02759844 0E-7
4.022 1.342000 7.331000 7.000000 1.000000 -0.02463636 0.02008973 0E-7
4.061 1.381000 7.684000 7.500000 1.000000 -0.03138810 0.001172060 0E-7
4.100 1.420000 8.030000 8.000000 1.000000 -0.02547989 -0.005733411 0E-7
4.137 1.457000 8.371000 8.500000 1.000000 -0.02731608 -0.02700661 0E-7
4.174 1.494000 8.707000 9.000000 1.000000 -0.01891294 -0.03775774 0E-7
4.210 1.530000 9.038000 9.500000 1.000000 -0.009708688 -0.05167361 0E-7
4.244 1.564000 9.364000 10.00000 1.000000 -0.009699149 -0.08346905 0E-7
4.278 1.598000 9.686000 10.50000 1.000000 -0.001037623 -0.1063366 0E-7
4.314 1.634000 10.03500 11.00000 1.000000 0.005240765 -0.09128489 0E-7
4.351 1.671000 10.39700 11.50000 1.000000 0.01403907 -0.05117373 0E-7
4.387 1.707000 10.75500 12.00000 1.000000 0.02243532 -0.01494945 0E-7
4.421 1.741000 11.10800 12.50000 1.000000 0.02068061 0.001457727 0E-7
4.455 1.775000 11.45700 13.00000 1.000000 0.02809723 0.02785938 0E-7
4.487 1.807000 11.80300 13.50000 1.000000 0.02237961 0.03273610 0E-7
4.519 1.839000 12.14600 14.00000 1.000000 0.02445453 0.04709899 0E-7
4.550 1.870000 12.48500 14.50000 1.000000 0.02442038 0.05477555 0E-7
4.580 1.900000 12.82100 15.00000 1.000000 0.02093194 0.05521519 0E-7
4.610 1.930000 13.15400 15.50000 1.000000 0.02495051 0.06500406 0E-7
4.638 1.958000 13.48400 16.00000 1.000000 0.01365852 0.04957981 0E-7
4.666 1.986000 13.81200 16.50000 1.000000 0.008469598 0.04296686 0E-7
4.694 2.014000 14.13700 17.00000 1.000000 0.01047381 0.04551966 0E-7
4.721 2.041000 14.46000 17.50000 1.000000 0.006857569 0.03915595 0E-7
4.747 2.067000 14.78000 18.00000 1.000000 -0.001740512 0.02322584 0E-7
4.773 2.093000 15.09700 18.50000 1.000000 -0.003483822 0.01618496 0E-7
4.799 2.119000 15.41200 19.00000 1.000000 0.0007090534 0.01838206 0E-7
4.824 2.144000 15.72600 19.50000 1.000000 -0.002584853 0.01031488 0E-7
4.848 2.168000 16.03700 20.00000 1.000000 -0.01173964 -0.008764068 0E-7
4.872 2.192000 16.34600 20.50000 1.000000 -0.01532976 -0.01903984 0E-7
4.896 2.216000 16.65300 21.00000 1.000000 -0.01328438 -0.02019080 0E-7
4.919 2.239000 16.95800 21.50000 1.000000 -0.01863747 -0.03325671 0E-7
4.942 2.262000 17.26100 22.00000 1.000000 -0.01852006 -0.03733376 0E-7
4.965 2.285000 17.56300 22.50000 1.000000 -0.01386562 -0.03210953 0E-7
4.987 2.307000 17.86300 23.00000 1.000000 -0.01717171 -0.03985124 0E-7
5.009 2.329000 18.16100 23.50000 1.000000 -0.01511897 -0.03849832 0E-7
5.030 2.350000 18.45800 24.00000 1.000000 -0.02251498 -0.05117651 0E-7
5.052 2.372000 18.75300 24.50000 1.000000 -0.01071793 -0.03117983 0E-7
5.073 2.393000 19.04600 25.00000 1.000000 -0.007560588 -0.02549694 0E-7
5.093 2.413000 19.33800 25.50000 1.000000 -0.01445157 -0.03516879 0E-7
5.114 2.434000 19.62800 26.00000 1.000000 -0.001824700 -0.01088767 0E-7
5.134 2.454000 19.91700 26.50000 1.000000 0.0005510660 -0.002321676 0E-7
5.154 2.474000 20.20500 27.00000 1.000000 0.007061628 0.01553198 0E-7
5.173 2.493000 20.49100 27.50000 1.000000 0.003797716 0.01633595 0E-7
5.193 2.513000 20.77600 28.00000 1.000000 0.01957171 0.05306455 0E-7
5.212 2.532000 21.05700 28.50000 1.000000 0.02735423 0.07229076 0E-7
5.229 2.549000 21.31400 29.00000 1.000000 0.03129414 0.04477037 0E-7
5.245 2.565000 21.58400 29.50000 1.001290 0.009120947 -0.003556849 0E-7
5.261 2.581000 21.86600 30.00000 1.002630 -0.02285459 -0.04495849 0E-7
]]></om:result>
    </tuhh:WPointsObservation>
   </wb1d2d:pointsMember>
   <wb1d2d:polynomialMember>
    <math:Polynomial1D gml:id="Polynomial1D119135521289029">
     <gml:description>Q1(h)</gml:description>
     <gml:name>Q1(h)</gml:name>
     <math:coefficients>4.75614905537 -17.3234133675 23.0813284911 -8.55724461356 1.42602469933</math:coefficients>
     <math:minRange>0.611</math:minRange>
     <math:maxRange>2.581</math:maxRange>
     <math:domainPhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonRunoff"/>
     <math:rangePhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonWaterlevel"/>
    </math:Polynomial1D>
   </wb1d2d:polynomialMember>
   <wb1d2d:polynomialMember>
    <math:Polynomial1D gml:id="Polynomial1D1191355212890153">
     <gml:description>A1(h)</gml:description>
     <gml:name>A1(h)</gml:name>
     <math:coefficients>-0.94817594178 2.81453844092 3.36122172439 -0.925962544632 0.204084645979</math:coefficients>
     <math:minRange>0.611</math:minRange>
     <math:maxRange>2.581</math:maxRange>
     <math:domainPhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonArea"/>
     <math:rangePhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonWaterlevel"/>
    </math:Polynomial1D>
   </wb1d2d:polynomialMember>
   <wb1d2d:polynomialMember>
    <math:Polynomial1D gml:id="Polynomial1D11913552128904">
     <gml:description>al1(h)</gml:description>
     <gml:name>al1(h)</gml:name>
     <math:coefficients>1.0</math:coefficients>
     <math:minRange>0.611</math:minRange>
     <math:maxRange>2.549</math:maxRange>
     <math:domainPhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonAlpha"/>
     <math:rangePhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonWaterlevel"/>
    </math:Polynomial1D>
   </wb1d2d:polynomialMember>
   <wb1d2d:polynomialMember>
    <math:Polynomial1D gml:id="Polynomial1D1191355212890155">
     <gml:description>Spl_al</gml:description>
     <gml:name>Spl_al</gml:name>
     <math:coefficients>5079.0615189 -5951.3424719 2324.89257859 -302.734375061</math:coefficients>
     <math:minRange>2.549</math:minRange>
     <math:maxRange>2.565</math:maxRange>
     <math:domainPhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonAlpha"/>
     <math:rangePhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonWaterlevel"/>
    </math:Polynomial1D>
   </wb1d2d:polynomialMember>
   <wb1d2d:polynomialMember>
    <math:Polynomial1D gml:id="Polynomial1D119135521289025">
     <gml:description>al2(h)</gml:description>
     <gml:name>al2(h)</gml:name>
     <math:coefficients>0.78647125 0.08375</math:coefficients>
     <math:minRange>2.565</math:minRange>
     <math:maxRange>2.581</math:maxRange>
     <math:domainPhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonAlpha"/>
     <math:rangePhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonWaterlevel"/>
    </math:Polynomial1D>
   </wb1d2d:polynomialMember>
   <wb1d2d:station>59.4000</wb1d2d:station>
   <wb1d2d:profileMember xlink:href="terrain.gml#Profile119135521235929"/>
   <wb1d2d:slope>0.00100</wb1d2d:slope>
  </wb1d2d:TeschkeFlowRelation>
 </simBase:flowRelationshipMember>
 <simBase:flowRelationshipMember>
  <wb1d2d:TeschkeFlowRelation gml:id="TeschkeFlowRelation119135521289086">
   <gml:description>Gelesen aus: PROF0059.4500.txt</gml:description>
   <gml:name>59.4500</gml:name>
   <simBase:position>
    <gml:Point xmlns:ns1="http://www.w3.org/2001/SMIL20/" xmlns:st="http://www.seegrid.csiro.au/xml/st" xmlns:ns2="http://www.isotc211.org/2005/gmd" xmlns:ns3="http://www.isotc211.org/2005/gco" xmlns:ns4="http://www.isotc211.org/2005/gts" xmlns:ns5="http://www.isotc211.org/2005/gss" xmlns:ns6="http://www.isotc211.org/2005/gsr" xmlns:ns7="http://www.w3.org/2001/SMIL20/Language" srsName="EPSG:31467">
     <gml:coordinates ts="," decimal="." cs=" ">3552987.479811037 5987773.96679014 2.8</gml:coordinates>
    </gml:Point>
   </simBase:position>
   <wb1d2d:pointsMember>
    <tuhh:WPointsObservation gml:id="WPointsObservation119135521289034">
     <gml:description>�bernommen aus Datei: PROF0059.4500.txt</gml:description>
     <gml:name>0059.4500</gml:name>
     <om:resultDefinition>
      <swe:RecordDefinition gml:id="RecordDefinition119135521289052">
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#Waterlevel"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#Depth"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#Area"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#Runoff"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#Alpha"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#DeltaArea"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#DeltaRunoff"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#DeltaAlpha"/>
      </swe:RecordDefinition>
     </om:resultDefinition>
     <om:result><![CDATA[3.255 0.4550000 2.004000 1.000000 1.000000 0.02606520 0.02684168 0E-7
3.352 0.5520000 2.684000 1.500000 1.000000 -0.0004626787 0.04324622 0E-7
3.424 0.6240000 3.222000 2.000000 1.000000 -0.01207103 0.01358563 0E-7
3.488 0.6880000 3.719000 2.500000 1.000000 -0.01536314 -0.005662328 0E-7
3.546 0.7460000 4.184000 3.000000 1.000000 -0.01427377 -0.01901969 0E-7
3.599 0.7990000 4.627000 3.500000 1.000000 -0.01742646 -0.03212547 0E-7
3.649 0.8490000 5.049000 4.000000 1.000000 -0.01343682 -0.03610699 0E-7
3.694 0.8940000 5.438000 4.500000 1.000000 -0.01069125 -0.05952692 0E-7
3.737 0.9370000 5.816000 5.000000 1.000000 -0.007569275 -0.07773502 0E-7
3.780 0.9800000 6.195000 5.500000 1.000000 0.0006741709 -0.07049352 0E-7
3.823 1.023000 6.580000 6.000000 1.000000 0.008584901 -0.03819758 0E-7
3.863 1.063000 6.949000 6.500000 1.000000 0.009815224 -0.02093993 0E-7
3.901 1.101000 7.302000 7.000000 1.000000 0.01248852 -0.01019482 0E-7
3.938 1.138000 7.647000 7.500000 1.000000 0.01729413 0.004854675 0E-7
3.974 1.174000 7.987000 8.000000 1.000000 0.02078690 0.02241938 0E-7
4.008 1.208000 8.320000 8.500000 1.000000 0.01491897 0.02576708 0E-7
4.042 1.242000 8.648000 9.000000 1.000000 0.01659995 0.04288442 0E-7
4.075 1.275000 8.972000 9.500000 1.000000 0.01495151 0.05761308 0E-7
4.107 1.307000 9.289000 10.00000 1.000000 0.01271307 0.06846581 0E-7
4.138 1.338000 9.595000 10.50000 1.000000 0.01365387 0.07403518 0E-7
4.168 1.368000 9.898000 11.00000 1.000000 0.009567812 0.07299392 0E-7
4.197 1.397000 10.19600 11.50000 1.000000 0.002268968 0.06409477 0E-7
4.226 1.426000 10.49100 12.00000 1.000000 -0.0002995166 0.06352695 0E-7
4.255 1.455000 10.78300 12.50000 1.000000 0.001881514 0.07098808 0E-7
4.283 1.483000 11.07200 13.00000 1.000000 -0.001394164 0.06827459 0E-7
4.310 1.510000 11.35700 13.50000 1.000000 -0.009270849 0.05433834 0E-7
4.337 1.537000 11.64000 14.00000 1.000000 -0.01353338 0.04654596 0E-7
4.364 1.564000 11.92000 14.50000 1.000000 -0.01313468 0.04461729 0E-7
4.391 1.591000 12.19700 15.00000 1.000000 -0.008020030 0.04826342 0E-7
4.417 1.617000 12.47200 15.50000 1.000000 -0.009674171 0.03824719 0E-7
4.442 1.642000 12.74500 16.00000 1.000000 -0.01822861 0.01374586 0E-7
4.468 1.668000 13.01500 16.50000 1.000000 -0.01146112 0.01252754 0E-7
4.493 1.693000 13.28400 17.00000 1.000000 -0.01259241 -0.004040308 0E-7
4.517 1.717000 13.54900 17.50000 1.000000 -0.01875976 -0.03665576 0E-7
4.540 1.740000 13.80000 18.00000 1.000000 -0.02010399 -0.08594478 0E-7
4.563 1.763000 14.05000 18.50000 1.000000 -0.01880886 -0.1327098 0E-7
4.590 1.790000 14.33700 19.00000 1.000000 -0.008625165 -0.09772604 0E-7
4.613 1.813000 14.59500 19.50000 1.000000 -0.01152309 -0.1397645 0E-7
4.634 1.834000 14.82600 20.00000 1.000000 -0.007971030 -0.2200355 0E-7
4.659 1.859000 15.10800 20.50000 1.000000 -0.008621631 -0.2186323 0E-7
4.683 1.883000 15.36800 21.00000 1.000000 0.003739035 -0.2357885 0E-7
4.712 1.912000 15.69100 21.50000 1.000000 0.01294980 -0.1507947 0E-7
4.739 1.939000 16.00500 22.00000 1.000000 0.01146380 -0.1050240 0E-7
4.766 1.966000 16.31700 22.50000 1.000000 0.01524173 -0.05859180 0E-7
4.794 1.994000 16.65200 23.00000 1.000000 0.01134257 0.008329529 0E-7
4.822 2.022000 16.97900 23.50000 1.000000 0.01933080 0.07503514 0E-7
4.849 2.049000 17.31000 24.00000 1.000000 0.01522860 0.1208414 0E-7
4.876 2.076000 17.63800 24.50000 1.000000 0.01812335 0.1655490 0E-7
4.902 2.102000 17.96400 25.00000 1.000000 0.01472631 0.1886201 0E-7
4.927 2.127000 18.28600 25.50000 1.000000 0.006762762 0.1898305 0E-7
4.952 2.152000 18.60600 26.00000 1.000000 0.004737228 0.1889540 0E-7
4.976 2.176000 18.91400 26.50000 1.000000 0.005860402 0.1657962 0E-7
5.001 2.201000 19.23900 27.00000 1.000000 0.007067495 0.1597202 0E-7
5.024 2.224000 19.55300 27.50000 1.000000 -0.002875410 0.1112859 0E-7
5.047 2.247000 19.86400 28.00000 1.000000 -0.005882593 0.05980627 0E-7
5.070 2.270000 20.17100 28.50000 1.000000 -0.0008006887 0.004966023 0E-7
5.089 2.289000 20.44500 29.00000 1.000000 -0.01379799 -0.1300552 0E-7
5.113 2.313000 20.77300 29.50000 1.000000 -0.007827019 -0.1729034 0E-7
5.135 2.335000 21.09000 30.00000 1.000000 -0.01433801 -0.2579425 0E-7
]]></om:result>
    </tuhh:WPointsObservation>
   </wb1d2d:pointsMember>
   <wb1d2d:polynomialMember>
    <math:Polynomial1D gml:id="Polynomial1D11913552128908">
     <gml:description>Q1(h)</gml:description>
     <gml:name>Q1(h)</gml:name>
     <math:coefficients>0.294832361061 -1.17627810228 5.44758103897 1.79107037234 -0.683210140559</math:coefficients>
     <math:minRange>0.455</math:minRange>
     <math:maxRange>2.335</math:maxRange>
     <math:domainPhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonRunoff"/>
     <math:rangePhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonWaterlevel"/>
    </math:Polynomial1D>
   </wb1d2d:polynomialMember>
   <wb1d2d:polynomialMember>
    <math:Polynomial1D gml:id="Polynomial1D119135521289047">
     <gml:description>A1(h)</gml:description>
     <gml:name>A1(h)</gml:name>
     <math:coefficients>0.173682436252 1.22648164836 7.6234785371 -3.24357593362 0.597677452724</math:coefficients>
     <math:minRange>0.455</math:minRange>
     <math:maxRange>2.335</math:maxRange>
     <math:domainPhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonArea"/>
     <math:rangePhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonWaterlevel"/>
    </math:Polynomial1D>
   </wb1d2d:polynomialMember>
   <wb1d2d:polynomialMember>
    <math:Polynomial1D gml:id="Polynomial1D119135521289073">
     <gml:description>al1(h)</gml:description>
     <gml:name>al1(h)</gml:name>
     <math:coefficients>1.0</math:coefficients>
     <math:minRange>0.455</math:minRange>
     <math:maxRange>2.335</math:maxRange>
     <math:domainPhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonAlpha"/>
     <math:rangePhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonWaterlevel"/>
    </math:Polynomial1D>
   </wb1d2d:polynomialMember>
   <wb1d2d:polynomialMember>
    <math:Polynomial1D gml:id="Polynomial1D1191355212890166">
     <gml:description>Spl_al</gml:description>
     <gml:name>Spl_al</gml:name>
     <math:coefficients>0.0</math:coefficients>
     <math:minRange>2.335</math:minRange>
     <math:maxRange>2.335</math:maxRange>
     <math:domainPhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonAlpha"/>
     <math:rangePhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonWaterlevel"/>
    </math:Polynomial1D>
   </wb1d2d:polynomialMember>
   <wb1d2d:polynomialMember>
    <math:Polynomial1D gml:id="Polynomial1D1191355212890138">
     <gml:description>al2(h)</gml:description>
     <gml:name>al2(h)</gml:name>
     <math:coefficients>0.0</math:coefficients>
     <math:minRange>2.335</math:minRange>
     <math:maxRange>2.335</math:maxRange>
     <math:domainPhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonAlpha"/>
     <math:rangePhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonWaterlevel"/>
    </math:Polynomial1D>
   </wb1d2d:polynomialMember>
   <wb1d2d:station>59.4500</wb1d2d:station>
   <wb1d2d:profileMember xlink:href="terrain.gml#Profile119135521237530"/>
   <wb1d2d:slope>0.00100</wb1d2d:slope>
  </wb1d2d:TeschkeFlowRelation>
 </simBase:flowRelationshipMember>
 <simBase:flowRelationshipMember>
  <wb1d2d:TeschkeFlowRelation gml:id="TeschkeFlowRelation11913552128905">
   <gml:description>Gelesen aus: PROF0059.5000.txt</gml:description>
   <gml:name>59.5000</gml:name>
   <simBase:position>
    <gml:Point xmlns:ns1="http://www.w3.org/2001/SMIL20/" xmlns:st="http://www.seegrid.csiro.au/xml/st" xmlns:ns2="http://www.isotc211.org/2005/gmd" xmlns:ns3="http://www.isotc211.org/2005/gco" xmlns:ns4="http://www.isotc211.org/2005/gts" xmlns:ns5="http://www.isotc211.org/2005/gss" xmlns:ns6="http://www.isotc211.org/2005/gsr" xmlns:ns7="http://www.w3.org/2001/SMIL20/Language" srsName="EPSG:31467">
     <gml:coordinates ts="," decimal="." cs=" ">3553013.913110992 5987819.153790032 2.85</gml:coordinates>
    </gml:Point>
   </simBase:position>
   <wb1d2d:pointsMember>
    <tuhh:WPointsObservation gml:id="WPointsObservation119135521289011">
     <gml:description>�bernommen aus Datei: PROF0059.5000.txt</gml:description>
     <gml:name>0059.5000</gml:name>
     <om:resultDefinition>
      <swe:RecordDefinition gml:id="RecordDefinition119135521289071">
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#Waterlevel"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#Depth"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#Area"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#Runoff"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#Alpha"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#DeltaArea"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#DeltaRunoff"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#DeltaAlpha"/>
      </swe:RecordDefinition>
     </om:resultDefinition>
     <om:result><![CDATA[3.196 0.3460000 2.186000 1.000000 1.000000 0.03082206 -0.06608544 0E-7
3.273 0.4230000 2.788000 1.500000 1.000000 0.003983304 0.01853691 0E-7
3.340 0.4900000 3.334000 2.000000 1.000000 -0.01254699 0.05408895 0E-7
3.398 0.5480000 3.818000 2.500000 1.000000 -0.01842417 0.04575995 0E-7
3.452 0.6020000 4.280000 3.000000 1.000000 -0.02014986 0.03206380 0E-7
3.504 0.6540000 4.740000 3.500000 1.000000 -0.02419181 0.03013561 0E-7
3.552 0.7020000 5.163000 4.000000 1.000000 -0.01601434 0.01851744 0E-7
3.595 0.7450000 5.551000 4.500000 1.000000 -0.009912451 -0.01887750 0E-7
3.637 0.7870000 5.938000 5.000000 1.000000 -0.005254331 -0.04285738 0E-7
3.681 0.8310000 6.347000 5.500000 1.000000 0.002773995 -0.01744963 0E-7
3.720 0.8700000 6.720000 6.000000 1.000000 0.004855630 -0.02814918 0E-7
3.758 0.9080000 7.083000 6.500000 1.000000 0.01199765 -0.02955959 0E-7
3.794 0.9440000 7.438000 7.000000 1.000000 0.01173235 -0.03702017 0E-7
3.829 0.9790000 7.786000 7.500000 1.000000 0.01226435 -0.03914744 0E-7
3.864 1.014000 8.128000 8.000000 1.000000 0.02226942 -0.02244778 0E-7
3.897 1.047000 8.463000 8.500000 1.000000 0.02224238 -0.01803887 0E-7
3.927 1.077000 8.774000 9.000000 1.000000 0.01829124 -0.04503777 0E-7
3.958 1.108000 9.097000 9.500000 1.000000 0.01504895 -0.04193757 0E-7
3.989 1.139000 9.420000 10.00000 1.000000 0.01427563 -0.02444724 0E-7
4.019 1.169000 9.737000 10.50000 1.000000 0.01142440 -0.01016865 0E-7
4.049 1.199000 10.05000 11.00000 1.000000 0.01482705 0.01710680 0E-7
4.077 1.227000 10.35700 11.50000 1.000000 0.005155648 0.02068428 0E-7
4.104 1.254000 10.65000 12.00000 1.000000 0.0007059210 0.01647356 0E-7
4.131 1.281000 10.93900 12.50000 1.000000 0.002063407 0.02197879 0E-7
4.157 1.307000 11.22400 13.00000 1.000000 -0.001619713 0.01764243 0E-7
4.183 1.333000 11.50700 13.50000 1.000000 -0.001611674 0.02169856 0E-7
4.209 1.359000 11.79800 14.00000 1.000000 -0.007897644 0.03380291 0E-7
4.235 1.385000 12.08800 14.50000 1.000000 -0.01145800 0.05358390 0E-7
4.260 1.410000 12.36400 15.00000 1.000000 -0.01038522 0.06024166 0E-7
4.285 1.435000 12.64900 15.50000 1.000000 -0.01666855 0.07324987 0E-7
4.310 1.460000 12.92100 16.00000 1.000000 -0.008277994 0.09220682 0E-7
4.333 1.483000 13.19100 16.50000 1.000000 -0.01881105 0.07453612 0E-7
4.357 1.507000 13.45800 17.00000 1.000000 -0.01348961 0.08244400 0E-7
4.380 1.530000 13.72300 17.50000 1.000000 -0.01597330 0.07322593 0E-7
4.403 1.553000 13.98600 18.00000 1.000000 -0.01491208 0.06757087 0E-7
4.425 1.575000 14.24700 18.50000 1.000000 -0.02185064 0.04338851 0E-7
4.448 1.598000 14.50600 19.00000 1.000000 -0.01365253 0.04353425 0E-7
4.469 1.619000 14.75800 19.50000 1.000000 -0.02023396 0.002238756 0E-7
4.492 1.642000 15.01800 20.00000 1.000000 -0.009804769 0.006458204 0E-7
4.513 1.663000 15.27200 20.50000 1.000000 -0.01535503 -0.03187949 0E-7
4.534 1.684000 15.51300 21.00000 1.000000 -0.006397617 -0.06936437 0E-7
4.556 1.706000 15.77500 21.50000 1.000000 -0.004874384 -0.08432092 0E-7
4.574 1.724000 15.98700 22.00000 1.000000 0.00003625299 -0.1873908 0E-7
4.598 1.748000 16.27100 22.50000 1.000000 0.007125172 -0.1585082 0E-7
4.616 1.766000 16.48600 23.00000 1.000000 0.01188732 -0.2624506 0E-7
4.638 1.788000 16.76100 23.50000 1.000000 0.007219000 -0.2795120 0E-7
4.662 1.812000 17.04900 24.00000 1.000000 0.01636768 -0.2546432 0E-7
4.693 1.843000 17.42400 24.50000 1.000000 0.02877556 -0.08079405 0E-7
4.721 1.871000 17.78300 25.00000 1.000000 0.02331291 0.02272324 0E-7
4.749 1.899000 18.13800 25.50000 1.000000 0.02543393 0.1202066 0E-7
4.776 1.926000 18.48900 26.00000 1.000000 0.02233378 0.1895414 0E-7
4.803 1.953000 18.83600 26.50000 1.000000 0.02684330 0.2510947 0E-7
4.828 1.978000 19.17700 27.00000 1.000000 0.01465928 0.2631451 0E-7
4.853 2.003000 19.51900 27.50000 1.000000 0.004813040 0.2666609 0E-7
4.876 2.026000 19.83400 28.00000 1.000000 -0.001551725 0.2215570 0E-7
4.895 2.045000 20.10000 28.50000 1.000000 -0.01031246 0.09076999 0E-7
4.914 2.064000 20.36400 29.00000 1.000000 -0.01494933 -0.04641901 0E-7
4.933 2.083000 20.62800 29.50000 1.000000 -0.01740361 -0.1904453 0E-7
4.951 2.101000 20.89000 30.00000 1.000000 -0.02955576 -0.3599156 0E-7
]]></om:result>
    </tuhh:WPointsObservation>
   </wb1d2d:pointsMember>
   <wb1d2d:polynomialMember>
    <math:Polynomial1D gml:id="Polynomial1D119135521290613">
     <gml:description>Q1(h)</gml:description>
     <gml:name>Q1(h)</gml:name>
     <math:coefficients>-1.76934992807 9.15871072077 -7.00928645417 9.87760068396 -2.48906318278</math:coefficients>
     <math:minRange>0.346</math:minRange>
     <math:maxRange>2.101</math:maxRange>
     <math:domainPhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonRunoff"/>
     <math:rangePhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonWaterlevel"/>
    </math:Polynomial1D>
   </wb1d2d:polynomialMember>
   <wb1d2d:polynomialMember>
    <math:Polynomial1D gml:id="Polynomial1D119135521290622">
     <gml:description>A1(h)</gml:description>
     <gml:name>A1(h)</gml:name>
     <math:coefficients>0.188427377502 4.2794421266 5.27343454151 -2.16983268682 0.437586625832</math:coefficients>
     <math:minRange>0.346</math:minRange>
     <math:maxRange>2.101</math:maxRange>
     <math:domainPhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonArea"/>
     <math:rangePhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonWaterlevel"/>
    </math:Polynomial1D>
   </wb1d2d:polynomialMember>
   <wb1d2d:polynomialMember>
    <math:Polynomial1D gml:id="Polynomial1D1191355212906151">
     <gml:description>al1(h)</gml:description>
     <gml:name>al1(h)</gml:name>
     <math:coefficients>1.0</math:coefficients>
     <math:minRange>0.346</math:minRange>
     <math:maxRange>2.101</math:maxRange>
     <math:domainPhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonAlpha"/>
     <math:rangePhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonWaterlevel"/>
    </math:Polynomial1D>
   </wb1d2d:polynomialMember>
   <wb1d2d:polynomialMember>
    <math:Polynomial1D gml:id="Polynomial1D119135521290614">
     <gml:description>Spl_al</gml:description>
     <gml:name>Spl_al</gml:name>
     <math:coefficients>0.0</math:coefficients>
     <math:minRange>2.101</math:minRange>
     <math:maxRange>2.101</math:maxRange>
     <math:domainPhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonAlpha"/>
     <math:rangePhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonWaterlevel"/>
    </math:Polynomial1D>
   </wb1d2d:polynomialMember>
   <wb1d2d:polynomialMember>
    <math:Polynomial1D gml:id="Polynomial1D1191355212906149">
     <gml:description>al2(h)</gml:description>
     <gml:name>al2(h)</gml:name>
     <math:coefficients>0.0</math:coefficients>
     <math:minRange>2.101</math:minRange>
     <math:maxRange>2.101</math:maxRange>
     <math:domainPhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonAlpha"/>
     <math:rangePhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonWaterlevel"/>
    </math:Polynomial1D>
   </wb1d2d:polynomialMember>
   <wb1d2d:station>59.5000</wb1d2d:station>
   <wb1d2d:profileMember xlink:href="terrain.gml#Profile119135521237533"/>
   <wb1d2d:slope>0.00100</wb1d2d:slope>
  </wb1d2d:TeschkeFlowRelation>
 </simBase:flowRelationshipMember>
 <simBase:flowRelationshipMember>
  <wb1d2d:TeschkeFlowRelation gml:id="TeschkeFlowRelation119135521290689">
   <gml:description>Gelesen aus: PROF0059.5500.txt</gml:description>
   <gml:name>59.5500</gml:name>
   <simBase:position>
    <gml:Point xmlns:ns1="http://www.w3.org/2001/SMIL20/" xmlns:st="http://www.seegrid.csiro.au/xml/st" xmlns:ns2="http://www.isotc211.org/2005/gmd" xmlns:ns3="http://www.isotc211.org/2005/gco" xmlns:ns4="http://www.isotc211.org/2005/gts" xmlns:ns5="http://www.isotc211.org/2005/gss" xmlns:ns6="http://www.isotc211.org/2005/gsr" xmlns:ns7="http://www.w3.org/2001/SMIL20/Language" srsName="EPSG:31467">
     <gml:coordinates ts="," decimal="." cs=" ">3553043.235210942 5987861.082089935 2.67</gml:coordinates>
    </gml:Point>
   </simBase:position>
   <wb1d2d:pointsMember>
    <tuhh:WPointsObservation gml:id="WPointsObservation1191355212906123">
     <gml:description>�bernommen aus Datei: PROF0059.5500.txt</gml:description>
     <gml:name>0059.5500</gml:name>
     <om:resultDefinition>
      <swe:RecordDefinition gml:id="RecordDefinition1191355212906109">
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#Waterlevel"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#Depth"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#Area"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#Runoff"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#Alpha"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#DeltaArea"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#DeltaRunoff"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#DeltaAlpha"/>
      </swe:RecordDefinition>
     </om:resultDefinition>
     <om:result><![CDATA[3.203 0.5330000 2.114000 1.000000 1.000000 -0.01661672 -0.09313582 0E-7
3.294 0.6240000 2.829000 1.500000 1.000000 0.01693629 0.02905750 0E-7
3.362 0.6920000 3.414000 2.000000 1.000000 0.01360327 0.05941137 0E-7
3.419 0.7490000 3.926000 2.500000 1.000000 0.003190795 0.04838699 0E-7
3.472 0.8020000 4.405000 3.000000 1.000000 0.001621834 0.04012890 0E-7
3.521 0.8510000 4.860000 3.500000 1.000000 -0.002812102 0.02702138 0E-7
3.567 0.8970000 5.295000 4.000000 1.000000 -0.007040795 0.01263265 0E-7
3.611 0.9410000 5.713000 4.500000 1.000000 -0.006115015 0.003200704 0E-7
3.653 0.9830000 6.118000 5.000000 1.000000 -0.005093080 -0.004604940 0E-7
3.693 1.023000 6.511000 5.500000 1.000000 -0.005943209 -0.01403233 0E-7
3.732 1.062000 6.894000 6.000000 1.000000 -0.001558247 -0.01518116 0E-7
3.769 1.099000 7.267000 6.500000 1.000000 -0.002513548 -0.02314474 0E-7
3.805 1.135000 7.633000 7.000000 1.000000 -0.002354385 -0.02687351 0E-7
3.840 1.170000 7.991000 7.500000 1.000000 -0.0004724009 -0.02783421 0E-7
3.874 1.204000 8.342000 8.000000 1.000000 0.001763390 -0.02746690 0E-7
3.907 1.237000 8.688000 8.500000 1.000000 0.002004628 -0.02718032 0E-7
3.939 1.269000 9.027000 9.000000 1.000000 0.001921835 -0.02834787 0E-7
3.970 1.300000 9.362000 9.500000 1.000000 -0.001797171 -0.03230414 0E-7
4.001 1.331000 9.692000 10.00000 1.000000 0.002376092 -0.02374223 0E-7
4.031 1.361000 10.01800 10.50000 1.000000 0.002511653 -0.01975023 0E-7
4.060 1.390000 10.33900 11.00000 1.000000 -0.0006683072 -0.02157818 0E-7
4.089 1.419000 10.65600 11.50000 1.000000 0.002658782 -0.01270395 0E-7
4.117 1.447000 10.97000 12.00000 1.000000 0.0003163153 -0.01131497 0E-7
4.145 1.475000 11.28000 12.50000 1.000000 0.004307934 -0.0001382490 0E-7
4.172 1.502000 11.58700 13.00000 1.000000 0.002297656 0.001954354 0E-7
4.199 1.529000 11.89100 13.50000 1.000000 0.005462615 0.01295121 0E-7
4.225 1.555000 12.19200 14.00000 1.000000 0.002311770 0.01333863 0E-7
4.251 1.581000 12.49000 14.50000 1.000000 0.004188965 0.02178359 0E-7
4.276 1.606000 12.78500 15.00000 1.000000 -0.0005478548 0.01817277 0E-7
4.301 1.631000 13.07800 15.50000 1.000000 -0.001394268 0.02181417 0E-7
4.326 1.656000 13.36800 16.00000 1.000000 0.002659280 0.03260378 0E-7
4.350 1.680000 13.65600 16.50000 1.000000 -0.001251739 0.02958597 0E-7
4.374 1.704000 13.94200 17.00000 1.000000 -0.001390954 0.03295549 0E-7
4.398 1.728000 14.22500 17.50000 1.000000 0.003253542 0.04260801 0E-7
4.421 1.751000 14.50700 18.00000 1.000000 -0.001401324 0.03682057 0E-7
4.444 1.774000 14.78600 18.50000 1.000000 -0.001393621 0.03660518 0E-7
4.467 1.797000 15.06400 19.00000 1.000000 0.001290043 0.04185963 0E-7
4.489 1.819000 15.33900 19.50000 1.000000 -0.003648470 0.03016742 0E-7
4.511 1.841000 15.61300 20.00000 1.000000 -0.006027106 0.02328784 0E-7
4.533 1.863000 15.88500 20.50000 1.000000 -0.004831703 0.02112273 0E-7
4.555 1.885000 16.15600 21.00000 1.000000 -0.001047304 0.02357111 0E-7
4.576 1.906000 16.42500 21.50000 1.000000 -0.006256343 0.007389248 0E-7
4.597 1.927000 16.69200 22.00000 1.000000 -0.007988829 -0.004776315 0E-7
4.618 1.948000 16.95700 22.50000 1.000000 -0.006229726 -0.01302066 0E-7
4.639 1.969000 17.22200 23.00000 1.000000 -0.002963332 -0.01744121 0E-7
4.660 1.990000 17.48400 23.50000 1.000000 0.004826711 -0.01813776 0E-7
4.680 2.010000 17.74500 24.00000 1.000000 0.002201719 -0.03924187 0E-7
4.700 2.030000 18.00400 24.50000 1.000000 0.002989417 -0.05715106 0E-7
4.720 2.050000 18.26100 25.00000 1.000000 0.007205606 -0.07195749 0E-7
4.740 2.070000 18.52400 25.50000 1.000000 0.006866635 -0.08375526 0E-7
4.761 2.091000 18.80400 26.00000 1.000000 0.004234212 -0.06800996 0E-7
4.782 2.112000 19.08700 26.50000 1.000000 0.0002335500 -0.04916699 0E-7
4.803 2.133000 19.36900 27.00000 1.000000 -0.001114493 -0.02734219 0E-7
4.824 2.154000 19.65000 27.50000 1.000000 0.0002116016 -0.002653744 0E-7
4.845 2.175000 19.92900 28.00000 1.000000 0.005234015 0.02477779 0E-7
4.865 2.195000 20.20700 28.50000 1.000000 -0.0006704826 0.02953139 0E-7
4.885 2.215000 20.48300 29.00000 1.000000 -0.002995369 0.03655344 0E-7
4.905 2.235000 20.75900 29.50000 1.000000 -0.003719814 0.04573385 0E-7
4.925 2.255000 21.03300 30.00000 1.000000 -0.0008224425 0.05696058 0E-7
]]></om:result>
    </tuhh:WPointsObservation>
   </wb1d2d:pointsMember>
   <wb1d2d:polynomialMember>
    <math:Polynomial1D gml:id="Polynomial1D1191355212906140">
     <gml:description>Q1(h)</gml:description>
     <gml:name>Q1(h)</gml:name>
     <math:coefficients>-1.00714666529 1.34199185452 3.21216511359 2.15912132163 -0.504847683438</math:coefficients>
     <math:minRange>0.533</math:minRange>
     <math:maxRange>2.255</math:maxRange>
     <math:domainPhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonRunoff"/>
     <math:rangePhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonWaterlevel"/>
    </math:Polynomial1D>
   </wb1d2d:polynomialMember>
   <wb1d2d:polynomialMember>
    <math:Polynomial1D gml:id="Polynomial1D119135521290612">
     <gml:description>A1(h)</gml:description>
     <gml:name>A1(h)</gml:name>
     <math:coefficients>-1.47354561329 5.17966597298 3.2456810362 -0.81441807156 0.141542043162</math:coefficients>
     <math:minRange>0.533</math:minRange>
     <math:maxRange>2.255</math:maxRange>
     <math:domainPhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonArea"/>
     <math:rangePhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonWaterlevel"/>
    </math:Polynomial1D>
   </wb1d2d:polynomialMember>
   <wb1d2d:polynomialMember>
    <math:Polynomial1D gml:id="Polynomial1D1191355212906117">
     <gml:description>al1(h)</gml:description>
     <gml:name>al1(h)</gml:name>
     <math:coefficients>1.0</math:coefficients>
     <math:minRange>0.533</math:minRange>
     <math:maxRange>2.255</math:maxRange>
     <math:domainPhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonAlpha"/>
     <math:rangePhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonWaterlevel"/>
    </math:Polynomial1D>
   </wb1d2d:polynomialMember>
   <wb1d2d:polynomialMember>
    <math:Polynomial1D gml:id="Polynomial1D1191355212906126">
     <gml:description>Spl_al</gml:description>
     <gml:name>Spl_al</gml:name>
     <math:coefficients>0.0</math:coefficients>
     <math:minRange>2.255</math:minRange>
     <math:maxRange>2.255</math:maxRange>
     <math:domainPhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonAlpha"/>
     <math:rangePhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonWaterlevel"/>
    </math:Polynomial1D>
   </wb1d2d:polynomialMember>
   <wb1d2d:polynomialMember>
    <math:Polynomial1D gml:id="Polynomial1D119135521290630">
     <gml:description>al2(h)</gml:description>
     <gml:name>al2(h)</gml:name>
     <math:coefficients>0.0</math:coefficients>
     <math:minRange>2.255</math:minRange>
     <math:maxRange>2.255</math:maxRange>
     <math:domainPhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonAlpha"/>
     <math:rangePhenomenon xlink:href="urn:ogc:gml:dict:kalypso:model:wspmtuhh:qIntervallPointsComponents#phenomenonWaterlevel"/>
    </math:Polynomial1D>
   </wb1d2d:polynomialMember>
   <wb1d2d:station>59.5500</wb1d2d:station>
   <wb1d2d:profileMember xlink:href="terrain.gml#Profile119135521239024"/>
   <wb1d2d:slope>0.00100</wb1d2d:slope>
  </wb1d2d:TeschkeFlowRelation>
 </simBase:flowRelationshipMember>
 <simBase:flowRelationshipMember>
  <op1d2d:BoundaryCondition gml:id="BoundaryCondition1191481450468245">
   <gml:description>Manuell erzeugt am: 04.10.2007 9:04</gml:description>
   <gml:name>Wasserstand - Zeitreihe</gml:name>
   <simBase:position>
    <gml:Point xmlns:ns1="http://www.w3.org/2001/SMIL20/" xmlns:st="http://www.seegrid.csiro.au/xml/st" xmlns:ns2="http://www.isotc211.org/2005/gmd" xmlns:ns3="http://www.isotc211.org/2005/gco" xmlns:ns4="http://www.isotc211.org/2005/gts" xmlns:ns5="http://www.isotc211.org/2005/gss" xmlns:ns6="http://www.isotc211.org/2005/gsr" xmlns:ns7="http://www.w3.org/2001/SMIL20/Language" srsName="EPSG:31467">
     <gml:coordinates ts="," decimal="." cs=" ">3552976.267011057 5986892.157092223</gml:coordinates>
    </gml:Point>
   </simBase:position>
   <op1d2d:direction/>
   <op1d2d:observation>
    <ns8:ObservationWithSource gml:id="ObservationWithSource1191481450468355">
     <gml:name>Wasserstand - Zeitreihe</gml:name>
     <om:observedProperty xlink:href="urn:ogc:gml:dict:kalypso:model:1d2d:timeserie:phenomenons#TimeserieBorderCondition1D"/>
     <om:resultDefinition>
      <sweExt:SortedRecordDefinition gml:id="SortedRecordDefinition1191481450484200">
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:1d2d:timeserie:components#Time"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:1d2d:timeserie:components#Waterlevel"/>
       <sweExt:sortedComponent xlink:href="urn:ogc:gml:dict:kalypso:model:1d2d:timeserie:components#Time"/>
      </sweExt:SortedRecordDefinition>
     </om:resultDefinition>
     <om:result><![CDATA[2007-10-04T00%3A00%3A00.000%2B02%3A00 20.0
2007-10-04T01%3A00%3A00.000%2B02%3A00 20.0
2007-10-04T02%3A00%3A00.000%2B02%3A00 20.0
2007-10-04T03%3A00%3A00.000%2B02%3A00 20.0
2007-10-04T04%3A00%3A00.000%2B02%3A00 20.0
2007-10-04T05%3A00%3A00.000%2B02%3A00 20.0
2007-10-04T06%3A00%3A00.000%2B02%3A00 20.0
2007-10-04T07%3A00%3A00.000%2B02%3A00 20.0
2007-10-04T08%3A00%3A00.000%2B02%3A00 20.0
2007-10-04T09%3A00%3A00.000%2B02%3A00 20.0
2007-10-04T10%3A00%3A00.000%2B02%3A00 20.0
2007-10-04T11%3A00%3A00.000%2B02%3A00 20.0
2007-10-04T12%3A00%3A00.000%2B02%3A00 20.0
2007-10-04T13%3A00%3A00.000%2B02%3A00 20.0
2007-10-04T14%3A00%3A00.000%2B02%3A00 20.0
2007-10-04T15%3A00%3A00.000%2B02%3A00 20.0
2007-10-04T16%3A00%3A00.000%2B02%3A00 20.0
2007-10-04T17%3A00%3A00.000%2B02%3A00 20.0
2007-10-04T18%3A00%3A00.000%2B02%3A00 20.0
2007-10-04T19%3A00%3A00.000%2B02%3A00 20.0
2007-10-04T20%3A00%3A00.000%2B02%3A00 20.0
2007-10-04T21%3A00%3A00.000%2B02%3A00 20.0
2007-10-04T22%3A00%3A00.000%2B02%3A00 20.0
2007-10-04T23%3A00%3A00.000%2B02%3A00 20.0
2007-10-05T00%3A00%3A00.000%2B02%3A00 20.0
]]></om:result>
     <ns8:dataSourceURI/>
    </ns8:ObservationWithSource>
   </op1d2d:observation>
   <op1d2d:bcType>LINE1D2D</op1d2d:bcType>
   <op1d2d:parentModelElement>ContinuityLine1D11913552388599119</op1d2d:parentModelElement>
   <op1d2d:parentCalculationUnit>CalculationUnit1D119148158759313274</op1d2d:parentCalculationUnit>
   <op1d2d:parentCalculationUnit>CalculationUnit1D2D11915776313123651</op1d2d:parentCalculationUnit>
   <op1d2d:stationaryCondition>4.5</op1d2d:stationaryCondition>
  </op1d2d:BoundaryCondition>
 </simBase:flowRelationshipMember>
 <simBase:flowRelationshipMember>
  <op1d2d:BoundaryCondition gml:id="BoundaryCondition1191481470203193">
   <gml:description>Manuell erzeugt am: 04.10.2007 9:04</gml:description>
   <gml:name>Abfluss - Zeitreihe</gml:name>
   <simBase:position>
    <gml:Point xmlns:ns1="http://www.w3.org/2001/SMIL20/" xmlns:st="http://www.seegrid.csiro.au/xml/st" xmlns:ns2="http://www.isotc211.org/2005/gmd" xmlns:ns3="http://www.isotc211.org/2005/gco" xmlns:ns4="http://www.isotc211.org/2005/gts" xmlns:ns5="http://www.isotc211.org/2005/gss" xmlns:ns6="http://www.isotc211.org/2005/gsr" xmlns:ns7="http://www.w3.org/2001/SMIL20/Language" srsName="EPSG:31467">
     <gml:coordinates ts="," decimal="." cs=" ">3553043.235210942 5987861.082089935</gml:coordinates>
    </gml:Point>
   </simBase:position>
   <op1d2d:direction>235</op1d2d:direction>
   <op1d2d:observation>
    <ns8:ObservationWithSource gml:id="ObservationWithSource1191481470203172">
     <gml:name>Abfluss - Zeitreihe</gml:name>
     <om:observedProperty xlink:href="urn:ogc:gml:dict:kalypso:model:1d2d:timeserie:phenomenons#TimeserieBorderCondition1D"/>
     <om:resultDefinition>
      <sweExt:SortedRecordDefinition gml:id="SortedRecordDefinition1191481470203180">
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:1d2d:timeserie:components#Time"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:1d2d:timeserie:components#Discharge"/>
       <sweExt:sortedComponent xlink:href="urn:ogc:gml:dict:kalypso:model:1d2d:timeserie:components#Time"/>
      </sweExt:SortedRecordDefinition>
     </om:resultDefinition>
     <om:result><![CDATA[2007-10-04T00%3A00%3A00.000%2B02%3A00 20.0
2007-10-04T01%3A00%3A00.000%2B02%3A00 20.0
2007-10-04T02%3A00%3A00.000%2B02%3A00 20.0
2007-10-04T03%3A00%3A00.000%2B02%3A00 20.0
2007-10-04T04%3A00%3A00.000%2B02%3A00 20.0
2007-10-04T05%3A00%3A00.000%2B02%3A00 20.0
2007-10-04T06%3A00%3A00.000%2B02%3A00 20.0
2007-10-04T07%3A00%3A00.000%2B02%3A00 20.0
2007-10-04T08%3A00%3A00.000%2B02%3A00 20.0
2007-10-04T09%3A00%3A00.000%2B02%3A00 20.0
2007-10-04T10%3A00%3A00.000%2B02%3A00 20.0
2007-10-04T11%3A00%3A00.000%2B02%3A00 20.0
2007-10-04T12%3A00%3A00.000%2B02%3A00 20.0
2007-10-04T13%3A00%3A00.000%2B02%3A00 20.0
2007-10-04T14%3A00%3A00.000%2B02%3A00 20.0
2007-10-04T15%3A00%3A00.000%2B02%3A00 20.0
2007-10-04T16%3A00%3A00.000%2B02%3A00 20.0
2007-10-04T17%3A00%3A00.000%2B02%3A00 20.0
2007-10-04T18%3A00%3A00.000%2B02%3A00 20.0
2007-10-04T19%3A00%3A00.000%2B02%3A00 20.0
2007-10-04T20%3A00%3A00.000%2B02%3A00 20.0
2007-10-04T21%3A00%3A00.000%2B02%3A00 20.0
2007-10-04T22%3A00%3A00.000%2B02%3A00 20.0
2007-10-04T23%3A00%3A00.000%2B02%3A00 20.0
2007-10-05T00%3A00%3A00.000%2B02%3A00 20.0
]]></om:result>
     <ns8:dataSourceURI/>
    </ns8:ObservationWithSource>
   </op1d2d:observation>
   <op1d2d:bcType>LINE1D2D</op1d2d:bcType>
   <op1d2d:parentModelElement>ContinuityLine1D11913552508753423</op1d2d:parentModelElement>
   <op1d2d:parentCalculationUnit>CalculationUnit1D119148158759313274</op1d2d:parentCalculationUnit>
   <op1d2d:stationaryCondition>20.0</op1d2d:stationaryCondition>
  </op1d2d:BoundaryCondition>
 </simBase:flowRelationshipMember>
 <simBase:flowRelationshipMember>
  <op1d2d:BoundaryCondition gml:id="BoundaryCondition1191482545687131">
   <gml:description>Manuell erzeugt am: 04.10.2007 9:22</gml:description>
   <gml:name>Wasserstand - Zeitreihe</gml:name>
   <simBase:position>
    <gml:Point xmlns:ns1="http://www.w3.org/2001/SMIL20/" xmlns:st="http://www.seegrid.csiro.au/xml/st" xmlns:ns2="http://www.isotc211.org/2005/gmd" xmlns:ns3="http://www.isotc211.org/2005/gco" xmlns:ns4="http://www.isotc211.org/2005/gts" xmlns:ns5="http://www.isotc211.org/2005/gss" xmlns:ns6="http://www.isotc211.org/2005/gsr" xmlns:ns7="http://www.w3.org/2001/SMIL20/Language" srsName="EPSG:31467">
     <gml:coordinates ts="," decimal="." cs=" ">3553060.0391668202 5987851.926068425 0.0</gml:coordinates>
    </gml:Point>
   </simBase:position>
   <op1d2d:direction/>
   <op1d2d:observation>
    <ns8:ObservationWithSource gml:id="ObservationWithSource1191482545687221">
     <gml:name>Wasserstand - Zeitreihe</gml:name>
     <om:observedProperty xlink:href="urn:ogc:gml:dict:kalypso:model:1d2d:timeserie:phenomenons#TimeserieBorderCondition1D"/>
     <om:resultDefinition>
      <sweExt:SortedRecordDefinition gml:id="SortedRecordDefinition1191482545687330">
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:1d2d:timeserie:components#Time"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:1d2d:timeserie:components#Waterlevel"/>
       <sweExt:sortedComponent xlink:href="urn:ogc:gml:dict:kalypso:model:1d2d:timeserie:components#Time"/>
      </sweExt:SortedRecordDefinition>
     </om:resultDefinition>
     <om:result><![CDATA[2007-09-23T00%3A00%3A00.000%2B02%3A00 8
2007-09-23T12%3A00%3A00.000%2B02%3A00 7.8
2007-09-24T00%3A00%3A00.000%2B02%3A00 7.6
2007-09-24T12%3A00%3A00.000%2B02%3A00 7.4
2007-09-25T00%3A00%3A00.000%2B02%3A00 7.2
2007-09-25T12%3A00%3A00.000%2B02%3A00 7
2007-09-26T00%3A00%3A00.000%2B02%3A00 6.8
2007-09-26T12%3A00%3A00.000%2B02%3A00 6.6
2007-09-27T00%3A00%3A00.000%2B02%3A00 6.4
2007-09-27T12%3A00%3A00.000%2B02%3A00 6.2
2007-09-28T00%3A00%3A00.000%2B02%3A00 6.1
2007-09-28T12%3A00%3A00.000%2B02%3A00 6.0
2007-09-29T00%3A00%3A00.000%2B02%3A00 5.9
2007-09-29T12%3A00%3A00.000%2B02%3A00 5.8
2007-09-30T00%3A00%3A00.000%2B02%3A00 5.7
2007-09-30T12%3A00%3A00.000%2B02%3A00 5.6
2007-10-01T00%3A00%3A00.000%2B02%3A00 5.5
2007-10-01T12%3A00%3A00.000%2B02%3A00 5.4
2007-10-02T00%3A00%3A00.000%2B02%3A00 5.3
2007-10-02T12%3A00%3A00.000%2B02%3A00 5.2
2007-10-03T00%3A00%3A00.000%2B02%3A00 5.1
2007-10-03T12%3A00%3A00.000%2B02%3A00 5.05
]]></om:result>
     <ns8:dataSourceURI/>
    </ns8:ObservationWithSource>
   </op1d2d:observation>
   <op1d2d:bcType>LINE1D2D</op1d2d:bcType>
   <op1d2d:parentModelElement>ContinuityLine2D11913552548599339</op1d2d:parentModelElement>
   <op1d2d:parentCalculationUnit>CalculationUnit2D11914828330154813</op1d2d:parentCalculationUnit>
   <op1d2d:stationaryCondition>8.0</op1d2d:stationaryCondition>
  </op1d2d:BoundaryCondition>
 </simBase:flowRelationshipMember>
 <simBase:flowRelationshipMember>
  <op1d2d:BoundaryCondition gml:id="BoundaryCondition1191482702828121">
   <gml:description>Manuell erzeugt am: 04.10.2007 9:25</gml:description>
   <gml:name>Abfluss - Zeitreihe</gml:name>
   <simBase:position>
    <gml:Point xmlns:ns1="http://www.w3.org/2001/SMIL20/" xmlns:st="http://www.seegrid.csiro.au/xml/st" xmlns:ns2="http://www.isotc211.org/2005/gmd" xmlns:ns3="http://www.isotc211.org/2005/gco" xmlns:ns4="http://www.isotc211.org/2005/gts" xmlns:ns5="http://www.isotc211.org/2005/gss" xmlns:ns6="http://www.isotc211.org/2005/gsr" xmlns:ns7="http://www.w3.org/2001/SMIL20/Language" srsName="EPSG:31467">
     <gml:coordinates ts="," decimal="." cs=" ">3553520.9015082084 5989132.229181283 0.0</gml:coordinates>
    </gml:Point>
   </simBase:position>
   <op1d2d:direction>260</op1d2d:direction>
   <op1d2d:observation>
    <ns8:ObservationWithSource gml:id="ObservationWithSource119148270282896">
     <gml:name>Abfluss - Zeitreihe</gml:name>
     <om:observedProperty xlink:href="urn:ogc:gml:dict:kalypso:model:1d2d:timeserie:phenomenons#TimeserieBorderCondition1D"/>
     <om:resultDefinition>
      <sweExt:SortedRecordDefinition gml:id="SortedRecordDefinition1191482702843244">
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:1d2d:timeserie:components#Time"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:1d2d:timeserie:components#Discharge"/>
       <sweExt:sortedComponent xlink:href="urn:ogc:gml:dict:kalypso:model:1d2d:timeserie:components#Time"/>
      </sweExt:SortedRecordDefinition>
     </om:resultDefinition>
     <om:result><![CDATA[2007-09-23T00%3A00%3A00.000%2B02%3A00 1
2007-09-23T12%3A00%3A00.000%2B02%3A00 1
2007-09-24T00%3A00%3A00.000%2B02%3A00 2
2007-09-24T12%3A00%3A00.000%2B02%3A00 3
2007-09-25T00%3A00%3A00.000%2B02%3A00 4
2007-09-25T12%3A00%3A00.000%2B02%3A00 5
2007-09-26T00%3A00%3A00.000%2B02%3A00 7
2007-09-26T12%3A00%3A00.000%2B02%3A00 9
2007-09-27T00%3A00%3A00.000%2B02%3A00 10.0
2007-09-27T12%3A00%3A00.000%2B02%3A00 10.0
2007-09-28T00%3A00%3A00.000%2B02%3A00 10.0
2007-09-28T12%3A00%3A00.000%2B02%3A00 10.0
2007-09-29T00%3A00%3A00.000%2B02%3A00 10.0
2007-09-29T12%3A00%3A00.000%2B02%3A00 10.0
2007-09-30T00%3A00%3A00.000%2B02%3A00 10.0
2007-09-30T12%3A00%3A00.000%2B02%3A00 10.0
2007-10-01T00%3A00%3A00.000%2B02%3A00 10.0
2007-10-01T12%3A00%3A00.000%2B02%3A00 10.0
2007-10-02T00%3A00%3A00.000%2B02%3A00 10.0
2007-10-02T12%3A00%3A00.000%2B02%3A00 10.0
2007-10-03T00%3A00%3A00.000%2B02%3A00 10.0
2007-10-03T12%3A00%3A00.000%2B02%3A00 10.0
]]></om:result>
     <ns8:dataSourceURI/>
    </ns8:ObservationWithSource>
   </op1d2d:observation>
   <op1d2d:bcType>LINE1D2D</op1d2d:bcType>
   <op1d2d:parentModelElement>ContinuityLine2D11913553087503829</op1d2d:parentModelElement>
   <op1d2d:parentCalculationUnit>CalculationUnit2D11914828330154813</op1d2d:parentCalculationUnit>
   <op1d2d:parentCalculationUnit>CalculationUnit1D2D11915776313123651</op1d2d:parentCalculationUnit>
   <op1d2d:stationaryCondition>10.0</op1d2d:stationaryCondition>
  </op1d2d:BoundaryCondition>
 </simBase:flowRelationshipMember>
 <simBase:flowRelationshipMember>
  <op1d2d:BoundaryCondition gml:id="BoundaryCondition1191482790562340">
   <gml:description>Manuell erzeugt am: 04.10.2007 9:26</gml:description>
   <gml:name>Abfluss - Zeitreihe</gml:name>
   <simBase:position>
    <gml:Point xmlns:ns1="http://www.w3.org/2001/SMIL20/" xmlns:st="http://www.seegrid.csiro.au/xml/st" xmlns:ns2="http://www.isotc211.org/2005/gmd" xmlns:ns3="http://www.isotc211.org/2005/gco" xmlns:ns4="http://www.isotc211.org/2005/gts" xmlns:ns5="http://www.isotc211.org/2005/gss" xmlns:ns6="http://www.isotc211.org/2005/gsr" xmlns:ns7="http://www.w3.org/2001/SMIL20/Language" srsName="EPSG:31467">
     <gml:coordinates ts="," decimal="." cs=" ">3553931.5793737723 5988987.747052198 0.0</gml:coordinates>
    </gml:Point>
   </simBase:position>
   <op1d2d:direction>170</op1d2d:direction>
   <op1d2d:observation>
    <ns8:ObservationWithSource gml:id="ObservationWithSource1191482790562286">
     <gml:name>Abfluss - Zeitreihe</gml:name>
     <om:observedProperty xlink:href="urn:ogc:gml:dict:kalypso:model:1d2d:timeserie:phenomenons#TimeserieBorderCondition1D"/>
     <om:resultDefinition>
      <sweExt:SortedRecordDefinition gml:id="SortedRecordDefinition1191482790578222">
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:1d2d:timeserie:components#Time"/>
       <swe:component xlink:href="urn:ogc:gml:dict:kalypso:model:1d2d:timeserie:components#Discharge"/>
       <sweExt:sortedComponent xlink:href="urn:ogc:gml:dict:kalypso:model:1d2d:timeserie:components#Time"/>
      </sweExt:SortedRecordDefinition>
     </om:resultDefinition>
     <om:result><![CDATA[2007-09-23T00%3A00%3A00.000%2B02%3A00 1
2007-09-23T12%3A00%3A00.000%2B02%3A00 2
2007-09-24T00%3A00%3A00.000%2B02%3A00 3
2007-09-24T12%3A00%3A00.000%2B02%3A00 4
2007-09-25T00%3A00%3A00.000%2B02%3A00 5
2007-09-25T12%3A00%3A00.000%2B02%3A00 7
2007-09-26T00%3A00%3A00.000%2B02%3A00 9
2007-09-26T12%3A00%3A00.000%2B02%3A00 10.0
2007-09-27T00%3A00%3A00.000%2B02%3A00 10.0
2007-09-27T12%3A00%3A00.000%2B02%3A00 10.0
2007-09-28T00%3A00%3A00.000%2B02%3A00 10.0
2007-09-28T12%3A00%3A00.000%2B02%3A00 10.0
2007-09-29T00%3A00%3A00.000%2B02%3A00 10.0
2007-09-29T12%3A00%3A00.000%2B02%3A00 10.0
2007-09-30T00%3A00%3A00.000%2B02%3A00 10.0
2007-09-30T12%3A00%3A00.000%2B02%3A00 10.0
2007-10-01T00%3A00%3A00.000%2B02%3A00 10.0
2007-10-01T12%3A00%3A00.000%2B02%3A00 10.0
2007-10-02T00%3A00%3A00.000%2B02%3A00 10.0
2007-10-02T12%3A00%3A00.000%2B02%3A00 10.0
2007-10-03T00%3A00%3A00.000%2B02%3A00 10.0
2007-10-03T12%3A00%3A00.000%2B02%3A00 10.0
]]></om:result>
     <ns8:dataSourceURI/>
    </ns8:ObservationWithSource>
   </op1d2d:observation>
   <op1d2d:bcType>LINE1D2D</op1d2d:bcType>
   <op1d2d:parentModelElement>ContinuityLine2D119135529204624542</op1d2d:parentModelElement>
   <op1d2d:parentCalculationUnit>CalculationUnit2D11914828330154813</op1d2d:parentCalculationUnit>
   <op1d2d:parentCalculationUnit>CalculationUnit1D2D11915776313123651</op1d2d:parentCalculationUnit>
   <op1d2d:stationaryCondition>10.0</op1d2d:stationaryCondition>
  </op1d2d:BoundaryCondition>
 </simBase:flowRelationshipMember>
</simBase:FlowRelationshipModel>
