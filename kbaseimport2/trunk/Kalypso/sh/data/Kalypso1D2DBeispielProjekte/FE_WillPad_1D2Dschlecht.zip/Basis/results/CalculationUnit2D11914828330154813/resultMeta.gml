<?xml version="1.0" encoding="UTF-8"?>
<resultMeta1d2d:CalculationUnitResultMeta xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:gml="http://www.opengis.net/gml" xmlns:xs="http://www.w3.org/2001/XMLSchema-instance" xmlns:resultMeta1d2d="http://www.tu-harburg.de/wb/kalypso/schemata/1d2dResultMeta" xmlns:commonShp="org.kalypso.gml.common" gml:id="root">
 <gml:description></gml:description>
 <gml:name>WillBuenz_OW</gml:name>
 <resultMeta:path xmlns:resultMeta="http://www.tu-harburg.de/wb/kalypso/schemata/simulationbase/result/meta">CalculationUnit2D11914828330154813</resultMeta:path>
 <resultMeta:childMember xmlns:resultMeta="http://www.tu-harburg.de/wb/kalypso/schemata/simulationbase/result/meta">
  <resultMeta1d2d:StepResultMeta gml:id="StepResultMeta11924702848570">
   <gml:description>stationärer Rechenlauf</gml:description>
   <gml:name>stationär</gml:name>
   <resultMeta:path>steady</resultMeta:path>
   <resultMeta:childMember>
    <resultMeta1d2d:DocumentResultMeta gml:id="DocumentResultMeta11924702872310">
     <gml:description>ASCII Ergebnisdatei(en) des RMA10 Rechenkerns</gml:description>
     <gml:name>RMA-Rohdaten</gml:name>
     <resultMeta:path>original.2d.zip</resultMeta:path>
     <resultMeta1d2d:type>coreDataZip</resultMeta1d2d:type>
    </resultMeta1d2d:DocumentResultMeta>
   </resultMeta:childMember>
   <resultMeta:childMember>
    <resultMeta1d2d:DocumentResultMeta gml:id="DocumentResultMeta11924703166441">
     <gml:description>TIN der Fließtiefen</gml:description>
     <gml:name>Fließtiefen</gml:name>
     <resultMeta:path>Tin/tin_DEPTH.gml</resultMeta:path>
     <resultMeta1d2d:type>tinDepth</resultMeta1d2d:type>
     <resultMeta1d2d:minValue>0.000</resultMeta1d2d:minValue>
     <resultMeta1d2d:maxValue>5.339</resultMeta1d2d:maxValue>
    </resultMeta1d2d:DocumentResultMeta>
   </resultMeta:childMember>
   <resultMeta:childMember>
    <resultMeta1d2d:DocumentResultMeta gml:id="DocumentResultMeta11924703166443">
     <gml:description>TIN der Wasserspiegellagen</gml:description>
     <gml:name>Wasserspiegellagen</gml:name>
     <resultMeta:path>Tin/tin_WATERLEVEL.gml</resultMeta:path>
     <resultMeta1d2d:type>tinWsp</resultMeta1d2d:type>
     <resultMeta1d2d:minValue>0.000</resultMeta1d2d:minValue>
     <resultMeta1d2d:maxValue>8.044</resultMeta1d2d:maxValue>
    </resultMeta1d2d:DocumentResultMeta>
   </resultMeta:childMember>
   <resultMeta:childMember>
    <resultMeta1d2d:DocumentResultMeta gml:id="DocumentResultMeta11924703166442">
     <gml:description>TIN der tiefengemittelten Fließgeschwindigkeiten</gml:description>
     <gml:name>Geschwindigkeiten</gml:name>
     <resultMeta:path>Tin/tin_VELOCITY.gml</resultMeta:path>
     <resultMeta1d2d:type>tinVelo</resultMeta1d2d:type>
     <resultMeta1d2d:minValue>0.000</resultMeta1d2d:minValue>
     <resultMeta1d2d:maxValue>0.253</resultMeta1d2d:maxValue>
    </resultMeta1d2d:DocumentResultMeta>
   </resultMeta:childMember>
   <resultMeta:childMember>
    <resultMeta1d2d:DocumentResultMeta gml:id="DocumentResultMeta11924703166447">
     <gml:description>Ergebnisse an den Knoten</gml:description>
     <gml:name>Vektoren</gml:name>
     <resultMeta:path>results.gml</resultMeta:path>
     <resultMeta1d2d:type>nodes</resultMeta1d2d:type>
     <resultMeta1d2d:minValue>0.000</resultMeta1d2d:minValue>
     <resultMeta1d2d:maxValue>0.253</resultMeta1d2d:maxValue>
    </resultMeta1d2d:DocumentResultMeta>
   </resultMeta:childMember>
   <resultMeta1d2d:stepTime>2007-09-23T02:00:00.000+02:00</resultMeta1d2d:stepTime>
   <resultMeta1d2d:stepNumber>-1</resultMeta1d2d:stepNumber>
   <resultMeta1d2d:isRestart/>
   <resultMeta1d2d:type>steady</resultMeta1d2d:type>
  </resultMeta1d2d:StepResultMeta>
 </resultMeta:childMember>
 <resultMeta:childMember xmlns:resultMeta="http://www.tu-harburg.de/wb/kalypso/schemata/simulationbase/result/meta">
  <resultMeta1d2d:DocumentResultMeta gml:id="DocumentResultMeta11924703166445">
   <gml:description>TIN der Modellhöhen</gml:description>
   <gml:name>Modellhöhen</gml:name>
   <resultMeta:path>model/Tin/tin_TERRAIN.gml</resultMeta:path>
   <resultMeta1d2d:type>tinTerrain</resultMeta1d2d:type>
   <resultMeta1d2d:minValue>0.000</resultMeta1d2d:minValue>
   <resultMeta1d2d:maxValue>8.396</resultMeta1d2d:maxValue>
  </resultMeta1d2d:DocumentResultMeta>
 </resultMeta:childMember>
 <resultMeta:childMember xmlns:resultMeta="http://www.tu-harburg.de/wb/kalypso/schemata/simulationbase/result/meta">
  <resultMeta1d2d:StepResultMeta gml:id="StepResultMeta11924703245325">
   <gml:description>instationärer Rechenlauf zum Zeitpunkt: 23.09.2007 14:00:00</gml:description>
   <gml:name>Zeitschritt 1 (23.09.2007 14:00:00)</gml:name>
   <resultMeta:path>timestep-0001</resultMeta:path>
   <resultMeta:childMember>
    <resultMeta1d2d:DocumentResultMeta gml:id="DocumentResultMeta11924703278592">
     <gml:description>ASCII Ergebnisdatei(en) des RMA10 Rechenkerns</gml:description>
     <gml:name>RMA-Rohdaten</gml:name>
     <resultMeta:path>original.2d.zip</resultMeta:path>
     <resultMeta1d2d:type>coreDataZip</resultMeta1d2d:type>
    </resultMeta1d2d:DocumentResultMeta>
   </resultMeta:childMember>
   <resultMeta:childMember>
    <resultMeta1d2d:DocumentResultMeta gml:id="DocumentResultMeta11924703528821">
     <gml:description>TIN der Fließtiefen</gml:description>
     <gml:name>Fließtiefen</gml:name>
     <resultMeta:path>Tin/tin_DEPTH.gml</resultMeta:path>
     <resultMeta1d2d:type>tinDepth</resultMeta1d2d:type>
     <resultMeta1d2d:minValue>0.000</resultMeta1d2d:minValue>
     <resultMeta1d2d:maxValue>5.182</resultMeta1d2d:maxValue>
    </resultMeta1d2d:DocumentResultMeta>
   </resultMeta:childMember>
   <resultMeta:childMember>
    <resultMeta1d2d:DocumentResultMeta gml:id="DocumentResultMeta11924703528824">
     <gml:description>TIN der Wasserspiegellagen</gml:description>
     <gml:name>Wasserspiegellagen</gml:name>
     <resultMeta:path>Tin/tin_WATERLEVEL.gml</resultMeta:path>
     <resultMeta1d2d:type>tinWsp</resultMeta1d2d:type>
     <resultMeta1d2d:minValue>0.000</resultMeta1d2d:minValue>
     <resultMeta1d2d:maxValue>7.846</resultMeta1d2d:maxValue>
    </resultMeta1d2d:DocumentResultMeta>
   </resultMeta:childMember>
   <resultMeta:childMember>
    <resultMeta1d2d:DocumentResultMeta gml:id="DocumentResultMeta11924703528825">
     <gml:description>TIN der tiefengemittelten Fließgeschwindigkeiten</gml:description>
     <gml:name>Geschwindigkeiten</gml:name>
     <resultMeta:path>Tin/tin_VELOCITY.gml</resultMeta:path>
     <resultMeta1d2d:type>tinVelo</resultMeta1d2d:type>
     <resultMeta1d2d:minValue>0.000</resultMeta1d2d:minValue>
     <resultMeta1d2d:maxValue>0.476</resultMeta1d2d:maxValue>
    </resultMeta1d2d:DocumentResultMeta>
   </resultMeta:childMember>
   <resultMeta:childMember>
    <resultMeta1d2d:DocumentResultMeta gml:id="DocumentResultMeta11924703528829">
     <gml:description>Ergebnisse an den Knoten</gml:description>
     <gml:name>Vektoren</gml:name>
     <resultMeta:path>results.gml</resultMeta:path>
     <resultMeta1d2d:type>nodes</resultMeta1d2d:type>
     <resultMeta1d2d:minValue>0.000</resultMeta1d2d:minValue>
     <resultMeta1d2d:maxValue>0.476</resultMeta1d2d:maxValue>
    </resultMeta1d2d:DocumentResultMeta>
   </resultMeta:childMember>
   <resultMeta1d2d:stepTime>2007-09-23T14:00:00.000+02:00</resultMeta1d2d:stepTime>
   <resultMeta1d2d:stepNumber>1</resultMeta1d2d:stepNumber>
   <resultMeta1d2d:isRestart/>
   <resultMeta1d2d:type>unsteady</resultMeta1d2d:type>
  </resultMeta1d2d:StepResultMeta>
 </resultMeta:childMember>
 <resultMeta:childMember xmlns:resultMeta="http://www.tu-harburg.de/wb/kalypso/schemata/simulationbase/result/meta">
  <resultMeta1d2d:StepResultMeta gml:id="StepResultMeta11924703630190">
   <gml:description>instationärer Rechenlauf zum Zeitpunkt: 24.09.2007 02:00:00</gml:description>
   <gml:name>Zeitschritt 2 (24.09.2007 02:00:00)</gml:name>
   <resultMeta:path>timestep-0002</resultMeta:path>
   <resultMeta:childMember>
    <resultMeta1d2d:DocumentResultMeta gml:id="DocumentResultMeta11924703669247">
     <gml:description>ASCII Ergebnisdatei(en) des RMA10 Rechenkerns</gml:description>
     <gml:name>RMA-Rohdaten</gml:name>
     <resultMeta:path>original.2d.zip</resultMeta:path>
     <resultMeta1d2d:type>coreDataZip</resultMeta1d2d:type>
    </resultMeta1d2d:DocumentResultMeta>
   </resultMeta:childMember>
   <resultMeta:childMember>
    <resultMeta1d2d:DocumentResultMeta gml:id="DocumentResultMeta119247039052610">
     <gml:description>TIN der Fließtiefen</gml:description>
     <gml:name>Fließtiefen</gml:name>
     <resultMeta:path>Tin/tin_DEPTH.gml</resultMeta:path>
     <resultMeta1d2d:type>tinDepth</resultMeta1d2d:type>
     <resultMeta1d2d:minValue>0.000</resultMeta1d2d:minValue>
     <resultMeta1d2d:maxValue>4.979</resultMeta1d2d:maxValue>
    </resultMeta1d2d:DocumentResultMeta>
   </resultMeta:childMember>
   <resultMeta:childMember>
    <resultMeta1d2d:DocumentResultMeta gml:id="DocumentResultMeta11924703905261">
     <gml:description>TIN der Wasserspiegellagen</gml:description>
     <gml:name>Wasserspiegellagen</gml:name>
     <resultMeta:path>Tin/tin_WATERLEVEL.gml</resultMeta:path>
     <resultMeta1d2d:type>tinWsp</resultMeta1d2d:type>
     <resultMeta1d2d:minValue>0.000</resultMeta1d2d:minValue>
     <resultMeta1d2d:maxValue>7.648</resultMeta1d2d:maxValue>
    </resultMeta1d2d:DocumentResultMeta>
   </resultMeta:childMember>
   <resultMeta:childMember>
    <resultMeta1d2d:DocumentResultMeta gml:id="DocumentResultMeta11924703905260">
     <gml:description>TIN der tiefengemittelten Fließgeschwindigkeiten</gml:description>
     <gml:name>Geschwindigkeiten</gml:name>
     <resultMeta:path>Tin/tin_VELOCITY.gml</resultMeta:path>
     <resultMeta1d2d:type>tinVelo</resultMeta1d2d:type>
     <resultMeta1d2d:minValue>0.000</resultMeta1d2d:minValue>
     <resultMeta1d2d:maxValue>0.464</resultMeta1d2d:maxValue>
    </resultMeta1d2d:DocumentResultMeta>
   </resultMeta:childMember>
   <resultMeta:childMember>
    <resultMeta1d2d:DocumentResultMeta gml:id="DocumentResultMeta119247039052618">
     <gml:description>Ergebnisse an den Knoten</gml:description>
     <gml:name>Vektoren</gml:name>
     <resultMeta:path>results.gml</resultMeta:path>
     <resultMeta1d2d:type>nodes</resultMeta1d2d:type>
     <resultMeta1d2d:minValue>0.000</resultMeta1d2d:minValue>
     <resultMeta1d2d:maxValue>0.464</resultMeta1d2d:maxValue>
    </resultMeta1d2d:DocumentResultMeta>
   </resultMeta:childMember>
   <resultMeta1d2d:stepTime>2007-09-24T02:00:00.000+02:00</resultMeta1d2d:stepTime>
   <resultMeta1d2d:stepNumber>2</resultMeta1d2d:stepNumber>
   <resultMeta1d2d:isRestart/>
   <resultMeta1d2d:type>unsteady</resultMeta1d2d:type>
  </resultMeta1d2d:StepResultMeta>
 </resultMeta:childMember>
 <resultMeta:childMember xmlns:resultMeta="http://www.tu-harburg.de/wb/kalypso/schemata/simulationbase/result/meta">
  <resultMeta1d2d:StepResultMeta gml:id="StepResultMeta11924703981806">
   <gml:description>instationärer Rechenlauf zum Zeitpunkt: 24.09.2007 14:00:00</gml:description>
   <gml:name>Zeitschritt 3 (24.09.2007 14:00:00)</gml:name>
   <resultMeta:path>timestep-0003</resultMeta:path>
   <resultMeta:childMember>
    <resultMeta1d2d:DocumentResultMeta gml:id="DocumentResultMeta119247040310019">
     <gml:description>ASCII Ergebnisdatei(en) des RMA10 Rechenkerns</gml:description>
     <gml:name>RMA-Rohdaten</gml:name>
     <resultMeta:path>original.2d.zip</resultMeta:path>
     <resultMeta1d2d:type>coreDataZip</resultMeta1d2d:type>
    </resultMeta1d2d:DocumentResultMeta>
   </resultMeta:childMember>
   <resultMeta:childMember>
    <resultMeta1d2d:DocumentResultMeta gml:id="DocumentResultMeta11924704282019">
     <gml:description>TIN der Fließtiefen</gml:description>
     <gml:name>Fließtiefen</gml:name>
     <resultMeta:path>Tin/tin_DEPTH.gml</resultMeta:path>
     <resultMeta1d2d:type>tinDepth</resultMeta1d2d:type>
     <resultMeta1d2d:minValue>0.000</resultMeta1d2d:minValue>
     <resultMeta1d2d:maxValue>4.777</resultMeta1d2d:maxValue>
    </resultMeta1d2d:DocumentResultMeta>
   </resultMeta:childMember>
   <resultMeta:childMember>
    <resultMeta1d2d:DocumentResultMeta gml:id="DocumentResultMeta119247042820113">
     <gml:description>TIN der Wasserspiegellagen</gml:description>
     <gml:name>Wasserspiegellagen</gml:name>
     <resultMeta:path>Tin/tin_WATERLEVEL.gml</resultMeta:path>
     <resultMeta1d2d:type>tinWsp</resultMeta1d2d:type>
     <resultMeta1d2d:minValue>0.000</resultMeta1d2d:minValue>
     <resultMeta1d2d:maxValue>7.450</resultMeta1d2d:maxValue>
    </resultMeta1d2d:DocumentResultMeta>
   </resultMeta:childMember>
   <resultMeta:childMember>
    <resultMeta1d2d:DocumentResultMeta gml:id="DocumentResultMeta119247042820115">
     <gml:description>TIN der tiefengemittelten Fließgeschwindigkeiten</gml:description>
     <gml:name>Geschwindigkeiten</gml:name>
     <resultMeta:path>Tin/tin_VELOCITY.gml</resultMeta:path>
     <resultMeta1d2d:type>tinVelo</resultMeta1d2d:type>
     <resultMeta1d2d:minValue>0.000</resultMeta1d2d:minValue>
     <resultMeta1d2d:maxValue>0.524</resultMeta1d2d:maxValue>
    </resultMeta1d2d:DocumentResultMeta>
   </resultMeta:childMember>
   <resultMeta:childMember>
    <resultMeta1d2d:DocumentResultMeta gml:id="DocumentResultMeta11924704282017">
     <gml:description>Ergebnisse an den Knoten</gml:description>
     <gml:name>Vektoren</gml:name>
     <resultMeta:path>results.gml</resultMeta:path>
     <resultMeta1d2d:type>nodes</resultMeta1d2d:type>
     <resultMeta1d2d:minValue>0.000</resultMeta1d2d:minValue>
     <resultMeta1d2d:maxValue>0.524</resultMeta1d2d:maxValue>
    </resultMeta1d2d:DocumentResultMeta>
   </resultMeta:childMember>
   <resultMeta1d2d:stepTime>2007-09-24T14:00:00.000+02:00</resultMeta1d2d:stepTime>
   <resultMeta1d2d:stepNumber>3</resultMeta1d2d:stepNumber>
   <resultMeta1d2d:isRestart/>
   <resultMeta1d2d:type>unsteady</resultMeta1d2d:type>
  </resultMeta1d2d:StepResultMeta>
 </resultMeta:childMember>
 <resultMeta:childMember xmlns:resultMeta="http://www.tu-harburg.de/wb/kalypso/schemata/simulationbase/result/meta">
  <resultMeta1d2d:StepResultMeta gml:id="StepResultMeta11924704347775">
   <gml:description>instationärer Rechenlauf zum Zeitpunkt: 25.09.2007 02:00:00</gml:description>
   <gml:name>Zeitschritt 4 (25.09.2007 02:00:00)</gml:name>
   <resultMeta:path>timestep-0004</resultMeta:path>
   <resultMeta:childMember>
    <resultMeta1d2d:DocumentResultMeta gml:id="DocumentResultMeta119247044016613">
     <gml:description>ASCII Ergebnisdatei(en) des RMA10 Rechenkerns</gml:description>
     <gml:name>RMA-Rohdaten</gml:name>
     <resultMeta:path>original.2d.zip</resultMeta:path>
     <resultMeta1d2d:type>coreDataZip</resultMeta1d2d:type>
    </resultMeta1d2d:DocumentResultMeta>
   </resultMeta:childMember>
   <resultMeta:childMember>
    <resultMeta1d2d:DocumentResultMeta gml:id="DocumentResultMeta11924704636436">
     <gml:description>TIN der Fließtiefen</gml:description>
     <gml:name>Fließtiefen</gml:name>
     <resultMeta:path>Tin/tin_DEPTH.gml</resultMeta:path>
     <resultMeta1d2d:type>tinDepth</resultMeta1d2d:type>
     <resultMeta1d2d:minValue>0.000</resultMeta1d2d:minValue>
     <resultMeta1d2d:maxValue>4.574</resultMeta1d2d:maxValue>
    </resultMeta1d2d:DocumentResultMeta>
   </resultMeta:childMember>
   <resultMeta:childMember>
    <resultMeta1d2d:DocumentResultMeta gml:id="DocumentResultMeta11924704636432">
     <gml:description>TIN der Wasserspiegellagen</gml:description>
     <gml:name>Wasserspiegellagen</gml:name>
     <resultMeta:path>Tin/tin_WATERLEVEL.gml</resultMeta:path>
     <resultMeta1d2d:type>tinWsp</resultMeta1d2d:type>
     <resultMeta1d2d:minValue>0.000</resultMeta1d2d:minValue>
     <resultMeta1d2d:maxValue>7.252</resultMeta1d2d:maxValue>
    </resultMeta1d2d:DocumentResultMeta>
   </resultMeta:childMember>
   <resultMeta:childMember>
    <resultMeta1d2d:DocumentResultMeta gml:id="DocumentResultMeta119247046364327">
     <gml:description>TIN der tiefengemittelten Fließgeschwindigkeiten</gml:description>
     <gml:name>Geschwindigkeiten</gml:name>
     <resultMeta:path>Tin/tin_VELOCITY.gml</resultMeta:path>
     <resultMeta1d2d:type>tinVelo</resultMeta1d2d:type>
     <resultMeta1d2d:minValue>0.000</resultMeta1d2d:minValue>
     <resultMeta1d2d:maxValue>0.385</resultMeta1d2d:maxValue>
    </resultMeta1d2d:DocumentResultMeta>
   </resultMeta:childMember>
   <resultMeta:childMember>
    <resultMeta1d2d:DocumentResultMeta gml:id="DocumentResultMeta119247046364328">
     <gml:description>Ergebnisse an den Knoten</gml:description>
     <gml:name>Vektoren</gml:name>
     <resultMeta:path>results.gml</resultMeta:path>
     <resultMeta1d2d:type>nodes</resultMeta1d2d:type>
     <resultMeta1d2d:minValue>0.000</resultMeta1d2d:minValue>
     <resultMeta1d2d:maxValue>0.385</resultMeta1d2d:maxValue>
    </resultMeta1d2d:DocumentResultMeta>
   </resultMeta:childMember>
   <resultMeta1d2d:stepTime>2007-09-25T02:00:00.000+02:00</resultMeta1d2d:stepTime>
   <resultMeta1d2d:stepNumber>4</resultMeta1d2d:stepNumber>
   <resultMeta1d2d:isRestart/>
   <resultMeta1d2d:type>unsteady</resultMeta1d2d:type>
  </resultMeta1d2d:StepResultMeta>
 </resultMeta:childMember>
 <resultMeta:childMember xmlns:resultMeta="http://www.tu-harburg.de/wb/kalypso/schemata/simulationbase/result/meta">
  <resultMeta1d2d:StepResultMeta gml:id="StepResultMeta11924704659869">
   <gml:description>instationärer Rechenlauf zum Zeitpunkt: 25.09.2007 14:00:00</gml:description>
   <gml:name>Zeitschritt 5 (25.09.2007 14:00:00)</gml:name>
   <resultMeta:path>timestep-0005</resultMeta:path>
   <resultMeta:childMember>
    <resultMeta1d2d:DocumentResultMeta gml:id="DocumentResultMeta11924704722341">
     <gml:description>ASCII Ergebnisdatei(en) des RMA10 Rechenkerns</gml:description>
     <gml:name>RMA-Rohdaten</gml:name>
     <resultMeta:path>original.2d.zip</resultMeta:path>
     <resultMeta1d2d:type>coreDataZip</resultMeta1d2d:type>
    </resultMeta1d2d:DocumentResultMeta>
   </resultMeta:childMember>
   <resultMeta:childMember>
    <resultMeta1d2d:DocumentResultMeta gml:id="DocumentResultMeta11924704958046">
     <gml:description>TIN der Fließtiefen</gml:description>
     <gml:name>Fließtiefen</gml:name>
     <resultMeta:path>Tin/tin_DEPTH.gml</resultMeta:path>
     <resultMeta1d2d:type>tinDepth</resultMeta1d2d:type>
     <resultMeta1d2d:minValue>0.000</resultMeta1d2d:minValue>
     <resultMeta1d2d:maxValue>4.374</resultMeta1d2d:maxValue>
    </resultMeta1d2d:DocumentResultMeta>
   </resultMeta:childMember>
   <resultMeta:childMember>
    <resultMeta1d2d:DocumentResultMeta gml:id="DocumentResultMeta11924704958041">
     <gml:description>TIN der Wasserspiegellagen</gml:description>
     <gml:name>Wasserspiegellagen</gml:name>
     <resultMeta:path>Tin/tin_WATERLEVEL.gml</resultMeta:path>
     <resultMeta1d2d:type>tinWsp</resultMeta1d2d:type>
     <resultMeta1d2d:minValue>0.000</resultMeta1d2d:minValue>
     <resultMeta1d2d:maxValue>7.058</resultMeta1d2d:maxValue>
    </resultMeta1d2d:DocumentResultMeta>
   </resultMeta:childMember>
   <resultMeta:childMember>
    <resultMeta1d2d:DocumentResultMeta gml:id="DocumentResultMeta119247049580414">
     <gml:description>TIN der tiefengemittelten Fließgeschwindigkeiten</gml:description>
     <gml:name>Geschwindigkeiten</gml:name>
     <resultMeta:path>Tin/tin_VELOCITY.gml</resultMeta:path>
     <resultMeta1d2d:type>tinVelo</resultMeta1d2d:type>
     <resultMeta1d2d:minValue>0.000</resultMeta1d2d:minValue>
     <resultMeta1d2d:maxValue>0.811</resultMeta1d2d:maxValue>
    </resultMeta1d2d:DocumentResultMeta>
   </resultMeta:childMember>
   <resultMeta:childMember>
    <resultMeta1d2d:DocumentResultMeta gml:id="DocumentResultMeta11924704958044">
     <gml:description>Ergebnisse an den Knoten</gml:description>
     <gml:name>Vektoren</gml:name>
     <resultMeta:path>results.gml</resultMeta:path>
     <resultMeta1d2d:type>nodes</resultMeta1d2d:type>
     <resultMeta1d2d:minValue>0.000</resultMeta1d2d:minValue>
     <resultMeta1d2d:maxValue>0.811</resultMeta1d2d:maxValue>
    </resultMeta1d2d:DocumentResultMeta>
   </resultMeta:childMember>
   <resultMeta1d2d:stepTime>2007-09-25T14:00:00.000+02:00</resultMeta1d2d:stepTime>
   <resultMeta1d2d:stepNumber>5</resultMeta1d2d:stepNumber>
   <resultMeta1d2d:isRestart/>
   <resultMeta1d2d:type>unsteady</resultMeta1d2d:type>
  </resultMeta1d2d:StepResultMeta>
 </resultMeta:childMember>
 <resultMeta:childMember xmlns:resultMeta="http://www.tu-harburg.de/wb/kalypso/schemata/simulationbase/result/meta">
  <resultMeta1d2d:StepResultMeta gml:id="StepResultMeta119247049710026">
   <gml:description>instationärer Rechenlauf zum Zeitpunkt: 26.09.2007 02:00:00</gml:description>
   <gml:name>Zeitschritt 6 (26.09.2007 02:00:00)</gml:name>
   <resultMeta:path>timestep-0006</resultMeta:path>
   <resultMeta:childMember>
    <resultMeta1d2d:DocumentResultMeta gml:id="DocumentResultMeta119247050378633">
     <gml:description>ASCII Ergebnisdatei(en) des RMA10 Rechenkerns</gml:description>
     <gml:name>RMA-Rohdaten</gml:name>
     <resultMeta:path>original.2d.zip</resultMeta:path>
     <resultMeta1d2d:type>coreDataZip</resultMeta1d2d:type>
    </resultMeta1d2d:DocumentResultMeta>
   </resultMeta:childMember>
   <resultMeta:childMember>
    <resultMeta1d2d:DocumentResultMeta gml:id="DocumentResultMeta11924705280909">
     <gml:description>TIN der Fließtiefen</gml:description>
     <gml:name>Fließtiefen</gml:name>
     <resultMeta:path>Tin/tin_DEPTH.gml</resultMeta:path>
     <resultMeta1d2d:type>tinDepth</resultMeta1d2d:type>
     <resultMeta1d2d:minValue>0.000</resultMeta1d2d:minValue>
     <resultMeta1d2d:maxValue>4.173</resultMeta1d2d:maxValue>
    </resultMeta1d2d:DocumentResultMeta>
   </resultMeta:childMember>
   <resultMeta:childMember>
    <resultMeta1d2d:DocumentResultMeta gml:id="DocumentResultMeta11924705280905">
     <gml:description>TIN der Wasserspiegellagen</gml:description>
     <gml:name>Wasserspiegellagen</gml:name>
     <resultMeta:path>Tin/tin_WATERLEVEL.gml</resultMeta:path>
     <resultMeta1d2d:type>tinWsp</resultMeta1d2d:type>
     <resultMeta1d2d:minValue>0.000</resultMeta1d2d:minValue>
     <resultMeta1d2d:maxValue>6.868</resultMeta1d2d:maxValue>
    </resultMeta1d2d:DocumentResultMeta>
   </resultMeta:childMember>
   <resultMeta:childMember>
    <resultMeta1d2d:DocumentResultMeta gml:id="DocumentResultMeta119247052809037">
     <gml:description>TIN der tiefengemittelten Fließgeschwindigkeiten</gml:description>
     <gml:name>Geschwindigkeiten</gml:name>
     <resultMeta:path>Tin/tin_VELOCITY.gml</resultMeta:path>
     <resultMeta1d2d:type>tinVelo</resultMeta1d2d:type>
     <resultMeta1d2d:minValue>0.000</resultMeta1d2d:minValue>
     <resultMeta1d2d:maxValue>1.470</resultMeta1d2d:maxValue>
    </resultMeta1d2d:DocumentResultMeta>
   </resultMeta:childMember>
   <resultMeta:childMember>
    <resultMeta1d2d:DocumentResultMeta gml:id="DocumentResultMeta119247052809026">
     <gml:description>Ergebnisse an den Knoten</gml:description>
     <gml:name>Vektoren</gml:name>
     <resultMeta:path>results.gml</resultMeta:path>
     <resultMeta1d2d:type>nodes</resultMeta1d2d:type>
     <resultMeta1d2d:minValue>0.000</resultMeta1d2d:minValue>
     <resultMeta1d2d:maxValue>1.470</resultMeta1d2d:maxValue>
    </resultMeta1d2d:DocumentResultMeta>
   </resultMeta:childMember>
   <resultMeta1d2d:stepTime>2007-09-26T02:00:00.000+02:00</resultMeta1d2d:stepTime>
   <resultMeta1d2d:stepNumber>6</resultMeta1d2d:stepNumber>
   <resultMeta1d2d:isRestart/>
   <resultMeta1d2d:type>unsteady</resultMeta1d2d:type>
  </resultMeta1d2d:StepResultMeta>
 </resultMeta:childMember>
 <resultMeta:childMember xmlns:resultMeta="http://www.tu-harburg.de/wb/kalypso/schemata/simulationbase/result/meta">
  <resultMeta1d2d:StepResultMeta gml:id="StepResultMeta119247052543519">
   <gml:description>instationärer Rechenlauf zum Zeitpunkt: 26.09.2007 14:00:00</gml:description>
   <gml:name>Zeitschritt 7 (26.09.2007 14:00:00)</gml:name>
   <resultMeta:path>timestep-0007</resultMeta:path>
   <resultMeta:childMember>
    <resultMeta1d2d:DocumentResultMeta gml:id="DocumentResultMeta119247053488527">
     <gml:description>ASCII Ergebnisdatei(en) des RMA10 Rechenkerns</gml:description>
     <gml:name>RMA-Rohdaten</gml:name>
     <resultMeta:path>original.2d.zip</resultMeta:path>
     <resultMeta1d2d:type>coreDataZip</resultMeta1d2d:type>
    </resultMeta1d2d:DocumentResultMeta>
   </resultMeta:childMember>
   <resultMeta:childMember>
    <resultMeta1d2d:DocumentResultMeta gml:id="DocumentResultMeta119247055787716">
     <gml:description>TIN der Fließtiefen</gml:description>
     <gml:name>Fließtiefen</gml:name>
     <resultMeta:path>Tin/tin_DEPTH.gml</resultMeta:path>
     <resultMeta1d2d:type>tinDepth</resultMeta1d2d:type>
     <resultMeta1d2d:minValue>0.000</resultMeta1d2d:minValue>
     <resultMeta1d2d:maxValue>3.973</resultMeta1d2d:maxValue>
    </resultMeta1d2d:DocumentResultMeta>
   </resultMeta:childMember>
   <resultMeta:childMember>
    <resultMeta1d2d:DocumentResultMeta gml:id="DocumentResultMeta119247055787732">
     <gml:description>TIN der Wasserspiegellagen</gml:description>
     <gml:name>Wasserspiegellagen</gml:name>
     <resultMeta:path>Tin/tin_WATERLEVEL.gml</resultMeta:path>
     <resultMeta1d2d:type>tinWsp</resultMeta1d2d:type>
     <resultMeta1d2d:minValue>0.000</resultMeta1d2d:minValue>
     <resultMeta1d2d:maxValue>6.686</resultMeta1d2d:maxValue>
    </resultMeta1d2d:DocumentResultMeta>
   </resultMeta:childMember>
   <resultMeta:childMember>
    <resultMeta1d2d:DocumentResultMeta gml:id="DocumentResultMeta11924705578772">
     <gml:description>TIN der tiefengemittelten Fließgeschwindigkeiten</gml:description>
     <gml:name>Geschwindigkeiten</gml:name>
     <resultMeta:path>Tin/tin_VELOCITY.gml</resultMeta:path>
     <resultMeta1d2d:type>tinVelo</resultMeta1d2d:type>
     <resultMeta1d2d:minValue>0.000</resultMeta1d2d:minValue>
     <resultMeta1d2d:maxValue>2.178</resultMeta1d2d:maxValue>
    </resultMeta1d2d:DocumentResultMeta>
   </resultMeta:childMember>
   <resultMeta:childMember>
    <resultMeta1d2d:DocumentResultMeta gml:id="DocumentResultMeta119247055787737">
     <gml:description>Ergebnisse an den Knoten</gml:description>
     <gml:name>Vektoren</gml:name>
     <resultMeta:path>results.gml</resultMeta:path>
     <resultMeta1d2d:type>nodes</resultMeta1d2d:type>
     <resultMeta1d2d:minValue>0.000</resultMeta1d2d:minValue>
     <resultMeta1d2d:maxValue>2.178</resultMeta1d2d:maxValue>
    </resultMeta1d2d:DocumentResultMeta>
   </resultMeta:childMember>
   <resultMeta1d2d:stepTime>2007-09-26T14:00:00.000+02:00</resultMeta1d2d:stepTime>
   <resultMeta1d2d:stepNumber>7</resultMeta1d2d:stepNumber>
   <resultMeta1d2d:isRestart/>
   <resultMeta1d2d:type>unsteady</resultMeta1d2d:type>
  </resultMeta1d2d:StepResultMeta>
 </resultMeta:childMember>
 <resultMeta:childMember xmlns:resultMeta="http://www.tu-harburg.de/wb/kalypso/schemata/simulationbase/result/meta">
  <resultMeta1d2d:StepResultMeta gml:id="StepResultMeta11924705530984">
   <gml:description>instationärer Rechenlauf zum Zeitpunkt: 27.09.2007 02:00:00</gml:description>
   <gml:name>Zeitschritt 8 (27.09.2007 02:00:00)</gml:name>
   <resultMeta:path>timestep-0008</resultMeta:path>
   <resultMeta:childMember>
    <resultMeta1d2d:DocumentResultMeta gml:id="DocumentResultMeta119247056535940">
     <gml:description>ASCII Ergebnisdatei(en) des RMA10 Rechenkerns</gml:description>
     <gml:name>RMA-Rohdaten</gml:name>
     <resultMeta:path>original.2d.zip</resultMeta:path>
     <resultMeta1d2d:type>coreDataZip</resultMeta1d2d:type>
    </resultMeta1d2d:DocumentResultMeta>
   </resultMeta:childMember>
   <resultMeta:childMember>
    <resultMeta1d2d:DocumentResultMeta gml:id="DocumentResultMeta119247058977324">
     <gml:description>TIN der Fließtiefen</gml:description>
     <gml:name>Fließtiefen</gml:name>
     <resultMeta:path>Tin/tin_DEPTH.gml</resultMeta:path>
     <resultMeta1d2d:type>tinDepth</resultMeta1d2d:type>
     <resultMeta1d2d:minValue>0.000</resultMeta1d2d:minValue>
     <resultMeta1d2d:maxValue>3.767</resultMeta1d2d:maxValue>
    </resultMeta1d2d:DocumentResultMeta>
   </resultMeta:childMember>
   <resultMeta:childMember>
    <resultMeta1d2d:DocumentResultMeta gml:id="DocumentResultMeta119247058977318">
     <gml:description>TIN der Wasserspiegellagen</gml:description>
     <gml:name>Wasserspiegellagen</gml:name>
     <resultMeta:path>Tin/tin_WATERLEVEL.gml</resultMeta:path>
     <resultMeta1d2d:type>tinWsp</resultMeta1d2d:type>
     <resultMeta1d2d:minValue>0.000</resultMeta1d2d:minValue>
     <resultMeta1d2d:maxValue>6.527</resultMeta1d2d:maxValue>
    </resultMeta1d2d:DocumentResultMeta>
   </resultMeta:childMember>
   <resultMeta:childMember>
    <resultMeta1d2d:DocumentResultMeta gml:id="DocumentResultMeta11924705897890">
     <gml:description>TIN der tiefengemittelten Fließgeschwindigkeiten</gml:description>
     <gml:name>Geschwindigkeiten</gml:name>
     <resultMeta:path>Tin/tin_VELOCITY.gml</resultMeta:path>
     <resultMeta1d2d:type>tinVelo</resultMeta1d2d:type>
     <resultMeta1d2d:minValue>0.000</resultMeta1d2d:minValue>
     <resultMeta1d2d:maxValue>0.460</resultMeta1d2d:maxValue>
    </resultMeta1d2d:DocumentResultMeta>
   </resultMeta:childMember>
   <resultMeta:childMember>
    <resultMeta1d2d:DocumentResultMeta gml:id="DocumentResultMeta119247058978948">
     <gml:description>Ergebnisse an den Knoten</gml:description>
     <gml:name>Vektoren</gml:name>
     <resultMeta:path>results.gml</resultMeta:path>
     <resultMeta1d2d:type>nodes</resultMeta1d2d:type>
     <resultMeta1d2d:minValue>0.000</resultMeta1d2d:minValue>
     <resultMeta1d2d:maxValue>0.460</resultMeta1d2d:maxValue>
    </resultMeta1d2d:DocumentResultMeta>
   </resultMeta:childMember>
   <resultMeta1d2d:stepTime>2007-09-27T02:00:00.000+02:00</resultMeta1d2d:stepTime>
   <resultMeta1d2d:stepNumber>8</resultMeta1d2d:stepNumber>
   <resultMeta1d2d:isRestart/>
   <resultMeta1d2d:type>unsteady</resultMeta1d2d:type>
  </resultMeta1d2d:StepResultMeta>
 </resultMeta:childMember>
 <resultMeta:childMember xmlns:resultMeta="http://www.tu-harburg.de/wb/kalypso/schemata/simulationbase/result/meta">
  <resultMeta1d2d:StepResultMeta gml:id="StepResultMeta11924705756375">
   <gml:description>instationärer Rechenlauf zum Zeitpunkt: 27.09.2007 14:00:00</gml:description>
   <gml:name>Zeitschritt 9 (27.09.2007 14:00:00)</gml:name>
   <resultMeta:path>timestep-0009</resultMeta:path>
   <resultMeta:childMember>
    <resultMeta1d2d:DocumentResultMeta gml:id="DocumentResultMeta119247059911440">
     <gml:description>ASCII Ergebnisdatei(en) des RMA10 Rechenkerns</gml:description>
     <gml:name>RMA-Rohdaten</gml:name>
     <resultMeta:path>original.2d.zip</resultMeta:path>
     <resultMeta1d2d:type>coreDataZip</resultMeta1d2d:type>
    </resultMeta1d2d:DocumentResultMeta>
   </resultMeta:childMember>
   <resultMeta:childMember>
    <resultMeta1d2d:DocumentResultMeta gml:id="DocumentResultMeta11924706217471">
     <gml:description>TIN der Fließtiefen</gml:description>
     <gml:name>Fließtiefen</gml:name>
     <resultMeta:path>Tin/tin_DEPTH.gml</resultMeta:path>
     <resultMeta1d2d:type>tinDepth</resultMeta1d2d:type>
     <resultMeta1d2d:minValue>0.000</resultMeta1d2d:minValue>
     <resultMeta1d2d:maxValue>3.566</resultMeta1d2d:maxValue>
    </resultMeta1d2d:DocumentResultMeta>
   </resultMeta:childMember>
   <resultMeta:childMember>
    <resultMeta1d2d:DocumentResultMeta gml:id="DocumentResultMeta119247062174713">
     <gml:description>TIN der Wasserspiegellagen</gml:description>
     <gml:name>Wasserspiegellagen</gml:name>
     <resultMeta:path>Tin/tin_WATERLEVEL.gml</resultMeta:path>
     <resultMeta1d2d:type>tinWsp</resultMeta1d2d:type>
     <resultMeta1d2d:minValue>0.000</resultMeta1d2d:minValue>
     <resultMeta1d2d:maxValue>6.450</resultMeta1d2d:maxValue>
    </resultMeta1d2d:DocumentResultMeta>
   </resultMeta:childMember>
   <resultMeta:childMember>
    <resultMeta1d2d:DocumentResultMeta gml:id="DocumentResultMeta11924706217470">
     <gml:description>TIN der tiefengemittelten Fließgeschwindigkeiten</gml:description>
     <gml:name>Geschwindigkeiten</gml:name>
     <resultMeta:path>Tin/tin_VELOCITY.gml</resultMeta:path>
     <resultMeta1d2d:type>tinVelo</resultMeta1d2d:type>
     <resultMeta1d2d:minValue>0.000</resultMeta1d2d:minValue>
     <resultMeta1d2d:maxValue>0.626</resultMeta1d2d:maxValue>
    </resultMeta1d2d:DocumentResultMeta>
   </resultMeta:childMember>
   <resultMeta:childMember>
    <resultMeta1d2d:DocumentResultMeta gml:id="DocumentResultMeta119247062174756">
     <gml:description>Ergebnisse an den Knoten</gml:description>
     <gml:name>Vektoren</gml:name>
     <resultMeta:path>results.gml</resultMeta:path>
     <resultMeta1d2d:type>nodes</resultMeta1d2d:type>
     <resultMeta1d2d:minValue>0.000</resultMeta1d2d:minValue>
     <resultMeta1d2d:maxValue>0.626</resultMeta1d2d:maxValue>
    </resultMeta1d2d:DocumentResultMeta>
   </resultMeta:childMember>
   <resultMeta1d2d:stepTime>2007-09-27T14:00:00.000+02:00</resultMeta1d2d:stepTime>
   <resultMeta1d2d:stepNumber>9</resultMeta1d2d:stepNumber>
   <resultMeta1d2d:isRestart/>
   <resultMeta1d2d:type>unsteady</resultMeta1d2d:type>
  </resultMeta1d2d:StepResultMeta>
 </resultMeta:childMember>
 <resultMeta:childMember xmlns:resultMeta="http://www.tu-harburg.de/wb/kalypso/schemata/simulationbase/result/meta">
  <resultMeta1d2d:StepResultMeta gml:id="StepResultMeta11924706078928">
   <gml:description>instationärer Rechenlauf zum Zeitpunkt: 28.09.2007 02:00:00</gml:description>
   <gml:name>Zeitschritt 10 (28.09.2007 02:00:00)</gml:name>
   <resultMeta:path>timestep-0010</resultMeta:path>
   <resultMeta:childMember>
    <resultMeta1d2d:DocumentResultMeta gml:id="DocumentResultMeta119247063360346">
     <gml:description>ASCII Ergebnisdatei(en) des RMA10 Rechenkerns</gml:description>
     <gml:name>RMA-Rohdaten</gml:name>
     <resultMeta:path>original.2d.zip</resultMeta:path>
     <resultMeta1d2d:type>coreDataZip</resultMeta1d2d:type>
    </resultMeta1d2d:DocumentResultMeta>
   </resultMeta:childMember>
   <resultMeta:childMember>
    <resultMeta1d2d:DocumentResultMeta gml:id="DocumentResultMeta11924706576110">
     <gml:description>TIN der Fließtiefen</gml:description>
     <gml:name>Fließtiefen</gml:name>
     <resultMeta:path>Tin/tin_DEPTH.gml</resultMeta:path>
     <resultMeta1d2d:type>tinDepth</resultMeta1d2d:type>
     <resultMeta1d2d:minValue>0.000</resultMeta1d2d:minValue>
     <resultMeta1d2d:maxValue>3.466</resultMeta1d2d:maxValue>
    </resultMeta1d2d:DocumentResultMeta>
   </resultMeta:childMember>
   <resultMeta:childMember>
    <resultMeta1d2d:DocumentResultMeta gml:id="DocumentResultMeta119247065761133">
     <gml:description>TIN der Wasserspiegellagen</gml:description>
     <gml:name>Wasserspiegellagen</gml:name>
     <resultMeta:path>Tin/tin_WATERLEVEL.gml</resultMeta:path>
     <resultMeta1d2d:type>tinWsp</resultMeta1d2d:type>
     <resultMeta1d2d:minValue>0.000</resultMeta1d2d:minValue>
     <resultMeta1d2d:maxValue>6.467</resultMeta1d2d:maxValue>
    </resultMeta1d2d:DocumentResultMeta>
   </resultMeta:childMember>
   <resultMeta:childMember>
    <resultMeta1d2d:DocumentResultMeta gml:id="DocumentResultMeta119247065761138">
     <gml:description>TIN der tiefengemittelten Fließgeschwindigkeiten</gml:description>
     <gml:name>Geschwindigkeiten</gml:name>
     <resultMeta:path>Tin/tin_VELOCITY.gml</resultMeta:path>
     <resultMeta1d2d:type>tinVelo</resultMeta1d2d:type>
     <resultMeta1d2d:minValue>0.000</resultMeta1d2d:minValue>
     <resultMeta1d2d:maxValue>0.692</resultMeta1d2d:maxValue>
    </resultMeta1d2d:DocumentResultMeta>
   </resultMeta:childMember>
   <resultMeta:childMember>
    <resultMeta1d2d:DocumentResultMeta gml:id="DocumentResultMeta119247065761166">
     <gml:description>Ergebnisse an den Knoten</gml:description>
     <gml:name>Vektoren</gml:name>
     <resultMeta:path>results.gml</resultMeta:path>
     <resultMeta1d2d:type>nodes</resultMeta1d2d:type>
     <resultMeta1d2d:minValue>0.000</resultMeta1d2d:minValue>
     <resultMeta1d2d:maxValue>0.692</resultMeta1d2d:maxValue>
    </resultMeta1d2d:DocumentResultMeta>
   </resultMeta:childMember>
   <resultMeta1d2d:stepTime>2007-09-28T02:00:00.000+02:00</resultMeta1d2d:stepTime>
   <resultMeta1d2d:stepNumber>10</resultMeta1d2d:stepNumber>
   <resultMeta1d2d:isRestart/>
   <resultMeta1d2d:type>unsteady</resultMeta1d2d:type>
  </resultMeta1d2d:StepResultMeta>
 </resultMeta:childMember>
 <resultMeta:childMember xmlns:resultMeta="http://www.tu-harburg.de/wb/kalypso/schemata/simulationbase/result/meta">
  <resultMeta1d2d:StepResultMeta gml:id="StepResultMeta119247065367445">
   <gml:description>instationärer Rechenlauf zum Zeitpunkt: 28.09.2007 14:00:00</gml:description>
   <gml:name>Zeitschritt 11 (28.09.2007 14:00:00)</gml:name>
   <resultMeta:path>timestep-0011</resultMeta:path>
   <resultMeta:childMember>
    <resultMeta1d2d:DocumentResultMeta gml:id="DocumentResultMeta119247067126225">
     <gml:description>ASCII Ergebnisdatei(en) des RMA10 Rechenkerns</gml:description>
     <gml:name>RMA-Rohdaten</gml:name>
     <resultMeta:path>original.2d.zip</resultMeta:path>
     <resultMeta1d2d:type>coreDataZip</resultMeta1d2d:type>
    </resultMeta1d2d:DocumentResultMeta>
   </resultMeta:childMember>
   <resultMeta:childMember>
    <resultMeta1d2d:DocumentResultMeta gml:id="DocumentResultMeta119247069336429">
     <gml:description>TIN der Fließtiefen</gml:description>
     <gml:name>Fließtiefen</gml:name>
     <resultMeta:path>Tin/tin_DEPTH.gml</resultMeta:path>
     <resultMeta1d2d:type>tinDepth</resultMeta1d2d:type>
     <resultMeta1d2d:minValue>0.000</resultMeta1d2d:minValue>
     <resultMeta1d2d:maxValue>3.366</resultMeta1d2d:maxValue>
    </resultMeta1d2d:DocumentResultMeta>
   </resultMeta:childMember>
   <resultMeta:childMember>
    <resultMeta1d2d:DocumentResultMeta gml:id="DocumentResultMeta119247069336436">
     <gml:description>TIN der Wasserspiegellagen</gml:description>
     <gml:name>Wasserspiegellagen</gml:name>
     <resultMeta:path>Tin/tin_WATERLEVEL.gml</resultMeta:path>
     <resultMeta1d2d:type>tinWsp</resultMeta1d2d:type>
     <resultMeta1d2d:minValue>0.000</resultMeta1d2d:minValue>
     <resultMeta1d2d:maxValue>6.422</resultMeta1d2d:maxValue>
    </resultMeta1d2d:DocumentResultMeta>
   </resultMeta:childMember>
   <resultMeta:childMember>
    <resultMeta1d2d:DocumentResultMeta gml:id="DocumentResultMeta119247069336457">
     <gml:description>TIN der tiefengemittelten Fließgeschwindigkeiten</gml:description>
     <gml:name>Geschwindigkeiten</gml:name>
     <resultMeta:path>Tin/tin_VELOCITY.gml</resultMeta:path>
     <resultMeta1d2d:type>tinVelo</resultMeta1d2d:type>
     <resultMeta1d2d:minValue>0.000</resultMeta1d2d:minValue>
     <resultMeta1d2d:maxValue>0.827</resultMeta1d2d:maxValue>
    </resultMeta1d2d:DocumentResultMeta>
   </resultMeta:childMember>
   <resultMeta:childMember>
    <resultMeta1d2d:DocumentResultMeta gml:id="DocumentResultMeta119247069336435">
     <gml:description>Ergebnisse an den Knoten</gml:description>
     <gml:name>Vektoren</gml:name>
     <resultMeta:path>results.gml</resultMeta:path>
     <resultMeta1d2d:type>nodes</resultMeta1d2d:type>
     <resultMeta1d2d:minValue>0.000</resultMeta1d2d:minValue>
     <resultMeta1d2d:maxValue>0.827</resultMeta1d2d:maxValue>
    </resultMeta1d2d:DocumentResultMeta>
   </resultMeta:childMember>
   <resultMeta1d2d:stepTime>2007-09-28T14:00:00.000+02:00</resultMeta1d2d:stepTime>
   <resultMeta1d2d:stepNumber>11</resultMeta1d2d:stepNumber>
   <resultMeta1d2d:isRestart/>
   <resultMeta1d2d:type>unsteady</resultMeta1d2d:type>
  </resultMeta1d2d:StepResultMeta>
 </resultMeta:childMember>
 <resultMeta:childMember xmlns:resultMeta="http://www.tu-harburg.de/wb/kalypso/schemata/simulationbase/result/meta">
  <resultMeta1d2d:StepResultMeta gml:id="StepResultMeta119247068892843">
   <gml:description>instationärer Rechenlauf zum Zeitpunkt: 29.09.2007 02:00:00</gml:description>
   <gml:name>Zeitschritt 12 (29.09.2007 02:00:00)</gml:name>
   <resultMeta:path>timestep-0012</resultMeta:path>
   <resultMeta:childMember>
    <resultMeta1d2d:DocumentResultMeta gml:id="DocumentResultMeta119247070937533">
     <gml:description>ASCII Ergebnisdatei(en) des RMA10 Rechenkerns</gml:description>
     <gml:name>RMA-Rohdaten</gml:name>
     <resultMeta:path>original.2d.zip</resultMeta:path>
     <resultMeta1d2d:type>coreDataZip</resultMeta1d2d:type>
    </resultMeta1d2d:DocumentResultMeta>
   </resultMeta:childMember>
   <resultMeta:childMember>
    <resultMeta1d2d:DocumentResultMeta gml:id="DocumentResultMeta119247073271143">
     <gml:description>TIN der Fließtiefen</gml:description>
     <gml:name>Fließtiefen</gml:name>
     <resultMeta:path>Tin/tin_DEPTH.gml</resultMeta:path>
     <resultMeta1d2d:type>tinDepth</resultMeta1d2d:type>
     <resultMeta1d2d:minValue>0.000</resultMeta1d2d:minValue>
     <resultMeta1d2d:maxValue>3.266</resultMeta1d2d:maxValue>
    </resultMeta1d2d:DocumentResultMeta>
   </resultMeta:childMember>
   <resultMeta:childMember>
    <resultMeta1d2d:DocumentResultMeta gml:id="DocumentResultMeta119247073271152">
     <gml:description>TIN der Wasserspiegellagen</gml:description>
     <gml:name>Wasserspiegellagen</gml:name>
     <resultMeta:path>Tin/tin_WATERLEVEL.gml</resultMeta:path>
     <resultMeta1d2d:type>tinWsp</resultMeta1d2d:type>
     <resultMeta1d2d:minValue>0.000</resultMeta1d2d:minValue>
     <resultMeta1d2d:maxValue>6.426</resultMeta1d2d:maxValue>
    </resultMeta1d2d:DocumentResultMeta>
   </resultMeta:childMember>
   <resultMeta:childMember>
    <resultMeta1d2d:DocumentResultMeta gml:id="DocumentResultMeta119247073271158">
     <gml:description>TIN der tiefengemittelten Fließgeschwindigkeiten</gml:description>
     <gml:name>Geschwindigkeiten</gml:name>
     <resultMeta:path>Tin/tin_VELOCITY.gml</resultMeta:path>
     <resultMeta1d2d:type>tinVelo</resultMeta1d2d:type>
     <resultMeta1d2d:minValue>0.000</resultMeta1d2d:minValue>
     <resultMeta1d2d:maxValue>0.832</resultMeta1d2d:maxValue>
    </resultMeta1d2d:DocumentResultMeta>
   </resultMeta:childMember>
   <resultMeta:childMember>
    <resultMeta1d2d:DocumentResultMeta gml:id="DocumentResultMeta119247073271115">
     <gml:description>Ergebnisse an den Knoten</gml:description>
     <gml:name>Vektoren</gml:name>
     <resultMeta:path>results.gml</resultMeta:path>
     <resultMeta1d2d:type>nodes</resultMeta1d2d:type>
     <resultMeta1d2d:minValue>0.000</resultMeta1d2d:minValue>
     <resultMeta1d2d:maxValue>0.832</resultMeta1d2d:maxValue>
    </resultMeta1d2d:DocumentResultMeta>
   </resultMeta:childMember>
   <resultMeta1d2d:stepTime>2007-09-29T02:00:00.000+02:00</resultMeta1d2d:stepTime>
   <resultMeta1d2d:stepNumber>12</resultMeta1d2d:stepNumber>
   <resultMeta1d2d:isRestart/>
   <resultMeta1d2d:type>unsteady</resultMeta1d2d:type>
  </resultMeta1d2d:StepResultMeta>
 </resultMeta:childMember>
 <resultMeta:childMember xmlns:resultMeta="http://www.tu-harburg.de/wb/kalypso/schemata/simulationbase/result/meta">
  <resultMeta1d2d:StepResultMeta gml:id="StepResultMeta119247072082423">
   <gml:description>instationärer Rechenlauf zum Zeitpunkt: 29.09.2007 14:00:00</gml:description>
   <gml:name>Zeitschritt 13 (29.09.2007 14:00:00)</gml:name>
   <resultMeta:path>timestep-0013</resultMeta:path>
   <resultMeta:childMember>
    <resultMeta1d2d:DocumentResultMeta gml:id="DocumentResultMeta119247074394263">
     <gml:description>ASCII Ergebnisdatei(en) des RMA10 Rechenkerns</gml:description>
     <gml:name>RMA-Rohdaten</gml:name>
     <resultMeta:path>original.2d.zip</resultMeta:path>
     <resultMeta1d2d:type>coreDataZip</resultMeta1d2d:type>
    </resultMeta1d2d:DocumentResultMeta>
   </resultMeta:childMember>
   <resultMeta:childMember>
    <resultMeta1d2d:DocumentResultMeta gml:id="DocumentResultMeta119247075921826">
     <gml:description>TIN der Fließtiefen</gml:description>
     <gml:name>Fließtiefen</gml:name>
     <resultMeta:path>Tin/tin_DEPTH.gml</resultMeta:path>
     <resultMeta1d2d:type>tinDepth</resultMeta1d2d:type>
     <resultMeta1d2d:minValue>0.000</resultMeta1d2d:minValue>
     <resultMeta1d2d:maxValue>3.166</resultMeta1d2d:maxValue>
    </resultMeta1d2d:DocumentResultMeta>
   </resultMeta:childMember>
   <resultMeta:childMember>
    <resultMeta1d2d:DocumentResultMeta gml:id="DocumentResultMeta119247075921867">
     <gml:description>TIN der Wasserspiegellagen</gml:description>
     <gml:name>Wasserspiegellagen</gml:name>
     <resultMeta:path>Tin/tin_WATERLEVEL.gml</resultMeta:path>
     <resultMeta1d2d:type>tinWsp</resultMeta1d2d:type>
     <resultMeta1d2d:minValue>0.000</resultMeta1d2d:minValue>
     <resultMeta1d2d:maxValue>6.385</resultMeta1d2d:maxValue>
    </resultMeta1d2d:DocumentResultMeta>
   </resultMeta:childMember>
   <resultMeta:childMember>
    <resultMeta1d2d:DocumentResultMeta gml:id="DocumentResultMeta119247075921818">
     <gml:description>TIN der tiefengemittelten Fließgeschwindigkeiten</gml:description>
     <gml:name>Geschwindigkeiten</gml:name>
     <resultMeta:path>Tin/tin_VELOCITY.gml</resultMeta:path>
     <resultMeta1d2d:type>tinVelo</resultMeta1d2d:type>
     <resultMeta1d2d:minValue>0.000</resultMeta1d2d:minValue>
     <resultMeta1d2d:maxValue>0.896</resultMeta1d2d:maxValue>
    </resultMeta1d2d:DocumentResultMeta>
   </resultMeta:childMember>
   <resultMeta:childMember>
    <resultMeta1d2d:DocumentResultMeta gml:id="DocumentResultMeta119247075921827">
     <gml:description>Ergebnisse an den Knoten</gml:description>
     <gml:name>Vektoren</gml:name>
     <resultMeta:path>results.gml</resultMeta:path>
     <resultMeta1d2d:type>nodes</resultMeta1d2d:type>
     <resultMeta1d2d:minValue>0.000</resultMeta1d2d:minValue>
     <resultMeta1d2d:maxValue>0.896</resultMeta1d2d:maxValue>
    </resultMeta1d2d:DocumentResultMeta>
   </resultMeta:childMember>
   <resultMeta1d2d:stepTime>2007-09-29T14:00:00.000+02:00</resultMeta1d2d:stepTime>
   <resultMeta1d2d:stepNumber>13</resultMeta1d2d:stepNumber>
   <resultMeta1d2d:isRestart/>
   <resultMeta1d2d:type>unsteady</resultMeta1d2d:type>
  </resultMeta1d2d:StepResultMeta>
 </resultMeta:childMember>
 <resultMeta1d2d:simulationStartTime>2007-10-15T19:43:53.374+02:00</resultMeta1d2d:simulationStartTime>
 <resultMeta1d2d:simulationEndTime>2007-10-15T19:52:39.359+02:00</resultMeta1d2d:simulationEndTime>
 <resultMeta1d2d:calcUnitID>CalculationUnit2D11914828330154813</resultMeta1d2d:calcUnitID>
</resultMeta1d2d:CalculationUnitResultMeta>
