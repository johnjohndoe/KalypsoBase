A standalone, explicit GML representation of the ISO 19139 CV_DiscreteCoverage model, 
following the geometry-value pair (interleaved) pattern. 

SJDC 2006-12-12

---
Updated SWE Common references to version 1.0.1
Updated namespace to http://www.opengis.net/cv/0.2.1

SJDC 2007-11-21
