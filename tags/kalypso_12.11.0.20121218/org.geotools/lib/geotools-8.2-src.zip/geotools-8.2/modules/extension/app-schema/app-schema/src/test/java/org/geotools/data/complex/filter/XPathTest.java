/*
 *    GeoTools - The Open Source Java GIS Toolkit
 *    http://geotools.org
 *
 *    (C) 2005-2011, Open Source Geospatial Foundation (OSGeo)
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Lesser General Public
 *    License as published by the Free Software Foundation;
 *    version 2.1 of the License.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Lesser General Public License for more details.
 */

package org.geotools.data.complex.filter;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import javax.xml.namespace.QName;
import org.geotools.data.ComplexTestData;
import org.geotools.data.complex.filter.XPath.StepList;
import org.geotools.feature.Types;
import org.geotools.feature.type.AttributeDescriptorImpl;
import org.geotools.feature.type.UniqueNameFeatureTypeFactoryImpl;
import org.geotools.gml3.GMLSchema;
import org.geotools.test.AppSchemaTestSupport;
import org.geotools.xlink.XLINK;
import org.junit.Test;
import org.opengis.feature.type.AttributeDescriptor;
import org.opengis.feature.type.FeatureType;
import org.opengis.feature.type.Name;
import org.xml.sax.helpers.NamespaceSupport;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.fail;

/**
 * 
 * @author Gabriel Roldan (Axios Engineering)
 * @version $Id$
 *
 *
 *
 * @source $URL$
 * @since 2.4
 */
public class XPathTest extends AppSchemaTestSupport {

    @Test
    public void testSteps() throws Exception {
        FeatureType complexType = ComplexTestData
                .createExample01MultiValuedComplexProperty(new UniqueNameFeatureTypeFactoryImpl());
        Name name = complexType.getName();
        AttributeDescriptor descriptor = new AttributeDescriptorImpl(complexType, name, 0,
                Integer.MAX_VALUE, true, null);

        NamespaceSupport namespaces = new NamespaceSupport();
        namespaces.declarePrefix("wq", name.getNamespaceURI());
        try {
            XPath.steps(descriptor, null, namespaces);
            fail("passed null");
        } catch (NullPointerException e) {
        }

        List expected;
        String xpath;

        xpath = "/";
        assertEquals(1, XPath.steps(descriptor, xpath, namespaces).size());
        XPath.Step step = (XPath.Step) XPath.steps(descriptor, xpath, namespaces).get(0);
        QName rootQName = new QName(name.getNamespaceURI(), name.getLocalPart());
        assertEquals(rootQName, step.getName());

        expected = Collections.singletonList(new XPath.Step(rootQName, 1));
        xpath = "wq_plus";
        assertEquals(expected, XPath.steps(descriptor, xpath, namespaces));

        expected = Collections.singletonList(new XPath.Step(rootQName, 1));
        xpath = "/wq_plus";
        assertEquals(expected, XPath.steps(descriptor, xpath, namespaces));

        expected = Collections.singletonList(new XPath.Step(rootQName, 1));
        xpath = "wq_plus/measurement/result/../../measurement/determinand_description/../..";
        assertEquals(expected, XPath.steps(descriptor, xpath, namespaces));

        expected = Arrays.asList(new XPath.Step[] {
                new XPath.Step(new QName(rootQName.getNamespaceURI(), "measurement"), 2),
                new XPath.Step(new QName(rootQName.getNamespaceURI(), "result"), 1) });

        xpath = "wq_plus/measurement/result/../../measurement[2]/result";
        assertEquals(expected, XPath.steps(descriptor, xpath, namespaces));

        expected = Arrays.asList(new XPath.Step[] {
                new XPath.Step(new QName(rootQName.getNamespaceURI(), "measurement"), 1),
                new XPath.Step(new QName(rootQName.getNamespaceURI(), "result"), 1) });
        xpath = "wq_plus/measurement/result/../result/.";
        assertEquals(expected, XPath.steps(descriptor, xpath, namespaces));

        expected = Arrays.asList(new XPath.Step[] { new XPath.Step(new QName(rootQName
                .getNamespaceURI(), "measurement"), 5) });
        xpath = "measurement/result/../../measurement[5]";
        assertEquals(expected, XPath.steps(descriptor, xpath, namespaces));
    }

    /**
     * Tests a location path of the form <code>"foo/bar/@baz"</code> gets built as a
     * {@link StepList} of attribute names <code>"foo/bar/baz"</code> (i.e. no distinction between
     * what's a "property" and what's an (xml) "attribute".
     * 
     * @throws Exception
     */
    @Test
    public void testStepsWithXmlAttribute() throws Exception {
        FeatureType complexType = ComplexTestData
                .createExample01MultiValuedComplexProperty(new UniqueNameFeatureTypeFactoryImpl());
        Name name = complexType.getName();
        AttributeDescriptor descriptor = new AttributeDescriptorImpl(complexType, name, 0,
                Integer.MAX_VALUE, true, null);
        QName rootQName = new QName(name.getNamespaceURI(), name.getLocalPart());

        NamespaceSupport namespaces = new NamespaceSupport();
        namespaces.declarePrefix("wq", name.getNamespaceURI());
        namespaces.declarePrefix("xlink", XLINK.NAMESPACE);

        StepList steps = XPath.steps(descriptor, "wq_plus/measurement[2]/@xlink:href", namespaces);
        assertNotNull(steps);
        assertEquals(steps.toString(), 2, steps.size());

        XPath.Step step1 = new XPath.Step(new QName(rootQName.getNamespaceURI(), "measurement"), 2,
                false);
        XPath.Step step2 = new XPath.Step(XLINK.HREF, 1, true);

        assertEquals(step1, steps.get(0));
        assertEquals(step2, steps.get(1));
    }

    @Test
    public void testStepEquals() {
        XPath.Step step1 = new XPath.Step(XLINK.FROM, 1);

        XPath.Step step2 = new XPath.Step(XLINK.HREF, 1, false);
        XPath.Step step3 = new XPath.Step(XLINK.HREF, 1, false);

        XPath.Step step4 = new XPath.Step(XLINK.HREF, 1, true);
        XPath.Step step5 = new XPath.Step(XLINK.HREF, 2, false);

        assertFalse(step1.equals(null));
        assertFalse(step1.equals(new Object()));
        assertFalse(step1.equals(step2));

        assertTrue(step2.equals(step3));
        assertFalse(step2.equals(step4));
        assertFalse(step2.equals(step5));
    }

    /**
     * Test that some simple-content and non-simple-content types are correctly detected.
     */
    @Test
    public void testIsSimpleContentType() {
        assertTrue(Types.isSimpleContentType(GMLSchema.CODETYPE_TYPE));
        assertTrue(Types.isSimpleContentType(GMLSchema.MEASURETYPE_TYPE));
        assertFalse(Types.isSimpleContentType(GMLSchema.POINTTYPE_TYPE));
        assertFalse(Types.isSimpleContentType(GMLSchema.POINTPROPERTYTYPE_TYPE));
        assertFalse(Types.isSimpleContentType(GMLSchema.ABSTRACTFEATURETYPE_TYPE));
        assertFalse(Types.isSimpleContentType(GMLSchema.ABSTRACTFEATURECOLLECTIONTYPE_TYPE));
    }

  /**
   * Test that the {@link StepList} for the root element is properly formed.
   */
  @Test
    public void testRootElementSteps() {
        NamespaceSupport namespaces = new NamespaceSupport();

        try {
            XPath.rootElementSteps(null, namespaces);
            fail("passed null");
        } catch (NullPointerException e) {
        }

        FeatureType complexType = ComplexTestData
                .createExample05NoNamespaceURI(new UniqueNameFeatureTypeFactoryImpl());
        Name name = complexType.getName();
        AttributeDescriptor descriptor = new AttributeDescriptorImpl(complexType, name, 0,
                Integer.MAX_VALUE, true, null);

        try {
            XPath.rootElementSteps(descriptor, namespaces);
        } catch (NullPointerException e) {
            fail("failed null");
        }

        assertEquals(1, XPath.rootElementSteps(descriptor, namespaces).size());
        XPath.Step step = XPath.rootElementSteps(descriptor, namespaces).get(0);
        QName rootQName = new QName(name.getNamespaceURI(), name.getLocalPart(), "");
        assertEquals(rootQName, step.getName());

        complexType = ComplexTestData
                .createExample01MultiValuedComplexProperty(new UniqueNameFeatureTypeFactoryImpl());
        name = complexType.getName();
        descriptor = new AttributeDescriptorImpl(complexType, name, 0, Integer.MAX_VALUE, true,
                null);

        String prefix = "wq";
        namespaces.declarePrefix(prefix, name.getNamespaceURI());

        try {
            XPath.rootElementSteps(descriptor, namespaces);
        } catch (NullPointerException e) {
            fail("failed null");
        }

        assertEquals(1, XPath.rootElementSteps(descriptor, namespaces).size());
        step = XPath.rootElementSteps(descriptor, namespaces).get(0);
        rootQName = new QName(name.getNamespaceURI(), name.getLocalPart(), prefix);
        assertEquals(rootQName, step.getName());
    }
}
