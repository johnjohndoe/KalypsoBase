//$HeadURL: https://svn.wald.intevation.org/svn/deegree/base/trunk/src/org/deegree/framework/util/IDGenerator.java $
/*----------------    FILE HEADER  ------------------------------------------
 
 This file is part of deegree.
 Copyright (C) 2001-2008 by:
 EXSE, Department of Geography, University of Bonn
 http://www.giub.uni-bonn.de/deegree/
 lat/lon GmbH
 http://www.lat-lon.de
 
 This library is free software; you can redistribute it and/or
 modify it under the terms of the GNU Lesser General Public
 License as published by the Free Software Foundation; either
 version 2.1 of the License, or (at your option) any later version.
 
 This library is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 Lesser General Public License for more details.
 
 You should have received a copy of the GNU Lesser General Public
 License along with this library; if not, write to the Free Software
 Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 
 Contact:
 
 Andreas Poth
 lat/lon GmbH
 Aennchenstr. 19
 53115 Bonn
 Germany
 E-Mail: poth@lat-lon.de

 Prof. Dr. Klaus Greve 
 Department of Geography
 University of Bonn
 Meckenheimer Allee 166
 53115 Bonn 
 Germany
 E-Mail: greve@giub.uni-bonn.de

 ----------------------------------------------------------------------------*/

package org.deegree.framework.util;

/**
 * Produces unique IDs (used to generate Request-IDs, for example).
 * <p>
 * 
 * @author <a href="mailto:mschneider@lat-lon.de">Markus Schneider</a>
 * @version $Revision: 10660 $ $Date: 2008-03-24 22:39:54 +0100 (Mon, 24 Mar 2008) $
 */
public class IDGenerator {

    /**
     * The only instance of this class.
     */
    private static IDGenerator instance = null;

    /** The current ID. */
    private long id = 0;

    /**
     * Returns the only instance of this class.
     * 
     * @return the only instance of IDGenerator
     * 
     */
    synchronized public static IDGenerator getInstance() {
        if ( instance == null )
            instance = new IDGenerator();
        return instance;
    }

    /**
     * Generates a completly unique ID.
     * 
     * @return a unique ID
     */
    synchronized public long generateUniqueID() {
        return id++;
    }
}
