//$HeadURL: https://svn.wald.intevation.org/svn/deegree/base/trunk/src/org/deegree/framework/util/LoggingInterceptor.java $
//$Id: LoggingInterceptor.java 11888 2008-05-26 08:41:56Z rbezema $
/*----------------    FILE HEADER  ------------------------------------------
 
 This file is part of deegree.
 Copyright (C) 2001-2008 by:
 EXSE, Department of Geography, University of Bonn
 http://www.giub.uni-bonn.de/deegree/
 lat/lon GmbH
 http://www.lat-lon.de
 
 This library is free software; you can redistribute it and/or
 modify it under the terms of the GNU Lesser General Public
 License as published by the Free Software Foundation; either
 version 2.1 of the License, or (at your option) any later version.
 
 This library is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 Lesser General Public License for more details.
 
 You should have received a copy of the GNU Lesser General Public
 License along with this library; if not, write to the Free Software
 Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 
 Contact:
 
 Andreas Poth
 lat/lon GmbH
 Aennchenstr. 19
 53115 Bonn
 Germany
 E-Mail: poth@lat-lon.de
 
 Prof. Dr. Klaus Greve
 Department of Geography
 University of Bonn
 Meckenheimer Allee 166
 53115 Bonn
 Germany
 E-Mail: greve@giub.uni-bonn.de
 
 
 ---------------------------------------------------------------------------*/

package org.deegree.framework.util;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

/**
 * Logging interceptor to log the entering and exiting of a method call.
 * 
 * @author <a href="mailto:tfr@users.sourceforge.net">Torsten Friebe </A>
 * 
 * @author last edited by: $Author: rbezema $
 * 
 * @version 2.0, $Revision: 11888 $, $Date: 2008-05-26 10:41:56 +0200 (Mon, 26 May 2008) $
 * 
 * @see <a href="http://www.dofactory.com/patterns/PatternChain.aspx">Chain of Responsibility Design
 *      Pattern </a>
 * 
 * @since 2.0
 */
public class LoggingInterceptor extends Interceptor {

    /**
     * @param nextInterceptor pointing to the next intersection
     */
    public LoggingInterceptor( Interceptor nextInterceptor ) {
        this.nextInterceptor = nextInterceptor;
    }

    @Override 
    protected Object handleInvocation( Method method, Object[] params )
                            throws IllegalAccessException, InvocationTargetException {
        LOG.logDebug( ">Invoke " + method.getName() + " on " + getTarget() );
        Object result = nextInterceptor.handleInvocation( method, params );
        LOG.logDebug( "<Finish " + method.getName() + " on " + getTarget() );
        return result;
    }

}