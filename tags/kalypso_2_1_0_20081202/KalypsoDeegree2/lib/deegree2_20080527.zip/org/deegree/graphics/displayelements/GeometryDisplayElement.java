//$HeadURL: https://svn.wald.intevation.org/svn/deegree/base/trunk/src/org/deegree/graphics/displayelements/GeometryDisplayElement.java $
/*----------------    FILE HEADER  ------------------------------------------

 This file is part of deegree.
 Copyright (C) 2001-2008 by:
 EXSE, Department of Geography, University of Bonn
 http://www.giub.uni-bonn.de/deegree/
 lat/lon GmbH
 http://www.lat-lon.de

 This library is free software; you can redistribute it and/or
 modify it under the terms of the GNU Lesser General Public
 License as published by the Free Software Foundation; either
 version 2.1 of the License, or (at your option) any later version.

 This library is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 Lesser General Public License for more details.

 You should have received a copy of the GNU Lesser General Public
 License along with this library; if not, write to the Free Software
 Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

 Contact:

 Andreas Poth
 lat/lon GmbH
 Aennchenstr. 19
 53115 Bonn
 Germany
 E-Mail: poth@lat-lon.de

 Prof. Dr. Klaus Greve
 Department of Geography
 University of Bonn
 Meckenheimer Allee 166
 53115 Bonn
 Germany
 E-Mail: greve@giub.uni-bonn.de

 
 ---------------------------------------------------------------------------*/
package org.deegree.graphics.displayelements;

import java.io.Serializable;

import org.deegree.graphics.sld.Symbolizer;
import org.deegree.model.feature.Feature;
import org.deegree.model.spatialschema.Envelope;
import org.deegree.model.spatialschema.Geometry;
import org.deegree.model.spatialschema.Position;

/**
 * Basic interface of all display elements that are related to a geometry (this is the common case).
 * 
 * @author <a href="mailto:poth@lat-lon.de">Andreas Poth</a>
 * @author last edited by: $Author: apoth $
 * 
 * @version $Revision: 10660 $, $Date: 2008-03-24 22:39:54 +0100 (Mon, 24 Mar 2008) $
 */
abstract class GeometryDisplayElement extends AbstractDisplayElement implements Serializable {

    /** Use serialVersionUID for interoperability. */
    private final static long serialVersionUID = 465725117946501686L;

    protected Geometry geometry;

    protected Symbolizer symbolizer;

    protected Symbolizer highlightSymbolizer;

    protected Symbolizer selectedSymbolizer;

    protected Object placement;

    /**
     * Creates a new GeometryDisplayElement object.
     * 
     * @param feature
     * @param geometry
     */
    GeometryDisplayElement( Feature feature, Geometry geometry ) {
        super( feature );
        setGeometry( geometry );
    }

    /**
     * Creates a new GeometryDisplayElement object.
     * 
     * @param feature
     * @param geometry
     * @param symbolizer
     */
    GeometryDisplayElement( Feature feature, Geometry geometry, Symbolizer symbolizer ) {
        super( feature );
        setGeometry( geometry );
        setSymbolizer( symbolizer );
        setHighlightSymbolizer( symbolizer );
        setSelectedSymbolizer( symbolizer );
    }

    /**
     * Creates a new GeometryDisplayElement object.
     * 
     * @param feature
     * @param geometry
     * @param symbolizer
     * @param selectedSymbolizer
     * @param highlightSymbolizer
     */
    GeometryDisplayElement( Feature feature, Geometry geometry, Symbolizer symbolizer, Symbolizer highlightSymbolizer,
                            Symbolizer selectedSymbolizer ) {
        super( feature );
        setGeometry( geometry );
        setSymbolizer( symbolizer );
        setSelectedSymbolizer( selectedSymbolizer );
        setHighlightSymbolizer( highlightSymbolizer );
    }

    /**
     * Returns a new {@link Envelope} for the given envelope that has a border of percent * (with |
     * height) on all sides around it (the longer side is used to determine the border size).
     * 
     * @param env
     * @param percent
     * @return envelope with border around it
     */
    protected Envelope growEnvelope( Envelope env, float percent ) {
        Position minPos = env.getMin();
        Position maxPos = env.getMax();
        double h = maxPos.getX() - minPos.getX();
        double w = maxPos.getY() - minPos.getY();
        h = Math.abs( h );
        w = Math.abs( w );
        double maxSide = Math.max( w, h );
        return env.getBuffer( maxSide * percent );
    }

    /**
     * Overwrites the default placement of the <tt>DisplayElement</tt>. This method is used by
     * the <tt>PlacementOptimizer</tt> to minimize the overlapping of labels, for example.
     * <p>
     * 
     * @param o
     *            the placement to be used
     */
    public void setPlacement( Object o ) {
        placement = o;
    }

    /**
     * sets the geometry that determines the position the DisplayElement will be rendered to
     */
    public void setGeometry( Geometry geometry ) {
        this.geometry = geometry;
    }

    /**
     * returns the geometry that determines the position the DisplayElement will be rendered to
     */
    public Geometry getGeometry() {
        return geometry;
    }

    /**
     * sets the rules that determines how the geometry will be rendered
     */
    public void setSymbolizer( Symbolizer symbolizer ) {
        this.symbolizer = symbolizer;
    }

    /**
     * Returns the symbolizer that determines how the geometry will be rendered.
     */
    public Symbolizer getSymbolizer() {
        return symbolizer;
    }

    /**
     * sets the rule that determines how the geometry will be rendered when it's highlighted
     * 
     * @param rule
     *            symbolizer defining rendering style
     */
    public void setHighlightSymbolizer( Symbolizer rule ) {
        this.highlightSymbolizer = rule;
    }

    /**
     * returns the symbolizer that determines how the geometry will be rendered if it's highlighted
     */
    public Symbolizer getHighlightSymbolizer() {
        return highlightSymbolizer;
    }

    /**
     * sets the rule that determines how the geometry will be rendered when it's selected
     * 
     * @param rule
     *            symbolizer defining rendering style
     */
    public void setSelectedSymbolizer( Symbolizer rule ) {
        selectedSymbolizer = rule;
    }

    /**
     * returns the symbolizer that determines how the geometry will be rendered if it's selected
     */
    public Symbolizer getSelectedSymbolizer() {
        return selectedSymbolizer;
    }

    /**
     * Returns if the <tt>DisplayElement</tt> should be painted at the current scale or not.
     */
    public boolean doesScaleConstraintApply( double scale ) {
        return symbolizer.getMinScaleDenominator() <= scale && symbolizer.getMaxScaleDenominator() > scale;
    }
}
