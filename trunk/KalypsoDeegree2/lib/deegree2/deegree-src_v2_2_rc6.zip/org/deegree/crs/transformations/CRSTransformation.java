//$HeadURL: $
/*----------------    FILE HEADER  ------------------------------------------
 This file is part of deegree.
 Copyright (C) 2001-2008 by:
 Department of Geography, University of Bonn
 http://www.giub.uni-bonn.de/deegree/
 lat/lon GmbH
 http://www.lat-lon.de

 This library is free software; you can redistribute it and/or
 modify it under the terms of the GNU Lesser General Public
 License as published by the Free Software Foundation; either
 version 2.1 of the License, or (at your option) any later version.
 This library is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 Lesser General Public License for more details.
 You should have received a copy of the GNU Lesser General Public
 License along with this library; if not, write to the Free Software
 Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 Contact:

 Andreas Poth
 lat/lon GmbH
 Aennchenstr. 19
 53177 Bonn
 Germany
 E-Mail: poth@lat-lon.de

 Prof. Dr. Klaus Greve
 Department of Geography
 University of Bonn
 Meckenheimer Allee 166
 53115 Bonn
 Germany
 E-Mail: greve@giub.uni-bonn.de
 ---------------------------------------------------------------------------*/

package org.deegree.crs.transformations;

import java.util.ArrayList;
import java.util.List;

import javax.vecmath.Point3d;

import org.deegree.crs.Identifiable;
import org.deegree.crs.coordinatesystems.CoordinateSystem;
import org.deegree.crs.exceptions.TransformationException;
import org.deegree.i18n.Messages;

/**
 * The change of coordinates from one CRS to another CRS based on different datum is 'currently' only possible via a
 * coordinate <code>Transformation</code>.
 * <p>
 * The transformation parameters could only be derived empirically by a set of points common to both coordinate
 * reference systems it means by identical points. Choice, allocation, number and the quality of coordinates of the
 * points affect extensive the results and the accuracy. Therefore different realizations for transformations from one
 * datum to another exist.
 * </p>
 * 
 * @author <a href="mailto:bezema@lat-lon.de">Rutger Bezema</a>
 * 
 * @author last edited by: $Author:$
 * 
 * @version $Revision:$, $Date:$
 * 
 */

public abstract class CRSTransformation extends Identifiable {

    private CoordinateSystem sourceCRS;

    private CoordinateSystem targetCRS;

    boolean isInverse;

    /**
     * @param sourceCRS
     * @param targetCRS
     * @param identifiers
     */
    public CRSTransformation( CoordinateSystem sourceCRS, CoordinateSystem targetCRS, String[] identifiers ) {
        this( sourceCRS, targetCRS, identifiers, null, null, null, null );
    }

    /**
     * @param sourceCRS
     * @param targetCRS
     * @param identifiers
     * @param names
     * @param versions
     * @param descriptions
     * @param areasOfUse
     */
    public CRSTransformation( CoordinateSystem sourceCRS, CoordinateSystem targetCRS, String[] identifiers,
                              String[] names, String[] versions, String[] descriptions, String[] areasOfUse ) {
        super( identifiers, names, versions, descriptions, areasOfUse );
        this.sourceCRS = sourceCRS;
        this.targetCRS = targetCRS;
        isInverse = false;
    }

    /**
     * @param sourceCRS
     * @param targetCRS
     * @param identifier
     * @param name
     * @param version
     * @param description
     * @param areaOfUse
     */
    public CRSTransformation( CoordinateSystem sourceCRS, CoordinateSystem targetCRS, String identifier, String name,
                              String version, String description, String areaOfUse ) {
        this( sourceCRS,
              targetCRS,
              new String[] { identifier },
              new String[] { name },
              new String[] { version },
              new String[] { description },
              new String[] { areaOfUse } );
    }

    /**
     * This constructor creates takes the id. Name, Version, description and areaOfUse are set to null.
     * 
     * @param source
     *            the geographic crs.
     * @param target
     *            the geocentric crs.
     * @param identifier
     */
    public CRSTransformation( CoordinateSystem source, CoordinateSystem target, String identifier ) {
        this( source, target, identifier, null, null, null, null );
    }

    /**
     * Creates a CRSTransformation with following identifier and name: <code>
     * FROM_id1_TO_id2.</code> The name will be
     * generated the same way (with getName() instead). And version, description and areaOfUse set to 'Unkown'.
     * 
     * @param sourceCRS
     * @param targetCRS
     */
    public CRSTransformation( CoordinateSystem sourceCRS, CoordinateSystem targetCRS ) {
        this( sourceCRS, targetCRS, createFromTo( sourceCRS.getIdentifier(), targetCRS.getIdentifier() ) );
    }

    /**
     * Little helper function to create a temporary id or name.
     * 
     * @param from
     *            containing the value (id or name) of the 'from' coourdinateSystem
     * @param to
     *            containing the value (id or name) of the 'to' coourdinateSystem
     * @return a following string "FROM_fromValue_TO_toValue".
     */
    protected static String createFromTo( String from, String to ) {
        return new StringBuilder( "FROM_" ).append( from ).append( "_TO_" ).append( to ).toString();
    }

    /**
     * Do a transformation, e.g. the incoming data comes from the sourceCRS and must be transformed to the targetCRS.
     * 
     * @param srcPts
     *            the points which must be transformed, expected are following values either, long_1, lat_1, height_1,
     *            long_2, lat_2, height_2. or long_1, lat_1, long_2, lat_2
     * @return the transformed points
     */
    public abstract List<Point3d> doTransform( final List<Point3d> srcPts );

    /**
     * Wraps the incoming coords into a List<Point3d> and calls the {@link #doTransform(List)}. The source array will
     * be read according to the dimension of the source CRS {@link #getSourceDimension()} and the target coords will be
     * put according to the dimension of the targetCRS {@link #getTargetDimension()}. If the sourceDim &lt; 2 or &gt; 3
     * a transformation exception will be thrown.
     * 
     * @param srcCoords
     *            the array holding the source ('original') coords.
     * @param startPositionSrc
     *            the position to start reading the coords from the source array (0 is the first).
     * @param destCoords
     *            the array which will receive the tranformed coords.
     * @param startPositionDest
     *            the index of the destCoords array to put the results, if the result will exceed the arraylength, the
     *            array will be enlarged to hold the transformed coords.
     * @param lastCoord
     *            the index of the last coord (normally length-1)
     * @throws TransformationException
     *             If the sourceDim &lt; 2 or soureDim &gt 3;
     * @throws IllegalArgumentException
     *             if
     *             <ul>
     *             <li> the srcCoords is null</li>
     *             <li>the startPositionSrc &gt; srcCoords.length</li>
     *             <li> the lastCoord &gt; startPositionSrc</li>
     *             <li>the number of source coords are not kongruent with the source dimension</li>
     *             <li> the lastCoord &lt; startCoordSrc</li>
     *             <li>the source or target dimension &lt; 2 or &gt; 3</li>
     *             </ul>
     */
    public void doTransform( double[] srcCoords, int startPositionSrc, double[] destCoords, int startPositionDest,
                             int lastCoord )
                                            throws TransformationException {
        if ( startPositionSrc < 0 ) {
            startPositionSrc = 0;
        }
        if ( srcCoords == null ) {
            throw new IllegalArgumentException( Messages.getMessage( "CRS_PARAMETER_NOT_NULL",
                                                                     "doTransform(double[],int,double[],int,int)",
                                                                     "srcCoords" ) );
        }
        if ( startPositionSrc > srcCoords.length ) {
            throw new IllegalArgumentException( Messages.getMessage( "CRS_TRANSFORM_START_GT_LENGTH" ) );
        }
        if ( lastCoord > srcCoords.length ) {
            throw new IllegalArgumentException( Messages.getMessage( "CRS_TRANSFORM_END_GT_LENGTH" ) );
        }
        if ( ( lastCoord - startPositionSrc ) % getSourceDimension() != 0 ) {
            throw new IllegalArgumentException( Messages.getMessage( "CRS_TRANSFORM_SRC_WRONG_DIM" ) );
        }
        int listSize = ( lastCoord - startPositionSrc ) / getSourceDimension();
        if ( listSize < 0 ) {
            throw new IllegalArgumentException( Messages.getMessage( "CRS_TRANSFORM_LAST_LT_START" ) );
        }

        List<Point3d> sourceCoords = new ArrayList<Point3d>( listSize );
        final int dim = getSourceDimension();
        if ( dim > 3 || dim < 2 ) {
            throw new TransformationException( Messages.getMessage( "CRS_TRANSFORM_WRONG_CRS_DIM", "source" ) );
        }
        for ( int i = startPositionSrc; i < lastCoord && ( i + ( dim - 1 ) ) < lastCoord; i += dim ) {
            sourceCoords.add( new Point3d( srcCoords[i], srcCoords[i + 1], ( dim == 3 ) ? srcCoords[i + 2] : 0 ) );
        }
        List<Point3d> result = doTransform( sourceCoords );
        if ( startPositionDest < 0 ) {
            startPositionDest = 0;
        }
        final int requiredSpace = result.size() * getTargetDimension();
        if ( destCoords == null ) {
            startPositionDest = 0;
            destCoords = new double[requiredSpace];
        }
        final int requiredSize = startPositionDest + requiredSpace;
        if ( requiredSize > destCoords.length ) {
            double[] tmp = new double[requiredSize];
            System.arraycopy( destCoords, 0, tmp, 0, startPositionDest );
            destCoords = tmp;
        }
        final int dimDest = getTargetDimension();
        if ( dimDest > 3 || dimDest < 2 ) {
            throw new TransformationException( Messages.getMessage( "CRS_TRANSFORM_WRONG_CRS_DIM", "target" ) );
        }
        int arrayPos = startPositionDest;
        for ( Point3d coord : result ) {
            destCoords[arrayPos++] = coord.x;
            destCoords[arrayPos++] = coord.y;
            if ( dimDest == 3 ) {
                destCoords[arrayPos++] = coord.z;
            }
        }

    }

    /**
     * Transforms a single point3d (by calling the doTransform( List<Point3d>).
     * 
     * @param coordinate
     *            to transform, if <code>null</code> null will be returned.
     * @return the transformed coordinate.
     */
    public Point3d doTransform( Point3d coordinate ) {
        if ( coordinate == null ) {
            return null;
        }
        List<Point3d> coord = new ArrayList<Point3d>( 1 );
        coord.add( coordinate );
        return doTransform( coord ).get( 0 );
    }

    /**
     * @return true if this transformation doesn't transform the incoming points. (e.g. is the id. matrix)
     */
    public abstract boolean isIdentity();

    /**
     * @return true if the doInverseTransform method should be called, false otherwise.
     */
    public boolean isInverseTransform() {
        return isInverse;
    }

    /**
     * Call this method to indicate the transform should be inverse (or not).
     */
    public void inverse() {
        isInverse = !isInverse;
    }

    /**
     * @return a representation of this transformations name.
     */
    public String getTransformationName() {
        StringBuilder result = new StringBuilder( isInverse ? "Inverse " : "" );
        result.append( getName() );
        return result.toString();
    }

    /**
     * @return the sourceCRS.
     */
    public final CoordinateSystem getSourceCRS() {
        return isInverse ? targetCRS : sourceCRS;
    }

    /**
     * @return the targetCRS.
     */
    public final CoordinateSystem getTargetCRS() {
        return isInverse ? sourceCRS : targetCRS;
    }

    /**
     * @return the dimension of the source coordinateSystem.
     */
    public int getSourceDimension() {
        return getSourceCRS().getDimension();
    }

    /**
     * @return the dimension of the target coordinateSystem.
     */
    public int getTargetDimension() {
        return getTargetCRS().getDimension();
    }

    /**
     * Checks if this transformation is the inverse of the other transformation, which means, this.sourceCRS equals
     * other.targetCRS && this.targetCRS == other.sourceCRS. If Both transformations are identity this method also
     * returns true.
     * 
     * @param other
     *            the transformation to check
     * @return true if this and the other transformation are eachothers inverse.
     */
    public boolean areInverse( CRSTransformation other ) {
        return ( other == null ) ? false
                                : ( this.isIdentity() && other.isIdentity() ) || ( ( this.getSourceCRS()
                                                                                         .equals( other.getTargetCRS() ) && this.getTargetCRS()
                                                                                                                                .equals( other.getSourceCRS() ) ) );
    }

    /**
     * @param sb to add the transformation chain to, if <code>null</code> a new StringBuilder will be created.
     * @return the given StringBuilder (or a new instance) with the appended transformation steps.
     */
    public final StringBuilder getTransformationPath( StringBuilder sb ) {
        if ( sb == null ) {
            sb = new StringBuilder();
        }
        outputTransform( 0, sb, this );
        return sb;
    }

    private int outputTransform( int level, StringBuilder sb, CRSTransformation t ) {
        if ( t instanceof ConcatenatedTransform ) {
            level = outputTransform( level, sb, ( (ConcatenatedTransform) t ).getFirstTransform() );
            level = outputTransform( level, sb, ( (ConcatenatedTransform) t ).getSecondTransform() );
        } else {
            if ( level != 0 ) {
                sb.append( "->" );
            }
            sb.append( "(" ).append( level ).append( ")" ).append( t.getTransformationName() );
            return ++level;
        }
        return level;
    }
}
