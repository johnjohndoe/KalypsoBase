// $HeadURL: svn+ssh://rbezema@svn.wald.intevation.org/deegree/base/branches/2.2_testing/src/org/deegree/datatypes/parameter/GeneralParameterValueIm.java $
/*----------------    FILE HEADER  ------------------------------------------

 This file is part of deegree.
 Copyright (C) 2001-2008 by:
 EXSE, Department of Geography, University of Bonn
 http://www.giub.uni-bonn.de/deegree/
 lat/lon GmbH
 http://www.lat-lon.de

 This library is free software; you can redistribute it and/or
 modify it under the terms of the GNU Lesser General Public
 License as published by the Free Software Foundation; either
 version 2.1 of the License, or (at your option) any later version.

 This library is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 Lesser General Public License for more details.

 You should have received a copy of the GNU Lesser General Public
 License along with this library; if not, write to the Free Software
 Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

 Contact:

 Andreas Poth
 lat/lon GmbH
 Aennchenstr. 19
 53115 Bonn
 Germany
 E-Mail: poth@lat-lon.de

 Prof. Dr. Klaus Greve
 Department of Geography
 University of Bonn
 Meckenheimer Allee 166
 53115 Bonn
 Germany
 E-Mail: greve@giub.uni-bonn.de

 
 ---------------------------------------------------------------------------*/
package org.deegree.datatypes.parameter;

import java.io.Serializable;

/**
 * @version $Revision: 9337 $
 * @author <a href="mailto:poth@lat-lon.de">Andreas Poth</a>
 * @author last edited by: $Author: apoth $
 * 
 * @version 1.0. $Revision: 9337 $, $Date: 2007-12-27 13:31:11 +0100 (Do, 27 Dez 2007) $
 * 
 * @since 2.0
 */

public class GeneralParameterValueIm implements Serializable {

    private static final long serialVersionUID = 5138443095346081064L;

    private GeneralOperationParameterIm descriptor = null;

    /**
     * @param descriptor
     */
    public GeneralParameterValueIm( GeneralOperationParameterIm descriptor ) {
        this.descriptor = descriptor;
    }

    /**
     * @return Returns the descriptor.
     * 
     */
    public GeneralOperationParameterIm getDescriptor() {
        return descriptor;
    }

    /**
     * @param descriptor The descriptor to set.
     * 
     */
    public void setDescriptor( GeneralOperationParameterIm descriptor ) {
        this.descriptor = descriptor;
    }

    /**
     * Creates and returns a copy of this object.
     * The precise meaning of "copy" may depend on the class of the object.
     *
     * @return A clone of this instance.
     * @see Object#clone
     */
    public Object clone() {
        return new GeneralParameterValueIm( descriptor );
    }
}
