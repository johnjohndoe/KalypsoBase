//$HeadURL: svn+ssh://rbezema@svn.wald.intevation.org/deegree/base/branches/2.2_testing/src/org/deegree/datatypes/values/Interval.java $
/*----------------    FILE HEADER  ------------------------------------------

 This file is part of deegree.
 Copyright (C) 2001-2008 by:
 EXSE, Department of Geography, University of Bonn
 http://www.giub.uni-bonn.de/deegree/
 lat/lon GmbH
 http://www.lat-lon.de

 This library is free software; you can redistribute it and/or
 modify it under the terms of the GNU Lesser General Public
 License as published by the Free Software Foundation; either
 version 2.1 of the License, or (at your option) any later version.

 This library is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 Lesser General Public License for more details.

 You should have received a copy of the GNU Lesser General Public
 License along with this library; if not, write to the Free Software
 Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

 Contact:

 Andreas Poth
 lat/lon GmbH
 Aennchenstr. 19
 53115 Bonn
 Germany
 E-Mail: poth@lat-lon.de

 Prof. Dr. Klaus Greve
 Department of Geography
 University of Bonn
 Meckenheimer Allee 166
 53115 Bonn
 Germany
 E-Mail: greve@giub.uni-bonn.de

 
 ---------------------------------------------------------------------------*/
package org.deegree.datatypes.values;

import java.io.Serializable;
import java.net.URI;

/**
 * @version $Revision: 9337 $
 * @author <a href="mailto:poth@lat-lon.de">Andreas Poth</a>
 * @author last edited by: $Author: apoth $
 * 
 * @version 1.0. $Revision: 9337 $, $Date: 2007-12-27 13:31:11 +0100 (Do, 27 Dez 2007) $
 * 
 * @since 2.0
 */

public class Interval extends ValueRange implements Cloneable, Serializable {

    private static final long serialVersionUID = 1L;
    private TypedLiteral res = null;

    
    
    /**
     * default:
     * atomic = false
     * closure = closed
     * 
     * @param min
     * @param max
     * @param type
     * @param semantic
     */
    public Interval(TypedLiteral min, TypedLiteral max, URI type, URI semantic, TypedLiteral res) {
        super(min, max, type, semantic);
        this.res = res;
    }

    /**
     * @param min
     * @param max
     * @param type
     * @param semantic
     * @param atomic
     * @param closure
     */
    public Interval(TypedLiteral min, TypedLiteral max, URI type, URI semantic, 
                    boolean atomic, Closure closure, TypedLiteral res) {
        super(min, max, type, semantic, atomic, closure);
        this.res = res;
    }

    /**
     * @return Returns the res.
     * 
     */
    public TypedLiteral getRes() {
        return res;
    }

    /**
     * @param res The res to set.
     * 
     */
    public void setRes(TypedLiteral res) {
        this.res = res;
    }

    
    /**
     * @see java.lang.Object#clone()
     */
    public Object clone() {
        ValueRange vr = (ValueRange)super.clone();
        TypedLiteral res_ = (TypedLiteral)res.clone();
        return new Interval( vr.getMin(), vr.getMax(), vr.getType(), vr.getSemantic(), 
                             vr.isAtomic(), vr.getClosure(), res_);
    }

}
