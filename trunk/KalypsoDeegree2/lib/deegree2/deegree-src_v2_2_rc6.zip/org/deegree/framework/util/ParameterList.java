//$HeadURL: svn+ssh://rbezema@svn.wald.intevation.org/deegree/base/branches/2.2_testing/src/org/deegree/framework/util/ParameterList.java $
/*----------------    FILE HEADER  ------------------------------------------

 This file is part of deegree.
 Copyright (C) 2001-2008 by:
 EXSE, Department of Geography, University of Bonn
 http://www.giub.uni-bonn.de/deegree/
 lat/lon GmbH
 http://www.lat-lon.de

 This library is free software; you can redistribute it and/or
 modify it under the terms of the GNU Lesser General Public
 License as published by the Free Software Foundation; either
 version 2.1 of the License, or (at your option) any later version.

 This library is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 Lesser General Public License for more details.

 You should have received a copy of the GNU Lesser General Public
 License along with this library; if not, write to the Free Software
 Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

 Contact:

 Andreas Poth
 lat/lon GmbH
 Aennchenstr. 19
 53115 Bonn
 Germany
 E-Mail: poth@lat-lon.de

 Prof. Dr. Klaus Greve
 Department of Geography
 University of Bonn
 Meckenheimer Allee 166
 53115 Bonn
 Germany
 E-Mail: greve@giub.uni-bonn.de
 
 ---------------------------------------------------------------------------*/

package org.deegree.framework.util;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;

/**
 * The interface defines the access to a list of paramters that can be used as submitted parameters
 * to methods that may receive an variable list of parameters.
 * 
 * @author <a href="mailto:poth@lat-lon.de">Andreas Poth</a>
 * @author last edited by: $Author: apoth $
 * 
 * @version $Revision: 9339 $ $Date: 2007-12-27 13:31:52 +0100 (Do, 27 Dez 2007) $
 */
final public class ParameterList {

    private HashMap<String, Parameter> params = new HashMap<String, Parameter>();

    private ArrayList<String> keys = new ArrayList<String>( 100 );

    /**
     * returns the parameter that matches the submitted name. if no parameter can be found
     * <tt>null</tt> will be returned.
     * 
     * @param name
     * @return name parameter
     */
    public Parameter getParameter( String name ) {
        return params.get( name );
    }

    /**
     * adds a new <tt>Parameter</tt> to the list
     * 
     * @param name
     * @param value
     * 
     */
    public void addParameter( String name, Object value ) {
        Parameter p = new Parameter( name, value );
        addParameter( p );
    }

    /**
     * adds a new <tt>Parameter</tt> to the list
     * 
     * @param param
     */
    public void addParameter( Parameter param ) {
        params.put( param.getName(), param );
        keys.add( param.getName() );
    }

    /**
     * returns all <tt>Parameter</tt>s contained within the list as array. it is guarenteered
     * that the arrays isn't <tt>null</tt>
     * 
     * @return returns an array with all Parameters from the list.
     */
    public Parameter[] getParameters() {
        Parameter[] p = new Parameter[keys.size()];
        Iterator iter = keys.iterator();
        int i = 0;
        while ( iter.hasNext() ) {
            p[i++] = params.get( iter.next() );
        }
        return p;
    }

    /**
     * returns an array of all <tt>Parameter</tt>s names. it is guarenteered that the arrays
     * isn't <tt>null</tt>
     * 
     * @return parameter names
     */
    public String[] getParameterNames() {
        String[] s = new String[keys.size()];
        return keys.toArray( s );
    }

    /**
     * returns an array of all <tt>Parameter</tt>s values. it is guarenteered that the arrays
     * isn't <tt>null</tt>
     * 
     * @return parameter values
     */
    public Object[] getParameterValues() {
        Object[] o = new Object[keys.size()];
        for ( int i = 0; i < o.length; i++ ) {
            Parameter p = params.get( keys.get( i ) );
            o[i] = p.getValue();
        }
        return o;
    }

    /**
     * removes a parameter from the list
     * 
     * @param name
     *            name of the parameter
     * @return nemd parameter
     */
    public Parameter removeParameter( String name ) {
        keys.remove( name );
        return params.remove( name );
    }

    /**
     * @return string representation
     */
    public String toString() {
        String ret = null;
        ret = "params = " + params + "\n";
        return ret;
    }

}