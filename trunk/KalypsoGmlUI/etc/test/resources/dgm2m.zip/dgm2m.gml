<?xml version="1.0" encoding="WINDOWS-1252"?>
<gml:_FeatureCollection xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:gml="http://www.opengis.net/gml" xmlns:xs="http://www.w3.org/2001/XMLSchema-instance" gml:id="root">
	<gml:featureMember>
		<gml:RectifiedGridCoverage>
		 <rectifiedGridDomain xmlns="http://www.opengis.net/gml">
		  <gml:RectifiedGrid dimension="2">
		   <gml:limits>
		    <gml:GridEnvelope>
		     <gml:low>0 0</gml:low>
		     <gml:high>2715 3953</gml:high>
		    </gml:GridEnvelope>
		   </gml:limits>
		   <gml:origin>
		    <gml:Point srsName="EPSG:31468">
		     <gml:pos>4379380.0 5382474.0</gml:pos>
		    </gml:Point>
		   </gml:origin>
		   <rgc:offsetVector xmlns:rgc="http://www.opengis.net/gml">2.0 0.0</rgc:offsetVector>
		   <rgc:offsetVector xmlns:rgc="http://www.opengis.net/gml">0.0 -2.0</rgc:offsetVector>
		  </gml:RectifiedGrid>
		 </rectifiedGridDomain>

		 <gml:rangeSet xmlns:ns1="http://www.w3.org/2001/SMIL20/" xmlns:swe="http://www.opengis.net/swe" xmlns:st="http://www.seegrid.csiro.au/xml/st" xmlns:ns2="http://www.isotc211.org/2005/gmd" xmlns:ns3="http://www.isotc211.org/2005/gco" xmlns:ns4="http://www.isotc211.org/2005/gss" xmlns:ns5="http://www.isotc211.org/2005/gts" xmlns:ns6="http://www.isotc211.org/2005/gsr" xmlns:ns7="http://www.w3.org/2001/SMIL20/Language">
		  <gml:File>
		   <gml:fileName>dgm2m.ascbin</gml:fileName>
		   <gml:fileStructure>Record Interleaved</gml:fileStructure>
		   <gml:mimeType>image/bin</gml:mimeType>
		  </gml:File>
		 </gml:rangeSet>

		 <gml:description>Imported via Kalypso</gml:description>
		</gml:RectifiedGridCoverage>
	</gml:featureMember>
</gml:_FeatureCollection>